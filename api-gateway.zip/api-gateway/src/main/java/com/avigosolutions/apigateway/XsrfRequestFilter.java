package com.avigosolutions.apigateway;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;

@Component
public class XsrfRequestFilter extends ZuulFilter {
	private static final int FILTER_ORDER=1;
	private static final boolean SHOULD_FILTER=true;
	private static final String XSRF_REQUEST_HEADER_NAME = "X-Requested-With";
	private static final String XSRF_REQUEST_HEADER_VALUE = "XMLHttpRequest";
	private static final Logger logger = LoggerFactory.getLogger(XsrfRequestFilter.class);
	
	// Setting a dummy response body so that we are able to differentiate between this 403 response 
	// and any other without conveying the exact reason 
	private static final String FAILURE_RESPONSE_BODY = "ERROR_CODE: API: 1001";
	
	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return SHOULD_FILTER;
	}

	@Override
	public Object run() {
		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		
		// Below lines for logging incoming request
		String remoteAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR"):  request.getRemoteAddr();
		logger.info("Request uri ==>  " + ctx.getRequest().getRequestURI()+ ",  Remote Address ==> " + remoteAddress); 
		
		String xsrfHeaderValue = request.getHeader(XSRF_REQUEST_HEADER_NAME);
		if(xsrfHeaderValue == null || !xsrfHeaderValue.equals(XSRF_REQUEST_HEADER_VALUE)) {
			ctx.setSendZuulResponse(false);
			ctx.setResponseBody(FAILURE_RESPONSE_BODY);
			ctx.setResponseStatusCode(HttpStatus.FORBIDDEN.value());
		}
		
		return null;
	}

	@Override
	public String filterType() {
		return "pre";
	}

	@Override
	public int filterOrder() {
		return FILTER_ORDER;
	}

}
