#author Ajay Kumar
# Campaign Service
Campaign serivce source code for microservice.This service is responsible to manage campaigns.

### Prerequisites
  * Software: Campaign-service
  * JDK 1.8
  * Spring Boot. 
  * For Persistence, we are using SQL DB.
  * Tomcat as Embedded Server.
  * slf4j is used for logging.
  * Maven 3.0 is used to build project.
  * Using Azure DevOps for repo and deployment.
  * CI using Jenkins and Azure Conatainer service via Kubernetes.

### Documentation

[Technical and Functional documentation]

https://questdiagnostics.sharepoint.com/sites/DW-PROJECT/SPRINTT/Documents/Forms/AllItems.aspx?View=%7B0C3E433E%2DAFC3%2D400F%2DA077%2D86D8D1AF63B9%7D

### Installation and Build

  1. Move to the base of microservice folder i.e. ${PROJECT_CHECKOUT_FOLDER}\campaign-service.

  2. Configure user crdential,http,https and quest proxy in .gitconfig file.
  
  3. Run "mvn clean install" to build the project with unit test cases. 
  
  4. Run "maven clean install -DskipTests" to build all the project without unit test cases

  5. Import the project to the Eclipse IDE. 
  

### Database  
   
  Add/edit database related information like mongo db uri,password and database at ${PROJECT_CHECKOUT_FOLDER}\campaign-service\
  src\main\resources\application.properties .To enable db connectivity sql DB should install on local machine.
  
### Running the MicroService
   Move to the ${PROJECT_CHECKOUT_FOLDER}\campaign-service\target
   Execute command: campaign-service-0.0.1-SNAPSHOT.jar
   
### Dockerfile
  Location of executable jar,config path of the service are specified at ${PROJECT_CHECKOUT_FOLDER}\campaign-service\Dockerfile
  
### Deployment
  Location of deployment variables are specified at ${PROJECT_CHECKOUT_FOLDER}\campaign-service\deploy

### Versioning
  API versioning is followed.
  
### License
 QUEST DIAGNOSTICS PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 Copyright (c) 2020 Quest Diagnostics, Inc.
 All Rights Reserved. 

 NOTICE: All information contained herein is, and remains the property of Quest Diagnostics, Inc. The intellectual and technical concepts contained 
 herein are proprietary to Quest Diagnostics, Inc. and may be covered by U.S. 
 and Foreign Patents, patent applications, and are protected by trade secret 
 or copyright law. Dissemination of this information, reproduction of this  
 material, and copying or distribution of this software is strictly forbidden   
 unless prior written permission is obtained from Quest Diagnostics, Inc.