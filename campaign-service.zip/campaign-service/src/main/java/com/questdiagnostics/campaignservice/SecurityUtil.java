package com.questdiagnostics.campaignservice;

import java.nio.charset.Charset;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

@Service("securityUtil")
@Transactional(readOnly = true)
public class SecurityUtil {

	@Value("${sprintt.auth.user}")
	private String springAuthUser;

	@Value("${sprintt.auth.password}")
	private String springAuthPassword;

	@Value("${sprintt.auth.urlformat}")
	private String springAuthUrlFormat;

	@Value("${sprintt.auth.roleurlformat}")
	private String springAuthRoleUrlFormat;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private Map<String, Boolean> permissionMap = new HashMap<>();

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public boolean hasPermission(HttpHeaders headers, String entityName, String methodType) {
		String uniqueId = getUniqueIdValue(headers);
		String key = uniqueId + entityName + methodType;

		if (permissionMap.containsKey(key)) {
			boolean b = permissionMap.get(key).booleanValue();
			logger.info("hasPermission Returning from cache for {} -- {}", key, permissionMap.get(key));
			return b;
		}
		String urlStr = getURL(uniqueId, entityName, methodType);
		logger.info("***** urlStr: {} {} entity: {} " ,urlStr,entityName,methodType);
		HttpHeaders httpHeaders = createHeaders(springAuthUser, springAuthPassword);
		logger.info("HttpHeaders: " + httpHeaders.getValuesAsList("Authorization").toString());
		ResponseEntity<Boolean> response = restTemplate().exchange(urlStr, HttpMethod.GET,
				new HttpEntity<Object>(httpHeaders), boolean.class);
		setUserContext(uniqueId);
		boolean b = response.getBody();
		permissionMap.put(key, Boolean.valueOf(b));
		if(!b) {
			logger.warn("DENIED PERMISSION FOR USER -- {} ENTITY -- {} METHOD TYPE -- {}",uniqueId, entityName, methodType);
		}
		return b;
	}

	private String getUniqueIdValue(HttpHeaders headers) {
		String uniqueId = "";
		if (headers != null && !headers.isEmpty()) {
			List<String> uniqueValue = headers.get("UUID");
			if (!uniqueValue.isEmpty()) {
				uniqueId = uniqueValue.get(0);
			}
		}
		return uniqueId;
	}

	private String getURL(final String uid, final String entityName, final String methodType) {

		return String.format(springAuthUrlFormat, uid, entityName, methodType);
	}

	private HttpHeaders createHeaders(final String username, final String password) {
		HttpHeaders headers = new HttpHeaders() {
			/**
			* 
			*/
			private static final long serialVersionUID = 1L;

			{
				String auth = username + ":" + password;
				byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(Charset.forName("US-ASCII")));
				String authHeader = "Basic " + new String(encodedAuth);
				set("Authorization", authHeader);
			}
		};
		return headers;
	}

	public Long getRoleId(HttpHeaders headers) {
		String uName = getUniqueIdValue(headers);
		return getRoleId(uName);
	}

	public Long getRoleId(String uName) {
		try {
			String urlStr = String.format(springAuthRoleUrlFormat, uName);
			logger.info("***** urlStr: {} " ,urlStr);
			HttpHeaders httpHeaders = createHeaders(springAuthUser, springAuthPassword);
			logger.info("HttpHeaders: {} " ,httpHeaders.getValuesAsList("Authorization").toString());
			ResponseEntity<Long> response = restTemplate().exchange(urlStr, HttpMethod.GET,
					new HttpEntity<Object>(httpHeaders), Long.class);
			return response.getBody();
		} catch (Exception ex) {
			return 1L;
		}
	}

	private void setUserContext(String username) {

		try {
			logger.info("**** setting username into security context");
			PreAuthenticatedAuthenticationToken authentication = new PreAuthenticatedAuthenticationToken(username, "",
					null);
			SecurityContextHolder.getContext().setAuthentication(authentication);
			logger.info("**** setting username into security context** Successfull");
		} catch (Exception e) {
			SecurityContextHolder.getContext().setAuthentication(null);
			logger.error("Failure in setUserContext", e);
		}
	}

}