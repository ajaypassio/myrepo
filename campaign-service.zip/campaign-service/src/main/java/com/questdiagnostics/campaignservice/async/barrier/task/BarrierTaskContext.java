package com.questdiagnostics.campaignservice.async.barrier.task;

import com.questdiagnostics.campaignservice.async.task.TaskContext;

public class BarrierTaskContext extends TaskContext {
	
	protected BarrierTaskContext() {
		super();
	}
}