package com.questdiagnostics.campaignservice.async.barrier.task;

import java.util.concurrent.CyclicBarrier;

import com.questdiagnostics.campaignservice.async.task.CampaignAsyncTask;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;

public abstract class CampaignAsyncBarrierTask<T> extends CampaignAsyncTask {

	private CyclicBarrier barrier;
	
	private T data;
	
	private Boolean isStudyLink;
	
	protected CampaignAsyncBarrierTask() {
		super();
	}

	protected CyclicBarrier getBarrier() {
		return barrier;
	}

	public void initializeNewTask(long campaignId, long trialId, SprinttCampaignStatus taskType,
			int newJobStatusForCampaign, CyclicBarrier barrier) {
		super.initializeNewTask(campaignId, trialId, taskType, newJobStatusForCampaign);
		this.barrier = barrier;
	}

	public void initializeInterruptedTask(long campaignId, long trialId, Long jobId, SprinttCampaignStatus taskType,
			int newJobStatusForCampaign, CyclicBarrier barrier) {
		super.initializeInterruptedTask(campaignId, trialId, jobId, taskType, newJobStatusForCampaign);
		this.barrier = barrier;
	}

	protected T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public void setBarrier(CyclicBarrier barrier) {
		this.barrier = barrier;
	}
	
	public Boolean getIsStudyLink() {
		return isStudyLink;
	}

	public void setIsStudyLink(Boolean isStudyLink) {
		this.isStudyLink = isStudyLink;
	}
}
