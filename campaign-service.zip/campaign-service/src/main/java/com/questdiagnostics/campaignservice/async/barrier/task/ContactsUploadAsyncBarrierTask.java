package com.questdiagnostics.campaignservice.async.barrier.task;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.WHITESPACE;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.BrokenBarrierException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.manager.ContactManager;
import com.questdiagnostics.campaignservice.request.model.ContactRequest;
import com.questdiagnostics.campaignservice.response.model.FieldValue;
import com.questdiagnostics.campaignservice.util.ParticipantEncryptionUtil;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ContactsUploadAsyncBarrierTask extends CampaignAsyncBarrierTask<List<Object[]>> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ContactManager contactManager;

	@Autowired
	private ParticipantEncryptionUtil encryptionUtil;

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	
	@Value("${sprintt.token.id}")
	private String sprinttTokenId;

	@Override
	public Long call() throws Exception {
		Long retVal = -1l;
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		try {
			retVal = createContactsInEloquaBackend(getData(), localEntityManager, getIsStudyLink());
		} finally {
			try {
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
				getBarrier().await();
			} catch (InterruptedException e) {
				logger.error("Caught interrupted exception while creating contacts in eloqua: {}", e);
				Thread.currentThread().interrupt();
			} catch (BrokenBarrierException e) {
				logger.error("Caught broken barrier exception while creating contacts in eloqua: {}", e);
			}
		}
		return retVal;
	}

	private Long createContactsInEloquaBackend(List<Object[]> patientList, EntityManager localEntityManager,
			Boolean isStudyLink) throws EloquaException {
		for (Object[] patientData : patientList) {
			String contactId = (String) patientData[3];
			// a. create patient contacts in eloqua
			ContactRequest contactRequest = new ContactRequest();
			contactRequest.setFirstName((String) patientData[0]);
			contactRequest.setLastName((String) patientData[1]);
			contactRequest.setEmailAddress((String) patientData[2]);
			contactRequest.setId(StringUtils.isEmpty(contactId) ? "-1" : contactId);
			Long participantId = Long.valueOf(String.valueOf(patientData[4]));
			/*for including external study link*/
			if (!isStudyLink)
				contactRequest.setFieldValues(generateEncryptedParticipant(participantId));
			// handle no email addr case
			try {
				contactRequest.setId(contactManager.createContactInEloqua(contactRequest).getId());
				populateContactIdOfParticipant(contactRequest, participantId, localEntityManager);
			} catch (Exception e) {
				if (e.getMessage().contains("409")) {
					handleException(contactRequest, participantId, localEntityManager);
				} else if (e.getMessage().contains("400")) {
					logger.debug("contactRequest with email {} has been skipped due to 400 Validation Error: {}",
							contactRequest.getEmailAddress(), e.getMessage());
				} else {
					logger.debug("contactRequest with email {} has been skipped due to Error: {}",
							contactRequest.getEmailAddress(), e.getMessage());
				}
			}
		}
		return Long.valueOf(-1l);
	}

	private void handleException(ContactRequest contactRequest, Long participantId, EntityManager localEntityManager)
			throws EloquaException {
		logger.debug("email address {} already exists in eloqua.", contactRequest.getEmailAddress());
		contactManager.getContactIdByEmailFromEloqua(contactRequest.getEmailAddress()).ifPresent(existingContact -> {
			contactRequest.setId(existingContact.getId());
			existingContact.getFieldValues().stream().forEach(fieldValue -> {
				if (fieldValue.getId().equals(sprinttTokenId) && StringUtils.isEmpty(fieldValue.getValue())) {
					// call update eloqua
					try {
						contactRequest.setId(contactManager.updateContactInEloqua(contactRequest).getId());
					} catch (Exception exception) {
						logger.error("error occured during updaing contact in eloqua : {} ", exception.getMessage());
					}
				}
			});
			try {
				populateContactIdOfParticipant(contactRequest, participantId, localEntityManager);
			} catch (Exception e) {
				logger.debug("contactRequest with email {} has been skipped due to Error: {}",
						contactRequest.getEmailAddress(), e.getMessage());
			}
		});
	}

	private void populateContactIdOfParticipant(ContactRequest contactRequest, Long participantId,
			EntityManager localEntityManager) {
		/* Update participant table with eloqua contact id */
		
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("UPDATE P1 SET P1.ContactId=?,P1.UpdatedOn=? from")
						.append(WHITESPACE).append("DBO.Participant P1").append(WHITESPACE)
						.append("WHERE P1.ParticipantIdXRef=? ").toString());
		EntityTransaction transaction = null;
		try {
			transaction = localEntityManager.getTransaction();
			transaction.begin();
			query.setParameter(1, contactRequest.getId());
			query.setParameter(2, new Date());
			query.setParameter(3, participantId);
			query.executeUpdate();
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null)
				transaction.rollback();
		}

	}

	private List<FieldValue> generateEncryptedParticipant(Long participantId) {
		FieldValue fieldValue = new FieldValue();
		fieldValue.setType("FieldValue");
		fieldValue.setId(sprinttTokenId);
		fieldValue.setValue(encryptionUtil.encryptToBase64(String.valueOf(participantId)));
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(fieldValue);
		return fieldValueList;
	}
}
