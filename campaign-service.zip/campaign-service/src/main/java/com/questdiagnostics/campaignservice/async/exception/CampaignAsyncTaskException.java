package com.questdiagnostics.campaignservice.async.exception;

public class CampaignAsyncTaskException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CampaignAsyncTaskException() {
		super();
	}
	
	public CampaignAsyncTaskException(String message) {
		super(message);
	}

	public CampaignAsyncTaskException(Throwable cause) {
		super(cause);
	}
	
	public CampaignAsyncTaskException(String message, Throwable cause) {
		super(message, cause);
	}

	public CampaignAsyncTaskException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
