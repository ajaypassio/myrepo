package com.questdiagnostics.campaignservice.async.exception;

public class DiscardAsyncTaskException extends CampaignAsyncTaskException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DiscardAsyncTaskException() {
		super();
	}

	public DiscardAsyncTaskException(String message) {
		super(message);
	}

	public DiscardAsyncTaskException(Throwable cause) {
		super(cause);
	}
	
	public DiscardAsyncTaskException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public DiscardAsyncTaskException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
