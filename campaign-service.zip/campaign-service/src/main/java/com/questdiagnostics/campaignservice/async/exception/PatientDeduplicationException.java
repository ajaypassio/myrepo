package com.questdiagnostics.campaignservice.async.exception;

public class PatientDeduplicationException extends DiscardAsyncTaskException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PatientDeduplicationException() {
		super();
	}

	public PatientDeduplicationException(String message) {
		super(message);
	}

	public PatientDeduplicationException(Throwable cause) {
		super(cause);
	}

	public PatientDeduplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	public PatientDeduplicationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
