package com.questdiagnostics.campaignservice.async.exception;

public class PatientPropagationException extends DiscardAsyncTaskException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PatientPropagationException() {
		super();
	}

	public PatientPropagationException(String message) {
		super(message);
	}

	public PatientPropagationException(Throwable cause) {
		super(cause);
	}

	public PatientPropagationException(String message, Throwable cause) {
		super(message, cause);
	}

	public PatientPropagationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}
