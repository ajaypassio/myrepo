package com.questdiagnostics.campaignservice.async.exception;

public class ScheduleAsyncTaskException extends CampaignAsyncTaskException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ScheduleAsyncTaskException() {
		super();
	}

	public ScheduleAsyncTaskException(String message) {
		super(message);
	}

	public ScheduleAsyncTaskException(Throwable cause) {
		super(cause);
	}
		
	public ScheduleAsyncTaskException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public ScheduleAsyncTaskException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
