package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_EMPTY;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_IN_PROGRESS;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_IN_PROGRESS;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DISCARDED;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.task.CampaignAsyncTask;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.util.CommonUtil;
import com.questdiagnostics.campaignservice.workflowengine.CampaignStateTransitionManager;

public abstract class AsbtractCampaignAsyncTaskService implements CampaignAsyncTaskService {

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	protected void processTrialMap(Map<Long, List<CampaignMaster>> asyncTaskTrialMap,
			ScheduleRepository scheduleRepository, SprinttCampaignStatus taskType,
			CampaignMasterRepository campaignMasterRepository, TrialExecutorService campaignExecutorService,
			boolean avoidCutOffCheck, CampaignAsyncJobRepository campaignAsyncJobRepository) {
		asyncTaskTrialMap.forEach((trialId, taskCampaigns) -> {
			CampaignMaster eligibleCampaign = // avoidCutOffCheck ? taskCampaigns.get(0)
					getCampaignWithinCutOffPeriod(taskCampaigns, scheduleRepository, campaignAsyncJobRepository,
							avoidCutOffCheck);
			if (eligibleCampaign == null) {
				logger.warn("Skipping trial {} for execution as all {} campaigns are within cut-off period.", trialId,
						taskType.name());
				return;
			}
			CampaignAsyncTask task = prepareTask(eligibleCampaign, trialId, taskType);
			if (!task.isInitialized()) {
				logger.warn("All the {} jobs for trial {} and campaign {} have exhausted retry limits.",
						taskType.name(), trialId, eligibleCampaign.getSprinttCampaignId());
				return;
			}
			// check again if the trial is not in execution (lazy-check)
			if (!isTrialInExecution(trialId, campaignMasterRepository, campaignExecutorService)) {
				try {

					  // added remarks
				eligibleCampaign.setRemarks(CommonUtil.populateCampaignRemarks(eligibleCampaign.getRemarks(),
							CommonConstants.DEDUPLICATION_AND_CONTACT_STARTED));
				campaignMasterRepository.save(eligibleCampaign);

					logResultAndUpdateCampaignJobStatus(campaignExecutorService.submitTask(task, trialId),
							eligibleCampaign.getSprinttCampaignId(), taskType);
				} catch (Exception e) {
					logger.error("Caught error during {} task execution: {}", taskType.name(), e);
				}
			} else {
				logger.info("Skipped trial {} for {} process as it is in execution.", trialId, taskType.name());
			}
		});

	}

	/**
	 * Check if the campaign was already in-progress of the process could not be
	 * completed due to thread termination/interrupt.
	 * 
	 * @param campaignData
	 * @param trialId
	 * @param taskType
	 * @param task
	 * @param jobs
	 * @param jobStatus
	 * @return
	 */
	protected CampaignAsyncTask prepareTask(CampaignMaster campaignData, long trialId, SprinttCampaignStatus taskType,
			CampaignAsyncTask task, List<CampaignAsyncJob> jobs, int jobStatus) {
		if (!CollectionUtils.isEmpty(jobs)) {
			filterJobsOnRetries(jobs).ifPresent(job -> {
				logger.info("Resuming job {} for trial {} and campaign {} in {} process.", jobs.get(0).getId(), trialId,
						campaignData.getSprinttCampaignId(), taskType.name());
				task.initializeInterruptedTask(jobs.get(0).getCampaignId(), jobs.get(0).getTrialId(),
						jobs.get(0).getId(), taskType, jobStatus);
			});
		} else {
			logger.info("Creating new {} task for trial {} and campaign {}.", taskType, trialId,
					campaignData.getSprinttCampaignId());
			task.initializeNewTask(campaignData.getSprinttCampaignId(), trialId, taskType, jobStatus);
		}
		return task;
	}

	protected boolean isTrialInExecution(Long trialId, CampaignMasterRepository repo,
			TrialExecutorService executorService) {
		return executorService.isTrialInExecution(trialId) && repo.countInProgressCampaignJobsByTrialId(trialId,
				Arrays.asList(CONTACT_LIST_UPLOAD_IN_PROGRESS.getValue(), DISCARD_IN_PROGRESS.getValue())) > 0l;
	}

	protected Map<Long, List<CampaignMaster>> filterTrialsInExecution(List<CampaignMaster> campaignList,
			CampaignMasterRepository repo, TrialExecutorService executorService) {
		Map<Long, List<CampaignMaster>> trialMap = new HashMap<>();
		List<Long> skippedTrials = new ArrayList<>();
		for (CampaignMaster campaignData : campaignList) {
			if (!skippedTrials.contains(campaignData.getTrialId())) {
				if (!isTrialInExecution(campaignData.getTrialId(), repo, executorService)) {
					trialMap.computeIfAbsent(campaignData.getTrialId(), k -> new ArrayList<>());
					trialMap.computeIfPresent(campaignData.getTrialId(), (k, v) -> {
						v.add(campaignData);
						return v;
					});
				} else {
					skippedTrials.add(campaignData.getTrialId());
				}
			}
		}
		return trialMap;
	}

	protected void moveCampaignToDiscarded(CampaignMaster campaignData,
			CampaignStateTransitionManager campaignStateTransitionManager) {
		try {
			campaignData = campaignStateTransitionManager.forceExecute(campaignData, DISCARDED);
			campaignData.setCampaignJobStatusId(CONTACT_LIST_EMPTY.getValue());
			logger.info("Moved campaign {} to discarded as patient list is empty.",
					campaignData.getSprinttCampaignId());
		} catch (WorkflowEngineException e) {
			logger.error("Could not revert campaign {} state to DISCARDED due to: {}",
					campaignData.getSprinttCampaignId(), e);
		}
	}

	@Override
	public List<Integer> getJobStatusIds() {
		return Arrays.asList(CONTACT_LIST_UPLOAD_INITIATED.getValue(), CONTACT_LIST_UPLOAD_FAILED.getValue());
	}

}
