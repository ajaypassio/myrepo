package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.ASYNC_SERVICE_NAME;
import static com.questdiagnostics.campaignservice.constant.CommonConstants.WHITESPACE;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.model.AsyncJobModReplicas;
import com.questdiagnostics.campaignservice.repository.AsyncJobModReplicasRepository;

@Service
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class AsyncJobModReplicaService {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${no.of.pods}")
	private int modProperty;

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private AsyncJobModReplicasRepository modRepo;

	private int modAcquired;

	private boolean isModReplicationEnabled = true;

	/**
	 * 1. Generate a modulus value based on modulus property.
	 * 
	 * 2. Check if the modulus value exists in database for the service.
	 * 
	 * 3. If the modulus value does not exist, then acquire it and reserve.
	 * 
	 * 4. If the modulus value exists in database, check it's updated on date.
	 * 
	 * 5. If the updated on date is null or before 90 seconds from current time,
	 * then acquire the modulus.
	 * 
	 * 6. If the above generated modulus is already acquired by another pod (within
	 * last 90 seconds), then try with another modulus value and repeat steps 1-5
	 * 
	 * @param modRepo
	 * @return
	 */
	@PostConstruct
	private void acquireModForServicePod() {
		String serviceName = ASYNC_SERVICE_NAME;
		int currentMod = 0;
		if (modProperty != 1) {
			EntityManager localEntityManager = entityManagerFactory.createEntityManager();
			try {
				AsyncJobModReplicas asyncJobModReplica = modRepo.findByModValueAndServiceName(currentMod, serviceName);
				if (asyncJobModReplica == null) {
					modAcquired = insertModForService(currentMod, serviceName, localEntityManager);
				} else {
					modAcquired = updateModForServiceNew(currentMod, serviceName, localEntityManager);
				}
			} finally {
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
			}
			logger.info("mod acquired for service pod is {}", modAcquired);
		} else {
			modAcquired = modProperty;
			isModReplicationEnabled = false;
			logger.info("mod replication is disabled as mod property is 1.");
		}
		cleanUpRedundantMods(serviceName);
	}

	private void cleanUpRedundantMods(String serviceName) {
		List<AsyncJobModReplicas> jobModReplicasList = modRepo.findAll();
		if (!CollectionUtils.isEmpty(jobModReplicasList)) {
			int diff = jobModReplicasList.size() - modProperty;
			if (modProperty == 1) {
				modRepo.performCleanUp();
				logger.info("Deleted all mods for {} service as mod property is 1.", serviceName);
			} else if (diff > 0) {
				for (int i = 0; i < diff; i++) {
					modRepo.performCleanUpForModValueAndServiceName(i + modProperty, serviceName);
					logger.info("Deleted redundant mod {} for {} service.", i + modProperty, serviceName);
				}
			}
		}
	}

	public int insertModForService(int currentMod, String serviceName, EntityManager localEntityManager) {
		if (currentMod < modProperty) {
			EntityTransaction transaction = null;
			AsyncJobModReplicas modReplica = new AsyncJobModReplicas();
			modReplica.setModValue(currentMod);
			modReplica.setServiceName(serviceName);
			try {
				transaction = localEntityManager.getTransaction();
				transaction.begin();
				localEntityManager.persist(modReplica);
				transaction.commit();
			} catch (Exception e) {
				if (transaction != null) {
					transaction.rollback();
					currentMod = currentMod + 1;
					currentMod = insertModForService(currentMod, serviceName, localEntityManager);
				}
			}
		}
		return currentMod;
	}

	public int updateModForServiceNew(int currentMod, String serviceName, EntityManager localEntityManager) {
		if (currentMod < modProperty) {
			EntityTransaction transaction = null;
			try {
				transaction = localEntityManager.getTransaction();
				transaction.begin();
				List<AsyncJobModReplicas> modReplicas = localEntityManager
						.createQuery(
								new StringBuilder("SELECT a FROM AsyncJobModReplicas a WHERE").append(WHITESPACE)
										.append("a.modValue = :modValue AND a.serviceName = :serviceName").toString(),
								AsyncJobModReplicas.class)
						.setParameter("modValue", currentMod).setParameter("serviceName", serviceName).getResultList();
				if (CollectionUtils.isEmpty(modReplicas)) {
					transaction.commit();
					return insertModForService(currentMod, serviceName, localEntityManager);
				}
				AsyncJobModReplicas modReplica = modReplicas.get(0);
				localEntityManager.lock(modReplica, LockModeType.PESSIMISTIC_FORCE_INCREMENT);
				Date updatedOn = modReplica.getUpdatedOn() == null ? null : modReplica.getUpdatedOn();
				if (isLastAcquiredModBefore(75, updatedOn, modReplica.getCreatedOn())) {
					modReplica.setUpdatedOn(new Date());
					localEntityManager.persist(modReplica);
					transaction.commit();
				} else {
					transaction.commit();
					currentMod = currentMod + 1;
					currentMod = updateModForServiceNew(currentMod, serviceName, localEntityManager);
				}
			} catch (Exception e) {
				if (transaction != null) {
					transaction.rollback();
					currentMod = currentMod + 1;
					currentMod = updateModForServiceNew(currentMod, serviceName, localEntityManager);
				}
			}
		}
		return currentMod;
	}

	private boolean isLastAcquiredModBefore(int seconds, Date updatedOn, Date createdOn) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.SECOND, -seconds);
		Date cutOffTime = cal.getTime();
		return (updatedOn == null) ? createdOn.before(cutOffTime) : updatedOn.before(cutOffTime);
	}

	public int getModAcquired() {
		return modAcquired;
	}

	public boolean isModReplicationEnabled() {
		return isModReplicationEnabled;
	}

	public int getModProperty() {
		return modProperty;
	}

}
