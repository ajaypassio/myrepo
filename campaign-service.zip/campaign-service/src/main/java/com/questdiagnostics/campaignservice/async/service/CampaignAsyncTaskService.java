package com.questdiagnostics.campaignservice.async.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.task.CampaignAsyncTask;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;

public interface CampaignAsyncTaskService {

	void executeTask();

	void logResultAndUpdateCampaignJobStatus(Future<Long> future, long campaignId, SprinttCampaignStatus taskType)
			throws InterruptedException, ExecutionException;

	CampaignAsyncTask prepareTask(CampaignMaster campaignData, long trialId, SprinttCampaignStatus taskType);

	void updateCampaignJobStatus(int newCampaignJobStatus, long campaignId);

	List<Integer> getJobStatusIds();

	default void updateCampaignJobStatus(int newCampaignJobStatus, long campaignId,
			CampaignMasterRepository campaignMasterRepository) {
		campaignMasterRepository.findById(campaignId).ifPresent(campaign -> {
			campaign.setCampaignJobStatusId(newCampaignJobStatus);
			campaign = campaignMasterRepository.save(campaign);
		});
	}

	default Optional<CampaignAsyncJob> filterJobsOnRetries(List<CampaignAsyncJob> jobs) {
		for (CampaignAsyncJob job : jobs) {
			if (job.getNoOfRetries() < 2)
				return Optional.ofNullable(job);
		}
		return Optional.ofNullable(null);
	}

	/**
	 * 1. for all order campaigns by date asc 2. if a job exists within allowed
	 * retry limit, filter on cutoff 3. if 2 exists return 4. if not then a new
	 * request - filter on cutoff
	 * 
	 * @param campaigns
	 * @param scheduleRepository
	 * @param campaignAsyncJobRepository
	 * @param avoidCutOffCheck
	 * @return
	 */
	default CampaignMaster getCampaignWithinCutOffPeriod(List<CampaignMaster> campaigns,
			ScheduleRepository scheduleRepository, CampaignAsyncJobRepository campaignAsyncJobRepository,
			boolean avoidCutOffCheck) {
		CampaignMaster returnVal = null;
		for (CampaignMaster campaign : campaigns) {
			campaign.setSchedule(scheduleRepository.findById(campaign.getScheduleId()).orElse(null));
			List<CampaignAsyncJob> jobs = campaignAsyncJobRepository.findPendingOrFailedJobsForTrialAndCampaign(
					campaign.getTrialId(), campaign.getSprinttCampaignId(), getJobStatusIds());

			if (!CollectionUtils.isEmpty(jobs)) {
				if (!filterJobsOnRetries(jobs).isPresent()) {
					continue;
				}
				returnVal = filterCampaignOnCutOff(avoidCutOffCheck, campaign);
			} else {
				returnVal = filterCampaignOnCutOff(avoidCutOffCheck, campaign);
			}
			if (returnVal != null) {
				return returnVal;
			}
		}
		return null;
	}

	default CampaignMaster filterCampaignOnCutOff(boolean avoidCutOffCheck, CampaignMaster campaign) {
		if (avoidCutOffCheck) {
			return campaign;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		// cal.add(Calendar.HOUR_OF_DAY, 1);
		cal.add(Calendar.MINUTE, 5);
		Date cutOffTime = cal.getTime();
		if (campaign.getSchedule().getNormalizedStartDateTime().after(cutOffTime)) {
			return campaign;
		}
		return null;
	}

	default List<CampaignMaster> getCampaignsWithinCutOffPeriod(List<CampaignMaster> campaigns,
			ScheduleRepository scheduleRepository) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		// cal.add(Calendar.HOUR_OF_DAY, 1);
		cal.add(Calendar.MINUTE, 5);
		Date cutOffTime = cal.getTime();
		List<CampaignMaster> retList = new ArrayList<>();
		for (CampaignMaster campaign : campaigns) {
			campaign.setSchedule(scheduleRepository.findById(campaign.getScheduleId()).orElse(null));
			if (campaign.getSchedule().getNormalizedStartDateTime().after(cutOffTime))
				retList.add(campaign);
		}
		return retList;
	}
}