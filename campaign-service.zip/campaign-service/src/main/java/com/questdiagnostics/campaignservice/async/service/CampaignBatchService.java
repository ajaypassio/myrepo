package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_INITIATED;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import org.slf4j.Logger;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.task.TaskContext;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.manager.ContactListManager;
import com.questdiagnostics.campaignservice.manager.ContactSegmentManager;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJobBatch;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.EmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.request.model.ContactListRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElement;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElementList;
import com.questdiagnostics.campaignservice.response.model.ContactListResponse;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentResponse;

public interface CampaignBatchService {

	Long executeCampaignJobInBatches(TaskContext taskContext);

	default CampaignAsyncJob initializeNewJob(CampaignJobStatus taskInitialStatus, int batchSize,
			TaskContext taskContext) {
		CampaignAsyncJob job = new CampaignAsyncJob();
		job.setTrialId(taskContext.getTrialId());
		job.setCampaignId(taskContext.getCampaignId());
		job.setBatchSize(batchSize);
		job.setJobStatus(taskInitialStatus);
		job.setJobType(taskContext.getTaskType().getValue());
		return job;
	}

	default CampaignAsyncJob initializeFailedJob(CampaignAsyncJobRepository repo, Long jobId, TaskContext taskContext) {
		return fetchJobFromDB(repo, jobId);
	}

	default CampaignAsyncJob fetchJobFromDB(CampaignAsyncJobRepository repo, Long jobId) {
		return repo.findById(jobId).orElseGet(null);
	}

	default CampaignAsyncJobBatch prepareBatch(CampaignAsyncJob job, List<Object[]> patientBatch, int batchStatus,
			int arrIdx) {
		int patientBatchSize = CollectionUtils.isEmpty(patientBatch) ? 0 : patientBatch.size();
		// create batch and update job table
		CampaignAsyncJobBatch batch = new CampaignAsyncJobBatch();
		batch.setBatchSize(patientBatchSize);
		batch.setBatchStatus(batchStatus);
		batch.setStartPos(Long.valueOf(String.valueOf(patientBatch.get(0)[arrIdx])));
		batch.setEndPos(Long.valueOf(String.valueOf(patientBatch.get(patientBatchSize - 1)[arrIdx])));
		job.addJobBatch(batch);

		return batch;
	}

	default void updateRetryJob(CampaignAsyncJob job, TaskContext taskContext) {
		if (taskContext.isFailedOnLastExecution()) {
			job.setNoOfRetries(job.getNoOfRetries() + 1);
			job.setUpdatedOn(new Date());
		}
	}

	default void updateRetryBatch(CampaignAsyncJobBatch batch, TaskContext taskContext) {
		if (taskContext.isFailedOnLastExecution()) {
			batch.setNoOfRetries(batch.getNoOfRetries() + 1);
			batch.setUpdatedOn(new Date());
		}
	}

	default String truncateFailureMessage(String errorMsg) {
		if (errorMsg == null) {
			return null;
		}
		return errorMsg.length() > 1000 ? errorMsg.substring(0, errorMsg.length() - 1) : errorMsg;
	}

	default CampaignAsyncJob updateJob(CampaignAsyncJob job, CampaignAsyncJobBatch batch, List<Object[]> patientBatch,
			TaskContext taskContext, CampaignAsyncJobRepository repo) {
		// if current batch is a failed batch and is not yet re-tried, don't add it job
		if (!(taskContext.isFailedOnLastExecution() && taskContext.getFailedBatchRetryStatus() == null)) {
			job.setNumberOfBatches(job.getNumberOfBatches() + 1);
			job.setTotalRecordsProcessed(
					job.getTotalRecordsProcessed() + (CollectionUtils.isEmpty(patientBatch) ? 0 : patientBatch.size()));
		}

		if (job.getStartPos() == 0l || batch.getStartPos() < job.getStartPos()) {
			job.setStartPos(batch.getStartPos());
		}
		if (batch.getEndPos() > job.getEndPos()) {
			job.setEndPos(batch.getEndPos());
		}
		job.setUpdatedOn(new Date());
		return repo.save(job);
	}

	default CampaignMaster retrieveCampaignData(Optional<CampaignMaster> campaignDataOpt, ScheduleRepository scheduleRepository,
			EmailTemplateRepository emailTemplateRepository) {
		CampaignMaster campaignData = campaignDataOpt.get();
		scheduleRepository.findById(campaignData.getScheduleId()).ifPresent(campaignData::setSchedule);
		emailTemplateRepository.findById(campaignData.getEmailTemplateId()).ifPresent(campaignData::setEmailTemplate);
		return campaignData;
	}

	default CampaignAsyncJob retrieveCampaignAsyncJob(Long jobId, CampaignAsyncJobRepository repo) {
		Optional<CampaignAsyncJob> jobOpt = repo.findById(jobId);
		if (jobOpt.isPresent()) {
			return jobOpt.get();
		}
		return null;
	}

	default void saveOrUpdateContactListBatchInEloqua(CampaignMaster campaignData, List<Object[]> patientBatch,
			CampaignAsyncJobBatch batch, boolean isMembershipAddition, Logger log,
			ContactSegmentManager contactSegmentManager, ContactListManager contactListManager) throws EloquaException {
		if (CollectionUtils.isEmpty(patientBatch)) {
			batch.setBatchStatus(CONTACT_LIST_UPLOAD_COMPLETED.getValue());
			return;
		}
		batch.setBatchStatus(CONTACT_LIST_UPLOAD_INITIATED.getValue());
		ContactSegmentResponse contactSegmentResponse = contactSegmentManager
				.getContactSegmentFromEloqua(String.valueOf(campaignData.getSegmentId()));

		ContactListRequest contactListRequest = new ContactListRequest();
		List<String> contactIds = new ArrayList<>();
		patientBatch.forEach(item -> contactIds.add(String.valueOf(item[0])));
		// update - add/delete contact IDs
		if (!CollectionUtils.isEmpty(contactSegmentResponse.getElements())) {
			contactListRequest.setId(contactSegmentResponse.getElements().get(0).getList().getId());
			contactListRequest.setName(contactSegmentResponse.getElements().get(0).getList().getName());
			if (isMembershipAddition) {
				contactListRequest.setMembershipAdditions(contactIds);
			} else {
				contactListRequest.setMembershipDeletions(contactIds);
			}
			ContactListResponse contactListResponse = contactListManager.updateContactListInEloqua(contactListRequest);
			log.info("contact list Id {} updated for campaign {} for jobId {}", contactListResponse.getId(),
					campaignData.getSprinttCampaignId(), batch.getCampaignAsyncJob().getId());
		} else {/**
				 * create contact list with contact IDs and update segment with the new contact
				 * list ID
				 */
			contactListRequest
					.setName(campaignData.getTrialId() + "_" + campaignData.getCampaignId() + "_participants");
			contactListRequest.setMembershipAdditions(contactIds);
			ContactListResponse contactListResponse = contactListManager.createContactListInEloqua(contactListRequest);
			log.info("contact list Id {} created for campaign {} and segment Id {} for jobId {}",
					contactListResponse.getId(), campaignData.getSprinttCampaignId(), campaignData.getSegmentId(),
					batch.getCampaignAsyncJob().getId());
			ContactSegmentRequest contactSegmentReq = new ContactSegmentRequest();
			contactSegmentReq.setId(String.valueOf(campaignData.getSegmentId()));
			contactSegmentReq.setName(contactSegmentResponse.getName());
			List<ContactSegmentRequestElement> elements = new ArrayList<>();
			ContactSegmentRequestElement element = new ContactSegmentRequestElement();
			ContactSegmentRequestElementList list = new ContactSegmentRequestElementList();
			list.setId(contactListResponse.getId());
			list.setName(contactListRequest.getName());
			element.setList(list);
			elements.add(element);
			contactSegmentReq.setElements(elements);
			contactSegmentManager.updateContactSegmentInEloqua(contactSegmentReq);
		}
		batch.setBatchStatus(CONTACT_LIST_UPLOAD_COMPLETED.getValue());
	}

	default long updateJobAndGenerateConsolidatedReport(CampaignAsyncJob jobLocal, CampaignAsyncJobRepository repo,
			Logger logger) {
		long jobId;
		jobLocal = repo.save(jobLocal);
		jobId = jobLocal.getId();
		//logger.info("consolidate job report: {}", jobLocal);
		return jobId;
	}

	static class Bound {
		private Long lowerBound;
		private Long upperBound;

		public Bound() {
			// default constructor
		}

		public Long getLowerBound() {
			return lowerBound;
		}

		public Long getUpperBound() {
			return upperBound;
		}

		public Bound bounds(CampaignAsyncJobBatch batch, int lowerBoundIdx, int upperBoundIdx) {
			String[] dataArr = batch.getRemarks2().split(",");
			this.lowerBound = Long.valueOf(dataArr[lowerBoundIdx]);
			this.upperBound = Long.valueOf(dataArr[upperBoundIdx]);
			return this;
		}

		public static String concatenateData(long... longArr) {
			return LongStream.of(longArr).mapToObj(Long::toString).collect(Collectors.joining(","));
		}

		public static CampaignAsyncJobBatch setBatchForPropagationBounds(CampaignAsyncJobBatch batch,
				List<Object[]> propagatablePatientBatch) {
			batch.setRemarks2(Bound.concatenateData(Long.valueOf(String.valueOf(propagatablePatientBatch.get(0)[1])),
					Long.valueOf(String.valueOf(propagatablePatientBatch.get(0)[2])),
					Long.valueOf(String.valueOf(propagatablePatientBatch.get(propagatablePatientBatch.size() - 1)[1])),
					Long.valueOf(
							String.valueOf(propagatablePatientBatch.get(propagatablePatientBatch.size() - 1)[2]))));
			return batch;
		}
	}

}