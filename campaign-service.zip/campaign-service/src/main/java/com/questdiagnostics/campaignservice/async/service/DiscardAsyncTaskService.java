package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_IN_PROGRESS;
import static com.questdiagnostics.campaignservice.enums.EloquaCampaignStatus.DRAFT;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DISCARDED;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.task.CampaignAsyncTask;
import com.questdiagnostics.campaignservice.async.task.DiscardAsyncTask;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;

@Service
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class DiscardAsyncTaskService extends AsbtractCampaignAsyncTaskService {

	@Autowired
	private TrialExecutorService campaignExecutorService;

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@Autowired
	private CampaignAsyncJobRepository campaignAsyncJobRepository;

	@Autowired
	private ObjectFactory<DiscardAsyncTask> prototypeDiscardTaskFactory;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private AsyncJobModReplicaService asyncJobModReplicaService;

	/**
	 * 1a. Find all DISCARD_INITIATED campaigns which are currently in scheduled
	 * state.
	 * 
	 * 1b. For each campaign, find whether its trial has an "in-progress" operation
	 * already running (deploy, schedule, discard) for a campaign. If such an
	 * "in-progress" campaign exists, skip the trial and try later when the
	 * operation has ended.
	 * 
	 * 1c. For each trial find the earliest created campaign (and has a discard
	 * request initiated by above parameters), fetch the patients with non-null
	 * contact IDs from the corresponding trial table to create the patient
	 * propagation list.
	 * 
	 * 2. Find the list for scheduled (process completed) campaigns.
	 * 
	 * 3. For each scheduled campaign, patients' without contact IDs need to be
	 * compared to the above campaign's patients. If a null exists in contact ID
	 * column for the scheduled campaign, propagate the contact ID to this
	 * participant and update contact list in Eloqua for this campaign, updating the
	 * contact ID to null in the original campaign.
	 * 
	 * 4. If discarded campaign's contact IDs aren't exhausted while the scheduled
	 * campaign is exhausted, repeat step 3 for the next scheduled campaign (if it
	 * exists). If no more scheduled campaigns exists, patient propagation for the
	 * discarded campaign is complete.
	 * 
	 * 5. Execute steps 1-4 for one and exactly one discard (initiated) campaign in
	 * thread/trial model (one thread per trial table). Each thread should perform
	 * the steps with a pre-determined (configured) batch of patients. After each
	 * batch is completed, the job table needs to be be updated.
	 * 
	 */

	@Scheduled(initialDelay = 30000l, fixedRateString = "${scheduler.cron.job.fixedrate.discard}")
	@Override
	public void executeTask() {
		// find all discard initiated (failed, in-progress) campaigns for all trials
		logger.debug("Discard async task job started.");
		List<CampaignMaster> discardedCampaignList = asyncJobModReplicaService.isModReplicationEnabled()
				? campaignMasterRepository.findCampaignByStatusAndJobStatusesByMod(DISCARDED.getValue(),
						Arrays.asList(DISCARD_FAILED.getValue(), DISCARD_IN_PROGRESS.getValue(),
								DISCARD_INITIATED.getValue()),
						asyncJobModReplicaService.getModProperty(), asyncJobModReplicaService.getModAcquired())
				: campaignMasterRepository.findCampaignByStatusAndJobStatuses(DISCARDED.getValue(), Arrays.asList(
						DISCARD_FAILED.getValue(), DISCARD_IN_PROGRESS.getValue(), DISCARD_INITIATED.getValue()));
		if (!CollectionUtils.isEmpty(discardedCampaignList)) {
			Map<Long, List<CampaignMaster>> discardableTrialMap = filterTrialsInExecution(discardedCampaignList,
					campaignMasterRepository, campaignExecutorService);
			if (!CollectionUtils.isEmpty(discardableTrialMap)) {
				processTrialMap(discardableTrialMap, scheduleRepository, DISCARDED, campaignMasterRepository,
						campaignExecutorService, true, campaignAsyncJobRepository);
			} else {
				logger.info(
						"All discard campaign requests are in progress. No pending discard request found for any scheduled campaign.");
			}
		} else {
			logger.info("No discard requests were found for any scheduled campaigns.");
		}
		logger.debug("Discard async task job ended.");
	}

	@Override
	public CampaignAsyncTask prepareTask(CampaignMaster campaignData, long trialId, SprinttCampaignStatus taskType) {
		CampaignAsyncTask task = getDiscardTaskInstance();
		List<CampaignAsyncJob> jobs = campaignAsyncJobRepository.findPendingOrFailedJobsForTrialAndCampaign(trialId,
				campaignData.getSprinttCampaignId(),
				Arrays.asList(DISCARD_FAILED.getValue(), DISCARD_INITIATED.getValue()));

		return super.prepareTask(campaignData, trialId, taskType, task, jobs, DISCARD_IN_PROGRESS.getValue());
	}

	@Override
	public void logResultAndUpdateCampaignJobStatus(Future<Long> future, long campaignId,
			SprinttCampaignStatus taskType) throws InterruptedException, ExecutionException {
		campaignAsyncJobRepository.findById(future.get()).ifPresent(job -> {
			campaignMasterRepository.findById(campaignId).ifPresent(campaign -> {
				switch (CampaignJobStatus.getStatusOf(job.getJobStatus())) {
				case DISCARD_COMPLETED:
					campaign.setEloCampgnStatusId(DRAFT.getValue());
					campaign.setCampaignJobStatusId(DISCARD_COMPLETED.getValue());
					break;
				case DISCARD_FAILED:
				case DISCARD_INITIATED:
				default:
					campaign.setCampaignJobStatusId(DISCARD_FAILED.getValue());
					break;
				}
				campaign.setUpdatedOn(new Date());
				campaignMasterRepository.save(campaign);
			});
			logger.info("job {} completed with status {} for campaign {} and trial {} for {} process.", job.getId(),
					CampaignJobStatus.getStatusOf(job.getJobStatus()).getType(), job.getCampaignId(), job.getTrialId(),
					taskType);
		});
	}

	public DiscardAsyncTask getDiscardTaskInstance() {
		return prototypeDiscardTaskFactory.getObject();
	}

	@Override
	public void updateCampaignJobStatus(int newCampaignJobStatus, long campaignId) {
		super.updateCampaignJobStatus(newCampaignJobStatus, campaignId, campaignMasterRepository);
	}

	@Override
	public List<Integer> getJobStatusIds() {
		return Arrays.asList(DISCARD_FAILED.getValue(), DISCARD_INITIATED.getValue());
	}
}
