package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.WHITESPACE;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DRAFT;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.barrier.task.CampaignAsyncBarrierTask;
import com.questdiagnostics.campaignservice.async.barrier.task.ContactsUploadAsyncBarrierTask;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.util.CommonUtil;

/**
 * @author Ajay Kumar
 *
 */
@Component
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class PatientContactGeneratorAsyncService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@Autowired
	private CommonUtil commonUtil;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private ObjectFactory<ContactsUploadAsyncBarrierTask> prototypeContactsUploadABTFactory;

	@Autowired
	private TrialExecutorService trialExecutorService;

	private int noOfParallelBatches = 8;

	@Value("${contact.upload.batch.size}")
	private int contactUploadBatchSize;

	@Autowired
	private AsyncJobModReplicaService asyncJobModReplicaService;

	private static final String SELECT = "SELECT P.FirstName, P.LastName, P.EmailAddress, P.ContactId, P.ParticipantIdXRef";
	private static final String JOIN = "AS PS INNER JOIN DBO.Participant P ON P.ParticipantIdXRef = PS.ParticipantId";
	private static final String WHERE = "WHERE PS.SprinttCampaignId=? AND P.EmailAddress IS NOT NULL ";
	private static final String ORDER = "ORDER BY P.ParticipantIdXRef ASC";
	private static final String OFFSET = "OFFSET";
	private static final String ROWS = "ROWS FETCH NEXT";
	private static final String ONLY = "ROWS ONLY";

	@Scheduled(fixedDelayString = "${scheduler.cron.job.fixeddelay.contact.upload}")
	public void processPatientContactIdGeneration() {
		Instant begin = Instant.now();
		logger.info("Contact uploads job started");

		fetchCamapignsParallelBatchProcessing();

		Instant end = Instant.now();
		logger.info("Contact uploads job completed and took {} seconds", Duration.between(begin, end).getSeconds());
	}

	private void fetchCamapignsParallelBatchProcessing() {
		List<CampaignMaster> campaignList = asyncJobModReplicaService.isModReplicationEnabled()
				? campaignMasterRepository.fetchSheduleAndDraftCampaignsWithSucccessByMod(
						Arrays.asList(CampaignJobStatus.Success.getValue(),
								CampaignJobStatus.CONTACTS_UPLOAD_INITIATED.getValue(),
								CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue(),
								CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue()),
						Arrays.asList(SprinttCampaignStatus.DEPLOYED.getValue(),
								SprinttCampaignStatus.SCHEDULED.getValue()),
						asyncJobModReplicaService.getModProperty(), asyncJobModReplicaService.getModAcquired())
				: campaignMasterRepository.fetchSheduleAndDraftCampaignsWithSucccess(
						Arrays.asList(CampaignJobStatus.Success.getValue(),
								CampaignJobStatus.CONTACTS_UPLOAD_INITIATED.getValue(),
								CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue(),
								CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue()),
						Arrays.asList(SprinttCampaignStatus.DEPLOYED.getValue(),
								SprinttCampaignStatus.SCHEDULED.getValue()));
		if (!CollectionUtils.isEmpty(campaignList)) {
			campaignList.forEach(campaignMaster -> {
				campaignMaster.setCampaignJobStatusId(CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue());
				commonUtil.buildUpdateAuditField(campaignMaster,
						CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue());
				campaignMasterRepository.save(campaignMaster);
				try {
					// spawn (noOfParallelBatches) worker threads fed with barrier synchronizer
					executeParallelBatches(campaignMaster);

					campaignMaster.setCampaignJobStatusId(CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue());
					commonUtil.buildUpdateAuditField(campaignMaster,
							CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue());
					campaignMasterRepository.save(campaignMaster);
				} catch (Exception e) {
					logger.error("Failed the contact generation list === {} ", e);
					campaignMaster.setCampaignJobStatusId(CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue());
					commonUtil.buildUpdateAuditField(campaignMaster,
							CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue());
					campaignMasterRepository.save(campaignMaster);
					// update fail counter for this campaign
				}
			});
		}
	}

	private void executeParallelBatches(CampaignMaster campaignMaster) throws InterruptedException, ExecutionException {
		boolean patientListEmpty = false;
		logger.info("Contact Upload Batch Size = {}", contactUploadBatchSize);
		CyclicBarrier barrier = new CyclicBarrier(noOfParallelBatches);
		int offset = 0;
		while (!patientListEmpty) {
			// reset offset and barrier task list for the next set of parallel batches
			List<CampaignAsyncBarrierTask<List<Object[]>>> barrierTasks = new ArrayList<>();
			List<Object[]> patientBatch = getContactBatch(campaignMaster.getTrialId(),
					campaignMaster.getSprinttCampaignId(), contactUploadBatchSize, offset);
			if (CollectionUtils.isEmpty(patientBatch)) {
				break;
			}
			for (int i = 0; i < noOfParallelBatches; i++) {
				CampaignAsyncBarrierTask<List<Object[]>> batchBarrierTask = getContactsUploadAsyncBarrierTaskInstance();
				batchBarrierTask.initializeNewTask(campaignMaster.getSprinttCampaignId(), campaignMaster.getTrialId(),
						DRAFT, CONTACTS_UPLOAD_IN_PROGRESS.getValue(), barrier);
				batchBarrierTask.setData(patientBatch);
				batchBarrierTask.setIsStudyLink(campaignMaster.isExternalStudyLink());
				barrierTasks.add(batchBarrierTask);

				offset = offset + contactUploadBatchSize;
				logger.debug("Offset {} and batch size {} ", offset, contactUploadBatchSize);
				patientBatch = getContactBatch(campaignMaster.getTrialId(), campaignMaster.getSprinttCampaignId(),
						contactUploadBatchSize, offset);
				if (CollectionUtils.isEmpty(patientBatch)) {
					patientListEmpty = true;
					break;
				}
			}
			logger.debug("{} parallel batch tasks prepared for barrier synchronizer", noOfParallelBatches);
			if (!CollectionUtils.isEmpty(barrierTasks)) {
				int barrierTaskSize = barrierTasks.size();
				if (barrierTaskSize != noOfParallelBatches) {
					barrier = new CyclicBarrier(barrierTaskSize);
					logger.debug("Re-initialized cyclic barrier with {} parties.", barrierTaskSize);
				}
				List<Future<Long>> futureResults = new ArrayList<>();
				for (CampaignAsyncBarrierTask<List<Object[]>> barrierTask : barrierTasks) {
					barrierTask.setBarrier(barrier);
					futureResults.add(trialExecutorService.submitTask(barrierTask));
				}
				for (Future<Long> futureResult : futureResults) {
					futureResult.get();
				}
				barrier.reset();
				logger.debug("Parallel batch executed and cyclic barrier reset.");
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> getContactBatch(long trialId, long campaignId, int limit, int offset) {
		Query query = entityManager.createNativeQuery(new StringBuilder(SELECT).append(WHITESPACE).append("FROM")
				.append(WHITESPACE).append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE).append(JOIN)
				.append(WHITESPACE).append(WHERE).append(WHITESPACE).append(ORDER).append(WHITESPACE).append(OFFSET)
				.append(WHITESPACE).append(offset).append(WHITESPACE).append(ROWS).append(WHITESPACE).append(limit)
				.append(WHITESPACE).append(ONLY).toString());
		query.setParameter(1, String.valueOf(campaignId));
		return query.getResultList();
	}

	public ContactsUploadAsyncBarrierTask getContactsUploadAsyncBarrierTaskInstance() {
		return prototypeContactsUploadABTFactory.getObject();
	}

}