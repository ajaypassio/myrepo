package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.WHITESPACE;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_EMPTY;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DEDUPLICATION_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DEDUPLICATION_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DEDUPLICATION_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.exception.PatientDeduplicationException;
import com.questdiagnostics.campaignservice.async.exception.ScheduleAsyncTaskException;
import com.questdiagnostics.campaignservice.async.task.TaskContext;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.manager.CampaignManager;
import com.questdiagnostics.campaignservice.manager.ContactListManager;
import com.questdiagnostics.campaignservice.manager.ContactSegmentManager;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJobBatch;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.EmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;

@Service
public class PatientDeduplicationService implements CampaignBatchService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private ContactListManager contactListManager;

	@Autowired
	private CampaignManager campaignManager;

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@Autowired
	private CampaignAsyncJobRepository campaignAsyncJobRepository;

	@Autowired
	private ContactSegmentManager contactSegmentManager;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Value("${batch.size.value}")
	private int batchSize;

	private static final String SELECT = "SELECT P.FirstName, P.LastName, P.EmailAddress, P.ContactId, P.ParticipantIdXRef";
	private static final String JOIN = "AS PS INNER JOIN DBO.Participant P ON P.ParticipantIdXRef = PS.ParticipantId";
	private static final String WHERE = "WHERE PS.SprinttCampaignId=? AND P.EmailAddress IS NOT NULL";
	private static final String ORDER = "ORDER BY P.ParticipantIdXRef ASC";
	private static final String OFFSET = "OFFSET";
	private static final String ROWS = "ROWS FETCH NEXT";
	private static final String ONLY = "ROWS ONLY";

	@Override
	public Long executeCampaignJobInBatches(TaskContext taskContext) {
		long jobId = taskContext.getJobId();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(taskContext.getCampaignId());
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = retrieveCampaignData(campaignDataOpt, scheduleRepository,
					emailTemplateRepository);

			CampaignAsyncJob jobLocal = jobId == -1
					? initializeNewJob(CONTACT_LIST_UPLOAD_INITIATED, batchSize, taskContext)
					: initializeFailedJob(campaignAsyncJobRepository, jobId, taskContext);
			updateRetryJob(jobLocal, taskContext);
			jobLocal = campaignAsyncJobRepository.save(jobLocal);
			taskContext.setJobId(jobLocal.getId());
			logger.info("Initiated {} process for campaign {} with job {}", taskContext.getTaskType().getType(),
					jobLocal.getCampaignId(), jobLocal.getId());
			try {
				campaignManager.updateDraftCampaignInEloqua(campaignData);
				jobLocal = uploadDeduplicatedPatientsForCampaign(jobLocal, campaignData, taskContext);
				switch (taskContext.getTaskType()) {
				case SCHEDULED:
					campaignManager.scheduleCampaign(campaignData, taskContext);
					break;
				case DEPLOYED:
					campaignManager.activateCampaign(campaignData, taskContext);
					break;
				default:
					break;
				}
				jobLocal.setJobStatus(CONTACT_LIST_UPLOAD_COMPLETED);
				logger.info("Completed {} process for campaign {} with job {}", taskContext.getTaskType().getType(),
						jobLocal.getCampaignId(), jobLocal.getId());
			} catch (Exception e) {
				jobLocal = retrieveCampaignAsyncJob(taskContext.getJobId(), campaignAsyncJobRepository);
				jobLocal.setRemarks(truncateFailureMessage(e.getMessage()));
				logger.error("{} campaign process failed for campaign {} for jobId {} due to: {}",
						taskContext.getTaskType().getType(), campaignData.getSprinttCampaignId(), jobLocal.getId(), e);

				if (taskContext.isPatientListEmpty()) {
					jobLocal.setJobStatus(CONTACT_LIST_EMPTY);
				} else if (taskContext.isScheduleLapsed()) {
					jobLocal.setJobStatus(SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED);
				} else {
					jobLocal.setJobStatus(CONTACT_LIST_UPLOAD_FAILED);
				}
			} finally {
				jobId = updateJobAndGenerateConsolidatedReport(jobLocal, campaignAsyncJobRepository, logger);
			}
		} else {
			logger.error("No campaign data. Terminating job and returning job.");
		}
		return jobId;
	}

	private CampaignAsyncJob uploadDeduplicatedPatientsForCampaign(CampaignAsyncJob job, CampaignMaster campaignData,
			TaskContext jobContext) throws ScheduleAsyncTaskException {
		logger.info("Initiated {} process for campaign {} in job {}", jobContext.getTaskType().getType(),
				job.getCampaignId(), job.getId());
		int offset = 0;
		if (jobContext.isFailedOnLastExecution()) {
			if (!CollectionUtils.isEmpty(job.getJobBatchList())) {
				return retryFailedBatchAndResumePendingBatches(job, campaignData, jobContext, offset);
			} else {
				/**
				 * Job failed at start without having any processing any batch so it is
				 * effectively a new job now.
				 */
				jobContext.setFailedOnLastExecution(false);
			}
		}
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		try {
			List<Object[]> deduplicablePatientBatch = getDeduplicablePatientBatch(job.getTrialId(), job.getCampaignId(),
					batchSize, offset, localEntityManager);
			while (!CollectionUtils.isEmpty(deduplicablePatientBatch)) {
				job = uploadDeduplicatedPatientBatch(job, deduplicablePatientBatch, campaignData, jobContext,
						localEntityManager);
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
				logger.info("Completed batch {} of job {} for {} campaign {}", job.getLatestBatchId(), job.getId(),
						jobContext.getTaskType().getType(), job.getCampaignId());
				offset = offset + batchSize;
				localEntityManager = entityManagerFactory.createEntityManager();
				deduplicablePatientBatch = getDeduplicablePatientBatch(job.getTrialId(), job.getCampaignId(), batchSize,
						offset, localEntityManager);
			}
		} finally {
			if (localEntityManager.isOpen()) {
				localEntityManager.close();
			}
		}
		logger.info("Completed upload of dedup patients of {} process for campaign {} in job {}",
				jobContext.getTaskType().getType(), job.getCampaignId(), job.getId());
		return job;
	}

	private CampaignAsyncJob retryFailedBatchAndResumePendingBatches(CampaignAsyncJob job, CampaignMaster campaignData,
			TaskContext taskContext, int offset) throws ScheduleAsyncTaskException {
		long lowerBound = 0l;
		for (CampaignAsyncJobBatch batch : job.getJobBatchList()) {
			switch (CampaignJobStatus.getStatusOf(batch.getBatchStatus())) {
			case DEDUPLICATION_INITIATED:
			case DEDUPLICATION_FAILED:
			case DEDUPLICATION_COMPLETED:
			case CONTACT_LIST_UPLOAD_INITIATED:
			case CONTACT_LIST_UPLOAD_FAILED:
				taskContext.setFailureType(CampaignJobStatus.getStatusOf(batch.getBatchStatus()));
				taskContext.setFailedBatchId(batch.getBatchId());
				lowerBound = Math.toIntExact((batch).getEndPos());
				job.setFailedBatch(batch);
				break;
			default:
				continue;
			}
		}
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		try {
			// process failed batch
			if (taskContext.getFailedBatchId() > 0) {
				CampaignAsyncJobBatch failedBatch = job.getFailedBatch();
				logger.info("Retrying failed batch {} of job {} for {} campaign {}", failedBatch.getBatchId(),
						job.getId(), taskContext.getTaskType().getType(), job.getCampaignId());
				updateRetryBatch(failedBatch, taskContext);
				List<Object[]> failedDeduplicablePatientBatch = getFailedDeduplicablePatientBatch(job.getTrialId(),
						job.getCampaignId(), failedBatch.getStartPos(), failedBatch.getEndPos(), localEntityManager);
				job = uploadDeduplicatedPatientBatch(job, failedDeduplicablePatientBatch, campaignData, taskContext,
						localEntityManager);
				logger.info("Completed failed batch {} of job {} for {} campaign {}",
						job.getBatch(taskContext.getFailedBatchId()).getBatchId(), job.getId(),
						taskContext.getTaskType().getType(), job.getCampaignId());
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
			} else {
				lowerBound = Math.toIntExact(job.getLatestBatch().getEndPos());
			}
			// update retry status of failed batch, if any
			taskContext.setFailedBatchRetryStatus(CONTACT_LIST_UPLOAD_COMPLETED);
			// process pending batches
			if (!localEntityManager.isOpen()) {
				localEntityManager = entityManagerFactory.createEntityManager();
			}
			List<Object[]> remainingDeduplicablePatientBatch = getDeduplicablePatientBatch(job.getTrialId(),
					job.getCampaignId(), batchSize, offset, lowerBound, localEntityManager);
			while (!CollectionUtils.isEmpty(remainingDeduplicablePatientBatch)) {
				job = uploadDeduplicatedPatientBatch(job, remainingDeduplicablePatientBatch, campaignData, taskContext,
						localEntityManager);
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
				logger.info("Completed pending batch {} of job {} for {} campaign {}", job.getLatestBatchId(),
						job.getId(), taskContext.getTaskType().getType(), job.getCampaignId());
				offset = offset + batchSize;
				localEntityManager = entityManagerFactory.createEntityManager();
				remainingDeduplicablePatientBatch = getDeduplicablePatientBatch(job.getTrialId(), job.getCampaignId(),
						batchSize, offset, lowerBound, localEntityManager);
			}
		} finally {
			if (localEntityManager.isOpen()) {
				localEntityManager.close();
			}
		}
		logger.info("Completed pending upload of dedup patients of {} process for campaign {} in job {}",
				taskContext.getTaskType().getType(), job.getCampaignId(), job.getId());
		return job;
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> getDeduplicablePatientBatch(long trialId, long campaignId, int limit, int offset,
			EntityManager localEntityManager) {
		Query query = localEntityManager.createNativeQuery(new StringBuilder(SELECT).append(WHITESPACE).append("FROM")
				.append(WHITESPACE).append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE).append(JOIN)
				.append(WHITESPACE).append(WHERE).append(WHITESPACE).append(ORDER).append(WHITESPACE).append(OFFSET)
				.append(WHITESPACE).append(offset).append(WHITESPACE).append(ROWS).append(WHITESPACE).append(limit)
				.append(WHITESPACE).append(ONLY).toString());
		query.setParameter(1, String.valueOf(campaignId));
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getFailedDeduplicablePatientBatch(long trialId, long campaignId, long lowerBound,
			long upperBound, EntityManager localEntityManager) {
		Query query = localEntityManager.createNativeQuery(new StringBuilder(SELECT).append(WHITESPACE).append("FROM")
				.append(WHITESPACE).append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE).append(JOIN)
				.append(WHITESPACE).append(WHERE).append(WHITESPACE)
				.append("AND P.ParticipantIdXRef >= ? AND P.ParticipantIdXRef <= ?").append(WHITESPACE).append(ORDER)
				.toString());
		query.setParameter(1, String.valueOf(campaignId));
		query.setParameter(2, lowerBound);
		query.setParameter(3, upperBound);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getDeduplicablePatientBatch(long trialId, long campaignId, int limit, int offset,
			long lowerBound, EntityManager localEntityManager) {
		Query query = localEntityManager.createNativeQuery(new StringBuilder(SELECT).append(WHITESPACE).append("FROM")
				.append(WHITESPACE).append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE).append(JOIN)
				.append(WHITESPACE).append(WHERE).append(WHITESPACE).append("AND P.ParticipantIdXRef > ?")
				.append(WHITESPACE).append(ORDER).append(WHITESPACE).append(OFFSET).append(WHITESPACE).append(offset)
				.append(WHITESPACE).append(ROWS).append(WHITESPACE).append(limit).append(WHITESPACE).append(ONLY)
				.toString());
		query.setParameter(1, String.valueOf(campaignId));
		query.setParameter(2, lowerBound);
		return query.getResultList();
	}

	private CampaignAsyncJob uploadDeduplicatedPatientBatch(CampaignAsyncJob job,
			List<Object[]> deduplicablePatientBatch, CampaignMaster campaignData, TaskContext taskContext,
			EntityManager localEntityManager) throws ScheduleAsyncTaskException {
		if (CollectionUtils.isEmpty(deduplicablePatientBatch)) {
			return job;
		}
		CampaignAsyncJobBatch batch = (taskContext.isFailedOnLastExecution()
				&& taskContext.getFailedBatchRetryStatus() == null) ? job.getFailedBatch()
						: prepareBatch(job, deduplicablePatientBatch, DEDUPLICATION_INITIATED.getValue(), 4);
		try {
			/**
			 * skip updating contacts if current batch had failed previously while uploading
			 * contacts. Possible states could be DEDUPLICATION_COMPLETED,
			 * CONTACT_LIST_UPLOAD_INITIATED, CONTACT_LIST_UPLOAD_FAILED
			 */
			if (!(taskContext.isFailedOnLastExecution()
					&& (taskContext.getFailureType() == CONTACT_LIST_UPLOAD_INITIATED
							|| taskContext.getFailureType() == CONTACT_LIST_UPLOAD_FAILED
							|| taskContext.getFailureType() == DEDUPLICATION_COMPLETED))) {
				updateContactIdForNewPatients(deduplicablePatientBatch, campaignData, localEntityManager);
				batch.setBatchStatus(DEDUPLICATION_COMPLETED.getValue());
			}

			/**
			 * save or update for 1. new job 2a. failed batch 2b. pending batches after the
			 * failed batch of 2a.
			 */
			if (taskContext.isFailedOnLastExecution()) {
				saveOrUpdateContactListBatchInEloqua(campaignData,
						taskContext.getFailedBatchRetryStatus() == CONTACT_LIST_UPLOAD_COMPLETED
								? getPendingContactIdBatch(campaignData.getTrialId(),
										campaignData.getSprinttCampaignId(), batchSize, 0,
										job.getLatestBatch().getEndPos(), localEntityManager)
								: getFailedContactIdBatch(campaignData.getTrialId(),
										campaignData.getSprinttCampaignId(), batch.getStartPos(), batch.getEndPos(),
										localEntityManager),
						batch, true, logger, contactSegmentManager, contactListManager);
			} else {
				saveOrUpdateContactListBatchInEloqua(campaignData,
						getContactIdBatch(campaignData.getTrialId(), campaignData.getSprinttCampaignId(),
								deduplicablePatientBatch, localEntityManager),
						batch, true, logger, contactSegmentManager, contactListManager);
			}
		} catch (PatientDeduplicationException ppe) {
			batch.setBatchStatus(DEDUPLICATION_FAILED);
			batch.setRemarks(truncateFailureMessage(ppe.getMessage()));
			throw new ScheduleAsyncTaskException(ppe);
		} catch (Exception e) {
			batch.setBatchStatus(CONTACT_LIST_UPLOAD_FAILED);
			batch.setRemarks(truncateFailureMessage(e.getMessage()));
			throw new ScheduleAsyncTaskException(e);
		} finally {
			job = updateJob(job, batch, deduplicablePatientBatch, taskContext, campaignAsyncJobRepository);
			localEntityManager.close();
		}
		return job;
	}

	private void updateContactIdForNewPatients(List<Object[]> partcipantData, CampaignMaster campaignData,
			EntityManager localEntityManager) throws PatientDeduplicationException {
		Query query = localEntityManager.createNativeQuery(new StringBuilder("UPDATE p1 SET p1.ContactId=? from")
				.append(WHITESPACE).append(CommonConstants.TRIAL_TABLE).append(campaignData.getTrialId())
				.append(WHITESPACE)
				.append("p1 WHERE p1.ParticipantId=? AND p1.SprinttCampaignId=? AND p1.ParticipantId not in")
				.append(WHITESPACE).append("(select p2.ParticipantId from").append(WHITESPACE)
				.append(CommonConstants.TRIAL_TABLE).append(campaignData.getTrialId()).append(WHITESPACE).append("p2")
				.append(WHITESPACE).append("where p2.ParticipantId=? and p2.ContactId is not null and ChannelId=1 )").toString());
		EntityTransaction transaction = null;
		for (Object[] participant : partcipantData) {
			try {
				transaction = localEntityManager.getTransaction();
				transaction.begin();
				Long participantId = Long.valueOf(String.valueOf(participant[4]));
				query.setParameter(1, (String) participant[3]);
				query.setParameter(2, participantId);
				query.setParameter(3, String.valueOf(campaignData.getSprinttCampaignId()));
				query.setParameter(4, participantId);
				query.executeUpdate();
				transaction.commit();
				logger.debug("Dedup applied for patient id {} and sprintt campaign id {} ", participantId,
						campaignData.getSprinttCampaignId());
			} catch (Exception e) {
				if (transaction != null)
					transaction.rollback();
				throw new PatientDeduplicationException(e);
			}
		}
	}
	// TODO - use distint for Contact IDs

	@SuppressWarnings("unchecked")
	private List<Object[]> getContactIdBatch(long trialId, long campaignId, List<Object[]> dedupBatch,
			EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT PS.ContactId, PS.ParticipantId FROM").append(WHITESPACE)
						.append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE)
						.append("AS PS where PS.SprinttCampaignId=? AND PS.ContactId IS NOT NULL AND ChannelId=1 ").append(WHITESPACE)
						.append("AND PS.ParticipantId >= ? AND PS.ParticipantId <= ?").toString());

		query.setParameter(1, String.valueOf(campaignId));
		query.setParameter(2, Long.valueOf(String.valueOf(dedupBatch.get(0)[4])));
		query.setParameter(3, Long.valueOf(String.valueOf(dedupBatch.get(dedupBatch.size() - 1)[4])));
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getPendingContactIdBatch(long trialId, long campaignId, int limit, int offset,
			long lowerBound, EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT PS.ContactId, PS.ParticipantId FROM").append(WHITESPACE)
						.append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE)
						.append("AS PS where PS.SprinttCampaignId=? AND PS.ContactId IS NOT NULL AND ChannelId=1 ").append(WHITESPACE)
						.append("AND PS.ParticipantId > ?").append(WHITESPACE).append("ORDER BY PS.ParticipantId")
						.append(WHITESPACE).append(OFFSET).append(WHITESPACE).append(offset).append(WHITESPACE)
						.append(ROWS).append(WHITESPACE).append(limit).append(WHITESPACE).append(ONLY).toString());

		query.setParameter(1, String.valueOf(campaignId));
		query.setParameter(2, lowerBound);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getFailedContactIdBatch(long trialId, long campaignId, long lowerBound, long upperBound,
			EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT PS.ContactId, PS.ParticipantId FROM").append(WHITESPACE)
						.append(CommonConstants.TRIAL_TABLE).append(trialId).append(WHITESPACE)
						.append("AS PS where PS.SprinttCampaignId=? AND PS.ContactId IS NOT NULL AND ChannelId=1 ").append(WHITESPACE)
						.append("AND PS.ParticipantId >= ? AND PS.ParticipantId <= ?").append(WHITESPACE)
						.append("ORDER BY PS.ParticipantId").toString());
		query.setParameter(1, String.valueOf(campaignId));
		query.setParameter(2, lowerBound);
		query.setParameter(3, upperBound);
		return query.getResultList();
	}

}