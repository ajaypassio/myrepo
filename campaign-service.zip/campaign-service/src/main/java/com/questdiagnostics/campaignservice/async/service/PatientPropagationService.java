package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.WHITESPACE;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.DISCARD_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.PATIENT_PROPAGATION_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.PATIENT_PROPAGATION_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.PATIENT_PROPAGATION_INITATED;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.SCHEDULED;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.questdiagnostics.campaignservice.async.exception.DiscardAsyncTaskException;
import com.questdiagnostics.campaignservice.async.exception.PatientPropagationException;
import com.questdiagnostics.campaignservice.async.task.TaskContext;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.manager.ContactListManager;
import com.questdiagnostics.campaignservice.manager.ContactSegmentManager;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJobBatch;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.EmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;

@Service
public class PatientPropagationService implements CampaignBatchService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private ContactListManager contactListManager;

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@Autowired
	private CampaignAsyncJobRepository campaignAsyncJobRepository;

	@Autowired
	private ContactSegmentManager contactSegmentManager;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Value("${batch.size.value}")
	private int batchSize;

	private static final String ORDER_BY = "ORDER BY c1.ParticipantStudySiteId";
	private static final String JOIN_ON = "ON c1.ParticipantId = c2.ParticipantId";
	private static final String FROM_TABLE = "FROM ParticipantStudySite_T_";
	private static final String INNER_JOIN = "c1 INNER JOIN ParticipantStudySite_T_";
	private static final String OFFSET = "OFFSET";
	private static final String FETCH = "ROWS FETCH NEXT";
	private static final String ROWS = "ROWS ONLY";

	/**
	 * 1c. For each trial find the earliest created campaign (and has a discard
	 * request initiated by above parameters), fetch the patients with non-null
	 * contact IDs from the corresponding trial table to create the patient
	 * propagation list.
	 * 
	 * 2. Find the list for scheduled (process completed) campaigns.
	 * 
	 * 3. For each scheduled campaign, patients' without contact IDs need to be
	 * compared to the above campaign's patients. If a null exists in contact ID
	 * column for the scheduled campaign, propagate the contact ID to this
	 * participant and update contact list in Eloqua for this campaign, updating the
	 * contact ID to null in the original campaign.
	 * 
	 * 4. If discarded campaign's contact IDs aren't exhausted while the scheduled
	 * campaign is exhausted, repeat step 3 for the next scheduled campaign (if it
	 * exists). If no more scheduled campaigns exists, patient propagation for the
	 * discarded campaign is complete.
	 * 
	 * 5. Execute steps 1-4 for one and exactly one discard (initiated) campaign in
	 * thread/trial model (one thread per trial table). Each thread should perform
	 * the steps with a pre-determined (configured) batch of patients. After each
	 * batch is completed, the job table needs to be be updated.
	 * 
	 * 
	 * Performs the following steps: 1. Update Job table entry for various fields 2.
	 * Create the batch table entry 3. Consume the patient batch for target
	 * campaign(s). 4a. If the patient batch is consumed for one campaign, change
	 * the batch status and start the contact-list upload step. 4b. Update the batch
	 * table for contact-list batch step for the target campaign. 5a. If patient
	 * batch is not consumed for one campaign, persist the current batch. 5b. Create
	 * a new batch for the next target campaign (if patient batch has some common
	 * entries for the new target campaign). 6. Repeat Steps 4/5 until either one of
	 * the two is exhausted - patient batch and target campaigns.
	 * 
	 * @throws Exception
	 */
	@Override
	public Long executeCampaignJobInBatches(TaskContext taskContext) {
		long jobId = taskContext.getJobId();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(taskContext.getCampaignId());
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = retrieveCampaignData(campaignDataOpt, scheduleRepository,
					emailTemplateRepository);

			CampaignAsyncJob jobLocal = jobId == -1 ? initializeNewJob(DISCARD_INITIATED, batchSize, taskContext)
					: initializeFailedJob(campaignAsyncJobRepository, jobId, taskContext);
			updateRetryJob(jobLocal, taskContext);
			jobLocal = campaignAsyncJobRepository.save(jobLocal);
			taskContext.setJobId(jobLocal.getId());
			logger.info("Initiated discard process for campaign {} with job {}", jobLocal.getCampaignId(),
					jobLocal.getId());

			List<CampaignMaster> scheduledCampaignsForTrial = campaignMasterRepository
					.findCampaignByTrialAndCampaignStatusAndCampaignJobStatus(jobLocal.getTrialId(),
							SCHEDULED.getValue(), CONTACT_LIST_UPLOAD_COMPLETED.getValue());
			try {
				if (!CollectionUtils.isEmpty(scheduledCampaignsForTrial)) {
					jobLocal = processScheduledCampaignsForPatientPropagation(jobLocal, taskContext, campaignData,
							scheduledCampaignsForTrial);
				} else {
					logger.info("No other scheduled campaigns exist. Discard process for campaign {} initiated.",
							campaignData.getSprinttCampaignId());
				}
				/**
				 * discard all the remaining patients of the campaign which could not be
				 * propagated.
				 */
				jobLocal = discardPatientsForCampaign(jobLocal, campaignData, taskContext);
				jobLocal.setJobStatus(DISCARD_COMPLETED);
				logger.info("Completed discard process for campaign {} with job {}", jobLocal.getCampaignId(),
						jobLocal.getId());
			} catch (Exception e) {
				jobLocal = retrieveCampaignAsyncJob(taskContext.getJobId(), campaignAsyncJobRepository);
				jobLocal.setJobStatus(DISCARD_FAILED);
				jobLocal.setRemarks(truncateFailureMessage(e.getMessage()));
				logger.error("Discard campaign process failed for campaign {} for jobId {} due to: {}",
						jobLocal.getCampaignId(), jobLocal.getId(), e);
			} finally {
				jobId = updateJobAndGenerateConsolidatedReport(jobLocal, campaignAsyncJobRepository, logger);
			}
		} else {
			logger.error("No campaign data. Terminating job and returning job.");
		}
		return jobId;
	}

	private CampaignAsyncJob processScheduledCampaignsForPatientPropagation(CampaignAsyncJob job,
			TaskContext taskContext, CampaignMaster campaignData, List<CampaignMaster> scheduledCampaignsForTrial)
			throws DiscardAsyncTaskException {
		for (CampaignMaster targetCampaign : scheduledCampaignsForTrial) {
			// retry failed batch first and toggle retry flag if completed.
			if (!isTargetCampaignWithinCutoffPeriod(targetCampaign, scheduleRepository)) {
				if (taskContext.isFailedOnLastExecution() && !StringUtils.isEmpty(job.getRemarks2())
						&& Long.valueOf(job.getRemarks2()).equals(targetCampaign.getSprinttCampaignId())) {
					job = propagatePatientsToCampaign(targetCampaign, job, campaignData, taskContext);
					taskContext.setFailedOnLastExecution(false);
					continue;
				}
				job = propagatePatientsToCampaign(targetCampaign, job, campaignData, taskContext);
			} else {
				logger.info(
						"Skipping campaign {} for patient propagation from discarded campaign {} as its schedule is within cut-off period of 2 hour.",
						targetCampaign.getSprinttCampaignId(), campaignData.getSprinttCampaignId());
			}
		}
		return job;
	}

	private boolean isTargetCampaignWithinCutoffPeriod(CampaignMaster campaign, ScheduleRepository scheduleRepository) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.HOUR_OF_DAY, 2);
		Date cutOffTime = cal.getTime();
		campaign.setSchedule(scheduleRepository.findById(campaign.getScheduleId()).orElse(null));
		return campaign.getSchedule().getNormalizedStartDateTime().before(cutOffTime);
	}

	private CampaignAsyncJob propagatePatientsToCampaign(CampaignMaster targetCampaign, CampaignAsyncJob job,
			CampaignMaster sourceCampaign, TaskContext taskContext) throws DiscardAsyncTaskException {
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		try {
			if (taskContext.isFailedOnLastExecution()) {
				if (!CollectionUtils.isEmpty(job.getJobBatchList())) {
					for (CampaignAsyncJobBatch batch : job.getJobBatchList()) {
						switch (CampaignJobStatus.getStatusOf(batch.getBatchStatus())) {
						case PATIENT_PROPAGATION_INITATED:
						case PATIENT_PROPAGATION_FAILED:
						case PATIENT_PROPAGATION_COMPLETED:
						case CONTACT_LIST_UPLOAD_INITIATED:
						case CONTACT_LIST_UPLOAD_FAILED:
							taskContext.setFailureType(CampaignJobStatus.getStatusOf(batch.getBatchStatus()));
							taskContext.setFailedBatchId(batch.getBatchId());
							job.setFailedBatch(batch);
							break;
						default:
							continue;
						}
					}
					if (taskContext.getFailedBatchId() > 0) {
						CampaignAsyncJobBatch failedBatch = job.getFailedBatch();
						logger.info(
								"Retrying propagate process for failed batch {} from campaign {} to campaign {} for job {}",
								failedBatch.getBatchId(), job.getCampaignId(), targetCampaign.getSprinttCampaignId(),
								job.getId());
						updateRetryBatch(failedBatch, taskContext);
						List<Object[]> failedPropagatedPatientBatch = getPropagatedPatientBatch(job.getCampaignId(),
								targetCampaign.getSprinttCampaignId(), job.getTrialId(),
								new Bound().bounds(failedBatch, 0, 1), new Bound().bounds(failedBatch, 2, 3),
								localEntityManager);
						job = propagateOrDiscardPatientBatch(targetCampaign, job, failedPropagatedPatientBatch,
								sourceCampaign, taskContext, localEntityManager);
						if (localEntityManager.isOpen()) {
							localEntityManager.close();
						}
						logger.info(
								"Completed propagate process for failed batch {} from campaign {} to campaign {}  for job {}",
								failedBatch.getBatchId(), job.getCampaignId(), targetCampaign.getSprinttCampaignId(),
								job.getId());
					}
					taskContext.setFailedBatchRetryStatus(CONTACT_LIST_UPLOAD_COMPLETED);
				} else {
					/**
					 * Job failed at start without having any processing any batch so it is
					 * effectively a new job now relative to the target campaign.
					 */
					taskContext.setFailedOnLastExecution(false);
				}
			}
			logger.info("Initiated patient propagation from campaign {} to campaign {} for job {}", job.getCampaignId(),
					targetCampaign.getSprinttCampaignId(), job.getId());
			if (!localEntityManager.isOpen()) {
				localEntityManager = entityManagerFactory.createEntityManager();
			}
			List<Object[]> propagatablePatientBatch = getPropagatablePatientBatch(job.getCampaignId(),
					targetCampaign.getSprinttCampaignId(), batchSize, 0, job.getTrialId(), localEntityManager);

			while (!CollectionUtils.isEmpty(propagatablePatientBatch)) {
				job = propagateOrDiscardPatientBatch(targetCampaign, job, propagatablePatientBatch, sourceCampaign,
						taskContext, localEntityManager);
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
				logger.info("Propagated patient batch {} of job {} from campaign {} to campaign {}",
						job.getLatestBatchId(), job.getId(), job.getCampaignId(),
						targetCampaign.getSprinttCampaignId());
				localEntityManager = entityManagerFactory.createEntityManager();
				propagatablePatientBatch = getPropagatablePatientBatch(job.getCampaignId(),
						targetCampaign.getSprinttCampaignId(), batchSize, 0, job.getTrialId(), localEntityManager);
			}
			logger.info("Completed patient propagation from campaign {} to campaign {} for job {}", job.getCampaignId(),
					targetCampaign.getSprinttCampaignId(), job.getId());
		} finally {
			if (localEntityManager.isOpen()) {
				localEntityManager.close();
			}
		}
		return job;
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getPropagatablePatientBatch(long sourceCampaignId, long targetCampaignId, int fetch,
			int offset, long trialId, EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT c1.ContactId, c1.ParticipantStudySiteId as c1_pk,")
						.append("c2.ParticipantStudySiteId AS c2_pk").append(WHITESPACE).append(FROM_TABLE)
						.append(trialId).append(WHITESPACE).append(INNER_JOIN).append(trialId).append(WHITESPACE)
						.append("c2").append(WHITESPACE).append(JOIN_ON).append(WHITESPACE)
						.append("WHERE c1.SprinttCampaignId = ? AND c2.SprinttCampaignId = ?").append(WHITESPACE)
						.append("AND c1.ContactId IS NOT NULL AND c2.ContactId IS NULL").append(WHITESPACE)
						.append(ORDER_BY).append(WHITESPACE).append(OFFSET).append(WHITESPACE).append(offset)
						.append(WHITESPACE).append(FETCH).append(WHITESPACE).append(fetch).append(WHITESPACE)
						.append(ROWS).toString());
		query.setParameter(1, String.valueOf(sourceCampaignId));
		query.setParameter(2, String.valueOf(targetCampaignId));
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> getPropagatedPatientBatch(long sourceCampaignId, long targetCampaignId, long trialId,
			Bound sourceBounds, Bound targetBounds, EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT c1.ContactId, c1.ParticipantStudySiteId as c1_pk,")
						.append("c2.ParticipantStudySiteId AS c2_pk").append(WHITESPACE).append(FROM_TABLE)
						.append(trialId).append(WHITESPACE).append(INNER_JOIN).append(trialId).append(WHITESPACE)
						.append("c2").append(WHITESPACE).append(JOIN_ON).append(WHITESPACE)
						.append("WHERE c1.SprinttCampaignId = ? AND c2.SprinttCampaignId = ?").append(WHITESPACE)
						.append("AND c2.ContactId IS NOT NULL AND c1.ContactId IS NULL").append(WHITESPACE)
						.append("AND c1_pk >= ? AND c1_pk <= ? AND c2_pk >= ? AND c2_pk <= ?").append(ORDER_BY)
						.toString());
		query.setParameter(1, String.valueOf(sourceCampaignId));
		query.setParameter(2, String.valueOf(targetCampaignId));
		query.setParameter(3, sourceBounds.getLowerBound());
		query.setParameter(4, sourceBounds.getUpperBound());
		query.setParameter(5, targetBounds.getLowerBound());
		query.setParameter(6, targetBounds.getUpperBound());
		return query.getResultList();
	}

	private CampaignAsyncJob propagateOrDiscardPatientBatch(CampaignMaster targetCampaign, CampaignAsyncJob job,
			List<Object[]> patientBatch, CampaignMaster sourceCampaign, TaskContext taskContext,
			EntityManager localEntityManager) throws DiscardAsyncTaskException {
		if (CollectionUtils.isEmpty(patientBatch)) {
			// target campaign exhausted
			return job;
		}
		CampaignAsyncJobBatch batch = (taskContext.isFailedOnLastExecution()
				&& taskContext.getFailedBatchRetryStatus() == null) ? job.getFailedBatch()
						: prepareBatch(job, patientBatch, PATIENT_PROPAGATION_INITATED.getValue(), 1);
		try {
			propagateOrDiscardPatients(targetCampaign, job, patientBatch, sourceCampaign, taskContext, batch,
					localEntityManager);
			if (targetCampaign != null) {
				saveOrUpdateContactListBatchInEloqua(targetCampaign, patientBatch, batch, true, logger,
						contactSegmentManager, contactListManager);
			}
			saveOrUpdateContactListBatchInEloqua(sourceCampaign, patientBatch, batch, false, logger,
					contactSegmentManager, contactListManager);
		} catch (PatientPropagationException ppe) {
			batch.setBatchStatus(PATIENT_PROPAGATION_FAILED);
			batch.setRemarks(truncateFailureMessage(ppe.getMessage()));
			if (targetCampaign != null) {
				Bound.setBatchForPropagationBounds(batch, patientBatch);
				job.setRemarks2(Bound.concatenateData(targetCampaign.getSprinttCampaignId()));
			}
			throw new DiscardAsyncTaskException(ppe);
		} catch (Exception e) {
			batch.setBatchStatus(CONTACT_LIST_UPLOAD_FAILED);
			batch.setRemarks(truncateFailureMessage(e.getMessage()));
			if (targetCampaign != null) {
				Bound.setBatchForPropagationBounds(batch, patientBatch);
				job.setRemarks2(Bound.concatenateData(targetCampaign.getSprinttCampaignId()));
			}
			throw new DiscardAsyncTaskException(e);
		} finally {
			job = updateJob(job, batch, patientBatch, taskContext, campaignAsyncJobRepository);
		}
		return job;
	}

	private void propagateOrDiscardPatients(CampaignMaster targetCampaign, CampaignAsyncJob job,
			List<Object[]> patientBatch, CampaignMaster sourceCampaign, TaskContext taskContext,
			CampaignAsyncJobBatch batch, EntityManager localEntityManager) throws PatientPropagationException {
		if (!(taskContext.isFailedOnLastExecution() && (taskContext.getFailureType() == PATIENT_PROPAGATION_COMPLETED
				|| taskContext.getFailureType() == CONTACT_LIST_UPLOAD_INITIATED
				|| taskContext.getFailureType() == CONTACT_LIST_UPLOAD_FAILED))) {
			if (targetCampaign != null) {
				propagatePatientsInDB(patientBatch, sourceCampaign.getSprinttCampaignId(),
						targetCampaign.getSprinttCampaignId(), job.getId(), job.getTrialId(), localEntityManager);
			} else {
				discardPatientsInDB(patientBatch, job.getCampaignId(), job.getId(), job.getTrialId(),
						localEntityManager);
			}
			batch.setBatchStatus(PATIENT_PROPAGATION_COMPLETED.getValue());
		}
	}

	private void propagatePatientsInDB(List<Object[]> propagatablePatients, long sourceCampaignId,
			long targetCampaignId, long jobId, long trialId, EntityManager localEntityManager)
			throws PatientPropagationException {
		List<Long> sourcePKs = new ArrayList<>();
		List<Long> targetPKs = new ArrayList<>();
		propagatablePatients.forEach(entry -> {
			sourcePKs.add(Long.valueOf(String.valueOf(entry[1])));
			targetPKs.add(Long.valueOf(String.valueOf(entry[2])));
		});
		// update target campaign participants
		Query targetUpdateQuery = localEntityManager
				.createNativeQuery(new StringBuilder("UPDATE c2 SET c2.ContactId = c1.ContactId").append(WHITESPACE)
						.append(FROM_TABLE).append(trialId).append(WHITESPACE).append(INNER_JOIN).append(trialId)
						.append(WHITESPACE).append("c2").append(WHITESPACE).append(JOIN_ON).append(WHITESPACE)
						.append("WHERE c1.SprinttCampaignId = :sourceCampaignId AND").append(WHITESPACE)
						.append("c2.ParticipantStudySiteId IN (:targetPKs)").toString());
		targetUpdateQuery.setParameter("sourceCampaignId", String.valueOf(sourceCampaignId));
		targetUpdateQuery.setParameter("targetPKs", targetPKs);
		// update source campaign participants
		Query sourceUpdateQuery = localEntityManager
				.createNativeQuery(new StringBuilder("UPDATE c1 SET c1.ContactId = null").append(WHITESPACE)
						.append(FROM_TABLE).append(trialId).append(WHITESPACE).append("c1").append(WHITESPACE)
						.append("WHERE c1.ParticipantStudySiteId IN (:sourcePKs)").toString());
		sourceUpdateQuery.setParameter("sourcePKs", sourcePKs);

		EntityTransaction transaction = localEntityManager.getTransaction();
		try {
			transaction.begin();
			int targetRowsUpdated = targetUpdateQuery.executeUpdate();
			int sourceRowsUpdated = sourceUpdateQuery.executeUpdate();
			transaction.commit();
			logger.info(
					"targetRowsUpdated = {}, sourceRowsUpdated = {} for jobId {} from source campaign {} to target campaign {}",
					targetRowsUpdated, sourceRowsUpdated, jobId, sourceCampaignId, targetCampaignId);
		} catch (Exception e) {
			transaction.rollback();
			throw new PatientPropagationException(e);
		}
	}

	private CampaignAsyncJob discardPatientsForCampaign(CampaignAsyncJob job, CampaignMaster sourceCampaign,
			TaskContext taskContext) throws DiscardAsyncTaskException {
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		try {
			if (taskContext.isFailedOnLastExecution()) {
				if (!CollectionUtils.isEmpty(job.getJobBatchList())) {
					for (CampaignAsyncJobBatch batch : job.getJobBatchList()) {
						switch (CampaignJobStatus.getStatusOf(batch.getBatchStatus())) {
						case PATIENT_PROPAGATION_INITATED:
						case PATIENT_PROPAGATION_FAILED:
						case PATIENT_PROPAGATION_COMPLETED:
						case CONTACT_LIST_UPLOAD_INITIATED:
						case CONTACT_LIST_UPLOAD_FAILED:
							taskContext.setFailureType(CampaignJobStatus.getStatusOf(batch.getBatchStatus()));
							taskContext.setFailedBatchId(batch.getBatchId());
							job.setFailedBatch(batch);
							break;
						default:
							continue;
						}
					}
					if (taskContext.getFailedBatchId() > 0) {
						CampaignAsyncJobBatch failedBatch = job.getFailedBatch();
						logger.info("Retrying discard process for failed batch {} for campaign {} for job {}",
								failedBatch.getBatchId(), job.getCampaignId(), job.getId());
						updateRetryBatch(failedBatch, taskContext);
						List<Object[]> failedDiscardablePatientBatch = getDiscardablePatientBatch(job.getCampaignId(),
								job.getTrialId(), failedBatch.getStartPos(), failedBatch.getEndPos(),
								localEntityManager);
						job = propagateOrDiscardPatientBatch(null, job, failedDiscardablePatientBatch, sourceCampaign,
								taskContext, localEntityManager);
						if (localEntityManager.isOpen()) {
							localEntityManager.close();
						}
						logger.info("Completed discard process for failed batch {} for campaign {} for job {}",
								failedBatch.getBatchId(), job.getCampaignId(), job.getId());
					}
					taskContext.setFailedBatchRetryStatus(CONTACT_LIST_UPLOAD_COMPLETED);
				} else {
					/**
					 * Job failed at start without having any processing any batch so it is
					 * effectively a new job now.
					 */
					taskContext.setFailedOnLastExecution(false);
				}
			}
			logger.info("Initiated discard process for campaign {} for job {}", job.getCampaignId(), job.getId());
			if (!localEntityManager.isOpen()) {
				localEntityManager = entityManagerFactory.createEntityManager();
			}
			List<Object[]> discardablePatientBatch = getDiscardablePatientBatch(job.getCampaignId(), batchSize, 0,
					job.getTrialId(), localEntityManager);
			while (!CollectionUtils.isEmpty(discardablePatientBatch)) {
				job = propagateOrDiscardPatientBatch(null, job, discardablePatientBatch, sourceCampaign, taskContext,
						localEntityManager);
				if (localEntityManager.isOpen()) {
					localEntityManager.close();
				}
				localEntityManager = entityManagerFactory.createEntityManager();
				discardablePatientBatch = getDiscardablePatientBatch(job.getCampaignId(), batchSize, 0,
						job.getTrialId(), localEntityManager);
			}
		} finally {
			if (localEntityManager.isOpen()) {
				localEntityManager.close();
			}
		}
		logger.info("Completed discard process for campaign {} for job {}", job.getCampaignId(), job.getId());
		return job;
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getDiscardablePatientBatch(long campaignId, int fetch, int offset, long trialId,
			EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT c1.ContactId, c1.ParticipantStudySiteId as c1_pk")
						.append(WHITESPACE).append(FROM_TABLE).append(trialId).append(WHITESPACE).append("c1")
						.append(WHITESPACE).append("WHERE c1.SprinttCampaignId = ?").append(WHITESPACE)
						.append("AND c1.ContactId IS NOT NULL").append(WHITESPACE).append(ORDER_BY).append(WHITESPACE)
						.append(OFFSET).append(WHITESPACE).append(offset).append(WHITESPACE).append(FETCH)
						.append(WHITESPACE).append(fetch).append(WHITESPACE).append(ROWS).toString());
		query.setParameter(1, String.valueOf(campaignId));
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	private List<Object[]> getDiscardablePatientBatch(long campaignId, long trialId, long lowerBound, long upperBound,
			EntityManager localEntityManager) {
		Query query = localEntityManager
				.createNativeQuery(new StringBuilder("SELECT c1.ContactId, c1.ParticipantStudySiteId as c1_pk")
						.append(WHITESPACE).append(FROM_TABLE).append(trialId).append(WHITESPACE).append("c1")
						.append(WHITESPACE).append("WHERE c1.SprinttCampaignId = ?").append(WHITESPACE)
						.append("AND c1.ContactId IS NOT NULL AND c1_pk >= ? AND c1_pk <= ?").append(WHITESPACE)
						.append(ORDER_BY).toString());
		query.setParameter(1, String.valueOf(campaignId));
		query.setParameter(2, lowerBound);
		query.setParameter(3, upperBound);
		return query.getResultList();
	}

	private void discardPatientsInDB(List<Object[]> discardablePatients, long campaignId, long jobId, long trialId,
			EntityManager localEntityManager) throws PatientPropagationException {
		List<Long> sourcePKs = new ArrayList<>();
		discardablePatients.forEach(entry -> sourcePKs.add(Long.valueOf(String.valueOf(entry[1]))));

		// update source campaign participants
		Query sourceUpdateQuery = localEntityManager
				.createNativeQuery(new StringBuilder("UPDATE c1 SET c1.ContactId = null").append(WHITESPACE)
						.append(FROM_TABLE).append(trialId).append(WHITESPACE).append("c1").append(WHITESPACE)
						.append("WHERE c1.ParticipantStudySiteId IN (:sourcePKs)").toString());
		sourceUpdateQuery.setParameter("sourcePKs", sourcePKs);

		EntityTransaction transaction = localEntityManager.getTransaction();
		try {
			transaction.begin();
			int sourceRowsUpdated = sourceUpdateQuery.executeUpdate();
			transaction.commit();
			logger.info("sourceRowsUpdated = {} for jobId {} for campaign {} for discard job", sourceRowsUpdated, jobId,
					campaignId);
		} catch (Exception e) {
			transaction.rollback();
			throw new PatientPropagationException(e);
		}
	}
}
