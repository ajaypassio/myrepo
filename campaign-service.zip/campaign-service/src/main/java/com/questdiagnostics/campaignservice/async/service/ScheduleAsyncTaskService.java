package com.questdiagnostics.campaignservice.async.service;

import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_EMPTY;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_FAILED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_INITIATED;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.CONTACT_LIST_UPLOAD_IN_PROGRESS;
import static com.questdiagnostics.campaignservice.enums.CampaignJobStatus.SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.SCHEDULED;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.task.CampaignAsyncTask;
import com.questdiagnostics.campaignservice.async.task.ScheduleAsyncTask;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.CampaignAsyncJobRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.util.CommonUtil;
import com.questdiagnostics.campaignservice.workflowengine.CampaignStateTransitionManager;

@Service
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class ScheduleAsyncTaskService extends AsbtractCampaignAsyncTaskService {

	@Autowired
	private TrialExecutorService campaignExecutorService;

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@Autowired
	private CampaignAsyncJobRepository campaignAsyncJobRepository;

	@Autowired
	private ObjectFactory<ScheduleAsyncTask> prototypeScheduleTaskFactory;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private CampaignStateTransitionManager campaignStateTransitionManager;

	@Autowired
	private AsyncJobModReplicaService asyncJobModReplicaService;

	@Scheduled(initialDelay = 30000l, fixedRateString = "${scheduler.cron.job.fixedrate.schedule}")
	@Override
	public void executeTask() {
		logger.debug("Schedule async task started.");
		Optional<List<CampaignMaster>> scheduledCampaignsOpt = asyncJobModReplicaService.isModReplicationEnabled()
				? campaignMasterRepository.fetchScheduledCampaignsByMod(SCHEDULED.getValue(),
						Arrays.asList(CONTACTS_UPLOAD_COMPLETED.getValue(), CONTACT_LIST_UPLOAD_FAILED.getValue(),
								CONTACT_LIST_UPLOAD_IN_PROGRESS.getValue()),
						asyncJobModReplicaService.getModProperty(), asyncJobModReplicaService.getModAcquired())
				: campaignMasterRepository.fetchScheduledCampaigns(SCHEDULED.getValue(),
						Arrays.asList(CONTACTS_UPLOAD_COMPLETED.getValue(), CONTACT_LIST_UPLOAD_FAILED.getValue(),
								CONTACT_LIST_UPLOAD_IN_PROGRESS.getValue()));
		if (scheduledCampaignsOpt.isPresent()) {
			Map<Long, List<CampaignMaster>> scheduledTrialMap = filterTrialsInExecution(scheduledCampaignsOpt.get(),
					campaignMasterRepository, campaignExecutorService);
			if (!CollectionUtils.isEmpty(scheduledTrialMap)) {
				processTrialMap(scheduledTrialMap, scheduleRepository, SCHEDULED, campaignMasterRepository,
						campaignExecutorService, false, campaignAsyncJobRepository);
			} else {
				logger.info(
						"All schedule campaign requests are in progress. No pending request found for any scheduled campaign.");
			}
		} else {
			logger.info("No schedule campaigns requests were found.");
		}
		logger.debug("Schedule async task ended.");
	}

	@Override
	public CampaignAsyncTask prepareTask(CampaignMaster campaignData, long trialId, SprinttCampaignStatus taskType) {
		ScheduleAsyncTask task = getScheduledTaskInstance();
		List<CampaignAsyncJob> jobs = campaignAsyncJobRepository.findPendingOrFailedJobsForTrialAndCampaign(trialId,
				campaignData.getSprinttCampaignId(),
				Arrays.asList(CONTACT_LIST_UPLOAD_INITIATED.getValue(), CONTACT_LIST_UPLOAD_FAILED.getValue()));

		return super.prepareTask(campaignData, trialId, taskType, task, jobs,
				CONTACT_LIST_UPLOAD_IN_PROGRESS.getValue());
	}

	@Override
	public void logResultAndUpdateCampaignJobStatus(Future<Long> future, long campaignId,
			SprinttCampaignStatus taskType) throws InterruptedException, ExecutionException {
		campaignAsyncJobRepository.findById(future.get()).ifPresent(job -> {
			campaignMasterRepository.findById(campaignId).ifPresent(campaign -> {
				switch (CampaignJobStatus.getStatusOf(job.getJobStatus())) {
				case CONTACT_LIST_UPLOAD_COMPLETED:
					campaign.setEloCampgnStatusId(SCHEDULED.getValue());
					campaign.setCampaignJobStatusId(CONTACT_LIST_UPLOAD_COMPLETED.getValue());
					break;
				case CONTACT_LIST_EMPTY:
					campaign.setCampaignJobStatusId(CONTACT_LIST_EMPTY.getValue());
					// move campaign to discard state
					moveCampaignToDiscarded(campaign, campaignStateTransitionManager);
					break;
				case SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED:
					campaign.setCampaignJobStatusId(SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED.getValue());
					break;
				case CONTACT_LIST_UPLOAD_FAILED:
				case CONTACT_LIST_UPLOAD_INITIATED:
				default:
					campaign.setCampaignJobStatusId(CONTACT_LIST_UPLOAD_FAILED.getValue());
					break;
				}

				// added remarks
				campaign.setRemarks(CommonUtil.populateCampaignRemarks(campaign.getRemarks(),
						CommonConstants.DEDUPLICATION_AND_CONTACT_ENDED));

				campaign.setUpdatedOn(new Date());
				campaignMasterRepository.save(campaign);
			});
			logger.info("job {} completed with status {} for campaign {} and trial {} for {} process.", job.getId(),
					CampaignJobStatus.getStatusOf(job.getJobStatus()).getType(), job.getCampaignId(), job.getTrialId(),
					taskType.name());
		});
	}

	@Override
	public void updateCampaignJobStatus(int newCampaignJobStatus, long campaignId) {
		super.updateCampaignJobStatus(newCampaignJobStatus, campaignId, campaignMasterRepository);
	}

	public ScheduleAsyncTask getScheduledTaskInstance() {
		return prototypeScheduleTaskFactory.getObject();
	}

}
