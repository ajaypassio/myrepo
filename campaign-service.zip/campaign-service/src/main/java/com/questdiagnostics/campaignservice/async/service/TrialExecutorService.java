package com.questdiagnostics.campaignservice.async.service;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public final class TrialExecutorService {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	private static final int PERMITS = 2;
	private static final int THREADS_PER_CORE = 3;
	/**
	 * Can have up-to 3 keys, based on the executor pool thread size. Removing
	 * values is to be done by the submitted tasks.
	 */
	private final Set<Long> currenTrialsInExecution = new HashSet<>();

	private final Lock lock = new ReentrantLock();

	private final Semaphore coresAvailable = new Semaphore(PERMITS);

	// 10 extra threads for contact upload
	private final ExecutorService campaignExecutorPool = Executors.newFixedThreadPool(PERMITS * THREADS_PER_CORE + 10);

	private boolean verifyTrialExecutionAndAcquireCoreLock(long trialId) {
		return !isTrialInExecution(trialId) && coresAvailable.tryAcquire();
	}

	private void putTrialInExecution(long trialId) {
		currenTrialsInExecution.add(trialId);
	}

	public boolean isTrialInExecution(long trialId) {
		return currenTrialsInExecution.contains(trialId);
	}

	public boolean removeTrialFromExecution(long trialId) {
		boolean lockAquired = false;
		try {
			lock.lock();
			lockAquired = true;
			coresAvailable.release();
			currenTrialsInExecution.remove(trialId);
			return true;
		} catch (Exception e) {
			logger.error("Caught exception while trying to remove trial {} from execution: {}", trialId, e);
			return false;
		} finally {
			if (lockAquired)
				lock.unlock();
		}
	}

	public  <T> Future<T> submitTask(Runnable task, long trialId, T resultObj) {
		return submitTask(task, trialId, resultObj, false);
	}
	
	public Future<?> forceSubmitTask(Runnable task) {
		return campaignExecutorPool.submit(task);
	}
	
	private <T> Future<T> submitTask(Runnable task, long trialId, T resultObj, boolean forceSubmit) {
		boolean lockAquired = false;
		try {
			if (!forceSubmit) {
				if (lock.tryLock()) {
					lockAquired = true;
					if (verifyTrialExecutionAndAcquireCoreLock(trialId)) {
						putTrialInExecution(trialId);
						return campaignExecutorPool.submit(task, resultObj);
					}
					logger.debug("Permit not available for trial {}", trialId);
				}
				logger.debug("Lock not available for trial {}", trialId);
				return null;
			} else {
				return campaignExecutorPool.submit(task, resultObj);
			}
		} catch (Exception e) { 
			logger.error("Caught exception while trying to submit trial {} for execution: {}", trialId, e);
			return null;
		} finally {
			if (lockAquired)
				lock.unlock();
		}
	}

	public <T> Future<T> submitTask(Callable<T> task, long trialId) {
		return submitTask(task, trialId, false);
	}
	
	public <T> Future<T> submitTask(Callable<T> task) {
		return campaignExecutorPool.submit(task);
	} 
	
	private <T> Future<T> submitTask(Callable<T> task, long trialId, boolean forceSubmit) {
		boolean lockAquired = false;
		try {
			if (!forceSubmit) {
				if (lock.tryLock()) {
					lockAquired = true;
					if (verifyTrialExecutionAndAcquireCoreLock(trialId)) {
						putTrialInExecution(trialId);
						return campaignExecutorPool.submit(task);
					}
					logger.debug("Permit not available for trial {}", trialId);
				}
				logger.debug("Lock not available for trial {}", trialId);
				return null;
			} else {
				return campaignExecutorPool.submit(task);
			}
		} catch (Exception e) { 
			logger.error("Caught exception while trying to submit trial {} for execution: {}", trialId, e);
			return null;
		} finally {
			if (lockAquired)
				lock.unlock();
		}
	}

}
