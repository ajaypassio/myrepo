package com.questdiagnostics.campaignservice.async.task;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.questdiagnostics.campaignservice.async.service.CampaignAsyncTaskService;
import com.questdiagnostics.campaignservice.async.service.CampaignBatchService;
import com.questdiagnostics.campaignservice.async.service.TrialExecutorService;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;

public abstract class CampaignAsyncTask implements Callable<Long> {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private Long taskResult;
	private TaskContext taskContext;

	protected CampaignAsyncTask() {
		super();
	}

	protected Long getTaskResult() {
		return taskResult;
	}

	protected TaskContext getTaskContext() {
		return taskContext;
	}

	public boolean isInitialized() {
		return taskResult != null && taskContext.getTrialId() != 0l && taskContext.getCampaignId() != 0l;
	}

	public void initializeNewTask(long campaignId, long trialId, SprinttCampaignStatus taskType,
			int newJobStatusForCampaign) {
		taskResult = -1l;
		taskContext = new TaskContext(false, taskType, campaignId, trialId, newJobStatusForCampaign, -1l);
	}

	public void initializeInterruptedTask(long campaignId, long trialId, Long jobId, SprinttCampaignStatus taskType,
			int newJobStatusForCampaign) {
		this.taskResult = jobId;
		taskContext = new TaskContext(true, taskType, campaignId, trialId, newJobStatusForCampaign, jobId);
	}

	protected Long call(CampaignAsyncTaskService campaignAsyncTaskService, CampaignBatchService campaignBatchService,
			TrialExecutorService trialCampaignExecutorService) {
		Instant jobStart = Instant.now();
		try {
			campaignAsyncTaskService.updateCampaignJobStatus(getTaskContext().getNewJobStatusForCampaign(),
					getTaskContext().getCampaignId());

			return campaignBatchService.executeCampaignJobInBatches(getTaskContext());
		} finally {
			trialCampaignExecutorService.removeTrialFromExecution(getTaskContext().getTrialId());
			logger.info("{} task completed for campaign {} and took {} seconds", getTaskContext().getTaskType(),
					getTaskContext().getCampaignId(), Duration.between(jobStart, Instant.now()).getSeconds());
		}
	}

}
