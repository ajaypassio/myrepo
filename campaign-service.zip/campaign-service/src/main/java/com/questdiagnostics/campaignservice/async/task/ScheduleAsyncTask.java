package com.questdiagnostics.campaignservice.async.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.questdiagnostics.campaignservice.async.service.CampaignAsyncTaskService;
import com.questdiagnostics.campaignservice.async.service.CampaignBatchService;
import com.questdiagnostics.campaignservice.async.service.TrialExecutorService;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ScheduleAsyncTask extends CampaignAsyncTask {

	@Autowired
	@Qualifier("scheduleAsyncTaskService")
	private CampaignAsyncTaskService campaignAsyncTaskService;

	@Autowired
	@Qualifier("patientDeduplicationService")
	private CampaignBatchService campaignBatchService;

	@Autowired
	private TrialExecutorService trialCampaignExecutorService;

	@Override
	public Long call() throws Exception {
		return super.call(campaignAsyncTaskService, campaignBatchService, trialCampaignExecutorService);
	}

}
