package com.questdiagnostics.campaignservice.async.task;

import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;

public class TaskContext {

	private long jobId;
	private long campaignId;
	private long trialId;
	private int newJobStatusForCampaign;
	private boolean failedOnLastExecution;
	private boolean isPatientListEmpty;
	private boolean scheduleLapsed;
	private CampaignJobStatus failureType;
	private CampaignJobStatus failedBatchRetryStatus;
	private SprinttCampaignStatus taskType;
	private long failedBatchId;

	protected TaskContext() {
	}

	TaskContext(boolean failedOnLastExecution, SprinttCampaignStatus taskType, long campaignId, long trialId,
			int newJobStatusForCampaign, long jobId) {
		super();
		this.failedOnLastExecution = failedOnLastExecution;
		this.taskType = taskType;
		this.campaignId = campaignId;
		this.trialId = trialId;
		this.newJobStatusForCampaign = newJobStatusForCampaign;
		this.jobId = jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}
	
	public long getJobId() {
		return jobId;
	}

	public long getCampaignId() {
		return campaignId;
	}

	public long getTrialId() {
		return trialId;
	}

	public int getNewJobStatusForCampaign() {
		return newJobStatusForCampaign;
	}

	public void setFailedOnLastExecution(boolean failedOnLastExecution) {
		this.failedOnLastExecution = failedOnLastExecution;
	}

	public boolean isFailedOnLastExecution() {
		return failedOnLastExecution;
	}

	public CampaignJobStatus getFailureType() {
		return failureType;
	}

	public void setFailureType(CampaignJobStatus failureType) {
		this.failureType = failureType;
	}

	public long getFailedBatchId() {
		return failedBatchId;
	}

	public void setFailedBatchId(long failedBatchId) {
		this.failedBatchId = failedBatchId;
	}

	public CampaignJobStatus getFailedBatchRetryStatus() {
		return failedBatchRetryStatus;
	}

	public void setFailedBatchRetryStatus(CampaignJobStatus retryStatus) {
		this.failedBatchRetryStatus = retryStatus;
	}

	public SprinttCampaignStatus getTaskType() {
		return taskType;
	}

	public boolean isPatientListEmpty() {
		return isPatientListEmpty;
	}

	public void setPatientListEmpty(boolean isPatientListEmpty) {
		this.isPatientListEmpty = isPatientListEmpty;
	}

	/**
	 * @return the scheduleLapsed
	 */
	public boolean isScheduleLapsed() {
		return scheduleLapsed;
	}

	/**
	 * @param scheduleLapsed the scheduleLapsed to set
	 */
	public void setScheduleLapsed(boolean scheduleLapsed) {
		this.scheduleLapsed = scheduleLapsed;
	}
}