
package com.questdiagnostics.campaignservice.async.task.report;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "batchId", "recordsProcessed", "totalTimeTaken", "batchStatus", "stages" })
public class BatchMetrics implements Serializable {
	private static final long serialVersionUID = 1;

	@JsonProperty("batchId")
	private Long batchId;

	@JsonProperty("recordsProcessed")
	private Integer recordsProcessed;

	@JsonProperty("totalTimeTaken")
	private Long totalTimeTaken;

	@JsonProperty("batchStatus")
	private String batchStatus;

	@JsonProperty("stages")
	private List<StageMetrics> stages;

	public BatchMetrics() {
		super();
		stages = new ArrayList<>();
		batchId = -1l;
		recordsProcessed = 0;
		totalTimeTaken = 0l;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public Integer getRecordsProcessed() {
		return recordsProcessed;
	}

	public void addToRecordsProcessed(Integer recordsProcessed) {
		this.recordsProcessed = this.recordsProcessed + recordsProcessed;
	}

	public Long getTotalTimeTaken() {
		return totalTimeTaken;
	}

	public void addToTotalTimeTaken(Long totalTimeTaken) {
		this.totalTimeTaken = this.totalTimeTaken + totalTimeTaken;
	}

	public String getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
	}

	List<StageMetrics> getStages() {
		return stages;
	}

	public void addStage(StageMetrics stage) {
		stages.add(stage);
	}
	
	public StageMetrics getStage(int index) {
		return stages.get(index);
	}
	
	public StageMetrics getLatestStage() {
		return stages.get(stages.size() - 1);
	}
}
