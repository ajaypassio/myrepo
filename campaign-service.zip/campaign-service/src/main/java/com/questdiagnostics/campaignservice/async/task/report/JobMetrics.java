
package com.questdiagnostics.campaignservice.async.task.report;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "jobId", "trialId", "campaignId", "jobStatus", "jobType", "recordsProcessed", "batchesProcessed",
		"batchSize", "totalTimeTaken", "batches" })
public class JobMetrics implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonProperty("jobId")
	private Long jobId;

	@JsonProperty("trialId")
	private Long trialId;

	@JsonProperty("campaignId")
	private Long campaignId;

	@JsonProperty("jobStatus")
	private String jobStatus;

	@JsonProperty("jobType")
	private String jobType;

	@JsonProperty("recordsProcessed")
	private Integer recordsProcessed;

	@JsonProperty("batchesProcessed")
	private Integer batchesProcessed;

	@JsonProperty("batchSize")
	private Integer batchSize;

	@JsonProperty("totalTimeTaken")
	private Long totalTimeTaken;

	@JsonProperty("batches")
	private List<BatchMetrics> batches;

	public JobMetrics(Long jobId, Long trialId, Long campaignId, String jobType) {
		super();
		this.jobId = jobId;
		this.trialId = trialId;
		this.campaignId = campaignId;
		this.jobType = jobType;
		this.batchSize = 0;
		batches = new ArrayList<>();
		recordsProcessed = 0;
		batchesProcessed = 0;		
		totalTimeTaken = 0l;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Long getJobId() {
		return jobId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public Long getCampaignId() {
		return campaignId;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setBatchSize(Integer batchSize) {
		this.batchSize = batchSize;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getJobType() {
		return jobType;
	}

	public Integer getRecordsProcessed() {
		return recordsProcessed;
	}

	public void addRecordsProcessed(Integer recordsProcessed) {
		this.recordsProcessed = this.recordsProcessed + recordsProcessed;
	}

	public Integer getBatchesProcessed() {
		return batchesProcessed;
	}

	private void addBatchesProcessed() {
		this.batchesProcessed = this.batchesProcessed + 1;
	}

	public Integer getBatchSize() {
		return batchSize;
	}

	public Long getTotalTimeTaken() {
		return totalTimeTaken;
	}

	public void addTotalTimeTaken(Long totalTimeTaken) {
		this.totalTimeTaken = this.totalTimeTaken + totalTimeTaken;
	}

	public void addBatch(BatchMetrics batch) {
		this.batches.add(batch);
		addBatchesProcessed();
	}
	
	public BatchMetrics getBatch(int index) {
		return batches.get(index);
	}
	
	public BatchMetrics getLatestBatch() {
		return batches.get(batches.size() - 1);
	}
}
