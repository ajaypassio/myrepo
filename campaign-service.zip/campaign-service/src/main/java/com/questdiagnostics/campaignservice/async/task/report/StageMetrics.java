
package com.questdiagnostics.campaignservice.async.task.report;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "stage", "timeTaken" })
public class StageMetrics implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("stage")
	private String stage;

	@JsonProperty("timeTaken")
	private Long timeTaken;

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public Long getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(Long timeTaken) {
		this.timeTaken = timeTaken;
	}

}
