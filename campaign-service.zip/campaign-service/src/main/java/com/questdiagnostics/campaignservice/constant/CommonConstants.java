package com.questdiagnostics.campaignservice.constant;

/*
 * Constant class
 * @author: Ajay kumar
 */
public class CommonConstants {

	private CommonConstants() {
		throw new UnsupportedOperationException("Utility class; constructor not allowed.");
	}

	public static final String ASYNC_SERVICE_NAME = "campaign-processor";
	public static final String WHITESPACE = " ";
	public static final String TRUE_VALUE = "true";
	public static final String FALSE_VALUE = "false";
	public static final String EMPTY_STRING = "";
	public static final String PATIENT_LIST_GENERATED = "Campaign patient list file successfully processed";
	public static final String PATIENT_LIST_FAILED = "Campaign patient list file creation process failed";

	public static final String DRAFT_CREATED = "Draft Created at #dateTime";
	public static final String DRAFT_MODIFIED = "Draft Modified at #dateTime";
	public static final String SCHEDULED_SUCCESSFULLY = "Scheduled Successfully at #dateTime";
	public static final String EMAIL_TO_BE_SENT_AT = "Email to be sent at #dateTime";
	public static final String DEPLOYED_AT = "Deployed at #dateTime";
	public static final String EMAIL_SCHEDULED_FOR = "Email Scheduled for #dateTime";
	public static final String EMAIL_SENT_AT = "Email Sent at #dateTime";
	public static final String ENDED_ON = "Ended on #dateTime";
	public static final String DISCARDED_ON = "Discarded on #dateTime";
	public static final String REVERTED_TO_DRAFT = "Reverted to Draft on #dateTime";

	public static final String UPDATE_CAMPAIGN_ERROR_MSG = "Campaign update failed.";
	public static final String ELOQUA_COMMUINICATION_ERROR_MSG = "Error occured while interacting with Eloqua.";

	public static final String CAMPAIGN_DEPLOYED_MSG = "Campaign successfully deployed.";
	public static final String CAMPAIGN_SCHEDULED_MSG = "Campaign successfully scheduled.";
	public static final String PATIENT_EMAIL_DOES_NOT_EXIST = "None of patients in the patient list have email address.";
	public static final String CAMPAIGN_DOES_NOT_EXIST = "Campaign Doesn't exist.";
	public static final String CONTACT_LIST_UPLOAD_IS_IN_PROGRESS = "Contact List Upload is in progress";
	public static final String EMPTY_EMAIL_SCHEDULE_ERROR_MSG = "Schedule and Email template both must be present.";
	public static final String EST = "US/Eastern";
	public static final String BLANK = "No next action planned";
	public static final String NO_ACTION_NEEDED = "No next action applied";

	public static final String GMT = "GMT";

	public static final String SUCCESS = "SUCCESS";

	public static final String IN_PROGRESS = "IN_PROGRESS";
	public static final String NOT_EXISTS = "NOT_EXISTS";
	public static final String PATIENT_LIST_GENERATION_INPROGRESS_MSG = "Patients list is still being associated with the campaign.";
	public static final String NO_ACTION = "Next action or Last action was not provided.";
	public static final String TRIAL_TABLE = "ParticipantStudySite_T_";
	public static final String CONTACT_UPLOADED_USER = "Contact uploaded by backend job";

	public static final String REMINDER_AT = "Reminder at #dateTime";
	public static final String NEXT_REMINDER_AT = "Reminder #reminder at #dateTime";

//	public static final String REMINDER_SENT_AT = "Reminder #reminder Sent at #dateTime";   // comment by jyoti-28-03-2020
	public static final String REMINDER_SENT_AT = "Email #reminder Sent at #dateTime";
	public static final String REMINDER_SENT_ENDED = "End at #dateTime when end time is available for Trial default";
	public static final String OFFSET = "OFFSET";
	public static final String ROWS = "ROWS FETCH NEXT";
	public static final String ONLY = "ROWS ONLY";
	public static final String CAMPAIGN_SCHEDULING_IN_PROGRESS = "Campaign scheduling is in progress. Please try to deploy the campaign again after sometime";
	public static final String CAMPAIGN_FAILED_EMPTY_CONTACT_LIST = "Campaign has been failed due to empty contact list. This campaign cannot be redeployed.";

	public static final String DEFAULT_REMARKS = "|";
	public static final String PATIENT_LIST_GENERATION_STARTED = " Patient list generation started at ";
	public static final String PATIENT_LIST_GENERATION_ENDED = " Patient list generation ended at ";
	public static final String CONTACT_GENERATION_STARTED = " Contact generation started at ";
	public static final String CONTACT_GENERATION_ENDED = " Contact generation ended at ";
	public static final String CONTACT_GENERATION_FAILED = " Contact generation failed at ";
	public static final String DEDUPLICATION_AND_CONTACT_STARTED = " Deduplication and Contact upload started at ";
	public static final String DEDUPLICATION_AND_CONTACT_ENDED = " Deduplication and Contact upload ended at ";
	public static final String DRAFT = "DRAFT";
	public static final String SCHEDULED = "SCHEDULED";
	public static final String DEPLOYED = "DEPLOYED";
	public static final String DISCARDED = "DISCARDED";
	public static final String CLOSED = "CLOSED";
	public static final String GET_IMAGE_SASURL_ERROR = "Error occured while processing get SAS image url for image";
	public static final String PATIENT_LIST_TO_BE_SENT = "Patient list to be sent at #dateTime";
	public static final String INITIATED_TRANSACTION_OUT_BOX_ENTRY_EXISTS="Already an initiated record exists for this sprinttCampaignId in MyQuestTransactionOutBox";
	public static final String PATIENT_LIST_SENT_ON = "Patient list sent on #dateTime";
	public static final String CAMPAIGN_EDITS_WERE_SENT_LASTACTION = "Campaign edits were sent on #dateTime";
	public static final String CAMPAIGN_EDITS_WERE_SENT_NEXTACTION = "Campaign edits will be sent on #dateTime";
	public static final String CAMPAIGN_NAME_OR_USER_NAME_BLANK= "CampaignName or UserName is blank";
	public static final String CAMPAIGN_NAME_EXIST= "Campaign Name already exist";
	public static final String SCHEDULED_AND_NPI_ASSOCIATION_REQUEST_SUBMITTED = "Campaign Scheduled and NPI association request successfully submitted.";
	public static final String SCHEDULED_AND_NPI_ASSOCIATION_REQUEST_FAILED = "Campaign Scheduled and NPI association request failed.";
	public static final String SCHEDULED_ELOQUA_PATIENT_CAMPAIGN_START= "Scheduled Eloqua Patient Campaign-Start";
	public static final String SCHEDULED_ELOQUA_PATIENT_CAMPAIGN_SUCCESS= "Scheduled Eloqua Patient Campaign-Success";
	public static final String SCHEDULED_ELOQUA_PATIENT_CAMPAIGN_FAILURE= "Scheduled Eloqua Patient Campaign-Failure";
	public static final String PHYSICIAN_LIST_START = "Physician List-Start";
}
