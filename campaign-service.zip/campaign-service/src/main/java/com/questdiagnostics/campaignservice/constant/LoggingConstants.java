package com.questdiagnostics.campaignservice.constant;

/**
 * Author: Ajay Kumar The Class LoggingConstants.
 */
public class LoggingConstants {

	private LoggingConstants() {

	}

	/** The Constant ERROR_CAMPAIGN_CREATION */
	public static final String ERROR_CAMPAIGN_CREATION = "campaign creation error";

	public static final String ERROR_CAMPAIGN_ACTIVATION = "campaign activation error";

	public static final String ERROR_CAMPAIGN_DEACTIVATION = "campaign deactivation error";

	public static final String ERROR_CAMPAIGN_RECONSIDER = "campaign reconsider error";

	public static final String ERROR_CAMPAIGN_END = "campaign end error";

	public static final String ERROR_CAMPAIGN_SCHEDULING = "campaign scheduling error";

	/** The Constant ERROR_REMINDER_CREATION */
	public static final String ERROR_REMINDER_CREATION = "Reminder creation error";
	public static final String ERROR_CAMPAIGN_CREATION_LOG = "Error occured while processing create campaign: {} ";

	/** The Constant ERROR_REMINDER_UPDATION */
	public static final String ERROR_REMINDER_UPDATION = "Reminder updation error";

	/** The Constant ERROR_REMINDER_GETTING */
	public static final String ERROR_REMINDER_GETTING = "Reminder getting error";

	/** The Constant ERROR_REMINDER_SCHEDULE_CREATION */
	public static final String ERROR_REMINDER_SCHEDULE_CREATION = "Reminder and Schedule creation error";

	public static final String ERROR_REMINDER_SCHEDULE_CREATION_LOG = "Error occured while adding default options : {} ";

	/** The Constant ERROR_REMINDER_SCHEDULE_UPDATION */
	public static final String ERROR_REMINDER_SCHEDULE_UPDATION = "Reminder and Schedule updation error";
	public static final String ERROR_REMINDER_SCHEDULE_UPDATION_LOG = "Error occured while updating default options: {} ";

	/** The Constant ERROR_REMINDER_SCHEDULE_GETTING */
	public static final String ERROR_REMINDER_SCHEDULE_GETTING = "Reminder and Schedule getting error";
	public static final String ERROR_REMINDER_SCHEDULE_GETTING_LOG = "Error occured while getting default options: {} ";

	/** The Constant ERROR_SCHEDULE_CREATION */
	public static final String ERROR_SCHEDULE_CREATION = "Schedule creation error";

	/** The Constant ERROR_SCHEDULE_UPDATION */
	public static final String ERROR_SCHEDULE_UPDATION = "Schedule updation error";

	/** The Constant ERROR_SCHEDULE_GETTING */
	public static final String ERROR_SCHEDULE_GETTING = "schedule getting error";

	/** The Constant ERROR_SCHEDULE_GETTING */
	public static final String ERROR_SCHEDULE_UPDATION_SCHEDULEID = "scheduleID updation error";

	/** The Constant ERROR_SCHEDULE_GETTING */
	public static final String ERROR_REMINDER_UPDATION_REMINDERID = "REMINDERID updation error";

	/** The Constant CAMPAIGN_EXIST */
	public static final String CAMPAIGN_EXIST = "Campaign already exist with trail id {} and campaign name {}";

	/** The Constant CAMPAIGN_NOT_EXIST */
	public static final String CAMPAIGN_NOT_EXIST = "Campaign does not exist for trail id {} and campaign name {}";

	/** The Constant ERROR_EMAIL_CREATION */
	public static final String ERROR_EMAIL_CREATION = "Email creation error";

	/** The Constant ERROR_SCHEDULE_UPDATION */
	public static final String ERROR_EMAIL_UPDATION = "Email updation error";

	/** The Constant ERROR_EMAIL_GETTING */
	public static final String ERROR_EMAIL_GETTING = "Email Template getting error";

	/** The Constant ERROR_CAMPAIGN_UPDATION */
	public static final String ERROR_CAMPAIGN_UPDATION = "campaign updation error";
	public static final String ERROR_CAMPAIGN_UPDATION_LOG = "Error occured while processing update campaign: {} ";

	/** The Constant ERROR_CAMPAIGN_GETTING */
	public static final String ERROR_CAMPAIGN_GETTING = "campaign getting error";

	public static final String ERROR_CAMPAIGN_ALREADY_EXIST_LOG = "Error occured while create campaign as the campaign name already exists: {} ";
	public static final String ERROR_CAMPAIGN_ALREADY_EXIST = "Campaign Name Already Exists";
	public static final String ERROR_DEFAULT_SCHEDULE_DOES_NOT_EXIST = "Default Schedule Does Not Exist";
	public static final String ERROR_DEFAULT_EMAIL_TEMPLATE_DOES_NOT_EXIST = "Default Email Template Does Not Exist";
	public static final String ERROR_DEFAULT_REMINDER_DOES_NOT_EXIST = "Default Reminder Does Not Exist";
	public static final String CAMPAIGN_ALREADY_EXIST = "Campaign Name Already Exists";

	/** The Constant ERROR_SCHEDULE_GETTING Schedule already exist */
	public static final String ERROR_SCHEDULE_EXIST = "Schedule with trail id already exist";

	/** The Constant ERROR_Reminder_GETTING Reminder already exist */
	public static final String ERROR_REMINDER_EXIST = "Reminder with trail id already exist";

	/** The Constant ERROR_Email Template_GETTING Email template already exist */
	public static final String ERROR_EMAIL_TEMPLATE_EXIST = "Email Template with trail id already exist";

	public static final String ERROR_CAMPAIGN_DISCARD = "campaign discard error";

	public static final String ERROR_CAMPAIGN_RECONSIDER_LOG = "Caught exception while trying to move campaign {} to {} : {}";

	public static final String ERROR_CAMPAIGN_UPDATE_LOG = "Error occured during campaign update.";

	public static final String CAMPAIGN_NOT_DEPLOYED = "Campaign not deployed error.";

	public static final String ERROR_CAMPAIGN_DISCARD_LOG = "Caught exception while trying to discard campaign {} to {} : {}";

	public static final String ERROR_CAMPAIGN_RECONSIDER_END_CAMPAIGN = "reconsider end campaign error";

	public static final String ERROR_MYQUEST_CAMPAIGN_GETTING = "myquest campaign getting error";
	public static final String ERROR_MYQUEST_CAMPAIGN_UPDATION = "myquest campaign updation error";

	public static final String ERROR_MYQUEST_CAMPAIGN_UPDATION_LOG = "Error occured while processing update campaign myquest: {} ";
	
	public static final String PHYSICIAN_CAMPAIGN_NOT_EXIST = "SprinttCampaignId is not exist.";
}