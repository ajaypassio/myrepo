package com.questdiagnostics.campaignservice.constant;

/*
 * Message class
 * @author: Ajay kumar
 */
public class MessageConstants {

	private MessageConstants() {
		throw new IllegalStateException("Utility class");
	}

	public static final String CAMPAIGN_EXIST = "Campaign already exists";
	public static final String CAMPAIGN_NOT_EXIST = "Campaign does not exists";
	public static final String PHYSICIAN_EMAIL_OUTREACH_DOES_NOT_EXIST = "Physician Email Outreach does not exists";
	public static final String CAMPAIGN_ID_MNDT = "Campaign id is mandatory";
	public static final String CAMPAIGID_MNDT = "Campaign id is mandatory";
	public static final String TRIALID_MNDT = "Trial id is mandatory";
	public static final String CAMPAIGN_DISCARD_SUCCESS = "Campaign discarded successfully";
	public static final String CAMPAIGN_DISCARD_FALIURE = "Campaign can't be discarded";
	public static final String STUDY_INFO_NOT_EXIST = "Study info does not exists";
	public static final String IMAGE_VALIDATION_TXT = "Maximum five images allowed";
	public static final String IMAGE_UPLOAD_SUCCESS = "Successfully uploaded campaign image";
	public static final String CAMPAIGN_SURVEY_VALIDATION_ERROR = "Please remove the scheduling details until a survey is associated with the trial.";
	public static final String CAMPAIGN_DISCARD_ERROR = "Campaign can't be discarded as its not in draft or Schedule state";
}
