package com.questdiagnostics.campaignservice.controllers;

import static com.questdiagnostics.campaignservice.constant.LoggingConstants.ERROR_CAMPAIGN_UPDATION;
import static com.questdiagnostics.campaignservice.constant.LoggingConstants.ERROR_CAMPAIGN_UPDATION_LOG;

import java.io.IOException;
import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.constant.LoggingConstants;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.CampaignServiceException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;
import com.questdiagnostics.campaignservice.request.model.CampaignRequest;
import com.questdiagnostics.campaignservice.request.model.ImageInfo;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.CampaignService;
import com.questdiagnostics.campaignservice.util.Constants;

/*
 * Campaign controller class which is responsible for handling campaign related activities
 * @author: Ajay kumar
 */
@RestController
public class CampaignController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CampaignService campaignService;

	@PutMapping(value = "/campaign/update")
	public ResponseEntity<ResponseObjectModel> updateEloquaCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignMaster campaignMaster) {

		ResponseObjectModel responseObjectModel = null;

		try {
			responseObjectModel = campaignService.updateCampaign(campaignMaster, false);
		} catch (URISyntaxException | JsonProcessingException | HttpClientErrorException e) {
			logger.error(ERROR_CAMPAIGN_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ERROR_CAMPAIGN_UPDATION, e);
		} catch (EloquaException e) {
			logger.error(ERROR_CAMPAIGN_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_CAMPAIGN_UPDATION, e);
		} catch (Exception e) {
			logger.error(ERROR_CAMPAIGN_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_CAMPAIGN_UPDATION, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	/*
	 * @PutMapping(value = "/campaign/activate/{sprinttCampaignId}") public
	 * ResponseEntity<String> activateCampaign(@RequestHeader HttpHeaders headers,
	 * 
	 * @PathVariable Long sprinttCampaignId) { try {
	 * campaignService.activateCampaign(sprinttCampaignId, true); } catch
	 * (HttpClientErrorException httpClientErrorException) {
	 * logger.error("Error occured while processing activate campaign: {} ",
	 * httpClientErrorException.getMessage()); throw new
	 * ResponseStatusException(HttpStatus.NOT_FOUND,
	 * LoggingConstants.ERROR_CAMPAIGN_ACTIVATION, httpClientErrorException); }
	 * catch (WorkflowEngineException e) {
	 * logger.error("Error occured while processing activate campaign: {} ",
	 * e.getMessage()); throw new ResponseStatusException(HttpStatus.NOT_FOUND,
	 * LoggingConstants.ERROR_CAMPAIGN_ACTIVATION, e); } catch (EloquaException e) {
	 * logger.error("Error occured while processing activate campaign: {} ",
	 * e.getMessage()); throw new ResponseStatusException(HttpStatus.NOT_FOUND,
	 * LoggingConstants.ERROR_CAMPAIGN_ACTIVATION, e); } return new
	 * ResponseEntity<>("{\"message\":\"campaign successfully deployed\"}",
	 * HttpStatus.OK); }
	 */

	@PutMapping(value = "/campaign/deactivate/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> deactivateCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for activate campaign for Sprintt campaign {}", sprinttCampaignId);
			responseObjectModel = campaignService.deactivateCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing deactivate campaign: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_DEACTIVATION,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			logger.error("Error occured while processing deactivate campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_DEACTIVATION, e);
		} catch (EloquaException e) {
			logger.error("Error occured while processing deactivate campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_DEACTIVATION, e);
		} catch (Exception e) {
			logger.error("Error occured while processing deactivate campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_DEACTIVATION, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PutMapping(value = "/campaign/activate/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> activateCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for activate campaign for Sprintt campaign {}", sprinttCampaignId);
			responseObjectModel = campaignService.activateCampaign(sprinttCampaignId, true);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing activate campaign: {} ",
					httpClientErrorException.getMessage());

			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_ACTIVATION,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			e.printStackTrace();
			logger.error("Error occured while processing activate campaign: {} ", e.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_ACTIVATION, e);
		} catch (EloquaException e) {
			e.printStackTrace();
			logger.error("Error occured while processing activate campaign: {} ", e.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_ACTIVATION, e);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error occured while processing activate campaign: {} ", e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_ACTIVATION, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PutMapping(value = "/campaign/schedule/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> scheduleCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for schedule campaign for Sprintt campaign {}", sprinttCampaignId);
			responseObjectModel = campaignService.activateCampaign(sprinttCampaignId, false);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing scheduling campaign: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_SCHEDULING,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			e.printStackTrace();
			logger.error("Error occured while processing scheduling campaign: {} ", e.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_SCHEDULING, e);
		} catch (EloquaException e) {
			e.printStackTrace();
			logger.error("Error occured while processing scheduling campaign: {} ", e.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_SCHEDULING, e);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error occured while processing activate campaign: {} ", e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_SCHEDULING, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PostMapping(value = "/campaign")
	public ResponseEntity<ResponseObjectModel> createDraftSprinttCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignMaster campaignData) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.createDraftCampaign(campaignData,Boolean.FALSE);
		} catch (URISyntaxException | JsonProcessingException | HttpClientErrorException campaignException) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_CREATION_LOG, campaignException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_CAMPAIGN_CREATION,
					campaignException);
		} catch (EloquaException e) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_CREATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_CREATION, e);
		} /*
			 * catch (Exception e) {
			 * logger.error(LoggingConstants.ERROR_CAMPAIGN_CREATION_LOG, e.getMessage());
			 * throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
			 * LoggingConstants.ERROR_CAMPAIGN_CREATION, e); }
			 */

		return new ResponseEntity<>(responseObjectModel, HttpStatus.CREATED);

	}

	@PutMapping(value = "/campaigns/update/draft")
	public ResponseEntity<CampaignMaster> updateDraftSprinttCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignMaster campaignData) {
		CampaignMaster campMaster = null;
		try {
			// campMaster=campaignService.persistCampaignData(campaignData);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing update campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_CAMPAIGN_UPDATION,
					httpClientErrorException);
		}
		return new ResponseEntity<>(campMaster, HttpStatus.CREATED);

	}

	@GetMapping(value = "/campaign/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> getDefault(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.getCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing get campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_GETTING,
					httpClientErrorException);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@GetMapping(value = "/campaign/trial/{sprinttTrialId}")
	public ResponseEntity<ResponseObjectModel> getCampaignsForTrailId(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttTrialId) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		responseObjectModel = campaignService.getCampaignsForTrial(sprinttTrialId);
		if (responseObjectModel.getHttpStatus().equals(HttpStatus.OK))
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		else
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
	}

	/*
	 * End point to handle deploy or schedule campaigns Implementation of US24661 by
	 * Jitendra
	 */
	@PutMapping(value = "/campaign/activate/v2/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> deployScheduleCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;

		/*
		 * Here we need to call update campaign end point to update the
		 * campaign,schedule,reminders and email template before deploy or schedule
		 */
		boolean isUpdated = true;

		if (isUpdated) {
			responseObjectModel = campaignService.deployScheduleCampaign(sprinttCampaignId, true);
			logger.info("Deploy Campaign request received {}", sprinttCampaignId);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} else {
			responseObjectModel.setMessage(CommonConstants.UPDATE_CAMPAIGN_ERROR_MSG);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping(value = "/campaign/discard/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> discardCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for discard campaign for Sprintt campaign {}", sprinttCampaignId);
			responseObjectModel = campaignService.discardCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing discard campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_DISCARD,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			logger.error("Error occured while processing discard campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_DISCARD, e);
		} catch (EloquaException e) {
			logger.error("Error occured while processing discard campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_DISCARD, e);
		} catch (Exception e) {
			logger.error("Error occured while processing discard campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, LoggingConstants.ERROR_CAMPAIGN_DISCARD,
					e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PutMapping(value = "/campaign/reconsider/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> reconsiderCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for reconsider discarded campaign for Sprintt campaign {}",
					sprinttCampaignId);
			responseObjectModel = campaignService.reconsiderCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing reconsider campaign: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_RECONSIDER,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			logger.error("Error occured while reconsidering a campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_RECONSIDER, e);
		} catch (EloquaException e) {
			logger.error("Error occured while reconsidering a campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_RECONSIDER, e);
		} catch (Exception e) {
			logger.error("Error occured while reconsidering a campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_RECONSIDER, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PutMapping(value = "/campaign/end/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> endCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for end campaign for Sprintt campaign {}", sprinttCampaignId);
			responseObjectModel = campaignService.endCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing end campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_END,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			logger.error("Error occured while ending a campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_END, e);
		} catch (EloquaException e) {
			logger.error("Error occured while ending a campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_END, e);
		} catch (Exception e) {
			logger.error("Error occured while ending a campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, LoggingConstants.ERROR_CAMPAIGN_END, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PutMapping(value = "/campaign/activate")
	public ResponseEntity<ResponseObjectModel> deployScheduleCampaignNew(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignMaster campaignData)
			throws JsonProcessingException, URISyntaxException, CampaignServiceException {
		ResponseObjectModel responseObjectModel = null;
		String tempSprintCampaignStatus = null;
		if (campaignData != null)
			tempSprintCampaignStatus = SprinttCampaignStatus.getStatusOf(campaignData.getCampaignStatusId()).getType();
		try {
			/**
			 * Check whether all reminders of the campaign are in future date ( > 60 minutes
			 * from scheduled date)
			 */
			responseObjectModel = campaignService.updateCampaign(campaignData, true);
		} catch (Exception e) {
			logger.error("Error occured while updating campaign campaign: {} ", e.getMessage());
			responseObjectModel.setMessage(LoggingConstants.ERROR_CAMPAIGN_UPDATE_LOG);
		}
		if(responseObjectModel.getData()!= null) {
			CampaignMaster campaignMaster = (CampaignMaster) responseObjectModel.getData();
			if (tempSprintCampaignStatus.equals("DRAFT"))
				responseObjectModel = campaignService.deployDraftScheduleCampaign(campaignMaster.getSprinttCampaignId(),
						true);
			else if (tempSprintCampaignStatus.equals("SCHEDULED"))
				responseObjectModel = campaignService.deployDraftScheduleCampaign(campaignMaster.getSprinttCampaignId(),false);
			else
				responseObjectModel.setMessage(LoggingConstants.CAMPAIGN_NOT_DEPLOYED);
		}
		
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@GetMapping(value = "/campaign/checkpatientlist/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> checkPatientListStatus(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		logger.info("Received request for checkPatientListStatus {}", sprinttCampaignId);
		ResponseObjectModel responseObjectModel = campaignService.isPatientListGenerated(sprinttCampaignId);
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
	
	@PutMapping(value = "/campaign/reconsiderEndedCampaign/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> reconsiderEndedCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			logger.info("Received request for reconsiderEndedCampaign to draft for Sprintt campaign {}",
					sprinttCampaignId);
			responseObjectModel = campaignService.reconsiderEndedCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing end campaign to draft: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_END_CAMPAIGN,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			logger.error("Error occured while reconsidering end campaign to draft: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_END_CAMPAIGN, e);
		} catch (EloquaException e) {
			logger.error("Error occured while reconsidering end campaign to draft: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_END_CAMPAIGN, e);
		} catch (Exception e) {
			logger.error("Error occured while reconsidering end campaign to draft: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_END_CAMPAIGN, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
	
	@GetMapping(value = "/campaign/checkdeployedcampaign/{trialId}")
	public ResponseEntity<ResponseObjectModel> checkTrialforDeployedCamp(@RequestHeader HttpHeaders headers,
			@PathVariable String trialId) {
		logger.info("Received request for checkTrialforDeployedCamp {}" + trialId);
		ResponseObjectModel responseObjectModel = campaignService.isCampDeployedForTrial(trialId);
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
	
	@GetMapping(value = "/campaign/eloquaCampaign/{eloquaCampaignId}")
	public ResponseEntity<ResponseObjectModel> getEloquaCampaignDetails(@RequestHeader HttpHeaders headers,
			@PathVariable String eloquaCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.getCampaignByEloquaId(eloquaCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing get campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_GETTING,
					httpClientErrorException);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
	
	@PostMapping(value = "/campaign/campaignMyQuest")
	public ResponseEntity<ResponseObjectModel> createDraftSprinttMyQuestCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignMasterMyQuest campaignDataMyQuest) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.createDraftMyQuestCampaign(campaignDataMyQuest,Boolean.FALSE);
		} catch (Exception e) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_CREATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_CREATION, e);
		}

		return new ResponseEntity<>(responseObjectModel, HttpStatus.CREATED);

	}

	@PostMapping(value = "/campaign/uploadCampaignImage/{trialId}", consumes = { "multipart/form-data" })
	public ResponseEntity<ResponseObjectModel> uploadCampaignImage(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId, @RequestParam(value = "uploadFiles", required = true) MultipartFile images[])
			throws IOException {
		logger.info("Upload image for trial id {} ", trialId);
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (images == null || StringUtils.isEmpty(trialId)) {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("trialId id is blank or images are blank");
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
		responseObjectModel = campaignService.uploadFiles(images, trialId);
		if (responseObjectModel.getHttpStatus().equals(HttpStatus.OK))
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		else
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
	}

	@GetMapping(value = "/campaign/getSASUrl/{imageName}/{trialId}")
	public ResponseEntity<ResponseObjectModel> getMyQuestImageSASUrl(@RequestHeader HttpHeaders headers,
			@PathVariable String imageName, @PathVariable Long trialId) {
		logger.info(" get SAS image url for image {} ", imageName);
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.getImageSASUrl(trialId, imageName);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing get SAS image url for image: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, CommonConstants.GET_IMAGE_SASURL_ERROR,
					httpClientErrorException);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@GetMapping(value = "/campaign/getImages/{trialId}")
	public ResponseEntity<ResponseObjectModel> getImages(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId) {
		logger.info("Received request to fetch Trial Images {}" + trialId);
		ResponseObjectModel responseObjectModel = campaignService.getImages(trialId);
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PostMapping(value = "/campaign/deleteImage")
	public ResponseEntity<ResponseObjectModel> deleteTrialImage(@RequestHeader HttpHeaders headers,
			@RequestBody ImageInfo imageInfo) {
		logger.info("Delete Image file for trial id {} ", imageInfo.getTrialId());
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		responseObjectModel = campaignService.deleteTrialImage(imageInfo.getTrialId(), imageInfo.getImageName());
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@PutMapping(value = "/campaign/updateMyquestCampaign")
	public ResponseEntity<ResponseObjectModel> updateDraftSprinttMyQuestCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignMasterMyQuest campaignDataMyQuest) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.updateDraftMyQuestCampaign(campaignDataMyQuest);
		} catch (Exception e) {
			logger.error(LoggingConstants.ERROR_MYQUEST_CAMPAIGN_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_MYQUEST_CAMPAIGN_UPDATION, e);
		}

		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);

	}

	@GetMapping(value = "/campaign/myQuest/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> getMyQuestCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.getMyQuestCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing get campaignMyquest: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_MYQUEST_CAMPAIGN_GETTING,
					httpClientErrorException);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);

	}
	@PostMapping(value = "/campaign/combinedcampaign")
	public ResponseEntity<ResponseObjectModel> createCombinedCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignRequest campaignRequest) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = campaignService.createCampaign(campaignRequest);
		} catch (Exception e) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_CREATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_CAMPAIGN_CREATION, e);
		}

		return new ResponseEntity<>(responseObjectModel, HttpStatus.CREATED);

	}
	
	@PutMapping(value = "/campaign/myquest/{campaign}/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> endMyQuestCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable String campaign,@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			if(campaign.equalsIgnoreCase("end")){
				logger.info("Received request for end MyQuest campaign for Sprintt campaign {}", sprinttCampaignId);
				responseObjectModel = campaignService.endMyQuestCampaign(sprinttCampaignId);
			}else if(campaign.equalsIgnoreCase("discard")){
				logger.info("Received request for discard MyQuest campaign for Sprintt campaign {}", sprinttCampaignId);
				responseObjectModel = campaignService.discardMyQuestCampaign(sprinttCampaignId);
			}else if(campaign.equalsIgnoreCase("revert")){
				logger.info("Received request for revert to Draft MyQuest campaign for Sprintt campaign {}", sprinttCampaignId);
				responseObjectModel = campaignService.reconsiderMyQuestCampaign(sprinttCampaignId);
			}else{
				responseObjectModel.setMessage(Constants.OPTION_NOT_SELECTED);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
			}
			
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing end MyQuest campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_END,
					httpClientErrorException);
		} catch (WorkflowEngineException e) {
			logger.error("Error occured while ending a MyQuest campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_END, e);
		}catch (Exception e) {
			logger.error("Error occured while ending a MyQuest campaign: {} ", e.getMessage());
			e.printStackTrace();
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, LoggingConstants.ERROR_CAMPAIGN_END, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
	
}
