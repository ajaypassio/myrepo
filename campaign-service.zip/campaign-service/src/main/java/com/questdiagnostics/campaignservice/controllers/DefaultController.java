package com.questdiagnostics.campaignservice.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.server.ResponseStatusException;

import com.questdiagnostics.campaignservice.constant.LoggingConstants;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.request.model.DefaultCampaignRequest;
import com.questdiagnostics.campaignservice.request.model.EmailTemplateElementResponse;
import com.questdiagnostics.campaignservice.response.model.DefaultCampaignResponse;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.DefaultService;

@Controller
@RequestMapping(path = "/default")
public class DefaultController {

	@Autowired
	private DefaultService defaultService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@PostMapping(value = "/schedule")
	public ResponseEntity<DefaultCampaignResponse> addDefaultScheduler(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("Add default schedular: {} ", defaultCampaignRequest);
		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();
		try {
			Schedule schedule = defaultCampaignRequest.getSchedule();
			schedule.setTrialId(defaultCampaignRequest.getTrailId());
			Schedule scheduleResponse = this.defaultService.persistDefaultScheduler(schedule);

			defaultCampaignResponse.setSchedule(scheduleResponse);
			defaultCampaignResponse.setTrialId(scheduleResponse.getTrialId());
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while adding default schedule: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_SCHEDULE_CREATION,
					httpClientErrorException);
		}
		return new ResponseEntity<>(defaultCampaignResponse, HttpStatus.CREATED);
	}

	@PostMapping(value = "/reminder")
	public ResponseEntity<DefaultCampaignResponse> addDefaultReminder(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("Adding default Reminder: {} ", defaultCampaignRequest);

		DefaultCampaignResponse campaignResponse = new DefaultCampaignResponse();
		try {
			Reminder reminder = defaultCampaignRequest.getReminder();
			reminder.setTrialId(defaultCampaignRequest.getTrailId());
			Reminder reminderResponse = this.defaultService.persistDefaultReminder(reminder);

			campaignResponse.setTrialId(reminderResponse.getTrialId());
			campaignResponse.setReminder(reminderResponse);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while adding default reminder: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_REMINDER_CREATION,
					httpClientErrorException);
		}
		return new ResponseEntity<>(campaignResponse, HttpStatus.CREATED);
	}

	@PutMapping(value = "/schedule")
	public ResponseEntity<DefaultCampaignResponse> updateDefaultSchedule(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("Update default schedule: {} ", defaultCampaignRequest);
		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();
		try {
			Schedule schedule = defaultCampaignRequest.getSchedule();
			schedule.setTrialId(defaultCampaignRequest.getTrailId());
			Schedule scheduleResponse = this.defaultService.updateDefaultSchedule(schedule);

			defaultCampaignResponse.setSchedule(scheduleResponse);
			defaultCampaignResponse.setTrialId(scheduleResponse.getTrialId());
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while updating default schedule: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_SCHEDULE_UPDATION,
					httpClientErrorException);
		}
		return new ResponseEntity<>(defaultCampaignResponse, HttpStatus.CREATED);
	}

	@PutMapping(value = "/reminder")
	public ResponseEntity<DefaultCampaignResponse> updateDefaultReminder(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("update default reminder: {}", defaultCampaignRequest);
		DefaultCampaignResponse campaignResponse = new DefaultCampaignResponse();
		try {
			Reminder reminder = defaultCampaignRequest.getReminder();
			reminder.setTrialId(defaultCampaignRequest.getTrailId());
			Reminder reminderResponse = this.defaultService.updateDefaultReminder(reminder);
			campaignResponse.setReminder(reminderResponse);
			campaignResponse.setTrialId(reminderResponse.getTrialId());
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while updating default reminder: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_REMINDER_UPDATION,
					httpClientErrorException);
		}

		return new ResponseEntity<>(campaignResponse, HttpStatus.CREATED);
	}

	@PostMapping(value = "/attibutes")
	public ResponseEntity<DefaultCampaignResponse> addDefault(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("----Add default schedular and Reminder {} ", defaultCampaignRequest.toString());
		DefaultCampaignResponse campaignResponse = null;
		try {

			// set default reminder details
			Reminder reminder = defaultCampaignRequest.getReminder();
			if (reminder != null) {
				reminder.setTrialId(defaultCampaignRequest.getTrailId());
			}else {
				reminder = new Reminder();
				reminder.setTrialId(defaultCampaignRequest.getTrailId());
			}

			// set default scheduler details
			Schedule schedule = defaultCampaignRequest.getSchedule();
			if (schedule != null) {
				schedule.setTrialId(defaultCampaignRequest.getTrailId());
			}else {
				schedule = new Schedule();
				schedule.setTrialId(defaultCampaignRequest.getTrailId());
			}

			// set default Email details
			EmailTemplate emailTemplate = defaultCampaignRequest.getEmailTemplate();
			if (emailTemplate != null) {
				emailTemplate.setTrialId(defaultCampaignRequest.getTrailId());
			}

			
			campaignResponse = this.defaultService.persistDefault(schedule, reminder, emailTemplate);
			if (defaultCampaignRequest.getTrailId() != null) {
				campaignResponse.setTrialId(defaultCampaignRequest.getTrailId());
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error(LoggingConstants.ERROR_REMINDER_SCHEDULE_CREATION_LOG, httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_REMINDER_SCHEDULE_CREATION,
					httpClientErrorException);
		} catch (Exception e) {
			logger.error(LoggingConstants.ERROR_REMINDER_SCHEDULE_CREATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_REMINDER_SCHEDULE_CREATION, e);
		}
		return new ResponseEntity<>(campaignResponse, HttpStatus.CREATED);
	}

	@PutMapping(value = "/attibutes")
	public ResponseEntity<DefaultCampaignResponse> updateDefault(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.debug("update default schedular and reminder {}", defaultCampaignRequest.toString());
		DefaultCampaignResponse campaignResponse = null;
		try {
			// set default reminder details
			Reminder reminder = defaultCampaignRequest.getReminder();
			if (reminder != null) {
				reminder.setTrialId(defaultCampaignRequest.getTrailId());
			}

			// set default scheduler details
			Schedule schedule = defaultCampaignRequest.getSchedule();
			if (schedule != null) {
				schedule.setTrialId(defaultCampaignRequest.getTrailId());
			}

			// set default Email details
			EmailTemplate emailTemplate = defaultCampaignRequest.getEmailTemplate();
			if (emailTemplate != null) {
				emailTemplate.setTrialId(defaultCampaignRequest.getTrailId());
			}

			campaignResponse = this.defaultService.updateDefault(schedule, reminder, emailTemplate);
			if (defaultCampaignRequest.getTrailId() != null) {
				campaignResponse.setTrialId(defaultCampaignRequest.getTrailId());
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error(LoggingConstants.ERROR_REMINDER_SCHEDULE_UPDATION_LOG, httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_REMINDER_SCHEDULE_UPDATION,
					httpClientErrorException);
		} catch (Exception e) {
			logger.error(LoggingConstants.ERROR_REMINDER_SCHEDULE_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_REMINDER_SCHEDULE_UPDATION, e);
		}
		return new ResponseEntity<>(campaignResponse, HttpStatus.CREATED);
	}

	@GetMapping(value = "/{trialId}")
	public ResponseEntity<ResponseObjectModel> getDefault(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId) {

		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		try {
			responseObjectModel = this.defaultService.getDefault(trialId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error(LoggingConstants.ERROR_REMINDER_SCHEDULE_GETTING_LOG, httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_REMINDER_SCHEDULE_GETTING,
					httpClientErrorException);
		} catch (Exception e) {
			logger.error(LoggingConstants.ERROR_REMINDER_SCHEDULE_GETTING_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
					LoggingConstants.ERROR_REMINDER_SCHEDULE_GETTING, e);
		}
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		return rect;
	}

	@GetMapping(value = "/schedule/{trialId}")
	public ResponseEntity<ResponseObjectModel> getDefaultSchedule(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId) {

		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		try {
			Schedule schedule = this.defaultService.getDefaultSchedule(trialId);
			if (schedule != null) {
				defaultCampaignResponse.setSchedule(schedule);
				defaultCampaignResponse.setTrialId(schedule.getTrialId());

				responseObjectModel.setData(defaultCampaignResponse);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage("Success");

			} else {
				responseObjectModel.setData(null);
				responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
				responseObjectModel.setMessage("Details not available");
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing GET Schedule : {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_SCHEDULE_GETTING,
					httpClientErrorException);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}

	@GetMapping(value = "/reminder/{trialId}")
	public ResponseEntity<ResponseObjectModel> getDefaultReminder(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId) {
		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			Reminder reminder = this.defaultService.getDefaultReminder(trialId);
			if (reminder != null) {
				defaultCampaignResponse.setReminder(reminder);
				defaultCampaignResponse.setTrialId(reminder.getTrialId());

				responseObjectModel.setData(defaultCampaignResponse);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage("Success");

			} else {
				responseObjectModel.setData(null);
				responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
				responseObjectModel.setMessage("Details not available");
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing create campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_REMINDER_GETTING,
					httpClientErrorException);
		}
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		return rect;
	}

	// Email Template
		@GetMapping(value = "/email")
		public ResponseEntity<EmailTemplateElementResponse> getEmailTemplates(@RequestHeader HttpHeaders headers) {
			EmailTemplateElementResponse elementResponse = new EmailTemplateElementResponse();
			try {

				List<EmailTemplateResponse> emailTemplateResponse = this.defaultService.getListOfEmail();
				EmailTemplateResponse[] elementRequest = new EmailTemplateResponse[emailTemplateResponse.size()];
				elementRequest = emailTemplateResponse.toArray(elementRequest);
				
				elementResponse.setElements(elementRequest);
					return new ResponseEntity<>(elementResponse, HttpStatus.OK);
				

			} catch (Exception httpClientErrorException) {
				logger.error("Error occured while processing GET List of Template from Eloqua : {} ",
						httpClientErrorException.getMessage());
				throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_EMAIL_GETTING,
						httpClientErrorException);
			}

		}

	@PostMapping(value = "/emails")
	public ResponseEntity<DefaultCampaignResponse> addDefaultEmailTemplate(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("Add default Email Template: {} ", defaultCampaignRequest);
		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();
		try {
			EmailTemplate emailTemplate = defaultCampaignRequest.getEmailTemplate();
			emailTemplate.setTrialId(defaultCampaignRequest.getTrailId());
			EmailTemplate emailResponse = this.defaultService.persistEmailTempalte(emailTemplate);

			defaultCampaignResponse.setEmailTemplate(emailResponse);
			defaultCampaignResponse.setTrialId(emailResponse.getTrialId());
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing create Email Template: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_EMAIL_CREATION,
					httpClientErrorException);
		}
		return new ResponseEntity<>(defaultCampaignResponse, HttpStatus.CREATED);
	}

	@PutMapping(value = "/emails")
	public ResponseEntity<DefaultCampaignResponse> updateDefaultEmailTemplate(@RequestHeader HttpHeaders headers,
			@RequestBody DefaultCampaignRequest defaultCampaignRequest) {
		logger.info("Update default Email Template: {} ", defaultCampaignRequest);
		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();

		try {
			EmailTemplate emailTemplate = defaultCampaignRequest.getEmailTemplate();
			emailTemplate.setTrialId(defaultCampaignRequest.getTrailId());
			EmailTemplate emailResponse = this.defaultService.updateEmailTempalte(emailTemplate);

			defaultCampaignResponse.setEmailTemplate(emailResponse);
			defaultCampaignResponse.setTrialId(emailResponse.getTrialId());
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing create Email Template: {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_EMAIL_CREATION,
					httpClientErrorException);
		}
		return new ResponseEntity<>(defaultCampaignResponse, HttpStatus.CREATED);
	}

	@GetMapping(value = "/emailById/{trialId}")
	public ResponseEntity<ResponseObjectModel> getEmailTemplateByTrialId(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId) {

		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();

		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		try {

			EmailTemplate emailTemplate = this.defaultService.getEmailTemplateByTrialId(trialId);
			if (emailTemplate != null) {
				defaultCampaignResponse.setEmailTemplate(emailTemplate);
				defaultCampaignResponse.setTrialId(emailTemplate.getTrialId());

				responseObjectModel.setData(defaultCampaignResponse);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage("Success");

			} else {
				responseObjectModel.setData(null);
				responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
				responseObjectModel.setMessage("Details not available");
			}

		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing GET EmailTemplate by Id : {} ",
					httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_EMAIL_GETTING,
					httpClientErrorException);
		}

		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		return rect;
	}
}