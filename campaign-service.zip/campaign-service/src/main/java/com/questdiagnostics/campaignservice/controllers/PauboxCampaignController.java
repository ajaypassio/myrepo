package com.questdiagnostics.campaignservice.controllers;

import static com.questdiagnostics.campaignservice.constant.LoggingConstants.ERROR_CAMPAIGN_UPDATION;
import static com.questdiagnostics.campaignservice.constant.LoggingConstants.ERROR_CAMPAIGN_UPDATION_LOG;

import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.constant.LoggingConstants;
import com.questdiagnostics.campaignservice.model.PauboxCampaignMaster;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.PauboxCampaignService;

@Controller
@RequestMapping(path = "/pauboxCampaign")
public class PauboxCampaignController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PauboxCampaignService pauboxCampaignService;
	
	@PostMapping(value = "/campaign")
	public ResponseEntity<ResponseObjectModel> createSprinttPauboxCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody PauboxCampaignMaster pauboxCampaignData) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = pauboxCampaignService.createSprinttPauboxCampaign(pauboxCampaignData, Boolean.FALSE);
		} catch (URISyntaxException | JsonProcessingException | HttpClientErrorException campaignException) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_CREATION_LOG, campaignException.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_CAMPAIGN_CREATION,
					campaignException);
		} 

		return new ResponseEntity<>(responseObjectModel, HttpStatus.CREATED);

	}
	
	@PutMapping(value = "/campaign/updatePaubox")
	public ResponseEntity<ResponseObjectModel> updateEloquaCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody PauboxCampaignMaster pauboxCampaignData) {

		ResponseObjectModel responseObjectModel = null;

		try {
			responseObjectModel = pauboxCampaignService.updatePauboxCampaign(pauboxCampaignData, false);
		} catch (URISyntaxException | JsonProcessingException | HttpClientErrorException e) {
			logger.error(ERROR_CAMPAIGN_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ERROR_CAMPAIGN_UPDATION, e);
		} catch (Exception e) {
			logger.error(ERROR_CAMPAIGN_UPDATION_LOG, e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_CAMPAIGN_UPDATION, e);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
	
	@GetMapping(value = "/campaign/{sprinttCampaignId}")
	public ResponseEntity<ResponseObjectModel> getPauboxCampaign(@RequestHeader HttpHeaders headers,
			@PathVariable Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = pauboxCampaignService.getPauboxCampaign(sprinttCampaignId);
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while processing get campaign: {} ", httpClientErrorException.getMessage());
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_CAMPAIGN_GETTING,
					httpClientErrorException);
		}
		return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
	}
}
