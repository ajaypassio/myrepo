package com.questdiagnostics.campaignservice.controllers;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

import com.questdiagnostics.campaignservice.constant.LoggingConstants;
import com.questdiagnostics.campaignservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.campaignservice.model.PhysicianCampaignMasterList;
import com.questdiagnostics.campaignservice.model.PhysicianEmailOutreach;
import com.questdiagnostics.campaignservice.request.model.EmailTemplateElementResponse;
import com.questdiagnostics.campaignservice.request.model.PhysicianCampaignRequest;
import com.questdiagnostics.campaignservice.request.model.PhysicianUpdateCampaignRequest;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.PhysicianCampaignService;

@Controller
@RequestMapping(path = "/physicianCampaign")
public class PhysicianCampaignController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private PhysicianCampaignService physicianCampaignService;

	@PostMapping(value = "/create")
	public ResponseEntity<ResponseObjectModel> createPhysicianCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianCampaignRequest physicianCampaignRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.createPhysicianCampaign(physicianCampaignRequest);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/getCampaigns")
	public ResponseEntity<ResponseObjectModel> getPhysicianCampaigns(@RequestHeader HttpHeaders headers,
			@RequestParam(required = false) String campaignName) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.getPhysicianCampaigns(campaignName);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/getEligibleCampaigns")
	public ResponseEntity<PhysicianCampaignMasterList> getEligibleCampaigns(@RequestHeader HttpHeaders headers) {
		PhysicianCampaignMasterList  physicianCampaignMasterList = new PhysicianCampaignMasterList();
		try {
			physicianCampaignMasterList.setPhysicianCampaignMasterList(
					this.physicianCampaignService.getEligibleCampaigns());
			return new ResponseEntity<>(physicianCampaignMasterList, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(physicianCampaignMasterList, HttpStatus.BAD_REQUEST);
		}
	}
	

	@GetMapping(value = "/getCampaignsWithCreationIncomplete")
	public ResponseEntity<PhysicianCampaignMasterList> getCampaignsWithCreationIncomplete(@RequestHeader HttpHeaders headers) {
		PhysicianCampaignMasterList  physicianCampaignMasterList = new PhysicianCampaignMasterList();
		try {
			physicianCampaignMasterList.setPhysicianCampaignMasterList(
					this.physicianCampaignService.getCampaignsWithCreationIncomplete());
			return new ResponseEntity<>(physicianCampaignMasterList, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(physicianCampaignMasterList, HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping(value = "/update")
	public ResponseEntity<PhysicianCampaignMaster> updatePhysicianCampaignStatusId(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianUpdateCampaignRequest physicianUpdateCampaignRequest ) {
		PhysicianCampaignMaster physicianCampaignMaster = null;
		try {
			physicianCampaignMaster = this.physicianCampaignService.updatePhysicianCampaignStatusId(physicianUpdateCampaignRequest);
			return new ResponseEntity<>(physicianCampaignMaster, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(physicianCampaignMaster, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/emailOutreach/{campaignId}")
	public ResponseEntity<ResponseObjectModel> getPhysicianCampaignEmailOutreach(@RequestHeader HttpHeaders headers,
			@PathVariable Long campaignId) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.getPhysicianCampaignEmailOutreach(campaignId);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}
		
	// Email Template
			@GetMapping(value = "/emailTemplate")
			public ResponseEntity<EmailTemplateElementResponse> getEmailTemplates(@RequestHeader HttpHeaders headers) {
				EmailTemplateElementResponse elementResponse = new EmailTemplateElementResponse();
				try {

					List<EmailTemplateResponse> emailTemplateResponse = this.physicianCampaignService.getListOfEmail();
					EmailTemplateResponse[] elementRequest = new EmailTemplateResponse[emailTemplateResponse.size()];
					elementRequest = emailTemplateResponse.toArray(elementRequest);
					
					elementResponse.setElements(elementRequest);
						return new ResponseEntity<>(elementResponse, HttpStatus.OK);

				} catch (Exception httpClientErrorException) {
					logger.error("Error occured while processing GET List of Template from Eloqua : {} ",
							httpClientErrorException.getMessage());
					throw new ResponseStatusException(HttpStatus.NOT_FOUND, LoggingConstants.ERROR_EMAIL_GETTING,
							httpClientErrorException);
				}

			}
			
	@PostMapping(value = "/createEmailOutreach")
	public ResponseEntity<ResponseObjectModel> createPhysicianEmailOutreach(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianEmailOutreach physicianEmailOutreach) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.createPhysicianEmailOutreach(physicianEmailOutreach);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping(value = "/updateEmailOutreach")
	public ResponseEntity<ResponseObjectModel> updatePhysicianEmailOutreach(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianEmailOutreach physicianEmailOutreach) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.updatePhysicianEmailOutreach(physicianEmailOutreach);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(value = "/checkCampaignStatusByUserName")
	public ResponseEntity<ResponseObjectModel> checkCampaignStatusByUserName(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianCampaignRequest physicianCampaignRequest) {
		logger.info("inside campaign inprogress validation");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.getCampaignStatusByUserName(physicianCampaignRequest.getUserName());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/scheduleEmailOutreach")
	public ResponseEntity<ResponseObjectModel> schedulePhysicianEmailOutreach(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianEmailOutreach physicianEmailOutreach) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCampaignService.schedulePhysicianEmailOutreach(physicianEmailOutreach);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/getEmailOutreach/{campaignId}")
	public ResponseEntity<PhysicianEmailOutreach> getPhysicianEmailOutreach(@RequestHeader HttpHeaders headers,
			@PathVariable Long campaignId) {
		PhysicianEmailOutreach physicianEmailOutreach = new PhysicianEmailOutreach();
		try {
			physicianEmailOutreach = this.physicianCampaignService.getPhysicianEmailOutreach(campaignId);
			return new ResponseEntity<>(physicianEmailOutreach, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(physicianEmailOutreach, HttpStatus.BAD_REQUEST);
		}
	}

}
