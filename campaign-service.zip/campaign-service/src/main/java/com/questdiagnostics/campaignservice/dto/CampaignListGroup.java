package com.questdiagnostics.campaignservice.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value = Include.NON_NULL)
public class CampaignListGroup implements Serializable {


	private static final long serialVersionUID = 7929035088763565934L;

	private List<Object> deployed;
	
	private List<Object> scheduled;

	private List<Object> draft;

	private List<Object> ended;

	private List<Object> discarded;

	public List<Object> getDeployed() {
		return deployed;
	}

	public void setDeployed(List<Object> deployed) {
		this.deployed = deployed;
	}

	public List<Object> getScheduled() {
		return scheduled;
	}

	public void setScheduled(List<Object> scheduled) {
		this.scheduled = scheduled;
	}

	public List<Object> getDraft() {
		return draft;
	}

	public void setDraft(List<Object> draft) {
		this.draft = draft;
	}

	public List<Object> getEnded() {
		return ended;
	}

	public void setEnded(List<Object> ended) {
		this.ended = ended;
	}

	public List<Object> getDiscarded() {
		return discarded;
	}

	public void setDiscarded(List<Object> discarded) {
		this.discarded = discarded;
	}

}
