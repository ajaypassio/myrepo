package com.questdiagnostics.campaignservice.dto;

import java.io.Serializable;
import java.util.List;

import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;

public class CampaignListGroupMyQuest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7395478920491821817L;
	
	
	private List<CampaignMasterMyQuest> deployed;
	
	private List<CampaignMasterMyQuest> scheduled;

	private List<CampaignMasterMyQuest> draft;


	public List<CampaignMasterMyQuest> getDeployed() {
		return deployed;
	}


	public void setDeployed(List<CampaignMasterMyQuest> deployed) {
		this.deployed = deployed;
	}


	public List<CampaignMasterMyQuest> getScheduled() {
		return scheduled;
	}


	public void setScheduled(List<CampaignMasterMyQuest> scheduled) {
		this.scheduled = scheduled;
	}


	public List<CampaignMasterMyQuest> getDraft() {
		return draft;
	}


	public void setDraft(List<CampaignMasterMyQuest> draft) {
		this.draft = draft;
	}
	

}
