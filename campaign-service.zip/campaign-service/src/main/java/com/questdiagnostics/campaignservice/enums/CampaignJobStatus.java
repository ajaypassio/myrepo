/**
 * 
 */
package com.questdiagnostics.campaignservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author Ajay Kumar
 *
 */
public enum CampaignJobStatus {
	// Patient-list generation states
	/** The INITIATED. */
	Initiated("Initiated", 1),

	/** The FETCHED. */
	Fecthed("Fetched", 2),

	/** The SUCCESS. */
	Success("Success", 3),

	/** The FAILED. */
	Failed("Failed", 4),

	// Patient upload in Eloqua contacts states
	CONTACTS_UPLOAD_INITIATED("Contact_Upload_Initiated", 5),
	CONTACTS_UPLOAD_IN_PROGRESS("Contact_Upload_In_Progress", 6),
	CONTACTS_UPLOAD_COMPLETED("Contact_Upload_Completed", 7),
	CONTACTS_UPLOAD_FAILED("Contact_Upload_Failed", 8),

	// Contact Ids association with contact-list in Eloqua states
	CONTACT_LIST_UPLOAD_INITIATED("Contact_List_Upload_Initiated", 9),
	CONTACT_LIST_UPLOAD_IN_PROGRESS("Contact_List_Upload_In_Progress", 10),
	CONTACT_LIST_UPLOAD_COMPLETED("Contact_List_Upload_Completed", 11),
	CONTACT_LIST_UPLOAD_FAILED("Contact_List_Upload_Failed", 12),

	// Discard states for discarding a scheduled campaign
	DISCARD_INITIATED("Discard_Initiated", 13), 
	DISCARD_IN_PROGRESS("Discard_In_Progress", 14),
	DISCARD_FAILED("Discard_Failed", 15), 
	DISCARD_COMPLETED("Discard_Completed", 16),

	// patient propagation states for discard process
	PATIENT_PROPAGATION_INITATED("Patient_Propagation_Initiated", 17),
	PATIENT_PROPAGATION_IN_PROGRESS("Patient_Propagation_In_Progress", 18),
	PATIENT_PROPAGATION_FAILED("Patient_Propagation_Failed", 19),
	PATIENT_PROPAGATION_COMPLETED("Patient_Propagation_Completed", 20),

	// de-duplication states for schedule/deploy process
	DEDUPLICATION_FAILED("Deduplication_Failed", 21), 
	DEDUPLICATION_INITIATED("Deduplication_Initiated", 22),
	DEDUPLICATION_IN_PROGRESS("Deduplication_In_Progress", 23), 
	DEDUPLICATION_COMPLETED("Deduplication_Completed", 24),
	
	CONTACT_LIST_EMPTY("Contact_List_Empty", 28),
	
	SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED("Scheduled_Failed", 29);
	
	

	/** The value. */
	private final String type;
	private final Integer value;

	CampaignJobStatus(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static CampaignJobStatus getStatusOf(int value) {
		for (CampaignJobStatus status : CampaignJobStatus.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static CampaignJobStatus getStatusOf(String type) {
		for (CampaignJobStatus status : CampaignJobStatus.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}

}
