/**
 * 
 */
package com.questdiagnostics.campaignservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;


/**
 * @author Ajay Kumar
 *
 */
public enum CampaignMyQuestJobStatus {
	// Patient-list generation states
		/** The INITIATED. */
		Initiated("Initiated", 1),

		/** The FETCHED. */
		Fecthed("Fetched", 2),

		/** The SUCCESS. */
		Success("Success", 3),

		/** The FAILED. */
		Failed("Failed", 4),	

		/* This is for MyQuest Campaign job status */
		FEED_GENERATION_FAILED("FeedGeneration_Failed", 5), FEED_GENERATION_INITIATED("FeedGeneration_Initiated", 6),
		FEED_GENERATION_IN_PROGRESS("FeedGeneration_In_Progress", 7),
		FEED_GENERATION_COMPLETED("FeedGeneration_Completed", 8),
		FEED_GENERATION_PARTIAL_COMPLETED("FeedGenerationPartial_Completed", 9),
		FEED_GENERATION_PARTIAL_COMPLETED_REINITIATED("FeedGenerationPartialCompleted_reinitiated", 10);

		/** The value. */
		private final String type;
		private final Integer value;

		CampaignMyQuestJobStatus(String type, Integer value) {
			this.type = type;
			this.value = value;
		}

		/**
		 * @return the type
		 */
		@JsonValue
		public String getType() {
			return type;
		}

		/**
		 * @return the value
		 */
		@JsonValue
		public Integer getValue() {
			return value;
		}

		public static CampaignMyQuestJobStatus getStatusOf(int value) {
			for (CampaignMyQuestJobStatus status : CampaignMyQuestJobStatus.values()) {
				if (status.value == value)
					return status;
			}
			return null;
		}

		public static CampaignMyQuestJobStatus getStatusOf(String type) {
			for (CampaignMyQuestJobStatus status : CampaignMyQuestJobStatus.values()) {
				if (status.type.equalsIgnoreCase(type))
					return status;
			}
			return null;
		}

		@Override
		public String toString() {
			return this.type;
		}

}
