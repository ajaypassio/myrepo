/**
 * 
 */
package com.questdiagnostics.campaignservice.enums;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author Ajay Kumar
 *
 */
public enum ChannelType {

	/** The channel type. */
	ELOQUA("ELOQUA", 1), MYQUEST("MYQUEST", 2);

	/** The value. */
	private final String type;
	private final Integer value;

	ChannelType(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	@Override
	public String toString() {
		return this.type;
	}

	/**
	 * Gets the enum values.
	 *
	 * @return the enum values
	 */
	public static List<Integer> getEnumValues() {
		List<Integer> enumValues = new ArrayList<>();
		for (ChannelType e : ChannelType.values()) {
			enumValues.add(e.value);
		}
		return enumValues;
	}

	public static ChannelType getStatusOf(int value) {
		for (ChannelType status : ChannelType.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static ChannelType getStatusOf(String type) {
		for (ChannelType status : ChannelType.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

}
