/**
 * 
 */
package com.questdiagnostics.campaignservice.enums;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author Ajay Kumar
 *
 */
public enum EloquaCampaignStatus {

	/** The eloqua status. */
	DRAFT("DRAFT", 5), ACTIVE("ACTIVE", 6), SCHEDULED("SCHEDULED", 7), DELETED("DELETED", 8);

	/** The value. */
	private final String type;
	private final Integer value;

	EloquaCampaignStatus(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	@Override
	public String toString() {
		return this.type;
	}
	
	 /**
	   * Gets the enum values.
	   *
	   * @return the enum values
	   */
	  public static List<Integer> getEnumValues() {
	    List<Integer> enumValues = new ArrayList<>();
	    for (EloquaCampaignStatus e : EloquaCampaignStatus.values()) {
	      enumValues.add(e.value);
	    }
	    return enumValues;
	  }
	  
	  public static EloquaCampaignStatus getStatusOf(int value) {
			for (EloquaCampaignStatus status : EloquaCampaignStatus.values()) {
				if (status.value == value)
					return status;
			}
			return null;
		}

		public static EloquaCampaignStatus getStatusOf(String type) {
			for (EloquaCampaignStatus status : EloquaCampaignStatus.values()) {
				if (status.type.equalsIgnoreCase(type))
					return status;
			}
			return null;
		}

	  /**
	   * Gets the key for STATUS.
	   *
	   * @return the String
	   */
	/*
	 * public static Integer getValue(String key) { if
	 * (key.equals(EloquaCampaignStatus.DRAFT.name())) { return
	 * EloquaCampaignStatus.DRAFT.value; }
	 * 
	 * else if (value.equals(LEARNINGAPP_ITEM.value())) { return
	 * AssetType.LEARNINGAPP_ITEM; } return AssetType.valueOf(value); }
	 */
}
