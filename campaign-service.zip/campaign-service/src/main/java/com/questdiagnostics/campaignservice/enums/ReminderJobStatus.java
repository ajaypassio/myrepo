/**
 * 
 */
package com.questdiagnostics.campaignservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author Ajay Kumar
 *
 */
public enum ReminderJobStatus {


	SCHEDULAR_EMAIL_SENT("Schedular_Email_Sent", 1),

	REMINDER_ON("Reminder_On", 2),

	REMINDER_SENT("Reminder_Sent", 3);


	/** The value. */
	private final String type;
	private final Integer value;

	ReminderJobStatus(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static ReminderJobStatus getStatusOf(int value) {
		for (ReminderJobStatus status : ReminderJobStatus.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static ReminderJobStatus getStatusOf(String type) {
		for (ReminderJobStatus status : ReminderJobStatus.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}

}
