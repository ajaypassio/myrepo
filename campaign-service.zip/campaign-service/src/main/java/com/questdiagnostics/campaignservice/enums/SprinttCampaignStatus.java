/**
 * 
 */
package com.questdiagnostics.campaignservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @author Ajay Kumar
 *
 */
public enum SprinttCampaignStatus {

	/** The Sprintt status. */
	DRAFT("DRAFT", 1), SCHEDULED("SCHEDULED", 2), DEPLOYED("DEPLOYED", 3), DISCARDED("DISCARDED", 4),
	CLOSED("ENDED", 11), STOPPED("STOPPED", 12);

	/** The value. */
	private final String type;
	private final Integer value;

	SprinttCampaignStatus(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static SprinttCampaignStatus getStatusOf(int value) {
		for (SprinttCampaignStatus status : SprinttCampaignStatus.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static SprinttCampaignStatus getStatusOf(String type) {
		for (SprinttCampaignStatus status : SprinttCampaignStatus.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}
}
