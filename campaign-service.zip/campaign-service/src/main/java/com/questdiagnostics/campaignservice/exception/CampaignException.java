/**
 * 
 */
package com.questdiagnostics.campaignservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.questdiagnostics.campaignservice.constant.LoggingConstants;

/**
 * @author Ajay Kumar
 *
 */
@ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR, reason = LoggingConstants.ERROR_CAMPAIGN_CREATION)
public class CampaignException extends Exception {

	private static final long serialVersionUID = -765712965538368152L;

	public CampaignException(String message) {		
		super(LoggingConstants.ERROR_CAMPAIGN_CREATION);
	}

}
