package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class CampaignServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private ResponseObjectModel responseObject;

	
	public ResponseObjectModel getResponseObject() {
		return responseObject;
	}

	public CampaignServiceException() {
		super();
	}
	
	public CampaignServiceException(String message) {
		super(message);
	}

	public CampaignServiceException(String message, ResponseObjectModel resp) {
		super(message);
		responseObject = resp;
	}

	public CampaignServiceException(Throwable cause) {
		super(cause);
	}
	
	public CampaignServiceException(Throwable cause, ResponseObjectModel resp) {
		super(cause);
		responseObject = resp;
	}

	public CampaignServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public CampaignServiceException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause);
		responseObject = resp;
	}

	public CampaignServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
