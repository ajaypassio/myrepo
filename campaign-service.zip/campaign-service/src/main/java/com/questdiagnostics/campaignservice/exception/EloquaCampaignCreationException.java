package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EloquaCampaignCreationException extends EloquaCampaignException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EloquaCampaignCreationException() {
		// default constructor
	}

	public EloquaCampaignCreationException(String message) {
		super(message);
	}

	public EloquaCampaignCreationException(Throwable cause) {
		super(cause);
	}

	public EloquaCampaignCreationException(String message, Throwable cause) {
		super(message, cause);
	}

	public EloquaCampaignCreationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public EloquaCampaignCreationException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public EloquaCampaignCreationException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public EloquaCampaignCreationException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}
}
