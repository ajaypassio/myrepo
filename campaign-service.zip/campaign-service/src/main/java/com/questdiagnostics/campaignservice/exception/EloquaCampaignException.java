package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EloquaCampaignException extends EloquaException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EloquaCampaignException() {
		// default constructor
	}

	public EloquaCampaignException(String message) {
		super(message);
	}

	public EloquaCampaignException(Throwable cause) {
		super(cause);
	}

	public EloquaCampaignException(String message, Throwable cause) {
		super(message, cause);
	}

	public EloquaCampaignException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	public EloquaCampaignException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public EloquaCampaignException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public EloquaCampaignException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
