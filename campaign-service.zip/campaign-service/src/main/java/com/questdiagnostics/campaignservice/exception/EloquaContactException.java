package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EloquaContactException extends EloquaException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EloquaContactException() {
		// default constructor
	}

	public EloquaContactException(String message) {
		super(message);
	}

	public EloquaContactException(Throwable cause) {
		super(cause);
	}

	public EloquaContactException(String message, Throwable cause) {
		super(message, cause);
	}

	public EloquaContactException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	public EloquaContactException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public EloquaContactException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public EloquaContactException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
