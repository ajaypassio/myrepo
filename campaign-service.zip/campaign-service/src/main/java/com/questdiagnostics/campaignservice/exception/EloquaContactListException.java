package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EloquaContactListException extends EloquaException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EloquaContactListException() {
		super();
	}

	public EloquaContactListException(String message) {
		super(message);
	}

	public EloquaContactListException(Throwable cause) {
		super(cause);
	}

	public EloquaContactListException(String message, Throwable cause) {
		super(message, cause);
	}

	public EloquaContactListException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	public EloquaContactListException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public EloquaContactListException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public EloquaContactListException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
