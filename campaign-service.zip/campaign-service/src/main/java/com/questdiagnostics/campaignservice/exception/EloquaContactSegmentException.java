package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EloquaContactSegmentException extends EloquaException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EloquaContactSegmentException() {
		// default constructor
	}

	public EloquaContactSegmentException(String message) {
		super(message);
	}

	public EloquaContactSegmentException(Throwable cause) {
		super(cause);
	}

	public EloquaContactSegmentException(String message, Throwable cause) {
		super(message, cause);
	}

	public EloquaContactSegmentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	public EloquaContactSegmentException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public EloquaContactSegmentException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public EloquaContactSegmentException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
