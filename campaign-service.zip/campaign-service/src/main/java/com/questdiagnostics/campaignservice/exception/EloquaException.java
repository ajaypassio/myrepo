package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EloquaException extends CampaignServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EloquaException() {
		// default constructor
	}

	public EloquaException(String message) {
		super(message);
	}

	public EloquaException(Throwable cause) {
		super(cause);
	}

	public EloquaException(String message, Throwable cause) {
		super(message, cause);
	}

	public EloquaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	
	public EloquaException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public EloquaException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public EloquaException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
