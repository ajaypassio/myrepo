package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class FailedGuardException extends WorkflowEngineException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FailedGuardException() {
		// default constructor
	}

	public FailedGuardException(String message, Throwable cause) {
		super(message, cause);
	}

	public FailedGuardException(String message) {
		super(message);
	}
	
	public FailedGuardException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public FailedGuardException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public FailedGuardException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
