package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class InvalidTransitionException extends WorkflowEngineException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTransitionException() {
		// default constructor
	}

	public InvalidTransitionException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidTransitionException(String message) {
		super(message);
	}
	
	public InvalidTransitionException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public InvalidTransitionException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public InvalidTransitionException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}

}
