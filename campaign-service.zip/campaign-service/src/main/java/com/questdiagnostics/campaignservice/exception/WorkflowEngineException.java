package com.questdiagnostics.campaignservice.exception;

import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class WorkflowEngineException extends CampaignServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WorkflowEngineException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public WorkflowEngineException() {
		super();
	}

	public WorkflowEngineException(String message, Throwable cause) {
		super(message, cause);
	}

	public WorkflowEngineException(String message) {
		super(message);
	}
	
	public WorkflowEngineException(Throwable cause) {
		super(cause);
	}
	
	public WorkflowEngineException(String message, Throwable cause, ResponseObjectModel resp) {
		super(message, cause, resp);
	}

	public WorkflowEngineException(String message, ResponseObjectModel resp) {
		super(message, resp);
	}
	
	public WorkflowEngineException(Throwable cause, ResponseObjectModel resp) {
		super(cause, resp);
	}
}
