package com.questdiagnostics.campaignservice.helper;

import static com.questdiagnostics.campaignservice.request.model.CampaignElementOutputTerminalType.OUT;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementOutputTerminalType.NO;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementOutputTerminalType.YES;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_EMAIL;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_EMAIL_OPENED_RULE;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_EMAIL_CLICKTHROUGH_RULE;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_WAIT_ACTION;

import java.util.List;

import com.questdiagnostics.campaignservice.request.model.CampaignElement;
import com.questdiagnostics.campaignservice.request.model.CampaignElementOutputTerminal;
import com.questdiagnostics.campaignservice.request.model.CampaignEmail;
import com.questdiagnostics.campaignservice.request.model.CampaignEmailClickthroughRule;
import com.questdiagnostics.campaignservice.request.model.CampaignEmailOpenedRule;
import com.questdiagnostics.campaignservice.request.model.CampaignSegment;
import com.questdiagnostics.campaignservice.request.model.CampaignWaitAction;
import com.questdiagnostics.campaignservice.request.model.EloquaCampaignRequest;

public class CampaignElementHelper {

	private CampaignElementHelper() {
		throw new UnsupportedOperationException("Constructor not allowed.");
	}

	public static CampaignElement addSegment(String segmentId, EloquaCampaignRequest request) {
		CampaignSegment segment = new CampaignSegment();
		segment.setId("-1");
		segment.setSegmentId(segmentId);
		request.setLatestElementId(segment.getId());
		return segment;
	}

	@Deprecated
	public static CampaignElement addEmailSchedule(CampaignElement lastElement, long timeInUTC, long emailTemplateId,
			List<CampaignElement> campaignElements) {
		// add wait action followed by an email asset
		CampaignWaitAction wait = new CampaignWaitAction();
		// set output terminal for previous element
		// wait action will always follow either a segment audience or an email asset.
		CampaignElement previous = lastElement;
		CampaignElementOutputTerminal previousElementOutputTerminal = null;
		int prevOutputTerminalSize = previous.getOutputTerminalsSize();
		if (prevOutputTerminalSize == 0) {
			previousElementOutputTerminal = new CampaignElementOutputTerminal();
			if (previous instanceof CampaignSegment) {
				previousElementOutputTerminal.setId("-10011"); // start with an arbitrary -ve number
			} else {
				previousElementOutputTerminal
						.setId(String.valueOf(Long.valueOf(previous.getPrevious().getOutputTerminals(0).getId()) - 1));
			}
		} else {
			previousElementOutputTerminal = previous.getOutputTerminals(0);
			previousElementOutputTerminal
					.setId(String.valueOf(Long.valueOf(previousElementOutputTerminal.getId()) - 1));
		}
		previousElementOutputTerminal.setTerminalType(OUT.getTerminalType());
		previousElementOutputTerminal.setConnectedId(String.valueOf(Long.valueOf(previous.getId()) - 1));
		// this wait is for the scheduled email.
		previousElementOutputTerminal.setConnectedType(CAMPAIGN_WAIT_ACTION.getType());
		previous.addOutputTerminal(previousElementOutputTerminal);

		// create wait action
		wait.setId(String.valueOf(Long.valueOf(previous.getId()) - 1));
		wait.setWaitUntil(String.valueOf(timeInUTC / 1000));
		wait.setPrevious(lastElement);
		campaignElements.add(wait);
		previous = wait;

		// create email asset
		CampaignEmail email = new CampaignEmail();
		email.setId(String.valueOf(Long.valueOf(previous.getId()) - 1));
		email.setEmailId(String.valueOf(emailTemplateId));
		// connect the email to previous element's output terminal.
		CampaignElementOutputTerminal previousElementOutputTerminal2 = new CampaignElementOutputTerminal();
		previousElementOutputTerminal2.setId(String.valueOf(Long.valueOf(previousElementOutputTerminal.getId()) - 1));
		previousElementOutputTerminal2.setTerminalType(OUT.getTerminalType());
		previousElementOutputTerminal2.setConnectedId(String.valueOf(Long.valueOf(previous.getId()) - 1));
		previousElementOutputTerminal2.setConnectedType(CAMPAIGN_EMAIL.getType());
		previous.addOutputTerminal(previousElementOutputTerminal2);

		// link email to previous (wait) element
		email.setPrevious(previous);
		campaignElements.add(email);
		// update last element pointer
		lastElement = email;
		return lastElement;
	}

	private static CampaignElementOutputTerminal connectWaitWithPreviousElementOutputTerminal(String waitElementId,
			EloquaCampaignRequest request) {
		// set output terminal for previous element
		CampaignElementOutputTerminal previousElementOutputTerminal = new CampaignElementOutputTerminal();
		String outputTerminalId = null;
		int prevOutputTerminalSize = request.getLastElement().getOutputTerminalsSize();
		if (prevOutputTerminalSize == 0) {
			if (request.getLastElement() instanceof CampaignSegment) {
				outputTerminalId = "-10011"; // start with an arbitrary -ve number
			} else {
				outputTerminalId = String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1);
			}
		} else {
			outputTerminalId = String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1);
		}
		previousElementOutputTerminal.setId(outputTerminalId);
		previousElementOutputTerminal.setTerminalType(OUT.getTerminalType());
		previousElementOutputTerminal.setConnectedId(waitElementId);
		previousElementOutputTerminal.setConnectedType(CAMPAIGN_WAIT_ACTION.getType());
		request.getLastElement().addOutputTerminal(previousElementOutputTerminal);

		request.setLatestOutputTerminalId(outputTerminalId);

		return previousElementOutputTerminal;
	}

	public static CampaignElement addEmailSchedule(long timeInUTC, long emailTemplateId,
			EloquaCampaignRequest request) {
		CampaignWaitAction wait = new CampaignWaitAction();
		String waitElementId = String.valueOf(Long.valueOf(request.getLatestElementId()) - 1);

		CampaignElementOutputTerminal previousElementOutputTerminal = connectWaitWithPreviousElementOutputTerminal(
				waitElementId, request);

		request.setLatestElementId(waitElementId);
		request.setLatestOutputTerminalId(previousElementOutputTerminal.getId());

		wait.setId(waitElementId);
		wait.setWaitUntil(String.valueOf(timeInUTC / 1000));
		wait.setPrevious(request.getLastElement());
		request.addCampaignElement(wait);

		// create email action
		CampaignEmail email = new CampaignEmail();
		email.setId(String.valueOf(Long.valueOf(request.getLatestElementId()) - 1));
		email.setEmailId(String.valueOf(emailTemplateId));
		// connect the email to previous element's output terminal.
		CampaignElementOutputTerminal emailElementOutputTerminal = new CampaignElementOutputTerminal();
		emailElementOutputTerminal.setId(String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1));
		emailElementOutputTerminal.setTerminalType(OUT.getTerminalType());
		emailElementOutputTerminal.setConnectedId(email.getId());
		emailElementOutputTerminal.setConnectedType(CAMPAIGN_EMAIL.getType());

		wait.addOutputTerminal(emailElementOutputTerminal);
		request.setLatestElementId(email.getId());
		request.setLatestOutputTerminalId(emailElementOutputTerminal.getId());
		email.setPrevious(wait);
		request.addCampaignElement(email);

		return email;
	}

	private static CampaignEmailOpenedRule prepareReminderCommonElements(long timeInUTC, long emailTemplateId,
			EloquaCampaignRequest request) {
		CampaignWaitAction wait = new CampaignWaitAction();
		String waitElementId = String.valueOf(Long.valueOf(request.getLatestElementId()) - 1);
		request.setLatestElementId(waitElementId);

		CampaignElementOutputTerminal previousElementOutputTerminal = connectWaitWithPreviousElementOutputTerminal(
				waitElementId, request);
		request.setLatestOutputTerminalId(previousElementOutputTerminal.getId());

		wait.setId(waitElementId);
		wait.setWaitUntil(String.valueOf(timeInUTC / 1000));
		wait.setPrevious(request.getLastElement());
		request.addCampaignElement(wait);

		// create opened email rule
		CampaignEmailOpenedRule emailOpenedRule = new CampaignEmailOpenedRule();
		emailOpenedRule.setId(String.valueOf(Long.valueOf(request.getLatestElementId()) - 1));
		emailOpenedRule.setEmailId(String.valueOf(emailTemplateId));

		// connect with previous wait element
		CampaignElementOutputTerminal emailOpenedRuleElementOutputTerminal = new CampaignElementOutputTerminal();
		emailOpenedRuleElementOutputTerminal
				.setId(String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1));
		emailOpenedRuleElementOutputTerminal.setTerminalType(OUT.getTerminalType());
		emailOpenedRuleElementOutputTerminal.setConnectedId(emailOpenedRule.getId());
		emailOpenedRuleElementOutputTerminal.setConnectedType(CAMPAIGN_EMAIL_OPENED_RULE.getType());

		wait.addOutputTerminal(emailOpenedRuleElementOutputTerminal);
		request.setLatestElementId(emailOpenedRule.getId());
		request.setLatestOutputTerminalId(emailOpenedRuleElementOutputTerminal.getId());
		emailOpenedRule.setPrevious(wait);
		request.addCampaignElement(emailOpenedRule);

		return emailOpenedRule;
	}

	public static CampaignElement addNonOpenerReminder(long timeInUTC, long emailTemplateId,
			EloquaCampaignRequest request) {
		CampaignEmailOpenedRule emailOpenedRule = prepareReminderCommonElements(timeInUTC, emailTemplateId, request);

		// create email action
		CampaignEmail email = new CampaignEmail();
		email.setId(String.valueOf(Long.valueOf(request.getLatestElementId()) - 1));
		email.setEmailId(String.valueOf(emailTemplateId));
		// connect the email to previous element's output terminal.
		CampaignElementOutputTerminal emailElementOutputTerminal = new CampaignElementOutputTerminal();
		emailElementOutputTerminal.setId(String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1));
		emailElementOutputTerminal.setTerminalType(NO.getTerminalType());
		emailElementOutputTerminal.setConnectedId(email.getId());
		emailElementOutputTerminal.setConnectedType(CAMPAIGN_EMAIL.getType());

		emailOpenedRule.addOutputTerminal(emailElementOutputTerminal);
		request.setLatestElementId(email.getId());
		request.setLatestOutputTerminalId(emailElementOutputTerminal.getId());
		email.setPrevious(emailOpenedRule);
		request.addCampaignElement(email);

		return email;
	}

	public static CampaignEmailOpenedRule addNonClickedReminder(long timeInUTC, long emailTemplateId,
			EloquaCampaignRequest request) {
		CampaignEmailOpenedRule emailOpenedRule = prepareReminderCommonElements(timeInUTC, emailTemplateId, request);

		// create email clicked rule
		CampaignEmailClickthroughRule emailClickedRule = new CampaignEmailClickthroughRule();
		emailClickedRule.setId(String.valueOf(Long.valueOf(request.getLatestElementId()) - 1));
		emailClickedRule.setEmailId(String.valueOf(emailTemplateId));
		// connect email clicked rule to previous element's output terminal
		CampaignElementOutputTerminal emailClickedRuleElementOutputTerminal = new CampaignElementOutputTerminal();
		emailClickedRuleElementOutputTerminal
				.setId(String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1));
		emailClickedRuleElementOutputTerminal.setTerminalType(YES.getTerminalType());
		emailClickedRuleElementOutputTerminal.setConnectedId(emailClickedRule.getId());
		emailClickedRuleElementOutputTerminal.setConnectedType(CAMPAIGN_EMAIL_CLICKTHROUGH_RULE.getType());

		emailOpenedRule.addOutputTerminal(emailClickedRuleElementOutputTerminal);
		request.setLatestElementId(emailClickedRule.getId());
		request.setLatestOutputTerminalId(emailClickedRuleElementOutputTerminal.getId());
		emailClickedRule.setPrevious(emailOpenedRule);
		request.addCampaignElement(emailClickedRule);

		// create email action
		CampaignEmail email = new CampaignEmail();
		email.setId(String.valueOf(Long.valueOf(request.getLatestElementId()) - 1));
		email.setEmailId(String.valueOf(emailTemplateId));
		// connect the email to previous element's output terminal.
		CampaignElementOutputTerminal emailElementOutputTerminal = new CampaignElementOutputTerminal();
		emailElementOutputTerminal.setId(String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1));
		emailElementOutputTerminal.setTerminalType(NO.getTerminalType());
		emailElementOutputTerminal.setConnectedId(email.getId());
		emailElementOutputTerminal.setConnectedType(CAMPAIGN_EMAIL.getType());

		emailClickedRule.addOutputTerminal(emailElementOutputTerminal);
		request.setLatestElementId(email.getId());
		request.setLatestOutputTerminalId(emailElementOutputTerminal.getId());
		email.setPrevious(emailClickedRule);
		request.addCampaignElement(email);

		return emailOpenedRule;
	}

	public static CampaignElement addNonClickedNonOpenerReminder(long timeInUTC, long emailTemplateId,
			EloquaCampaignRequest request) {
		CampaignEmailOpenedRule emailOpenedRule = addNonClickedReminder(timeInUTC, emailTemplateId, request);
		// create email action
		CampaignEmail email = new CampaignEmail();
		email.setId(String.valueOf(Long.valueOf(request.getLatestElementId()) - 1));
		email.setEmailId(String.valueOf(emailTemplateId));

		// connect the email to previous element's output terminal.
		CampaignElementOutputTerminal emailElementOutputTerminal = new CampaignElementOutputTerminal();
		emailElementOutputTerminal.setId(String.valueOf(Long.valueOf(request.getLatestOutputTerminalId()) - 1));
		emailElementOutputTerminal.setTerminalType(NO.getTerminalType());
		emailElementOutputTerminal.setConnectedId(email.getId());
		emailElementOutputTerminal.setConnectedType(CAMPAIGN_EMAIL.getType());

		emailOpenedRule.addOutputTerminal(emailElementOutputTerminal);
		request.setLatestElementId(email.getId());
		request.setLatestOutputTerminalId(emailElementOutputTerminal.getId());
		email.setPrevious(emailOpenedRule);
		request.addCampaignElement(email);

		return email;
	}

}
