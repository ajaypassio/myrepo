package com.questdiagnostics.campaignservice.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.manager.ContactListManager;
import com.questdiagnostics.campaignservice.manager.ContactManager;
import com.questdiagnostics.campaignservice.manager.ContactSegmentManager;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.repository.ParticipantRepository;
import com.questdiagnostics.campaignservice.request.model.ContactListRequest;
import com.questdiagnostics.campaignservice.request.model.ContactRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElement;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElementList;
import com.questdiagnostics.campaignservice.response.model.ContactListResponse;
import com.questdiagnostics.campaignservice.response.model.ContactResponse;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentResponse;
import com.questdiagnostics.campaignservice.response.model.FieldValue;
import com.questdiagnostics.campaignservice.util.ParticipantEncryptionUtil;

@Component
public class ParticipantListHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ParticipantListHelper.class);

	@Autowired
	private ContactManager contactManager;

	@Autowired
	private ContactListManager contactListManager;

	@Autowired
	private ContactSegmentManager contactSegmentManager;

	@Autowired
	private ParticipantEncryptionUtil encryptionUtil;

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private ParticipantRepository participantRepository;
	
	@Value("${sprintt.token.id}")
	private String sprinttTokenId;

	public void createContactsInEloquaBackend(List<Object[]> patientList) throws EloquaException {
		LOGGER.info("Sprintt token Id = {}", sprinttTokenId);
		for (Object[] patientData : patientList) {
			String contactId = (String) patientData[3];
			//if (StringUtils.isEmpty(contactId)) {
				// a. create patient contacts in eloqua
				ContactRequest contactRequest = new ContactRequest();
				contactRequest.setFirstName((String) patientData[0]);
				contactRequest.setLastName((String) patientData[1]);
				contactRequest.setEmailAddress((String) patientData[2]);
				contactRequest.setId(contactId);
				Long participantId = Long.valueOf(String.valueOf(patientData[4]));
				contactRequest.setFieldValues(generateEncryptedParticipant(participantId));
				// handle no email addr case
				try {
					contactRequest.setId(contactManager.createContactInEloqua(contactRequest).getId());
					populateContactIdOfParticipant(contactRequest,participantId);
				} catch (Exception e) {
					if (e.getMessage().contains("409")) {
						LOGGER.warn("email address {} already exists in eloqua.", contactRequest.getEmailAddress());
						contactManager.getContactIdByEmailFromEloqua(contactRequest.getEmailAddress())
								.ifPresent(existingContact -> {
									contactRequest.setId(existingContact.getId());
									existingContact.getFieldValues().stream().forEach(fieldValue -> {
										if (fieldValue.getId().equals(sprinttTokenId)
												&& StringUtils.isEmpty(fieldValue.getValue())) {
											// call update eloqua
											try {
												contactRequest.setId(
														contactManager.updateContactInEloqua(contactRequest).getId());
											} catch (Exception exception) {
												LOGGER.error("error occured during updaing contact in eloqua : {} ",
														exception.getMessage());
											}
										}
									});
									populateContactIdOfParticipant(contactRequest,participantId);
								});
					}
				}
			//}

		}
	}

	private void populateContactIdOfParticipant(ContactRequest contactRequest,Long participantId) {
		/* Update participant table with eloqua contact id */
		participantRepository.findByParticipantIdXRef(participantId)
				.ifPresent(participant -> {
					participant.setContactId(contactRequest.getId());
					participant.setUpdatedOn(new Date());
					participantRepository.save(participant);
				});
	}

	public List<String> createContactsInEloqua(List<Object[]> patientList) throws EloquaException {
		LOGGER.info("Sprintt token Id = {}", sprinttTokenId);
		List<String> contactIds = new ArrayList<>();
		for (Object[] patientData : patientList) {
			// a. create patient contacts in eloqua
			ContactRequest contactRequest = new ContactRequest();
			contactRequest.setFirstName((String) patientData[0]);
			contactRequest.setLastName((String) patientData[1]);
			contactRequest.setEmailAddress((String) patientData[2]);
			contactRequest.setId((String) patientData[3]);
			Long participantId = Long.valueOf((String)(patientData[4]));
			contactRequest.setFieldValues(generateEncryptedParticipant(participantId));
			// handle no email addr case
			try {
				ContactResponse contactResp = contactManager.createContactInEloqua(contactRequest);
				contactIds.add(contactResp.getId());
			} catch (Exception e) {
				if (e.getMessage().contains("409")) {
					LOGGER.warn("email address {} already exists in eloqua.", contactRequest.getEmailAddress());
					contactManager.getContactIdByEmailFromEloqua(contactRequest.getEmailAddress())
							.ifPresent(existingContact -> {
								contactRequest.setId(existingContact.getId());
								existingContact.getFieldValues().stream().forEach(fieldValue -> {
									if (fieldValue.getId().equals(sprinttTokenId)
											&& StringUtils.isEmpty(fieldValue.getValue())) {
										// call update eloqua
										try {
											contactRequest.setId(
													contactManager.updateContactInEloqua(contactRequest).getId());
										} catch (Exception exception) {
											LOGGER.error("error occured during updaing contact in eloqua : {} ",
													exception.getMessage());
										}
									}
								});
								contactIds.add(existingContact.getId());

							});
				}
			}
		}
		return contactIds;
	}

	private List<FieldValue> generateEncryptedParticipant(Long participantId ) {
		LOGGER.info("Sprintt token Id = {}", sprinttTokenId);
		FieldValue fieldValue = new FieldValue();
		fieldValue.setType("FieldValue");
		fieldValue.setId(sprinttTokenId);
		fieldValue.setValue(encryptionUtil.encryptToBase64(String.valueOf(participantId)));
		List<FieldValue> fieldValueList = new ArrayList<>();
		fieldValueList.add(fieldValue);
		return fieldValueList;
	}

	public void prepareContactListAndUpdateContactSegment(List<String> contactIds, CampaignMaster campaignData)
			throws EloquaException {
		// b. create contact list with contact Ids from above call
		ContactListRequest contactListReq = new ContactListRequest();
		contactListReq.setName(campaignData.getTrialId() + "_" + campaignData.getCampaignId() + "_participants");
		contactListReq.setMembershipAdditions(contactIds);
		ContactListResponse contactListResponse = contactListManager.createContactListInEloqua(contactListReq);
		// c. update contact segment of the campaign with the above contact list
		ContactSegmentRequest contactSegmentReq = new ContactSegmentRequest();
		contactSegmentReq.setId(String.valueOf(campaignData.getSegmentId()));
		contactSegmentReq.setName(campaignData.getTrialId() + "_" + campaignData.getCampaignName());
		List<ContactSegmentRequestElement> elements = new ArrayList<>();
		ContactSegmentRequestElement element = new ContactSegmentRequestElement();
		ContactSegmentRequestElementList list = new ContactSegmentRequestElementList();
		list.setId(contactListResponse.getId());
		list.setName(contactListReq.getName());
		element.setList(list);
		elements.add(element);
		contactSegmentReq.setElements(elements);
		contactSegmentManager.updateContactSegmentInEloqua(contactSegmentReq);
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> getPatientListFromParticipantDB(CampaignMaster campaignData) {
		String table = CommonConstants.TRIAL_TABLE + campaignData.getTrialId();
		Query query = entityManager
				.createNativeQuery("SELECT P.FirstName,P.LastName,P.EmailAddress,P.ContactId,P.ParticipantIdXRef FROM "
						+ table + " AS PS INNER JOIN DBO.Participant P ON P.ParticipantIdXRef=PS.ParticipantId "
						+ " WHERE PS.SprinttCampaignId=? AND P.EmailAddress IS NOT NULL");
		query.setParameter(1, String.valueOf(campaignData.getSprinttCampaignId()));
		return query.getResultList();
	}

	public void populateContactIdInParticipantStudySiteTrial(List<Object[]> partcipantData,
			CampaignMaster campaignData) {
		String table = CommonConstants.TRIAL_TABLE + campaignData.getTrialId();
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		Query query = localEntityManager.createNativeQuery(new StringBuilder(" UPDATE p1 SET p1.ContactId=? from ")
				.append(table).append(" p1 ").append(" WHERE p1.ParticipantId=? AND p1.SprinttCampaignId=?")
				.append(" AND p1.ParticipantId not in ( select p2.ParticipantId from ").append(table).append(" p2 ")
				.append(" where p2.ParticipantId=?  and p2.ContactId is not null and ChannelId=1 )").toString());
		EntityTransaction transaction = null;
		for (Object[] participant : partcipantData) {
			try {
				transaction = localEntityManager.getTransaction();
				transaction.begin();
				String participantId = (String) participant[4];
				query.setParameter(1, (String) participant[3]);
				query.setParameter(2, participantId);
				query.setParameter(3, String.valueOf(campaignData.getSprinttCampaignId()));
				query.setParameter(4, participantId);
				query.executeUpdate();
				transaction.commit();
				LOGGER.info("Dedup applied for patient id {} and sprintt campaign id {} ", participantId,
						campaignData.getSprinttCampaignId());
			} catch (Exception e) {
				LOGGER.error("Exception occured in de dup logic {} ", e.getMessage());
				transaction.rollback();

			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<String> getContactIdsFromParticipantDB(CampaignMaster campaignData) {
		String table = CommonConstants.TRIAL_TABLE + campaignData.getTrialId();
		Query query = entityManager.createNativeQuery(new StringBuilder("SELECT PS.ContactId FROM ").append(table)
				.append(" AS PS where PS.SprinttCampaignId=?  AND PS.ContactId IS NOT NULL").toString());

		query.setParameter(1, String.valueOf(campaignData.getSprinttCampaignId()));
		return query.getResultList();
	}

	public void saveOrUpdateContactListInELoqua(CampaignMaster campaignData, List<String> contactIds,
			boolean isMembershipAddition) throws EloquaException {

		ContactSegmentResponse contactSegmentResponse = contactSegmentManager
				.getContactSegmentFromEloqua(String.valueOf(campaignData.getSegmentId()));

		ContactListRequest contactListRequest = new ContactListRequest();
		// List<String> contactIds = new ArrayList<>();
		// patientBatch.forEach(item -> contactIds.add(String.valueOf(item[0])));
		// update - add/delete contact IDs
		if (!CollectionUtils.isEmpty(contactSegmentResponse.getElements())) {
			contactListRequest.setId(contactSegmentResponse.getElements().get(0).getList().getId());
			contactListRequest.setName(contactSegmentResponse.getElements().get(0).getList().getName());
			if (isMembershipAddition) {
				contactListRequest.setMembershipAdditions(contactIds);
			} else {
				contactListRequest.setMembershipDeletions(contactIds);
			}
			ContactListResponse contactListResponse = contactListManager.updateContactListInEloqua(contactListRequest);

		} else {/**
				 * create contact list with contact IDs and update segment with the new contact
				 * list ID
				 */
			contactListRequest
					.setName(campaignData.getTrialId() + "_" + campaignData.getCampaignId() + "_participants");
			contactListRequest.setMembershipAdditions(contactIds);
			ContactListResponse contactListResponse = contactListManager.createContactListInEloqua(contactListRequest);

			ContactSegmentRequest contactSegmentReq = new ContactSegmentRequest();
			contactSegmentReq.setId(String.valueOf(campaignData.getSegmentId()));
			contactSegmentReq.setName(contactSegmentResponse.getName());
			List<ContactSegmentRequestElement> elements = new ArrayList<>();
			ContactSegmentRequestElement element = new ContactSegmentRequestElement();
			ContactSegmentRequestElementList list = new ContactSegmentRequestElementList();
			list.setId(contactListResponse.getId());
			list.setName(contactListRequest.getName());
			element.setList(list);
			elements.add(element);
			contactSegmentReq.setElements(elements);
			contactSegmentManager.updateContactSegmentInEloqua(contactSegmentReq);
		}
	}

}
