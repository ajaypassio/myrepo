package com.questdiagnostics.campaignservice.helper;

import org.springframework.http.HttpStatus;

import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.CampaignMyQuestJobStatus;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class ValidationHelper {

	private ValidationHelper() {
		throw new UnsupportedOperationException("Constructor not allowed.");
	}
	
	public static boolean verifyDraftCompletionStatus(CampaignMaster campaignData, ResponseObjectModel responseObject) {
		switch (CampaignJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case Initiated:
		case Fecthed:
		case Failed:
		case CONTACTS_UPLOAD_INITIATED:		
		case CONTACTS_UPLOAD_IN_PROGRESS:		
		case CONTACTS_UPLOAD_FAILED:			
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			return false;
		default:
			return true;
		}
	}
	
	public static boolean verifyScheduleCompletionStatus(CampaignMaster campaignData, ResponseObjectModel responseObject) {
		switch (CampaignJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case CONTACTS_UPLOAD_COMPLETED:
		case CONTACT_LIST_UPLOAD_INITIATED:
		case CONTACT_LIST_UPLOAD_FAILED:		
		case CONTACTS_UPLOAD_IN_PROGRESS:		
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			return false;
		default:
			return true;
		}
	}
	
	public static boolean verifyMyQuestScheduleCompletionStatus(CampaignMasterMyQuest campaignData, ResponseObjectModel responseObject) {
		switch (CampaignMyQuestJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case FEED_GENERATION_INITIATED:
		case FEED_GENERATION_PARTIAL_COMPLETED:
		case FEED_GENERATION_PARTIAL_COMPLETED_REINITIATED:				
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			return false;
		default:
			return true;
		}
	}
	public static boolean verifyDeployCompletionStatus(CampaignMaster campaignData, ResponseObjectModel responseObject) {
		return verifyScheduleCompletionStatus(campaignData, responseObject);
	}

	public static boolean verifyDiscardStatus(CampaignMaster campaignData, ResponseObjectModel responseObject) {
		switch (CampaignJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case DISCARD_INITIATED:
			responseObject.setMessage("Discard was initiated for this campaign and is pending for completion. Please try later.");
			return false;
		case DISCARD_IN_PROGRESS:
			responseObject.setMessage("Discard is still in-progress for this campaign. Please try again.");
			return false;
		case DISCARD_FAILED:
			responseObject.setMessage("Discard has failed for this campaign. Cannot reconsider.");
			return false;
		default:
			return true;
		}
	}

	public static boolean verifyPatientGenerationStatus(CampaignMaster campaignData, ResponseObjectModel responseObject,
			boolean now) {
		switch (CampaignJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case Initiated:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now already initiated" : "Schedule already initiated");
			return false;
		case Fecthed:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now is in-progress" : "Schedule upload is in-progress");
			return false;
		case Failed:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now has failed" : "Schedule upload has failed.");
			return false;
		default:
			return true;
		}
	}

	public static boolean verifyContactsUploadStatus(CampaignMaster campaignData, ResponseObjectModel responseObject,
			boolean now) {
		switch (CampaignJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case CONTACTS_UPLOAD_INITIATED:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now already initiated" : "Schedule already initiated");
			return false;
		case CONTACTS_UPLOAD_IN_PROGRESS:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now is in-progress" : "Schedule upload is in-progress");
			return false;
		case CONTACTS_UPLOAD_FAILED:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now has failed" : "Schedule upload has failed.");
			return false;
		default:
			return true;
		}
	}

	public static boolean verifyContactListUploadStatus(CampaignMaster campaignData, ResponseObjectModel responseObject,
			boolean now) {
		switch (CampaignJobStatus.getStatusOf(campaignData.getCampaignJobStatusId())) {
		case CONTACT_LIST_UPLOAD_INITIATED:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now already initiated" : "Schedule already initiated");
			return false;
		case CONTACT_LIST_UPLOAD_IN_PROGRESS:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now is in-progress" : "Schedule upload is in-progress");
			return false;
		case CONTACT_LIST_UPLOAD_FAILED:
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(now ? "Deploy now has failed" : "Schedule upload has failed.");
			return false;
		default:
			return true;
		}
	}
}
