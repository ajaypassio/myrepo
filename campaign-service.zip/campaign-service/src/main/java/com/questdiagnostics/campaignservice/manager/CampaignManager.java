package com.questdiagnostics.campaignservice.manager;

import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DRAFT;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.SCHEDULED;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.async.task.TaskContext;
import com.questdiagnostics.campaignservice.enums.EloquaCampaignStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.EloquaCampaignCreationException;
import com.questdiagnostics.campaignservice.exception.EloquaCampaignDeployException;
import com.questdiagnostics.campaignservice.exception.EloquaCampaignException;
import com.questdiagnostics.campaignservice.exception.EloquaCampaignUpdationException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.campaignservice.model.PhysicianEmailOutreach;
import com.questdiagnostics.campaignservice.repository.PhysicianCampaignMasterRepository;
import com.questdiagnostics.campaignservice.request.model.ContactListRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElement;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElementList;
import com.questdiagnostics.campaignservice.request.model.EloquaCampaignRequest;
import com.questdiagnostics.campaignservice.response.model.ContactListResponse;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentResponse;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentUpdateResponse;
import com.questdiagnostics.campaignservice.response.model.EloquaCampaignResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.PhysicianCampaignService;
import com.questdiagnostics.campaignservice.util.RESTUtils;

@Component
public class CampaignManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(CampaignManager.class);

	@Autowired
	private RESTUtils restUtils;

	@Autowired
	private ContactSegmentManager contactSegmentManager;
	
	@Autowired
	private ContactListManager contactListManager;
	
	@Autowired
	private PhysicianCampaignMasterRepository physicianCampaignMasterRepository;

	@Autowired
	private PhysicianCampaignService physicianCampaignService;

	private static final String URI_CONTEXT_PATH = "/2.0/assets/campaign";

	public EloquaCampaignResponse createCampaignInEloqua(CampaignMaster campaignData) throws EloquaException {
		LOGGER.debug("Create campaign request received for sprintt campaign Id {}.",
				campaignData.getSprinttCampaignId());

		// create segment request, execute and get segment Id
		EloquaCampaignResponse resp = null;
		String segmentId = null;
		try {
			segmentId = contactSegmentManager
					.createContactSegmentInEloqua(campaignData.getTrialId() + "_" + campaignData.getCampaignName())
					.getId();

			// capture segment Id
			campaignData.setSegmentId(Long.valueOf(segmentId));
			LOGGER.info("{} received as segment Id from eloqua for sprintt campaign Id {}", segmentId,
					campaignData.getSprinttCampaignId());

			// create campaign request using above segment id
			EloquaCampaignRequest campaignRequest = EloquaCampaignRequest.builder().name(campaignData.getCampaignName())
					.segment(segmentId).currentStatus(StringUtils.capitalize(DRAFT.getType().toLowerCase()))
					.permissions("Retrieve", "Delete", "Update", "Activate")
					.emailSchedule(campaignData.getSchedule(), campaignData.getEmailTemplate())
					.schedule(campaignData.getSchedule())
					.reminders(campaignData.getReminders(), campaignData.getEmailTemplate()).build();

			resp = restUtils
					.execute(campaignRequest, getURIContextPath(), HttpMethod.POST, EloquaCampaignResponse.class)
					.getBody();
		} catch (Exception e) {
			LOGGER.error("deleting segment {} for campaign {}.", segmentId, campaignData.getSprinttCampaignId());
			if (segmentId != null)
				contactSegmentManager.deleteContactSegmentFromEloqua(segmentId);
			throw new EloquaCampaignCreationException(e);
		}
		return resp;
	}

	public EloquaCampaignResponse getCampaignInEloqua(String eloquaCampaignId) throws EloquaException {
		LOGGER.debug("Get campaign request received for eloqua campaign Id {}.", eloquaCampaignId);
		EloquaCampaignResponse resp = null;
		try {
			resp = restUtils.execute(null, getURIContextPath() + "/" + eloquaCampaignId, HttpMethod.GET,
					EloquaCampaignResponse.class).getBody();
		} catch (Exception e) {
			throw new EloquaCampaignException(e);
		}
		return resp;
	}

	/**
	 * Edit a draft campaign - allows the user to edit a draft campaign attributes.
	 * 
	 * @param campaignData
	 * @return the eloqua's campaign response
	 * @throws JsonProcessingException
	 * @throws URISyntaxException
	 * @throws EloquaException
	 */
	public EloquaCampaignResponse updateDraftCampaignInEloqua(CampaignMaster campaignData) throws EloquaException {
		LOGGER.debug("Update sprintt campaign {} details for eloqua campaign Id {}.",
				campaignData.getSprinttCampaignId(), campaignData.getCampaignId());
		EloquaCampaignResponse response = null;
		try {
			// Create the request using request builder
			EloquaCampaignRequest campaignRequest = EloquaCampaignRequest.builder()
					.id(String.valueOf(campaignData.getCampaignId())).name(campaignData.getCampaignName())
					.segment(String.valueOf(campaignData.getSegmentId()))
					.currentStatus(StringUtils.capitalize(DRAFT.getType().toLowerCase()))
					.permissions("Retrieve", "Delete", "Update", "Activate")
					.emailSchedule(campaignData.getSchedule(), campaignData.getEmailTemplate())
					.schedule(campaignData.getSchedule())
					.reminders(campaignData.getReminders(), campaignData.getEmailTemplate()).build();

			response = restUtils.execute(campaignRequest, getURIContextPath() + "/" + campaignData.getCampaignId(),
					HttpMethod.PUT, EloquaCampaignResponse.class).getBody();
			LOGGER.info("Sprintt campaign {} updated for eloqua campaign Id {}", campaignData.getSprinttCampaignId(),
					campaignData.getCampaignId());
		} catch (Exception e) {
			throw new EloquaCampaignUpdationException(e);
		}
		return response;
	}

	/**
	 * Edit a scheduled campaign - allows the user to edit a scheduled campaign
	 * attributes in eloqua. THe campaign must be first moved to draft status in
	 * eloqua before updating and then back to schedule after update.
	 * 
	 * @param campaignData
	 * @return the eloqua's campaign response
	 * @throws JsonProcessingException
	 * @throws URISyntaxException
	 * @throws EloquaException
	 */
	public EloquaCampaignResponse updateScheduledCampaignInEloqua(CampaignMaster campaignData, ResponseObjectModel resp)
			throws EloquaException {
		LOGGER.debug("Update sprintt campaign {} details for eloqua campaign Id {}.",
				campaignData.getSprinttCampaignId(), campaignData.getCampaignId());

		SprinttCampaignStatus currentState = SprinttCampaignStatus.getStatusOf(campaignData.getCampaignStatusId());
		EloquaCampaignStatus eloquaCurrentState = null;

		EloquaCampaignResponse response = null;
		try {
			/**
			 * Deactivate the current campaign status from scheduled to draft in eloqua if
			 * not already deactivated. The campaign must be in scheduled in both sprintt
			 * and eloqua
			 */
			if (currentState == SCHEDULED) {
				eloquaCurrentState = EloquaCampaignStatus
						.getStatusOf(getCampaignInEloqua(campaignData.getCampaignId()).getCurrentStatus());
				if ((eloquaCurrentState == EloquaCampaignStatus.SCHEDULED)
						|| (eloquaCurrentState == EloquaCampaignStatus.DRAFT)) {
					deactivateCampaign(campaignData);
				} else {
					resp.setHttpStatus(HttpStatus.BAD_REQUEST);
					resp.setMessage("Campaign cannot be updated as it is already live in Eloqua.");
					throw new EloquaCampaignUpdationException("campaign " + campaignData.getSprinttCampaignId()
							+ " cannot be updated as it is not scheduled in eloqua.", resp);
				}
			}

			// Create the request using request builder
			EloquaCampaignRequest campaignRequest = EloquaCampaignRequest.builder()
					.id(String.valueOf(campaignData.getCampaignId())).name(campaignData.getCampaignName())
					.segment(String.valueOf(campaignData.getSegmentId()))
					.currentStatus(StringUtils.capitalize(DRAFT.getType().toLowerCase()))
					.permissions("Retrieve", "Delete", "Update", "Activate")
					.emailSchedule(campaignData.getSchedule(), campaignData.getEmailTemplate())
					.schedule(campaignData.getSchedule())
					.reminders(campaignData.getReminders(), campaignData.getEmailTemplate()).build();

			response = restUtils.execute(campaignRequest, getURIContextPath() + "/" + campaignData.getCampaignId(),
					HttpMethod.PUT, EloquaCampaignResponse.class).getBody();
			LOGGER.info("Sprintt campaign {} updated for eloqua campaign Id {}", campaignData.getSprinttCampaignId(),
					campaignData.getCampaignId());
			if (currentState == SCHEDULED && eloquaCurrentState == EloquaCampaignStatus.SCHEDULED) {
				scheduleCampaign(campaignData);
			}
		} catch (Exception e) {
			// If the campaign was scheduled in Eloqua restore it to previous schedule
			if (currentState == SCHEDULED && eloquaCurrentState == EloquaCampaignStatus.SCHEDULED) {
				scheduleCampaign(campaignData);
			}
			throw new EloquaCampaignUpdationException(e);
		}
		return response;
	}

	public EloquaCampaignResponse deactivateCampaign(CampaignMaster campaignData) throws EloquaException {
		LOGGER.debug("Deactivating sprintt campaign {} for eloqua campaign Id {}.", campaignData.getSprinttCampaignId(),
				campaignData.getCampaignId());
		try {
			EloquaCampaignResponse resp = restUtils
					.execute(null, getURIContextPath() + "/draft/" + campaignData.getCampaignId(), HttpMethod.POST,
							EloquaCampaignResponse.class)
					.getBody();
			LOGGER.info("Deactivated sprintt campaign {} for eloqua campaign Id {}.",
					campaignData.getSprinttCampaignId(), campaignData.getCampaignId());
			return resp;
		} catch (Exception e) {
			throw new EloquaCampaignUpdationException(e);
		}
	}

	public EloquaCampaignResponse activateCampaign(CampaignMaster campaignData) throws EloquaException {
		return scheduleCampaign(campaignData, true);
	}

	public EloquaCampaignResponse activateCampaign(CampaignMaster campaignData, TaskContext taskContext)
			throws EloquaException {
		return scheduleCampaign(campaignData, true, taskContext);
	}

	public EloquaCampaignResponse scheduleCampaign(CampaignMaster campaignData) throws EloquaException {
		return scheduleCampaign(campaignData, false);
	}

	public EloquaCampaignResponse scheduleCampaign(CampaignMaster campaignData, TaskContext taskContext)
			throws EloquaException {
		return scheduleCampaign(campaignData, false, taskContext);
	}

	public void deleteCampaign(String campaignId) throws EloquaCampaignUpdationException {
		LOGGER.debug("Deleting eloqua campaign {}", campaignId);
		// response type is null for DELETE method.
		try {
			restUtils.execute(null, getURIContextPath() + "/" + campaignId, HttpMethod.DELETE, null);
			LOGGER.info("Deleted eloqua campaign {}", campaignId);
		} catch (Exception e) {
			throw new EloquaCampaignUpdationException(e);
		}
	}

	private EloquaCampaignResponse scheduleCampaign(CampaignMaster campaignData, boolean now) throws EloquaException {
		LOGGER.debug(now ? "Activating" : "Scheduling" + "sprintt campaign {} for eloqua campaign Id {}.",
				campaignData.getSprinttCampaignId(), campaignData.getCampaignId());
		EloquaCampaignResponse resp = null;
		try {
			resp = restUtils.execute(null,
					getURIContextPath() + "/active/" + campaignData.getCampaignId() + "?scheduledFor="
							+ (now ? "now" : campaignData.getSchedule().getNormalizedStartDateTime().getTime() / 1000),
					HttpMethod.POST, EloquaCampaignResponse.class).getBody();

			LOGGER.info((now ? "Activated " : "Scheduled ") + "sprintt campaign {} for eloqua campaign Id {}.",
					campaignData.getSprinttCampaignId(), campaignData.getCampaignId());
		} catch (Exception e) {
			throw new EloquaCampaignDeployException(e);
		}
		return resp;
	}

	private EloquaCampaignResponse scheduleCampaign(CampaignMaster campaignData, boolean now, TaskContext taskContext)
			throws EloquaException {
		LOGGER.debug(now ? "Activating" : "Scheduling" + "sprintt campaign {} for eloqua campaign Id {}.",
				campaignData.getSprinttCampaignId(), campaignData.getCampaignId());
		EloquaCampaignResponse resp = null;
		try {
			resp = restUtils.execute(null,
					getURIContextPath() + "/active/" + campaignData.getCampaignId() + "?scheduledFor="
							+ (now ? "now" : campaignData.getSchedule().getNormalizedStartDateTime().getTime() / 1000),
					HttpMethod.POST, EloquaCampaignResponse.class).getBody();

			LOGGER.info((now ? "Activated " : "Scheduled ") + "sprintt campaign {} for eloqua campaign Id {}.",
					campaignData.getSprinttCampaignId(), campaignData.getCampaignId());
		} catch (Exception e) {
			if (e.getMessage().contains("400 Validation Error")) {
				// check if segment is empty or not
				ContactSegmentResponse contactSegmentResp = contactSegmentManager
						.getContactSegmentFromEloqua(String.valueOf(campaignData.getSegmentId()));
				if (CollectionUtils.isEmpty(contactSegmentResp.getElements())
						|| contactSegmentResp.getElements().get(0).getCount().equals("0")) {
					taskContext.setPatientListEmpty(true);
				} else {
					taskContext.setScheduleLapsed(true);
				}
			}
			throw new EloquaCampaignDeployException(e);
		}
		return resp;
	}

	public static String getURIContextPath() {
		return URI_CONTEXT_PATH;
	}
	
	public EloquaCampaignResponse createPhysicianCampaignInEloqua(PhysicianEmailOutreach physicianEmailOutreach)
			throws EloquaException {
		LOGGER.debug("Create physician campaign request received for sprintt campaign Id {}.",
				physicianEmailOutreach.getSprinttCampaignId());
		// create segment request, execute and get segment Id
		EloquaCampaignResponse resp = null;
		String segmentId = null;
		ContactListResponse contactListResponse = null;
		try {
			String segmentName = physicianEmailOutreach.getSprinttCampaignId() + "_segment_physician";
			segmentId = contactSegmentManager.createContactSegmentInEloqua(segmentName).getId();

			// capture segment Id
			physicianEmailOutreach.setSegmentId(Long.valueOf(segmentId));
			LOGGER.info("{} received as segment Id from eloqua for sprintt campaign Id {}", segmentId,
					physicianEmailOutreach.getSprinttCampaignId());

			// create campaign request using above segment id
			EloquaCampaignRequest campaignRequest = EloquaCampaignRequest.builder()
					.name(physicianEmailOutreach.getCampaignName()).segment(segmentId)
					.currentStatus(StringUtils.capitalize(DRAFT.getType().toLowerCase()))
					.permissions("Retrieve", "Delete", "Update", "Activate")
					.emailSchedule(physicianEmailOutreach.getSchedule(), physicianEmailOutreach.getEmailTemplate())
					.schedule(physicianEmailOutreach.getSchedule()).physicianReminders(
							physicianEmailOutreach.getReminders(), physicianEmailOutreach.getEmailTemplate())
					.build();

			ContactListRequest contactListRequest = new ContactListRequest();
			contactListRequest.setName(segmentId + "_contactList_physician");
			// contactListRequest.setMembershipAdditions(contactIds);
			contactListResponse = contactListManager.createContactListInEloqua(contactListRequest);
			
			ContactSegmentRequest contactSegmentReq = new ContactSegmentRequest();
			contactSegmentReq.setId(segmentId);
			contactSegmentReq.setName(segmentName);
			List<ContactSegmentRequestElement> elements = new ArrayList<>();
			ContactSegmentRequestElement element = new ContactSegmentRequestElement();
			ContactSegmentRequestElementList list = new ContactSegmentRequestElementList();
			list.setId(contactListResponse.getId());
			list.setName(contactListRequest.getName());
			element.setList(list);
			elements.add(element);
			contactSegmentReq.setElements(elements);
			contactSegmentManager.updateContactSegmentInEloqua(contactSegmentReq);

			resp = restUtils
					.execute(campaignRequest, getURIContextPath(), HttpMethod.POST, EloquaCampaignResponse.class)
					.getBody();
			resp.setContactListId(contactListResponse.getId());
			physicianEmailOutreach.setEloquaCampaignId(resp.getId());
			EloquaCampaignResponse campaignResponse = schedulePhysicianCampaign(physicianEmailOutreach, false);
			if(!ObjectUtils.isEmpty(campaignResponse))
			resp.setCurrentStatus(campaignResponse.getCurrentStatus());
		} catch (Exception e) {
			LOGGER.error("deleting segment {} for campaign {}.", segmentId,
					physicianEmailOutreach.getSprinttCampaignId());
			if (segmentId != null) {
				// ContactList delete opertaion
				if (null != contactListResponse && !StringUtils.isEmpty(contactListResponse.getId())) {
					contactListManager.deleteContactListFromEloqua(contactListResponse.getId());
				}
				contactSegmentManager.deleteContactSegmentFromEloqua(segmentId);
			}
			throw new EloquaCampaignCreationException(e);
		}
		return resp;
	}
	
	public EloquaCampaignResponse updateScheduledPhysicianCampaignInEloqua(PhysicianEmailOutreach physicianEmailOutreach, ResponseObjectModel resp)
			throws EloquaException {
		LOGGER.debug("Update physician sprintt campaign {} details for eloqua campaign Id {}.",
				physicianEmailOutreach.getSprinttCampaignId(), physicianEmailOutreach.getEloquaCampaignId());
		Optional<PhysicianCampaignMaster> physicianCampaignMaster = physicianCampaignMasterRepository
				.findById(physicianEmailOutreach.getSprinttCampaignId());
		physicianEmailOutreach.setCampaignName(physicianCampaignMaster.get().getCampaignName());
		/*SprinttCampaignStatus currentState = SprinttCampaignStatus
				.getStatusOf(physicianCampaignMaster.get().getCampaignStatusId());*/
		SprinttCampaignStatus currentState = SprinttCampaignStatus
				.getStatusOf(SCHEDULED.getValue());
		EloquaCampaignStatus eloquaCurrentState = null;

		EloquaCampaignResponse response = null;
		try {
			/**
			 * Deactivate the current campaign status from scheduled to draft in eloqua if
			 * not already deactivated. The campaign must be in scheduled in both sprintt
			 * and eloqua
			 */
			if (currentState == SCHEDULED) {
				eloquaCurrentState = EloquaCampaignStatus
						.getStatusOf(getCampaignInEloqua(physicianEmailOutreach.getEloquaCampaignId()).getCurrentStatus());
				if ((eloquaCurrentState == EloquaCampaignStatus.SCHEDULED)
						|| (eloquaCurrentState == EloquaCampaignStatus.DRAFT)) {
					deactivatePhysicianCampaign(physicianEmailOutreach);
				} else {
					resp.setHttpStatus(HttpStatus.BAD_REQUEST);
					resp.setMessage("Campaign cannot be updated as it is already live in Eloqua.");
					throw new EloquaCampaignUpdationException("campaign " + physicianEmailOutreach.getSprinttCampaignId()
							+ " cannot be updated as it is not scheduled in eloqua.", resp);
				}
			}

			// Create the request using request builder
			EloquaCampaignRequest campaignRequest = EloquaCampaignRequest.builder()
					.id(String.valueOf(physicianEmailOutreach.getEloquaCampaignId())).name(physicianEmailOutreach.getCampaignName())
					.segment(String.valueOf(physicianEmailOutreach.getSegmentId()))
					.currentStatus(StringUtils.capitalize(DRAFT.getType().toLowerCase()))
					.permissions("Retrieve", "Delete", "Update", "Activate")
					.emailSchedule(physicianEmailOutreach.getSchedule(), physicianEmailOutreach.getEmailTemplate())
					.schedule(physicianEmailOutreach.getSchedule())
					.physicianReminders(physicianEmailOutreach.getReminders(), physicianEmailOutreach.getEmailTemplate()).build();

			response = restUtils.execute(campaignRequest, getURIContextPath() + "/" + physicianEmailOutreach.getEloquaCampaignId(),
					HttpMethod.PUT, EloquaCampaignResponse.class).getBody();
			LOGGER.info("Sprintt campaign {} updated for eloqua campaign Id {}", physicianEmailOutreach.getSprinttCampaignId(),
					physicianEmailOutreach.getEloquaCampaignId());
			if (currentState == SCHEDULED && eloquaCurrentState == EloquaCampaignStatus.SCHEDULED) {
				schedulePhysicianCampaign(physicianEmailOutreach);
			}
		} catch (Exception e) {
			// If the campaign was scheduled in Eloqua restore it to previous schedule
			if (currentState == SCHEDULED && eloquaCurrentState == EloquaCampaignStatus.SCHEDULED) {
				schedulePhysicianCampaign(physicianEmailOutreach);
			}
			throw new EloquaCampaignUpdationException(e);
		}
		return response;
	}
	
	public EloquaCampaignResponse deactivatePhysicianCampaign(PhysicianEmailOutreach physicianEmailOutreach) throws EloquaException {
		LOGGER.debug("Deactivating physician sprintt campaign {} for eloqua campaign Id {}.", physicianEmailOutreach.getSprinttCampaignId(),
				physicianEmailOutreach.getEloquaCampaignId());
		try {
			EloquaCampaignResponse resp = restUtils
					.execute(null, getURIContextPath() + "/draft/" + physicianEmailOutreach.getEloquaCampaignId(), HttpMethod.POST,
							EloquaCampaignResponse.class)
					.getBody();
			LOGGER.info("Deactivated sprintt campaign {} for eloqua campaign Id {}.",
					physicianEmailOutreach.getSprinttCampaignId(), physicianEmailOutreach.getEloquaCampaignId());
			return resp;
		} catch (Exception e) {
			throw new EloquaCampaignUpdationException(e);
		}
	}
	
	private EloquaCampaignResponse schedulePhysicianCampaign(PhysicianEmailOutreach physicianEmailOutreach, boolean now) throws EloquaException {
		LOGGER.info(now ? "Activating" : "Scheduling" + "sprintt campaign {} for eloqua campaign Id {}.",
				physicianEmailOutreach.getSprinttCampaignId(), physicianEmailOutreach.getEloquaCampaignId());
		EloquaCampaignResponse resp = null;
		try {
			resp = restUtils.execute(null,
					getURIContextPath() + "/active/" + physicianEmailOutreach.getEloquaCampaignId() + "?scheduledFor="
							+ (now ? "now" : physicianEmailOutreach.getSchedule().getNormalizedStartDateTime().getTime() / 1000),
					HttpMethod.POST, EloquaCampaignResponse.class).getBody();

			LOGGER.info((now ? "Activated " : "Scheduled ") + "sprintt campaign {} for eloqua campaign Id {}.",
					physicianEmailOutreach.getSprinttCampaignId(), physicianEmailOutreach.getEloquaCampaignId());
		} catch (Exception e) {
			// throw new EloquaCampaignDeployException(e);
			LOGGER.error("Exception occured during scheduling sprintt physician campaign {} for eloqua campaign Id {}.",
					physicianEmailOutreach.getSprinttCampaignId(), physicianEmailOutreach.getEloquaCampaignId());
		}
		return resp;
	}
	
	public EloquaCampaignResponse schedulePhysicianCampaign(PhysicianEmailOutreach physicianEmailOutreach)
			throws EloquaException {
		return schedulePhysicianCampaign(physicianEmailOutreach, false);
	}
}
