package com.questdiagnostics.campaignservice.manager;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.exception.EloquaContactListException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.request.model.ContactListRequest;
import com.questdiagnostics.campaignservice.response.model.ContactListResponse;
import com.questdiagnostics.campaignservice.response.model.ContactListSearchResponse;
import com.questdiagnostics.campaignservice.util.RESTUtils;

@Component
public class ContactListManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(ContactListManager.class);

	// TODO - load from configuration
	private static final String URI_CONTEXT_PATH_1 = "/1.0/assets/contact/list";
	private static final String URI_CONTEXT_PATH_2 = "/1.0/data/contacts";
	private static final String URI_CONTEXT_PATH_3 = "/1.0/assets/contact/lists";

	@Autowired
	private RESTUtils restUtils;

	public static String getURIContextPath(int num) {
		switch (num) {
		case 1:
			return URI_CONTEXT_PATH_1;
		case 2:
			return URI_CONTEXT_PATH_2;
		case 3:
			return URI_CONTEXT_PATH_3;
		default:
			return URI_CONTEXT_PATH_1;
		}
	}

	public ContactListResponse createContactListInEloqua(ContactListRequest contactList) throws EloquaException {
		LOGGER.debug("Create contact list request received {}.", contactList);
		ContactListResponse resp = null;
		try {
			resp = restUtils.execute(contactList, getURIContextPath(1), HttpMethod.POST, ContactListResponse.class)
					.getBody();
			LOGGER.info("Created contact list {} in eloqua with contact list Id {}", contactList, resp.getId());
		} catch (Exception e) {
			if (e.getMessage().contains("409 Conflicts Found")) {
				Optional<String> contactListIdOpt = getContactListIdByAttributeFromEloqua(contactList.getName(),
						"name");
				if (contactListIdOpt.isPresent()) {
					return getContactListFromEloqua(contactListIdOpt.get());
				}
			}
			throw new EloquaContactListException(e);
		}
		return resp;
	}

	public ContactListResponse updateContactListInEloqua(ContactListRequest contactList) throws EloquaException {
		LOGGER.debug("Create contact list request received {}.", contactList);
		ContactListResponse resp = null;
		try {
			resp = restUtils.execute(contactList, getURIContextPath(1) + "/" + contactList.getId(), HttpMethod.PUT,
					ContactListResponse.class).getBody();
			LOGGER.info("Updated contact list {} in eloqua with contact list Id {}", contactList, resp.getId());
		} catch (Exception e) {
			throw new EloquaContactListException(e);
		}
		return resp;
	}

	public ContactListResponse getContactListFromEloqua(String contactListId) throws EloquaException {
		LOGGER.debug("Get contact list request from eloqua for contact list Id {}.", contactListId);
		ContactListResponse resp = null;
		try {
			resp = restUtils.execute(null, getURIContextPath(1) + "/" + contactListId, HttpMethod.GET,
					ContactListResponse.class).getBody();
		} catch (Exception e) {
			throw new EloquaContactListException(e);
		}
		return resp;
	}

	public Optional<String> getContactListIdByAttributeFromEloqua(String value, String key) throws EloquaException {
		LOGGER.debug("Get contact list request from eloqua for contact list {} having value = {}.", key, value);
		ContactListSearchResponse resp = null;
		try {
			resp = restUtils.execute(null, getURIContextPath(3) + "?search=" + key + "=" + value, HttpMethod.GET,
					ContactListSearchResponse.class).getBody();
			if (!CollectionUtils.isEmpty(resp.getElements())) {
				return Optional.ofNullable(resp.getElements().get(0).getId());
			}
		} catch (Exception e) {
			throw new EloquaContactListException(e);
		}
		return Optional.ofNullable(null);
	}

	public ContactListResponse deleteContactListFromEloqua(String contactListId) throws EloquaException {
		LOGGER.debug("Delete contact list request received for eloqua for contact list Id {}.", contactListId);
		ContactListResponse resp = null;
		try {
			resp = restUtils.execute(null, getURIContextPath(1) + "/" + contactListId, HttpMethod.DELETE,
					ContactListResponse.class).getBody();
			LOGGER.debug("Deleted contact list Id {} in eloqua.", contactListId);
		} catch (Exception e) {
			throw new EloquaContactListException(e);
		}
		return resp;
	}

}
