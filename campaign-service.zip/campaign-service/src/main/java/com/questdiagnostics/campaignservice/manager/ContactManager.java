package com.questdiagnostics.campaignservice.manager;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.exception.EloquaContactException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.request.model.ContactRequest;
import com.questdiagnostics.campaignservice.response.model.ContactListSearchResponse;
import com.questdiagnostics.campaignservice.response.model.ContactListSearchResponseElement;
import com.questdiagnostics.campaignservice.response.model.ContactResponse;
import com.questdiagnostics.campaignservice.util.RESTUtils;

@Component
public class ContactManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(ContactManager.class);

	private static final String URI_CONTEXT_PATH = "/1.0/data/contact";
	private static final String URI_CONTEXT_PATH_1 = "/1.0/data/contacts";

	@Autowired
	private RESTUtils restUtils;

	public static String getURIContextPath() {
		return URI_CONTEXT_PATH;
	}

	public ContactResponse createContactInEloqua(ContactRequest contact) throws EloquaException {
		LOGGER.debug("Create contact request received {}.", contact);
		ContactResponse resp = null;
		try {
			resp = restUtils.executeContactUpload(contact, getURIContextPath(), HttpMethod.POST, ContactResponse.class).getBody();
			LOGGER.debug("Created contact in eloqua with contact {} and contact Id {}", contact, resp.getId());
		} catch (Exception e) {
			throw new EloquaContactException(e);
		}
		return resp;
	}

	public ContactResponse getContactFromEloqua(String contactId) throws EloquaException {
		LOGGER.debug("Get contact request from eloqua for contact Id {}.", contactId);
		ContactResponse resp = null;
		try {
			resp = restUtils.execute(null, getURIContextPath() + "/" + contactId, HttpMethod.GET, ContactResponse.class)
					.getBody();
		} catch (Exception e) {
			throw new EloquaContactException(e);
		}
		return resp;
	}

	public ContactResponse deleteContactFromEloqua(String contactId) throws EloquaException {
		LOGGER.debug("Delete contact request received for eloqua for contact Id {}.", contactId);
		ContactResponse resp = null;
		try {
			resp = restUtils
					.execute(null, getURIContextPath() + "/" + contactId, HttpMethod.DELETE, ContactResponse.class)
					.getBody();
			LOGGER.debug("Deleted contact Id {} for eloqua.", contactId);
		} catch (Exception e) {
			throw new EloquaContactException(e);
		}
		return resp;
	}
	public Optional<ContactListSearchResponseElement> getContactIdByEmailFromEloqua(String emailAddr) throws EloquaException {
		LOGGER.debug("Get contactId request from eloqua for email {}", emailAddr);
		try {
			ContactListSearchResponse resp = restUtils
					.execute(null, URI_CONTEXT_PATH_1 + "?depth=complete&search=emailAddress=" + emailAddr, HttpMethod.GET,
							ContactListSearchResponse.class)
					.getBody();
			if (!CollectionUtils.isEmpty(resp.getElements()))
				return Optional.of(resp.getElements().get(0));
		} catch (Exception e) {
			LOGGER.error("Caught exception while trying to get contactId from eloqua for emailAddr {} - {}", emailAddr,
					e);
		}
		return Optional.of(null);
	}
	public ContactResponse updateContactInEloqua(ContactRequest contact) throws EloquaException {
		LOGGER.debug("Create contact request received {}.", contact);
		ContactResponse resp = null;
		try {
			resp = restUtils.execute(contact, getURIContextPath() + "/" + contact.getId(), HttpMethod.PUT,
					ContactResponse.class).getBody();
			LOGGER.debug("Updated contact in eloqua with contact {} and contact Id {}", contact, resp.getId());
		} catch (Exception e) {
			throw new EloquaContactException(e);
		}
		return resp;
	}
}
