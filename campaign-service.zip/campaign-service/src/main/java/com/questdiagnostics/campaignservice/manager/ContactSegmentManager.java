package com.questdiagnostics.campaignservice.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.exception.EloquaContactSegmentException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequest;
import com.questdiagnostics.campaignservice.request.model.EloquaSegmentRequest;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentResponse;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentUpdateResponse;
import com.questdiagnostics.campaignservice.util.RESTUtils;

@Component
public class ContactSegmentManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(ContactSegmentManager.class);

	@Autowired
	private RESTUtils restUtils;

	// TODO - load from configuration
	private static final String URI_CONTEXT_PATH_2 = "/2.0/assets/contact/segment";
	private static final String URI_CONTEXT_PATH_1 = "/1.0/assets/contact/segment";

	public ContactSegmentResponse createContactSegmentInEloqua(String segmentName) throws EloquaException {
		LOGGER.debug("Create segment request received with segment name {}.", segmentName);
		ContactSegmentResponse resp = null;
		try {
			resp = restUtils.execute(new EloquaSegmentRequest(segmentName), getURIContextPath(2), HttpMethod.POST,
					ContactSegmentResponse.class).getBody();
			LOGGER.info("Created segment in eloqua with segment name {} and segment Id {}", segmentName, resp.getId());
		} catch (Exception e) {
			throw new EloquaContactSegmentException(e);
		}
		return resp;
	}

	public  ContactSegmentResponse createContactSegmentInEloqua(ContactSegmentRequest request)
			throws EloquaException {
		LOGGER.debug("Create contact segment request received with segment name {}.", request.getName());
		ContactSegmentResponse resp = null;
		try {
			resp = restUtils.execute(request, getURIContextPath(2), HttpMethod.POST, ContactSegmentResponse.class)
					.getBody();
			LOGGER.info("Created segment in eloqua with segment name {} and segment Id {}", request.getName(),
					resp.getId());
		} catch (Exception e) {
			throw new EloquaContactSegmentException(e);
		}
		return resp;
	}

	public ContactSegmentUpdateResponse updateContactSegmentInEloqua(ContactSegmentRequest request)
			throws EloquaException {
		LOGGER.debug("Update contact segment request received with segment name {}.", request.getName());
		ContactSegmentUpdateResponse resp = null;
		try {
			resp = restUtils.execute(request, getURIContextPath(1) + "/" + request.getId(), HttpMethod.PUT,
					ContactSegmentUpdateResponse.class).getBody();
			LOGGER.info("Updated segment in eloqua with segment name {} and segment Id {}", request.getName(),
					resp.getId());
		} catch (Exception e) {
			throw new EloquaContactSegmentException(e);
		}
		return resp;
	}

	public ContactSegmentResponse getContactSegmentFromEloqua(String segmentId) throws EloquaException {
		LOGGER.debug("Get segment request from eloqua for segment Id {}.", segmentId);
		ContactSegmentResponse resp = null;
		try {
			resp = restUtils
					.execute(null, getURIContextPath(2) + "/" + segmentId, HttpMethod.GET, ContactSegmentResponse.class)
					.getBody();
		} catch (Exception e) {
			throw new EloquaContactSegmentException(e);
		}
		return resp;
	}
	
	public String getContactListIdForContactSegment(String segmentId) throws EloquaException {
		ContactSegmentResponse response = getContactSegmentFromEloqua(segmentId);
		if(!CollectionUtils.isEmpty(response.getElements())) {
			return response.getElements().get(0).getList().getId();
		}
		return null;
	}

	public ContactSegmentResponse deleteContactSegmentFromEloqua(String segmentId) throws EloquaException {
		LOGGER.debug("Delete segment request received for eloqua for segment Id {}.", segmentId);
		ContactSegmentResponse resp = null;
		try {
			resp = restUtils.execute(null, getURIContextPath(2) + "/" + segmentId, HttpMethod.DELETE,
					ContactSegmentResponse.class).getBody();
			LOGGER.debug("Deleted segment Id {} for eloqua.", segmentId);
		} catch (Exception e) {
			throw new EloquaContactSegmentException(e);
		}
		return resp;
	}

	public static String getURIContextPath(int num) {
		switch (num) {
		case 1:
			return URI_CONTEXT_PATH_1;
		case 2:
			return URI_CONTEXT_PATH_2;
		default:
			return URI_CONTEXT_PATH_2;
		}
	}
}
