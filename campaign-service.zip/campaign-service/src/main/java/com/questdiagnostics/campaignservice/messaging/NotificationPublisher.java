package com.questdiagnostics.campaignservice.messaging;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.questdiagnostics.campaignservice.messaging.models.NotificationPayload;
import com.questdiagnostics.campaignservice.util.AsyncUtil;

@Component
public class NotificationPublisher {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${notification.sprintt.azure.storage.queuename}")
	String notificationQueueName;
	

	@Autowired
	private AsyncUtil asyncUtil;
	
	public void publishNotification( NotificationPayload notificationPayload) {
		logger.info("Notification started for the Campaign name:{} and user: {} ", notificationPayload.getName(),
				notificationPayload.getUserid());
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		try {
			storageAccount = CloudStorageAccount.parse(asyncUtil.getNotificationStorageConnectionString());
			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(notificationQueueName);
			queue.createIfNotExists();
			ObjectMapper mapper = new ObjectMapper();
			queue.addMessage(new CloudQueueMessage(mapper.writeValueAsString(notificationPayload)));
			logger.info("Notification completed for the Campaign name:{} and user: {} ",notificationPayload.getName(),
					notificationPayload.getUserid());
		} catch (URISyntaxException | StorageException | InvalidKeyException | JsonProcessingException exception) {
			logger.error("Notification processing failed : {} ", exception);
		}
	}
}
