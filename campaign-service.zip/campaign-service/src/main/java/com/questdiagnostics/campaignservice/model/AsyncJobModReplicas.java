package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "AsyncJobModReplicas")
public class AsyncJobModReplicas implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id")
	private Long id;
	
	@Column(name = "ModValue", nullable = false)
	private int modValue;

	@Column(name = "CreatedOn", nullable = false, updatable = false)
	private Date createdOn = new Date();
	
	@Column(name = "UpdatedOn", nullable = false)
	private Date updatedOn;
	
	@Column(name = "ForceMod", nullable = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean forceMod;
	
	@Column(name = "ServiceName", nullable = false)
	private String serviceName;

	public int getModValue() {
		return modValue;
	}

	public void setModValue(int modValue) {
		this.modValue = modValue;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public boolean isForceMod() {
		return forceMod;
	}

	public void setForceMod(boolean forceMod) {
		this.forceMod = forceMod;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Long getId() {
		return id;
	}

	public Date getCreatedOn() {
		return createdOn;
	}
}
