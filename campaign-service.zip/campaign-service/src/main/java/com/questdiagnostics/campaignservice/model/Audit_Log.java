package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Audit_Log")
public class Audit_Log implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id", nullable = false)
	private Long id;
	
	
	@Column(name = "EntityName", nullable = true)
	private String entityName;
	
	@Column(name = "ActionPerformed", nullable = true)
	private String actionPerformed;
	
	@Column(name = "EntityContent", nullable = true)
	private String entityContent;
	
	@Column(name = "ModifiedBy", nullable = true)
	private Long modifiedBy;
	
	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getActionPerformed() {
		return actionPerformed;
	}

	public void setActionPerformed(String actionPerformed) {
		this.actionPerformed = actionPerformed;
	}

	public String getEntityContent() {
		return entityContent;
	}

	public void setEntityContent(String entityContent) {
		this.entityContent = entityContent;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "Audit_Log [id=" + id + ", entityName=" + entityName + ", actionPerformed=" + actionPerformed
				+ ", entityContent=" + entityContent + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate
				+ "]";
	}
	
	
	
	
	
	
	
	
	
}