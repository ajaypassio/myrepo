package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "CampaignAsyncJob")
public final class CampaignAsyncJob implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "JobId", nullable = false)
	@JsonProperty("jobId")
	private Long id;

	@Column(name = "JobStatus", nullable = false)
	@JsonProperty("jobStatus")
	private int jobStatus;
	
	@Column(name = "JobType", nullable = false)
	@JsonProperty("jobType")
	private int jobType;

	@Column(name = "CampaignId", nullable = false, updatable = false)
	@JsonProperty("campaignId")
	private long campaignId;

	@Column(name = "TrialId", nullable = false, updatable = false)
	@JsonProperty("trialId")
	private long trialId;

	@Column(name = "StartPos", nullable = false)
	@JsonIgnore
	private long startPos;

	@Column(name = "EndPos", nullable = false)
	@JsonIgnore
	private long endPos;

	@Column(name = "TotalRecordsProcessed", nullable = false)
	@JsonProperty("recordsProcessed")
	private int totalRecordsProcessed;

	@Column(name = "BatchSize", nullable = false)
	@JsonProperty("batchSize")
	private int batchSize;

	@Column(name = "NoOfBatches", nullable = false)
	@JsonProperty("batchesProcessed")
	private int numberOfBatches;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "campaignAsyncJob")
	@JsonProperty("batches")
	private List<CampaignAsyncJobBatch> jobBatchList;

	@Column(name = "CreatedBy")
	@JsonIgnore
	private String createdBy;

	@Column(name = "CreatedOn", nullable = false, updatable = false)
	@JsonIgnore
	private Date createdOn = new Date();

	@Column(name = "UpdatedBy")
	@JsonIgnore
	private String updatedBy;

	@Column(name = "UpdatedOn")
	@JsonIgnore
	private Date updatedOn;
	
	@Column(name = "NoOfRetries", nullable = false)
	@JsonIgnore
	private int noOfRetries;
	
	@Column(name = "Remarks")
	@JsonIgnore
	private String remarks;
	
	@Column(name = "Remarks2")
	@JsonIgnore
	private String remarks2;
	
	@Transient
	@JsonIgnore
	private CampaignAsyncJobBatch failedBatch;
	
	@JsonProperty("totalTimeTaken")
	@Transient
	private Long totalTimeTaken;
	
	public Integer getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(Integer jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	public void setJobStatus(CampaignJobStatus jobStatus) {
		setJobStatus(jobStatus.getValue());
	}
	
	public CampaignJobStatus getJobStatus(Integer jobStatus) {
		return CampaignJobStatus.getStatusOf(jobStatus);
	}

	public Integer getJobType() {
		return jobType;
	}

	public void setJobType(Integer jobType) {
		this.jobType = jobType;
	}

	public Long getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(Long campaignId) {
		this.campaignId = campaignId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public long getStartPos() {
		return startPos;
	}

	public void setStartPos(long startPos) {
		this.startPos = startPos;
	}

	public long getEndPos() {
		return endPos;
	}

	public void setEndPos(long endPos) {
		this.endPos = endPos;
	}

	public int getTotalRecordsProcessed() {
		return totalRecordsProcessed;
	}

	public void setTotalRecordsProcessed(int totalRecordsProcessed) {
		this.totalRecordsProcessed = totalRecordsProcessed;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(Integer batchSize) {
		this.batchSize = batchSize;
	}

	public int getNumberOfBatches() {
		return numberOfBatches;
	}

	public void setNumberOfBatches(int numberOfBatches) {
		this.numberOfBatches = numberOfBatches;
	}

	public List<CampaignAsyncJobBatch> getJobBatchList() {
		return jobBatchList;
	}

	public void setJobBatchList(List<CampaignAsyncJobBatch> jobBatchList) {
		this.jobBatchList = jobBatchList;
	}

	public void addJobBatch(CampaignAsyncJobBatch jobBatch) {
		if(jobBatchList == null)
			jobBatchList = new ArrayList<>();
		jobBatchList.add(jobBatch);
		jobBatch.setCampaignAsyncJob(this);
	}
	
	public Long getLatestBatchId() {
		if(CollectionUtils.isEmpty(jobBatchList)) {
			return 0l;
		}
		return jobBatchList.get(jobBatchList.size() - 1).getBatchId();
	}
	
	public CampaignAsyncJobBatch getLatestBatch() {
		if(CollectionUtils.isEmpty(jobBatchList)) {
			return null;
		}
		return jobBatchList.get(jobBatchList.size() - 1);
	}
	
	public CampaignAsyncJobBatch getBatch(long batchId) {
		if(CollectionUtils.isEmpty(jobBatchList)) {
			return null;
		}
		for(CampaignAsyncJobBatch batch : jobBatchList) {
			if(batchId == batch.getBatchId()) {
				return batch;
			}
		}
		return null;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getId() {
		return id;
	}

	public int getNoOfRetries() {
		return noOfRetries;
	}

	public void setNoOfRetries(int noOfRetries) {
		this.noOfRetries = noOfRetries;
	}

	public CampaignAsyncJobBatch getFailedBatch() {
		return failedBatch;
	}

	public void setFailedBatch(CampaignAsyncJobBatch failedBatch) {
		this.failedBatch = failedBatch;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getRemarks2() {
		return remarks2;
	}

	public void setRemarks2(String remarks2) {
		this.remarks2 = remarks2;
	}
	
}
