package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.campaignservice.async.task.report.StageMetrics;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Table(name = "CampaignAsyncJobBatch")
public final class CampaignAsyncJobBatch implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("batchId")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BatchId", nullable = false)
	private Long batchId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "JobId", nullable = false)
	@JsonIgnore
	private CampaignAsyncJob campaignAsyncJob;
	
	@Column(name = "BatchStatus", nullable = false)
	@JsonProperty("batchStatus")
	private int batchStatus;
	
	@Column(name = "BatchSize", nullable = false)
	@JsonProperty("recordsProcessed")
	private int batchSize;
	
	@Column(name = "StartPos", nullable = false)
	@JsonIgnore
	private long startPos;
	
	@Column(name = "EndPos", nullable = false)
	@JsonIgnore
	private long endPos;
	
	@Column(name = "Remarks")
	@JsonIgnore
	private String remarks;
	
	@Column(name = "Remarks2")
	@JsonIgnore
	private String remarks2;
	
	@Column(name = "CreatedOn", nullable = false, updatable = false)
	@JsonIgnore
	private Date createdOn = new Date();
	
	@Column(name = "NoOfRetries", nullable = false)
	@JsonIgnore
	private int noOfRetries;
	
	@Column(name = "UpdatedOn")
	@JsonIgnore
	private Date updatedOn;

	@JsonProperty("totalTimeTaken")
	@Transient
	private Long totalTimeTaken;
	
	@JsonProperty("stages")
	@Transient
	private List<StageMetrics> stages;
	
	public CampaignAsyncJob getCampaignAsyncJob() {
		return campaignAsyncJob;
	}

	public void setCampaignAsyncJob(CampaignAsyncJob campaignAsyncJob) {
		this.campaignAsyncJob = campaignAsyncJob;
	}

	public int getBatchStatus() {
		return batchStatus;
	}
	
	public CampaignJobStatus getBatchStatus(int batchStatus) {
		return CampaignJobStatus.getStatusOf(batchStatus);
	}

	public void setBatchStatus(int batchStatus) {
		this.batchStatus = batchStatus;
	}
	
	public void setBatchStatus(CampaignJobStatus jobStatus) {
		setBatchStatus(jobStatus.getValue());
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public long getStartPos() {
		return startPos;
	}

	public void setStartPos(long startPos) {
		this.startPos = startPos;
	}

	public long getEndPos() {
		return endPos;
	}

	public void setEndPos(long endPos) {
		this.endPos = endPos;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public String getRemarks2() {
		return remarks2;
	}

	public void setRemarks2(String remarks2) {
		this.remarks2 = remarks2;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public long getBatchId() {
		return batchId;
	}

	public int getNoOfRetries() {
		return noOfRetries;
	}

	public void setNoOfRetries(int noOfRetries) {
		this.noOfRetries = noOfRetries;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
	public Long getTotalTimeTaken() {
		return totalTimeTaken;
	}

	public void addToTotalTimeTaken(Long totalTimeTaken) {
		this.totalTimeTaken = this.totalTimeTaken + totalTimeTaken;
	}
	
	public void addStage(StageMetrics stage) {
		stages.add(stage);
	}
	
	public StageMetrics getStage(int index) {
		return stages.get(index);
	}
	
	public StageMetrics getLatestStage() {
		return stages.get(stages.size() - 1);
	}
}
