package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PersistenceContext;
import javax.persistence.Table;

@Entity
@Table(name = "CampaignAuditLog")
public class CampaignAuditLog implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id", nullable = false)
	private Long id;

	@Column(name = "FromState", nullable = true)
	private Integer fromState;

	@Column(name = "ToState", nullable = true)
	private Integer toState;

	@Column(name = "ModifiedBy", nullable = true)
	private Long modifiedBy;

	@Column(name = "ModifiedDate", nullable = true)
	private Date modifiedDate;

		
	@ManyToOne(fetch = FetchType.LAZY) 
	@JoinColumn(name = "SprinttCampaignId", nullable = false, updatable = false)
	private CampaignMaster campaignMaster;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getFromState() {
		return fromState;
	}

	public void setFromState(Integer fromState) {
		this.fromState = fromState;
	}

	public Integer getToState() {
		return toState;
	}

	public void setToState(Integer toState) {
		this.toState = toState;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public CampaignMaster getCampaignMaster() {
		return campaignMaster;
	}

	public void setCampaignMaster(CampaignMaster campaignMaster) {
		this.campaignMaster = campaignMaster;
	}

}