package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.workflowengine.CampaignTransitional;

@Entity
@Table(name = "CampaignMaster")
public class CampaignMaster implements Serializable, CampaignTransitional {

	private static final long serialVersionUID = -4509022779590403602L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "campaignid_generator")
	@SequenceGenerator(name = "campaignid_generator",sequenceName = "SprinttCampaignIdSequence", allocationSize = 1)
	private Long sprinttCampaignId;
	
	@Column(name = "CampaignId", nullable = true)
	private String campaignId;

	@Column(name = "CampaignName", nullable = true)
	private String campaignName;

	@JsonIgnore
	@Column(name = "SegmentId", nullable = false)
	private Long segmentId;

	@Column(name = "TrialId", nullable = false)
	private Long trialId;

	@Column(name = "ScheduleId", nullable = true)
	private Long scheduleId;

	@Column(name = "EmailTemplateId", nullable = true)
	private Long emailTemplateId;

	@Column(name = "CampaignStatusId", nullable = true)
	private Integer campaignStatusId;

	@JsonIgnore
	@Column(name = "EloCampgnStatusId", nullable = true)
	private Integer eloCampgnStatusId;

	@JsonIgnore
	@Column(name = "CampaignJobStatusId", nullable = true)
	private Integer campaignJobStatusId;

	@Column(name = "InclusionCriteria", nullable = true)
	private String inclusionCriteria;

	@Column(name = "ExclusionCriteria", nullable = true)
	private String exclusionCriteria;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@JsonProperty("createdOn")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@Transient
	@JsonProperty("isDifference")
	private boolean isDifference;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "ScheduleId", insertable = false, updatable = false)
	private Schedule schedule;

	@OneToMany(mappedBy = "campaignMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<Reminder> reminders;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "EmailTemplateId", insertable = false, updatable = false)
	private EmailTemplate emailTemplate;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "CampaignStatusId", insertable = false, updatable = false)
	private CampaignStatus campaignStatus;

	@Column(name = "LastAction", nullable = true)
	private String lastAction;

	@Column(name = "NextAction", nullable = true)
	private String nextAction;

	@JsonIgnore
	@Column(name = "Remarks", nullable = true)
	private String remarks;
	
	@Column(name = "ExternalStudyLink", nullable = true)
	private boolean externalStudyLink;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "campaignMaster")
	@Fetch(value = FetchMode.SUBSELECT)
	private List<CampaignAuditLog> auditLogs;
	
	@Column(name = "ReminderJobStatusId", nullable = false)
	private Integer reminderJobStatusId =0;
	
	@Column(name = "Channel", nullable = true)
	private Integer channel;
	
	/**
	 * @return the campaignStatus
	 */
	public CampaignStatus getCampaignStatus() {
		return campaignStatus;
	}

	/**
	 * @param campaignStatus the campaignStatus to set
	 */
	public void setCampaignStatus(CampaignStatus campaignStatus) {
		this.campaignStatus = campaignStatus;
	}

	/**
	 * @return the sprinttCampaignId
	 */
	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	/**
	 * @param sprinttCampaignId the sprinttCampaignId to set
	 */
	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	/**
	 * @return the scheduleId
	 */
	public Long getScheduleId() {
		return scheduleId;
	}

	/**
	 * @param scheduleId the scheduleId to set
	 */
	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}

	public Long getEmailTemplateId() {
		return emailTemplateId;
	}

	/**
	 * @param emailTemplateId the emailTemplateId to set
	 */
	public void setEmailTemplateId(Long emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}

	/**
	 * @return the campaignStatusId
	 */
	public Integer getCampaignStatusId() {
		return campaignStatusId;
	}

	/**
	 * @param campaignStatusId the campaignStatusId to set
	 */
	public void setCampaignStatusId(Integer campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	/**
	 * @return the eloCampgnStatusId
	 */
	public Integer getEloCampgnStatusId() {
		return eloCampgnStatusId;
	}

	/**
	 * @param eloCampgnStatusId the eloCampgnStatusId to set
	 */
	public void setEloCampgnStatusId(Integer eloCampgnStatusId) {
		this.eloCampgnStatusId = eloCampgnStatusId;
	}

	/**
	 * @return the campaignJobStatusId
	 */
	public Integer getCampaignJobStatusId() {
		return campaignJobStatusId;
	}

	/**
	 * @param campaignJobStatusId the campaignJobStatusId to set
	 */
	public void setCampaignJobStatusId(Integer campaignJobStatusId) {
		this.campaignJobStatusId = campaignJobStatusId;
	}

	/**
	 * @return the inclusionCriteria
	 */
	public String getInclusionCriteria() {
		return inclusionCriteria;
	}

	/**
	 * @param inclusionCriteria the inclusionCriteria to set
	 */
	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}

	/**
	 * @return the exclusionCriteria
	 */
	public String getExclusionCriteria() {
		return exclusionCriteria;
	}

	/**
	 * @param exclusionCriteria the exclusionCriteria to set
	 */
	public void setExclusionCriteria(String exclusionCriteria) {
		this.exclusionCriteria = exclusionCriteria;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the updatedOn
	 */
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the segmentId
	 */
	public Long getSegmentId() {
		return segmentId;
	}

	/**
	 * @param segmentId the segmentId to set
	 */
	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	/**
	 * @return the schedule
	 */
	public Schedule getSchedule() {
		return schedule;
	}

	/**
	 * @param schedule the schedule to set
	 */
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public List<Reminder> getReminders() {
		return reminders;
	}

	public void setReminders(List<Reminder> reminder) {
		this.reminders = reminder;
	}

	/**
	 * @return the emailTemplate
	 */
	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}

	/**
	 * @param emailTemplate the emailTemplate to set
	 */
	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public String getLastAction() {
		return lastAction;
	}

	/**
	 * @param lastAction
	 */
	public void setLastAction(String lastAction) {
		this.lastAction = lastAction;
	}

	/**
	 * @return
	 */
	public String getNextAction() {
		return nextAction;
	}

	/**
	 * @param nextAction
	 */
	public void setNextAction(String nextAction) {
		this.nextAction = nextAction;
	}
	
	/**
	 * 
	 * @return the state transition audit logs of the campaign
	 */
	public List<CampaignAuditLog> getAuditLogs() {
		return auditLogs;
	}

	/**
	 * 
	 * @param auditLogs the state transition audit logs of the campaign to set
	 */
	public void setAuditLogs(List<CampaignAuditLog> auditLogs) {
		this.auditLogs = auditLogs;
	}
	
	public void addAuditLog(CampaignAuditLog auditLog) {
		auditLogs.add(auditLog);
		auditLog.setCampaignMaster(this);
	}

	@JsonIgnore
	@Override
	public SprinttCampaignStatus getCurrentState() {
		return campaignStatusId == 0 ? SprinttCampaignStatus.DRAFT
				: SprinttCampaignStatus.getStatusOf(campaignStatusId);
	}

	/**
	 * @return the isDifference
	 */
	public boolean isDifference() {
		return isDifference;
	}

	/**
	 * @param isDifference the isDifference to set
	 */
	public void setDifference(boolean isDifference) {
		this.isDifference = isDifference;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getReminderJobStatusId() {
		return reminderJobStatusId;
	}

	public void setReminderJobStatusId(Integer reminderJobStatusId) {
		this.reminderJobStatusId = reminderJobStatusId;
	}

	public Integer getChannel() {
		return channel;
	}

	public void setChannel(Integer channel) {
		this.channel = channel;
	}

	public boolean isExternalStudyLink() {
		return externalStudyLink;
	}

	public void setExternalStudyLink(boolean externalStudyLink) {
		this.externalStudyLink = externalStudyLink;
	}
	
}
