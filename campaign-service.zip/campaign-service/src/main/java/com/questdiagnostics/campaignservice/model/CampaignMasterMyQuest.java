package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "CampaignMasterMyQuest")
public class CampaignMasterMyQuest implements Serializable{
	
	private static final long serialVersionUID = 7836712426577753135L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "campaignid_generator")
	@SequenceGenerator(name = "campaignid_generator",sequenceName = "SprinttCampaignIdSequence", allocationSize = 1)
	@Column(name = "SprinttCampaignId", nullable = true)
	private Long sprinttCampaignId;
	
	@Column(name = "CampaignName", nullable = true)
	private String campaignName;
	
	@Column(name = "TrialId", nullable = false)
	private Long trialId;
	
	@Column(name = "StudyInfoId", nullable = true)
	private Long studyInfoId;
	
	@Column(name = "Channel", nullable = false)
	private Integer channel;
	
	@Column(name = "ScheduleId", nullable = true)
	private Long scheduleId;
	
	@Column(name = "CampaignStatusId", nullable = true)
	private Integer campaignStatusId;
	
	@JsonIgnore
	@Column(name = "CampaignJobStatusId", nullable = true)
	private Integer campaignJobStatusId;
	
	@Column(name = "InclusionCriteria", nullable = true)
	private String inclusionCriteria;

	@Column(name = "ExclusionCriteria", nullable = true)
	private String exclusionCriteria;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@JsonProperty("createdOn")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;
	
	@Column(name = "LastAction", nullable = true)
	private String lastAction;

	@Column(name = "NextAction", nullable = true)
	private String nextAction;

	@JsonIgnore
	@Column(name = "Remarks", nullable = true)
	private String remarks;
	
	@Column(name = "RetryCount")
	private Integer retryCount; 
	
	@JsonProperty("isDifference")
	@Column(name = "isDifference", nullable = true)
	private boolean isDifference;
	
	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "ScheduleId", insertable = false, updatable = false)
	private Schedule schedule;
	
	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "StudyInfoId", insertable = false, updatable = false)
	private StudyInfo studyInfo;
	
	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "CampaignStatusId", insertable = false, updatable = false)
	private CampaignStatus campaignStatus;

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Long getStudyInfoId() {
		return studyInfoId;
	}

	public void setStudyInfoId(Long studyInfoId) {
		this.studyInfoId = studyInfoId;
	}

	public Integer getChannel() {
		return channel;
	}

	public void setChannel(Integer channel) {
		this.channel = channel;
	}

	public Long getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}

	public Integer getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(Integer campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	public Integer getCampaignJobStatusId() {
		return campaignJobStatusId;
	}

	public void setCampaignJobStatusId(Integer campaignJobStatusId) {
		this.campaignJobStatusId = campaignJobStatusId;
	}

	public String getInclusionCriteria() {
		return inclusionCriteria;
	}

	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}

	public String getExclusionCriteria() {
		return exclusionCriteria;
	}

	public void setExclusionCriteria(String exclusionCriteria) {
		this.exclusionCriteria = exclusionCriteria;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getLastAction() {
		return lastAction;
	}

	public void setLastAction(String lastAction) {
		this.lastAction = lastAction;
	}

	public String getNextAction() {
		return nextAction;
	}

	public void setNextAction(String nextAction) {
		this.nextAction = nextAction;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public StudyInfo getStudyInfo() {
		return studyInfo;
	}

	public void setStudyInfo(StudyInfo studyInfo) {
		this.studyInfo = studyInfo;
	}

	public CampaignStatus getCampaignStatus() {
		return campaignStatus;
	}

	public void setCampaignStatus(CampaignStatus campaignStatus) {
		this.campaignStatus = campaignStatus;
	}
	
	public boolean isDifference() {
		return isDifference;
	}

	public void setDifference(boolean isDifference) {
		this.isDifference = isDifference;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	@Override
	public String toString() {
		return "CampaignMasterMyQuest [sprinttCampaignId=" + sprinttCampaignId + ", campaignName=" + campaignName
				+ ", trialId=" + trialId + ", studyInfoId=" + studyInfoId + ", channel=" + channel + ", scheduleId="
				+ scheduleId + ", campaignStatusId=" + campaignStatusId + ", campaignJobStatusId=" + campaignJobStatusId
				+ ", inclusionCriteria=" + inclusionCriteria + ", exclusionCriteria=" + exclusionCriteria
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn="
				+ updatedOn + ", lastAction=" + lastAction + ", nextAction=" + nextAction + ", remarks=" + remarks
				+ ", retryCount=" + retryCount + ", isDifference=" + isDifference + ", schedule=" + schedule
				+ ", studyInfo=" + studyInfo + ", campaignStatus=" + campaignStatus + "]";
	}
}
