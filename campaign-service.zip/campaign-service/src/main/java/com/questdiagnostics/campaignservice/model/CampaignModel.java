package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;

/**
 * @author Ajay Kumar
 *
 */
public class CampaignModel implements Serializable {

	private static final long serialVersionUID = -61859165319720920L;

	private long trialId;

	private String inclusionCriteria;

	private String exclusionCriteria;

	private long sprinttCampaignId;

	private String campaignStatus;

	private boolean isDifference;

      private int channel;
      
	/**
	 * @return the trialId
	 */
	public long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public void setTrialId(long trialId) {
		this.trialId = trialId;
	}

	/**
	 * @return the inclusionCriteria
	 */
	public String getInclusionCriteria() {
		return inclusionCriteria;
	}

	/**
	 * @param inclusionCriteria the inclusionCriteria to set
	 */
	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}

	/**
	 * @return the exclusionCriteria
	 */
	public String getExclusionCriteria() {
		return exclusionCriteria;
	}

	/**
	 * @param exclusionCriteria the exclusionCriteria to set
	 */
	public void setExclusionCriteria(String exclusionCriteria) {
		this.exclusionCriteria = exclusionCriteria;
	}

	/**
	 * @return the sprinttCampaignId
	 */
	public long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	/**
	 * @param sprinttCampaignId the sprinttCampaignId to set
	 */
	public void setSprinttCampaignId(long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	/**
	 * @return the campaignStatus
	 */
	public String getCampaignStatus() {
		return campaignStatus;
	}

	/**
	 * @param campaignStatus the campaignStatus to set
	 */
	public void setCampaignStatus(String campaignStatus) {
		this.campaignStatus = campaignStatus;
	}

	/**
	 * @return the isDifference
	 */
	public boolean isDifference() {
		return isDifference;
	}

	/**
	 * @param isDifference the isDifference to set
	 */
	public void setDifference(boolean isDifference) {
		this.isDifference = isDifference;
	}
	
	public int getChannel() {
		return channel;
	}

	public void setChannel(int channel) {
		this.channel = channel;
	}

	@Override
	public String toString() {
		return "CampaignModel [trialId=" + trialId + ", inclusionCriteria=" + inclusionCriteria + ", exclusionCriteria="
				+ exclusionCriteria + ", sprinttCampaignId=" + sprinttCampaignId + ", campaignStatus=" + campaignStatus
				+ ", isDifference=" + isDifference + ", channel=" + channel + "]";
	}


}