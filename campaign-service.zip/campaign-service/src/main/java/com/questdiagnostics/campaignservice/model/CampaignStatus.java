package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CampaignStatus")
public class CampaignStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CampaignStatusId", nullable = false)
	private Long campaignStatusId;

	@Column(name = "Name", nullable = false)
	private String name;

	@Column(name = "StatusType", nullable = false)
	private String statusType;

	@Column(name = "CreatedBy", nullable = true)
	private Long createdBy;

	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	public Long getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(Long campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the statusType
	 */
	public String getStatusType() {
		return statusType;
	}

	/**
	 * @param statusType the statusType to set
	 */
	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

	@Override
	public String toString() {
		return "CampaignStatus [campaignStatusId=" + campaignStatusId + ", name=" + name + ", statusType=" + statusType
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + "]";
	}

}