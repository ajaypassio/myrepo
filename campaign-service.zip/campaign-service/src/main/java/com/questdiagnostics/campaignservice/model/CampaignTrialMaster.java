package com.questdiagnostics.campaignservice.model;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="CampaignTrialMaster")
public class CampaignTrialMaster implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SprinttCampaignId", nullable = false)
	private Long sprinttCampaignId;
	
	@Column(name = "EloquaTrackId", nullable = false)
	private Long eloquaTrackId;
	
	@Column(name = "CampaignName", nullable = true)
	private String campaignName;
	
	@Column(name = "TrialId", nullable = false)
	private Long trialId;
	
	@Column(name = "EloquaCampaignId", nullable = false)
	private Long eloquaCampaignId;
	
	@Column(name = "EloquaCampaignName", nullable = true)
	private String eloquaCampaignName;

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public Long getEloquaTrackId() {
		return eloquaTrackId;
	}

	public void setEloquaTrackId(Long eloquaTrackId) {
		this.eloquaTrackId = eloquaTrackId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Long getEloquaCampaignId() {
		return eloquaCampaignId;
	}

	public void setEloquaCampaignId(Long eloquaCampaignId) {
		this.eloquaCampaignId = eloquaCampaignId;
	}

	public String getEloquaCampaignName() {
		return eloquaCampaignName;
	}

	public void setEloquaCampaignName(String eloquaCampaignName) {
		this.eloquaCampaignName = eloquaCampaignName;
	}

	@Override
	public String toString() {
		return "CampaignTrialMaster [sprinttCampaignId=" + sprinttCampaignId + ", eloquaTrackId=" + eloquaTrackId
				+ ", campaignName=" + campaignName + ", trialId=" + trialId + ", eloquaCampaignId=" + eloquaCampaignId
				+ ", eloquaCampaignName=" + eloquaCampaignName + "]";
	}
	
	
	
	
}


