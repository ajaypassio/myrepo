package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "EmailTemplate")
public class EmailTemplate implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EmailTemplateId", nullable = false)
	private Long emailTemplateId;

	@Column(name = "TrialId", nullable = false)
	private Long trialId;

	@Column(name = "DefaultEmailTemp", nullable = false)
	private Integer defaultEmailTemp;

	@Column(name = "eloquaEmailTempId", nullable = true)
	private Integer eloquaEmailTempId;

	@Column(name = "Name", nullable = true)
	private String name;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	@JsonIgnore
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@Transient
	public boolean useDefault;
	
	public Long getEmailTemplateId() {
		return emailTemplateId;
	}

	public void setEmailTemplateId(Long emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Integer getDefaultEmailTemp() {
		return defaultEmailTemp;
	}

	public void setDefaultEmailTemp(Integer defaultEmailTemp) {
		this.defaultEmailTemp = defaultEmailTemp;
	}

	public Integer getEloquaEmailTempId() {
		return eloquaEmailTempId;
	}

	public void setEloquaEmailTempId(Integer eloquaEmailTempId) {
		this.eloquaEmailTempId = eloquaEmailTempId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public boolean isUseDefault() {
		return useDefault;
	}

	public void setUseDefault(boolean useDefault) {
		this.useDefault = useDefault;
	}

	@Override
	public String toString() {
		return "EmailTemplate [emailTemplateId=" + emailTemplateId + ", trialId=" + trialId + ", defaultEmailTemp="
				+ defaultEmailTemp + ", eloquaEmailTempId=" + eloquaEmailTempId + ", name=" + name + ", createdBy="
				+ createdBy + ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn
				+ ", useDefault=" + useDefault + "]";
	}

}