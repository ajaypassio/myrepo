package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "MyQuestTransactionOutBox")
public class MyQuestTransactionOutBox implements Serializable {

	private static final long serialVersionUID = 8861781332758953441L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id", nullable = false)
	private Long id;

	@Column(name = "SprinttCampaignId", nullable = false)
	private Long sprinttCampaignId;

	@Column(name = "AuditQueue", nullable = false)
	private Boolean auditQueue;
	
	@Column(name = "SendToMyQuest", nullable = false)
	private Boolean sendToMyQuest;

	@Column(name = "RetryCount", nullable = false)
	private Integer retryCount;

	@Column(name = "Status", nullable = false)
	private String status;
	
	@Column(name = "AuditStatus", nullable = false)
	private String auditStatus;


	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa")
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Boolean getAuditQueue() {
		return auditQueue;
	}

	public void setAuditQueue(Boolean auditQueue) {
		this.auditQueue = auditQueue;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public Boolean getSendToMyQuest() {
		return sendToMyQuest;
	}

	public void setSendToMyQuest(Boolean sendToMyQuest) {
		this.sendToMyQuest = sendToMyQuest;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	@Override
	public String toString() {
		return "MyQuestTransactionOutBox [id=" + id + ", sprinttCampaignId=" + sprinttCampaignId + ", auditQueue="
				+ auditQueue + ", sendToMyQuest=" + sendToMyQuest + ", retryCount=" + retryCount + ", status=" + status + ", auditStatus=" + auditStatus + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn + "]";
	}

}
