package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.List;

public class NPIAssociationRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8393990585307005715L;
	private String campaignUserName;
	private Long sprinttCampaignId;
	private List<Long> npis;
	private boolean allSelected;

	public String getCampaignUserName() {
		return campaignUserName;
	}

	public void setCampaignUserName(String campaignUserName) {
		this.campaignUserName = campaignUserName;
	}

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public List<Long> getNpis() {
		return npis;
	}

	public void setNpis(List<Long> npis) {
		this.npis = npis;
	}

	public boolean isAllSelected() {
		return allSelected;
	}

	public void setAllSelected(boolean allSelected) {
		this.allSelected = allSelected;
	}

	@Override
	public String toString() {
		return "PhysicianCampaignRequest [campaignUserName=" + campaignUserName + ", sprinttCampaignId="
				+ sprinttCampaignId + ", npis=" + npis + ", allSelected=" + allSelected + "]";
	}

}
