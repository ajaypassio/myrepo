package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Participant")
public class Participant implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "FirstName", nullable = true)
	private String firstName;

	@Column(name = "LastName", nullable = true)
	private String lastName;

	@Column(name = "EmailAddress", nullable = false)
	private String emailAddress;

	@Column(name = "CreatedBy", nullable = true)
	private Long createdBy;

	@Column(name = "UpdatedBy", nullable = true)
	private Long updatedBy;

	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@Column(name = "TrialVisits", nullable = true)
	private Long trialVisits;

	@Column(name = "TrialSponsors", nullable = false)
	private String trialSponsors;

	@Id
	@Column(name = "ParticipantId", nullable = false)
	private String participantId;

	@Column(name = "ZipCode", nullable = true)
	private String zipCode;

	@Column(name = "ContactNumber", nullable = true)
	private String contactNumber;

	@Column(name = "DOB", nullable = true)
	private Date dOB;

	@Column(name = "Gender", nullable = true)
	private String gender;

	@Column(name = "Address", nullable = true)
	private String address;

	@Column(name = "SMS", nullable = true)
	private Integer sMS;

	@Column(name = "City", nullable = true)
	private String city;

	@Column(name = "State", nullable = true)
	private String state;

	@Column(name = "PhoneType", nullable = true)
	private String phoneType;

	@Column(name = "Voicemail", nullable = true)
	private Integer voicemail;

	@Column(name = "PreferredTimeOfContact", nullable = true)
	private String preferredTimeOfContact;

	@Column(name = "Session", nullable = true)
	private String session;

	@Column(name = "IsPreferredEmail", nullable = true)
	private Integer isPreferredEmail;

	@Column(name = "IsPreferredPhone", nullable = true)
	private Integer isPreferredPhone;

	@Column(name = "IsPreferredMail", nullable = true)
	private Integer isPreferredMail;	

	@Column(name = "ContactId", nullable = true)
	private String contactId;
	
	@Column(name = "ParticipantIdXRef", nullable = false)
	private Long participantIdXRef;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Long getTrialVisits() {
		return trialVisits;
	}

	public void setTrialVisits(Long trialVisits) {
		this.trialVisits = trialVisits;
	}

	public String getTrialSponsors() {
		return trialSponsors;
	}

	public void setTrialSponsors(String trialSponsors) {
		this.trialSponsors = trialSponsors;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Date getdOB() {
		return dOB;
	}

	public void setdOB(Date dOB) {
		this.dOB = dOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getsMS() {
		return sMS;
	}

	public void setsMS(Integer sMS) {
		this.sMS = sMS;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(String phoneType) {
		this.phoneType = phoneType;
	}

	public Integer getVoicemail() {
		return voicemail;
	}

	public void setVoicemail(Integer voicemail) {
		this.voicemail = voicemail;
	}

	public String getPreferredTimeOfContact() {
		return preferredTimeOfContact;
	}

	public void setPreferredTimeOfContact(String preferredTimeOfContact) {
		this.preferredTimeOfContact = preferredTimeOfContact;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public Integer getIsPreferredEmail() {
		return isPreferredEmail;
	}

	public void setIsPreferredEmail(Integer isPreferredEmail) {
		this.isPreferredEmail = isPreferredEmail;
	}

	public Integer getIsPreferredPhone() {
		return isPreferredPhone;
	}

	public void setIsPreferredPhone(Integer isPreferredPhone) {
		this.isPreferredPhone = isPreferredPhone;
	}

	public Integer getIsPreferredMail() {
		return isPreferredMail;
	}

	public void setIsPreferredMail(Integer isPreferredMail) {
		this.isPreferredMail = isPreferredMail;
	}

	/**
	 * @return the contactId
	 */
	public String getContactId() {
		return contactId;
	}

	/**
	 * @param contactId the contactId to set
	 */
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	
	public Long getParticipantIdXRef() {
		return participantIdXRef;
	}

	public void setParticipantIdXRef(Long participantIdXRef) {
		this.participantIdXRef = participantIdXRef;
	}

	@Override
	public String toString() {
		return "Participant [firstName=" + firstName + ", lastName=" + lastName + ", emailAddress=" + emailAddress
				+ ", createdBy=" + createdBy + ", updatedBy=" + updatedBy + ", createdOn=" + createdOn + ", updatedOn="
				+ updatedOn + ", trialVisits=" + trialVisits + ", trialSponsors=" + trialSponsors + ", participantId="
				+ participantId + ", zipCode=" + zipCode + ", contactNumber=" + contactNumber + ", dOB=" + dOB
				+ ", gender=" + gender + ", address=" + address + ", sMS=" + sMS + ", city=" + city + ", state=" + state
				+ ", phoneType=" + phoneType + ", voicemail=" + voicemail + ", preferredTimeOfContact="
				+ preferredTimeOfContact + ", session=" + session + ", isPreferredEmail=" + isPreferredEmail
				+ ", isPreferredPhone=" + isPreferredPhone + ", isPreferredMail=" + isPreferredMail + ", contactId=" + contactId + "]";
	}

}