package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "PauboxCampaignEmailTemplate")
public class PauboxCampaignEmailTemplate implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id")
	private Long id;

	@Column(name = "Type", nullable = false)
	private String type;
	
	@Column(name = "TrialId", nullable = false)
	private Long trialId;
	
	@Column(name = "CampaignId", nullable = false)
	private Long campaignId;
	
	@Column(name = "EmailContent", nullable = true)
	private String emailContent;
	
	@Column(name = "Status", nullable = false)
	private Integer status=0;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	@JsonIgnore
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Long getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(Long campaignId) {
		this.campaignId = campaignId;
	}

	public String getEmailContent() {
		return emailContent;
	}

	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Override
	public String toString() {
		return "EmailContentMapping [id=" + id + ", type=" + type + ", trialId=" + trialId + ", campaignId="
				+ campaignId + ", emailContent=" + emailContent + ", status=" + status + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + "]";
	}

}