package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "PauboxCampaignMaster")
public class PauboxCampaignMaster implements Serializable{

	private static final long serialVersionUID = -7250500871099220519L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "campaignid_generator")
	@SequenceGenerator(name = "campaignid_generator",sequenceName = "SprinttCampaignIdSequence", allocationSize = 1)
	private Long sprinttCampaignId;
	
	@Column(name = "CampaignId", nullable = true)
	private String campaignId;

	@Column(name = "CampaignName", nullable = true)
	private String campaignName;

	@Column(name = "TrialId", nullable = false)
	private Long trialId;

	@Column(name = "ScheduleId", nullable = true)
	private Long scheduleId;

	
	@Column(name = "ReminderId", nullable = true)
	private Long reminderId;

	
	@Column(name = "CampaignStatusId", nullable = true)
	private Integer campaignStatusId;

	@JsonIgnore
	@Column(name = "PauboxCampgnStatusId", nullable = true)
	private Integer pauboxCampgnStatusId;

	@JsonIgnore
	@Column(name = "CampaignJobStatusId", nullable = true)
	private Integer campaignJobStatusId;

	@Column(name = "InclusionCriteria", nullable = true)
	private String inclusionCriteria;

	@Column(name = "ExclusionCriteria", nullable = true)
	private String exclusionCriteria;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@JsonProperty("createdOn")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@Transient
	@JsonProperty("isDifference")
	private boolean isDifference;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "ScheduleId", insertable = false, updatable = false)
	private Schedule schedule;

	@OneToMany(mappedBy = "pauboxCampaignMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<PauboxReminder> reminder;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "CampaignStatusId", insertable = false, updatable = false)
	private CampaignStatus campaignStatus;
	
	@Column(name = "Channel", nullable = true)
	private Integer channel;

	/**
	 * @return the sprinttCampaignId
	 */
	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	/**
	 * @param sprinttCampaignId the sprinttCampaignId to set
	 */
	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	/**
	 * @return the campaignId
	 */
	public String getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the campaignName
	 */
	public String getCampaignName() {
		return campaignName;
	}

	/**
	 * @param campaignName the campaignName to set
	 */
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	/**
	 * @return the scheduleId
	 */
	public Long getScheduleId() {
		return scheduleId;
	}

	/**
	 * @param scheduleId the scheduleId to set
	 */
	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}

	/**
	 * @return the reminderId
	 */
	public Long getReminderId() {
		return reminderId;
	}

	/**
	 * @param reminderId the reminderId to set
	 */
	public void setReminderId(Long reminderId) {
		this.reminderId = reminderId;
	}

	/**
	 * @return the campaignStatusId
	 */
	public Integer getCampaignStatusId() {
		return campaignStatusId;
	}

	/**
	 * @param campaignStatusId the campaignStatusId to set
	 */
	public void setCampaignStatusId(Integer campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	/**
	 * @return the pauboxCampgnStatusId
	 */
	public Integer getPauboxCampgnStatusId() {
		return pauboxCampgnStatusId;
	}

	/**
	 * @param pauboxCampgnStatusId the pauboxCampgnStatusId to set
	 */
	public void setPauboxCampgnStatusId(Integer pauboxCampgnStatusId) {
		this.pauboxCampgnStatusId = pauboxCampgnStatusId;
	}

	/**
	 * @return the campaignJobStatusId
	 */
	public Integer getCampaignJobStatusId() {
		return campaignJobStatusId;
	}

	/**
	 * @param campaignJobStatusId the campaignJobStatusId to set
	 */
	public void setCampaignJobStatusId(Integer campaignJobStatusId) {
		this.campaignJobStatusId = campaignJobStatusId;
	}

	/**
	 * @return the inclusionCriteria
	 */
	public String getInclusionCriteria() {
		return inclusionCriteria;
	}

	/**
	 * @param inclusionCriteria the inclusionCriteria to set
	 */
	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}

	/**
	 * @return the exclusionCriteria
	 */
	public String getExclusionCriteria() {
		return exclusionCriteria;
	}

	/**
	 * @param exclusionCriteria the exclusionCriteria to set
	 */
	public void setExclusionCriteria(String exclusionCriteria) {
		this.exclusionCriteria = exclusionCriteria;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the updatedOn
	 */
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the isDifference
	 */
	public boolean isDifference() {
		return isDifference;
	}

	/**
	 * @param isDifference the isDifference to set
	 */
	public void setDifference(boolean isDifference) {
		this.isDifference = isDifference;
	}

	/**
	 * @return the schedule
	 */
	public Schedule getSchedule() {
		return schedule;
	}

	/**
	 * @param schedule the schedule to set
	 */
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	/**
	 * @return the reminder
	 */
	public List<PauboxReminder> getReminder() {
		return reminder;
	}

	/**
	 * @param reminder the reminder to set
	 */
	public void setReminder(List<PauboxReminder> reminder) {
		this.reminder = reminder;
	}

	/**
	 * @return the campaignStatus
	 */
	public CampaignStatus getCampaignStatus() {
		return campaignStatus;
	}

	/**
	 * @param campaignStatus the campaignStatus to set
	 */
	public void setCampaignStatus(CampaignStatus campaignStatus) {
		this.campaignStatus = campaignStatus;
	}

	/**
	 * @return the channel
	 */
	public Integer getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(Integer channel) {
		this.channel = channel;
	}

	@Override
	public String toString() {
		return "PauboxCampaignMaster [sprinttCampaignId=" + sprinttCampaignId + ", campaignId=" + campaignId
				+ ", campaignName=" + campaignName + ", trialId=" + trialId + ", scheduleId=" + scheduleId
				+ ", reminderId=" + reminderId + ", campaignStatusId=" + campaignStatusId + ", pauboxCampgnStatusId="
				+ pauboxCampgnStatusId + ", campaignJobStatusId=" + campaignJobStatusId + ", inclusionCriteria="
				+ inclusionCriteria + ", exclusionCriteria=" + exclusionCriteria + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn
				+ ", isDifference=" + isDifference + ", schedule=" + schedule + ", reminder=" + reminder
				+ ", campaignStatus=" + campaignStatus + ", channel=" + channel + "]";
	}

	
}
