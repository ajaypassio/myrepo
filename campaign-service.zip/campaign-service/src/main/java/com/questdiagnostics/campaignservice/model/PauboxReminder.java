package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "PauboxReminder")
public class PauboxReminder implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ReminderId", nullable = false)
	private Long reminderId;

	@Column(name = "TrialId", nullable = false)
	private Long trialId;

	
	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa") 
	@Column(name = "RemindOnDateTime", nullable = true)
	private Date remindOnDateTime;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	@JsonIgnore
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@Column(name = "ReminderTimeZone", nullable = false)
	@JsonProperty("reminderTimeZone")
	private String reminderTimeZone;

	
	@JsonIgnore
	@Transient
	@JsonProperty("startDateTime")
	private Date startDateTime;

	@JsonIgnore
	@Transient
	@JsonProperty("endDateTime")
	private Date endDateTime;

	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SprinttCampaignId", nullable = false)
	@JsonBackReference
	private PauboxCampaignMaster pauboxCampaignMaster;
	
	@Transient
	@JsonIgnore
	private Date normalizedRemindOnDateTime;
	
	@Transient
	private String status;

	/**
	 * @return the reminderId
	 */
	public Long getReminderId() {
		return reminderId;
	}

	/**
	 * @param reminderId the reminderId to set
	 */
	public void setReminderId(Long reminderId) {
		this.reminderId = reminderId;
	}

	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	/**
	 * @return the remindOnDateTime
	 */
	public Date getRemindOnDateTime() {
		return remindOnDateTime;
	}

	/**
	 * @param remindOnDateTime the remindOnDateTime to set
	 */
	public void setRemindOnDateTime(Date remindOnDateTime) {
		this.remindOnDateTime = remindOnDateTime;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the updatedOn
	 */
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	/**
	 * @return the reminderTimeZone
	 */
	public String getReminderTimeZone() {
		return reminderTimeZone;
	}

	/**
	 * @param reminderTimeZone the reminderTimeZone to set
	 */
	public void setReminderTimeZone(String reminderTimeZone) {
		this.reminderTimeZone = reminderTimeZone;
	}

	/**
	 * @return the startDateTime
	 */
	public Date getStartDateTime() {
		return startDateTime;
	}

	/**
	 * @param startDateTime the startDateTime to set
	 */
	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	/**
	 * @return the endDateTime
	 */
	public Date getEndDateTime() {
		return endDateTime;
	}

	/**
	 * @param endDateTime the endDateTime to set
	 */
	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}

	/**
	 * @return the pauboxCampaignMaster
	 */
	public PauboxCampaignMaster getPauboxCampaignMaster() {
		return pauboxCampaignMaster;
	}

	/**
	 * @param pauboxCampaignMaster the pauboxCampaignMaster to set
	 */
	public void setPauboxCampaignMaster(PauboxCampaignMaster pauboxCampaignMaster) {
		this.pauboxCampaignMaster = pauboxCampaignMaster;
	}

	/**
	 * @return the normalizedRemindOnDateTime
	 */
	public Date getNormalizedRemindOnDateTime() {
		return normalizedRemindOnDateTime;
	}

	/**
	 * @param normalizedRemindOnDateTime the normalizedRemindOnDateTime to set
	 */
	public void setNormalizedRemindOnDateTime(Date normalizedRemindOnDateTime) {
		this.normalizedRemindOnDateTime = normalizedRemindOnDateTime;
	}	
	

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "PauboxReminder [reminderId=" + reminderId + ", trialId=" + trialId + ", remindOnDateTime="
				+ remindOnDateTime + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy="
				+ updatedBy + ", updatedOn=" + updatedOn + ", reminderTimeZone=" + reminderTimeZone + ", startDateTime="
				+ startDateTime + ", endDateTime=" + endDateTime + ", pauboxCampaignMaster=" + pauboxCampaignMaster
				+ ", normalizedRemindOnDateTime=" + normalizedRemindOnDateTime + "]";
	}
	
	
	
}