package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PhysicianCampaignMaster")
public class PhysicianCampaignMaster implements Serializable{

	private static final long serialVersionUID = -4509022779590403602L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SprinttCampaignId", nullable = false)
	private Long sprinttCampaignId;

	@Column(name = "CampaignName", nullable = true)
	private String campaignName;

	@Column(name = "UserName", nullable = false)
	private String userName;
	
	@Column(name = "Specs", nullable = true,  columnDefinition = "text")
	private String specs;
	
	@Column(name = "CampaignStatusId", nullable = true)
	private int campaignStatusId;
	
	@Column(name = "Remarks", nullable = true)
	private String remarks;
	
	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;
	
	@Transient
	@Column(name = "ContactListId", nullable = true)
	private Integer contactListId;
	
	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getSpecs() {
		return specs;
	}

	public void setSpecs(String specs) {
		this.specs = specs;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public int getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(int campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	public Integer getContactListId() {
		return contactListId;
	}

	public void setContactListId(Integer contactListId) {
		this.contactListId = contactListId;
	}

	@Override
	public String toString() {
		return "PhysicianCampaignMaster [sprinttCampaignId=" + sprinttCampaignId + ", campaignName=" + campaignName
				+ ", userName=" + userName + ", specs=" + specs + ", campaignStatusId=" + campaignStatusId
				+ ", remarks=" + remarks + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn + ", createdOn="
				+ createdOn + "]";
	}

}

