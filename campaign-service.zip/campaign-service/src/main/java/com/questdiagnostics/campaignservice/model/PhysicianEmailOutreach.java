package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "PhysicianEmailOutreach")
public class PhysicianEmailOutreach implements Serializable{

	private static final long serialVersionUID = -4509022779590403602L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "campaignid_generator")
	@SequenceGenerator(name = "campaignid_generator",sequenceName = "SprinttCampaignIdSequence", allocationSize = 1)
	@Column(name = "EmailOutreachId", nullable = false)
	private Long emailOutreachId;

	@Column(name = "SprinttCampaignId", nullable = false)
	private Long sprinttCampaignId;

	@Column(name = "EloquaCampaignId", nullable = true)
	private String eloquaCampaignId;
	
	@Column(name = "SegmentId", nullable = true)
	private Long segmentId;
	
	@Column(name = "ScheduleId", nullable = true)
	private Long scheduleId;
	
	@Column(name = "EmailTemplateId", nullable = true)
	private Long emailTemplateId;
	
	@Column(name = "EloCampgnStatusId", nullable = true)
	private int eloCampgnStatusId;
	
	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;
	
	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;
	
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;
	
	@Column(name = "ContactListId", nullable = true)
	private Integer contactListId;
	
	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "ScheduleId", insertable = false, updatable = false)
	private Schedule schedule;

	@OneToMany(mappedBy = "physicianEmailOutreach", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<PhysicianReminder> reminders;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "EmailTemplateId", insertable = false, updatable = false)
	private EmailTemplate emailTemplate;

	@Transient
	private Long trialId;
	
	@Transient
	private String campaignName;
	
	@Transient
	private NPIAssociationRequest npiAssociationRequest;
	
	public Long getEmailOutreachId() {
		return emailOutreachId;
	}

	public void setEmailOutreachId(Long emailOutreachId) {
		this.emailOutreachId = emailOutreachId;
	}

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public String getEloquaCampaignId() {
		return eloquaCampaignId;
	}

	public void setEloquaCampaignId(String eloquaCampaignId) {
		this.eloquaCampaignId = eloquaCampaignId;
	}

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public Long getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}

	public Long getEmailTemplateId() {
		return emailTemplateId;
	}

	public void setEmailTemplateId(Long emailTemplateId) {
		this.emailTemplateId = emailTemplateId;
	}

	public int getEloCampgnStatusId() {
		return eloCampgnStatusId;
	}

	public void setEloCampgnStatusId(int eloCampgnStatusId) {
		this.eloCampgnStatusId = eloCampgnStatusId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public List<PhysicianReminder> getReminders() {
		return reminders;
	}

	public void setReminders(List<PhysicianReminder> reminders) {
		this.reminders = reminders;
	}

	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}

	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public Integer getContactListId() {
		return contactListId;
	}

	public void setContactListId(Integer contactListId) {
		this.contactListId = contactListId;
	}

	public NPIAssociationRequest getNpiAssociationRequest() {
		return npiAssociationRequest;
	}

	public void setNpiAssociationRequest(NPIAssociationRequest npiAssociationRequest) {
		this.npiAssociationRequest = npiAssociationRequest;
	}

	@Override
	public String toString() {
		return "PhysicianEmailOutreach [emailOutreachId=" + emailOutreachId + ", sprinttCampaignId=" + sprinttCampaignId
				+ ", eloquaCampaignId=" + eloquaCampaignId + ", segmentId=" + segmentId + ", scheduleId=" + scheduleId
				+ ", emailTemplateId=" + emailTemplateId + ", eloCampgnStatusId=" + eloCampgnStatusId + ", createdBy="
				+ createdBy + ", updatedBy=" + updatedBy + ", createdOn=" + createdOn + ", updatedOn=" + updatedOn
				+ ", contactListId=" + contactListId + ", schedule=" + schedule + ", reminders=" + reminders
				+ ", emailTemplate=" + emailTemplate + ", trialId=" + trialId + ", campaignName=" + campaignName + "]";
	}

}


