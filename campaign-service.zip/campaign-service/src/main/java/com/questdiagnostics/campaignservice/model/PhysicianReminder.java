package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.campaignservice.util.CommonUtil;

@Entity
@Table(name = "PhysicianReminder")
public class PhysicianReminder implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4955363459194349626L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ReminderId", nullable = false)
	private Long reminderId;

	@Column(name = "TrialId", nullable = false)
	private Long trialId;

	@Column(name = "DefaultReminder", nullable = false)
	private Integer defaultReminder;

	/*
	 * @Column(name = "Type", nullable = true) public String type;
	 */
	@JsonIgnore
	@Column(name = "RemindTo", nullable = true)
	private String remindTo;

	//@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa") 
	@Column(name = "RemindOnDateTime", nullable = true)
	private Date remindOnDateTime;

	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	@JsonIgnore
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	@Column(name = "ReminderTimeZone", nullable = false)
	@JsonProperty("reminderTimeZone")
	private String reminderTimeZone;

	@Column(name = "IsReminderSent", nullable = false)
	private Integer isReminderSent = 0;
	
	@JsonIgnore
	@Transient
	@JsonProperty("startDateTime")
	private Date startDateTime;

	@JsonIgnore
	@Transient
	@JsonProperty("endDateTime")
	private Date endDateTime;

	@Transient
	@JsonProperty("nonOpener")
	private Boolean nonOpener = false;

	@Transient
	@JsonProperty("nonClicked")
	private Boolean nonClicked = false;

	@Transient
	private boolean useDefault;
	
	@Transient
	private String status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EmailOutreachId", nullable = false)
	@JsonBackReference
	private PhysicianEmailOutreach physicianEmailOutreach;
	
	@Transient
	@JsonIgnore
	private Date normalizedRemindOnDateTime;
	
	
	public Long getReminderId() {
		return reminderId;
	}

	public void setReminderId(Long reminderId) {
		this.reminderId = reminderId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Integer getDefaultReminder() {
		return defaultReminder;
	}

	public void setDefaultReminder(Integer defaultReminder) {
		this.defaultReminder = defaultReminder;
	}

	public String getRemindTo() {
		return remindTo;
	}

	public void setRemindTo(String remindTo) {
		this.remindTo = remindTo;
	}

	public Date getRemindOnDateTime() {
		return remindOnDateTime;
	}

	public void setRemindOnDateTime(Date remindOnDateTime) {
		this.remindOnDateTime = remindOnDateTime;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getReminderTimeZone() {
		return reminderTimeZone;
	}

	public void setReminderTimeZone(String reminderTimeZone) {
		this.reminderTimeZone = reminderTimeZone;
	}

	public Boolean getNonOpener() {
		return nonOpener;
	}

	public void setNonOpener(Boolean nonOpener) {
		this.nonOpener = nonOpener;
	}

	public Boolean getNonClicked() {
		return nonClicked;
	}

	public void setNonClicked(Boolean nonClicked) {
		this.nonClicked = nonClicked;
	}

	public boolean isUseDefault() {
		return useDefault;
	}

	public void setUseDefault(boolean useDefault) {
		this.useDefault = useDefault;
	}

	public PhysicianEmailOutreach getPhysicianEmailOutreach() {
		return physicianEmailOutreach;
	}

	public void setPhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach) {
		this.physicianEmailOutreach = physicianEmailOutreach;
	}

	public Date getNormalizedRemindOnDateTime() {
		if(normalizedRemindOnDateTime == null) {
			setNormalizedRemindOnDateTime();
		}
		return normalizedRemindOnDateTime;
	}

	private void setNormalizedRemindOnDateTime() {
		this.normalizedRemindOnDateTime = CommonUtil.normalizeDateTime(remindOnDateTime, reminderTimeZone);
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

	public Integer getIsReminderSent() {
		return isReminderSent;
	}

	public void setIsReminderSent(Integer isReminderSent) {
		this.isReminderSent = isReminderSent;
	}

	@Override
	public String toString() {
		return "Reminder [reminderId=" + reminderId + ", trialId=" + trialId + ", defaultReminder=" + defaultReminder
				+ ", remindTo=" + remindTo + ", remindOnDateTime=" + remindOnDateTime + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn
				+ ", reminderTimeZone=" + reminderTimeZone + ", isReminderSent=" + isReminderSent + ", startDateTime="
				+ startDateTime + ", endDateTime=" + endDateTime + ", nonOpener=" + nonOpener + ", nonClicked="
				+ nonClicked + ", useDefault=" + useDefault + ", status=" + status + ", campaignMaster="
				+ physicianEmailOutreach + ", normalizedRemindOnDateTime=" + normalizedRemindOnDateTime + "]";
	}
}