package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.campaignservice.util.CommonUtil;

@Entity
@Table(name = "Schedule")
public class Schedule implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ScheduleId", nullable = false)
	public Long scheduleId;

	@Column(name = "TrialId", nullable = false)
	public Long trialId;

	@Column(name = "DefaultSchedule", nullable = false)
	public Integer defaultSchedule;

	@Column(name = "SchedulerTimeZone", nullable = false)
	@JsonProperty("timezone")
	public String timezone;

	// @Transient
	// @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa")
	@Column(name = "StartDateTime", nullable = true)
	public Date startDateTime;

	// @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa")
	@Column(name = "EndDate", nullable = true)
	public Date endDate;

	@Column(name = "CreatedBy", nullable = true)
	public String createdBy;

	@JsonIgnore
	@Column(name = "CreatedOn", nullable = true)
	public Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	public String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	public Date updatedOn;

	@Transient
	public boolean useDefault;

	@Transient
	@JsonIgnore
	private Date normalizedStartDateTime;

	@Transient
	@JsonIgnore
	private Date normalizedEndDate;
	
	@Transient
	private String scheduleDisplay;

	@JsonProperty("scheduleId")
	public Long getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Integer getDefaultSchedule() {
		return defaultSchedule;
	}

	public void setDefaultSchedule(Integer defaultSchedule) {
		this.defaultSchedule = defaultSchedule;
	}

	public Date getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public boolean isUseDefault() {
		return useDefault;
	}

	public void setUseDefault(boolean useDefault) {
		this.useDefault = useDefault;
	}

	public Date getNormalizedStartDateTime() {
		if (normalizedStartDateTime == null) {
			setNormalizedStartDateTime();
		}
		return normalizedStartDateTime;
	}
	
	public Date getNormalizedEndDate() {
		if(normalizedEndDate == null) {
			setNormalizedEndDate();
		}
		return normalizedEndDate;
	}

	private void setNormalizedStartDateTime() {
		this.normalizedStartDateTime = CommonUtil.normalizeDateTime(startDateTime, timezone);
	}

	private void setNormalizedEndDate() {
		this.normalizedEndDate = CommonUtil.normalizeDateTime(endDate, timezone);
		
		//Setting Normalized end date to the end of the day.
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(normalizedEndDate);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		this.normalizedEndDate = CommonUtil.normalizeDateTime(calendar.getTime(), timezone);
	}
	
	public String getScheduleDisplay() {
		return scheduleDisplay;
	}

	public void setScheduleDisplay(String scheduleDisplay) {
		this.scheduleDisplay = scheduleDisplay;
	}

	@Override
	public String toString() {
		return "Schedule [scheduleId=" + scheduleId + ", trialId=" + trialId + ", defaultSchedule=" + defaultSchedule
				+ ", timezone=" + timezone + ", startDateTime=" + startDateTime + ", endDate=" + endDate
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn="
				+ updatedOn + ", useDefault=" + useDefault + "]";
	}

}