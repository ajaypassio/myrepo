/**
 * 
 */
package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;

/**
 * @author Ajay Kumar
 *
 */
public class Spec implements Serializable {

	private static final long serialVersionUID = -39235939468748652L;

	private String speciality;
	private boolean isBmis;
	private String state;

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String specility) {
		this.speciality = specility;
	}

	public boolean isBmis() {
		return isBmis;
	}

	public void setBmis(boolean isBmis) {
		this.isBmis = isBmis;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Spec [speciality=" + speciality + ", isBmis=" + isBmis + ", state=" + state + "]";
	}

}
