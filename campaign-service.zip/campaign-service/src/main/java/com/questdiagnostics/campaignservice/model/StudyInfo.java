package com.questdiagnostics.campaignservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "StudyInfo")
public class StudyInfo implements Serializable {

	private static final long serialVersionUID = 7081692455663584769L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "StudyInfoId", nullable = true)
	private Long studyInfoId;
	
	@Column(name = "PatientHeadline", nullable = true)
	private String patientHeadline;
	
	@Column(name = "StudyMessage", nullable = true)
	private String studyMessage;
	
	@Column(name = "ExternalStudyLink", nullable = true)
	private String externalStudyLink;
	
	@Column(name = "StudyImageName", nullable = true)
	private String studyImageName;
	
	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;

	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@JsonProperty("createdOn")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;

	@JsonIgnore
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;

	public Long getStudyInfoId() {
		return studyInfoId;
	}

	public void setStudyInfoId(Long studyInfoId) {
		this.studyInfoId = studyInfoId;
	}

	public String getPatientHeadline() {
		return patientHeadline;
	}

	public void setPatientHeadline(String patientHeadline) {
		this.patientHeadline = patientHeadline;
	}

	public String getStudyMessage() {
		return studyMessage;
	}

	public void setStudyMessage(String studyMessage) {
		this.studyMessage = studyMessage;
	}

	public String getExternalStudyLink() {
		return externalStudyLink;
	}

	public void setExternalStudyLink(String externalStudyLink) {
		this.externalStudyLink = externalStudyLink;
	}

	public String getStudyImageName() {
		return studyImageName;
	}

	public void setStudyImageName(String studyImageName) {
		this.studyImageName = studyImageName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
}
