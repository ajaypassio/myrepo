package com.questdiagnostics.campaignservice.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.questdiagnostics.campaignservice.model.AsyncJobModReplicas;

@Repository
public interface AsyncJobModReplicasRepository extends JpaRepository<AsyncJobModReplicas, Long>, Serializable {

	AsyncJobModReplicas findByModValueAndServiceName(int modValue, String serviceName);

	@Modifying
	@Transactional
	@Query(value = "delete from AsyncJobModReplicas")
	void performCleanUp();

	@Modifying
	@Transactional
	@Query(value = "delete from AsyncJobModReplicas where ModValue = :modValue and ServiceName = :serviceName")
	void performCleanUpForModValueAndServiceName(@Param("modValue") int modValue,
			@Param("serviceName") String serviceName);
}
