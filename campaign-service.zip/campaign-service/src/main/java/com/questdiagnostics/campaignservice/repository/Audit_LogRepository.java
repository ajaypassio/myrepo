package com.questdiagnostics.campaignservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.Audit_Log;


@Repository
public interface Audit_LogRepository extends JpaRepository<Audit_Log,Long> {

}
