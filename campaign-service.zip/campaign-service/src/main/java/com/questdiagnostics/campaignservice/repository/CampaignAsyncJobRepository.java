package com.questdiagnostics.campaignservice.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.CampaignAsyncJob;

@Repository
public interface CampaignAsyncJobRepository extends JpaRepository<CampaignAsyncJob, Long>, Serializable {

	List<CampaignAsyncJob> findByTrialIdAndCampaignIdAndJobStatus(long trialId, long campaignId, int jobStatus,
			Sort sort);

	@Query(value = "select * from CampaignAsyncJob where TrialId = :trialId and CampaignId = :campaignId"
			+ " and JobStatus in (:jobStatusIds) order by UpdatedOn ASC", nativeQuery = true)
	List<CampaignAsyncJob> findPendingOrFailedJobsForTrialAndCampaign(@Param("trialId") long trialId,
			@Param("campaignId") long campaignId, @Param("jobStatusIds") List<Integer> jobStatusIds);
}
