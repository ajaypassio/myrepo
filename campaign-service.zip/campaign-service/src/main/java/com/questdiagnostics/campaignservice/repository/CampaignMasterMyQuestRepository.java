package com.questdiagnostics.campaignservice.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;

@Repository
public interface CampaignMasterMyQuestRepository extends JpaRepository<CampaignMasterMyQuest, Long>, Serializable{
	public CampaignMasterMyQuest findByCampaignNameAndTrialId(String campaignName, Long trialId);
	
	List<CampaignMasterMyQuest> findByTrialId(Long trialId);
	
	@Query(value = "select * from CampaignMasterMyQuest t inner join StudyInfo s on s.studyInfoId=t.studyInfoId where t.trialId=:trialId and s.studyImageName=:imageName", nativeQuery = true)
	public Optional<List<CampaignMasterMyQuest>> findCampaignsWithSameImageName(@Param("trialId") Long trialId,@Param("imageName") String imageName);
}
