package com.questdiagnostics.campaignservice.repository;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.Schedule;

@Repository
public interface CampaignMasterRepository extends JpaRepository<CampaignMaster, Long>, Serializable {
	public CampaignMaster findByCampaignNameAndTrialId(String campaignName, Long trialId);

	public List<CampaignMaster> findByTrialIdAndCampaignStatusId(Long trailId, int statusId);

	public CampaignMaster findByCampaignName(String campaignName);

	public CampaignMaster findBySprinttCampaignId(Long id);

	public Optional<List<CampaignMaster>> findByCampaignStatusIdAndCampaignJobStatusId(int statusId,
			int campaignJobStatusId);

	public Optional<List<CampaignMaster>> findByCampaignStatusIdAndCampaignJobStatusIdIn(int sprinttCampaignStatusId,
			List<Integer> campaignJobStatusId);
	
	 // added ReminderJobStatus coloumn to check the status // added 01-04-2020
	public Optional<List<CampaignMaster>> findByCampaignStatusIdAndReminderJobStatusIdIn(int sprinttCampaignStatusId,
			List<Integer> reminderJobStatusId);

	@Query(value = "SELECT SprinttCampaignId FROM CampaignMaster WHERE CampaignJobStatusId=:campaignJobStatusId AND CampaignStatusId IN (:campaignStatusIds)", nativeQuery = true)
	public Optional<List<BigInteger>> findCampaignsForDeploy(@Param("campaignJobStatusId") Integer campaignJobStatusId,
			@Param("campaignStatusIds") List<Integer> campaignStatusIds);

	@Transactional
	@Query(value = "select * from dbo.CampaignMaster cm where cm.CampaignJobStatusId in (:campaignJobStatusIds) and cm.CampaignStatusId in (:campaignStatusIds) order by CreatedOn asc", nativeQuery = true)
	public List<CampaignMaster> fetchSheduleAndDraftCampaignsWithSucccess(
			@Param("campaignJobStatusIds") List<Integer> campaignJobStatusIds,
			@Param("campaignStatusIds") List<Integer> campaignStatusIds);
	
	@Transactional
	@Query(value = "select * from dbo.CampaignMaster cm where (cm.TrialId % :mod = :remainder) and cm.CampaignJobStatusId in (:campaignJobStatusIds) and cm.CampaignStatusId in (:campaignStatusIds) order by CreatedOn asc", nativeQuery = true)
	public List<CampaignMaster> fetchSheduleAndDraftCampaignsWithSucccessByMod(
			@Param("campaignJobStatusIds") List<Integer> campaignJobStatusIds,
			@Param("campaignStatusIds") List<Integer> campaignStatusIds, @Param("mod") int mod, @Param("remainder") int remainder);

	@Query(value = "select * from dbo.CampaignMaster cm where cm.CampaignStatusId=:campaignStatusId and cm.CampaignJobStatusId in (:campaignJobStatusIds) order by UpdatedOn, CreatedOn asc", nativeQuery = true)
	public Optional<List<CampaignMaster>> fetchScheduledCampaigns(@Param("campaignStatusId") Integer campaignStatusId,
			@Param("campaignJobStatusIds") List<Integer> campaignJobStatusIds);
	
	@Query(value = "select * from dbo.CampaignMaster cm where (cm.TrialId % :mod = :remainder) and cm.CampaignStatusId=:campaignStatusId and cm.CampaignJobStatusId in (:campaignJobStatusIds) order by UpdatedOn, CreatedOn asc", nativeQuery = true)
	public Optional<List<CampaignMaster>> fetchScheduledCampaignsByMod(@Param("campaignStatusId") Integer campaignStatusId,
			@Param("campaignJobStatusIds") List<Integer> campaignJobStatusIds, @Param("mod") int mod, @Param("remainder") int remainder);

	@Transactional
	@Query("FROM Schedule WHERE scheduleId=:scheduleId AND startDateTime<=:currentDateTime")
	public Schedule getScheduleForLastNextAction(@Param("scheduleId") Long scheduleId,
			@Param("currentDateTime") Date currentDateTime);

	/*
	 * public Optional<List<CampaignMaster>>
	 * findByCampaignJobStatusIdAndCampaignStatusIdIn(int sprinttCampaignStatusId,
	 * List<Integer> campaignJobStatusId);
	 */
	
	public Optional<List<CampaignMaster>> findByCampaignJobStatusIdAndCampaignStatusIdInAndReminderJobStatusIdNotIn(int sprinttCampaignStatusId,
			List<Integer> campaignJobStatusId,List<Integer> reminderJobStatusId);
	

	/*  // Comment by jyoti for Sprint 6 task .Updating the JOB status in only new Column added ReminderJobStatusId not in Campaign Job Status
	 * @Modifying  
	 * 
	 * @Transactional
	 * 
	 * @Query("UPDATE CampaignMaster SET lastAction=:lastAction, nextAction=:nextAction, campaignJobStatusId=:campaignJobStatusId WHERE sprinttCampaignId=:sprinttCampaignId"
	 * ) public void updateNextLastAction(@Param("lastAction") String
	 * lastAction, @Param("nextAction") String nextAction,
	 * 
	 * @Param("campaignJobStatusId") Integer campaignJobStatusId,
	 * 
	 * @Param("sprinttCampaignId") Long sprinttCampaignId);
	 */
	
	 @Modifying
	  @Transactional
	  @Query("UPDATE CampaignMaster SET lastAction=:lastAction, nextAction=:nextAction, reminderJobStatusId=:reminderJobStatusId WHERE sprinttCampaignId=:sprinttCampaignId"
	  ) public void updateNextLastAction(@Param("lastAction") String
	  lastAction, @Param("nextAction") String nextAction,@Param("reminderJobStatusId") Integer reminderJobStatusId,@Param("sprinttCampaignId") Long sprinttCampaignId);
	 
	@Modifying
	@Transactional
	@Query("UPDATE Reminder SET isReminderSent=:isReminderSent WHERE reminderId=:reminderId")
	public void updateReminderIsSent(@Param("isReminderSent") Integer lastAction, @Param("reminderId") Long reminderId);

	@Query(value = "select count(sprinttCampaignId) from CampaignMaster where TrialId = :trialId and CampaignJobStatusId in (:jobStatusIds)", nativeQuery = true)
	long countInProgressCampaignJobsByTrialId(@Param("trialId") long trialId,
			@Param("jobStatusIds") List<Integer> jobStatusIds);

	@Query(value = "select * from CampaignMaster where TrialId = :trialId and CampaignStatusId = :campaignStatusId and CampaignJobStatusId = :campaignJobStatusId"
			+ " order by SprinttCampaignId ASC", nativeQuery = true)
	List<CampaignMaster> findCampaignByTrialAndCampaignStatusAndCampaignJobStatus(@Param("trialId") long trialId,
			@Param("campaignStatusId") int campaignStatusId, @Param("campaignJobStatusId") int campaignJobStatusId);

	List<CampaignMaster> findByCampaignStatusIdAndCampaignJobStatusId(int campaignStatusId, int campaignJobStatusId,
			Sort sort);

	@Query(value = "select * from CampaignMaster where CampaignStatusId = :campaignStatusId and CampaignJobStatusId in (:campaignJobStatusIds)"
			+ " order by UpdatedOn, CreatedOn ASC", nativeQuery = true)
	List<CampaignMaster> findCampaignByStatusAndJobStatuses(@Param("campaignStatusId") long campaignStatusId,
			@Param("campaignJobStatusIds") List<Integer> campaignJobStatusIds);
	
	@Query(value = "select * from CampaignMaster where (TrialId % :mod = :remainder) and CampaignStatusId = :campaignStatusId and CampaignJobStatusId in (:campaignJobStatusIds)"
			+ " order by UpdatedOn, CreatedOn ASC", nativeQuery = true)
	List<CampaignMaster> findCampaignByStatusAndJobStatusesByMod(@Param("campaignStatusId") long campaignStatusId,
			@Param("campaignJobStatusIds") List<Integer> campaignJobStatusIds, @Param("mod") int mod, @Param("remainder") int remainder);
	
	public Optional<List<CampaignMaster>> findByCampaignStatusId(int statusId);
	
	public List<CampaignMaster> findByTrialId(Long trailId);
	
	public Optional<List<CampaignMaster>> findByTrialIdAndCampaignStatusId(String trialId,
			int campaignStatusId);
	
	public Optional<CampaignMaster> findByCampaignId(String eloquaCampaignId);

}
