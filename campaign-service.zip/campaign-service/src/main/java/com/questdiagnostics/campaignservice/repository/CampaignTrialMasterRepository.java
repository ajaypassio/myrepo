package com.questdiagnostics.campaignservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.CampaignTrialMaster;

@Repository
public interface CampaignTrialMasterRepository extends JpaRepository<CampaignTrialMaster,Long> {

}
