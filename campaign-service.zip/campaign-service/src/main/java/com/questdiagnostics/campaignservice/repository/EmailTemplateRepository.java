package com.questdiagnostics.campaignservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import com.questdiagnostics.campaignservice.model.EmailTemplate;

@Repository
public interface EmailTemplateRepository extends JpaRepository<EmailTemplate,Long> {

	
	 public EmailTemplate findEmailTempByTrialId(Long trialId);
	 
	 public EmailTemplate findByTrialIdAndDefaultEmailTemp(Long trialId,Integer defaultEmailTemp);
	 
	 public Optional<EmailTemplate> findByEmailTemplateId(Long emailTemplateId);
	
}
