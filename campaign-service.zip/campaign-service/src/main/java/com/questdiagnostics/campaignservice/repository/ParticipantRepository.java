package com.questdiagnostics.campaignservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.Participant;

@Repository
public interface ParticipantRepository extends JpaRepository<Participant, String> {

	public Optional<Participant> findByParticipantIdXRef(Long participantIdXRef);

}
