package com.questdiagnostics.campaignservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.questdiagnostics.campaignservice.model.PauboxCampaignEmailTemplate;

@Repository
public interface PauboxCampaignEmailTemplateRepository extends JpaRepository<PauboxCampaignEmailTemplate,Long> {

	 
	@Transactional
	@Query(value ="select * from PauboxCampaignEmailTemplate WHERE Type=:type and TrialId=:trialId and CampaignId=:campaignId and Status=:status", nativeQuery = true)
	public PauboxCampaignEmailTemplate fetchEmailByEmailType(@Param("type") String type, @Param("trialId") Long trialId,
			@Param("campaignId") Long campaignId, @Param("status") int status);
}
