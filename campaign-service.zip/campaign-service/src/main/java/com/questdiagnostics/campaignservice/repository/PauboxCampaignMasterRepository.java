package com.questdiagnostics.campaignservice.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.PauboxCampaignMaster;

@Repository
public interface PauboxCampaignMasterRepository extends JpaRepository<PauboxCampaignMaster, Long>, Serializable {

	public Optional<PauboxCampaignMaster> findById(Long sprinttCampaignId);
	public List<PauboxCampaignMaster> findByTrialId(Long trialId);
	public PauboxCampaignMaster findBySprinttCampaignId(Long id);
}
