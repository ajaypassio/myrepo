
package com.questdiagnostics.campaignservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.questdiagnostics.campaignservice.model.PhysicianCampaignMaster;

@Repository
public interface PhysicianCampaignMasterRepository extends JpaRepository<PhysicianCampaignMaster, Long> {

	Optional<List<PhysicianCampaignMaster>> findByCampaignStatusIdIn(List<Integer> status);

	Optional<List<PhysicianCampaignMaster>> findByCampaignStatusIdInAndCampaignNameLike(List<Integer> status, String campaignName);
	
	@Transactional
	@Query(value = "select cm.SprinttCampaignId, cm.CampaignName, cm.UserName, cm.Specs, cm.CampaignStatusId, peo.ContactListId from PhysicianCampaignMaster cm, PhysicianEmailOutreach peo where cm.CampaignStatusId in (:campaignStatusIds) and cm.SprinttCampaignId = peo.SprinttCampaignId order by cm.CreatedOn asc", nativeQuery = true)
	public List<Object[]> fetchEligibleCampaigns(
			@Param("campaignStatusIds") List<Integer> campaignStatusIds);

	Optional<List<PhysicianCampaignMaster>> findByUserName(String userName);
}
