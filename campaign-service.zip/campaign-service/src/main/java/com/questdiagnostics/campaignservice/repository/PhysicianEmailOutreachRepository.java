package com.questdiagnostics.campaignservice.repository;

import java.io.Serializable;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.questdiagnostics.campaignservice.model.PhysicianEmailOutreach;

public interface PhysicianEmailOutreachRepository extends JpaRepository<PhysicianEmailOutreach, Long>, Serializable{

	public Optional<PhysicianEmailOutreach> findBySprinttCampaignId(Long campaignId);
	
	public Optional<PhysicianEmailOutreach> findBySprinttCampaignIdAndEmailOutreachId(Long sprinttCampaignId,
			Long emailOutreachId);
}
