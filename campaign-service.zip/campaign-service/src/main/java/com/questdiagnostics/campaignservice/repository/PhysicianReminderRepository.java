package com.questdiagnostics.campaignservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.questdiagnostics.campaignservice.model.PhysicianEmailOutreach;
import com.questdiagnostics.campaignservice.model.PhysicianReminder;

@Repository
public interface PhysicianReminderRepository extends JpaRepository<PhysicianReminder, Long> {

	@Modifying
	@Transactional
	@Query(value = "delete from PhysicianReminder where ReminderId=:reminderId")
	public void deleteReminder(@Param("reminderId") Long reminderId);
	
    Optional<List<PhysicianReminder>> findByPhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach);
}
