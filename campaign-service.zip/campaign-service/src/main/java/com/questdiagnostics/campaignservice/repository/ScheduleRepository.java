package com.questdiagnostics.campaignservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.questdiagnostics.campaignservice.model.Schedule;

@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Long> {

	public Optional<Schedule> findByTrialIdAndDefaultSchedule(Long trialId, Integer defaultSchedule);

	public Optional<Schedule> findByTrialIdAndScheduleIdAndDefaultSchedule(Long trialId, Long scheduleId,
			Integer defaultSchedule);
	
	public Optional<Schedule> findByScheduleId(Long scheduleId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from Schedule where ScheduleId=:scheduleId")
	public void deleteSchedule(@Param("scheduleId") Long scheduleId);
}
