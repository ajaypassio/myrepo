package com.questdiagnostics.campaignservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.questdiagnostics.campaignservice.model.StudyInfo;

@Repository
public interface StudyInfoRepository extends JpaRepository<StudyInfo,Long> {

}
