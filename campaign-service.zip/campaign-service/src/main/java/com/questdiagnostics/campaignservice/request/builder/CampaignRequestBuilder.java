package com.questdiagnostics.campaignservice.request.builder;

import java.util.List;

import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.PhysicianReminder;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.request.model.EloquaCampaignRequest;

public interface CampaignRequestBuilder extends RequestBuilder<EloquaCampaignRequest> {

	CampaignRequestBuilder id(String id);
	
	CampaignRequestBuilder type(String type);

	CampaignRequestBuilder name(String campaignName);

	CampaignRequestBuilder currentStatus(String currentStatus);

	CampaignRequestBuilder permissions(String... permissions);

	CampaignRequestBuilder isReadOnly(String isReadOnly);

	CampaignRequestBuilder campaignCategory(String campaignCategory);

	CampaignRequestBuilder campaignType(String campaignType);

	CampaignRequestBuilder reminders(List<Reminder> reminders, EmailTemplate emailTemplateId);

	CampaignRequestBuilder segment(String segmentId);
	
	CampaignRequestBuilder emailSchedule(Schedule emailSchedule, EmailTemplate emailTemplateId);

	CampaignRequestBuilder schedule(Schedule schedule);
	
	CampaignRequestBuilder physicianReminders(List<PhysicianReminder> reminders, EmailTemplate emailTemplateId);
}
