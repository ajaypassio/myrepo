package com.questdiagnostics.campaignservice.request.builder;

public interface RequestBuilder<T> {

	T build();
}
