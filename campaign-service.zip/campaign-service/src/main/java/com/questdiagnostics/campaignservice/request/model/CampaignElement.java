package com.questdiagnostics.campaignservice.request.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals" })
public class CampaignElement {

	@JsonProperty("type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("name")
	private String name;

	@JsonProperty("memberCount")
	private String memberCount = "0";

	@JsonProperty("memberErrorCount")
	private String memberErrorCount = "0";

	@JsonProperty("outputTerminals")
	private List<CampaignElementOutputTerminal> outputTerminals;
	
	@JsonIgnore
	private CampaignElement previous;

	public CampaignElement() {
		super();
		outputTerminals = new ArrayList<>();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMemberCount() {
		return memberCount;
	}

	public void setMemberCount(String memberCount) {
		this.memberCount = memberCount;
	}

	public String getMemberErrorCount() {
		return memberErrorCount;
	}

	public void setMemberErrorCount(String memberErrorCount) {
		this.memberErrorCount = memberErrorCount;
	}

	@JsonIgnore
	public int getOutputTerminalsSize() {
		return outputTerminals.size();
	}

	public CampaignElementOutputTerminal getOutputTerminals(int index) {
		return outputTerminals.get(index);
	}

	public void addOutputTerminal(CampaignElementOutputTerminal outputTerminal) {
		this.outputTerminals.add(outputTerminal);
	}

	public CampaignElement getPrevious() {
		return previous;
	}

	public void setPrevious(CampaignElement previous) {
		this.previous = previous;
	}
}
