package com.questdiagnostics.campaignservice.request.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CampaignElementOutputTerminal {

	@JsonProperty("type")
	private String type = "CampaignOutputTerminal";
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("connectedId")
	private String connectedId;
	
	@JsonProperty("connectedType")
	private String connectedType;
	
	@JsonProperty("terminalType")
	private String terminalType;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getConnectedId() {
		return connectedId;
	}

	public void setConnectedId(String connectedId) {
		this.connectedId = connectedId;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getConnectedType() {
		return connectedType;
	}

	public void setConnectedType(String connectedType) {
		this.connectedType = connectedType;
	}

}
