package com.questdiagnostics.campaignservice.request.model;

public enum CampaignElementOutputTerminalType {

	OUT("out"), YES("yes"), NO("no");
	
	private String terminalType;

	private CampaignElementOutputTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getTerminalType() {
		return terminalType;
	}

}
