package com.questdiagnostics.campaignservice.request.model;

public enum CampaignElementType {

	CAMPAIGN_SEGMENT("CampaignSegment", "Segment Members"), CAMPAIGN_WAIT_ACTION("CampaignWaitAction", "Wait"),
	CAMPAIGN_EMAIL("CampaignEmail", "Email"), CAMPAIGN_EMAIL_SENT_RULE("CampaignEmailSentRule", "Sent Email?"),
	CAMPAIGN_CONTACT_LIST_ACTION("CampaignMoveToContactListAction", "Move to Shared List"),
	CAMPAIGN_EMAIL_OPENED_RULE("CampaignEmailOpenedRule", "Opened Email?"), CAMPAIGN_EMAIL_CLICKTHROUGH_RULE("CampaignEmailClickthroughRule", "Clicked Email?");

	private String type;

	private String name;

	private CampaignElementType(String type, String name) {
		this.type = type;
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public String getName() {
		return name;
	}

}
