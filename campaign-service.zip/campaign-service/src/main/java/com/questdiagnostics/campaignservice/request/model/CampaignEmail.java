package com.questdiagnostics.campaignservice.request.model;

import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_EMAIL;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals", "sendTimePeriod",
		"emailId", "includeListUnsubscribeHeader", "isAllowingResend", "stoArbitrationDelay", "stoType" })
public class CampaignEmail extends CampaignElement {

	@JsonProperty("sendTimePeriod")
	private String sendTimePeriod = "sendAllEmailAtOnce";

	@JsonProperty("emailId")
	private String emailId;

	@JsonProperty("includeListUnsubscribeHeader")
	private String includeListUnsubscribeHeader = "true";

	@JsonProperty("isAllowingResend")
	private String isAllowingResend = "true";

	@JsonProperty("stoArbitrationDelay")
	private String stoArbitrationDelay = "1";

	@JsonProperty("stoType")
	private String stoType = "none";

	public CampaignEmail() {
		super();
		setType(CAMPAIGN_EMAIL.getType());
		setName(CAMPAIGN_EMAIL.getName());
	}

	public String getSendTimePeriod() {
		return sendTimePeriod;
	}

	public void setSendTimePeriod(String sendTimePeriod) {
		this.sendTimePeriod = sendTimePeriod;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getIncludeListUnsubscribeHeader() {
		return includeListUnsubscribeHeader;
	}

	public void setIncludeListUnsubscribeHeader(String includeListUnsubscribeHeader) {
		this.includeListUnsubscribeHeader = includeListUnsubscribeHeader;
	}

	public String getIsAllowingResend() {
		return isAllowingResend;
	}

	public void setIsAllowingResend(String isAllowingResend) {
		this.isAllowingResend = isAllowingResend;
	}

	public String getStoArbitrationDelay() {
		return stoArbitrationDelay;
	}

	public void setStoArbitrationDelay(String stoArbitrationDelay) {
		this.stoArbitrationDelay = stoArbitrationDelay;
	}

	public String getStoType() {
		return stoType;
	}

	public void setStoType(String stoType) {
		this.stoType = stoType;
	}
}
