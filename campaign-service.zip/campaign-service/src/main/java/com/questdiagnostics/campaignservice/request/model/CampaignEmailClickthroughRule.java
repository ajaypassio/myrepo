package com.questdiagnostics.campaignservice.request.model;

import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_EMAIL_CLICKTHROUGH_RULE;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals", "emailId",
	"evaluateNoAfter", "numberOfClicks", "withinLast"})
public class CampaignEmailClickthroughRule extends CampaignElement {

	@JsonProperty("emailId")
	private String emailId;
	
	@JsonProperty("evaluateNoAfter")
	private String evaluateNoAfter = "0";
	
	@JsonProperty("numberOfClicks")
	private String numberOfClicks = "1";
	
	@JsonProperty("withinLast")
	private String withinLast = "604800";
	
	public CampaignEmailClickthroughRule() {
		super();
		setType(CAMPAIGN_EMAIL_CLICKTHROUGH_RULE.getType());
		setName(CAMPAIGN_EMAIL_CLICKTHROUGH_RULE.getName());
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEvaluateNoAfter() {
		return evaluateNoAfter;
	}

	public void setEvaluateNoAfter(String evaluateNoAfter) {
		this.evaluateNoAfter = evaluateNoAfter;
	}

	public String getNumberOfClicks() {
		return numberOfClicks;
	}

	public void setNumberOfClicks(String numberOfClicks) {
		this.numberOfClicks = numberOfClicks;
	}

	public String getWithinLast() {
		return withinLast;
	}

	public void setWithinLast(String withinLast) {
		this.withinLast = withinLast;
	}
}
