package com.questdiagnostics.campaignservice.request.model;

import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_EMAIL_OPENED_RULE;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals", "emailId",
	"evaluateNoAfter", "numberOfOpens", "withinLast" })
public class CampaignEmailOpenedRule extends CampaignElement {

	@JsonProperty("emailId")
	private String emailId;
	
	@JsonProperty("evaluateNoAfter")
	private String evaluateNoAfter = "0";
	
	@JsonProperty("numberOfOpens")
	private String numberOfOpens = "1";
	
	@JsonProperty("withinLast")
	private String withinLast = "604800";
	
	public CampaignEmailOpenedRule() {
		super();
		setType(CAMPAIGN_EMAIL_OPENED_RULE.getType());
		setName(CAMPAIGN_EMAIL_OPENED_RULE.getName());
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEvaluateNoAfter() {
		return evaluateNoAfter;
	}

	public void setEvaluateNoAfter(String evaluateNoAfter) {
		this.evaluateNoAfter = evaluateNoAfter;
	}

	public String getNumberOfOpens() {
		return numberOfOpens;
	}

	public void setNumberOfOpens(String numberOfOpens) {
		this.numberOfOpens = numberOfOpens;
	}

	public String getWithinLast() {
		return withinLast;
	}

	public void setWithinLast(String withinLast) {
		this.withinLast = withinLast;
	}

}
