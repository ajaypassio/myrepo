package com.questdiagnostics.campaignservice.request.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals", "emailId",
	"evaluateNoAfter" })
public class CampaignEmailSentRule extends CampaignElement {

	@JsonProperty("emailId")
	private String emailId;
	
	@JsonProperty("evaluateNoAfter")
	private String evaluateNoAfter;
	
	public CampaignEmailSentRule() {
		super();
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEvaluateNoAfter() {
		return evaluateNoAfter;
	}

	public void setEvaluateNoAfter(String evaluateNoAfter) {
		this.evaluateNoAfter = evaluateNoAfter;
	}

}
