/**
 * 
 */
package com.questdiagnostics.campaignservice.request.model;

import java.io.Serializable;

import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;
import com.questdiagnostics.campaignservice.model.PauboxCampaignMaster;

/**
 * @author Ajay Kumar
 *
 */
public class CampaignRequest implements Serializable {

	private static final long serialVersionUID = -6664320500092901259L;

	public CampaignMaster eloquaCampaign;

	public CampaignMasterMyQuest myQuestCampaign;
	
	public PauboxCampaignMaster pauboxCampaign;

	/**
	 * @return the eloquaCampaign
	 */
	public CampaignMaster getEloquaCampaign() {
		return eloquaCampaign;
	}

	/**
	 * @param eloquaCampaign the eloquaCampaign to set
	 */
	public void setEloquaCampaign(CampaignMaster eloquaCampaign) {
		this.eloquaCampaign = eloquaCampaign;
	}

	/**
	 * @return the myQuestCampaign
	 */
	public CampaignMasterMyQuest getMyQuestCampaign() {
		return myQuestCampaign;
	}

	/**
	 * @param myQuestCampaign the myQuestCampaign to set
	 */
	public void setMyQuestCampaign(CampaignMasterMyQuest myQuestCampaign) {
		this.myQuestCampaign = myQuestCampaign;
	}

	/**
	 * @return the pauboxCampaign
	 */
	public PauboxCampaignMaster getPauboxCampaign() {
		return pauboxCampaign;
	}

	/**
	 * @param pauboxCampaign the pauboxCampaign to set
	 */
	public void setPauboxCampaign(PauboxCampaignMaster pauboxCampaign) {
		this.pauboxCampaign = pauboxCampaign;
	}

}
