package com.questdiagnostics.campaignservice.request.model;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.FALSE_VALUE;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_SEGMENT;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_WAIT_ACTION;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals", "isFinished",
	"isRecurring", "segmentId" })
public class CampaignSegment extends CampaignElement {

	@JsonProperty("isFinished")
	private String isFinished = FALSE_VALUE;
	
	@JsonProperty("isRecurring")
	private String isRecurring = FALSE_VALUE;
	
	@JsonProperty("segmentId")
	private String segmentId;
	
	public CampaignSegment() {
		super();
		setType(CAMPAIGN_SEGMENT.getType());
		setName(CAMPAIGN_SEGMENT.getName());
	}
	
	public String getIsFinished() {
		return isFinished;
	}

	public void setIsFinished(String isFinished) {
		this.isFinished = isFinished;
	}

	public String getIsRecurring() {
		return isRecurring;
	}

	public void setIsRecurring(String isRecurring) {
		this.isRecurring = isRecurring;
	}

	public String getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}	
	
}
