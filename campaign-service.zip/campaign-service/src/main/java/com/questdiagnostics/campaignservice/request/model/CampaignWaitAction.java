package com.questdiagnostics.campaignservice.request.model;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.FALSE_VALUE;
import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_WAIT_ACTION;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "type", "id", "name", "memberCount", "memberErrorCount", "outputTerminals", "displayTimeZoneId",
		"isNotificationEnabled", "waitUntil" })
public class CampaignWaitAction extends CampaignElement {

	@JsonProperty("displayTimeZoneId")
	private String displayTimeZoneId = "64";

	@JsonProperty("isNotificationEnabled")
	private String isNotificationEnabled;

	@JsonProperty("waitUntil")
	private String waitUntil;

	public CampaignWaitAction() {
		super();
		setType(CAMPAIGN_WAIT_ACTION.getType());
		setName(CAMPAIGN_WAIT_ACTION.getName());
		setIsNotificationEnabled(FALSE_VALUE);
	}

	public String getDisplayTimeZoneId() {
		return displayTimeZoneId;
	}

	public void setDisplayTimeZoneId(String displayTimeZoneId) {
		this.displayTimeZoneId = displayTimeZoneId;
	}

	public String getIsNotificationEnabled() {
		return isNotificationEnabled;
	}

	public void setIsNotificationEnabled(String isNotificationEnabled) {
		this.isNotificationEnabled = isNotificationEnabled;
	}

	public String getWaitUntil() {
		return waitUntil;
	}

	public void setWaitUntil(String waitFor) {
		this.waitUntil = waitFor;
	}

}
