
package com.questdiagnostics.campaignservice.request.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "count", "description", "membershipAdditions", "membershipDeletions", "name", "scope", "id" })
public class ContactListRequest {

	@JsonProperty("count")
	private String count;
	@JsonProperty("description")
	private String description;
	@JsonProperty("membershipAdditions")
	private List<String> membershipAdditions;
	@JsonProperty("membershipDeletions")
	private List<String> membershipDeletions;
	@JsonProperty("name")
	private String name;
	@JsonProperty("scope")
	private String scope;
	@JsonProperty("id")
	private String id = "";

	public ContactListRequest() {
		super();
	}

	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	@JsonProperty("membershipAdditions")
	public List<String> getMembershipAdditions() {
		return membershipAdditions;
	}

	@JsonProperty("membershipAdditions")
	public void setMembershipAdditions(List<String> membershipAdditions) {
		this.membershipAdditions = membershipAdditions;
	}

	@JsonProperty("membershipDeletions")
	public List<String> getMembershipDeletions() {
		return membershipDeletions;
	}

	@JsonProperty("membershipDeletions")
	public void setMembershipDeletions(List<String> membershipDeletions) {
		this.membershipDeletions = membershipDeletions;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("count")
	public String getCount() {
		return count;
	}

	@JsonProperty("count")
	public void setCount(String count) {
		this.count = count;
	}

	@JsonProperty("scope")
	public String getScope() {
		return scope;
	}

	@JsonProperty("scope")
	public void setScope(String scope) {
		this.scope = scope;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "ContactListRequest [count=" + count + ", description=" + description + ", membershipAdditions="
				+ membershipAdditions + ", membershipDeletions=" + membershipDeletions + ", name=" + name + ", scope="
				+ scope + "]";
	}

}
