package com.questdiagnostics.campaignservice.request.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.questdiagnostics.campaignservice.response.model.FieldValue;

@JsonPropertyOrder({ "id", "firstName", "lastName", "emailAddress", "fieldValues" })
public class ContactRequest {

	@JsonProperty("id")
	private String id = "-1";

	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("emailAddress")
	private String emailAddress;

	@JsonProperty("fieldValues")
	private List<FieldValue> fieldValues = null;

	public ContactRequest() {
		// default constructor
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@JsonProperty("fieldValues")
	public List<FieldValue> getFieldValues() {
		return fieldValues;
	}

	@JsonProperty("fieldValues")
	public void setFieldValues(List<FieldValue> fieldValues) {
		this.fieldValues = fieldValues;
	}

	@Override
	public String toString() {
		return "ContactRequest [firstName=" + firstName + ", lastName=" + lastName + ", emailAddress=" + emailAddress
				+ "]";
	}

}
