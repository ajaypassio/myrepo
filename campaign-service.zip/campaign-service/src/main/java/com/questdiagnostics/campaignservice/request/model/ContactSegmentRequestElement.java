
package com.questdiagnostics.campaignservice.request.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "isIncluded",
    "list"
})
public class ContactSegmentRequestElement {

    @JsonProperty("type")
    private String type = "ContactListSegmentElement";
    @JsonProperty("isIncluded")
    private String isIncluded = "true";
    @JsonProperty("list")
    private ContactSegmentRequestElementList list;

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("isIncluded")
    public String getIsIncluded() {
		return isIncluded;
	}

    @JsonProperty("isIncluded")
	public void setIsIncluded(String isIncluded) {
		this.isIncluded = isIncluded;
	}

	@JsonProperty("list")
    public ContactSegmentRequestElementList getList() {
        return list;
    }

    @JsonProperty("list")
    public void setList(ContactSegmentRequestElementList list) {
        this.list = list;
    }

}
