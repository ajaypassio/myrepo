package com.questdiagnostics.campaignservice.request.model;

import static com.questdiagnostics.campaignservice.constant.CommonConstants.EMPTY_STRING;
import static com.questdiagnostics.campaignservice.constant.CommonConstants.FALSE_VALUE;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.questdiagnostics.campaignservice.helper.CampaignElementHelper;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.PhysicianReminder;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.request.builder.CampaignRequestBuilder;

@JsonPropertyOrder({ "id", "type", "currentStatus", "name", "permissions", "scheduledFor", "elements", "isReadOnly",
		"campaignCategory", "endAt", "campaignType", "startAt" })
public class EloquaCampaignRequest {

	@JsonProperty("id")
	private String id = "";

	@JsonProperty("type")
	private String type = "Campaign";

	@JsonProperty("currentStatus")
	private String currentStatus = "";

	@JsonProperty("name")
	private String name;

	@JsonProperty("permissions")
	private List<String> permissions;

	@JsonProperty("scheduledFor")
	private String scheduledFor = "";

	@JsonProperty("elements")
	private List<CampaignElement> campaignElements;

	@JsonIgnore
	private CampaignElement lastElement;

	@JsonIgnore
	private String latestOutputTerminalId;

	@JsonIgnore
	private String latestElementId;

	@JsonProperty("isReadOnly")
	private String isReadOnly = "false";

	@JsonProperty("campaignCategory")
	private String campaignCategory = "contact";

	@JsonProperty("endAt")
	private String endAt = "";

	@JsonProperty("campaignType")
	private String campaignType = "";

	@JsonProperty("startAt")
	private String startAt = "";

	public EloquaCampaignRequest() {
		// default constructor
		super();
		permissions = new ArrayList<>();
		campaignElements = new ArrayList<>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPermission(int index) {
		return permissions.get(index);
	}

	public void addPermission(String permission) {
		this.permissions.add(permission);
	}

	public void addPermissions(String... permissions) {
		for (String permission : permissions) {
			this.permissions.add(permission);
		}
	}

	@JsonIgnore
	public int getCampaignElementsSize() {
		return campaignElements.size();
	}

	public CampaignElement getCampaignElement(int index) {
		return campaignElements.get(index);
	}

	public void addCampaignElement(CampaignElement campaignElement) {
		this.campaignElements.add(campaignElement);
	}

	public String getIsReadOnly() {
		return isReadOnly;
	}

	public void setIsReadOnly(String isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	public String getCampaignCategory() {
		return campaignCategory;
	}

	public void setCampaignCategory(String campaignCategory) {
		this.campaignCategory = campaignCategory;
	}

	public String getCampaignType() {
		return campaignType;
	}

	public void setCampaignType(String campaignType) {
		this.campaignType = campaignType;
	}

	public String getScheduledFor() {
		return scheduledFor;
	}

	public void setScheduledFor(String scheduledFor) {
		this.scheduledFor = scheduledFor;
	}

	public String getEndAt() {
		return endAt;
	}

	public void setEndAt(String endAt) {
		this.endAt = endAt;
	}

	public String getStartAt() {
		return startAt;
	}

	public void setStartAt(String startAt) {
		this.startAt = startAt;
	}

	public String getLatestOutputTerminalId() {
		return latestOutputTerminalId;
	}

	public void setLatestOutputTerminalId(String latestOutputTerminalId) {
		this.latestOutputTerminalId = latestOutputTerminalId;
	}

	public String getLatestElementId() {
		return latestElementId;
	}

	public void setLatestElementId(String latestElementId) {
		this.latestElementId = latestElementId;
	}

	public CampaignElement getLastElement() {
		return lastElement;
	}

	public void setLastElement(CampaignElement lastElement) {
		this.lastElement = lastElement;
	}

	public static CampaignRequestBuilder builder() {
		return new CampaignRequestBuilderImpl();
	}

	public static class CampaignRequestBuilderImpl implements CampaignRequestBuilder {
		private final EloquaCampaignRequest eloquaCampaignRequest;

		private CampaignRequestBuilderImpl() {
			eloquaCampaignRequest = new EloquaCampaignRequest();
		}

		@Override
		public CampaignRequestBuilder id(String id) {
			eloquaCampaignRequest.setId(id);
			return this;
		}

		@Override
		public CampaignRequestBuilder name(String campaignName) {
			eloquaCampaignRequest.setName(campaignName);
			return this;
		}

		@Override
		public CampaignRequestBuilder currentStatus(String currentStatus) {
			eloquaCampaignRequest.setCurrentStatus(currentStatus);
			return this;
		}

		@Override
		public CampaignRequestBuilder permissions(String... permissions) {
			eloquaCampaignRequest.addPermissions(permissions);
			return this;
		}

		@Override
		public CampaignRequestBuilder type(String type) {
			eloquaCampaignRequest.setType("Campaign");
			return this;
		}

		@Override
		public CampaignRequestBuilder isReadOnly(String isReadOnly) {
			eloquaCampaignRequest.setIsReadOnly(FALSE_VALUE);
			return this;
		}

		@Override
		public CampaignRequestBuilder campaignCategory(String campaignCategory) {
			eloquaCampaignRequest.setCampaignCategory("contact");
			return this;
		}

		@Override
		public CampaignRequestBuilder campaignType(String campaignType) {
			eloquaCampaignRequest.setCampaignType(EMPTY_STRING);
			return this;
		}

		@Override
		public EloquaCampaignRequest build() {
			this.type(null).isReadOnly(null).campaignCategory(null).campaignType(null);
			return eloquaCampaignRequest;
		}

		@Override
		public CampaignRequestBuilder reminders(List<Reminder> reminders, EmailTemplate emailTemplate) {
			if (!CollectionUtils.isEmpty(reminders) && emailTemplate != null
					&& emailTemplate.getEloquaEmailTempId() != null) {
				Collections.sort(reminders,
						(r1, r2) -> r1.getNormalizedRemindOnDateTime().compareTo(r2.getNormalizedRemindOnDateTime()));
				for (Reminder reminder : reminders) {
					if (reminder.getNonOpener()) {
						if (reminder.getNonClicked()) {
							eloquaCampaignRequest.lastElement = CampaignElementHelper.addNonClickedNonOpenerReminder(
									reminder.getNormalizedRemindOnDateTime().getTime(),
									emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
						} else {
							eloquaCampaignRequest.lastElement = CampaignElementHelper.addNonOpenerReminder(
									reminder.getNormalizedRemindOnDateTime().getTime(),
									emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
						}
					} else if (reminder.getNonClicked()) {
						eloquaCampaignRequest.lastElement = CampaignElementHelper.addNonClickedReminder(
								reminder.getNormalizedRemindOnDateTime().getTime(),
								emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
					} else {
						eloquaCampaignRequest.lastElement = CampaignElementHelper.addEmailSchedule(
								reminder.getNormalizedRemindOnDateTime().getTime(),
								emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
						/*
						 * eloquaCampaignRequest.lastElement = CampaignElementHelper.addEmailSchedule(
						 * eloquaCampaignRequest.lastElement,
						 * reminder.getNormalizedRemindOnDateTime().getTime(),
						 * emailTemplate.getEloquaEmailTempId(),
						 * eloquaCampaignRequest.campaignElements);
						 */
					}
				}
			}
			return this;
		}

		@Override
		public CampaignRequestBuilder segment(String segmentId) {
			eloquaCampaignRequest.lastElement = CampaignElementHelper.addSegment(segmentId, eloquaCampaignRequest);
			eloquaCampaignRequest.addCampaignElement(eloquaCampaignRequest.lastElement);
			return this;
		}

		@Override
		public CampaignRequestBuilder emailSchedule(Schedule emailSchedule, EmailTemplate emailTemplate) {
			if (emailSchedule != null && emailSchedule.getStartDateTime() != null && emailTemplate != null
					&& emailTemplate.getEloquaEmailTempId() != null) {
				eloquaCampaignRequest.lastElement = CampaignElementHelper.addEmailSchedule(
						emailSchedule.getNormalizedStartDateTime().getTime(), emailTemplate.getEloquaEmailTempId(),
						eloquaCampaignRequest);
			}
			return this;
		}

		@Override
		public CampaignRequestBuilder schedule(Schedule schedule) {
			if (schedule != null) {
				if (schedule.getStartDateTime() != null) {
					Calendar cal = Calendar.getInstance();
					cal.setTime(schedule.getNormalizedStartDateTime());
					cal.add(Calendar.MINUTE, -5);
					
					eloquaCampaignRequest.startAt = String
							.valueOf(cal.getTime().getTime() / 1000);
					eloquaCampaignRequest.scheduledFor = String
							.valueOf(cal.getTime().getTime() / 1000); 
				}
				if (schedule.getEndDate() != null) {
					eloquaCampaignRequest.endAt = String.valueOf(schedule.getNormalizedEndDate().getTime() / 1000);
				}
			}
			return this;
		}
		
		@Override
		public CampaignRequestBuilder physicianReminders(List<PhysicianReminder> reminders,
				EmailTemplate emailTemplate) {
			if (!CollectionUtils.isEmpty(reminders) && emailTemplate != null
					&& emailTemplate.getEloquaEmailTempId() != null) {
				Collections.sort(reminders,
						(r1, r2) -> r1.getNormalizedRemindOnDateTime().compareTo(r2.getNormalizedRemindOnDateTime()));
				for (PhysicianReminder reminder : reminders) {
					if (reminder.getNonOpener()) {
						if (reminder.getNonClicked()) {
							eloquaCampaignRequest.lastElement = CampaignElementHelper.addNonClickedNonOpenerReminder(
									reminder.getNormalizedRemindOnDateTime().getTime(),
									emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
						} else {
							eloquaCampaignRequest.lastElement = CampaignElementHelper.addNonOpenerReminder(
									reminder.getNormalizedRemindOnDateTime().getTime(),
									emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
						}
					} else if (reminder.getNonClicked()) {
						eloquaCampaignRequest.lastElement = CampaignElementHelper.addNonClickedReminder(
								reminder.getNormalizedRemindOnDateTime().getTime(),
								emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
					} else {
						eloquaCampaignRequest.lastElement = CampaignElementHelper.addEmailSchedule(
								reminder.getNormalizedRemindOnDateTime().getTime(),
								emailTemplate.getEloquaEmailTempId(), eloquaCampaignRequest);
						/*
						 * eloquaCampaignRequest.lastElement = CampaignElementHelper.addEmailSchedule(
						 * eloquaCampaignRequest.lastElement,
						 * reminder.getNormalizedRemindOnDateTime().getTime(),
						 * emailTemplate.getEloquaEmailTempId(),
						 * eloquaCampaignRequest.campaignElements);
						 */
					}
				}
			}
			return this;
		}
	}
}
