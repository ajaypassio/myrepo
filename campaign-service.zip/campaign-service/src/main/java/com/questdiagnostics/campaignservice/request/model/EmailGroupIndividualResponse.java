package com.questdiagnostics.campaignservice.request.model;


import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmailGroupIndividualResponse {

	@JsonProperty("type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("createdAt")
	private String createdAt;

	@JsonProperty("createdBy")
	private String createdBy;

	@JsonProperty("depth")
	private String depth;

	@JsonProperty("name")
	private String name;

	/*@JsonProperty("permissions")
	private List<String> permissions = null;*/

	@JsonProperty("updatedAt")
	private String updatedAt;

	@JsonProperty("updatedBy")
	private String updatedBy;

	@JsonProperty("emailIds")
	private List<String> emailIds = null;

	@JsonProperty("isSecureNotificationsGroup")
	private String isSecureNotificationsGroup;

	@JsonProperty("isVisibleInOutlookPlugin")
	private String isVisibleInOutlookPlugin;

	@JsonProperty("isVisibleInPublicSubscriptionList")
	private String isVisibleInPublicSubscriptionList;

	@JsonProperty("isWelcomeCommunicationsGroup")
	private String isWelcomeCommunicationsGroup;

	@JsonProperty("notificationEmailId")
	private String notificationEmailId;

	@JsonProperty("requireOptIn")
	private String requireOptIn;

	@JsonProperty("subscriptionLandingPageId")
	private String subscriptionLandingPageId;

	@JsonProperty("subscriptionListDataLookupId")
	private String subscriptionListDataLookupId;

	@JsonProperty("subscriptionListId")
	private String subscriptionListId;

	@JsonProperty("unSubscriptionListDataLookupId")
	private String unSubscriptionListDataLookupId;

	@JsonProperty("unSubscriptionListId")
	private String unSubscriptionListId;

	@JsonProperty("unsubscriptionLandingPageId")
	private String unsubscriptionLandingPageId;

	@JsonProperty("useSecureChannel")
	private String useSecureChannel;

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("createdAt")
	public String getCreatedAt() {
		return createdAt;
	}

	@JsonProperty("createdAt")
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	@JsonProperty("createdBy")
	public String getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("createdBy")
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("depth")
	public String getDepth() {
		return depth;
	}

	@JsonProperty("depth")
	public void setDepth(String depth) {
		this.depth = depth;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	/*@JsonProperty("permissions")
	public List<String> getPermissions() {
		return permissions;
	}

	@JsonProperty("permissions")
	public void setPermissions(List<String> permissions) {
		this.permissions = permissions;
	}*/

	@JsonProperty("updatedAt")
	public String getUpdatedAt() {
		return updatedAt;
	}

	@JsonProperty("updatedAt")
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	@JsonProperty("updatedBy")
	public String getUpdatedBy() {
		return updatedBy;
	}

	@JsonProperty("updatedBy")
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@JsonProperty("emailIds")
	public List<String> getEmailIds() {
		return emailIds;
	}

	@JsonProperty("emailIds")
	public void setEmailIds(List<String> emailIds) {
		this.emailIds = emailIds;
	}

	@JsonProperty("isSecureNotificationsGroup")
	public String getIsSecureNotificationsGroup() {
		return isSecureNotificationsGroup;
	}

	@JsonProperty("isSecureNotificationsGroup")
	public void setIsSecureNotificationsGroup(String isSecureNotificationsGroup) {
		this.isSecureNotificationsGroup = isSecureNotificationsGroup;
	}

	@JsonProperty("isVisibleInOutlookPlugin")
	public String getIsVisibleInOutlookPlugin() {
		return isVisibleInOutlookPlugin;
	}

	@JsonProperty("isVisibleInOutlookPlugin")
	public void setIsVisibleInOutlookPlugin(String isVisibleInOutlookPlugin) {
		this.isVisibleInOutlookPlugin = isVisibleInOutlookPlugin;
	}

	@JsonProperty("isVisibleInPublicSubscriptionList")
	public String getIsVisibleInPublicSubscriptionList() {
		return isVisibleInPublicSubscriptionList;
	}

	@JsonProperty("isVisibleInPublicSubscriptionList")
	public void setIsVisibleInPublicSubscriptionList(String isVisibleInPublicSubscriptionList) {
		this.isVisibleInPublicSubscriptionList = isVisibleInPublicSubscriptionList;
	}

	@JsonProperty("isWelcomeCommunicationsGroup")
	public String getIsWelcomeCommunicationsGroup() {
		return isWelcomeCommunicationsGroup;
	}

	@JsonProperty("isWelcomeCommunicationsGroup")
	public void setIsWelcomeCommunicationsGroup(String isWelcomeCommunicationsGroup) {
		this.isWelcomeCommunicationsGroup = isWelcomeCommunicationsGroup;
	}

	@JsonProperty("notificationEmailId")
	public String getNotificationEmailId() {
		return notificationEmailId;
	}

	@JsonProperty("notificationEmailId")
	public void setNotificationEmailId(String notificationEmailId) {
		this.notificationEmailId = notificationEmailId;
	}

	@JsonProperty("requireOptIn")
	public String getRequireOptIn() {
		return requireOptIn;
	}

	@JsonProperty("requireOptIn")
	public void setRequireOptIn(String requireOptIn) {
		this.requireOptIn = requireOptIn;
	}

	@JsonProperty("subscriptionLandingPageId")
	public String getSubscriptionLandingPageId() {
		return subscriptionLandingPageId;
	}

	@JsonProperty("subscriptionLandingPageId")
	public void setSubscriptionLandingPageId(String subscriptionLandingPageId) {
		this.subscriptionLandingPageId = subscriptionLandingPageId;
	}

	@JsonProperty("subscriptionListDataLookupId")
	public String getSubscriptionListDataLookupId() {
		return subscriptionListDataLookupId;
	}

	@JsonProperty("subscriptionListDataLookupId")
	public void setSubscriptionListDataLookupId(String subscriptionListDataLookupId) {
		this.subscriptionListDataLookupId = subscriptionListDataLookupId;
	}

	@JsonProperty("subscriptionListId")
	public String getSubscriptionListId() {
		return subscriptionListId;
	}

	@JsonProperty("subscriptionListId")
	public void setSubscriptionListId(String subscriptionListId) {
		this.subscriptionListId = subscriptionListId;
	}

	@JsonProperty("unSubscriptionListDataLookupId")
	public String getUnSubscriptionListDataLookupId() {
		return unSubscriptionListDataLookupId;
	}

	@JsonProperty("unSubscriptionListDataLookupId")
	public void setUnSubscriptionListDataLookupId(String unSubscriptionListDataLookupId) {
		this.unSubscriptionListDataLookupId = unSubscriptionListDataLookupId;
	}

	@JsonProperty("unSubscriptionListId")
	public String getUnSubscriptionListId() {
		return unSubscriptionListId;
	}

	@JsonProperty("unSubscriptionListId")
	public void setUnSubscriptionListId(String unSubscriptionListId) {
		this.unSubscriptionListId = unSubscriptionListId;
	}

	@JsonProperty("unsubscriptionLandingPageId")
	public String getUnsubscriptionLandingPageId() {
		return unsubscriptionLandingPageId;
	}

	@JsonProperty("unsubscriptionLandingPageId")
	public void setUnsubscriptionLandingPageId(String unsubscriptionLandingPageId) {
		this.unsubscriptionLandingPageId = unsubscriptionLandingPageId;
	}

	@JsonProperty("useSecureChannel")
	public String getUseSecureChannel() {
		return useSecureChannel;
	}

	@JsonProperty("useSecureChannel")
	public void setUseSecureChannel(String useSecureChannel) {
		this.useSecureChannel = useSecureChannel;
	}

}
