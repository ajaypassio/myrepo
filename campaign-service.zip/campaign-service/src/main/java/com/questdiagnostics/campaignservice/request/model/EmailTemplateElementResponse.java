package com.questdiagnostics.campaignservice.request.model;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;


public class EmailTemplateElementResponse {

	
	@JsonProperty("elements")
	private EmailTemplateResponse[] elements;

	public EmailTemplateResponse[] getElements() {
		return elements;
	}

	public void setElements(EmailTemplateResponse[] elements) {
		this.elements = elements;
	}

	@Override
	public String toString() {
		return "EmailTemplateElementRequest [elements=" + Arrays.toString(elements) + "]";
	}


}

