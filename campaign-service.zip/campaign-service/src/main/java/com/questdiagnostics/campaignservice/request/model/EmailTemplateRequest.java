package com.questdiagnostics.campaignservice.request.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class EmailTemplateRequest {

	
	@JsonProperty("type")
	private String type;
	
	@JsonProperty("currentStatus")
	private String currentStatus;
	
	@JsonProperty("id")
	private String id;
	
	@JsonProperty("createdAt")
	private String createdAt;
	
	@JsonProperty("createdBy")
	private String createdBy;
	
	@JsonProperty("depth")
	private String depth;
	
	@JsonProperty("folderId")
	private String folderId;
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("permissions")
	private List<String> permissions;
	
	@JsonProperty("updatedAt")
	private String updatedAt;
	
	@JsonProperty("updatedBy")
	private String updatedBy;
	
	@JsonProperty("archive")
	private String archive;
	
	@JsonProperty("subject")
	private String subject;
	

	public EmailTemplateRequest() {
		//default constructor
		super();
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getCurrentStatus() {
		return currentStatus;
	}


	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getDepth() {
		return depth;
	}


	public void setDepth(String depth) {
		this.depth = depth;
	}


	public String getFolderId() {
		return folderId;
	}


	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<String> getPermissions() {
		return permissions;
	}


	public void setPermissions(List<String> permissions) {
		this.permissions = permissions;
	}


	public String getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public String getArchive() {
		return archive;
	}


	public void setArchive(String archive) {
		this.archive = archive;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}



	@Override
	public String toString() {
		return "EmailTemplateRequest [ type=" + type + ", currentStatus=" + currentStatus
				+ ", id=" + id + ", createdAt=" + createdAt + ", createdBy=" + createdBy + ", depth=" + depth
				+ ", folderId=" + folderId + ", name=" + name + ", permissions=" + permissions + ", updatedAt="
				+ updatedAt + ", updatedBy=" + updatedBy + ", archive=" + archive + ", subject=" + subject + "]";
	}


	

	
	
	
}

