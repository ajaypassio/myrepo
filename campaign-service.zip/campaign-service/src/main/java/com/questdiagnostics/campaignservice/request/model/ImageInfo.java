package com.questdiagnostics.campaignservice.request.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ImageInfo {

	@JsonProperty("trialId")
	private Long trialId;
	
	@JsonProperty("imageName")
	private String imageName;

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	@Override
	public String toString() {
		return "ImageInfo [trialId=" + trialId + ", imageName=" + imageName + "]";
	}
	
	
}
