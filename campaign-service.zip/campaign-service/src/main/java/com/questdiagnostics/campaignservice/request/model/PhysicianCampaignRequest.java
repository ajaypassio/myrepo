package com.questdiagnostics.campaignservice.request.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianCampaignRequest {
	
	@JsonProperty("campaignName")
	private String campaignName;
	
	@JsonProperty("userName")
	private String userName;
	
	@JsonProperty("spec")
	private String specs;
	
	@JsonProperty("campaignStatusId")
	private int campaignStatusId;
	
	@JsonProperty("remarks")
	private String remarks;
	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz", timezone = "America/New_York")
	@JsonProperty(value = "createdOn")
	private Date createdOn;
	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz", timezone = "America/New_York")
	@JsonProperty(value = "updatedOn")
	private Date updatedOn;
	
	@JsonProperty("sprinttCampaignId")
	private Long sprinttCampaignId;

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getSpecs() {
		return specs;
	}

	public void setSpecs(String specs) {
		this.specs = specs;
	}

	public int getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(int campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}
	
}
