package com.questdiagnostics.campaignservice.request.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianUpdateCampaignRequest {
	
	@JsonProperty("sprinttCampaignId")
	private Long sprinttCampaignId;
	
	@JsonProperty("campaignStatusId")
	private int campaignStatusId;

	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public int getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(int campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}
	
}
	