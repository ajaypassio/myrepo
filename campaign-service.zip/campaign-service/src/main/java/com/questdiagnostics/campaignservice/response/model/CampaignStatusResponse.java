package com.questdiagnostics.campaignservice.response.model;

public class CampaignStatusResponse {
	
	private Boolean isCampaignProcessing = false;

	public Boolean getIsCampaignProcessing() {
		return isCampaignProcessing;
	}

	public void setIsCampaignProcessing(Boolean isCampaignProcessing) {
		this.isCampaignProcessing = isCampaignProcessing;
	}

}
