
package com.questdiagnostics.campaignservice.response.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "currentStatus",
    "id",
    "createdAt",
    "depth",
    "name",
    "updatedAt",
    "emailAddress",
    "emailFormatPreference",
    "fieldValues",
    "firstName",
    "isBounceback",
    "isSubscribed",
    "lastName",
    "subscriptionDate"
})
public class ContactResponse {

    @JsonProperty("type")
    private String type;
    @JsonProperty("currentStatus")
    private String currentStatus;
    @JsonProperty("id")
    private String id;
    @JsonProperty("createdAt")
    private String createdAt;
    @JsonProperty("depth")
    private String depth;
    @JsonProperty("name")
    private String name;
    @JsonProperty("updatedAt")
    private String updatedAt;
    @JsonProperty("emailAddress")
    private String emailAddress;
    @JsonProperty("emailFormatPreference")
    private String emailFormatPreference;
    @JsonProperty("fieldValues")
    private List<FieldValue> fieldValues = null;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("isBounceback")
    private String isBounceback;
    @JsonProperty("isSubscribed")
    private String isSubscribed;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("subscriptionDate")
    private String subscriptionDate;

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("currentStatus")
    public String getCurrentStatus() {
        return currentStatus;
    }

    @JsonProperty("currentStatus")
    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("createdAt")
    public String getCreatedAt() {
        return createdAt;
    }

    @JsonProperty("createdAt")
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @JsonProperty("depth")
    public String getDepth() {
        return depth;
    }

    @JsonProperty("depth")
    public void setDepth(String depth) {
        this.depth = depth;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("updatedAt")
    public String getUpdatedAt() {
        return updatedAt;
    }

    @JsonProperty("updatedAt")
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @JsonProperty("emailAddress")
    public String getEmailAddress() {
        return emailAddress;
    }

    @JsonProperty("emailAddress")
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    @JsonProperty("emailFormatPreference")
    public String getEmailFormatPreference() {
        return emailFormatPreference;
    }

    @JsonProperty("emailFormatPreference")
    public void setEmailFormatPreference(String emailFormatPreference) {
        this.emailFormatPreference = emailFormatPreference;
    }

    @JsonProperty("fieldValues")
    public List<FieldValue> getFieldValues() {
        return fieldValues;
    }

    @JsonProperty("fieldValues")
    public void setFieldValues(List<FieldValue> fieldValues) {
        this.fieldValues = fieldValues;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("isBounceback")
    public String getIsBounceback() {
        return isBounceback;
    }

    @JsonProperty("isBounceback")
    public void setIsBounceback(String isBounceback) {
        this.isBounceback = isBounceback;
    }

    @JsonProperty("isSubscribed")
    public String getIsSubscribed() {
        return isSubscribed;
    }

    @JsonProperty("isSubscribed")
    public void setIsSubscribed(String isSubscribed) {
        this.isSubscribed = isSubscribed;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("subscriptionDate")
    public String getSubscriptionDate() {
        return subscriptionDate;
    }

    @JsonProperty("subscriptionDate")
    public void setSubscriptionDate(String subscriptionDate) {
        this.subscriptionDate = subscriptionDate;
    }

}
