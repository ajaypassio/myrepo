
package com.questdiagnostics.campaignservice.response.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "id",
    "depth",
    "count",
    "isIncluded",
    "lastCalculatedAt",
    "list"
})
public class ContactSegmentResponseElement {

    @JsonProperty("type")
    private String type;
    @JsonProperty("id")
    private String id;
    @JsonProperty("depth")
    private String depth;
    @JsonProperty("count")
    private String count;
    @JsonProperty("isIncluded")
    private String isIncluded;
    @JsonProperty("lastCalculatedAt")
    private String lastCalculatedAt;
    @JsonProperty("list")
    private ContactSegmentResponseElementList list;

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("depth")
    public String getDepth() {
        return depth;
    }

    @JsonProperty("depth")
    public void setDepth(String depth) {
        this.depth = depth;
    }

    @JsonProperty("count")
    public String getCount() {
        return count;
    }

    @JsonProperty("count")
    public void setCount(String count) {
        this.count = count;
    }

    @JsonProperty("isIncluded")
    public String getIsIncluded() {
        return isIncluded;
    }

    @JsonProperty("isIncluded")
    public void setIsIncluded(String isIncluded) {
        this.isIncluded = isIncluded;
    }

    @JsonProperty("lastCalculatedAt")
    public String getLastCalculatedAt() {
        return lastCalculatedAt;
    }

    @JsonProperty("lastCalculatedAt")
    public void setLastCalculatedAt(String lastCalculatedAt) {
        this.lastCalculatedAt = lastCalculatedAt;
    }

    @JsonProperty("list")
    public ContactSegmentResponseElementList getList() {
        return list;
    }

    @JsonProperty("list")
    public void setList(ContactSegmentResponseElementList list) {
        this.list = list;
    }

}
