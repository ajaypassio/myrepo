
package com.questdiagnostics.campaignservice.response.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "type",
    "currentStatus",
    "id",
    "initialId",
    "createdAt",
    "createdBy",
    "depth",
    "folderId",
    "name",
    "permissions",
    "updatedAt",
    "updatedBy",
    "count",
    "elements",
    "lastCalculatedAt"
})
public class ContactSegmentUpdateResponse {

    @JsonProperty("type")
    private String type;
    @JsonProperty("currentStatus")
    private String currentStatus;
    @JsonProperty("id")
    private String id;
    @JsonProperty("initialId")
    private String initialId;
    @JsonProperty("createdAt")
    private String createdAt;
    @JsonProperty("createdBy")
    private String createdBy;
    @JsonProperty("depth")
    private String depth;
    @JsonProperty("folderId")
    private String folderId;
    @JsonProperty("name")
    private String name;
    @JsonProperty("permissions")
    private String permissions;
    @JsonProperty("updatedAt")
    private String updatedAt;
    @JsonProperty("updatedBy")
    private String updatedBy;
    @JsonProperty("count")
    private String count;
    @JsonProperty("elements")
    private List<ContactSegmentUpdateResponseElement> elements = null;
    @JsonProperty("lastCalculatedAt")
    private String lastCalculatedAt;

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("currentStatus")
    public String getCurrentStatus() {
        return currentStatus;
    }

    @JsonProperty("currentStatus")
    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("initialId")
    public String getInitialId() {
        return initialId;
    }

    @JsonProperty("initialId")
    public void setInitialId(String initialId) {
        this.initialId = initialId;
    }

    @JsonProperty("createdAt")
    public String getCreatedAt() {
        return createdAt;
    }

    @JsonProperty("createdAt")
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @JsonProperty("createdBy")
    public String getCreatedBy() {
        return createdBy;
    }

    @JsonProperty("createdBy")
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @JsonProperty("depth")
    public String getDepth() {
        return depth;
    }

    @JsonProperty("depth")
    public void setDepth(String depth) {
        this.depth = depth;
    }

    @JsonProperty("folderId")
    public String getFolderId() {
        return folderId;
    }

    @JsonProperty("folderId")
    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("permissions")
    public String getPermissions() {
        return permissions;
    }

    @JsonProperty("permissions")
    public void setPermissions(String permissions) {
        this.permissions = permissions;
    }

    @JsonProperty("updatedAt")
    public String getUpdatedAt() {
        return updatedAt;
    }

    @JsonProperty("updatedAt")
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @JsonProperty("updatedBy")
    public String getUpdatedBy() {
        return updatedBy;
    }

    @JsonProperty("updatedBy")
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @JsonProperty("count")
    public String getCount() {
        return count;
    }

    @JsonProperty("count")
    public void setCount(String count) {
        this.count = count;
    }

    @JsonProperty("elements")
    public List<ContactSegmentUpdateResponseElement> getElements() {
        return elements;
    }

    @JsonProperty("elements")
    public void setElements(List<ContactSegmentUpdateResponseElement> elements) {
        this.elements = elements;
    }

    @JsonProperty("lastCalculatedAt")
    public String getLastCalculatedAt() {
        return lastCalculatedAt;
    }

    @JsonProperty("lastCalculatedAt")
    public void setLastCalculatedAt(String lastCalculatedAt) {
        this.lastCalculatedAt = lastCalculatedAt;
    }

}
