package com.questdiagnostics.campaignservice.response.model;

import java.io.Serializable;
import java.util.List;

import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;

public class DefaultCampaignResponse implements Serializable{

	private static final long serialVersionUID = -3047400718827803468L;
	
	private Long trialId;
	private Schedule schedule;
	private Reminder reminder;
	private EmailTemplate emailTemplate;
	
	public Long getTrialId() {
		return trialId;
	}
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}
	
	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}
	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}
	public Reminder getReminder() {
		return reminder;
	}
	public void setReminder(Reminder reminder) {
		this.reminder = reminder;
	}
	@Override
	public String toString() {
		return "DefaultCampaignResponse [trialId=" + trialId + ", schedule=" + schedule + ", reminder=" + reminder
				+ ", emailTemplate=" + emailTemplate + "]";
	}

	
}
