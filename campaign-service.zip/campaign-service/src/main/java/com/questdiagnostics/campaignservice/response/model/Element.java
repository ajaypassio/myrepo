
package com.questdiagnostics.campaignservice.response.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "id", "initialId", "name", "memberCount", "memberErrorCount", "outputTerminals",
		"position", "isFinished", "isRecurring", "segmentId", "isNotificationEnabled", "waitUntil", "sendTimePeriod",
		"emailId", "includeListUnsubscribeHeader", "isAllowingResend", "stoArbitrationDelay", "stoType",
		"evaluateNoAfter", "listId" })
public class Element implements Serializable {

	@JsonProperty("type")
	private String type;
	@JsonProperty("id")
	private String id;
	@JsonProperty("initialId")
	private String initialId;
	@JsonProperty("name")
	private String name;
	@JsonProperty("memberCount")
	private String memberCount;
	@JsonProperty("memberErrorCount")
	private String memberErrorCount;
	@JsonProperty("outputTerminals")
	private List<OutputTerminal> outputTerminals = null;
	@JsonProperty("position")
	private Position position;
	@JsonProperty("isFinished")
	private String isFinished;
	@JsonProperty("isRecurring")
	private String isRecurring;
	@JsonProperty("segmentId")
	private String segmentId;
	@JsonProperty("isNotificationEnabled")
	private String isNotificationEnabled;
	@JsonProperty("waitFor")
	private String waitFor;
	@JsonProperty("waitUntil")
	private String waitUntil;
	@JsonProperty("sendTimePeriod")
	private String sendTimePeriod;
	@JsonProperty("emailId")
	private String emailId;
	@JsonProperty("includeListUnsubscribeHeader")
	private String includeListUnsubscribeHeader;
	@JsonProperty("isAllowingResend")
	private String isAllowingResend;
	@JsonProperty("stoArbitrationDelay")
	private String stoArbitrationDelay;
	@JsonProperty("stoType")
	private String stoType;
	@JsonProperty("evaluateNoAfter")
	private String evaluateNoAfter;
	@JsonProperty("listId")
	private String listId;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	private final static long serialVersionUID = 962963550306119718L;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public Element() {
	}

	/**
	 * 
	 * @param memberCount
	 * @param outputTerminals
	 * @param isRecurring
	 * @param emailId
	 * @param stoType
	 * @param evaluateNoAfter
	 * @param type
	 * @param isFinished
	 * @param includeListUnsubscribeHeader
	 * @param isNotificationEnabled
	 * @param sendTimePeriod
	 * @param listId
	 * @param initialId
	 * @param segmentId
	 * @param name
	 * @param id
	 * @param position
	 * @param memberErrorCount
	 * @param waitFor
	 * @param isAllowingResend
	 * @param stoArbitrationDelay
	 */
	public Element(String type, String id, String initialId, String name, String memberCount, String memberErrorCount,
			List<OutputTerminal> outputTerminals, Position position, String isFinished, String isRecurring,
			String segmentId, String isNotificationEnabled, String waitFor, String sendTimePeriod, String emailId,
			String includeListUnsubscribeHeader, String isAllowingResend, String stoArbitrationDelay, String stoType,
			String evaluateNoAfter, String listId) {
		super();
		this.type = type;
		this.id = id;
		this.initialId = initialId;
		this.name = name;
		this.memberCount = memberCount;
		this.memberErrorCount = memberErrorCount;
		this.outputTerminals = outputTerminals;
		this.position = position;
		this.isFinished = isFinished;
		this.isRecurring = isRecurring;
		this.segmentId = segmentId;
		this.isNotificationEnabled = isNotificationEnabled;
		this.waitFor = waitFor;
		this.sendTimePeriod = sendTimePeriod;
		this.emailId = emailId;
		this.includeListUnsubscribeHeader = includeListUnsubscribeHeader;
		this.isAllowingResend = isAllowingResend;
		this.stoArbitrationDelay = stoArbitrationDelay;
		this.stoType = stoType;
		this.evaluateNoAfter = evaluateNoAfter;
		this.listId = listId;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("initialId")
	public String getInitialId() {
		return initialId;
	}

	@JsonProperty("initialId")
	public void setInitialId(String initialId) {
		this.initialId = initialId;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("memberCount")
	public String getMemberCount() {
		return memberCount;
	}

	@JsonProperty("memberCount")
	public void setMemberCount(String memberCount) {
		this.memberCount = memberCount;
	}

	@JsonProperty("memberErrorCount")
	public String getMemberErrorCount() {
		return memberErrorCount;
	}

	@JsonProperty("memberErrorCount")
	public void setMemberErrorCount(String memberErrorCount) {
		this.memberErrorCount = memberErrorCount;
	}

	@JsonProperty("outputTerminals")
	public List<OutputTerminal> getOutputTerminals() {
		return outputTerminals;
	}

	@JsonProperty("outputTerminals")
	public void setOutputTerminals(List<OutputTerminal> outputTerminals) {
		this.outputTerminals = outputTerminals;
	}

	@JsonProperty("position")
	public Position getPosition() {
		return position;
	}

	@JsonProperty("position")
	public void setPosition(Position position) {
		this.position = position;
	}

	@JsonProperty("isFinished")
	public String getIsFinished() {
		return isFinished;
	}

	@JsonProperty("isFinished")
	public void setIsFinished(String isFinished) {
		this.isFinished = isFinished;
	}

	@JsonProperty("isRecurring")
	public String getIsRecurring() {
		return isRecurring;
	}

	@JsonProperty("isRecurring")
	public void setIsRecurring(String isRecurring) {
		this.isRecurring = isRecurring;
	}

	@JsonProperty("segmentId")
	public String getSegmentId() {
		return segmentId;
	}

	@JsonProperty("segmentId")
	public void setSegmentId(String segmentId) {
		this.segmentId = segmentId;
	}

	@JsonProperty("isNotificationEnabled")
	public String getIsNotificationEnabled() {
		return isNotificationEnabled;
	}

	@JsonProperty("isNotificationEnabled")
	public void setIsNotificationEnabled(String isNotificationEnabled) {
		this.isNotificationEnabled = isNotificationEnabled;
	}

	@JsonProperty("waitFor")
	public String getWaitFor() {
		return waitFor;
	}

	@JsonProperty("waitFor")
	public void setWaitFor(String waitFor) {
		this.waitFor = waitFor;
	}

	@JsonProperty("waitUntil")
	public String getWaitUntil() {
		return waitUntil;
	}

	@JsonProperty("waitUntil")
	public void setWaitUntil(String waitUntil) {
		this.waitUntil = waitUntil;
	}

	@JsonProperty("sendTimePeriod")
	public String getSendTimePeriod() {
		return sendTimePeriod;
	}

	@JsonProperty("sendTimePeriod")
	public void setSendTimePeriod(String sendTimePeriod) {
		this.sendTimePeriod = sendTimePeriod;
	}

	@JsonProperty("emailId")
	public String getEmailId() {
		return emailId;
	}

	@JsonProperty("emailId")
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@JsonProperty("includeListUnsubscribeHeader")
	public String getIncludeListUnsubscribeHeader() {
		return includeListUnsubscribeHeader;
	}

	@JsonProperty("includeListUnsubscribeHeader")
	public void setIncludeListUnsubscribeHeader(String includeListUnsubscribeHeader) {
		this.includeListUnsubscribeHeader = includeListUnsubscribeHeader;
	}

	@JsonProperty("isAllowingResend")
	public String getIsAllowingResend() {
		return isAllowingResend;
	}

	@JsonProperty("isAllowingResend")
	public void setIsAllowingResend(String isAllowingResend) {
		this.isAllowingResend = isAllowingResend;
	}

	@JsonProperty("stoArbitrationDelay")
	public String getStoArbitrationDelay() {
		return stoArbitrationDelay;
	}

	@JsonProperty("stoArbitrationDelay")
	public void setStoArbitrationDelay(String stoArbitrationDelay) {
		this.stoArbitrationDelay = stoArbitrationDelay;
	}

	@JsonProperty("stoType")
	public String getStoType() {
		return stoType;
	}

	@JsonProperty("stoType")
	public void setStoType(String stoType) {
		this.stoType = stoType;
	}

	@JsonProperty("evaluateNoAfter")
	public String getEvaluateNoAfter() {
		return evaluateNoAfter;
	}

	@JsonProperty("evaluateNoAfter")
	public void setEvaluateNoAfter(String evaluateNoAfter) {
		this.evaluateNoAfter = evaluateNoAfter;
	}

	@JsonProperty("listId")
	public String getListId() {
		return listId;
	}

	@JsonProperty("listId")
	public void setListId(String listId) {
		this.listId = listId;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
}
