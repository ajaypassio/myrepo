
package com.questdiagnostics.campaignservice.response.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "currentStatus", "id", "createdAt", "createdBy", "depth", "folderId", "name",
		"permissions", "scheduledFor", "updatedAt", "updatedBy", "elements", "isReadOnly", "actualCost", "budgetedCost",
		"campaignCategory", "crmId", "endAt", "fieldValues", "isEmailMarketingCampaign", "isIncludedInROI",
		"isMemberAllowedReEntry", "isSyncedWithCRM", "startAt"})
public class EloquaCampaignResponse implements Serializable {

	@JsonProperty("type")
	private String type;
	@JsonProperty("currentStatus")
	private String currentStatus;
	@JsonProperty("id")
	private String id;
	@JsonProperty("createdAt")
	private String createdAt;
	@JsonProperty("createdBy")
	private String createdBy;
	@JsonProperty("depth")
	private String depth;
	@JsonProperty("folderId")
	private String folderId;
	@JsonProperty("name")
	private String name;
	@JsonProperty("permissions")
	private List<String> permissions = null;
	@JsonProperty("scheduledFor")
	private String scheduledFor;
	@JsonProperty("updatedAt")
	private String updatedAt;
	@JsonProperty("updatedBy")
	private String updatedBy;
	@JsonProperty("elements")
	private List<Element> elements = Collections.emptyList();
	@JsonProperty("isReadOnly")
	private String isReadOnly;
	@JsonProperty("actualCost")
	private String actualCost;
	@JsonProperty("budgetedCost")
	private String budgetedCost;
	@JsonProperty("campaignCategory")
	private String campaignCategory;
	@JsonProperty("crmId")
	private String crmId;
	@JsonProperty("endAt")
	private String endAt;
	@JsonProperty("fieldValues")
	private List<FieldValue> fieldValues = null;
	@JsonProperty("isEmailMarketingCampaign")
	private String isEmailMarketingCampaign;
	@JsonProperty("isIncludedInROI")
	private String isIncludedInROI;
	@JsonProperty("isMemberAllowedReEntry")
	private String isMemberAllowedReEntry;
	@JsonProperty("isSyncedWithCRM")
	private String isSyncedWithCRM;
	@JsonProperty("ContactListId")
	private String contactListId;
	@JsonIgnore
	private final static long serialVersionUID = 3848507176167428037L;
	
	@JsonProperty("startAt")
	private String startAt;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public EloquaCampaignResponse() {
	}

	/**
	 * 
	 * @param updatedBy
	 * @param isMemberAllowedReEntry
	 * @param currentStatus
	 * @param isSyncedWithCRM
	 * @param fieldValues
	 * @param type
	 * @param isIncludedInROI
	 * @param folderId
	 * @param isEmailMarketingCampaign
	 * @param createdAt
	 * @param crmId
	 * @param campaignCategory
	 * @param depth
	 * @param isReadOnly
	 * @param createdBy
	 * @param budgetedCost
	 * @param permissions
	 * @param elements
	 * @param name
	 * @param id
	 * @param updatedAt
	 * @param actualCost
	 */
	public EloquaCampaignResponse(String type, String currentStatus, String id, String createdAt, String createdBy, String depth,
			String folderId, String name, List<String> permissions, String updatedAt, String updatedBy,
			List<Element> elements, String isReadOnly, String actualCost, String budgetedCost, String campaignCategory,
			String crmId, List<FieldValue> fieldValues, String isEmailMarketingCampaign, String isIncludedInROI,
			String isMemberAllowedReEntry, String isSyncedWithCRM) {
		super();
		this.type = type;
		this.currentStatus = currentStatus;
		this.id = id;
		this.createdAt = createdAt;
		this.createdBy = createdBy;
		this.depth = depth;
		this.folderId = folderId;
		this.name = name;
		this.permissions = permissions;
		this.updatedAt = updatedAt;
		this.updatedBy = updatedBy;
		this.elements = elements;
		this.isReadOnly = isReadOnly;
		this.actualCost = actualCost;
		this.budgetedCost = budgetedCost;
		this.campaignCategory = campaignCategory;
		this.crmId = crmId;
		this.fieldValues = fieldValues;
		this.isEmailMarketingCampaign = isEmailMarketingCampaign;
		this.isIncludedInROI = isIncludedInROI;
		this.isMemberAllowedReEntry = isMemberAllowedReEntry;
		this.isSyncedWithCRM = isSyncedWithCRM;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("currentStatus")
	public String getCurrentStatus() {
		return currentStatus;
	}

	@JsonProperty("currentStatus")
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("createdAt")
	public String getCreatedAt() {
		return createdAt;
	}

	@JsonProperty("createdAt")
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	@JsonProperty("createdBy")
	public String getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("createdBy")
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("depth")
	public String getDepth() {
		return depth;
	}

	@JsonProperty("depth")
	public void setDepth(String depth) {
		this.depth = depth;
	}

	@JsonProperty("folderId")
	public String getFolderId() {
		return folderId;
	}

	@JsonProperty("folderId")
	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}

	@JsonProperty("name")
	public String getName() {
		return name;
	}

	@JsonProperty("name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("permissions")
	public List<String> getPermissions() {
		return permissions;
	}

	@JsonProperty("permissions")
	public void setPermissions(List<String> permissions) {
		this.permissions = permissions;
	}

	@JsonProperty("updatedAt")
	public String getUpdatedAt() {
		return updatedAt;
	}

	@JsonProperty("updatedAt")
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	@JsonProperty("updatedBy")
	public String getUpdatedBy() {
		return updatedBy;
	}

	@JsonProperty("updatedBy")
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@JsonProperty("elements")
	public List<Element> getElements() {
		return elements;
	}

	@JsonProperty("elements")
	public void setElements(List<Element> elements) {
		this.elements = elements;
	}

	@JsonProperty("isReadOnly")
	public String getIsReadOnly() {
		return isReadOnly;
	}

	@JsonProperty("isReadOnly")
	public void setIsReadOnly(String isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	@JsonProperty("actualCost")
	public String getActualCost() {
		return actualCost;
	}

	@JsonProperty("actualCost")
	public void setActualCost(String actualCost) {
		this.actualCost = actualCost;
	}

	@JsonProperty("budgetedCost")
	public String getBudgetedCost() {
		return budgetedCost;
	}

	@JsonProperty("budgetedCost")
	public void setBudgetedCost(String budgetedCost) {
		this.budgetedCost = budgetedCost;
	}

	@JsonProperty("campaignCategory")
	public String getCampaignCategory() {
		return campaignCategory;
	}

	@JsonProperty("campaignCategory")
	public void setCampaignCategory(String campaignCategory) {
		this.campaignCategory = campaignCategory;
	}

	@JsonProperty("crmId")
	public String getCrmId() {
		return crmId;
	}

	@JsonProperty("crmId")
	public void setCrmId(String crmId) {
		this.crmId = crmId;
	}

	@JsonProperty("fieldValues")
	public List<FieldValue> getFieldValues() {
		return fieldValues;
	}

	@JsonProperty("fieldValues")
	public void setFieldValues(List<FieldValue> fieldValues) {
		this.fieldValues = fieldValues;
	}

	@JsonProperty("isEmailMarketingCampaign")
	public String getIsEmailMarketingCampaign() {
		return isEmailMarketingCampaign;
	}

	@JsonProperty("isEmailMarketingCampaign")
	public void setIsEmailMarketingCampaign(String isEmailMarketingCampaign) {
		this.isEmailMarketingCampaign = isEmailMarketingCampaign;
	}

	@JsonProperty("isIncludedInROI")
	public String getIsIncludedInROI() {
		return isIncludedInROI;
	}

	@JsonProperty("isIncludedInROI")
	public void setIsIncludedInROI(String isIncludedInROI) {
		this.isIncludedInROI = isIncludedInROI;
	}

	@JsonProperty("isMemberAllowedReEntry")
	public String getIsMemberAllowedReEntry() {
		return isMemberAllowedReEntry;
	}

	@JsonProperty("isMemberAllowedReEntry")
	public void setIsMemberAllowedReEntry(String isMemberAllowedReEntry) {
		this.isMemberAllowedReEntry = isMemberAllowedReEntry;
	}

	@JsonProperty("isSyncedWithCRM")
	public String getIsSyncedWithCRM() {
		return isSyncedWithCRM;
	}

	@JsonProperty("isSyncedWithCRM")
	public void setIsSyncedWithCRM(String isSyncedWithCRM) {
		this.isSyncedWithCRM = isSyncedWithCRM;
	}

	@JsonProperty("scheduledFor")
	public String getScheduledFor() {
		return scheduledFor;
	}

	@JsonProperty("scheduledFor")
	public void setScheduledFor(String scheduledFor) {
		this.scheduledFor = scheduledFor;
	}

	@JsonProperty("endAt")
	public String getEndAt() {
		return endAt;
	}

	@JsonProperty("endAt")
	public void setEndAt(String endAt) {
		this.endAt = endAt;
	}

	@JsonProperty("startAt")
	public String getStartAt() {
		return startAt;
	}

	@JsonProperty("startAt")
	public void setStartAt(String startAt) {
		this.startAt = startAt;
	}

	@JsonProperty("ContactListId")
	public String getContactListId() {
		return contactListId;
	}

	@JsonProperty("ContactListId")
	public void setContactListId(String contactListId) {
		this.contactListId = contactListId;
	}

}
