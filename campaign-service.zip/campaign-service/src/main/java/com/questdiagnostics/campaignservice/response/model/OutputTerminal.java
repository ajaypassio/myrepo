
package com.questdiagnostics.campaignservice.response.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "id", "initialId", "connectedId", "connectedType", "terminalType" })
public class OutputTerminal implements Serializable {

	@JsonProperty("type")
	private String type;
	@JsonProperty("id")
	private String id;
	@JsonProperty("initialId")
	private String initialId;
	@JsonProperty("connectedId")
	private String connectedId;
	@JsonProperty("connectedType")
	private String connectedType;
	@JsonProperty("terminalType")
	private String terminalType;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	private final static long serialVersionUID = -2493119776563916576L;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public OutputTerminal() {
	}

	/**
	 * 
	 * @param initialId
	 * @param id
	 * @param type
	 * @param connectedType
	 * @param connectedId
	 * @param terminalType
	 */
	public OutputTerminal(String type, String id, String initialId, String connectedId, String connectedType,
			String terminalType) {
		super();
		this.type = type;
		this.id = id;
		this.initialId = initialId;
		this.connectedId = connectedId;
		this.connectedType = connectedType;
		this.terminalType = terminalType;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("initialId")
	public String getInitialId() {
		return initialId;
	}

	@JsonProperty("initialId")
	public void setInitialId(String initialId) {
		this.initialId = initialId;
	}

	@JsonProperty("connectedId")
	public String getConnectedId() {
		return connectedId;
	}

	@JsonProperty("connectedId")
	public void setConnectedId(String connectedId) {
		this.connectedId = connectedId;
	}

	@JsonProperty("connectedType")
	public String getConnectedType() {
		return connectedType;
	}

	@JsonProperty("connectedType")
	public void setConnectedType(String connectedType) {
		this.connectedType = connectedType;
	}

	@JsonProperty("terminalType")
	public String getTerminalType() {
		return terminalType;
	}

	@JsonProperty("terminalType")
	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
