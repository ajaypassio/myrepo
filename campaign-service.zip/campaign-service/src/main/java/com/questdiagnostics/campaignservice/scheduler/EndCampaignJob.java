package com.questdiagnostics.campaignservice.scheduler;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.CampaignService;
import com.questdiagnostics.campaignservice.services.impl.CampaignServiceImpl;
import com.questdiagnostics.campaignservice.workflowengine.CampaignStateTransitionManager;

@Component
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class EndCampaignJob {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	@Autowired
	CampaignService campaignService;

	@Autowired
	CampaignServiceImpl campaignServiceImpl;
	@Autowired
	private CampaignMasterRepository campaignMasterRepository;
	@Autowired
	private ScheduleRepository scheduleRepository;
	@Autowired
	private CampaignStateTransitionManager campaignStateTransitionManager;
	private static SimpleDateFormat estDateFormat = new SimpleDateFormat("MM/dd/yyyy , hh:mm aa zzz");
	Calendar instance = null;

	@Scheduled(fixedDelayString = "${scheduler.cron.job.campaign}")
	public void startCronDataProcessor() throws EloquaException {
		
		//logger.info("Deploy to End job :: Execution Time - {}", dateTimeFormatter.format(LocalDateTime.now()));
		campaignMasterRepository
				.findByCampaignStatusId(SprinttCampaignStatus.DEPLOYED.getValue())
				.ifPresent(campaignList -> campaignList.forEach(campaign -> {
					//logger.info("--------ScheduleId------" + campaign.getScheduleId());
					scheduleRepository.findById(campaign.getScheduleId()).ifPresent(campaign::setSchedule);

					if (campaign.getSchedule() != null && campaign.getSchedule().getNormalizedEndDate().before(new Date())) {
						logger.info("---schedule end date is past date so marking it as end campaign--"
								+ "for campaignId" + campaign.getSprinttCampaignId());
						try {
							ResponseObjectModel responseObject = new ResponseObjectModel();
							campaignStateTransitionManager.execute(responseObject, campaign,
									SprinttCampaignStatus.CLOSED);
							instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
							/*campaign.setLastAction( CommonConstants.ENDED_ON.replace("#dateTime",
							estDateFormat.format(instance.getTime())));*/
							
							
							campaign.setLastAction(CommonConstants.ENDED_ON.replace("#dateTime", estDateFormat
									.format(instance.getTime()).replace(instance.getTimeZone().toString(), CommonConstants.EST))); 
							
							campaign.setNextAction(CommonConstants.BLANK);
							campaignMasterRepository.save(campaign);
						} catch (WorkflowEngineException e) {
							logger.error("Caught exception while trying to move campaign {} to {} : {}",
									campaign.getCampaignId(), SprinttCampaignStatus.CLOSED, e);
						}

					}
				}));
	}

}
