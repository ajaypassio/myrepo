/**
 * 
 */
package com.questdiagnostics.campaignservice.scheduler;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.async.service.PatientDeduplicationService;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.helper.ParticipantListHelper;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.util.CommonUtil;

/**
 * @author Ajay Kumar
 *
 */
@Component
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class PatientContactGenerator {

	private static final Logger logger = LoggerFactory.getLogger(PatientContactGenerator.class);

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	private ParticipantListHelper participantListHelper;

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private PatientDeduplicationService patientDeduplicationService;

	@Value("${batch.size.value}")
	private int batchSize;

	// @Scheduled(fixedDelayString =
	// "${scheduler.cron.job.fixeddelay.contact.upload}")
	public void processPatientContactIdGeneration() throws EloquaException {
		logger.info("Process started ========== {} ", System.currentTimeMillis());
		/* Fetch all campaigns which in success state */
		/* Update campaign in CONTACTS_UPLOAD_INITIATED state */
		fetchCamapigns();
		/* Call Eloqua to create contact id for a patient */
		/* Parse response and update participant table with eloqua contact id */
	}

	private void fetchCamapigns() throws EloquaException {
		EntityManager localEntityManager = entityManagerFactory.createEntityManager();
		campaignMasterRepository.fetchSheduleAndDraftCampaignsWithSucccess(
				Arrays.asList(CampaignJobStatus.Success.getValue(),
						CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue()),
				Arrays.asList(SprinttCampaignStatus.DEPLOYED.getValue(), SprinttCampaignStatus.SCHEDULED.getValue()))
				.forEach(campaignMaster -> {
					campaignMaster.setCampaignJobStatusId(CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue());
				//	commonUtil.buildUpdateAuditField(campaignMaster);
					commonUtil.buildUpdateAuditField(campaignMaster,CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue());
					campaignMasterRepository.save(campaignMaster);
					try {
						int offset = 0;
						List<Object[]> patientBatch = patientDeduplicationService.getDeduplicablePatientBatch(
								campaignMaster.getTrialId(), campaignMaster.getSprinttCampaignId(), batchSize, offset,
								localEntityManager);
						while (!CollectionUtils.isEmpty(patientBatch)) {
							participantListHelper.createContactsInEloquaBackend(patientBatch);
							offset = offset + batchSize;
							patientBatch = patientDeduplicationService.getDeduplicablePatientBatch(
									campaignMaster.getTrialId(), campaignMaster.getSprinttCampaignId(), batchSize,
									offset, localEntityManager);
						}
						campaignMaster.setCampaignJobStatusId(CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue());
					//	commonUtil.buildUpdateAuditField(campaignMaster);
						commonUtil.buildUpdateAuditField(campaignMaster,CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue());
						campaignMasterRepository.save(campaignMaster);
					} catch (EloquaException e) {
						logger.error("Failed the contact generation list === {} ", e.getMessage());
						campaignMaster.setCampaignJobStatusId(CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue());
					//	commonUtil.buildUpdateAuditField(campaignMaster);
						commonUtil.buildUpdateAuditField(campaignMaster,CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue());
						campaignMasterRepository.save(campaignMaster);
					}
				});
	}
}
