package com.questdiagnostics.campaignservice.scheduler;

import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.EloquaCampaignStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.manager.CampaignManager;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.services.CampaignService;
import com.questdiagnostics.campaignservice.services.impl.CampaignServiceImpl;
import com.questdiagnostics.campaignservice.workflowengine.CampaignStateTransitionManager;

@Component
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class ScheduleToDeployJob {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	@Autowired
	CampaignService campaignService;

	@Autowired
	CampaignServiceImpl campaignServiceImpl;
	@Autowired
	private CampaignMasterRepository campaignMasterRepository;
	@Autowired
	private ScheduleRepository scheduleRepository;
	@Autowired
	private CampaignManager campaignManager;
	@Autowired
	private CampaignStateTransitionManager campaignStateTransitionManager;

	@Scheduled(fixedDelayString = "${scheduler.cron.job.campaign}")
	public void startCronDataProcessor() throws EloquaException {
		//logger.info("Schedule to Deploy job :: Execution Time - {}", dateTimeFormatter.format(LocalDateTime.now()));
		campaignMasterRepository
				.findByCampaignStatusIdAndCampaignJobStatusId(SprinttCampaignStatus.SCHEDULED.getValue(),
						CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue())
				.ifPresent(campaignList -> campaignList.forEach(campaign -> {
					//logger.info("ScheduleId------" + campaign.getScheduleId());
					/*
					 * campaign.setSchedule(scheduleRepository.findById(campaign.getScheduleId()).
					 * get());
					 */
					scheduleRepository.findById(campaign.getScheduleId()).ifPresent(campaign::setSchedule);
					if (campaign.getSchedule() != null
							&& campaign.getSchedule().getNormalizedStartDateTime().before(new Date())) {
						EloquaCampaignStatus eloquaCampaignStatus = null;
						try {
							eloquaCampaignStatus = EloquaCampaignStatus.getStatusOf(
									campaignManager.getCampaignInEloqua(campaign.getCampaignId()).getCurrentStatus());
						} catch (Exception e) {

							logger.debug("Something went wrong in retriveing details of campaign for CampaignId"
									+ campaign.getCampaignId());
						}
						if (EloquaCampaignStatus.ACTIVE == eloquaCampaignStatus) {
							logger.info(
									"---schedule start date is past date and campaign is active on Eloqua so marking it to deployed in sprintt--"
											+ "for campaignId" + campaign.getSprinttCampaignId());
							try {
								campaign = campaignStateTransitionManager.forceExecute(campaign,
										SprinttCampaignStatus.DEPLOYED);
								campaignMasterRepository.save(campaign);
							} catch (WorkflowEngineException e) {
								logger.error("Caught exception while trying to move campaign {} to {} : {}",
										campaign.getCampaignId(), SprinttCampaignStatus.DEPLOYED, e);
							}
						} else {
							logger.debug("Something went wrong campaign is not deployed yet.");
						}
					}
				}));
	}

}
