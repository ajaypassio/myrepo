package com.questdiagnostics.campaignservice.scheduler;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.ReminderJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ReminderRepository;
import com.questdiagnostics.campaignservice.services.CampaignService;
import com.questdiagnostics.campaignservice.util.CommonUtil;

@Component
@ConditionalOnProperty(name = "spring.enable.scheduling")
public class UpdateLastAndNextAction {

	private Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy , hh:mm a zzz");
	static ZoneId etZoneId = ZoneId.of("America/New_York");

	@Autowired
	CampaignService campaignService;

	@Autowired
	ReminderRepository reminderRepository;

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	Calendar instance = null;

	@Scheduled(cron = "${scheduler.cron.job.update.nextlastaction}")
	public void updateLastAndNextAction() {
		LocalDateTime currentDateTime = LocalDateTime.now();
		ZonedDateTime localDateTime = currentDateTime.atZone(etZoneId);
		
		LOGGER.info("Deploy Campaigns Schedular started at {}", dateTimeFormatter.format(localDateTime));

		// commented 01-04-2020 cheking with new colum ReminderJobStatus
		/*campaignMasterRepository
				.findByCampaignJobStatusIdAndCampaignStatusIdIn(CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue(),
						Arrays.asList(SprinttCampaignStatus.DEPLOYED.getValue()))*/
		
		
	campaignMasterRepository
		.findByCampaignJobStatusIdAndCampaignStatusIdInAndReminderJobStatusIdNotIn(CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue(),
				Arrays.asList(SprinttCampaignStatus.DEPLOYED.getValue()),Arrays.asList(ReminderJobStatus.REMINDER_ON.getValue(),ReminderJobStatus.REMINDER_SENT.getValue(),
						                     ReminderJobStatus.SCHEDULAR_EMAIL_SENT.getValue()))
				.ifPresent(lastNextActionDataList -> {
					lastNextActionDataList.stream().forEach(lastNextActionData -> {
						
						LOGGER.info("Current Date check for schedule comaprision = " + new Date());
							
						Schedule schedule = campaignMasterRepository
								.getScheduleForLastNextAction(lastNextActionData.getScheduleId(), new Date());
					
						/*    // comment by Jyoti
 						 * Optional<List<Reminder>> reminderListOptional = reminderRepository
						 * .findByCampaignMaster(lastNextActionData);
						 */
						
						Optional<List<Reminder>> reminderListOptional = reminderRepository
								.getReminderBysprintCampaignId(lastNextActionData.getSprinttCampaignId());
						
						if (reminderListOptional.isPresent() )
						{
							if(schedule !=null)
							{
							List<Reminder> reminderList = reminderListOptional.get();
							LOGGER.info("Reminder block Scheduler Date  = " + schedule.getStartDateTime());
							
							// added timeZone changes
							TimeZone timeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(schedule.getTimezone()));
							String scheduleZoneFormat = CommonUtil.getDayLightSavingZone(
									 timeZone.inDaylightTime(schedule.getStartDateTime()),
									 schedule.getTimezone());
							
							TimeZone reminderTimeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(reminderList.get(0).getReminderTimeZone()));
							String timeZoneReminder = CommonUtil.getDayLightSavingZone(
									reminderTimeZone.inDaylightTime(reminderList.get(0).getRemindOnDateTime()),
									 reminderList.get(0).getReminderTimeZone());	
							
							campaignMasterRepository.updateNextLastAction(
									CommonUtil.populateNextLastActionWithTimeZone(CommonConstants.EMAIL_SENT_AT,
											schedule.getStartDateTime(),scheduleZoneFormat),
									
									CommonUtil.populateNextLastActionWithTimeZone(CommonConstants.REMINDER_AT,   
											reminderList.get(0).getRemindOnDateTime(),timeZoneReminder),
									
									ReminderJobStatus.SCHEDULAR_EMAIL_SENT.getValue(),
									lastNextActionData.getSprinttCampaignId());
							}

						} else {
							if(schedule !=null)
							{
								LOGGER.info("Scheduler block Scheduler Date  = " + schedule.getStartDateTime());	
							
								TimeZone timeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(schedule.getTimezone()));
								String scheduleZoneFormat = CommonUtil.getDayLightSavingZone(
										 timeZone.inDaylightTime(schedule.getStartDateTime()),
										 schedule.getTimezone());
								
								campaignMasterRepository.updateNextLastAction(
									CommonUtil.populateNextLastActionWithTimeZone(CommonConstants.EMAIL_SENT_AT,
											schedule.getStartDateTime(),scheduleZoneFormat),
									CommonConstants.BLANK, ReminderJobStatus.SCHEDULAR_EMAIL_SENT.getValue(),
									lastNextActionData.getSprinttCampaignId());
							}	
						}							
					});

				});

                  // commented 01-04-2020 cheking with new colum ReminderJobStatus
		/*campaignMasterRepository
				.findByCampaignStatusIdAndCampaignJobStatusIdIn(SprinttCampaignStatus.DEPLOYED.getValue(),
						Arrays.asList(CampaignJobStatus.SCHEDULAR_EMAIL_SENT.getValue(),
								CampaignJobStatus.REMINDER_ON.getValue()))*/
		
		campaignMasterRepository
		.findByCampaignStatusIdAndReminderJobStatusIdIn(SprinttCampaignStatus.DEPLOYED.getValue(),
				Arrays.asList(ReminderJobStatus.SCHEDULAR_EMAIL_SENT.getValue(),
						ReminderJobStatus.REMINDER_ON.getValue()))  
		
		
				.ifPresent(lastNextActionDataList -> {

					LOGGER.info("Deploy Campaign scheduler  block when Reminder exist" );	
					
					lastNextActionDataList.stream().forEach(lastNextActionData -> {
						if (lastNextActionData != null) {
							
							   // Comment by Jyoti
							/*Optional<List<Reminder>> reminderListOptional = reminderRepository
									.findByCampaignMaster(lastNextActionData);*/
							
							Optional<List<Reminder>> reminderListOptional = reminderRepository
									.getReminderBysprintCampaignId(lastNextActionData.getSprinttCampaignId());

							if (reminderListOptional.isPresent()) {

								AtomicInteger counter = new AtomicInteger(0);

								AtomicReference<String> nextAction = new AtomicReference<>();
								AtomicReference<String> lastAction = new AtomicReference<>();

								AtomicInteger counterLastReminder = new AtomicInteger(0);
								List<Reminder> remiderList = reminderListOptional.get();
								
								remiderList.stream().sorted(Comparator.comparing(Reminder::getRemindOnDateTime))
										.forEach(reimnder -> {
											
							LOGGER.info("Check Reminder date equals current date :"+(reimnder.getRemindOnDateTime().equals(new Date())));
							LOGGER.info("Check Reminder date before current date :"+(reimnder.getRemindOnDateTime().before(new Date())));
											
									if ((reimnder.getIsReminderSent()!=null && reimnder.getIsReminderSent() != 1)
											&& (reimnder.getRemindOnDateTime().equals(new Date())
											|| reimnder.getRemindOnDateTime().before(new Date()))) {
												
												// added TimeZone changes
									TimeZone reminderTimeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(reimnder.getReminderTimeZone()));
									String timeZoneReminder = CommonUtil.getDayLightSavingZone(
											 reminderTimeZone.inDaylightTime(reimnder.getRemindOnDateTime()),
											 reimnder.getReminderTimeZone());	
												
												lastAction.set(CommonUtil
														.populateNextLastActionWithTimeZone(CommonConstants.REMINDER_SENT_AT,    
																reimnder.getRemindOnDateTime(),timeZoneReminder)
														.replace("#reminder", ""));
												reimnder.setIsReminderSent(1);
												campaignMasterRepository.updateReminderIsSent(1,
														reimnder.getReminderId());
												if (counter.intValue() == 1) {
													nextAction.set(CommonUtil
															.populateNextLastActionWithTimeZone(CommonConstants.NEXT_REMINDER_AT,  
																	reimnder.getRemindOnDateTime(),timeZoneReminder)
															.replace("#reminder", ""));
												}
												if (counter.intValue() == 0 && counterLastReminder.intValue() == 0) {
													lastAction.set(CommonUtil
															.populateNextLastActionWithTimeZone(CommonConstants.REMINDER_SENT_AT,  
																	reimnder.getRemindOnDateTime(),timeZoneReminder)
															.replace("#reminder", ""));
													nextAction.set(CommonConstants.BLANK);
													campaignMasterRepository.updateNextLastAction(lastAction.get(),
															nextAction.get(),
															ReminderJobStatus.REMINDER_SENT.getValue(),
															lastNextActionData.getSprinttCampaignId());
													counterLastReminder.getAndIncrement();
												}
												counter.getAndIncrement();

											} else {
												counterLastReminder.getAndIncrement();

												if (remiderList.size() == counterLastReminder.intValue()
														&& ( reimnder.getIsReminderSent() == null || reimnder.getIsReminderSent() == 0 )) {

													// added TimeZone changes
													TimeZone reminderTimeZone = TimeZone.getTimeZone(
															CommonUtil.getTimeZone(reimnder.getReminderTimeZone()));
													String timeZoneReminder = CommonUtil.getDayLightSavingZone(
															reminderTimeZone
																	.inDaylightTime(reimnder.getRemindOnDateTime()),
															reimnder.getReminderTimeZone());
																
													
													campaignMasterRepository.updateNextLastAction(
															CommonUtil.populateNextLastActionWithTimeZone(
																	CommonConstants.EMAIL_SENT_AT, null,timeZoneReminder), 
															CommonUtil.populateNextLastActionWithTimeZone(
																	CommonConstants.NEXT_REMINDER_AT,   // reminder to be sent at
																	reimnder.getRemindOnDateTime(),timeZoneReminder)
																	.replace("#reminder", "").toString(),
																	ReminderJobStatus.REMINDER_ON.getValue(),
															lastNextActionData.getSprinttCampaignId());
												}

										if (remiderList.size() == counterLastReminder.intValue()
														&& (reimnder.getIsReminderSent()!=null &&reimnder.getIsReminderSent() == 1)) {			
													
													// added TimeZone changes
													TimeZone reminderTimeZone = TimeZone.getTimeZone(
															CommonUtil.getTimeZone(reimnder.getReminderTimeZone()));
													String timeZoneReminder = CommonUtil.getDayLightSavingZone(
															reminderTimeZone
																	.inDaylightTime(reimnder.getRemindOnDateTime()),
															reimnder.getReminderTimeZone());
													

													campaignMasterRepository.updateNextLastAction(
														CommonUtil.populateNextLastActionWithTimeZone(
						                    			CommonConstants.REMINDER_SENT_AT, reimnder.getRemindOnDateTime(),timeZoneReminder) 
															.replace("#reminder", ""),
															CommonConstants.BLANK,
															ReminderJobStatus.REMINDER_SENT.getValue(),
															lastNextActionData.getSprinttCampaignId());
												}
											}

										});


								if (nextAction.get() != null && lastAction.get() != null) {
									campaignMasterRepository.updateNextLastAction(lastAction.get(), nextAction.get(),
											ReminderJobStatus.REMINDER_ON.getValue(),
											lastNextActionData.getSprinttCampaignId());

								}

							}
						}
					});
				});
		LOGGER.info("Deploy Campaigns Schedular ended at ===>>>" + dateTimeFormatter.format(localDateTime));
	}

}
