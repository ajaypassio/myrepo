/**
 * 
 */
package com.questdiagnostics.campaignservice.services;

import java.io.Serializable;
import java.net.URISyntaxException;
import java.util.concurrent.CompletableFuture;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.exception.CampaignServiceException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;
import com.questdiagnostics.campaignservice.request.model.CampaignRequest;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

/**
 * @author Ajay Kumar
 *
 */
public interface CampaignService extends Serializable {

	/**
	 * @param campaignMaster
	 * @throws URISyntaxException
	 * @throws JsonProcessingException
	 */
	ResponseObjectModel activateCampaign(Long sprinttCampaignId, boolean now) throws CampaignServiceException;

	ResponseObjectModel activateAScheduledCampaign(Long sprinttCampaignId) throws CampaignServiceException;

	ResponseObjectModel reScheduleAScheduledCampaign(Long sprinttCampaignId) throws CampaignServiceException;

	ResponseObjectModel deactivateCampaign(Long sprinttCampaignId) throws CampaignServiceException;

	ResponseObjectModel createDraftCampaign(CampaignMaster campaignData, Boolean isCombined)
			throws EloquaException, URISyntaxException, JsonProcessingException;

	ResponseObjectModel updateCampaign(CampaignMaster campaignMaster, boolean now)
			throws EloquaException, URISyntaxException, JsonProcessingException;

	/**
	 * @param sprinttCampaignId
	 *            return ResponseObjectModel
	 */
	ResponseObjectModel getCampaign(Long sprinttCampaignId);

	/**
	 * @param trialId
	 * @return
	 */
	public ResponseObjectModel getCampaignsForTrial(Long trialId);

	public ResponseObjectModel deployScheduleCampaign(Long campaignId, boolean isDeployed);

	ResponseObjectModel discardCampaign(Long campaignId) throws WorkflowEngineException, EloquaException;

	public ResponseObjectModel reconsiderCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException;

	ResponseObjectModel endCampaign(Long sprinttCampaignId) throws CampaignServiceException, WorkflowEngineException;

	ResponseObjectModel deployDraftScheduleCampaign(Long campaignId, boolean now) throws CampaignServiceException;

	ResponseObjectModel isPatientListGenerated(Long sprinttCampaignId);

	ResponseObjectModel isCampDeployedForTrial(String trialId);

	public CompletableFuture<CampaignMaster> enableAsyncDeployCampaignProcess(CampaignMaster campaignMasterObj);

	ResponseObjectModel reconsiderEndedCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException;

	ResponseObjectModel getCampaignByEloquaId(String eloquaCampaignId);

	ResponseObjectModel createDraftMyQuestCampaign(CampaignMasterMyQuest campaignDataMyQuest, Boolean isCombined);

	ResponseObjectModel getImages(Long trialId);

	ResponseObjectModel deleteTrialImage(Long trialId, String imageName);

	ResponseObjectModel uploadFiles(MultipartFile file[], Long trialId);

	ResponseObjectModel getImageSASUrl(Long trialId, String imageName);

	ResponseObjectModel updateDraftMyQuestCampaign(CampaignMasterMyQuest campaignDataMyQuest);

	ResponseObjectModel getMyQuestCampaign(Long sprinttCampaignId);

	ResponseObjectModel createCampaign(CampaignRequest campaignRequest)
			throws ResponseStatusException, EloquaException, JsonProcessingException, URISyntaxException;

	ResponseObjectModel endMyQuestCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException;

	ResponseObjectModel discardMyQuestCampaign(Long campaignId) throws WorkflowEngineException;

	public ResponseObjectModel reconsiderMyQuestCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException;
}
