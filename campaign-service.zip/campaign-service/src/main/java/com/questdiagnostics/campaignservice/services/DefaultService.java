package com.questdiagnostics.campaignservice.services;

import java.net.URISyntaxException;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.response.model.DefaultCampaignResponse;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public interface DefaultService {

	public DefaultCampaignResponse persistDefault(Schedule schedule, Reminder reminder,EmailTemplate emailTemplate);

	 Schedule persistDefaultScheduler(Schedule schedule);

	 Reminder persistDefaultReminder(Reminder reminder);

	 public DefaultCampaignResponse updateDefault(Schedule scheduleRequest, Reminder reminderRequest,EmailTemplate emailTemplateRequest);

	 Schedule updateDefaultSchedule(Schedule schedule);

	 Reminder updateDefaultReminder(Reminder reminder);

	// DefaultCampaignResponse getDefault(Long trialId);
	 public ResponseObjectModel getDefault(Long trialId);

	 Schedule getDefaultSchedule(Long trialId);

	 Reminder getDefaultReminder(Long trialId);
	
	 List<EmailTemplateResponse> getListOfEmail() throws JsonProcessingException, URISyntaxException;
	 
	 EmailTemplate persistEmailTempalte(EmailTemplate emailTemplate);
	
	 public EmailTemplate updateEmailTempalte(EmailTemplate emailTemplate);
	 
	 EmailTemplate getEmailTemplateByTrialId(Long trialId);
	 
	 //Added for Schedule and Reminder Null during set default
	 
	 Schedule persistSchedule(Schedule schedule);
	 Reminder persistReminder(Reminder reminder);
	 

}
