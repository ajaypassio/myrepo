package com.questdiagnostics.campaignservice.services;

import java.io.Serializable;
import java.net.URISyntaxException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.model.PauboxCampaignMaster;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public interface PauboxCampaignService extends Serializable {

	ResponseObjectModel createSprinttPauboxCampaign(PauboxCampaignMaster pauboxCampaignData, Boolean isCombined)
			throws URISyntaxException, JsonProcessingException;
	
	ResponseObjectModel updatePauboxCampaign(PauboxCampaignMaster pauboxCampaignData, boolean now)
			throws URISyntaxException, JsonProcessingException;
	
	ResponseObjectModel getPauboxCampaign(Long sprinttCampaignId);
}
