package com.questdiagnostics.campaignservice.services;

import java.io.Serializable;
import java.net.URISyntaxException;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.campaignservice.model.PhysicianEmailOutreach;
import com.questdiagnostics.campaignservice.request.model.PhysicianCampaignRequest;
import com.questdiagnostics.campaignservice.request.model.PhysicianUpdateCampaignRequest;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public interface PhysicianCampaignService extends Serializable {
	
	ResponseObjectModel createPhysicianCampaign(PhysicianCampaignRequest physicianCampaignRequest );
	
	ResponseObjectModel getPhysicianCampaigns(String campaignName);
	
	PhysicianCampaignMaster updatePhysicianCampaignStatusId(PhysicianUpdateCampaignRequest physicianUpdateCampaignRequest);

	List<PhysicianCampaignMaster> getEligibleCampaigns();
	
	List<PhysicianCampaignMaster> getCampaignsWithCreationIncomplete();

	ResponseObjectModel getPhysicianCampaignEmailOutreach(Long campaignId);
	
	List<EmailTemplateResponse> getListOfEmail() throws JsonProcessingException, URISyntaxException;
	
	ResponseObjectModel createPhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach);

	ResponseObjectModel updatePhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach);
	
	ResponseObjectModel getCampaignStatusByUserName(String userName);
	
	ResponseObjectModel schedulePhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach);

	PhysicianEmailOutreach getPhysicianEmailOutreach(Long campaignId);
	
}
