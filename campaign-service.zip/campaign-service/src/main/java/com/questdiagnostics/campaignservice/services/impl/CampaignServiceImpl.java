package com.questdiagnostics.campaignservice.services.impl;

import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_SEGMENT;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.constant.LoggingConstants;
import com.questdiagnostics.campaignservice.constant.MessageConstants;
import com.questdiagnostics.campaignservice.dto.CampaignListGroup;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.ChannelType;
import com.questdiagnostics.campaignservice.enums.EloquaCampaignStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.CampaignServiceException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.helper.ParticipantListHelper;
import com.questdiagnostics.campaignservice.helper.ValidationHelper;
import com.questdiagnostics.campaignservice.manager.CampaignManager;
import com.questdiagnostics.campaignservice.messaging.NotificationPublisher;
import com.questdiagnostics.campaignservice.messaging.models.NotificationPayload;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.CampaignMasterMyQuest;
import com.questdiagnostics.campaignservice.model.CampaignModel;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.MyQuestTransactionOutBox;
import com.questdiagnostics.campaignservice.model.PauboxCampaignMaster;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.model.StudyInfo;
import com.questdiagnostics.campaignservice.repository.CampaignMasterMyQuestRepository;
import com.questdiagnostics.campaignservice.repository.CampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.EmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.MyQuestTransactionOutBoxRepository;
import com.questdiagnostics.campaignservice.repository.PauboxCampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.ReminderRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.repository.StudyInfoRepository;
import com.questdiagnostics.campaignservice.request.model.CampaignRequest;
import com.questdiagnostics.campaignservice.response.model.Element;
import com.questdiagnostics.campaignservice.response.model.EloquaCampaignResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.CampaignService;
import com.questdiagnostics.campaignservice.services.PauboxCampaignService;
import com.questdiagnostics.campaignservice.util.CommonUtil;
import com.questdiagnostics.campaignservice.util.Constants;
import com.questdiagnostics.campaignservice.util.RESTUtils;
import com.questdiagnostics.campaignservice.util.SasGenerationUtil;
import com.questdiagnostics.campaignservice.util.StudyUrlUtility;
import com.questdiagnostics.campaignservice.workflowengine.CampaignStateTransitionManager;

/**
 * @author Ajay Kumar
 *
 */
@Service
public class CampaignServiceImpl implements CampaignService {

	private static final long serialVersionUID = 1847351051177697889L;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CampaignMasterRepository campaignMasterRepository;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private ReminderRepository reminderRepository;

	@Autowired
	private CampaignMasterMyQuestRepository campaignMasterMyQuestRepository;

	@Autowired
	private StudyInfoRepository studyInfoRepo;

	@Autowired
	MyQuestTransactionOutBoxRepository myQuestTransactionOutBoxRepo;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RESTUtils restUtils;

	@Autowired
	private CampaignStateTransitionManager campaignStateTransitionManager;

	@Autowired
	private CampaignManager campaignManager;

	@Autowired
	private ParticipantListHelper participantListHelper;

	@Value("${sprintt.candidate.service.generate.patient.url}")
	private String candidateServiceGenPatientUrl;
	
	@Autowired
	NotificationPublisher notificationPublisher;
	
	@Autowired
	private PauboxCampaignMasterRepository pauboxCampaignMasterRepository;

	@Autowired
	SasGenerationUtil sasGenerationUtil;

	@Autowired
	StudyUrlUtility studyUrlUtility;
	
	@Autowired
	private PauboxCampaignService pauboxCampaignService;

	private static SimpleDateFormat estDateFormat = new SimpleDateFormat("MM/dd/yyyy , hh:mm aa zzz");
	private static SimpleDateFormat uiDateFormat = new SimpleDateFormat("MM/dd/yyyy , hh:mm aa zzz");
	Calendar instance = null;

	static {
		estDateFormat.setTimeZone(TimeZone.getTimeZone(CommonConstants.EST));
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel createDraftCampaign(CampaignMaster campaignData, Boolean isCombined)
			throws EloquaException, JsonProcessingException, URISyntaxException, ResponseStatusException {
		ResponseObjectModel responseObject = persistCampaignData(campaignData, isCombined);

		if (!responseObject.getMessage().equals(LoggingConstants.CAMPAIGN_ALREADY_EXIST)) {
			CampaignMaster campMaster = (CampaignMaster) responseObject.getData();

			if (campMaster.getSchedule() != null) {
				logger.debug("The Start date value : {}", campMaster.getSchedule().getNormalizedStartDateTime());
				logger.debug("The end date value : {}", campMaster.getSchedule().getNormalizedEndDate());
			}
			
			//Add the queue call here
			updateCampaignWithEloquaResponseForCreate(campMaster.getSprinttCampaignId(),
				campaignManager.createCampaignInEloqua(campMaster));

			/* Initiate patient list generation */
			campaignPatientGeneration(campMaster);
		}
		return responseObject;
	}

	private void campaignPatientGeneration(CampaignMaster campaignMaster) {
		Long sprinttCampaignId = campaignMaster.getSprinttCampaignId();
		CompletableFuture.supplyAsync(() -> {
			HttpHeaders headers = CommonUtil.prepareHeader();
			HttpEntity<CampaignModel> httpEntity = new HttpEntity<>(generateCandidateServiePostObject(campaignMaster),
					headers);
			return restTemplate.postForEntity(candidateServiceGenPatientUrl, httpEntity, Boolean.class).getBody();
		}).whenComplete((result, ex) -> {
			if (!ObjectUtils.isEmpty(ex)) {
				/* Update campaign master */
				updateCampaignJobStatus(sprinttCampaignId, CommonConstants.PATIENT_LIST_FAILED,
						CampaignJobStatus.Failed);
			}
		}).thenAcceptAsync(jobStatus -> {
			if (jobStatus.booleanValue()) {
				/* Update campaign master */
				updateCampaignJobStatus(sprinttCampaignId, CommonConstants.PATIENT_LIST_GENERATED,
						CampaignJobStatus.Fecthed);
			} else {
				/* Update campaign master */
				updateCampaignJobStatus(sprinttCampaignId, CommonConstants.PATIENT_LIST_FAILED,
						CampaignJobStatus.Failed);
			}
		});

	}

	private CampaignModel generateCandidateServiePostObject(CampaignMaster campaignMaster) {
		CampaignModel campaignModel = new CampaignModel();
		campaignModel.setSprinttCampaignId(campaignMaster.getSprinttCampaignId());
		campaignModel.setTrialId(campaignMaster.getTrialId());
		campaignModel.setDifference(campaignMaster.isDifference());
		campaignModel.setInclusionCriteria(campaignMaster.getInclusionCriteria());
		campaignModel.setExclusionCriteria(campaignMaster.getExclusionCriteria());
		campaignModel.setChannel(campaignMaster.getChannel());
		campaignModel.setCampaignStatus(SprinttCampaignStatus.DRAFT.name());
		return campaignModel;
	}

	private void updateCampaignJobStatus(Long sprinttCampaignId, String remarks, CampaignJobStatus staus) {
		campaignMasterRepository.findById(sprinttCampaignId).ifPresent(campaignMaster -> {

			// append remarks
			campaignMaster.setRemarks(
					CommonUtil.populateCampaignRemarks("", CommonConstants.PATIENT_LIST_GENERATION_STARTED));

			campaignMaster.setCampaignJobStatusId(staus.getValue());
			campaignMasterRepository.save(campaignMaster);
		});

	}

	private ResponseObjectModel persistCampaignData(CampaignMaster requestCampaignMaster, Boolean isCombined) {
		logger.info("persist campaign data: {} ", requestCampaignMaster);
		EmailTemplate emailTemplate = null;
		Schedule scheduleDet = null;
		ResponseObjectModel responseObject = new ResponseObjectModel();
		List<Reminder> remindersList = new ArrayList<>();

		CampaignMaster campaignMaster = campaignMasterRepository.findByCampaignNameAndTrialId(
				requestCampaignMaster.getCampaignName(), requestCampaignMaster.getTrialId());

		if (campaignMaster != null && !isCombined.equals(Boolean.TRUE)) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_ALREADY_EXIST_LOG);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Name Already Exists");
			return responseObject;
		} else {

			// set Initial Draft campaign
			requestCampaignMaster.setCampaignStatusId(SprinttCampaignStatus.DRAFT.getValue());

			if (!ObjectUtils.isEmpty(requestCampaignMaster.getReminders())) {
				for (Reminder reminder : requestCampaignMaster.getReminders()) {
					if (reminder.isUseDefault()) {

						// call DB to get default reminder ID to insert into
						// campaign master
						Optional<Reminder> reminders = reminderRepository
								.findByTrialIdAndDefaultReminder(requestCampaignMaster.getTrialId(), 1);
						if (reminders.isPresent()) {
							Reminder reminderValue = new Reminder();
							reminderValue.setDefaultReminder(0);
							reminderValue.setCreatedOn(new Date());
							reminderValue.setReminderTimeZone(reminders.get().getReminderTimeZone());
							reminderValue.setRemindOnDateTime(reminders.get().getRemindOnDateTime());
							reminderValue.setRemindTo(reminders.get().getRemindTo());
							reminderValue.setTrialId(reminders.get().getTrialId());
							reminderValue.setCreatedBy(reminders.get().getCreatedBy());
							reminderValue.setUseDefault(true);
							reminderValue.setCampaignMaster(requestCampaignMaster);
							remindersList.add(reminderValue);
						} else {
							Reminder reminderValue = null;
							remindersList.add(reminderValue);
						}

					} else {
						logger.debug("Reminder Data: {} ", reminder);
						reminder.setTrialId(requestCampaignMaster.getTrialId());
						reminder.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminder));
						reminder.setCreatedOn(new Date());
						reminder.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminder.getRemindOnDateTime(),
								reminder.getReminderTimeZone()));
						reminder.setDefaultReminder(0);
						remindersList.add(reminder);

					}
				}
				requestCampaignMaster.setReminders(remindersList);
			}
			if (!ObjectUtils.isEmpty(requestCampaignMaster.getSchedule())) {
				if (requestCampaignMaster.getSchedule().isUseDefault()) {
					// call DB to get default schedule ID to insert into
					// campaign master
					Optional<Schedule> schedulePersist = scheduleRepository
							.findByTrialIdAndDefaultSchedule(requestCampaignMaster.getTrialId(), 1);
					if (schedulePersist.isPresent()) {
						Schedule schedule = new Schedule();

						schedule.setTrialId(requestCampaignMaster.getTrialId());
						schedule.setCreatedBy(schedulePersist.get().getCreatedBy());
						schedule.setEndDate(schedulePersist.get().getEndDate());
						schedule.setStartDateTime(schedulePersist.get().getStartDateTime());
						schedule.setTimezone(schedulePersist.get().getTimezone());
						schedule.setUseDefault(true);
						schedule.setDefaultSchedule(0);
						schedule.setCreatedOn(new Date());
						scheduleDet = scheduleRepository.save(schedule);

						// poplate RequestCamapaignMaster
						requestCampaignMaster.setScheduleId(scheduleDet.getScheduleId());
						requestCampaignMaster.setSchedule(scheduleDet);

					}
				} else {
					logger.debug("Schedule Data: {} ", requestCampaignMaster.getSchedule());
					scheduleDet = requestCampaignMaster.getSchedule();
					scheduleDet.setTrialId(requestCampaignMaster.getTrialId());
					scheduleDet.setDefaultSchedule(requestCampaignMaster.getSchedule().isUseDefault() ? 1 : 0);
					scheduleDet.setCreatedOn(new Date());
					scheduleDet = scheduleRepository.save(requestCampaignMaster.getSchedule());
					requestCampaignMaster.setScheduleId(scheduleDet.getScheduleId());
				}

				instance = Calendar
						.getInstance(TimeZone.getTimeZone(requestCampaignMaster.getSchedule().getTimezone()));

				// Next action Populated
				TimeZone timeZone = TimeZone
						.getTimeZone(CommonUtil.getTimeZone(requestCampaignMaster.getSchedule().getTimezone()));

				String timeZoneFormat = CommonUtil.getDayLightSavingZone(
						timeZone.inDaylightTime(requestCampaignMaster.getSchedule().getStartDateTime()),
						requestCampaignMaster.getSchedule().getTimezone());

				requestCampaignMaster
						.setNextAction(
								CommonConstants.EMAIL_TO_BE_SENT_AT
										.replace("#dateTime",
												uiDateFormat
														.format(requestCampaignMaster.getSchedule().getStartDateTime()))
										.replace("GMT", timeZoneFormat));

				requestCampaignMaster.setLastAction(CommonConstants.SCHEDULED_SUCCESSFULLY.replace("#dateTime",
						estDateFormat.format(instance.getTime()).replace(instance.getTimeZone().toString(),
								requestCampaignMaster.getSchedule().getTimezone())));
			} else {

				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				requestCampaignMaster.setLastAction(CommonConstants.DRAFT_CREATED.replace("#dateTime", estDateFormat
						.format(instance.getTime()).replace(instance.getTimeZone().toString(), CommonConstants.EST)));

				requestCampaignMaster.setNextAction(CommonConstants.BLANK);
			}
			if (requestCampaignMaster.getEmailTemplate() != null) {
				if (requestCampaignMaster.getEmailTemplate().isUseDefault()) {
					// call DB to get default schedule ID to insert into
					// campaign master
					emailTemplate = emailTemplateRepository
							.findByTrialIdAndDefaultEmailTemp(requestCampaignMaster.getTrialId(), 1);
					if (emailTemplate != null) {
						requestCampaignMaster.setEmailTemplateId(emailTemplate.getEmailTemplateId());
					}
				} else {
					logger.debug("Email Template Data: {} ", requestCampaignMaster.getEmailTemplate());
					emailTemplate = requestCampaignMaster.getEmailTemplate();
					emailTemplate.setTrialId(requestCampaignMaster.getTrialId());
					emailTemplate.setDefaultEmailTemp(requestCampaignMaster.getEmailTemplate().isUseDefault() ? 1 : 0);
					emailTemplate.setCreatedOn(new Date());
					// call DB to get default emailTemplate ID to insert into
					// campaign master
					emailTemplate = emailTemplateRepository.save(emailTemplate);
					requestCampaignMaster.setEmailTemplateId(emailTemplate.getEmailTemplateId());
				}

			}
		}

		// check for Campaign Status
		if (requestCampaignMaster.getSchedule() != null) {
			// set Status of Campaign
			requestCampaignMaster.setCampaignStatusId(SprinttCampaignStatus.SCHEDULED.getValue());
		}

		// requestCampaignMaster.setCreatedOn(estDateFormat.format(instance.getTime()));
		requestCampaignMaster.setCreatedOn(instance.getTime());
		requestCampaignMaster.setChannel(ChannelType.ELOQUA.getValue());
		logger.info("Campaign data before save: {}  ", requestCampaignMaster);
		CampaignMaster master = campaignMasterRepository.save(requestCampaignMaster);
		responseObject.setData(master);
		responseObject.setMessage("Success");
		responseObject.setHttpStatus(HttpStatus.OK);
		
		if(requestCampaignMaster.getSchedule() != null){
			notificationPublisher.publishNotification(buildNotificationPayload(master, CommonConstants.SCHEDULED_ELOQUA_PATIENT_CAMPAIGN_START));
		}
			
		return responseObject;
	}

	// samarth
	private void updateCampaignWithEloquaResponseForCreate(Long sprinttCampaignId,
			EloquaCampaignResponse campaignResponse) {
		campaignMasterRepository.findById(sprinttCampaignId).ifPresent(campaignMaster -> {
			campaignMaster.setCampaignId(campaignResponse.getId());
			campaignMaster.setCampaignJobStatusId(CampaignJobStatus.Initiated.getValue());
			campaignMaster.setEloCampgnStatusId(
					EloquaCampaignStatus.valueOf(campaignResponse.getCurrentStatus().toUpperCase()).getValue());
			/* iterate and find segment id of eloqua */
			for (Element element : campaignResponse.getElements()) {
				if (element.getType().equalsIgnoreCase(CAMPAIGN_SEGMENT.getType()))
					campaignMaster.setSegmentId(Long.valueOf(element.getSegmentId()));
			}
			if (!CollectionUtils.isEmpty(campaignMaster.getReminders())) {
				List<Reminder> reminders = new ArrayList<>(campaignMaster.getReminders());
				campaignMaster.setReminders(reminders);
			}
			campaignMasterRepository.save(campaignMaster);
		});
	}

	@Override
	public ResponseObjectModel getCampaign(Long sprinttCampaignId) {

		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		List<Reminder> remindersData = new ArrayList<>();
		if (StringUtils.isEmpty(sprinttCampaignId) || sprinttCampaignId == 0) {
			logger.info(MessageConstants.CAMPAIGN_ID_MNDT);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_ID_MNDT);
			return responseObjectModel;
		}
		Optional<CampaignMaster> existingCampaignMaster = campaignMasterRepository.findById(sprinttCampaignId);
		if (existingCampaignMaster.isPresent()) {
			CampaignMaster campaignMaster = existingCampaignMaster.get();
			List<Reminder> reminder = campaignMaster.getReminders();
			if (reminder != null && reminder.size() > 0) {
				reminder.sort(Comparator.comparing(Reminder::getRemindOnDateTime));
			}
			for (Reminder reminderData : reminder) {
				Reminder reminderDBC = CommonUtil.getUIValuesforRemindTo(reminderData);
				reminderData.setNonClicked(reminderDBC.getNonClicked());
				reminderData.setNonOpener(reminderDBC.getNonOpener());
				reminderData.setStatus(CommonUtil.getStatus(reminderData, campaignMaster.getCampaignStatusId()));
				remindersData.add(reminderData);
			}

			campaignMaster.setReminders(null);
			campaignMaster.setReminders(remindersData);

			Long scheduleId = campaignMaster.getScheduleId();
			Long emailTemplateId = campaignMaster.getEmailTemplateId();
			if (scheduleId != null && scheduleId != 0) {
				Optional<Schedule> scheduleDB = scheduleRepository.findById(scheduleId);
				if (scheduleDB.isPresent()) {
					Schedule schedulePersist = scheduleDB.get();
					if (schedulePersist.getDefaultSchedule() == 1)
						schedulePersist.setUseDefault(true);
					else
						schedulePersist.setUseDefault(false);
					campaignMaster.setSchedule(schedulePersist);

				}
			}
			if (emailTemplateId != null && emailTemplateId != 0) {
				Optional<EmailTemplate> emailTempDB = emailTemplateRepository.findById(emailTemplateId);

				if (emailTempDB.isPresent()) {
					campaignMaster.setEmailTemplate(emailTempDB.get());
				}
			}
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage("Success");
			responseObjectModel.setData(campaignMaster);
			return responseObjectModel;
		} else {
			logger.info(MessageConstants.CAMPAIGN_NOT_EXIST);
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
			return responseObjectModel;
		}
	}

	@Override
	public ResponseObjectModel updateCampaign(CampaignMaster campaignMaster, boolean now)
			throws URISyntaxException, JsonProcessingException, EloquaException {
		List<Reminder> reminders = new ArrayList<>();
		EmailTemplate emailTemplate = null;
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		CampaignMaster campaignMasterDB = campaignMasterRepository
				.findBySprinttCampaignId(campaignMaster.getSprinttCampaignId());

		if (campaignMaster.getSchedule() != null && campaignMaster.getSchedule().getScheduleId() != null) {
			Optional<Schedule> scheduleFrmDB = scheduleRepository
					.findById(campaignMaster.getSchedule().getScheduleId());
			if (scheduleFrmDB.isPresent()) {
				if (campaignMasterDB.getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())
						&& (campaignMasterDB.getCampaignJobStatusId()
								.equals(CampaignJobStatus.CONTACT_LIST_UPLOAD_FAILED.getValue()))
						|| campaignMasterDB.getCampaignJobStatusId()
								.equals(CampaignJobStatus.CONTACT_LIST_UPLOAD_IN_PROGRESS.getValue())) {

					logger.info(CommonConstants.CAMPAIGN_SCHEDULING_IN_PROGRESS);
					responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
					responseObjectModel.setMessage(CommonConstants.CAMPAIGN_SCHEDULING_IN_PROGRESS);
					return responseObjectModel;
				} else if (campaignMasterDB.getCampaignJobStatusId()
						.equals(CampaignJobStatus.CONTACT_LIST_EMPTY.getValue())) {
					responseObjectModel.setMessage(CommonConstants.CAMPAIGN_FAILED_EMPTY_CONTACT_LIST);
					responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
					return responseObjectModel;
				}
			}

		}

		campaignMasterDB.setCampaignName(campaignMaster.getCampaignName());

		// reminder details
		if (!ObjectUtils.isEmpty(campaignMaster.getReminders())) {
			for (Reminder reminder : campaignMaster.getReminders()) {
				if (reminder.isUseDefault()) {
					Optional<Reminder> reminderDB = reminderRepository
							.findByTrialIdAndDefaultReminder(campaignMaster.getTrialId(), 1);
					if (reminderDB.isPresent()) {
						Reminder reminderValue = new Reminder();
						reminderValue.setDefaultReminder(0);
						reminderValue.setCreatedOn(new Date());
						reminderValue.setNonClicked(reminderDB.get().getNonClicked());
						reminderValue.setNonOpener(reminderDB.get().getNonOpener());
						reminderValue.setReminderTimeZone(reminderDB.get().getReminderTimeZone());
						reminderValue.setRemindOnDateTime(reminderDB.get().getRemindOnDateTime());
						reminderValue.setRemindTo(reminderDB.get().getRemindTo());
						reminderValue.setUseDefault(true);
						reminderValue.setTrialId(reminderDB.get().getTrialId());
						reminderValue.setCampaignMaster(campaignMasterDB);
						reminders.add(reminderValue);
					} else {
						reminders = null;
					}
				} else {
					if (!ObjectUtils.isEmpty(reminder.getReminderId())
							&& ObjectUtils.isEmpty(reminder.getRemindOnDateTime())) {
						logger.info("Reminder Value Before Deletion: {}  ", reminder);
						reminderRepository.deleteReminder(reminder.getReminderId());
					} else if (ObjectUtils.isEmpty(reminder.getReminderId())) {
						reminder.setTrialId(campaignMaster.getTrialId());
						reminder.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminder));
						reminder.setUpdatedOn(new Date());
						reminder.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminder.getRemindOnDateTime(),
								reminder.getReminderTimeZone()));
						reminder.setDefaultReminder(0);
						reminders.add(reminder);
					}
				}
			}
			campaignMasterDB.setReminders(reminders);
		}

		// schedule details

		if (!ObjectUtils.isEmpty(campaignMaster.getSchedule())) {
			if (campaignMaster.getSchedule().useDefault) {
				scheduleRepository.findByTrialIdAndDefaultSchedule(campaignMaster.getTrialId(), 1)
						.ifPresent(defaultShedule -> {
							defaultShedule.setUseDefault(true);
							campaignMasterDB.setScheduleId(defaultShedule.getScheduleId());
							campaignMasterDB.setSchedule(defaultShedule);
						});
			} else {

				Schedule scheduleRequest = campaignMaster.getSchedule();
				if (campaignMaster.getSchedule().getScheduleId() != null) {
					Optional<Schedule> schedule = scheduleRepository
							.findById(campaignMaster.getSchedule().getScheduleId());

					if (schedule.isPresent()) {

						scheduleRequest.setCreatedBy(schedule.get().getCreatedBy());
						scheduleRequest.setCreatedOn(schedule.get().getCreatedOn());
					}
				}

				scheduleRequest.setTrialId(campaignMaster.getTrialId());
				scheduleRequest.setStartDateTime(CommonUtil.convertUIDateToUTC(scheduleRequest.getStartDateTime(),
						scheduleRequest.getTimezone()));
				scheduleRequest.setUpdatedOn(new Date());
				scheduleRequest.setDefaultSchedule(0);

				scheduleRequest = scheduleRepository.save(scheduleRequest);
				campaignMasterDB.setScheduleId(scheduleRequest.getScheduleId());
				campaignMasterDB.setSchedule(scheduleRequest);
				
				//Added Code for Notification
				notificationPublisher.publishNotification(buildNotificationPayload(campaignMaster, CommonConstants.SCHEDULED_ELOQUA_PATIENT_CAMPAIGN_START));

			}

		}

		if (!ObjectUtils.isEmpty(campaignMaster.getEmailTemplate())) {
			if (!ObjectUtils.isEmpty(campaignMaster.getEmailTemplate())) {
				if (campaignMaster.getEmailTemplate().isUseDefault()) {
					// call DB to get default schedule ID to insert into
					// campaign master
					emailTemplate = emailTemplateRepository
							.findByTrialIdAndDefaultEmailTemp(campaignMaster.getTrialId(), 1);
					if (emailTemplate != null) {
						campaignMasterDB.setEmailTemplateId(emailTemplate.getEmailTemplateId());
						campaignMasterDB.setEmailTemplate(emailTemplate);
					}
				} else {

					emailTemplate = campaignMaster.getEmailTemplate();
					if (campaignMaster.getEmailTemplate().getEmailTemplateId() != null) {

						Optional<EmailTemplate> emailTemplateDB = emailTemplateRepository
								.findByEmailTemplateId(campaignMaster.getEmailTemplate().getEmailTemplateId());

						if (emailTemplateDB.isPresent()) {
							emailTemplate.setCreatedBy(emailTemplateDB.get().getCreatedBy());
							emailTemplate.setCreatedOn(emailTemplateDB.get().getCreatedOn());
						}
					}

					emailTemplate.setUpdatedOn(new Date());
					emailTemplate.setTrialId(campaignMaster.getTrialId());
					emailTemplate = emailTemplateRepository.save(emailTemplate);
					campaignMasterDB.setEmailTemplateId(emailTemplate.getEmailTemplateId());
					campaignMasterDB.setEmailTemplate(emailTemplate);
				}
			}

		}

		// check for Campaign Status
		if (!now) {
			if (campaignMaster.getSchedule() != null) {
				// set Status of Campaign
				campaignMasterDB.setCampaignStatusId(SprinttCampaignStatus.SCHEDULED.getValue());
				// Changes added by JKT for US25616
				/*
				 * campaignMasterDB.setNextAction(CommonUtil.
				 * populateNextLastAction( CommonConstants.EMAIL_TO_BE_SENT_AT,
				 * campaignMasterDB.getSchedule().getStartDateTime()));
				 * campaignMasterDB
				 * .setLastAction(CommonUtil.populateNextLastAction(
				 * CommonConstants. SCHEDULED_SUCCESSFULLY, null));
				 */
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

				/*
				 * // Commented by Jyoti EST to EDT change
				 * campaignMasterDB.setNextAction(CommonConstants.
				 * EMAIL_TO_BE_SENT_AT .replace("#dateTime",
				 * uiDateFormat.format(campaignMasterDB.getSchedule().
				 * getStartDateTime())) .replace("GMT",
				 * campaignMasterDB.getSchedule().getTimezone()));
				 */

				// added by jyoti EST to EDT change
				TimeZone timeZone = TimeZone
						.getTimeZone(CommonUtil.getTimeZone(campaignMasterDB.getSchedule().getTimezone()));
				String timeZoneFormat = CommonUtil.getDayLightSavingZone(
						timeZone.inDaylightTime(campaignMasterDB.getSchedule().getStartDateTime()),
						campaignMasterDB.getSchedule().getTimezone());

				campaignMasterDB.setNextAction(CommonConstants.EMAIL_TO_BE_SENT_AT
						.replace("#dateTime", uiDateFormat.format(campaignMasterDB.getSchedule().getStartDateTime()))
						.replace("GMT", timeZoneFormat));

				// instance =
				// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				// campaignMasterDB.setLastAction(CommonConstants.SCHEDULED_SUCCESSFULLY
				// .replace("#dateTime",
				// estDateFormat.format(instance.getTime())).toString());

				campaignMasterDB.setLastAction(CommonConstants.SCHEDULED_SUCCESSFULLY.replace("#dateTime",
						estDateFormat.format(instance.getTime()).replace(instance.getTimeZone().toString(),
								campaignMasterDB.getSchedule().getTimezone())));

			} else {
				// set Status of Campaign
				campaignMasterDB.setCampaignStatusId(SprinttCampaignStatus.DRAFT.getValue());
				// Changes added by JKT for US25616
				// campaignMasterDB.setLastAction(CommonUtil.populateNextLastAction(CommonConstants.DRAFT_MODIFIED,
				// null));
				// instance =
				// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				// campaignMasterDB.setLastAction(
				// CommonConstants.DRAFT_MODIFIED.replace("#dateTime",
				// estDateFormat.format(instance.getTime())));

				campaignMasterDB.setLastAction(CommonConstants.DRAFT_MODIFIED.replace("#dateTime", estDateFormat
						.format(instance.getTime()).replace(instance.getTimeZone().toString(), CommonConstants.EST)));

				campaignMasterDB.setNextAction(CommonConstants.BLANK);
			}
		}
		// CampaignMaster Repository
		if(campaignMaster.getCampaignStatusId().equals(3)){
			campaignMasterDB.setCampaignStatusId(SprinttCampaignStatus.DEPLOYED.getValue());
		}
		campaignMasterDB.setUpdatedOn(new Date()); // should come from UI
		campaignMasterDB.setExternalStudyLink(campaignMaster.isExternalStudyLink());
		logger.info("Campaign data before update: {}  ", campaignMasterDB);
		campaignMasterRepository.save(campaignMasterDB);

		// get List of updated Reminders from sprintt DB and send it in Response
		// and
		// Eloqua
		CampaignMaster campaignMasteRemininderResponse = campaignMasterRepository
				.findBySprinttCampaignId(campaignMasterDB.getSprinttCampaignId());

		if (campaignMasterDB != null) {
			Optional<List<Reminder>> reminderDBList = reminderRepository.findByCampaignMaster(campaignMasterDB);
			if (reminderDBList.isPresent()) {
				List<Reminder> reminderList = reminderDBList.get();
				if (reminderList != null && reminderList.size() > 0) {
					campaignMasteRemininderResponse.setReminders(null);
					campaignMasteRemininderResponse.setReminders(reminderList);
				}
			}
		}

		campaignManager.updateScheduledCampaignInEloqua(campaignMasteRemininderResponse, responseObjectModel);

		responseObjectModel.setData(campaignMasteRemininderResponse);
		responseObjectModel.setMessage("Success");
		responseObjectModel.setHttpStatus(HttpStatus.OK);
		return responseObjectModel;

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel deactivateCampaign(Long campaignId) throws WorkflowEngineException, EloquaException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);
		// 1. perform state transition with guards
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			campaignData.setSchedule(scheduleRepository.findById(campaignData.getScheduleId()).orElse(null));
			if (campaignData.getSchedule().getStartDateTime().before(new Date())) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("Live campaign cannot be deactivated.");
				return responseObject;
			}
			campaignData
					.setEmailTemplate(emailTemplateRepository.findById(campaignData.getEmailTemplateId()).orElse(null));

			campaignStateTransitionManager.execute(responseObject, campaignData, SprinttCampaignStatus.DISCARDED);
			// 2. save entity
			// campaignData = campaignMasterRepository.save(campaignData);
			// 3. deactivate in eloqua
			EloquaCampaignResponse resp = campaignManager.deactivateCampaign(campaignData);
			// 4. update entity for eloqua status
			campaignData.setCampaignJobStatusId(CampaignJobStatus.DISCARD_INITIATED.getValue());
			campaignData.setEloCampgnStatusId(
					EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());

			// Changes added by JKT for US25616
			// campaignData.setLastAction(CommonUtil.populateNextLastAction(CommonConstants.DISCARDED_ON,
			// null));
			// instance =
			// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

			instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
			campaignData.setLastAction(
					CommonConstants.DISCARDED_ON.replace("#dateTime", estDateFormat.format(instance.getTime())));

			campaignData.setNextAction(CommonConstants.BLANK);
			responseObject.setData(campaignMasterRepository.save(campaignData));
			responseObject.setMessage("Deactivated successfully");
			responseObject.setHttpStatus(HttpStatus.OK);
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	// Need to removed
	public ResponseObjectModel reScheduleAScheduledCampaign(Long campaignId) throws CampaignServiceException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (campaignData.getScheduleId() == null || campaignData.getEmailTemplateId() == null) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("Schedule and Email template must be present.");
				return responseObject;
			}
			if (!ValidationHelper.verifyPatientGenerationStatus(campaignData, responseObject, false)
					|| !ValidationHelper.verifyContactsUploadStatus(campaignData, responseObject, false)) {
				return responseObject;
			}
			if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())) {
				try {
					campaignManager.updateScheduledCampaignInEloqua(campaignData, responseObject);
					EloquaCampaignResponse resp = campaignManager.scheduleCampaign(campaignData);
					campaignData.setEloCampgnStatusId(
							EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());
					campaignData = campaignMasterRepository.save(campaignData);
					responseObject.setData(campaignData);
					responseObject.setMessage("Scheduled successfully");
					responseObject.setHttpStatus(HttpStatus.OK);
				} catch (EloquaException e) {
					logger.error("Encounter exception while trying to reschedule campaign {} - {}", campaignId, e);
					return e.getResponseObject();
				}
			}
		}
		return responseObject;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	// Need to be removed
	public ResponseObjectModel activateAScheduledCampaign(Long campaignId) throws CampaignServiceException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (campaignData.getScheduleId() == null || campaignData.getEmailTemplateId() == null) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("Schedule and Email template must be present.");
				return responseObject;
			}
			if (!ValidationHelper.verifyPatientGenerationStatus(campaignData, responseObject, true)
					|| !ValidationHelper.verifyContactsUploadStatus(campaignData, responseObject, true)
					|| !ValidationHelper.verifyContactListUploadStatus(campaignData, responseObject, true)) {
				return responseObject;
			}
			if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())) {
				try {
					campaignData = campaignStateTransitionManager.execute(responseObject, campaignData,
							SprinttCampaignStatus.DEPLOYED);

					// Changes added by JKT for US25616
					/*
					 * campaignData.setLastAction(CommonUtil.
					 * populateNextLastAction(CommonConstants. DEPLOYED_AT,
					 * null)); campaignData.setNextAction(CommonUtil.
					 * populateNextLastAction(CommonConstants.
					 * EMAIL_SCHEDULED_FOR,
					 * campaignData.getSchedule().getStartDateTime()));
					 */
					// instance =
					// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

					instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
					campaignData.setLastAction(CommonConstants.DEPLOYED_AT.toString().replace("#dateTime",
							estDateFormat.format(instance.getTime())));
					campaignData.setNextAction(CommonConstants.EMAIL_SCHEDULED_FOR.toString()
							.replace("#dateTime", uiDateFormat.format(campaignData.getSchedule().getStartDateTime())) // change
							.replace("GMT", campaignData.getSchedule().getTimezone()));

					campaignManager.updateScheduledCampaignInEloqua(campaignData, responseObject);
					EloquaCampaignResponse resp = campaignManager.activateCampaign(campaignData);
					campaignData.setEloCampgnStatusId(
							EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());
					campaignData = campaignMasterRepository.save(campaignData);
					responseObject.setData(campaignData);
					responseObject.setMessage("Deployed successfully");
					responseObject.setHttpStatus(HttpStatus.OK);
				} catch (WorkflowEngineException e) {
					logger.error("Caught exception while trying to move campaign {} to {} : {}",
							campaignData.getCampaignId(), SprinttCampaignStatus.DEPLOYED, e);
					return responseObject;
				} catch (EloquaException e) {
					logger.error("Encounter exception while trying to reschedule campaign {} - {}", campaignId, e);
					return e.getResponseObject();
				} catch (Exception e) {
					logger.error("Exception occured while setting last and next action");
					logger.info("Schedule date  was " + campaignData.getSchedule().getStartDateTime());
				}
			}
		}
		return responseObject;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel activateCampaign(Long campaignId, boolean now) throws CampaignServiceException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);
		// 1. perform state transition with guards
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (campaignData.getScheduleId() == null || campaignData.getEmailTemplateId() == null) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("Schedule and Email template must be present.");
				return responseObject;
			}
			campaignData.setSchedule(scheduleRepository.findById(campaignData.getScheduleId()).orElse(null));
			campaignData
					.setEmailTemplate(emailTemplateRepository.findById(campaignData.getEmailTemplateId()).orElse(null));
			try {
				campaignData = campaignStateTransitionManager.execute(responseObject, campaignData,
						now ? SprinttCampaignStatus.DEPLOYED : SprinttCampaignStatus.SCHEDULED);
			} catch (WorkflowEngineException e) {
				logger.error("Caught exception while trying to move campaign {} to {} : {}",
						campaignData.getCampaignId(),
						now ? SprinttCampaignStatus.DEPLOYED : SprinttCampaignStatus.SCHEDULED, e);
				return responseObject;
			}
			//
			// need to revisit once deploy later and campaign will start going
			// to schedule

			// Changes added by JKT for US25616
			/*
			 * campaignData.setLastAction(CommonUtil.populateNextLastAction(
			 * CommonConstants. DEPLOYED_AT, null));
			 * campaignData.setNextAction(CommonUtil.populateNextLastAction(
			 * CommonConstants. EMAIL_SCHEDULED_FOR,
			 * campaignData.getSchedule().getStartDateTime()));
			 */
			// instance =
			// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

			try {
				SimpleDateFormat sf = new SimpleDateFormat("MM/dd/yyyy , hh:mm aa zzz");
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				campaignData.setLastAction(CommonConstants.DEPLOYED_AT.toString().replace("#dateTime",
						estDateFormat.format(instance.getTime())));
				campaignData.setNextAction(CommonConstants.EMAIL_SCHEDULED_FOR.toString()
						.replace("#dateTime", uiDateFormat.format(campaignData.getSchedule().getStartDateTime()))
						.replace("GMT", campaignData.getSchedule().getTimezone()));

				// campaignData.setNextAction(CommonConstants.EMAIL_TO_BE_SENT_AT.toString().replace("#dateTime",
				// sf.format(campaignData.getSchedule().getStartDateTime()).toString()));

			} catch (Exception e) {
				logger.error("Exception occured while setting last and next action");
				logger.info("Schedule date  was " + campaignData.getSchedule().getStartDateTime());

			}

			// 2. save entity
			campaignData = campaignMasterRepository.save(campaignData);			
			// 3. get patient list from sprinttdb
			List<Object[]> patientList = participantListHelper.getPatientListFromParticipantDB(campaignData);
			if (!CollectionUtils.isEmpty(patientList)) {
				logger.debug("patient list got from participant db");
				participantListHelper.prepareContactListAndUpdateContactSegment(
						participantListHelper.createContactsInEloqua(patientList), campaignData);
				// 4. call Eloqua to activate campaign
				EloquaCampaignResponse resp = now ? campaignManager.activateCampaign(campaignData)
						: campaignManager.scheduleCampaign(campaignData);
				// 5. update entity for eloqua status
				campaignData.setEloCampgnStatusId(
						EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());
				campaignData = campaignMasterRepository.save(campaignData);
				responseObject.setData(campaignData);
				responseObject.setMessage(now ? "Deployed successfully" : "Scheduled successfully");
				responseObject.setHttpStatus(HttpStatus.OK);
			} else {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("None of patients in the patient list have email address.");
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}

		return responseObject;
	}

	@Override
	public ResponseObjectModel getCampaignsForTrial(Long trialId) {
		logger.info("getCampaignsForTrial method started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (StringUtils.isEmpty(trialId) || trialId == 0) {
			logger.info(MessageConstants.TRIALID_MNDT);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(MessageConstants.TRIALID_MNDT);
			return responseObjectModel;
		}
		try {
			List<CampaignMaster> campaignMasterList = campaignMasterRepository.findByTrialId(trialId);
			CampaignListGroup campgrps = new CampaignListGroup();
			Map<String, List<CampaignMaster>> campaignMaterMap = getCampaignMasterMap(campaignMasterList);
			List<Object> deployedCampaigns = new ArrayList<Object>();
			List<Object> scheduledCampaigns = new ArrayList<Object>();
			List<Object> draftCampaigns = new ArrayList<Object>();
			List<Object> closedCampaigns = new ArrayList<Object>();
			List<Object> discardedCampaigns = new ArrayList<Object>();
			deployedCampaigns.addAll(campaignMaterMap.get(CommonConstants.DEPLOYED));
			scheduledCampaigns.addAll(campaignMaterMap.get(CommonConstants.SCHEDULED));
			draftCampaigns.addAll(campaignMaterMap.get(CommonConstants.DRAFT));
			closedCampaigns.addAll(campaignMaterMap.get(CommonConstants.CLOSED));
			discardedCampaigns.addAll(campaignMaterMap.get(CommonConstants.DISCARDED));
			List<CampaignMasterMyQuest> campaignMasterMyQuests = campaignMasterMyQuestRepository.findByTrialId(trialId);
			Map<String, List<CampaignMasterMyQuest>> campaignMaterMyQuestMap = getCampaignMasterMyQuestMap(
					campaignMasterMyQuests);
			deployedCampaigns.addAll(campaignMaterMyQuestMap.get(CommonConstants.DEPLOYED));
			scheduledCampaigns.addAll(campaignMaterMyQuestMap.get(CommonConstants.SCHEDULED));
			draftCampaigns.addAll(campaignMaterMyQuestMap.get(CommonConstants.DRAFT));
			closedCampaigns.addAll(campaignMaterMyQuestMap.get(CommonConstants.CLOSED));
			discardedCampaigns.addAll(campaignMaterMyQuestMap.get(CommonConstants.DISCARDED));
			campgrps.setDeployed(deployedCampaigns);
			campgrps.setScheduled(scheduledCampaigns);
			campgrps.setDraft(draftCampaigns);
			campgrps.setEnded(closedCampaigns);
			campgrps.setDiscarded(discardedCampaigns);
			
			List<PauboxCampaignMaster> pauboxCampaignMasterList = pauboxCampaignMasterRepository.findByTrialId(trialId);
			Map<String, List<PauboxCampaignMaster>> PauboxCampaignMaterMap = getPauboxCampaignMasterMap(pauboxCampaignMasterList);
			scheduledCampaigns.addAll(PauboxCampaignMaterMap.get(CommonConstants.SCHEDULED));			
			campgrps.setScheduled(scheduledCampaigns);
			responseObjectModel.setData(campgrps);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage(CommonConstants.SUCCESS);
		} catch (Exception e) {
			logger.error("Exception occured while fetching list of Campaigns {}", e);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("Error in getCampaignsForTrial method");
		}
		return responseObjectModel;
	}

	@Override
	@Transactional
	public ResponseObjectModel deployScheduleCampaign(Long campaignId, boolean isDeployed) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);

		/*
		 * Check if campaign is exists if not sent error message campaign does
		 * not exists
		 */
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (campaignData.getScheduleId() == null || campaignData.getEmailTemplateId() == null) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage(CommonConstants.EMPTY_EMAIL_SCHEDULE_ERROR_MSG);
				return responseObject;
			}
			campaignData.setSchedule(scheduleRepository.findById(campaignData.getScheduleId()).orElse(null));
			campaignData
					.setEmailTemplate(emailTemplateRepository.findById(campaignData.getEmailTemplateId()).orElse(null));
			try {
				campaignData = campaignStateTransitionManager.execute(responseObject, campaignData,
						isDeployed ? SprinttCampaignStatus.DEPLOYED : SprinttCampaignStatus.SCHEDULED);
			} catch (WorkflowEngineException e) {
				logger.error("Caught exception while trying to move campaign {} to {} :{} ",
						campaignData.getCampaignId(),
						isDeployed ? SprinttCampaignStatus.DEPLOYED : SprinttCampaignStatus.SCHEDULED, e);
				return e.getResponseObject();
			}

			ZonedDateTime localDateTime = ZonedDateTime.now();

			campaignData.setLastAction(
					CommonConstants.DEPLOYED_AT.toString().replace("#dateTime", estDateFormat.format(localDateTime)));
			campaignData.setNextAction(CommonConstants.EMAIL_SCHEDULED_FOR.toString().replace("#dateTime",
					uiDateFormat.format(localDateTime)));

			/*
			 * Save campaign data into sprintt DB with Scheduler, Reminders and
			 * Email Template.
			 */
			campaignData = campaignMasterRepository.save(campaignData);

			List<Object[]> patientList = new ArrayList<>();
			Object[] arr = { "Jitendra", "Tiwari", "tiwari.j@hcl.com" };
			patientList.add(arr);
			if (!CollectionUtils.isEmpty(patientList)) {
				logger.debug("patient list got from participant db");
				try {

					participantListHelper.prepareContactListAndUpdateContactSegment(
							participantListHelper.createContactsInEloqua(patientList), campaignData);

					// 4. call Eloqua to activate campaign
					EloquaCampaignResponse resp = isDeployed ? campaignManager.activateCampaign(campaignData)
							: campaignManager.scheduleCampaign(campaignData);
					// 5. update entity for eloqua status
					campaignData.setEloCampgnStatusId(
							EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());
				} catch (EloquaException eloquaException) {
					eloquaException.printStackTrace();
					logger.error(
							CommonConstants.ELOQUA_COMMUINICATION_ERROR_MSG + " : " + eloquaException.getMessage());
					responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
					responseObject.setMessage(eloquaException.getMessage());
					return responseObject;

				}

				campaignData = campaignMasterRepository.save(campaignData);
				responseObject.setData(campaignData);
				responseObject.setMessage(
						isDeployed ? CommonConstants.CAMPAIGN_DEPLOYED_MSG : CommonConstants.CAMPAIGN_SCHEDULED_MSG);
				responseObject.setHttpStatus(HttpStatus.OK);
			} else {
				logger.error(CommonConstants.PATIENT_EMAIL_DOES_NOT_EXIST);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage(CommonConstants.PATIENT_EMAIL_DOES_NOT_EXIST);
				return responseObject;
			}
		} else {
			logger.error(CommonConstants.CAMPAIGN_DOES_NOT_EXIST);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(CommonConstants.CAMPAIGN_DOES_NOT_EXIST);
			return responseObject;
		}

		return responseObject;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel discardCampaign(Long campaignId) throws WorkflowEngineException, EloquaException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (SprinttCampaignStatus.DRAFT.getValue().equals(campaignData.getCampaignStatusId())
					|| SprinttCampaignStatus.SCHEDULED.getValue().equals(campaignData.getCampaignStatusId())) {
				try {
					if (SprinttCampaignStatus.DRAFT.getValue().equals(campaignData.getCampaignStatusId())) {
						if (!ValidationHelper.verifyDraftCompletionStatus(campaignData, responseObject)) {
							responseObject.setMessage("Draft creation is still in-progress. Try again later.");
							return responseObject;
						}
						// here discard a draft campaign
						campaignStateTransitionManager.execute(responseObject, campaignData,
								SprinttCampaignStatus.DISCARDED);
						// instance =
						// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

						instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
						campaignData.setLastAction(CommonConstants.DISCARDED_ON.replace("#dateTime",
								estDateFormat.format(instance.getTime())));

						campaignData.setNextAction(CommonConstants.BLANK);
						campaignData = campaignMasterRepository.save(campaignData);
						responseObject.setData(campaignData);
						responseObject.setMessage(MessageConstants.CAMPAIGN_DISCARD_SUCCESS);
						responseObject.setHttpStatus(HttpStatus.OK);
					} else {
						// here discard a scheduled campaign
						if (!ValidationHelper.verifyScheduleCompletionStatus(campaignData, responseObject)) {
							responseObject.setMessage("Schedule upload is still in-progress. Try again later.");
							return responseObject;
						}
						return deactivateCampaign(campaignId);
					}
				} catch (WorkflowEngineException e) {
					logger.error(LoggingConstants.ERROR_CAMPAIGN_DISCARD_LOG, campaignData.getCampaignId(),
							SprinttCampaignStatus.DEPLOYED, e);
					return responseObject;
				}
			} else {
				responseObject.setMessage(MessageConstants.CAMPAIGN_DISCARD_FALIURE);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
		}
		return responseObject;
	}

	@Override
	public ResponseObjectModel reconsiderCampaign(Long sprinttCampaignId) throws CampaignServiceException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(sprinttCampaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (!ValidationHelper.verifyDiscardStatus(campaignData, responseObject)) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				return responseObject;
			}
			try {
				campaignStateTransitionManager.execute(responseObject, campaignData, SprinttCampaignStatus.DRAFT);

				campaignData.setLastAction(CommonConstants.REVERTED_TO_DRAFT.replace("#dateTime", estDateFormat
						.format(Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST)).getTime())));

				campaignData.setNextAction(CommonConstants.BLANK);
				campaignData = campaignMasterRepository.save(campaignData);
				responseObject.setData(campaignData);
				responseObject.setMessage("Moved to Draft State successfully");
				responseObject.setHttpStatus(HttpStatus.OK);
			} catch (WorkflowEngineException e) {
				logger.error(LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_LOG, campaignData.getCampaignId(),
						SprinttCampaignStatus.DEPLOYED, e);
				return responseObject;
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;

	}

	@Override
	public ResponseObjectModel endCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(sprinttCampaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();

			try {
				Optional<Schedule> schedule = scheduleRepository.findById(campaignData.getScheduleId());
				if (schedule.isPresent()) {

					if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.DEPLOYED.getValue())) {
						campaignStateTransitionManager.execute(responseObject, campaignData,
								SprinttCampaignStatus.CLOSED);
						EloquaCampaignResponse resp = campaignManager.deactivateCampaign(campaignData);
						campaignData.setEloCampgnStatusId(
								EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());
						// instance =
						// Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));

						instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
						/*
						 * campaignData.setLastAction(CommonConstants.ENDED_ON.
						 * replace("#dateTime",
						 * estDateFormat.format(instance.getTime())));
						 */

						campaignData.setLastAction(
								CommonConstants.ENDED_ON.replace("#dateTime", estDateFormat.format(instance.getTime())
										.replace(instance.getTimeZone().toString(), CommonConstants.EST)));

						// Changes added by JKT for US25616
						// campaignData.setLastAction(CommonUtil.populateNextLastAction(CommonConstants.ENDED_ON,
						// null));
						campaignData.setNextAction(CommonConstants.BLANK);
						campaignData = campaignMasterRepository.save(campaignData);
						responseObject.setData(campaignData);
						responseObject.setMessage("Moved to End State successfully");
						responseObject.setHttpStatus(HttpStatus.OK);
					} else {
						logger.error("Campaign can not be ended.");
						responseObject.setMessage("Campaign can not be ended.");
						responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
					}
				}
			} catch (WorkflowEngineException e) {
				logger.error(LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_LOG, campaignData.getCampaignId(),
						SprinttCampaignStatus.DEPLOYED, e);
				return responseObject;
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel deployDraftScheduleCampaign(Long campaignId, boolean now)
			throws CampaignServiceException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(campaignId);
		// 1. perform state transition with guards
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (campaignData.getScheduleId() == null || campaignData.getEmailTemplateId() == null) {
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("Schedule and Email template must be present.");
				return responseObject;
			}
			campaignData.setSchedule(scheduleRepository.findById(campaignData.getScheduleId()).orElse(null));
			campaignData
					.setEmailTemplate(emailTemplateRepository.findById(campaignData.getEmailTemplateId()).orElse(null));
			try {
				campaignData = campaignStateTransitionManager.execute(responseObject, campaignData,
						SprinttCampaignStatus.DEPLOYED);
				/*
				 * Call Eloqua to schedule campaign in sync call to handle the
				 * schedule elapsed campaign This will schedule campaign again
				 * when the contact list uploaded but failed due to past
				 * schedule date.
				 */
				if (!now && (campaignData.getCampaignJobStatusId()
						.equals(CampaignJobStatus.SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED.getValue()))) {
					campaignData.setCampaignJobStatusId(CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue());
				}

			} catch (WorkflowEngineException e) {
				logger.error("Caught exception while trying to move campaign {} to {} : {}",
						campaignData.getCampaignId(), SprinttCampaignStatus.DEPLOYED, e);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage(CommonConstants.CAMPAIGN_SCHEDULING_IN_PROGRESS);
				return responseObject;
			}
			try {
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				campaignData.setLastAction(CommonConstants.DEPLOYED_AT.toString().replace("#dateTime",
						estDateFormat.format(instance.getTime())));

				// Next action Populated
				TimeZone timeZone = TimeZone
						.getTimeZone(CommonUtil.getTimeZone(campaignData.getSchedule().getTimezone()));

				String timeZoneFormat = CommonUtil.getDayLightSavingZone(
						timeZone.inDaylightTime(campaignData.getSchedule().getStartDateTime()),
						campaignData.getSchedule().getTimezone());

				campaignData
						.setNextAction(CommonConstants.EMAIL_SCHEDULED_FOR.toString().replace("#dateTime", uiDateFormat
								.format(campaignData.getSchedule().getStartDateTime()).replace("GMT", timeZoneFormat)));

			} catch (Exception e) {
				logger.error("Exception occured while setting last and next action");
			}
			responseObject.setData(campaignMasterRepository.save(campaignData));
			responseObject.setMessage(CommonConstants.CAMPAIGN_DEPLOYED_MSG);
			responseObject.setHttpStatus(HttpStatus.OK);
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;
	}

	@Override
	public ResponseObjectModel isPatientListGenerated(Long sprinttCampaignId) {
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(sprinttCampaignId);

		ResponseObjectModel responseObject = new ResponseObjectModel();

		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();
			if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())
					&& (campaignData.getCampaignJobStatusId()
							.equals(CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue())
							|| campaignData.getCampaignJobStatusId().equals(
									CampaignJobStatus.SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED.getValue()))) {
				responseObject.setMessage(CommonConstants.SUCCESS);
				responseObject.setHttpStatus(HttpStatus.OK);
				return responseObject;
			} else if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())
					&& campaignData.getCampaignJobStatusId().equals(CampaignJobStatus.CONTACT_LIST_EMPTY.getValue())) {
				responseObject.setMessage(CommonConstants.CAMPAIGN_FAILED_EMPTY_CONTACT_LIST);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				return responseObject;
			} else if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())
					&& !campaignData.getCampaignJobStatusId()
							.equals(CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue())) {
				responseObject.setMessage(CommonConstants.CAMPAIGN_SCHEDULING_IN_PROGRESS);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				return responseObject;
			} else if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.DRAFT.getValue())) {
				responseObject.setMessage(CommonConstants.SUCCESS);
				responseObject.setHttpStatus(HttpStatus.OK);
				return responseObject;
			}

			// Shouldn't we keep a else here for Schedule camapign with states
			// other than 11
			// and 10.
		} else {
			responseObject.setMessage(CommonConstants.CAMPAIGN_DOES_NOT_EXIST);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			return responseObject;
		}

		return responseObject;

	}

	@Async("asyncExecutor")
	public CompletableFuture<CampaignMaster> enableAsyncDeployCampaignProcess(CampaignMaster campaignMasterObj) {

		List<Object[]> patientList = participantListHelper.getPatientListFromParticipantDB(campaignMasterObj);
		if (!CollectionUtils.isEmpty(patientList)) {
			logger.debug("patient list got from participant db");
			try {
				/*
				 * participantListHelper.
				 * prepareContactListAndUpdateContactSegment(
				 * participantListHelper.createContactsInEloqua(patientList),
				 * campaignMasterObj);
				 */
				logger.info("Inside dedup : {} ", patientList.size());
				participantListHelper.populateContactIdInParticipantStudySiteTrial(patientList, campaignMasterObj);
				logger.info("AFTER DEDUP");
				/*
				 * participantListHelper.
				 * prepareContactListAndUpdateContactSegment(
				 * participantListHelper.getContactIdsFromParticipantDB(
				 * campaignMasterObj), campaignMasterObj);
				 */
				participantListHelper.saveOrUpdateContactListInELoqua(campaignMasterObj,
						participantListHelper.getContactIdsFromParticipantDB(campaignMasterObj), true);
				logger.info("Completed upload segment with patient contact id's");
				EloquaCampaignResponse resp = campaignManager.activateCampaign(campaignMasterObj);

				campaignMasterObj.setEloCampgnStatusId(
						EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());

			} catch (EloquaException ex) {
				logger.error("Exception occured while populating patient list.");
			}

		} else {
			logger.error("Patient list is empty.");
		}
		return CompletableFuture.completedFuture(campaignMasterObj);
	}

	@Override
	public ResponseObjectModel reconsiderEndedCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMaster> campaignDataOpt = campaignMasterRepository.findById(sprinttCampaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMaster campaignData = campaignDataOpt.get();

			try {
				if (hasCampaignEnded(campaignData)) {
					responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
					responseObject.setMessage("Campaign cannot be moved to draft as the campaign has not ended yet.");
					return responseObject;
				}
				EloquaCampaignStatus eloquaCampaignStatus = null;
				try {
					eloquaCampaignStatus = EloquaCampaignStatus.getStatusOf(
							campaignManager.getCampaignInEloqua(campaignData.getCampaignId()).getCurrentStatus());
				} catch (Exception e) {

					logger.error("Something went wrong in retriveing details of campaign for CampaignId"
							+ campaignData.getCampaignId());
				}
				if (EloquaCampaignStatus.ACTIVE.getType().equalsIgnoreCase(eloquaCampaignStatus.getType())) {
					EloquaCampaignResponse resp = campaignManager.deactivateCampaign(campaignData);
					campaignData.setEloCampgnStatusId(
							EloquaCampaignStatus.valueOf(resp.getCurrentStatus().toUpperCase()).getValue());
					campaignStateTransitionManager.execute(responseObject, campaignData, SprinttCampaignStatus.DRAFT);
					campaignData.setLastAction(CommonConstants.REVERTED_TO_DRAFT.replace("#dateTime", estDateFormat
							.format(Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST)).getTime())));
					campaignData.setNextAction(CommonConstants.BLANK);
					campaignData = campaignMasterRepository.save(campaignData);
					responseObject.setData(campaignData);
					responseObject.setMessage("Moved to Draft State successfully");
					responseObject.setHttpStatus(HttpStatus.OK);
				} else {
					responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
					responseObject.setMessage("Campaign is not active on Eloqua.");
				}
			} catch (WorkflowEngineException e) {
				logger.error(LoggingConstants.ERROR_CAMPAIGN_RECONSIDER_LOG, campaignData.getCampaignId(),
						SprinttCampaignStatus.DEPLOYED, e);
				return responseObject;
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;

	}

	public boolean hasCampaignEnded(CampaignMaster campaignData) {
		Optional<Schedule> schedule = scheduleRepository.findById(campaignData.getScheduleId());
		if (campaignData.getReminders() != null && campaignData.getReminders().size() > 0) {
			Reminder reminder = campaignData.getReminders().stream()
					.filter(r -> (r.getNormalizedRemindOnDateTime().after(new Date()))).findAny().orElse(null);
			if (reminder == null)
				return false;
			else
				return true;
		} else if (schedule.isPresent()) {
			if (schedule.get().getNormalizedStartDateTime().after(new Date()))
				return true;
			else
				return false;

		} else
			return false;
	}

	private Map<String, List<CampaignMaster>> getCampaignMasterMap(List<CampaignMaster> campaignMasterList) {
		Map<String, List<CampaignMaster>> campaignMaterMap = new HashMap<String, List<CampaignMaster>>();
		List<CampaignMaster> draftCampaign = new ArrayList<CampaignMaster>();
		List<CampaignMaster> scheduledCampaign = new ArrayList<CampaignMaster>();
		List<CampaignMaster> deployedCampaign = new ArrayList<CampaignMaster>();
		List<CampaignMaster> closedCampaign = new ArrayList<CampaignMaster>();
		List<CampaignMaster> discardedCampaign = new ArrayList<CampaignMaster>();
		Schedule schedule = new Schedule();
		for (CampaignMaster campaignMaster : campaignMasterList) {
			if (campaignMaster.getScheduleId() != null) {
				Optional<Schedule> scheduleDetails = scheduleRepository
						.findByScheduleId(campaignMaster.getScheduleId());
				if (scheduleDetails.isPresent()) {
					Schedule sch = scheduleDetails.get();
					TimeZone timeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(sch.getTimezone()));
					String scheduleZoneFormat = CommonUtil
							.getDayLightSavingZone(timeZone.inDaylightTime(sch.getStartDateTime()), sch.getTimezone());
					sch.setScheduleDisplay("#dateTime".replace("#dateTime",
							uiDateFormat.format(sch.getStartDateTime()).replace("GMT", scheduleZoneFormat)));
					campaignMaster.setSchedule(sch);
				} else {
					campaignMaster.setSchedule(schedule);
				}
			} else {
				campaignMaster.setSchedule(schedule);
			}
			if (SprinttCampaignStatus.getStatusOf(campaignMaster.getCampaignStatusId()) != null) {
				switch (SprinttCampaignStatus.getStatusOf(campaignMaster.getCampaignStatusId())) {
				case DRAFT:
					draftCampaign.add(campaignMaster);
					break;
				case SCHEDULED:
					scheduledCampaign.add(campaignMaster);
					break;
				case DEPLOYED:
					deployedCampaign.add(campaignMaster);
					break;
				case DISCARDED:
					discardedCampaign.add(campaignMaster);
					break;
				case CLOSED:
					closedCampaign.add(campaignMaster);
					break;

				}
			}

		}
		campaignMaterMap.put(CommonConstants.DRAFT, draftCampaign);
		campaignMaterMap.put(CommonConstants.SCHEDULED, scheduledCampaign);
		campaignMaterMap.put(CommonConstants.DEPLOYED, deployedCampaign);
		campaignMaterMap.put(CommonConstants.DISCARDED, discardedCampaign);
		campaignMaterMap.put(CommonConstants.CLOSED, closedCampaign);
		return campaignMaterMap;
	}
	
	//New draft
	private Map<String, List<PauboxCampaignMaster>> getPauboxCampaignMasterMap(List<PauboxCampaignMaster> pauboxCampaignMasterList) {
		Map<String, List<PauboxCampaignMaster>> pauboxCampaignMaterMap = new HashMap<String, List<PauboxCampaignMaster>>();
		List<PauboxCampaignMaster> scheduledCampaign = new ArrayList<PauboxCampaignMaster>();
		List<PauboxCampaignMaster> deployedCampaign = new ArrayList<PauboxCampaignMaster>();
		List<PauboxCampaignMaster> closedCampaign = new ArrayList<PauboxCampaignMaster>();
		List<PauboxCampaignMaster> discardedCampaign = new ArrayList<PauboxCampaignMaster>();
		Schedule schedule = new Schedule();
		for (PauboxCampaignMaster pauboxCampaignMaster : pauboxCampaignMasterList) {
			if (pauboxCampaignMaster.getScheduleId() != null) {
				Optional<Schedule> scheduleDetails = scheduleRepository
						.findByScheduleId(pauboxCampaignMaster.getScheduleId());
				if (scheduleDetails.isPresent()) {
					Schedule sch = scheduleDetails.get();
					TimeZone timeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(sch.getTimezone()));
					String scheduleZoneFormat = CommonUtil
							.getDayLightSavingZone(timeZone.inDaylightTime(sch.getStartDateTime()), sch.getTimezone());
					sch.setScheduleDisplay("#dateTime".replace("#dateTime",
							uiDateFormat.format(sch.getStartDateTime()).replace("GMT", scheduleZoneFormat)));
					pauboxCampaignMaster.setSchedule(sch);
				} else {
					pauboxCampaignMaster.setSchedule(schedule);
				}
			} else {
				pauboxCampaignMaster.setSchedule(schedule);
			}
			if (SprinttCampaignStatus.getStatusOf(pauboxCampaignMaster.getCampaignStatusId()) != null) {
				switch (SprinttCampaignStatus.getStatusOf(pauboxCampaignMaster.getCampaignStatusId())) {
				case SCHEDULED:
					scheduledCampaign.add(pauboxCampaignMaster);
					break;
				case DEPLOYED:
					deployedCampaign.add(pauboxCampaignMaster);
					break;
				case DISCARDED:
					discardedCampaign.add(pauboxCampaignMaster);
					break;
				case CLOSED:
					closedCampaign.add(pauboxCampaignMaster);
					break;

				}
			}

		}
		
		pauboxCampaignMaterMap.put(CommonConstants.SCHEDULED, scheduledCampaign);
		pauboxCampaignMaterMap.put(CommonConstants.DEPLOYED, deployedCampaign);
		pauboxCampaignMaterMap.put(CommonConstants.DISCARDED, discardedCampaign);
		pauboxCampaignMaterMap.put(CommonConstants.CLOSED, closedCampaign);
		return pauboxCampaignMaterMap;
	}
	

	@Override
	public ResponseObjectModel isCampDeployedForTrial(String trialId) {

		boolean deployedcamp = campaignMasterRepository
				.findByTrialIdAndCampaignStatusId(trialId, SprinttCampaignStatus.DEPLOYED.getValue()).isPresent();
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (deployedcamp) {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("Trial cannot be moved since it has deployed campaign.");
			return responseObjectModel;
		} else {
			responseObjectModel.setMessage(CommonConstants.SUCCESS);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			return responseObjectModel;
		}

	}

	@Override
	public ResponseObjectModel getCampaignByEloquaId(String eloquaCampaignId) {

		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		if (StringUtils.isEmpty(eloquaCampaignId)) {
			logger.info(MessageConstants.CAMPAIGN_ID_MNDT);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_ID_MNDT);
			return responseObjectModel;
		}
		Optional<CampaignMaster> campDataFromDB = campaignMasterRepository.findByCampaignId(eloquaCampaignId);
		if (campDataFromDB.isPresent()) {
			CampaignMaster campDataToSend = new CampaignMaster();
			campDataToSend.setCampaignName(campDataFromDB.get().getCampaignName());
			campDataToSend.setCampaignId(campDataFromDB.get().getCampaignId());
			campDataToSend.setTrialId(campDataFromDB.get().getTrialId());
			campDataToSend.setEmailTemplateId(campDataFromDB.get().getEmailTemplateId());
			campDataToSend.setEmailTemplate(
					emailTemplateRepository.findById(campDataFromDB.get().getEmailTemplateId()).orElse(null));
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage("Success");
			responseObjectModel.setData(campDataToSend);
			return responseObjectModel;
		} else {
			logger.info(MessageConstants.CAMPAIGN_NOT_EXIST);
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
			return responseObjectModel;
		}
	}

	@Override
	public ResponseObjectModel createDraftMyQuestCampaign(CampaignMasterMyQuest campaignDataMyQuest,
			Boolean isCombined) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		if (!isCombined.equals(Boolean.TRUE)) {

			StringBuilder businessValidation = new StringBuilder();
			businessValidation = validateMyQuestCampaignData(campaignDataMyQuest, businessValidation);
			String studyLinkValidation = validateStudySiteInfo(campaignDataMyQuest, responseObject).getMessage();
			if (!StringUtils.isEmpty(studyLinkValidation)) {
				// businessValidation.append("|").append(studyLinkValidation);
				businessValidation = businessValidation.length() == 0 ? businessValidation.append(studyLinkValidation)
						: businessValidation.append(",").append(studyLinkValidation);
			}
			// if (!StringUtils.isEmpty(businessValidation)) {
			if (businessValidation.length() > 0) {
				logger.error("MyQuest Campaign Request Failed : {} ", businessValidation);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage(businessValidation.toString());
				return responseObject;
			}
		}
		responseObject = persistMyQuestCampaignData(campaignDataMyQuest, isCombined);

		// If Campaign name does not exist already then proceed
		if (!responseObject.getMessage().equals(LoggingConstants.CAMPAIGN_ALREADY_EXIST)) {
			CampaignMasterMyQuest campMasterMyQuest = (CampaignMasterMyQuest) responseObject.getData();

			if (campMasterMyQuest.getSchedule() != null) {
				logger.info("The CampaignId---" + campMasterMyQuest.getSprinttCampaignId());
				logger.info("The CampaignName---" + campMasterMyQuest.getCampaignName());
			}

			NotificationPayload notificationPayload = buildNotificationPayload(campMasterMyQuest,
					"Scheduled MyQuest Patient Campaign-Start");
					notificationPublisher.publishNotification(notificationPayload);
					
			/* Initiate patient list generation */
			// campaignPatientGeneration(getCampaignMasterWrapper(campMasterMyQuest));
		}
		return responseObject;
	}

	private ResponseObjectModel persistMyQuestCampaignData(CampaignMasterMyQuest requestCampaignMaster,
			Boolean isCombined) {
		logger.info("persist My Quest campaign data---");
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Schedule scheduleDet = null;
		CampaignMasterMyQuest campaignMaster = campaignMasterMyQuestRepository.findByCampaignNameAndTrialId(
				requestCampaignMaster.getCampaignName(), requestCampaignMaster.getTrialId());

		// Check if Campaign name already exists or not
		if (campaignMaster != null && !isCombined.equals(Boolean.TRUE)) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_ALREADY_EXIST_LOG);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Name Already Exists");
			return responseObject;
		} else {
			requestCampaignMaster.setCreatedOn(new Date());
			requestCampaignMaster.setChannel(ChannelType.MYQUEST.getValue());
			requestCampaignMaster.setRetryCount(0);
			StudyInfo studyInfoData = new StudyInfo();
			studyInfoData.setPatientHeadline(requestCampaignMaster.getStudyInfo().getPatientHeadline());
			studyInfoData.setStudyMessage(requestCampaignMaster.getStudyInfo().getStudyMessage());
			studyInfoData.setExternalStudyLink(requestCampaignMaster.getStudyInfo().getExternalStudyLink());
			studyInfoData.setStudyImageName(requestCampaignMaster.getStudyInfo().getStudyImageName());
			studyInfoData.setCreatedBy(Constants.ADMIN);
			studyInfoData.setCreatedOn(new Date());
			studyInfoData = studyInfoRepo.save(studyInfoData);

			requestCampaignMaster.setStudyInfoId(studyInfoData.getStudyInfoId());
			requestCampaignMaster.setStudyInfo(studyInfoData);
			// requestCampaignMaster.setCampaignStatusId(SprinttCampaignStatus.DEPLOYED.getValue());
			requestCampaignMaster.setCampaignStatusId(SprinttCampaignStatus.DRAFT.getValue());
			if (!ObjectUtils.isEmpty(requestCampaignMaster.getSchedule())) {

				if (requestCampaignMaster.getSchedule().isUseDefault()) {
					// call DB to get default schedule information, clone and
					// insert new schedule
					// row
					Optional<Schedule> schedulePersist = scheduleRepository
							.findByTrialIdAndDefaultSchedule(requestCampaignMaster.getTrialId(), 1);
					if (schedulePersist.isPresent()) {
						Schedule schedule = new Schedule();

						schedule.setTrialId(requestCampaignMaster.getTrialId());
						schedule.setCreatedBy(schedulePersist.get().getCreatedBy());
						schedule.setEndDate(schedulePersist.get().getEndDate());
						schedule.setStartDateTime(schedulePersist.get().getStartDateTime());
						schedule.setTimezone(schedulePersist.get().getTimezone());
						schedule.setUseDefault(true);
						schedule.setDefaultSchedule(0);
						schedule.setCreatedOn(new Date());
						scheduleDet = scheduleRepository.save(schedule);

						// poplate RequestCamapaignMaster
						requestCampaignMaster.setScheduleId(scheduleDet.getScheduleId());
						requestCampaignMaster.setSchedule(scheduleDet);

					}
				} else {
					logger.debug("Schedule Data: {} ", requestCampaignMaster.getSchedule());
					Schedule schedule = new Schedule();
					schedule = requestCampaignMaster.getSchedule();
					schedule.setTrialId(requestCampaignMaster.getTrialId());
					schedule.setDefaultSchedule(requestCampaignMaster.getSchedule().isUseDefault() ? 1 : 0);
					schedule.setCreatedOn(new Date());
					scheduleDet = scheduleRepository.save(schedule);
					requestCampaignMaster.setScheduleId(scheduleDet.getScheduleId());
				}
				requestCampaignMaster.setCampaignStatusId(SprinttCampaignStatus.SCHEDULED.getValue());
				TimeZone timeZone = TimeZone
						.getTimeZone(CommonUtil.getTimeZone(requestCampaignMaster.getSchedule().getTimezone()));

				String timeZoneFormat = CommonUtil.getDayLightSavingZone(
						timeZone.inDaylightTime(requestCampaignMaster.getSchedule().getStartDateTime()),
						requestCampaignMaster.getSchedule().getTimezone());

				requestCampaignMaster
						.setNextAction(
								CommonConstants.PATIENT_LIST_TO_BE_SENT
										.replace("#dateTime",
												uiDateFormat
														.format(requestCampaignMaster.getSchedule().getStartDateTime()))
										.replace("GMT", timeZoneFormat));

				requestCampaignMaster
						.setLastAction(
								CommonConstants.SCHEDULED_SUCCESSFULLY
										.replace("#dateTime",
												uiDateFormat
														.format(requestCampaignMaster.getSchedule().getStartDateTime()))
										.replace("GMT", timeZoneFormat));
			} else {
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				requestCampaignMaster.setLastAction(CommonConstants.DRAFT_CREATED.replace("#dateTime", estDateFormat
						.format(instance.getTime()).replace(instance.getTimeZone().toString(), CommonConstants.EST)));
				requestCampaignMaster.setNextAction(CommonConstants.NO_ACTION_NEEDED);
			}
			requestCampaignMaster.setCampaignJobStatusId(CampaignJobStatus.Initiated.getValue());

			if (requestCampaignMaster.getScheduleId() != null) { // set Status
																	// of
																	// Campaign
				requestCampaignMaster.setCampaignStatusId(SprinttCampaignStatus.SCHEDULED.getValue());
			}

			logger.info("Campaign data before save: {}  ", requestCampaignMaster);
			requestCampaignMaster = campaignMasterMyQuestRepository.save(requestCampaignMaster);
			// MyQuestTransactionOutBox creation
			getMyQuestTransactionOutBoxDetails(requestCampaignMaster);

			responseObject.setData(requestCampaignMaster);
			responseObject.setMessage(Constants.SUCCESS);
			responseObject.setHttpStatus(HttpStatus.OK);
			return responseObject;
		}
	}

	@Override
	public ResponseObjectModel uploadFiles(MultipartFile files[], Long trialId) {
		logger.info("Upload Campaign Images process started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		CloudBlobContainer container = null;
		CloudBlobDirectory directory = null;
		int toatlImageInContainer = 0;
		int nonExistingImageCount = 0;
		String downloadPath = new StringBuilder("T").append("_").append(trialId).toString();
		try {
			container = restUtils.getContainer();
			directory = container.getDirectoryReference(downloadPath);
			toatlImageInContainer = CommonUtil.totalContainerImagesCount(directory);
			for (MultipartFile multipartImage : files) {
				if (!CommonUtil.isFileExistInContainer(directory, multipartImage.getOriginalFilename())) {
					nonExistingImageCount++;
				}
			}
			if (toatlImageInContainer + nonExistingImageCount <= 5) {
				for (MultipartFile multipartFile : files) {
					logger.info("Uploading file {}", multipartFile.getOriginalFilename());
					byte[] imageBytes = multipartFile.getBytes();
					String pathWithoutContainerPS = new StringBuilder("T").append("_").append(trialId).append("/")
							.append(multipartFile.getOriginalFilename()).toString();
					CloudBlockBlob blob = container.getBlockBlobReference(pathWithoutContainerPS);
					blob.uploadFromByteArray(imageBytes, 0, imageBytes.length);
				}
			} else {
				responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObjectModel.setMessage(MessageConstants.IMAGE_VALIDATION_TXT);
				return responseObjectModel;
			}
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage(MessageConstants.IMAGE_UPLOAD_SUCCESS);
			logger.info("Upload Campaign Images process completed---");
		} catch (URISyntaxException | StorageException | IOException e) {
			logger.error("Error in uploadFile {}", e);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
		}

		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getImageSASUrl(Long trialId, String imageName) {
		logger.info("getImageSASUrl method started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			String sasUrl = sasGenerationUtil.getBlobSASString(trialId, imageName);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setData(sasUrl);
			responseObjectModel.setMessage(CommonConstants.SUCCESS);
			logger.info("getImageSASUrl method completed ---");
		} catch (InvalidKeyException | MalformedURLException | URISyntaxException | StorageException e) {
			logger.error("Error in generating SAS Url {}", e);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("Error in generating SAS Url");
		}
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel updateDraftMyQuestCampaign(CampaignMasterMyQuest campaignDataMyQuest) {
		logger.info("updateDraftMyQuestCampaign method started---");
		ResponseObjectModel responseObject = new ResponseObjectModel();

		if (StringUtils.isEmpty(campaignDataMyQuest.getSprinttCampaignId())
				|| campaignDataMyQuest.getSprinttCampaignId() == 0) {
			logger.info(MessageConstants.CAMPAIGN_ID_MNDT);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(MessageConstants.CAMPAIGN_ID_MNDT);
			return responseObject;
		}
		if (!StringUtils.isEmpty(validateStudySiteInfo(campaignDataMyQuest, responseObject).getMessage())) {
			return responseObject;
		}
		CampaignMasterMyQuest campaignMasterMyQuest = new CampaignMasterMyQuest();
		Schedule scheduleDet = new Schedule();
		Optional<CampaignMasterMyQuest> campaignMaster = campaignMasterMyQuestRepository
				.findById(campaignDataMyQuest.getSprinttCampaignId());
		if (campaignMaster.isPresent()) {
			campaignMasterMyQuest = campaignMaster.get();
			if (!campaignMasterMyQuest.getCampaignName().equals(campaignDataMyQuest.getCampaignName())) {
				if (!ObjectUtils.isEmpty(campaignDataMyQuest.getTrialId())
						&& !StringUtils.isEmpty(campaignDataMyQuest.getCampaignName())) {
					CampaignMasterMyQuest requestCampaignMaster = campaignMasterMyQuestRepository
							.findByCampaignNameAndTrialId(campaignDataMyQuest.getCampaignName(),
									campaignDataMyQuest.getTrialId());
					if (!ObjectUtils.isEmpty(requestCampaignMaster)) {
						logger.error(LoggingConstants.ERROR_CAMPAIGN_ALREADY_EXIST_LOG);
						responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
						responseObject.setMessage("Campaign Name Already Exists");
						return responseObject;
					}
				}
			}
			campaignMasterMyQuest.setCampaignName(campaignDataMyQuest.getCampaignName());
			campaignMasterMyQuest.setUpdatedBy(Constants.ADMIN);
			campaignMasterMyQuest.setUpdatedOn(new Date());

			Optional<StudyInfo> studyInfo = studyInfoRepo.findById(campaignDataMyQuest.getStudyInfo().getStudyInfoId());
			if (studyInfo.isPresent()) {
				StudyInfo stInfo = studyInfo.get();
				stInfo.setExternalStudyLink(campaignDataMyQuest.getStudyInfo().getExternalStudyLink());
				stInfo.setPatientHeadline(campaignDataMyQuest.getStudyInfo().getPatientHeadline());
				stInfo.setStudyImageName(campaignDataMyQuest.getStudyInfo().getStudyImageName());
				stInfo.setStudyMessage(campaignDataMyQuest.getStudyInfo().getStudyMessage());
				stInfo.setUpdatedBy(Constants.ADMIN);
				stInfo.setUpdatedOn(new Date());
				stInfo = studyInfoRepo.save(stInfo);
				campaignMasterMyQuest.setStudyInfo(stInfo);
			} else {
				logger.error(MessageConstants.STUDY_INFO_NOT_EXIST);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage(MessageConstants.STUDY_INFO_NOT_EXIST);
			}

			// Schedule
			if (!ObjectUtils.isEmpty(campaignDataMyQuest.getSchedule())) {

				if (!ObjectUtils.isEmpty(campaignDataMyQuest.getSchedule().getScheduleId())) {
					Optional<Schedule> scheduleData = scheduleRepository
							.findById(campaignDataMyQuest.getSchedule().getScheduleId());
					if (scheduleData.isPresent()) {
						if (campaignDataMyQuest.getSchedule().isUseDefault()) {
							Optional<Schedule> schedulePersist = scheduleRepository
									.findByTrialIdAndDefaultSchedule(campaignDataMyQuest.getTrialId(), 1);

							if (schedulePersist.isPresent()) {
								Schedule schedule = new Schedule();

								schedule.setTrialId(campaignDataMyQuest.getTrialId());
								schedule.setCreatedBy(schedulePersist.get().getCreatedBy());
								schedule.setEndDate(schedulePersist.get().getEndDate());
								schedule.setStartDateTime(schedulePersist.get().getStartDateTime());
								schedule.setTimezone(schedulePersist.get().getTimezone());
								schedule.setScheduleId(scheduleData.get().getScheduleId());
								schedule.setUseDefault(true);
								schedule.setDefaultSchedule(0);
								schedule.setUpdatedOn(new Date());
								scheduleDet = scheduleRepository.save(schedule);

								// poplate RequestCamapaignMaster
								campaignDataMyQuest.setScheduleId(scheduleDet.getScheduleId());
								campaignDataMyQuest.setSchedule(scheduleDet);

							}
						} else {
							// Update schedule
							Schedule schedule = new Schedule();
							schedule = scheduleData.get();

							// Add below in new method and keep above line and
							// if else here.
							schedule.setTrialId(campaignDataMyQuest.getTrialId());
							schedule.setStartDateTime(
									CommonUtil.convertUIDateToUTC(campaignDataMyQuest.getSchedule().getStartDateTime(),
											campaignDataMyQuest.getSchedule().getTimezone()));
							schedule.setEndDate(campaignDataMyQuest.getSchedule().getEndDate());
							schedule.setTimezone(campaignDataMyQuest.getSchedule().getTimezone());
							schedule.setUpdatedOn(new Date());
							schedule.setDefaultSchedule(0);
							scheduleDet = scheduleRepository.save(schedule);
							campaignMasterMyQuest.setSchedule(scheduleDet);
						}

						TimeZone timeZone = TimeZone
								.getTimeZone(CommonUtil.getTimeZone(campaignDataMyQuest.getSchedule().getTimezone()));

						String timeZoneFormat = CommonUtil.getDayLightSavingZone(
								timeZone.inDaylightTime(campaignDataMyQuest.getSchedule().getStartDateTime()),
								campaignDataMyQuest.getSchedule().getTimezone());

						campaignMasterMyQuest
								.setNextAction(
										CommonConstants.PATIENT_LIST_TO_BE_SENT
												.replace("#dateTime",
														uiDateFormat.format(
																campaignDataMyQuest.getSchedule().getStartDateTime()))
												.replace("GMT", timeZoneFormat));

						campaignMasterMyQuest
								.setLastAction(
										CommonConstants.SCHEDULED_SUCCESSFULLY
												.replace("#dateTime",
														uiDateFormat.format(
																campaignDataMyQuest.getSchedule().getStartDateTime()))
												.replace("GMT", timeZoneFormat));
					} else {
						instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
						campaignMasterMyQuest.setLastAction(CommonConstants.DRAFT_CREATED.replace("#dateTime",
								estDateFormat.format(instance.getTime()).replace(instance.getTimeZone().toString(),
										CommonConstants.EST)));
						campaignMasterMyQuest.setNextAction(CommonConstants.NO_ACTION_NEEDED);
					}
				} else {

					if (campaignDataMyQuest.getSchedule().isUseDefault()) {
						Optional<Schedule> schedulePersist = scheduleRepository
								.findByTrialIdAndDefaultSchedule(campaignDataMyQuest.getTrialId(), 1);

						if (schedulePersist.isPresent()) {
							Schedule schedule = new Schedule();

							schedule.setTrialId(campaignDataMyQuest.getTrialId());
							schedule.setCreatedBy(schedulePersist.get().getCreatedBy());
							schedule.setEndDate(schedulePersist.get().getEndDate());
							schedule.setStartDateTime(schedulePersist.get().getStartDateTime());
							schedule.setTimezone(schedulePersist.get().getTimezone());
							schedule.setUseDefault(true);
							schedule.setDefaultSchedule(0);
							schedule.setCreatedOn(new Date());
							scheduleDet = scheduleRepository.save(schedule);

							// poplate RequestCamapaignMaster
							campaignDataMyQuest.setScheduleId(scheduleDet.getScheduleId());
							campaignDataMyQuest.setSchedule(scheduleDet);

						}
					} else {
						Schedule schedule = new Schedule();

						schedule = campaignDataMyQuest.getSchedule();
						schedule.setTrialId(campaignDataMyQuest.getTrialId());
						schedule.setDefaultSchedule(campaignDataMyQuest.getSchedule().isUseDefault() ? 1 : 0);
						schedule.setCreatedOn(new Date());
						scheduleDet = scheduleRepository.save(schedule);
						campaignMasterMyQuest.setScheduleId(scheduleDet.getScheduleId());
						campaignMasterMyQuest.setSchedule(scheduleDet);
					}

					TimeZone timeZone = TimeZone
							.getTimeZone(CommonUtil.getTimeZone(campaignDataMyQuest.getSchedule().getTimezone()));

					String timeZoneFormat = CommonUtil.getDayLightSavingZone(
							timeZone.inDaylightTime(campaignDataMyQuest.getSchedule().getStartDateTime()),
							campaignDataMyQuest.getSchedule().getTimezone());

					campaignMasterMyQuest
							.setNextAction(
									CommonConstants.PATIENT_LIST_TO_BE_SENT
											.replace("#dateTime",
													uiDateFormat.format(
															campaignDataMyQuest.getSchedule().getStartDateTime()))
											.replace("GMT", timeZoneFormat));

					campaignMasterMyQuest
							.setLastAction(
									CommonConstants.SCHEDULED_SUCCESSFULLY
											.replace("#dateTime",
													uiDateFormat.format(
															campaignDataMyQuest.getSchedule().getStartDateTime()))
											.replace("GMT", timeZoneFormat));
				}

			}

			// next action and last action update for edit
			if (SprinttCampaignStatus.DEPLOYED.getValue().equals(campaignMasterMyQuest.getCampaignStatusId())) {
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				campaignMasterMyQuest.setLastAction(CommonConstants.CAMPAIGN_EDITS_WERE_SENT_LASTACTION
						.replace("#dateTime", estDateFormat.format(instance.getTime())
								.replace(instance.getTimeZone().toString(), CommonConstants.EST)));
				campaignMasterMyQuest.setNextAction(CommonConstants.CAMPAIGN_EDITS_WERE_SENT_NEXTACTION
						.replace("#dateTime", estDateFormat.format(instance.getTime())
								.replace(instance.getTimeZone().toString(), CommonConstants.EST)));
			}

			// TransactionOutBox entry creation for success case only if any
			// entry for the
			// same sprinttCampaignId exists with Initiated status no need to
			// create a new
			// entry
			List<MyQuestTransactionOutBox> myQuestTransactionOutBoxs = myQuestTransactionOutBoxRepo
					.findBySprinttCampaignIdAndStatus(campaignDataMyQuest.getSprinttCampaignId(), Constants.INITIATED);
			if (!ObjectUtils.isEmpty(myQuestTransactionOutBoxs)) {
				logger.info(CommonConstants.INITIATED_TRANSACTION_OUT_BOX_ENTRY_EXISTS);
			} else {
				getMyQuestTransactionOutBoxDetails(campaignDataMyQuest);
			}

			if (campaignMasterMyQuest.getSchedule() != null && campaignDataMyQuest.getCampaignStatusId() != 3) { // set
																													// Status
																													// of
				// Campaign
				campaignMasterMyQuest.setCampaignStatusId(SprinttCampaignStatus.SCHEDULED.getValue());
			} else if (campaignMasterMyQuest.getSchedule() != null && campaignDataMyQuest.getCampaignStatusId() == 3) {
				campaignMasterMyQuest.setCampaignStatusId(SprinttCampaignStatus.DEPLOYED.getValue());
			}

			campaignMasterMyQuestRepository.save(campaignMasterMyQuest);
			responseObject.setData(campaignMasterMyQuest);
			responseObject.setMessage(CommonConstants.SUCCESS);
			responseObject.setHttpStatus(HttpStatus.OK);
		} else {
			logger.error(MessageConstants.CAMPAIGN_NOT_EXIST);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
		}
		return responseObject;
	}

	public void getMyQuestTransactionOutBoxDetails(CampaignMasterMyQuest campaignDataMyQuest) {
		MyQuestTransactionOutBox myQuestTransactionOutBox = new MyQuestTransactionOutBox();
		myQuestTransactionOutBox.setRetryCount(0);
		myQuestTransactionOutBox.setSprinttCampaignId(campaignDataMyQuest.getSprinttCampaignId());
		myQuestTransactionOutBox.setAuditQueue(false);
		myQuestTransactionOutBox.setStatus(Constants.INITIATED);
		myQuestTransactionOutBox.setSendToMyQuest(false);
		myQuestTransactionOutBox.setAuditStatus(Constants.AUDIT_NOT_PROCESSED);
		myQuestTransactionOutBox.setCreatedBy(Constants.ADMIN);
		myQuestTransactionOutBox.setCreatedOn(new Date());
		myQuestTransactionOutBoxRepo.save(myQuestTransactionOutBox);
	}

	@Override
	public ResponseObjectModel getMyQuestCampaign(Long sprinttCampaignId) {
		logger.info("Get MyQuestCampaign method started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (StringUtils.isEmpty(sprinttCampaignId) || sprinttCampaignId == 0) {
			logger.info(MessageConstants.CAMPAIGN_ID_MNDT);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_ID_MNDT);
			return responseObjectModel;
		}
		Optional<CampaignMasterMyQuest> existingCampaignMaster = campaignMasterMyQuestRepository
				.findById(sprinttCampaignId);
		if (existingCampaignMaster.isPresent()) {
			CampaignMasterMyQuest campaignMasterMyQuest = existingCampaignMaster.get();
			Optional<StudyInfo> studyInfo = studyInfoRepo.findById(campaignMasterMyQuest.getStudyInfoId());
			if (studyInfo.isPresent()) {
				campaignMasterMyQuest.setStudyInfo(studyInfo.get());
			}

			if (!ObjectUtils.isEmpty(campaignMasterMyQuest.getScheduleId())) {
				Optional<Schedule> schedule = scheduleRepository.findById(campaignMasterMyQuest.getScheduleId());
				if (schedule.isPresent()) {
					campaignMasterMyQuest.setSchedule(schedule.get());
				}
			}
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setData(campaignMasterMyQuest);
			responseObjectModel.setMessage(CommonConstants.SUCCESS);
			return responseObjectModel;
		} else {
			logger.info(MessageConstants.CAMPAIGN_NOT_EXIST);
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
			return responseObjectModel;
		}
	}

	@Override
	public ResponseObjectModel getImages(Long trialId) {
		logger.info("Get Campaign Images process started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		CloudBlobContainer container = null;
		CloudBlobDirectory directory = null;
		try {
			container = restUtils.getContainer();

			String pathWithoutContainerPS = new StringBuilder("T").append("_").append(trialId).toString();

			directory = container.getDirectoryReference(pathWithoutContainerPS);
			Iterable<ListBlobItem> itr = directory.listBlobs();
			List<String> imagesName = new ArrayList<String>();
			for (ListBlobItem listBlobItem : itr) {
				String tempFileName = listBlobItem.getUri().toString();
				logger.info("Campaign Images File :" + tempFileName);
				String imageName = CommonUtil.getImagesName(pathWithoutContainerPS, tempFileName);
				logger.info("Image Name :" + imageName);
				imagesName.add(imageName);

			}
			responseObjectModel.setData(imagesName);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage("Successfully Received campaign image");
			logger.info("Receiving Campaign Images process completed---");
		} catch (URISyntaxException | StorageException e) {
			logger.error("Error in Receiving Images {}", e);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
		}

		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel deleteTrialImage(Long trialId, String imageName) {
		logger.info("Upload Campaign Images process started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		CloudBlobContainer container = null;
		CloudBlockBlob cloudBlockBlob = null;
		CloudBlobDirectory directory = null;
		try {

			// Check if image exists to other campaign of that trial if yes
			// don't allow to delete.
			Optional<List<CampaignMasterMyQuest>> campaignMaterMyQuestData = campaignMasterMyQuestRepository
					.findCampaignsWithSameImageName(trialId, imageName);
			if (campaignMaterMyQuestData.isPresent()) {
				if (campaignMaterMyQuestData.get().size() > 0) {
					responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
					responseObjectModel.setMessage(
							"This Image cannot be deleted as it has been already used in another campaign of the same trial");
					logger.info(
							"This Image cannot be deleted as it has been already used in another campaign of the same trial");
				} else {
					container = restUtils.getContainer();

					String pathWithoutContainerPS = new StringBuilder("T").append("_").append(trialId).append("/")
							.append(imageName).toString();
					cloudBlockBlob = container.getBlockBlobReference(pathWithoutContainerPS);
					cloudBlockBlob.deleteIfExists();
					String pathWithAfterDeletion = new StringBuilder("T").append("_").append(trialId).toString();

					directory = container.getDirectoryReference(pathWithAfterDeletion);
					Iterable<ListBlobItem> itr = directory.listBlobs();
					List<String> imagesName = new ArrayList<String>();
					for (ListBlobItem listBlobItem : itr) {
						String tempFileName = listBlobItem.getUri().toString();
						logger.info("Campaign Images File :" + tempFileName);
						String imageNameAfterDeletion = CommonUtil.getImagesName(pathWithAfterDeletion, tempFileName);
						logger.info("Image Name :" + imageNameAfterDeletion);
						imagesName.add(imageNameAfterDeletion);

					}
					responseObjectModel.setData(imagesName);
					responseObjectModel.setHttpStatus(HttpStatus.OK);
					responseObjectModel.setMessage("Successfully Deleted campaign image");
					logger.info("Successfully Deleted campaign image");
				}
			}

		} catch (URISyntaxException | StorageException e) {
			logger.error("Error in deleting the Image File {}", e);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
		}

		return responseObjectModel;
	}

	// Map CampaignMasterMyQuest Data to CampaignMaster
	private static CampaignMaster getCampaignMasterWrapper(CampaignMasterMyQuest campaignMasterMyQuest) {
		CampaignMaster campaignData = new CampaignMaster();
		campaignData.setTrialId(campaignMasterMyQuest.getTrialId());
		campaignData.setInclusionCriteria(campaignMasterMyQuest.getInclusionCriteria());
		campaignData.setExclusionCriteria(campaignMasterMyQuest.getExclusionCriteria());
		campaignData.setSprinttCampaignId(campaignMasterMyQuest.getSprinttCampaignId());
		campaignData.setCampaignStatus(campaignMasterMyQuest.getCampaignStatus());
		campaignData.setDifference(campaignMasterMyQuest.isDifference());
		campaignData.setChannel(ChannelType.MYQUEST.getValue());
		return campaignData;
	}

	private Map<String, List<CampaignMasterMyQuest>> getCampaignMasterMyQuestMap(
			List<CampaignMasterMyQuest> campaignMasterMyQuestList) {
		Map<String, List<CampaignMasterMyQuest>> campaignMaterMyQuestMap = new HashMap<String, List<CampaignMasterMyQuest>>();
		List<CampaignMasterMyQuest> draftCampaign = new ArrayList<CampaignMasterMyQuest>();
		List<CampaignMasterMyQuest> scheduledCampaign = new ArrayList<CampaignMasterMyQuest>();
		List<CampaignMasterMyQuest> deployedCampaign = new ArrayList<CampaignMasterMyQuest>();
		List<CampaignMasterMyQuest> closedCampaign = new ArrayList<CampaignMasterMyQuest>();
		List<CampaignMasterMyQuest> discardedCampaign = new ArrayList<CampaignMasterMyQuest>();
		for (CampaignMasterMyQuest campaignMasterMyQuest : campaignMasterMyQuestList) {
			if (campaignMasterMyQuest.getStudyInfoId() != null) {
				Optional<StudyInfo> studyInfo = studyInfoRepo.findById(campaignMasterMyQuest.getStudyInfoId());
				if (studyInfo.isPresent()) {
					campaignMasterMyQuest.setStudyInfo(studyInfo.get());
				}
			}
			if (!ObjectUtils.isEmpty(campaignMasterMyQuest.getScheduleId())) {
				Optional<Schedule> schedule = scheduleRepository.findById(campaignMasterMyQuest.getScheduleId());
				if (schedule.isPresent()) {
					Schedule sch = schedule.get();
					if (!ObjectUtils.isEmpty(sch.getTimezone())) {
						TimeZone timeZone = TimeZone.getTimeZone(CommonUtil.getTimeZone(sch.getTimezone()));
						String scheduleZoneFormat = CommonUtil.getDayLightSavingZone(
								timeZone.inDaylightTime(sch.getStartDateTime()), sch.getTimezone());
						sch.setScheduleDisplay("#dateTime".replace("#dateTime",
								uiDateFormat.format(sch.getStartDateTime()).replace("GMT", scheduleZoneFormat)));
					}
					campaignMasterMyQuest.setSchedule(sch);
				}
			}
			if (SprinttCampaignStatus.getStatusOf(campaignMasterMyQuest.getCampaignStatusId()) != null) {
				switch (SprinttCampaignStatus.getStatusOf(campaignMasterMyQuest.getCampaignStatusId())) {
				case DRAFT:
					draftCampaign.add(campaignMasterMyQuest);
					break;
				case SCHEDULED:
					scheduledCampaign.add(campaignMasterMyQuest);
					break;
				case DEPLOYED:
					deployedCampaign.add(campaignMasterMyQuest);
					break;
				case DISCARDED:
					discardedCampaign.add(campaignMasterMyQuest);
					break;
				case CLOSED:
					closedCampaign.add(campaignMasterMyQuest);
					break;
				}
			}

		}
		campaignMaterMyQuestMap.put(CommonConstants.DRAFT, draftCampaign);
		campaignMaterMyQuestMap.put(CommonConstants.SCHEDULED, scheduledCampaign);
		campaignMaterMyQuestMap.put(CommonConstants.DEPLOYED, deployedCampaign);
		campaignMaterMyQuestMap.put(CommonConstants.DISCARDED, discardedCampaign);
		campaignMaterMyQuestMap.put(CommonConstants.CLOSED, closedCampaign);
		return campaignMaterMyQuestMap;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel createCampaign(CampaignRequest campaignRequest)
			throws ResponseStatusException, EloquaException, JsonProcessingException, URISyntaxException {

		CampaignMaster eloquaCampaign = campaignRequest.getEloquaCampaign();
		CampaignMasterMyQuest myQuestCampaign = campaignRequest.getMyQuestCampaign();
		PauboxCampaignMaster pauboxCampaignMaster = campaignRequest.getPauboxCampaign();

		StringBuilder businessValidation = new StringBuilder();
		if (!ObjectUtils.isEmpty(eloquaCampaign)) {
			businessValidation = validateEloquaCampaignData(eloquaCampaign, businessValidation);
		}
		ResponseObjectModel responseObject = new ResponseObjectModel();
		if (!ObjectUtils.isEmpty(myQuestCampaign)) {
			validateMyQuestCampaignData(myQuestCampaign, businessValidation);

			String studyLinkValidation = validateStudySiteInfo(myQuestCampaign, responseObject).getMessage();
			if (!StringUtils.isEmpty(studyLinkValidation)) {
				businessValidation = businessValidation.length() == 0 ? businessValidation.append(studyLinkValidation)
						: businessValidation.append(",").append(studyLinkValidation);
			}
		}
		if (businessValidation.length() > 0) {
			logger.error("Combined Campaign Request Failed : {} ", businessValidation);
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(businessValidation.toString());
			return responseObject;
		}
		CampaignRequest campaignResponse = new CampaignRequest();
		if (!ObjectUtils.isEmpty(eloquaCampaign)) {
			// create eloqua campaign
			campaignResponse.setEloquaCampaign(
					(CampaignMaster) this.createDraftCampaign(eloquaCampaign, Boolean.TRUE).getData());
		}
		if (!ObjectUtils.isEmpty(myQuestCampaign)) {
			// create myquest campaign
			campaignResponse.setMyQuestCampaign(
					(CampaignMasterMyQuest) this.createDraftMyQuestCampaign(myQuestCampaign, Boolean.TRUE).getData());
		}
		// create paubox campaign
		if (!ObjectUtils.isEmpty(pauboxCampaignMaster)) {
			campaignResponse.setPauboxCampaign((PauboxCampaignMaster) this.pauboxCampaignService
					.createSprinttPauboxCampaign(pauboxCampaignMaster, Boolean.TRUE).getData());
		}

		logger.info("Combined Campaign data {}  ", campaignResponse);
		responseObject.setData(campaignResponse);
		responseObject.setMessage("Success");
		responseObject.setHttpStatus(HttpStatus.OK);
		return responseObject;
	}

	private StringBuilder validateEloquaCampaignData(CampaignMaster eloquaCampaign, StringBuilder businessValidation) {
		CampaignMaster campaignMaster = campaignMasterRepository
				.findByCampaignNameAndTrialId(eloquaCampaign.getCampaignName(), eloquaCampaign.getTrialId());
		if (campaignMaster != null) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_ALREADY_EXIST_LOG);
			// if (StringUtils.isEmpty(businessValidation)) {
			if (businessValidation.length() == 0) {
				businessValidation.append("Eloqua Campaign Name Already Exists");
			}
		}
		return businessValidation;
	}

	private StringBuilder validateMyQuestCampaignData(CampaignMasterMyQuest myQuestCampaign,
			StringBuilder businessValidation) {
		CampaignMasterMyQuest campaignMasterMyQuest = campaignMasterMyQuestRepository
				.findByCampaignNameAndTrialId(myQuestCampaign.getCampaignName(), myQuestCampaign.getTrialId());
		// Check if Campaign name already exists or not
		if (campaignMasterMyQuest != null) {
			logger.error(LoggingConstants.ERROR_CAMPAIGN_ALREADY_EXIST_LOG);
			/*
			 * businessValidation = StringUtils.isEmpty(businessValidation) ?
			 * businessValidation : businessValidation.append("|").
			 * append("MyQuest Campaign Name Already Exists");
			 */
			businessValidation = businessValidation.length() == 0
					? businessValidation.append("MyQuest Campaign Name Already Exists")
					: businessValidation.append(",").append("MyQuest Campaign Name Already Exists");
		}
		return businessValidation;
	}

	/**
	 * @param campaignDataMyQuest
	 * @param responseObject
	 */
	private ResponseObjectModel validateStudySiteInfo(CampaignMasterMyQuest campaignDataMyQuest,
			ResponseObjectModel responseObject) {
		if (!ObjectUtils.isEmpty(campaignDataMyQuest.getSchedule())
				&& (!ObjectUtils.isEmpty(campaignDataMyQuest.getTrialId()))) {
			String studySiteURL = studyUrlUtility.buildStudyURL(campaignDataMyQuest.getTrialId(), "pID");
			if (StringUtils.isEmpty(studySiteURL)) {
				if (ObjectUtils.isEmpty(campaignDataMyQuest.getStudyInfo())
						|| StringUtils.isEmpty(campaignDataMyQuest.getStudyInfo().getExternalStudyLink())) {
					logger.error(MessageConstants.CAMPAIGN_SURVEY_VALIDATION_ERROR);
					responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
					responseObject.setMessage(MessageConstants.CAMPAIGN_SURVEY_VALIDATION_ERROR);
					return responseObject;
				}
			}
		}
		return responseObject;
	}

	@Override
	public ResponseObjectModel endMyQuestCampaign(Long sprinttCampaignId)
			throws CampaignServiceException, WorkflowEngineException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMasterMyQuest> campaignDataOpt = campaignMasterMyQuestRepository.findById(sprinttCampaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMasterMyQuest campaignData = campaignDataOpt.get();

			if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.DEPLOYED.getValue())) {
				campaignData.setCampaignStatusId(SprinttCampaignStatus.CLOSED.getValue());
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				campaignData.setLastAction(CommonConstants.ENDED_ON.replace("#dateTime", estDateFormat
						.format(instance.getTime()).replace(instance.getTimeZone().toString(), CommonConstants.EST)));
				campaignData.setNextAction(null);
				campaignData.setUpdatedOn(new Date());
				campaignData = campaignMasterMyQuestRepository.save(campaignData);
				responseObject.setData(campaignData);
				responseObject.setMessage("Moved to End State successfully");
				responseObject.setHttpStatus(HttpStatus.OK);
			} else {
				logger.error("Campaign can not be ended.");
				responseObject.setMessage("Campaign can not be ended.");
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;
	}

	@Override
	public ResponseObjectModel discardMyQuestCampaign(Long campaignId) throws WorkflowEngineException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMasterMyQuest> campaignDataOpt = campaignMasterMyQuestRepository.findById(campaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMasterMyQuest campaignData = campaignDataOpt.get();
			if (SprinttCampaignStatus.DRAFT.getValue().equals(campaignData.getCampaignStatusId())
					|| SprinttCampaignStatus.SCHEDULED.getValue().equals(campaignData.getCampaignStatusId())) {
				if (SprinttCampaignStatus.DRAFT.getValue().equals(campaignData.getCampaignStatusId())) {

					// TODO mark discarded here
					campaignData.setCampaignStatusId(SprinttCampaignStatus.DISCARDED.getValue());

				} else {
					// here discard a scheduled campaign
					Optional<Schedule> schedule = scheduleRepository.findById(campaignData.getScheduleId());
					if (schedule.isPresent()) {
						Schedule scheduleData = schedule.get();
						Date currentDate = new Date();
						int dateData = scheduleData.getStartDateTime().compareTo(currentDate);
						if (dateData < 0) {
							responseObject.setMessage(Constants.SCHEDULE_DATE_ALREADY_PASSED);
							responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
							return responseObject;
						}
					}
					if (!ValidationHelper.verifyMyQuestScheduleCompletionStatus(campaignData, responseObject)) {
						responseObject.setMessage("Schedule Feed Generation is still in-progress. Try again later.");
						return responseObject;
					}
					// Schedule Campaign mark discarded here
					campaignData.setCampaignStatusId(SprinttCampaignStatus.DISCARDED.getValue());
				}

				// TODO add a check if schedule in behind the current state, if
				// it is then do not discard the scheduled campaign else discrad
				// it.
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
				campaignData.setLastAction(
						CommonConstants.DISCARDED_ON.replace("#dateTime", estDateFormat.format(instance.getTime())));
				campaignData.setNextAction(null);
				campaignData.setUpdatedOn(new Date());
				campaignData = campaignMasterMyQuestRepository.save(campaignData);
				responseObject.setData(campaignData);
				responseObject.setMessage(MessageConstants.CAMPAIGN_DISCARD_SUCCESS);
				responseObject.setHttpStatus(HttpStatus.OK);

			} else {
				responseObject.setMessage(MessageConstants.CAMPAIGN_DISCARD_ERROR);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			}
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
		}
		return responseObject;
	}

	@Override
	public ResponseObjectModel reconsiderMyQuestCampaign(Long sprinttCampaignId) throws CampaignServiceException {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Optional<CampaignMasterMyQuest> campaignDataOpt = campaignMasterMyQuestRepository.findById(sprinttCampaignId);
		if (campaignDataOpt.isPresent()) {
			CampaignMasterMyQuest campaignData = campaignDataOpt.get();

			if (campaignData.getCampaignStatusId().equals(SprinttCampaignStatus.DISCARDED.getValue())) {
				if (StringUtils.isEmpty(campaignData.getScheduleId())) {
					// Draft campaign
					campaignData.setCampaignStatusId(SprinttCampaignStatus.DRAFT.getValue());
				} else {

					// Schedule campaign
					scheduleRepository.deleteSchedule(campaignData.getScheduleId());
					campaignData.setSchedule(null);
					campaignData.setScheduleId(null);
					campaignData.setCampaignStatusId(SprinttCampaignStatus.DRAFT.getValue());

				}
			} else {
				responseObject.setMessage(Constants.CAMPAIN_NOT_IN_DISCARDED_STATE);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				return responseObject;
			}

			campaignData.setLastAction(CommonConstants.DRAFT_CREATED.replace("#dateTime",
					estDateFormat.format(Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST)).getTime())));

			campaignData.setNextAction(CommonConstants.BLANK);
			campaignData.setUpdatedOn(new Date());
			campaignData = campaignMasterMyQuestRepository.save(campaignData);
			responseObject.setData(campaignData);
			responseObject.setMessage("Moved to Draft State successfully");
			responseObject.setHttpStatus(HttpStatus.OK);
		} else {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObject.setMessage("Campaign Doesn't exist");
		}
		return responseObject;

	}
	
	private NotificationPayload buildNotificationPayload(CampaignMasterMyQuest campaignMasterMyQuest,
			String eventName) {
			NotificationPayload notificationPayload = new NotificationPayload();
			notificationPayload.setId(campaignMasterMyQuest.getSprinttCampaignId().intValue());
			notificationPayload.setName(campaignMasterMyQuest.getCampaignName());
			notificationPayload.setUserid(campaignMasterMyQuest.getCreatedBy());
			notificationPayload.setEventName(eventName);
			return notificationPayload;
			}
	
	private NotificationPayload buildNotificationPayload(CampaignMaster campaignMaster,
			String eventName) {
			NotificationPayload notificationPayload = new NotificationPayload();
			notificationPayload.setId(campaignMaster.getSprinttCampaignId());
			notificationPayload.setName(campaignMaster.getCampaignName());
			notificationPayload.setUserid(campaignMaster.getCreatedBy());
			notificationPayload.setEventName(eventName);
			return notificationPayload;
			}
}
