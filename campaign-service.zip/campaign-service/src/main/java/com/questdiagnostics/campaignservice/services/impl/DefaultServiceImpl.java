package com.questdiagnostics.campaignservice.services.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.util.StringUtils;
import com.questdiagnostics.campaignservice.util.RESTUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.constant.LoggingConstants;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.repository.EmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.ReminderRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.request.model.EmailGroupIndividualResponse;
import com.questdiagnostics.campaignservice.response.model.DefaultCampaignResponse;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.DefaultService;
import com.questdiagnostics.campaignservice.util.CommonUtil;
import com.questdiagnostics.campaignservice.util.SpringBeanUtil;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class DefaultServiceImpl implements DefaultService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private ReminderRepository reminderRepository;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Autowired
	RESTUtils restUtils;

	@Value("${sprintt.email.group.id}")
	private String emailGroupId;

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Schedule persistDefaultScheduler(Schedule schedule) {

		// get schedule to check if exists throw message else save
		Schedule scheduleDB = null;
		Optional<Schedule> scheduleDetails = scheduleRepository.findByTrialIdAndDefaultSchedule(schedule.getTrialId(),
				1);
		if (scheduleDetails.isPresent()) {
			logger.debug("Error occured while creating the Schedule, already exists: {} ", scheduleDetails);

			// to do update the schedule data

			Schedule schedulePersist = scheduleDetails.get();

			schedulePersist.setTrialId(schedule.getTrialId());
			schedulePersist
					.setDefaultSchedule(schedule.getDefaultSchedule() != null ? schedule.getDefaultSchedule() : 1);
			schedulePersist.setStartDateTime(schedule.getStartDateTime() != null ? schedule.getStartDateTime() : null);
			schedulePersist.setTimezone(schedule.getTimezone() != null ? schedule.getTimezone() : null);

			// schedulePersisit.setStartDateTime(
			// CommonUtil.convertUIDateToUTC(schedule.getStartDateTime(),
			// schedule.getTimezone()));
			if (schedule.getEndDate() != null) {
				schedulePersist
						.setEndDate(CommonUtil.convertUIDateToUTC(schedule.getEndDate(), schedule.getTimezone()));
			} else {
				schedulePersist.setEndDate(null);
			}
			// schedulePersist.setEndDate(CommonUtil.convertUIDateToUTC(schedule.getEndDate(),
			// schedule.getTimezone()));
			schedulePersist.setUpdatedOn(schedule.getUpdatedOn() != null ? schedule.getUpdatedOn() : null);
			schedulePersist.setUpdatedBy(schedule.getUpdatedBy() != null ? schedule.getUpdatedBy() : null);
			scheduleDB = scheduleRepository.save(schedulePersist);

		} else {

			schedule.setStartDateTime(schedule.getStartDateTime() != null ? schedule.getStartDateTime() : null);
			schedule.setCreatedOn(new Date());
			schedule.setDefaultSchedule(schedule.getDefaultSchedule() != null ? schedule.getDefaultSchedule() : 1);
			schedule.setEndDate(schedule.getEndDate() != null ? schedule.getEndDate() : null);
			scheduleDB = scheduleRepository.save(schedule);

		}
		return scheduleDB;

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Reminder persistDefaultReminder(Reminder reminderRequest) {
		Optional<Reminder> reminderDetails = reminderRepository
				.findByTrialIdAndDefaultReminder(reminderRequest.getTrialId(), 1);
		Reminder reminderDB = null;
		if (reminderDetails.isPresent()) {
			Reminder reminder = reminderDetails.get();

			if (!reminderRequest.getNonClicked().equals(false) || !reminderRequest.getNonOpener().equals(false)) {
				reminder.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminderRequest));
			} else {
				reminder.setRemindTo(null);
			}
			reminder.setUpdatedOn(new Date());
			reminder.setTrialId(reminderRequest.getTrialId());
			if (reminderRequest.getRemindOnDateTime() != null) {
				reminder.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminderRequest.getRemindOnDateTime(),
						reminderRequest.getReminderTimeZone()));
			} else {
				reminder.setRemindOnDateTime(null);
			}

			reminder.setReminderTimeZone(
					reminderRequest.getReminderTimeZone() != null ? reminderRequest.getReminderTimeZone() : null);
			reminder.setCreatedOn(
					reminderRequest.getCreatedOn() != null ? reminderRequest.getCreatedOn() : reminder.getCreatedOn());
			reminder.setCreatedBy(
					reminderRequest.getCreatedBy() != null ? reminderRequest.getCreatedBy() : reminder.getCreatedBy());
			reminder.setUpdatedBy(reminderRequest.getUpdatedBy() != null ? reminderRequest.getUpdatedBy() : null);
			reminder.setNonOpener(reminderRequest.getNonOpener());
			reminder.setNonClicked(reminderRequest.getNonClicked());
			reminder.setDefaultReminder(
					reminderRequest.getDefaultReminder() != null ? reminderRequest.getDefaultReminder() : 1);

			reminderDB = reminderRepository.save(reminder);
		} else {
			if (!reminderRequest.getNonClicked().equals(false) || !reminderRequest.getNonOpener().equals(false)) {
				reminderRequest.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminderRequest));
			} else {
				reminderRequest.setRemindTo(null);
			}
			reminderRequest.setCreatedOn(new Date());
			reminderRequest.setDefaultReminder(
					reminderRequest.getDefaultReminder() != null ? reminderRequest.getDefaultReminder() : 1);

			if (reminderRequest.getRemindOnDateTime() != null) {
				reminderRequest.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminderRequest.getRemindOnDateTime(),
						reminderRequest.getReminderTimeZone()));
			} else {
				reminderRequest.setRemindOnDateTime(null);
			}

			reminderDB = reminderRepository.save(reminderRequest);
		}
		return reminderDB;
	}

	@Override
	public Schedule updateDefaultSchedule(Schedule scheduleRequest) {

		// check if schedule is present then update else throw error
		Optional<Schedule> scheduleIdResponse = scheduleRepository.findByScheduleId(scheduleRequest.getScheduleId());
		Schedule schedule;
		if (scheduleIdResponse.isPresent()) {
			Optional<Schedule> scheduleDetails = scheduleRepository.findByTrialIdAndScheduleIdAndDefaultSchedule(
					scheduleRequest.getTrialId(), scheduleRequest.getScheduleId(), 1);

			if (scheduleDetails.isPresent()) {
				Schedule scheduleData = scheduleDetails.get();
				scheduleData.setCreatedBy(scheduleRequest.getCreatedBy());
				scheduleData.setEndDate(scheduleRequest.getEndDate());
				scheduleData.setTimezone(scheduleRequest.getTimezone());
				scheduleData.setUpdatedBy(scheduleRequest.getUpdatedBy());
				scheduleData.setUpdatedOn(new Date());
				scheduleData.setStartDateTime(CommonUtil.convertUIDateToUTC(scheduleRequest.getStartDateTime(),
						scheduleRequest.getTimezone()));
				scheduleData.setCreatedOn(new Date());

				schedule = scheduleRepository.save(scheduleData);
			} else {
				logger.debug("Error occured while updating the Schedule : {} ", scheduleDetails);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_SCHEDULE_UPDATION);
			}
		} else {
			logger.debug("Error occured while updating the Schedule : {} ", scheduleIdResponse);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
					LoggingConstants.ERROR_SCHEDULE_UPDATION_SCHEDULEID);
		}

		return schedule;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Reminder updateDefaultReminder(Reminder reminderRequest) {

		Optional<Reminder> reminderIdReponse = reminderRepository.findByReminderId(reminderRequest.getReminderId());
		Reminder reminderResponse = null;
		if (reminderIdReponse.isPresent()) {
			Optional<Reminder> reminderValue = reminderRepository.findByTrialIdAndReminderIdAndDefaultReminder(
					reminderRequest.getTrialId(), reminderRequest.getReminderId(), 1);

			if (reminderValue.isPresent()) {
				reminderRequest.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminderRequest));
				reminderRequest.setUpdatedOn(new Date());
				reminderRequest.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminderRequest.getRemindOnDateTime(),
						reminderRequest.getReminderTimeZone()));
				reminderResponse = reminderRepository.save(reminderRequest);
			} else {
				logger.debug("Error occured while updating the Reminder : {} ", reminderValue);
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_REMINDER_UPDATION);
			}
		} else {
			logger.debug("Error occured while updating the Reminder : {} ", reminderIdReponse);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
					LoggingConstants.ERROR_REMINDER_UPDATION_REMINDERID);
		}

		return reminderResponse;
		/* Need to prepare response data which will send to ui */
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public DefaultCampaignResponse persistDefault(Schedule schedule, Reminder reminder, EmailTemplate emailTemplate) {
		DefaultCampaignResponse campaignResponse = new DefaultCampaignResponse();

		Schedule scheduleDetails = null;
		Reminder reminderDetails = null;
		EmailTemplate emailTemplateDetails = null;
		// save Default Scheduler

		if (schedule != null && schedule.getStartDateTime() != null) {
			scheduleDetails = persistDefaultScheduler(schedule);
			campaignResponse.setSchedule(scheduleDetails);
		} else {
			scheduleDetails = persistSchedule(schedule);
			campaignResponse.setSchedule(scheduleDetails);
		}

		// save Default Reminder
		if (reminder != null && reminder.getRemindOnDateTime() != null) {
			reminderDetails = persistDefaultReminder(reminder);
			campaignResponse.setReminder(reminderDetails);
		} else {
			reminderDetails = persistReminder(reminder);
			campaignResponse.setReminder(reminderDetails);
		}

		// save Default Email Template
		if (emailTemplate != null) {
			emailTemplateDetails = persistEmailTempalte(emailTemplate);
			campaignResponse.setEmailTemplate(emailTemplateDetails);
		}

		// set Repsonce in Campaign Response
		campaignResponse.setSchedule(scheduleDetails);
		campaignResponse.setReminder(reminderDetails);
		campaignResponse.setEmailTemplate(emailTemplateDetails);

		return campaignResponse;

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public DefaultCampaignResponse updateDefault(Schedule scheduleRequest, Reminder reminderRequest,
			EmailTemplate emailTemplateRequest) {
		DefaultCampaignResponse campaignResponse = new DefaultCampaignResponse();

		Schedule scheduleDetails = null;
		Reminder reminderDetails = null;
		EmailTemplate emailTemplateDetails = null;

		// Update Default Scheduler
		if (scheduleRequest != null) {
			scheduleDetails = updateDefaultSchedule(scheduleRequest);
		}

		// Update Default Reminder
		if (reminderRequest != null) {
			reminderDetails = updateDefaultReminder(reminderRequest);
		}

		// Update Default Email Template

		if (emailTemplateRequest != null) {
			emailTemplateDetails = updateEmailTempalte(emailTemplateRequest);
		}

		// set Repsonce in Campaign Response
		campaignResponse.setSchedule(scheduleDetails);
		campaignResponse.setReminder(reminderDetails);
		campaignResponse.setEmailTemplate(emailTemplateDetails);

		return campaignResponse;
	}

	/**
	 *
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel getDefault(Long trialId) {
		DefaultCampaignResponse defaultCampaignResponse = new DefaultCampaignResponse();

		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		if (getDefaultSchedule(trialId) == null && getDefaultReminder(trialId) == null
				&& getEmailTemplateByTrialId(trialId) == null) {
			responseObjectModel.setData(null);
			responseObjectModel.setMessage("Details not found");
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
		} else {
			defaultCampaignResponse.setTrialId(trialId);
			defaultCampaignResponse.setSchedule(getDefaultSchedule(trialId));
			defaultCampaignResponse.setReminder(getDefaultReminder(trialId));
			defaultCampaignResponse.setEmailTemplate(getEmailTemplateByTrialId(trialId));

			responseObjectModel.setData(defaultCampaignResponse);
			responseObjectModel.setMessage("Success");
			responseObjectModel.setHttpStatus(HttpStatus.OK);

		}
		//
		return responseObjectModel;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Reminder getDefaultReminder(Long trialId) {
		Optional<Reminder> reminders = reminderRepository.findByTrialIdAndDefaultReminder(trialId, 1);

		Reminder reminder = null;
		if (reminders.isPresent()) {
			reminder = reminders.get();
			reminder.setTrialId(trialId);
			Reminder reminderValues = null;
			reminderValues = CommonUtil.getUIValuesforRemindTo(reminder);
			reminder.setNonOpener(reminderValues.getNonOpener());
			reminder.setNonClicked(reminderValues.getNonClicked());
		} else {
			logger.debug("Error occured while getting the Reminder.Trail id does not exist : {} ", trialId);
			// throw new ResponseStatusException(HttpStatus.NOT_FOUND,
			// LoggingConstants.ERROR_REMINDER_GETTING);
			return reminder;
		}

		return reminder;
		/* Need to prepare response data which will send to ui */
	}

	@Override
	public Schedule getDefaultSchedule(Long trialId) {

		// get list of schedule by trial Id
		Optional<Schedule> scheduleDetails = scheduleRepository.findByTrialIdAndDefaultSchedule(trialId, 1);
		Schedule schedule = null;
		if (scheduleDetails.isPresent()) {
			schedule = scheduleDetails.get();
			return schedule;
		} else {

			logger.debug("Error occured while getting the Schedule.Trail id does not exist : {} ", trialId);

			return schedule;
			// throw new ResponseStatusException(HttpStatus.NOT_FOUND,
			// LoggingConstants.ERROR_SCHEDULE_GETTING);

		}
	}

	// get Email Template API
	public List<EmailTemplateResponse> getListOfEmail() throws JsonProcessingException, URISyntaxException {

		EmailGroupIndividualResponse emailGroupindividualResponse = null;
		List<EmailTemplateResponse> emailTemplateResponse = new ArrayList<>();
		EmailTemplateResponse emailTemplate = null;

		//String emailGroupUrl = "/1.0/assets/email/group/" + emailGroupId+"?depth=partial";
		String emailGroupUrl = "/1.0/assets/email/group/" + emailGroupId+"?depth=complete";

		logger.info("EmailTemplate Url=="+emailGroupUrl);
		
		emailGroupindividualResponse = restUtils
				.execute(null, emailGroupUrl, HttpMethod.GET, EmailGroupIndividualResponse.class).getBody();
		if (!StringUtils.isEmpty(emailGroupindividualResponse)) {
			if (!StringUtils.isEmpty(emailGroupindividualResponse.getEmailIds())) {
				for (String emailIds : emailGroupindividualResponse.getEmailIds()) {
					//String emailUrl = "/1.0/assets/email/" + emailIds +"?depth=minimal";
					String emailUrl = "/2.0/assets/email/" + emailIds +"?depth=minimal";
					emailTemplate = restUtils.execute(null, emailUrl, HttpMethod.GET, EmailTemplateResponse.class)
							.getBody();
					emailTemplateResponse.add(emailTemplate);

				}
			}

		}

		return emailTemplateResponse;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public EmailTemplate persistEmailTempalte(EmailTemplate emailTemplate) {

		// get EmailTemplate to check if exists throw message else save
		EmailTemplate persistEmailTemplates = null;
		// EmailTemplate emailTemplateDetails =
		// emailTemplateRepository.findEmailTempByTrialId(emailTemplate.getTrialId());
		EmailTemplate emailTemplateDetails = emailTemplateRepository
				.findByTrialIdAndDefaultEmailTemp(emailTemplate.getTrialId(), 1);
		if (emailTemplateDetails != null) {

			emailTemplateDetails.setUpdatedOn(emailTemplate.getUpdatedOn());
			emailTemplateDetails.setUpdatedBy(emailTemplate.getUpdatedBy());
			emailTemplateDetails.setDefaultEmailTemp(emailTemplate.getDefaultEmailTemp());
			emailTemplateDetails.setName(emailTemplate.getName());
			emailTemplateDetails.setTrialId(emailTemplate.getTrialId());
			emailTemplateDetails.setEloquaEmailTempId(emailTemplate.getEloquaEmailTempId());

			persistEmailTemplates = emailTemplateRepository.save(emailTemplateDetails);

		} else {

			emailTemplate.setCreatedOn(new Date());
			persistEmailTemplates = emailTemplateRepository.save(emailTemplate);

		}
		return persistEmailTemplates;

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public EmailTemplate updateEmailTempalte(EmailTemplate emailTemplate) {

		// check if Email Template is present then update else throw error
		Optional<EmailTemplate> emailTemplateResponse = emailTemplateRepository
				.findByEmailTemplateId(emailTemplate.getEmailTemplateId());
		EmailTemplate persistEmailTemplates = null;

		if (emailTemplateResponse.isPresent()) {

			EmailTemplate emailTemplates = emailTemplateResponse.get();
			emailTemplates.setCreatedBy(emailTemplate.getCreatedBy());
			emailTemplates.setCreatedOn(emailTemplate.getCreatedOn());
			emailTemplates.setDefaultEmailTemp(emailTemplate.getDefaultEmailTemp());
			emailTemplates.setEloquaEmailTempId(emailTemplate.getEloquaEmailTempId());
			emailTemplates.setName(emailTemplate.getName());
			emailTemplates.setTrialId(emailTemplate.getTrialId());
			emailTemplates.setUpdatedBy(emailTemplate.getUpdatedBy());
			emailTemplates.setUpdatedOn(emailTemplate.getUpdatedOn());

			persistEmailTemplates = emailTemplateRepository.save(emailTemplates);

		} else {
			logger.debug("Error occured while updating the Email Template : {} ", emailTemplateResponse);
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, LoggingConstants.ERROR_EMAIL_UPDATION);
		}

		return persistEmailTemplates;
	}

	// get Email Template By Id
	@Override
	public EmailTemplate getEmailTemplateByTrialId(Long trialId) {

		// get list of schedule by trial Id
		EmailTemplate emailTemplateDetails = emailTemplateRepository.findByTrialIdAndDefaultEmailTemp(trialId, 1);

		if (emailTemplateDetails != null) {
			return emailTemplateDetails;
		} else {
			logger.debug("Error occured while getting the Email Template.Trail id does not exist : {} ", trialId);
			// throw new ResponseStatusException(HttpStatus.NOT_FOUND,
			// LoggingConstants.ERROR_EMAIL_GETTING);
			return emailTemplateDetails;
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Schedule persistSchedule(Schedule schedule) {
		Schedule scheduleDB = null;
		Optional<Schedule> scheduleDetails = scheduleRepository.findByTrialIdAndDefaultSchedule(schedule.getTrialId(),
				1);
		if (scheduleDetails.isPresent()) {
			scheduleDB = scheduleDetails.get();
			scheduleRepository.deleteSchedule(scheduleDB.getScheduleId());

		}
		return null;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Reminder persistReminder(Reminder reminder) {
		Optional<Reminder> reminderDetails = reminderRepository.findByTrialIdAndDefaultReminder(reminder.getTrialId(),
				1);
		if (reminderDetails.isPresent()) {
			reminderRepository.deleteReminder(reminderDetails.get().getReminderId());

		}
		return null;
	}
}