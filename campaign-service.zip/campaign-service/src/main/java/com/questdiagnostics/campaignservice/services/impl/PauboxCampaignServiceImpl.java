package com.questdiagnostics.campaignservice.services.impl;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.constant.MessageConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignModel;
import com.questdiagnostics.campaignservice.model.PauboxCampaignEmailTemplate;
import com.questdiagnostics.campaignservice.model.PauboxCampaignMaster;
import com.questdiagnostics.campaignservice.model.PauboxReminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.repository.PauboxCampaignEmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.PauboxCampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.PauboxReminderRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.PauboxCampaignService;
import com.questdiagnostics.campaignservice.util.CommonUtil;

@Service
public class PauboxCampaignServiceImpl implements PauboxCampaignService {

	private static final long serialVersionUID = 2613116285861609878L;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private PauboxCampaignMasterRepository pauboxCampaignMasterRepository;

	@Autowired
	private PauboxReminderRepository pauboxReminderRepository;
	
	@Autowired
	private PauboxCampaignEmailTemplateRepository pauboxEmailRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${sprintt.candidate.service.generate.patient.url}")
	private String candidateServiceGenPatientUrl;

	@Override
	public ResponseObjectModel createSprinttPauboxCampaign(PauboxCampaignMaster pauboxCampaignData, Boolean isCombined)
			throws URISyntaxException, JsonProcessingException {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();

		if (pauboxCampaignData.getSchedule() != null) {
			Schedule schedule = new Schedule();
			schedule.setTrialId(pauboxCampaignData.getTrialId());
			schedule.setCreatedBy(pauboxCampaignData.getSchedule().getCreatedBy());
			schedule.setEndDate(pauboxCampaignData.getSchedule().getEndDate());
			schedule.setStartDateTime(pauboxCampaignData.getSchedule().getStartDateTime());
			schedule.setTimezone(pauboxCampaignData.getSchedule().getTimezone());
			schedule.setUseDefault(true);
			schedule.setDefaultSchedule(0);
			schedule.setCreatedOn(new Date());
			Schedule scheduleDet = scheduleRepository.save(schedule);
			pauboxCampaignData.setScheduleId(scheduleDet.getScheduleId());
		}
		if (!pauboxCampaignData.getReminder().isEmpty()) {
			List<PauboxReminder> remindersList = new ArrayList<>();
			for(PauboxReminder reminder:pauboxCampaignData.getReminder()) {
				PauboxReminder reminderValue = new PauboxReminder();
				reminderValue.setCreatedOn(new Date());
				reminderValue.setReminderTimeZone(reminder.getReminderTimeZone());
				reminderValue.setRemindOnDateTime(reminder.getRemindOnDateTime());
				reminderValue.setTrialId(pauboxCampaignData.getTrialId());
				reminderValue.setCreatedBy(reminder.getCreatedBy());
				reminderValue.setPauboxCampaignMaster(pauboxCampaignData);
				remindersList.add(reminderValue);
			}
			pauboxCampaignData.setReminder(remindersList);
		}
		pauboxCampaignData.setCampaignJobStatusId(CampaignJobStatus.Initiated.getValue());
		pauboxCampaignData.setCreatedBy(pauboxCampaignData.getCreatedBy());
		pauboxCampaignData.setCreatedOn(new Date());
		PauboxCampaignMaster pauboxMaster = pauboxCampaignMasterRepository.save(pauboxCampaignData);
		/*Populate Email Template mapping */
		if(!ObjectUtils.isEmpty(pauboxCampaignData.getSchedule())){
			PauboxCampaignEmailTemplate pauboxCampaignEmailTemplate=new PauboxCampaignEmailTemplate();
			pauboxCampaignEmailTemplate.setTrialId(pauboxCampaignData.getTrialId());
			pauboxCampaignEmailTemplate.setCampaignId(pauboxMaster.getSprinttCampaignId());
			pauboxCampaignEmailTemplate.setType("Schedule");
			pauboxCampaignEmailTemplate.setCreatedBy(pauboxCampaignData.getCreatedBy());
			pauboxCampaignEmailTemplate.setCreatedOn(new Date());
			pauboxEmailRepository.save(pauboxCampaignEmailTemplate);
		}
		if(!ObjectUtils.isEmpty(pauboxCampaignData.getReminder())){
			PauboxCampaignEmailTemplate pauboxCampaignEmailTemplate=new PauboxCampaignEmailTemplate();
			pauboxCampaignEmailTemplate.setTrialId(pauboxCampaignData.getTrialId());
			pauboxCampaignEmailTemplate.setCampaignId(pauboxMaster.getSprinttCampaignId());
			pauboxCampaignEmailTemplate.setType("Reminder");
			pauboxCampaignEmailTemplate.setCreatedBy(pauboxCampaignData.getCreatedBy());
			pauboxCampaignEmailTemplate.setCreatedOn(new Date());
			pauboxEmailRepository.save(pauboxCampaignEmailTemplate);
		}
		/* Initiate patient list generation */
		campaignPatientGeneration(pauboxMaster);
		responseObjectModel.setData(pauboxMaster);
		responseObjectModel.setHttpStatus(HttpStatus.OK);
		responseObjectModel.setMessage("Success");
		return responseObjectModel;
	}
	private void campaignPatientGeneration(PauboxCampaignMaster pauboxCampaignData) {
		logger.info("Patient campaign generation for campaign id: {} ", pauboxCampaignData.getSprinttCampaignId());
		Long sprinttCampaignId = pauboxCampaignData.getSprinttCampaignId();
		CompletableFuture.supplyAsync(() -> {
			HttpHeaders headers = CommonUtil.prepareHeader();
			HttpEntity<CampaignModel> httpEntity = new HttpEntity<>(generateCandidateServiePostObject(pauboxCampaignData),
					headers);
			logger.info("Candidate service ", httpEntity);		
			return restTemplate.postForEntity(candidateServiceGenPatientUrl, httpEntity, Boolean.class).getBody();
		}).whenComplete((result, ex) -> {
			if (!ObjectUtils.isEmpty(ex)) {
				/* Update paubox campaign master */
				updateCampaignJobStatus(sprinttCampaignId, CampaignJobStatus.Failed);
				logger.info("update campaignJobStatus for failed");
			}
		}).thenAcceptAsync(jobStatus -> {
			if (jobStatus.booleanValue()) {
				/* Update paubox campaign master */
				updateCampaignJobStatus(sprinttCampaignId, CampaignJobStatus.Fecthed);
				logger.info("update campaignJobStatus for fetched");
			} else {
				/* Update paubox campaign master */
				updateCampaignJobStatus(sprinttCampaignId, CampaignJobStatus.Failed);
				logger.info("update campaignJobStatus for failed");
			}
		});

	}
	private CampaignModel generateCandidateServiePostObject(PauboxCampaignMaster pauboxCampaignData) {
		CampaignModel campaignModel = new CampaignModel();
		campaignModel.setSprinttCampaignId(pauboxCampaignData.getSprinttCampaignId());
		campaignModel.setTrialId(pauboxCampaignData.getTrialId());
		campaignModel.setDifference(pauboxCampaignData.isDifference());
		campaignModel.setInclusionCriteria(pauboxCampaignData.getInclusionCriteria());
		campaignModel.setExclusionCriteria(pauboxCampaignData.getExclusionCriteria());
		campaignModel.setChannel(pauboxCampaignData.getChannel());
		campaignModel.setCampaignStatus(SprinttCampaignStatus.SCHEDULED.name());
		logger.info("candidate service generated for paubox campaign data: {} ", campaignModel);
		return campaignModel;
	}
	private void updateCampaignJobStatus(Long sprinttCampaignId, CampaignJobStatus staus) {
		pauboxCampaignMasterRepository.findById(sprinttCampaignId).ifPresent(pauboxCampaignData -> {
			pauboxCampaignData.setCampaignJobStatusId(staus.getValue());
			pauboxCampaignMasterRepository.save(pauboxCampaignData);
		});

	}

	@Override
	public ResponseObjectModel updatePauboxCampaign(PauboxCampaignMaster pauboxCampaignData, boolean now)
			throws URISyntaxException, JsonProcessingException {
		
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		PauboxCampaignMaster pauboxCampaignMasterDB = pauboxCampaignMasterRepository
				.findBySprinttCampaignId(pauboxCampaignData.getSprinttCampaignId());
		pauboxCampaignMasterDB.setCampaignName(pauboxCampaignData.getCampaignName());
		pauboxCampaignMasterDB.setInclusionCriteria(pauboxCampaignData.getInclusionCriteria());
		pauboxCampaignMasterDB.setExclusionCriteria(pauboxCampaignData.getExclusionCriteria());
		if (!pauboxCampaignData.getReminder().isEmpty()) {
			List<PauboxReminder> reminders = new ArrayList<>();
			for (PauboxReminder reminder : pauboxCampaignData.getReminder()) {
				if (!ObjectUtils.isEmpty(reminder.getReminderId())
						&& ObjectUtils.isEmpty(reminder.getRemindOnDateTime())) {
					pauboxReminderRepository.deleteReminder(reminder.getReminderId());
				} else if (ObjectUtils.isEmpty(reminder.getReminderId())) {
					// Add a new reminder
					PauboxReminder reminderValue = new PauboxReminder();
					reminderValue.setUpdatedOn(new Date());
					reminderValue.setReminderTimeZone(reminder.getReminderTimeZone());
					reminderValue.setRemindOnDateTime(reminder.getRemindOnDateTime());
					reminderValue.setTrialId(pauboxCampaignData.getTrialId());
					reminderValue.setUpdatedBy(reminder.getCreatedBy());
					reminderValue.setPauboxCampaignMaster(pauboxCampaignMasterDB);
					reminders.add(reminderValue);
				}
			}
			pauboxCampaignMasterDB.setReminder(reminders);
		}
	
		Optional<Schedule> schedule = scheduleRepository.findByScheduleId(pauboxCampaignMasterDB.getScheduleId());
		if(schedule.isPresent()){
			Schedule requestSchedule = pauboxCampaignData.getSchedule();
			Schedule scheduleData = schedule.get();
			scheduleData.setTrialId(pauboxCampaignMasterDB.getTrialId());
			scheduleData.setStartDateTime(CommonUtil.convertUIDateToUTC(requestSchedule.getStartDateTime(),
					requestSchedule.getTimezone()));
			scheduleData.setEndDate(requestSchedule.getEndDate());
			scheduleData.setUpdatedOn(new Date());
			scheduleData.setDefaultSchedule(0);
			scheduleData = scheduleRepository.save(scheduleData);
			pauboxCampaignMasterDB.setSchedule(scheduleData);
		}
		pauboxCampaignMasterDB.setUpdatedOn(new Date());
		pauboxCampaignMasterDB.setUpdatedBy(pauboxCampaignMasterDB.getCreatedBy());
		PauboxCampaignMaster pauboxCampaignMaster = pauboxCampaignMasterRepository.save(pauboxCampaignMasterDB);
		responseObjectModel.setData(pauboxCampaignMaster);
		responseObjectModel.setHttpStatus(HttpStatus.OK);
		responseObjectModel.setMessage("SUCCESS");
		return responseObjectModel;
	}
	

	@Override
	public ResponseObjectModel getPauboxCampaign(Long sprinttCampaignId) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (StringUtils.isEmpty(sprinttCampaignId) || sprinttCampaignId == 0) {
			logger.info(MessageConstants.CAMPAIGN_ID_MNDT);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_ID_MNDT);
			return responseObjectModel;
		}

		Optional<PauboxCampaignMaster> existingPauboxCampaignMaster = pauboxCampaignMasterRepository
				.findById(sprinttCampaignId);
		if (existingPauboxCampaignMaster.isPresent()) {

			PauboxCampaignMaster pauboxMaster = existingPauboxCampaignMaster.get();
			Long scheduleId = pauboxMaster.getScheduleId();
			if (scheduleId != null && scheduleId != 0) {
				Optional<Schedule> scheduleDB = scheduleRepository.findById(scheduleId);
				if (scheduleDB.isPresent()) {
					Schedule schedulePersist = scheduleDB.get();
					if (schedulePersist.getDefaultSchedule() == 1)
						schedulePersist.setUseDefault(true);
					else
						schedulePersist.setUseDefault(false);
					pauboxMaster.setSchedule(schedulePersist);

				}
			}
			List<PauboxReminder> reminder = new ArrayList<>();
			for (PauboxReminder reminderData : pauboxMaster.getReminder()) {
				if(pauboxMaster.getCampaignJobStatusId()==6){
					reminderData.setStatus("Sent");
				}else {
					reminderData.setStatus("Scheduled");
				}
				reminder.add(reminderData);
			}

			pauboxMaster.setReminder(reminder);
			
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage("Success");
			responseObjectModel.setData(pauboxMaster);
			return responseObjectModel;
		} else {
			logger.info(MessageConstants.CAMPAIGN_NOT_EXIST);
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_NOT_EXIST);
			return responseObjectModel;
		}
	}
}
