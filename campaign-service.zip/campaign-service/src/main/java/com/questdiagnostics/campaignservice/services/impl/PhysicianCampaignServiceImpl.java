package com.questdiagnostics.campaignservice.services.impl;

import static com.questdiagnostics.campaignservice.request.model.CampaignElementType.CAMPAIGN_SEGMENT;

import java.io.Serializable;
import java.math.BigInteger;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.constant.MessageConstants;
import com.questdiagnostics.campaignservice.enums.EloquaCampaignStatus;
import com.questdiagnostics.campaignservice.enums.PhysicianCampaignStatusEnums;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.manager.CampaignManager;
import com.questdiagnostics.campaignservice.messaging.NotificationPublisher;
import com.questdiagnostics.campaignservice.messaging.models.NotificationPayload;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.NPIAssociationRequest;
import com.questdiagnostics.campaignservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.campaignservice.model.PhysicianEmailOutreach;
import com.questdiagnostics.campaignservice.model.PhysicianReminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.model.Spec;
import com.questdiagnostics.campaignservice.repository.EmailTemplateRepository;
import com.questdiagnostics.campaignservice.repository.PhysicianCampaignMasterRepository;
import com.questdiagnostics.campaignservice.repository.PhysicianEmailOutreachRepository;
import com.questdiagnostics.campaignservice.repository.PhysicianReminderRepository;
import com.questdiagnostics.campaignservice.repository.ScheduleRepository;
import com.questdiagnostics.campaignservice.request.model.EmailGroupIndividualResponse;
import com.questdiagnostics.campaignservice.request.model.PhysicianCampaignRequest;
import com.questdiagnostics.campaignservice.request.model.PhysicianUpdateCampaignRequest;
import com.questdiagnostics.campaignservice.response.model.CampaignStatusResponse;
import com.questdiagnostics.campaignservice.response.model.Element;
import com.questdiagnostics.campaignservice.response.model.EloquaCampaignResponse;
import com.questdiagnostics.campaignservice.response.model.EmailTemplateResponse;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;
import com.questdiagnostics.campaignservice.services.PhysicianCampaignService;
import com.questdiagnostics.campaignservice.util.AsyncUtil;
import com.questdiagnostics.campaignservice.util.CommonUtil;
import com.questdiagnostics.campaignservice.util.RESTUtils;

@Service
public class PhysicianCampaignServiceImpl implements PhysicianCampaignService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private static final long serialVersionUID = 1L;
	@Autowired
	private PhysicianCampaignMasterRepository physicianCampaignMasterRepository;

	@Autowired
	private PhysicianEmailOutreachRepository physicianEmailOutreachRepository;

	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private AsyncUtil asyncUtil;

	@Autowired
	RESTUtils restUtils;

	@Autowired
	PhysicianReminderRepository physicianReminderRepository;

	@Autowired
	private CampaignManager campaignManager;

	@Value("${sprintt.email.outreach.group.id}")
	private String emailOutreachGroupId;

	@Value("${sprintt.azure.storage.queueName}")
	private String queueName;
	
	@Value("${sprintt.npiassociation.queuename}")
	private String npiassociationQueueName;

	Calendar instance = null;

	private static final String URI_CONTEXT_PATH_GET_CAMPAIGNSTATUS = "/getCampaignBatchStatus";
	
	@Autowired
	private NotificationPublisher notificationPublisher;

	@Override
	public ResponseObjectModel createPhysicianCampaign(PhysicianCampaignRequest physicianCampaignRequest) {
		logger.info("Inside createPhysicianCampaign method");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (!StringUtils.isEmpty(physicianCampaignRequest.getCampaignName())
				&& !StringUtils.isEmpty(physicianCampaignRequest.getUserName())) {
			logger.info("CampaignName = {}, UserName = {}", physicianCampaignRequest.getCampaignName(),
					physicianCampaignRequest.getUserName());

			List<PhysicianCampaignMaster> list = physicianCampaignMasterRepository.findAll();
			boolean CampaignNameExisting = list.stream()
					.anyMatch(x -> x.getCampaignName().equalsIgnoreCase(physicianCampaignRequest.getCampaignName()));
			if (!CampaignNameExisting) {
				PhysicianCampaignMaster physicianCampaignMaster = new PhysicianCampaignMaster();
				physicianCampaignMaster.setCampaignName(physicianCampaignRequest.getCampaignName());
				physicianCampaignMaster.setUserName(physicianCampaignRequest.getUserName());
				physicianCampaignMaster.setSpecs(physicianCampaignRequest.getSpecs());
				physicianCampaignMaster.setCreatedOn(new Date());
				physicianCampaignMasterRepository.save(physicianCampaignMaster);
				// publish campaign event for the clinician service to persist campaign
				publishCampaignEvent(physicianCampaignMaster);
				//Notification producer :  Message for Physician List-Start
				publishNotification(physicianCampaignMaster, CommonConstants.PHYSICIAN_LIST_START);
				
				responseObjectModel.setData(physicianCampaignMaster);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(CommonConstants.SUCCESS);
			} else {
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(CommonConstants.CAMPAIGN_NAME_EXIST);
				return responseObjectModel;
			}
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.CONFLICT);
			responseObjectModel.setMessage(CommonConstants.CAMPAIGN_NAME_OR_USER_NAME_BLANK);
		}
		return responseObjectModel;
	}

	private void publishCampaignEvent(PhysicianCampaignMaster physicianCampaignMaster) {
		logger.info("PhysicianCampaignMaster publish message: {} ", physicianCampaignMaster);
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		try {
			PhysicianCampaignMsg physicianCampaignMsg = new PhysicianCampaignMsg();
			physicianCampaignMsg.setUserName(physicianCampaignMaster.getUserName());
			physicianCampaignMsg.setSprinttCampaignId(physicianCampaignMaster.getSprinttCampaignId());
			physicianCampaignMsg.setCampaignName(physicianCampaignMaster.getCampaignName());
			if (!ObjectUtils.isEmpty(physicianCampaignMaster) && !StringUtils.isEmpty(physicianCampaignMaster.getSpecs())) {
				Gson gson = new Gson();
				Spec spec = gson.fromJson(physicianCampaignMaster.getSpecs(), Spec.class);
				physicianCampaignMsg.setSpeciality(spec.getSpeciality());
				physicianCampaignMsg.setState(spec.getState());
				physicianCampaignMsg.setSource(spec.isBmis());
			}
			storageAccount = CloudStorageAccount.parse(asyncUtil.getStorageConnectionString());
			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(queueName);
			queue.createIfNotExists();
			ObjectMapper mapper = new ObjectMapper();
			queue.addMessage(new CloudQueueMessage(mapper.writeValueAsString(physicianCampaignMsg)));
			logger.info("process of sending physician campaign event completed: {} ",
					physicianCampaignMaster.getSprinttCampaignId());
		} catch (URISyntaxException | StorageException | InvalidKeyException | JsonProcessingException exception) {
			logger.error("Processing failed while reading message from queue of physician campaign: {} ", exception);
		}
	}

	@Override
	public ResponseObjectModel getPhysicianCampaigns(String campaignName) {
		logger.info("Inside getPhysicianCampaigns method");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		List<Integer> campaignStatus = new ArrayList<>();
		campaignStatus.add(PhysicianCampaignStatusEnums.Creation_Completed.getValue());
		campaignStatus.add(PhysicianCampaignStatusEnums.Schedule_Initiated.getValue());
		campaignStatus.add(PhysicianCampaignStatusEnums.Schedule_Completed.getValue());
		Optional<List<PhysicianCampaignMaster>> physicianCampaigns = null;
		if (StringUtils.isEmpty(campaignName))
			physicianCampaigns = physicianCampaignMasterRepository.findByCampaignStatusIdIn(campaignStatus);
		else {
			campaignName = "%" + campaignName + "%";
			physicianCampaigns = physicianCampaignMasterRepository
					.findByCampaignStatusIdInAndCampaignNameLike(campaignStatus, campaignName);
		}
		if (physicianCampaigns.isPresent()) {
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setData(physicianCampaigns.get());
			responseObjectModel.setMessage("Success");
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			responseObjectModel.setMessage("No Data Found.");
		}
		logger.info("completed getPhysicianCampaigns method");
		return responseObjectModel;
	}

	@Override
	public PhysicianCampaignMaster updatePhysicianCampaignStatusId(PhysicianUpdateCampaignRequest physicianCampaign) {
		logger.info("Inside getPhysicianCampaigns method");
		PhysicianCampaignMaster physicianCampaignData = null;
		Optional<PhysicianCampaignMaster> optionalObject = physicianCampaignMasterRepository
				.findById(physicianCampaign.getSprinttCampaignId());
		if (optionalObject.isPresent()) {
			PhysicianCampaignMaster physicianCampaignMaster = optionalObject.get();
			if (physicianCampaign.getCampaignStatusId() == 2) {
				physicianCampaignMaster.setCampaignStatusId(PhysicianCampaignStatusEnums.Creation_Completed.getValue());
			} else if (physicianCampaign.getCampaignStatusId() == 3) {
				physicianCampaignMaster.setCampaignStatusId(PhysicianCampaignStatusEnums.Creation_Failed.getValue());
			} else if (physicianCampaign.getCampaignStatusId() == 5) {
				physicianCampaignMaster.setCampaignStatusId(PhysicianCampaignStatusEnums.Schedule_Failed.getValue());
			} else if (physicianCampaign.getCampaignStatusId() == 6) {
				physicianCampaignMaster.setCampaignStatusId(PhysicianCampaignStatusEnums.Schedule_Completed.getValue());
			}
			physicianCampaignMaster.setUpdatedOn(new Date());
			physicianCampaignMaster.setUpdatedBy("admin");
			physicianCampaignData = physicianCampaignMasterRepository.save(physicianCampaignMaster);
		}
		return physicianCampaignData;
	}

	@Override
	public ResponseObjectModel getPhysicianCampaignEmailOutreach(Long campaignId) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		List<PhysicianReminder> remindersData = new ArrayList<>();
		if (StringUtils.isEmpty(campaignId) || campaignId == 0) {
			logger.info(MessageConstants.CAMPAIGN_ID_MNDT);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(MessageConstants.CAMPAIGN_ID_MNDT);
			return responseObjectModel;
		}
		Optional<PhysicianEmailOutreach> existingPhysicianEmailOutreach = physicianEmailOutreachRepository
				.findBySprinttCampaignId(campaignId);
		if (existingPhysicianEmailOutreach.isPresent()) {
			PhysicianEmailOutreach physicianEmailOutreach = existingPhysicianEmailOutreach.get();
			List<PhysicianReminder> physicianReminder = physicianEmailOutreach.getReminders();
			if (physicianReminder != null && physicianReminder.size() > 0) {
				physicianReminder.sort(Comparator.comparing(PhysicianReminder::getRemindOnDateTime));
			}
			for (PhysicianReminder reminderData : physicianReminder) {
				PhysicianReminder reminderDBC = CommonUtil.getValuesforRemindTo(reminderData);
				reminderData.setNonClicked(reminderDBC.getNonClicked());
				reminderData.setNonOpener(reminderDBC.getNonOpener());
				reminderData.setStatus(CommonUtil.getPhysicianReminderStatus(reminderData));
				remindersData.add(reminderData);
			}

			physicianEmailOutreach.setReminders(null);
			physicianEmailOutreach.setReminders(remindersData);

			Long scheduleId = physicianEmailOutreach.getScheduleId();
			if (scheduleId != null && scheduleId != 0) {
				Optional<Schedule> scheduleDB = scheduleRepository.findById(scheduleId);
				if (scheduleDB.isPresent()) {
					Schedule schedulePersist = scheduleDB.get();
					physicianEmailOutreach.setSchedule(schedulePersist);

				}
			}

			Long emailTemplateId = physicianEmailOutreach.getEmailTemplateId();
			if (emailTemplateId != null && emailTemplateId != 0) {
				Optional<EmailTemplate> emailTempDB = emailTemplateRepository.findById(emailTemplateId);

				if (emailTempDB.isPresent()) {
					physicianEmailOutreach.setEmailTemplate(emailTempDB.get());
				}
			}
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage("Success");
			responseObjectModel.setData(physicianEmailOutreach);
			return responseObjectModel;
		} else {
			logger.info(MessageConstants.PHYSICIAN_EMAIL_OUTREACH_DOES_NOT_EXIST);
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			responseObjectModel.setMessage(MessageConstants.PHYSICIAN_EMAIL_OUTREACH_DOES_NOT_EXIST);
			return responseObjectModel;
		}
	}

	// get Email Template API
	public List<EmailTemplateResponse> getListOfEmail() throws JsonProcessingException, URISyntaxException {

		EmailGroupIndividualResponse emailGroupindividualResponse = null;
		List<EmailTemplateResponse> emailTemplateResponse = new ArrayList<>();
		EmailTemplateResponse emailTemplate = null;

		// String emailGroupUrl = "/1.0/assets/email/group/" +
		// emailGroupId+"?depth=partial";
		String emailGroupUrl = "/1.0/assets/email/group/" + emailOutreachGroupId + "?depth=complete";

		logger.info("EmailTemplate Url==" + emailGroupUrl);

		emailGroupindividualResponse = restUtils
				.execute(null, emailGroupUrl, HttpMethod.GET, EmailGroupIndividualResponse.class).getBody();
		if (!StringUtils.isEmpty(emailGroupindividualResponse)) {
			if (!StringUtils.isEmpty(emailGroupindividualResponse.getEmailIds())) {
				for (String emailIds : emailGroupindividualResponse.getEmailIds()) {
					// String emailUrl = "/1.0/assets/email/" + emailIds +"?depth=minimal";
					String emailUrl = "/2.0/assets/email/" + emailIds + "?depth=minimal";
					emailTemplate = restUtils.execute(null, emailUrl, HttpMethod.GET, EmailTemplateResponse.class)
							.getBody();
					emailTemplateResponse.add(emailTemplate);

				}
			}
		}
		return emailTemplateResponse;
	}

	@Override
	public List<PhysicianCampaignMaster> getEligibleCampaigns() {
		logger.info("Inside getEligibleCampaigns method");
		List<PhysicianCampaignMaster> physicianCampaignsMasterList = new ArrayList<PhysicianCampaignMaster>();
		List<Object[]> listObject = null;
		
		listObject = physicianCampaignMasterRepository
				.fetchEligibleCampaigns(Arrays.asList(PhysicianCampaignStatusEnums.Schedule_Initiated.getValue(),
						PhysicianCampaignStatusEnums.Schedule_Failed.getValue()));
		if(null != listObject) {
			physicianCampaignsMasterList = convertArrayIntoPhysicianMasterList(listObject, physicianCampaignsMasterList);
		}
		
		return physicianCampaignsMasterList;
	}
	
	@Override
	public List<PhysicianCampaignMaster> getCampaignsWithCreationIncomplete() {
		logger.info("Inside getCampaignsWithCreationIncomplete method");
		List<PhysicianCampaignMaster> physicianCampaignsMasterList = new ArrayList<PhysicianCampaignMaster>();
		List<Object[]> listObject = null;

		listObject = physicianCampaignMasterRepository
				.fetchEligibleCampaigns(Arrays.asList(PhysicianCampaignStatusEnums.Creation_Initiated.getValue(),
						PhysicianCampaignStatusEnums.Creation_Failed.getValue()));
		if(null != listObject) {
			physicianCampaignsMasterList = convertArrayIntoPhysicianMasterList(listObject, physicianCampaignsMasterList);
		}
		return physicianCampaignsMasterList; 
	}

	@Override
	public ResponseObjectModel createPhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach) {
		logger.info("Inside createPhysicianEmailOutreach method");
		ResponseObjectModel responseObject = persistEmailOutreachCampaignData(physicianEmailOutreach);
		return responseObject;
	}

	@Override
	public ResponseObjectModel updatePhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach) {
		logger.info("Inside updatePhysicianEmailOutreach method");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		Integer trialId = 0;
		List<PhysicianReminder> reminders = new ArrayList<>();
		Optional<PhysicianEmailOutreach> phOptional = physicianEmailOutreachRepository
				.findBySprinttCampaignIdAndEmailOutreachId(physicianEmailOutreach.getSprinttCampaignId(),
						physicianEmailOutreach.getEmailOutreachId());
		if (phOptional.isPresent()) {
			PhysicianEmailOutreach physicianEmailOutreachDB = phOptional.get();
			// reminder details
			if (!ObjectUtils.isEmpty(physicianEmailOutreach.getReminders())) {
				for (PhysicianReminder reminder : physicianEmailOutreach.getReminders()) {
					if (!ObjectUtils.isEmpty(reminder.getReminderId())
							&& ObjectUtils.isEmpty(reminder.getRemindOnDateTime())) {
						logger.info("Reminder Value Before Deletion: {}  ", reminder);
						physicianReminderRepository.deleteReminder(reminder.getReminderId());
					} else if (ObjectUtils.isEmpty(reminder.getReminderId())) {
						reminder.setTrialId(trialId.longValue());
						reminder.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminder));
						reminder.setUpdatedOn(new Date());
						reminder.setCreatedOn(new Date());
						reminder.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminder.getRemindOnDateTime(),
								reminder.getReminderTimeZone()));
						reminder.setDefaultReminder(0);
						reminders.add(reminder);
					}
				}
				physicianEmailOutreachDB.setReminders(reminders);
			}
			// schedule details
			if (!ObjectUtils.isEmpty(physicianEmailOutreach.getSchedule())) {

				Schedule scheduleRequest = physicianEmailOutreach.getSchedule();
				if (physicianEmailOutreach.getSchedule().getScheduleId() != null) {
					Optional<Schedule> schedule = scheduleRepository
							.findById(physicianEmailOutreach.getSchedule().getScheduleId());
					if (schedule.isPresent()) {
						scheduleRequest.setUpdatedOn(new Date());
						scheduleRequest.setCreatedBy(schedule.get().getCreatedBy());
						scheduleRequest.setCreatedOn(schedule.get().getCreatedOn());
					} else {
						scheduleRequest.setCreatedOn(new Date());
					}
				}
				scheduleRequest.setTrialId(trialId.longValue());
				scheduleRequest.setStartDateTime(CommonUtil.convertUIDateToUTC(scheduleRequest.getStartDateTime(),
						scheduleRequest.getTimezone()));
				scheduleRequest.setDefaultSchedule(0);

				scheduleRequest = scheduleRepository.save(scheduleRequest);
				physicianEmailOutreachDB.setScheduleId(scheduleRequest.getScheduleId());
				physicianEmailOutreachDB.setSchedule(scheduleRequest);

			}
			// emailTemplate details
			if (!ObjectUtils.isEmpty(physicianEmailOutreach.getEmailTemplate())) {
				EmailTemplate emailTemplateRequest = physicianEmailOutreach.getEmailTemplate();
				if (!ObjectUtils.isEmpty(physicianEmailOutreach.getEmailTemplate().getEmailTemplateId())) {
					Optional<EmailTemplate> emailTemplateOpt = emailTemplateRepository
							.findById(physicianEmailOutreach.getEmailTemplate().getEmailTemplateId());
					if (emailTemplateOpt.isPresent()) {
						EmailTemplate emailTemplate = emailTemplateOpt.get();
						emailTemplate.setUpdatedOn(new Date());
						emailTemplate.setEloquaEmailTempId(emailTemplateRequest.getEloquaEmailTempId());
						emailTemplate.setName(emailTemplateRequest.getName());
						emailTemplate = emailTemplateRepository.save(emailTemplate);
						physicianEmailOutreachDB.setEmailTemplateId(emailTemplate.getEmailTemplateId());
						physicianEmailOutreachDB.setEmailTemplate(emailTemplate);
					}

				} else {
					emailTemplateRequest.setDefaultEmailTemp(0);
					emailTemplateRequest.setCreatedOn(new Date());
					emailTemplateRequest.setTrialId(trialId.longValue());
					emailTemplateRequest = emailTemplateRepository.save(emailTemplateRequest);
					physicianEmailOutreachDB.setEmailTemplateId(emailTemplateRequest.getEmailTemplateId());
					physicianEmailOutreachDB.setEmailTemplate(emailTemplateRequest);
				}
			}
			physicianEmailOutreachDB.setUpdatedOn(new Date());
			physicianEmailOutreachDB.setUpdatedBy(physicianEmailOutreach.getUpdatedBy());
			physicianEmailOutreachRepository.save(physicianEmailOutreachDB);

			Optional<PhysicianEmailOutreach> pOptional = physicianEmailOutreachRepository
					.findById(physicianEmailOutreachDB.getEmailOutreachId());
			if (pOptional.isPresent()) {
				PhysicianEmailOutreach pEmailOutreach = pOptional.get();
				Optional<List<PhysicianReminder>> physicianReminder = physicianReminderRepository
						.findByPhysicianEmailOutreach(pEmailOutreach);
				if (physicianReminder.isPresent())
					pEmailOutreach.setReminders(physicianReminder.get());
				//campaignManager.updateScheduledPhysicianCampaignInEloqua(pEmailOutreach, responseObjectModel);
				responseObjectModel.setData(pEmailOutreach);
				responseObjectModel.setMessage("Success");
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				return responseObjectModel;
			}

		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("Email Outreach not exist.");
		}
		return responseObjectModel;
	}

	private ResponseObjectModel persistEmailOutreachCampaignData(PhysicianEmailOutreach physicianEmailOutreach) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		List<PhysicianReminder> remindersList = new ArrayList<>();
		Integer trialId = 0;
		Schedule scheduleDet = null;
		EmailTemplate emailTemplate = null;
		Optional<PhysicianCampaignMaster> physicianCampaignMaster = physicianCampaignMasterRepository
				.findById(physicianEmailOutreach.getSprinttCampaignId());
		if (physicianCampaignMaster.isPresent()) {
			PhysicianCampaignMaster pCampaignMaster = physicianCampaignMaster.get();
			// physicianEmailOutreach.setCampaignJobStatusId(1L);
			physicianEmailOutreach.setSprinttCampaignId(pCampaignMaster.getSprinttCampaignId());
			physicianEmailOutreach.setCampaignName(pCampaignMaster.getCampaignName());
			// persisting remainder
			if (!ObjectUtils.isEmpty(physicianEmailOutreach.getReminders())) {
				for (PhysicianReminder reminder : physicianEmailOutreach.getReminders()) {
					logger.debug("Reminder Data: {} ", reminder);
					reminder.setTrialId(physicianEmailOutreach.getTrialId());
					reminder.setRemindTo(CommonUtil.getDbValuesforRemindTo(reminder));
					reminder.setCreatedOn(new Date());
					reminder.setRemindOnDateTime(CommonUtil.convertUIDateToUTC(reminder.getRemindOnDateTime(),
							reminder.getReminderTimeZone()));
					reminder.setDefaultReminder(0);
					reminder.setTrialId(trialId.longValue());
					remindersList.add(reminder);
				}
				physicianEmailOutreach.setReminders(remindersList);
			}
			// persisting schedule
			if (!ObjectUtils.isEmpty(physicianEmailOutreach.getSchedule())) {
				logger.debug("Schedule Data: {} ", physicianEmailOutreach.getSchedule());
				scheduleDet = physicianEmailOutreach.getSchedule();
				scheduleDet.setTrialId(physicianEmailOutreach.getTrialId());
				scheduleDet.setDefaultSchedule(0);
				scheduleDet.setCreatedOn(new Date());
				scheduleDet.setTrialId(trialId.longValue());
				scheduleDet = scheduleRepository.save(scheduleDet);
				physicianEmailOutreach.setScheduleId(scheduleDet.getScheduleId());
				instance = Calendar
						.getInstance(TimeZone.getTimeZone(physicianEmailOutreach.getSchedule().getTimezone()));
			}
			else {
				instance = Calendar.getInstance(TimeZone.getTimeZone(CommonConstants.EST));
			}
			// persisting email template
			if (!ObjectUtils.isEmpty(physicianEmailOutreach.getEmailTemplate())) {
				logger.debug("Email Template Data: {} ", physicianEmailOutreach.getEmailTemplate());
				emailTemplate = physicianEmailOutreach.getEmailTemplate();
				emailTemplate.setTrialId(physicianEmailOutreach.getTrialId());
				emailTemplate.setDefaultEmailTemp(0);
				emailTemplate.setCreatedOn(new Date());
				emailTemplate.setTrialId(trialId.longValue());
				emailTemplate = emailTemplateRepository.save(emailTemplate);
				physicianEmailOutreach.setEmailTemplateId(emailTemplate.getEmailTemplateId());
			}
			physicianEmailOutreach.setCreatedOn(instance.getTime());
			// physicianEmailOutreach.setCreatedBy("admin");
			responseObjectModel.setData(physicianEmailOutreachRepository.save(physicianEmailOutreach));
			responseObjectModel.setMessage(CommonConstants.SUCCESS);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			return responseObjectModel;
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("SprinttCampaignId is not exist.");
		}
		return responseObjectModel;
	}

	private void updateCampaignWithEloquaResponseForCreate(Long emailOutreachId,
			EloquaCampaignResponse campaignResponse) {
		physicianEmailOutreachRepository.findById(emailOutreachId).ifPresent(campaignMaster -> {
			campaignMaster.setEloquaCampaignId(campaignResponse.getId());
			//campaignMaster.setCampaignJobStatusId(CampaignJobStatus.Initiated.getValue().longValue());
			campaignMaster.setEloCampgnStatusId(
					EloquaCampaignStatus.valueOf(campaignResponse.getCurrentStatus().toUpperCase()).getValue());
			/* iterate and find segment id of eloqua */
			for (Element element : campaignResponse.getElements()) {
				if (element.getType().equalsIgnoreCase(CAMPAIGN_SEGMENT.getType()))
					campaignMaster.setSegmentId(Long.valueOf(element.getSegmentId()));
			}
			if (!CollectionUtils.isEmpty(campaignMaster.getReminders())) {
				List<PhysicianReminder> reminders = new ArrayList<>(campaignMaster.getReminders());
				campaignMaster.setReminders(reminders);
			}
			campaignMaster.setContactListId(Integer.valueOf(campaignResponse.getContactListId()));
			physicianEmailOutreachRepository.save(campaignMaster);
			// updating campaignStatusId and contactList update in PhysicianCampaignMaster
			PhysicianCampaignMaster physicianCampaignMaster = getPhysicianCampaignMasterByEmailOutreach(
					campaignMaster.getSprinttCampaignId());
			if (!ObjectUtils.isEmpty(physicianCampaignMaster)) {
				physicianCampaignMaster.setCampaignStatusId(PhysicianCampaignStatusEnums.Schedule_Initiated.getValue());
				physicianCampaignMasterRepository.save(physicianCampaignMaster);
			}
		});
		
	}

	public PhysicianCampaignMaster getPhysicianCampaignMasterByEmailOutreach(Long sprinttCampaignId) {
		PhysicianCampaignMaster physicianCampaignMaster = null;
		Optional<PhysicianCampaignMaster> physicianCampaignOptional = physicianCampaignMasterRepository
				.findById(sprinttCampaignId);
		if (physicianCampaignOptional.isPresent()) {
			physicianCampaignMaster = physicianCampaignOptional.get();
		}
		return physicianCampaignMaster;
	}

	@Override
	public ResponseObjectModel getCampaignStatusByUserName(String userName) {
		logger.info("Inside getCampaignStatusByUserName method");
		ResponseEntity<ResponseObjectModel> responseEntity = null;
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		Optional<List<PhysicianCampaignMaster>> physicianCampaignMasters = physicianCampaignMasterRepository
				.findByUserName(userName);
		if (physicianCampaignMasters.isPresent()) {
			List<PhysicianCampaignMaster> pCampaignMasters = physicianCampaignMasters.get();
			try {
				responseEntity = restUtils.executeGetCampaignStatus(pCampaignMasters,
						URI_CONTEXT_PATH_GET_CAMPAIGNSTATUS, HttpMethod.POST, ResponseObjectModel.class);
			} catch (JsonProcessingException | URISyntaxException e) {
				logger.error("Exception occured during intraction with clinician service : {}", e);
			}
			if (responseEntity != null && responseEntity.getStatusCode().equals(HttpStatus.OK)) {
				responseObjectModel = (ResponseObjectModel) responseEntity.getBody();
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				CampaignStatusResponse campaignStatusResponse = new CampaignStatusResponse();
				campaignStatusResponse.setIsCampaignProcessing((Boolean) responseObjectModel.getData());
				responseObjectModel.setData(campaignStatusResponse);
			}
		} else {
			responseObjectModel.setData(new CampaignStatusResponse());
			responseObjectModel.setHttpStatus(HttpStatus.OK);
		}
		return responseObjectModel;
	}

	private static class PhysicianCampaignMsg implements Serializable {

		private static final long serialVersionUID = -1L;

		private String userName;

		private Long sprinttCampaignId;

		private boolean source;

		private String speciality;

		private String state;
		
		private String campaignName;

		public String getUserName() {
			return userName;
		}

		@JsonProperty("userName")
		public void setUserName(String userName) {
			this.userName = userName;
		}

		public Long getSprinttCampaignId() {
			return sprinttCampaignId;
		}

		@JsonProperty("sprinttCampaignId")
		public void setSprinttCampaignId(Long sprinttCampaignId) {
			this.sprinttCampaignId = sprinttCampaignId;
		}

		public boolean getSource() {
			return source;
		}

		public void setSource(boolean source) {
			this.source = source;
		}

		public String getSpeciality() {
			return speciality;
		}

		@JsonProperty("speciality")
		public void setSpeciality(String speciality) {
			this.speciality = speciality;
		}

		public String getState() {
			return state;
		}

		@JsonProperty("state")
		public void setState(String state) {
			this.state = state;
		}
		
		public String getCampaignName() {
			return campaignName;
		}
		
		@JsonProperty("campaignName")
		public void setCampaignName(String campaignName) {
			this.campaignName = campaignName;
		}
	}

	@Override
	public ResponseObjectModel schedulePhysicianEmailOutreach(PhysicianEmailOutreach physicianEmailOutreach) {
		logger.info("inside schedulePhysicianEmailOutreach method ");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if ((ObjectUtils.isEmpty(physicianEmailOutreach.getEmailOutreachId()))
				|| (ObjectUtils.isEmpty(physicianEmailOutreach.getSprinttCampaignId()))) {
			responseObjectModel.setMessage("Email OutreachId and SprinttCampaignId must be present");
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			return responseObjectModel;
		}
		physicianEmailOutreach.setCampaignName(getPhysicianCampaignName(physicianEmailOutreach.getSprinttCampaignId()));
		if (ObjectUtils.isEmpty(physicianEmailOutreach.getCampaignName())) {
			responseObjectModel.setMessage("CampaignName must be present");
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			return responseObjectModel;
		}
		try {
			updateCampaignWithEloquaResponseForCreate(physicianEmailOutreach.getEmailOutreachId(),
					campaignManager.createPhysicianCampaignInEloqua(physicianEmailOutreach));
		} catch (EloquaException e) {
			logger.info("Exception occur during intraction with eloqua {}", e.getMessage());
			responseObjectModel.setMessage("Fail");
			responseObjectModel.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		responseObjectModel.setMessage("Success");
		Optional<PhysicianEmailOutreach> pOptional = physicianEmailOutreachRepository
				.findById(physicianEmailOutreach.getEmailOutreachId());
		if (pOptional.isPresent()) {
			responseObjectModel.setData(pOptional.get());
		}
		responseObjectModel.setHttpStatus(HttpStatus.OK);
		logger.info("process completed of schedulePhysicianEmailOutreach ");
		logger.info("process statred of requesting npiAssociation ");
		if (!ObjectUtils.isEmpty(physicianEmailOutreach.getNpiAssociationRequest())) {
			if (publishNPIAssociationRequest(physicianEmailOutreach.getNpiAssociationRequest()))
				responseObjectModel.setMessage(CommonConstants.SCHEDULED_AND_NPI_ASSOCIATION_REQUEST_SUBMITTED);
			else
				responseObjectModel.setMessage(CommonConstants.SCHEDULED_AND_NPI_ASSOCIATION_REQUEST_FAILED);
		}
		logger.info("process completed of requesting npiAssociation ");
		return responseObjectModel;
	}
	
	public String getPhysicianCampaignName(Long sprinttCampaignId) {
		String campaignName = null;
		Optional<PhysicianCampaignMaster> pOptional = physicianCampaignMasterRepository.findById(sprinttCampaignId);
		if (pOptional.isPresent()) {
			PhysicianCampaignMaster physicianCampaignMaster = pOptional.get();
			campaignName = physicianCampaignMaster.getCampaignName();
		}
		return campaignName;
	}

	@Override
	public PhysicianEmailOutreach getPhysicianEmailOutreach(Long campaignId) {
		PhysicianEmailOutreach physicianEmailOutreach = new PhysicianEmailOutreach();
		Optional<PhysicianEmailOutreach> existingPhysicianEmailOutreach = physicianEmailOutreachRepository.findBySprinttCampaignId(campaignId);
		if(existingPhysicianEmailOutreach.isPresent()){
			physicianEmailOutreach = existingPhysicianEmailOutreach.get();
		}
		return physicianEmailOutreach;
	}
	
	
	private List<PhysicianCampaignMaster> convertArrayIntoPhysicianMasterList(List<Object[]> listObject, List<PhysicianCampaignMaster> physicianCampaignsMasterList){
		Long sprinttCampaignId = null;
		String campaignName = null;
		String userName = null;
		String specs = null;
		Integer campaignStatusId = null;
		Integer contactListId = null;
		
		for(Object[] objArr :listObject) {
			if(null != objArr[0]){
				sprinttCampaignId =  ((BigInteger)objArr[0]).longValue();
			}
			if(null != objArr[1]){
				campaignName = (String) objArr[1];
			}
			if(null != objArr[2]){
				userName = (String) objArr[2];
			}
			if(null != objArr[3]){
				specs = (String) objArr[3];
			}
			if(null != objArr[4]){
				campaignStatusId = (Integer) objArr[4];
			}
			if(null != objArr[5]){
				contactListId = (Integer) objArr[5];
			}
			PhysicianCampaignMaster physicianCampaignMaster = new PhysicianCampaignMaster();
			physicianCampaignMaster.setSprinttCampaignId(sprinttCampaignId);
			physicianCampaignMaster.setCampaignName(campaignName);
			physicianCampaignMaster.setUserName(userName);
			physicianCampaignMaster.setSpecs(specs);
			physicianCampaignMaster.setCampaignStatusId(campaignStatusId);
			physicianCampaignMaster.setContactListId(contactListId);
			physicianCampaignsMasterList.add(physicianCampaignMaster);
		}
		return physicianCampaignsMasterList;
	}

	private Boolean publishNPIAssociationRequest(NPIAssociationRequest npiAssociationRequest) {
		logger.info("NPIAssociationRequest publish message: {} ", npiAssociationRequest);
		Boolean isNPIAssociated = false;
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		try {
			storageAccount = CloudStorageAccount.parse(asyncUtil.getStorageConnectionString());
			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(npiassociationQueueName);
			queue.createIfNotExists();
			ObjectMapper mapper = new ObjectMapper();
			queue.addMessage(new CloudQueueMessage(mapper.writeValueAsString(npiAssociationRequest)));
			logger.info(
					"process of sending npiAssociationRequest event completed for campaignUserName , campaignId : {} \\n {}  ",
					npiAssociationRequest.getCampaignUserName(), npiAssociationRequest.getSprinttCampaignId());
			isNPIAssociated = true;
		} catch (URISyntaxException | StorageException | InvalidKeyException | JsonProcessingException exception) {
			logger.error("Processing failed during  NPIAssociationRequest: {} ", exception);
		}
		return isNPIAssociated;
	}
	
	private void publishNotification(PhysicianCampaignMaster physicianCampaignMaster, String eventName){
		NotificationPayload notificationPayload = new NotificationPayload();
		notificationPayload.setId(physicianCampaignMaster.getSprinttCampaignId());
		notificationPayload.setName(physicianCampaignMaster.getCampaignName());
		notificationPayload.setEventName(eventName);
		notificationPayload.setUserid(physicianCampaignMaster.getUserName());
		notificationPublisher.publishNotification(notificationPayload);
	}
}
