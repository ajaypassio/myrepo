package com.questdiagnostics.campaignservice.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class AsyncUtil {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureAccountName;

	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureAccountKey;
	
	public String getStorageConnectionString() {
		return "DefaultEndpointsProtocol=https;" + "AccountName=" + azureAccountName + ";AccountKey="
				+ azureAccountKey + ";" + "EndpointSuffix=core.windows.net";

	}
	
	public String getNotificationStorageConnectionString() {
		return "DefaultEndpointsProtocol=https;"
				+ "AccountName="+azureAccountName
				+ ";AccountKey="+azureAccountKey+";"
				+ "EndpointSuffix=core.windows.net";
		
	}
}
