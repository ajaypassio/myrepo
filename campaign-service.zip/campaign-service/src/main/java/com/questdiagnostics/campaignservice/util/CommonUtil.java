package com.questdiagnostics.campaignservice.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FilenameUtils;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.ListBlobItem;
import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.PhysicianReminder;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

/**
 * @author Ajay Kumar
 *
 */
@Component
public class CommonUtil implements Serializable {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);

	private static final long serialVersionUID = 5014058255222880741L;

	public static final String SOURCE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String CONVERTED_DATE_TZ_FORMAT = "yyyy-MM-dd HH:mm:ss z";
	public static final String CONVERTED_DATE_TZ_FORMAT_NEW = "yyyy-MM-dd HH:mm:ss zzzz";

	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy , hh:mm a zzz");
	static ZoneId etZoneId = ZoneId.of("America/New_York");

	private static final String NON_OPENER = "Non-Opener";
	private static final String NON_CLICKED = "Non-Clicked";

	/** The object mapper. */
	ObjectMapper objectMapper = new ObjectMapper();

	/** The Constant JSON_FILES_PATH. */
	private static final String JSON_FILES_PATH = "jsonFiles";

	private static SimpleDateFormat estDateFormat = new SimpleDateFormat("MM/dd/yyyy , hh:mm aa zzz");

	private CommonUtil() {

	}

	public static HttpHeaders prepareHeader() {
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		return header;
	}

	/**
	 * @param reminder
	 * @return String This method reads reminder object coming from UI and
	 *         convert it to DB values of remindTo column ex
	 *         Non-Opener|Non-Clicked|
	 */
	// will revisit logic
	public static String getDbValuesforRemindTo(Reminder reminder) {
		StringBuffer remindTo = new StringBuffer();
		if (reminder.getNonOpener())
			remindTo.append(NON_OPENER + "|");
		if (reminder.getNonClicked())
			remindTo.append(NON_CLICKED);

		reminder.setRemindTo(remindTo.toString());
		return reminder.getRemindTo();
	}

	/**
	 * @param reminder
	 * @return String This method reads remindTO object coming from DB and
	 *         convert it to UI required attributes
	 *
	 */
	// will revisit logic
	public static Reminder getUIValuesforRemindTo(Reminder reminder) {
		if (reminder.getRemindTo() != null) {
			String days = new String(reminder.getRemindTo());
			if (days.contains(NON_OPENER))
				reminder.setNonOpener(true);
			if (days.contains(NON_CLICKED))
				reminder.setNonClicked(true);
		}
		/*
		 * String days = new String(reminder.getRemindTo()); if
		 * (days.contains(NON_OPENER)) reminder.setNonOpener(true); if
		 * (days.contains(NON_CLICKED)) reminder.setNonClicked(true);
		 */

		return reminder;

	}

	public static PhysicianReminder getValuesforRemindTo(PhysicianReminder physicianReminder) {
		if (physicianReminder.getRemindTo() != null) {
			String days = new String(physicianReminder.getRemindTo());
			if (days.contains(NON_OPENER))
				physicianReminder.setNonOpener(true);
			if (days.contains(NON_CLICKED))
				physicianReminder.setNonClicked(true);
		}

		return physicianReminder;

	}

	public static Date normalizeDateTime(Date dateTime, String timezone) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateTime);
		LocalDateTime localDateTimeForEloqua = LocalDateTime.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
				cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
				cal.get(Calendar.SECOND));
		ZoneId timeZoneId = ZoneId.of(getTimeZone(timezone));
		ZonedDateTime zonedDateTimeForEloqua = localDateTimeForEloqua.atZone(timeZoneId);
		return Date.from(zonedDateTimeForEloqua.toInstant());
	}

	public static String getTimeZone(String timezonFromUI) {
		switch (timezonFromUI) {
		case "EST":
			return "America/New_York";
		case "CST":
			return "America/Chicago";
		case "MST":
			return "America/Denver";
		case "PST":
			return "America/Los_Angeles";
		case "HST":
			return "America/Anchorage";
		case "US/Alaska":
			return "Pacific/Honolulu";
		default:
			return timezonFromUI;
		}
	}

	/**
	 * @param inputDate
	 * @param timeZone
	 * @return unixTime input date format = "Thu Jan 09 12:19:05 EST 2020"(java
	 *         default) timeZone=America/New_York
	 */
	// need to handle exception
	public static long getUnixTime(String inputDate, String timeZone) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		long unixTime = 0;
		dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
		try {
			unixTime = dateFormat.parse(inputDate).getTime();
			unixTime = unixTime / 1000;
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return unixTime;

	}

	public static String getStatus(Reminder reminder, Integer campaignStatusId) {
		String status;
		Date currentDate = new Date(System.currentTimeMillis());
		LOGGER.info("Current Date and Time {}", currentDate);
		long dateDifference = reminder.getRemindOnDateTime().getTime() - currentDate.getTime();
		LOGGER.info("Current remindOnDateTime in database {}", reminder.getRemindOnDateTime());
		LOGGER.info("The date difference value {}", dateDifference);

		if (!StringUtils.isEmpty(campaignStatusId)) {
			if (campaignStatusId.equals(SprinttCampaignStatus.SCHEDULED.getValue())) {
				status = "Scheduled";
				return status;
			} else if (campaignStatusId.equals(SprinttCampaignStatus.DEPLOYED.getValue())) {
				if (dateDifference >= 0) {
					status = "Scheduled";
				} else {
					status = "Sent";
				}
				return status;
			}
		}
		return null;
	}

	public static String getPhysicianReminderStatus(PhysicianReminder physicianReminder) {
		String status;
		Date currentDate = new Date(System.currentTimeMillis());
		LOGGER.info("Current Date and Time {}", currentDate);
		long dateDifference = physicianReminder.getRemindOnDateTime().getTime() - currentDate.getTime();
		LOGGER.info("Current remindOnDateTime in database {}", physicianReminder.getRemindOnDateTime());
		LOGGER.info("The date difference value {}", dateDifference);
		if (dateDifference >= 0) {
			status = "Scheduled";
		} else {
			status = "Sent";
		}
		return status;
	}

	public static Date convertUIDateToUTC(Date dateFromUI, String timeZone) {

		return dateFromUI;
		/*
		 * SimpleDateFormat inputFormat = new
		 * SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		 * inputFormat.setTimeZone(TimeZone.getTimeZone(timeZone)); String
		 * dateFromUI1 = null;
		 * 
		 * dateFromUI1 = inputFormat.format(dateFromUI); Date dateFormat = null;
		 * try { dateFormat = inputFormat.parse(dateFromUI1); } catch
		 * (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } DateFormat outputFormat = new
		 * SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		 * outputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		 * 
		 * String returnString = outputFormat.format(dateFormat);
		 * TimeZone.setDefault(TimeZone.getTimeZone("UTC")); try { return
		 * outputFormat.parse(returnString); } catch (ParseException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); } return new
		 * Date();
		 */
	}

	/**
	 * Convert json to object.
	 *
	 * @param <T>
	 *            the generic type
	 * @param jsonFile
	 *            the json file
	 * @param classType
	 *            the class type
	 * @return the t
	 * @throws ServiceException
	 *             the service exception
	 */
	public <T> T convertJsonToObject(String jsonFile, Class<T> classType) {
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			File file = new File(
					classLoader.getResource(JSON_FILES_PATH + "/" + FilenameUtils.getName(jsonFile)).getFile());
			LOGGER.debug(file.getPath() + " " + file.getAbsolutePath());
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			return objectMapper.readValue(file, classType);
		} catch (final IOException exception) {
			LOGGER.error("Error recived at converting json to object", exception);
		}
		return null;
	}

	/**
	 * Convert string to object.
	 * 
	 * @param <T>
	 * @param data
	 * @param classType
	 * @return
	 */
	public <T> T convertStringToObject(String data, Class<T> classType) {
		try {
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			return objectMapper.readValue(data, classType);
		} catch (final IOException exception) {
			LOGGER.error("Error recived at converting json to object", exception);
		}
		return null;
	}

	/**
	 * Convert object to String.
	 * 
	 * @param <T>
	 * @param data
	 * @param classType
	 * @return
	 */
	public String convertObjectToString(Object requestAttribute) {
		try {
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			return objectMapper.writeValueAsString(requestAttribute);
		} catch (final IOException exception) {
			LOGGER.error("Error recived at converting json to object", exception);
		}
		return null;
	}

	public static Map<String, String> initTimeZoneMap() {
		Map<String, String> timeZoneAlias = new HashMap<>();

		timeZoneAlias.put("(GMT-05:00) Eastern Time", "EST");
		timeZoneAlias.put("(GMT-06:00) Central Time", "CST");
		timeZoneAlias.put("(GMT-07:00) Mountain Time Arizona", "MST");
		timeZoneAlias.put("(GMT-07:00) Mountain Time", "MST");
		timeZoneAlias.put("(GMT-08:00) Pacific Time", "PST");
		timeZoneAlias.put("(GMT-09:00) Alaska Time", "US/Alaska");
		timeZoneAlias.put("(GMT-10:00) Hawaii Time", "US/Hawaii");
		return Collections.unmodifiableMap(timeZoneAlias);
	}

	public static String populateNextLastAction(String userAction, Date actionDate) {
		try {

			if (userAction != null && !StringUtils.isEmpty(userAction)) {
				LocalDateTime currentDateTime = LocalDateTime.now();
				ZonedDateTime localDateTime = currentDateTime.atZone(etZoneId);

				if (actionDate != null) {
					return userAction.replace("#dateTime",
							dateTimeFormatter.format(actionDate.toInstant().atZone(etZoneId)));
				} else {
					return userAction.replace("#dateTime", dateTimeFormatter.format(localDateTime));
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured while setting last and next action", e);
			LOGGER.info("Provided data was action = " + userAction + " and date = " + actionDate);

		}
		return CommonConstants.NO_ACTION;

	}

	public static String populateNextLastActionWithTimeZone(String userAction, Date actionDate, String timeZone) {
		Calendar instance = null;
		try {

			if (userAction != null && !StringUtils.isEmpty(userAction)) {
				if (actionDate != null) {

					instance = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
					return userAction.replace("#dateTime", estDateFormat.format(actionDate).replace("GMT", timeZone));
				} else {
					estDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
					instance = Calendar.getInstance(TimeZone.getTimeZone(timeZone));
					return userAction.replace("#dateTime", estDateFormat.format(instance.getTime())
							.replace(instance.getTimeZone().toString(), timeZone));

				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured while setting last and next action", e);
			LOGGER.info("Provided data was action = " + userAction + " and date = " + actionDate);

		}
		return CommonConstants.NO_ACTION;

	}

	public CampaignMaster buildCreatedAuditField(CampaignMaster campaignMaster) {
		return campaignMaster;
	}

	public CampaignMaster buildUpdateAuditField(CampaignMaster campaignMaster, Integer campaignJobStatus) {

		// append remarks
		if (campaignJobStatus.equals(CampaignJobStatus.CONTACTS_UPLOAD_INITIATED.getValue())
				|| campaignJobStatus.equals(CampaignJobStatus.CONTACTS_UPLOAD_IN_PROGRESS.getValue())) {
			campaignMaster.setRemarks(CommonUtil.populateCampaignRemarks(campaignMaster.getRemarks(),
					CommonConstants.CONTACT_GENERATION_STARTED));
		} else if (campaignJobStatus.equals(CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue())) {
			campaignMaster.setRemarks(CommonUtil.populateCampaignRemarks(campaignMaster.getRemarks(),
					CommonConstants.CONTACT_GENERATION_ENDED));
		} else if (campaignJobStatus.equals(CampaignJobStatus.CONTACTS_UPLOAD_FAILED.getValue())) {
			campaignMaster.setRemarks(CommonUtil.populateCampaignRemarks(campaignMaster.getRemarks(),
					CommonConstants.CONTACT_GENERATION_FAILED));
		}

		campaignMaster.setUpdatedBy(CommonConstants.CONTACT_UPLOADED_USER);
		campaignMaster.setUpdatedOn(new Date());
		return campaignMaster;
	}

	/*
	 * public static void main(String ss[]) { // 3/20/2020, 1:01:00 AM Fri Mar
	 * 20 06:31:00 IST 2020 // 2020-03-20 06:31:00 ET
	 * 
	 * // 2020-3-20 6 31 0 ET
	 * 
	 * try { SimpleDateFormat formatDB = new
	 * SimpleDateFormat(SOURCE_DATE_FORMAT); SimpleDateFormat formatEloqua = new
	 * SimpleDateFormat(CONVERTED_DATE_TZ_FORMAT);
	 * 
	 * System.out.println(formatEloqua.parse(formatDB.
	 * format("Fri Mar 20 06:31:00 IST 2020")));// + " " +
	 * getTimeZone(timezone)));
	 * 
	 * // System.out.println(formatEloqua.parse(formatDB.
	 * format("Fri Mar 20 06:31:00 IST 2020")));// + " " +
	 * getTimeZone(timezone)));
	 * 
	 * // return formatEloqua.parse(formatDB.format(dateTime) + " " +
	 * getTimeZone(timezone));
	 * 
	 * 
	 * 
	 * //DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy"
	 * ); //Date date = (Date)formatter.parse(dateStr);
	 * //System.out.println(date);  
	 * 
	 * } catch(Exception e) { e.printStackTrace(); } }
	 */

	public static String getDayLightSavingZone(boolean isDayLight, String timezone) {
		TimeZone currentTimeZone = TimeZone.getTimeZone(getTimeZone(timezone));
		String shortName = currentTimeZone.getDisplayName(isDayLight, 0);

		LOGGER.info("Day Light saving :::: = " + isDayLight + " and TimeZone passed = " + timezone + "  :: short name  "
				+ shortName);

		return shortName;
	}

	public static String getCurrentAndUpdatedDateTime() {
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy , hh:mm a zzz");
		LocalDateTime currentDateTime = LocalDateTime.now();
		ZoneId etZoneId = ZoneId.of(CommonConstants.EST);
		ZonedDateTime localDateTime = currentDateTime.atZone(etZoneId);
		String currentTime = dateTimeFormatter.format(localDateTime);
		return currentTime;
	}

	public static String populateCampaignRemarks(String existingRemarks, String newRemarks) {

		StringBuilder builder = new StringBuilder(
				existingRemarks == null ? CommonConstants.DEFAULT_REMARKS : existingRemarks);
		builder.append(CommonConstants.DEFAULT_REMARKS).append(newRemarks).append(getCurrentAndUpdatedDateTime());
		return builder.toString();
	}

	public static String getImagesName(String folderName, String imageName) {
		String[] imageValue = imageName.split(folderName + "\\/", 2);
		if (imageValue != null)
			return imageValue[1];
		else
			return null;
	}

	public static String getImageNameFromUri(String uri) {
		int statingIndex = uri.lastIndexOf("/") + 1;
		return uri.substring(statingIndex, uri.length());
	}

	public static Integer totalContainerImagesCount(CloudBlobDirectory directory) {
		int count = 0;
		try {
			Iterable<ListBlobItem> itr = directory.listBlobs();
			for (ListBlobItem listBlobItem : itr) {
				count++;
			}
		} catch (StorageException | URISyntaxException e) {
			LOGGER.error("Exception occured in  totalContainerImagesCount {}", e);
		}
		return count;
	}

	public static Boolean isFileExistInContainer(CloudBlobDirectory directory, String imageName) {
		boolean flag = false;
		try {
			Iterable<ListBlobItem> itr = directory.listBlobs();
			for (ListBlobItem listBlobItem : itr) {
				String tempFileName = listBlobItem.getUri().toString();
				String imageNameContainer = CommonUtil.getImageNameFromUri(tempFileName);
				if (imageNameContainer.equalsIgnoreCase(imageName)) {
					flag = true;
					break;
				}
			}
		} catch (StorageException | URISyntaxException e) {
			LOGGER.error("Exception occured in  isFileExistInContainer {}", e);
		}
		return flag;
	}
	
	public static String getDbValuesforRemindTo(PhysicianReminder reminder) {
		StringBuffer remindTo = new StringBuffer();
		if (reminder.getNonOpener())
			remindTo.append(NON_OPENER + "|");
		if (reminder.getNonClicked())
			remindTo.append(NON_CLICKED);

		reminder.setRemindTo(remindTo.toString());
		return reminder.getRemindTo();
	}
}
