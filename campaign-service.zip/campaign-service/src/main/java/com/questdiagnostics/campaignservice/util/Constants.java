package com.questdiagnostics.campaignservice.util;

public class Constants {

	public static final String CAMPAIGN_FILE_NAME="CampaignPatientList";
	public static final String CAMPAIGN_FILE_FOLDER="Trial-Campaign";
	public static final String CAMPAIGN_FILE_FORMAT=".csv";
	public static final String TRIAL="T";
	public static final String COMMA = ",";
	public static final String NEW_LINE = "\n";	
	public static final String UNDERSCORE = "_";
	public static final String BACKSLASH = "/";
	public static final String ADMIN="ADMIN";
	public static final String INITIATED="Initiated";
	public static final String SUCCESS="SUCCESS";
	public static final String AUDIT_NOT_PROCESSED="NOT PROCESSED";
	public static final String OPTION_NOT_SELECTED="Please select one option for Camapign";
	public static final String SCHEDULE_DATE_ALREADY_PASSED="Schedule start date already passed";
	public static final String CAMPAIN_NOT_IN_DISCARDED_STATE="This campaign is not in discarded state";
	public static final String CAMPAIGN_NOT_IN_DRAFT_OR_SCHEDULE_STATE="This campaign is not in Draft or schedule state";
}
