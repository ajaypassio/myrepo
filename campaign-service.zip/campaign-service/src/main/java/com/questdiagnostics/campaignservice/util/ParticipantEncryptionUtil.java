package com.questdiagnostics.campaignservice.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author Ajay Kumar
 *
 */
@Component
public class ParticipantEncryptionUtil {

	//@Value("${sprintt.secret.text}")
	//private String sprinttSecretText;

	private Cipher cipher = null;
	private SecretKey secretKey = null;

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Inject
	private ParticipantEncryptionUtil(@Value("${sprintt.secret.text}") String sprinttSecretText) {
		logger.info("Sprintt token Id = {}", sprinttSecretText);
		byte[] key = new byte[16];
		try {
			key = fixSecret(sprinttSecretText, 16);
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException", e);
		}
		secretKey = new SecretKeySpec(key, "AES");
		try {
			cipher = Cipher.getInstance("AES");
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			logger.error("UnsupportedEncodingException", e);
		}
	}

	private byte[] fixSecret(String s, int length) throws UnsupportedEncodingException {
		if (s.length() < length) {
			int missingLength = length - s.length();
			for (int i = 0; i < missingLength; i++) {
				s += " ";
			}
		}
		return s.substring(0, length).getBytes(StandardCharsets.UTF_8);
	}

	private synchronized byte[] encrypt(byte[] plainTextByte)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		return cipher.doFinal(plainTextByte);
	}

	private synchronized byte[] encrypt(String plainText)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] plainTextByte = plainText.getBytes(StandardCharsets.UTF_8);
		return encrypt(plainTextByte);
	}

	private synchronized byte[] decrypt(byte[] encryptedBytes)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		return cipher.doFinal(encryptedBytes);
	}

	public synchronized String encryptToBase64(String plainText) {
		byte[] encryptedByte = null;
		try {
			encryptedByte = encrypt(plainText);
			return getBase64Encoded(encryptedByte);
		} catch (Exception e) {
			logger.error("exception occured : {} ", e.getMessage());
		}
		return "";
	}

	public synchronized String decryptFromBase64(String encoded) {
		byte[] decryptedBytes = null;
		try {
			@SuppressWarnings("deprecation")
			byte[] decoded = getBase64DecodedBytes(URLDecoder.decode(encoded));
			decryptedBytes = decrypt(decoded);
			return new String(decryptedBytes, StandardCharsets.UTF_8);
		} catch (Exception e) {
			logger.error("exception occured : {} ", e.getMessage());
		}
		return "";
	}

	private String getBase64Encoded(byte msg[]) throws UnsupportedEncodingException {
		byte[] encodedBytes = Base64.getUrlEncoder().encode(msg);
		return new String(encodedBytes, StandardCharsets.UTF_8);
	}

	private byte[] getBase64DecodedBytes(String msg) {
		return Base64.getUrlDecoder().decode(msg.getBytes());
	}
}