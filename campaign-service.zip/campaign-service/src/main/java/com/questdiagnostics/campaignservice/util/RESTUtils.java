package com.questdiagnostics.campaignservice.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;

@Component
public class RESTUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(RESTUtils.class);

	@Autowired
	RestTemplate restTemplate;
	@Value("${eloqua.base.url}")
	private String baseUrl;
	
	@Value("${survey.base.url}")
	private String surveybaseURL;

	@Value("${eloqua.auth.value}")
	private String authValue;
	
	@Value("${sprintt.azure.storage.container.name}")
	private String imageContainerName;
	
	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureAccountName;

	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureAccountKey;
	
	@Value("${clinician.base.url}")
	private String clinicianbaseURL;


	public <T, U> ResponseEntity<U> execute(T entityBody, String uriContextPath, HttpMethod httpMethod,
			Class<U> responseType) throws URISyntaxException, JsonProcessingException {
		URI url = new URI(baseUrl + uriContextPath);
		LOGGER.info("Complete URL=="+baseUrl+"===path complete=="+url.getPath());
		String bodyString = null; // bodyString will be null for GET method
		if (entityBody != null) {
			ObjectMapper mapper = new ObjectMapper();
			bodyString = mapper.writeValueAsString(entityBody);
			LOGGER.debug("bodyString = {}", bodyString);
		}
		HttpHeaders eloquaHeaders = new HttpHeaders();
		eloquaHeaders.setContentType(MediaType.APPLICATION_JSON);
		LOGGER.trace("Base Url = {}", baseUrl);
		LOGGER.trace("Authorization = {}", authValue);
		eloquaHeaders.set("Authorization", "Basic " + authValue);
		HttpEntity<String> request = new HttpEntity<>(bodyString, eloquaHeaders);

		return restTemplate.exchange(url, httpMethod, request, responseType);
	}

	public <T, U> ResponseEntity<U> executeContactUpload(T entityBody, String uriContextPath, HttpMethod httpMethod,
			Class<U> responseType) throws URISyntaxException, JsonProcessingException {
		URI url = new URI(baseUrl + uriContextPath);
		String bodyString = null; // bodyString will be null for GET method
		if (entityBody != null) {
			ObjectMapper mapper = new ObjectMapper();
			bodyString = mapper.writeValueAsString(entityBody);
		}
		HttpHeaders eloquaHeaders = new HttpHeaders();
		eloquaHeaders.setContentType(MediaType.APPLICATION_JSON);
		LOGGER.trace("Base Url = {}", baseUrl);
		LOGGER.trace("Authorization = {}", authValue);
		eloquaHeaders.set("Authorization", "Basic " + authValue);
		HttpEntity<String> request = new HttpEntity<>(bodyString, eloquaHeaders);

		return restTemplate.exchange(url, httpMethod, request, responseType);
	}
	
	public <T, U> ResponseEntity<U> executeFetchSurvey(T entityBody, String uriContextPath, HttpMethod httpMethod,
			Class<U> responseType) throws URISyntaxException, JsonProcessingException {
		URI url = new URI(surveybaseURL + uriContextPath);
		String bodyString = null;
		if (entityBody != null) {
			ObjectMapper mapper = new ObjectMapper();
			bodyString = mapper.writeValueAsString(entityBody);
			LOGGER.debug("bodyString = {}", bodyString);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		LOGGER.trace("Base Url = {}", surveybaseURL);
		HttpEntity<String> request = new HttpEntity<>(bodyString, headers);

		return restTemplate.exchange(url, httpMethod, request, responseType);
	}
	
	public CloudBlobContainer getContainer() {
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		
		try {
			storageAccount = CloudStorageAccount.parse(getStorageConnectionString());
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(imageContainerName);
			container.createIfNotExists();
		} catch (InvalidKeyException | URISyntaxException | StorageException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error in deleting the Image File {}", e);
		}
		
		return container;
	}
	
	private  String getStorageConnectionString() {
		return "DefaultEndpointsProtocol=https;" + "AccountName=" + azureAccountName + ";AccountKey=" + azureAccountKey
				+ ";" + "EndpointSuffix=core.windows.net";

	}

	public <T, U> ResponseEntity<U> executeGetCampaignStatus(T entityBody, String uriContextPath, HttpMethod httpMethod,
			Class<U> responseType) throws URISyntaxException, JsonProcessingException {
		URI url = new URI(clinicianbaseURL + uriContextPath);
		String bodyString = null;
		if (entityBody != null) {
			ObjectMapper mapper = new ObjectMapper();
			bodyString = mapper.writeValueAsString(entityBody);
			LOGGER.debug("bodyString = {}", bodyString);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		LOGGER.trace("Base Url = {}", clinicianbaseURL);
		HttpEntity<String> request = new HttpEntity<>(bodyString, headers);

		return restTemplate.exchange(url, httpMethod, request, responseType);
	}
}
