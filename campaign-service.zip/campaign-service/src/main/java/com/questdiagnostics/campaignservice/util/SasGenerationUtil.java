package com.questdiagnostics.campaignservice.util;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.EnumSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.microsoft.azure.storage.StorageCredentials;
import com.microsoft.azure.storage.StorageCredentialsAccountAndKey;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudPageBlob;
import com.microsoft.azure.storage.blob.SharedAccessBlobPermissions;
import com.microsoft.azure.storage.blob.SharedAccessBlobPolicy;



@Component
public class SasGenerationUtil {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureAccountName;

	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureAccountKey;

	@Value("${sprintt.azure.storage.SASTokenGenerationTime}")
	private long sasToekenGenerationTime;

	@Value("${sprintt.azure.storage.container.name}")
	private String imageContainerName;

	public String getBlobSASString(Long trialId, String imageName)
			throws URISyntaxException, InvalidKeyException, StorageException, MalformedURLException {
		logger.info("Process started of getBlobSASString ==========");
		String directoryToDownloadString = new StringBuilder("T").append("_").append(trialId).toString();
		String sasString = "";
		try {
			URI uri = new URI("https://" + azureAccountName + ".blob.core.windows.net/" + imageContainerName + "/"
					+ directoryToDownloadString + "/" + imageName);
			sasString = uri.toString() + "?" + generateSasToken(uri);
			logger.debug(sasString);

		} catch (Exception e) {
			sasString = "Some Error Occured ,Please try again";
		}

		return sasString;
	}

	public String generateSasToken(URI fileUri) throws StorageException, URISyntaxException, InvalidKeyException {
		StorageCredentials credentials = new StorageCredentialsAccountAndKey(azureAccountName, azureAccountKey);
		CloudBlob file = new CloudPageBlob(fileUri, credentials);
		SharedAccessBlobPolicy policy = new SharedAccessBlobPolicy();
		policy.setPermissions(EnumSet.of(SharedAccessBlobPermissions.READ));
		policy.setSharedAccessStartTime(null);
		policy.setSharedAccessExpiryTime(getExpirationTime());
		return file.generateSharedAccessSignature(policy, null);
	}

	private Date getExpirationTime() {
		logger.debug("Current Date is:" + LocalDateTime.now());
		LocalDateTime expLDT = LocalDateTime.now().plusMinutes(sasToekenGenerationTime);
		logger.debug("Date after added time is:" + expLDT);
		logger.debug("Zone is:" + ZoneId.systemDefault());
		Instant expInstant = expLDT.atZone(ZoneId.systemDefault()).toInstant();
		logger.debug("Instant is:" + expInstant);
		return Date.from(expInstant);
	}

}
