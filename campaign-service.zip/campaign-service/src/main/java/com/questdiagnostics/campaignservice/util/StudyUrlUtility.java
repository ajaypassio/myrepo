package com.questdiagnostics.campaignservice.util;

import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;


@Component
public class StudyUrlUtility {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${study.base.URL}")
	private String studyBaseURL;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	RESTUtils restUtils;
	private static final String URI_CONTEXT_PATH = "/getSurveyId";

	public String buildStudyURL(Long trialId, String pId) {
		logger.info("buildStudyURL process started---");
		String source = "myquest";
		String studySideURl = null;
		String surveyId = getSurveyIdByTrialId(trialId);
		if (!StringUtils.isEmpty(surveyId) && !surveyId.equals("No survey found"))
			studySideURl = studyBaseURL + "?" + "qid=" + surveyId + "&" + "pid=" + pId + "&" + "src=" + source;
		return studySideURl;
	}

	public String getSurveyIdByTrialId(Long trialId) {
		ResponseEntity<ResponseObjectModel> responseEntity = null;
		String surveyId = null;
		try {
			responseEntity = restUtils.executeFetchSurvey(null, URI_CONTEXT_PATH + "/" + trialId, HttpMethod.GET,
					ResponseObjectModel.class);
		} catch (JsonProcessingException | URISyntaxException e) {
			logger.error("Exception occured during intraction with survey service : {}", e);
		}
		if (responseEntity != null && responseEntity.getStatusCode().equals(HttpStatus.OK)) {
			surveyId = (String) responseEntity.getBody().getData();
		}
		return surveyId;
	}
}
