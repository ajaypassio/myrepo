package com.questdiagnostics.campaignservice.workflowengine;

import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.workflowengine.CampaignGuardable.CampaignGuard;

public abstract class CampaignBaseTransitionTemplate {
	
	private Class<? extends CampaignMaster> transitionalEntityClazz;
	
	protected abstract void registerGuards();

	protected abstract void registerTransitionTemplate();

	protected abstract void registerTransitions();
	
	protected abstract <T extends CampaignMaster> boolean isValidTransition(CampaignTransition<T> transition);
	
	public abstract <T extends CampaignMaster> CampaignGuard getGuard(CampaignTransition<T> transition);

	protected void initialize() {
		registerTransitions();		
		registerGuards();
		registerTransitionTemplate();
	}
	
	protected <T extends CampaignMaster> void setTransitionalEntityClazz(Class<T> clazz) {
		this.transitionalEntityClazz = clazz;
	}
	
	public Class<? extends CampaignMaster> getTransitionalEntityClass() {
		return transitionalEntityClazz;
	}
}