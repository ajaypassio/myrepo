package com.questdiagnostics.campaignservice.workflowengine;

import java.util.function.BiPredicate;

import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignMaster;

public interface CampaignGuardable {

	boolean verify(EntityWithResponse<CampaignMaster> resp);
	
	static class CampaignGuard implements CampaignGuardable {
		private CampaignTransition<CampaignMaster> transition;
		private BiPredicate<EntityWithResponse<CampaignMaster>, SprinttCampaignStatus> guardCondition;
		
		CampaignGuard(CampaignTransition<CampaignMaster> transition) {
			this.transition = transition;
		}
		
		public CampaignGuard(SprinttCampaignStatus fromState, SprinttCampaignStatus toState, Class<CampaignMaster> transitioEntityClass,
				BiPredicate<EntityWithResponse<CampaignMaster>, SprinttCampaignStatus> guardCondition) {
			transition = new CampaignTransition<>(fromState, toState, transitioEntityClass);
			this.guardCondition = guardCondition;
		}

		public boolean verify(EntityWithResponse<CampaignMaster> resp) {
			return guardCondition.test(resp, transition.getToState());
		}
		
		CampaignTransition<CampaignMaster> getTransition() {
			return transition;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((transition == null) ? 0 : transition.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CampaignGuard other = (CampaignGuard) obj;
			if (transition == null) {
				if (other.transition != null)
					return false;
			} else if (!transition.equals(other.transition)) {
				return false;
			}
			return true;
		}
		
	}
}
