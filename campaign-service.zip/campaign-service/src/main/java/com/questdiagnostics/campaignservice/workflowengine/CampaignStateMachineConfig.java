package com.questdiagnostics.campaignservice.workflowengine;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.questdiagnostics.campaignservice.model.CampaignMaster;

public class CampaignStateMachineConfig {

	private CampaignStateMachineConfig() {
		throw new UnsupportedOperationException("Constructor not allowed.");
	}

	private static final Map<Class<? extends CampaignMaster>, CampaignBaseTransitionTemplate> TRANSITION_TEMPLATE_REGISTRY = new ConcurrentHashMap<>();

	public static void registerTransitionTemplate(CampaignBaseTransitionTemplate transitionTemplate) {
		TRANSITION_TEMPLATE_REGISTRY.putIfAbsent(transitionTemplate.getTransitionalEntityClass(), transitionTemplate);
	}

	public static <U extends CampaignMaster> CampaignBaseTransitionTemplate getTransitionTemplate(Class<U> clazz) {
		return TRANSITION_TEMPLATE_REGISTRY.get(clazz);
	}

}
