package com.questdiagnostics.campaignservice.workflowengine;

import java.util.ArrayList;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.FailedGuardException;
import com.questdiagnostics.campaignservice.exception.InvalidTransitionException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.model.CampaignAuditLog;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

@Component
public class CampaignStateTransitionManager {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@PostConstruct
	private void intitialTemplate() {
		CampaignTransitionTemplate.getInstance();
	}

	public CampaignMaster execute(ResponseObjectModel resp, CampaignMaster campaignEntity,
			SprinttCampaignStatus toState) throws WorkflowEngineException {
		if (!verify(resp, campaignEntity, toState)) {
			throw new FailedGuardException("Verfication for campaign Id " + campaignEntity.getSprinttCampaignId()
					+ " failed for transition from: " + campaignEntity.getCurrentState().name() + " to: "
					+ toState.name(), resp);
		}
		logger.debug("campaign entity {} transition from {} to {} verified.", campaignEntity.getSprinttCampaignId(),
				campaignEntity.getCurrentState().getType(), toState.getType());

		logger.info("campaign entity {} transition from {} to {} executed.", campaignEntity.getSprinttCampaignId(),
				campaignEntity.getCurrentState().getType(), toState.getType());
		performStateTransitionLogging(campaignEntity, toState);
		campaignEntity.setCampaignStatusId(toState.getValue());
		campaignEntity.setUpdatedOn(new Date());

		return campaignEntity;
	}
	
	@SuppressWarnings("unchecked")
	public CampaignMaster forceExecute(CampaignMaster campaignEntity,
			SprinttCampaignStatus toState) throws WorkflowEngineException {
		CampaignBaseTransitionTemplate transitionTemplate = CampaignStateMachineConfig
				.getTransitionTemplate(campaignEntity.getClass());
		CampaignTransition<CampaignMaster> transition = new CampaignTransition<>(campaignEntity.getCurrentState(), toState,
				(Class<CampaignMaster>) campaignEntity.getClass());
		if (!transitionTemplate.isValidTransition(transition)) {		
			
			throw new InvalidTransitionException("Transition for " + campaignEntity.getClass().getCanonicalName() + " from: "
					+ campaignEntity.getCurrentState().name() + " state to: " + toState.name() + " state not allowed.");
		}
		
		logger.debug("campaign entity {} transition from {} to {} verified.", campaignEntity.getSprinttCampaignId(),
				campaignEntity.getCurrentState().getType(), toState.getType());

		logger.info("campaign entity {} transition from {} to {} executed.", campaignEntity.getSprinttCampaignId(),
				campaignEntity.getCurrentState().getType(), toState.getType());
		performStateTransitionLogging(campaignEntity, toState);
		campaignEntity.setCampaignStatusId(toState.getValue());
		campaignEntity.setUpdatedOn(new Date());

		return campaignEntity;
	}

	@SuppressWarnings("unchecked")
	private boolean verify(ResponseObjectModel resp, CampaignMaster target, SprinttCampaignStatus toState)
			throws WorkflowEngineException {
		CampaignBaseTransitionTemplate transitionTemplate = CampaignStateMachineConfig
				.getTransitionTemplate(target.getClass());
		CampaignTransition<CampaignMaster> transition = new CampaignTransition<>(target.getCurrentState(), toState,
				(Class<CampaignMaster>) target.getClass());
		if (!transitionTemplate.isValidTransition(transition)) {
			/*
			 * resp.setHttpStatus(HttpStatus.BAD_REQUEST);
			 * resp.setMessage("Transition for campaign from: " +
			 * target.getCurrentState().name() + " state to: " + toState.name() +
			 * " state not allowed.");
			 */
			
			// added by JKT for backend job
			
			if(resp!=null) {
				resp.setHttpStatus(HttpStatus.BAD_REQUEST);
				resp.setMessage("Transition for campaign from: " + target.getCurrentState().name() + " state to: "
						+ toState.name() + " state not allowed.");
			}
			
			throw new InvalidTransitionException("Transition for " + target.getClass().getCanonicalName() + " from: "
					+ target.getCurrentState().name() + " state to: " + toState.name() + " state not allowed.", resp);
		}
		return transitionTemplate.getGuard(transition).verify(new EntityWithResponse<CampaignMaster>(target, resp));
	}

	private void performStateTransitionLogging(CampaignMaster campaignEntity, SprinttCampaignStatus toState) {
		CampaignAuditLog auditLog = new CampaignAuditLog();
		auditLog.setFromState(campaignEntity.getCurrentState().getValue());
		auditLog.setToState(toState.getValue());
		auditLog.setCampaignMaster(campaignEntity);
		auditLog.setModifiedDate(new Date());
		
	
		 if (CollectionUtils.isEmpty(campaignEntity.getAuditLogs())) {
		 campaignEntity.setAuditLogs(new ArrayList<>()); }
		 campaignEntity.addAuditLog(auditLog);
		 

		logger.debug("Campaign Audit Log {} added for campaign Id {}", auditLog, campaignEntity.getSprinttCampaignId());
	}
}
