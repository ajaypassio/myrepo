package com.questdiagnostics.campaignservice.workflowengine;

import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;

public final class CampaignTransition<T extends CampaignTransitional> {

	private SprinttCampaignStatus fromState;

	private SprinttCampaignStatus toState;

	private Class<T> entityClass;

	public CampaignTransition(SprinttCampaignStatus fromState, SprinttCampaignStatus toState, Class<T> entityClass) {
		this.fromState = fromState;
		this.toState = toState;
		this.entityClass = entityClass;
	}

	public SprinttCampaignStatus getFromState() {
		return fromState;
	}

	public SprinttCampaignStatus getToState() {
		return toState;
	}

	public Class<T> getEntityClass() {
		return entityClass;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fromState == null) ? 0 : fromState.hashCode());
		result = prime * result + ((toState == null) ? 0 : toState.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CampaignTransition<?> other = (CampaignTransition<?>) obj;
		if (entityClass == null) {
			if (other.entityClass != null)
				return false;
		} else if (!entityClass.equals(other.entityClass)) {
			return false;
		}
		if (fromState != other.fromState || toState != other.toState) {
			return false;
		}
		return true;
	}
}
