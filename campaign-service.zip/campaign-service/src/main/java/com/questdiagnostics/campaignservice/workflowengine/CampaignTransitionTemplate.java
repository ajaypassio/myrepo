package com.questdiagnostics.campaignservice.workflowengine;

import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.CLOSED;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DEPLOYED;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DISCARDED;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.DRAFT;
import static com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus.SCHEDULED;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.questdiagnostics.campaignservice.constant.CommonConstants;
import com.questdiagnostics.campaignservice.enums.CampaignJobStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.workflowengine.CampaignGuardable.CampaignGuard;

public class CampaignTransitionTemplate extends CampaignBaseTransitionTemplate {

	private static final Logger LOGGER = LoggerFactory.getLogger(CampaignTransitionTemplate.class);
	private static final Set<CampaignGuard> GUARD_REGISTRY = new HashSet<>();

	private static final Set<CampaignTransition<CampaignMaster>> TRANSITION_REGISTRY = new HashSet<>();

	private static final CampaignBaseTransitionTemplate INSTANCE = new CampaignTransitionTemplate();

	private CampaignTransitionTemplate() {
		initialize();
	}

	public static CampaignBaseTransitionTemplate getInstance() {
		return INSTANCE;
	}

	@Override
	protected void registerGuards() {
		GUARD_REGISTRY.add(new CampaignGuard(DRAFT, DISCARDED, CampaignMaster.class, (e, t) -> true));

		// 1. check if scheduler, email templates are present
		// 2. schedule date after current date
		// 3. Patient job status is success

		// added by JKT and Jyoti for backend job
		GUARD_REGISTRY.add(new CampaignGuard(DEPLOYED, DEPLOYED, CampaignMaster.class,
				(entityWithResponse, toState) -> deployedToDeployed(entityWithResponse)));

		GUARD_REGISTRY.add(new CampaignGuard(DRAFT, DEPLOYED, CampaignMaster.class,
				(entityWithResponse, toState) -> draftToDeployed(entityWithResponse)));
		GUARD_REGISTRY.add(new CampaignGuard(DRAFT, SCHEDULED, CampaignMaster.class,
				(entityWithResponse, toState) -> draftToScheduled(entityWithResponse)));

		// schedule start date/time must be after current date
		GUARD_REGISTRY.add(new CampaignGuard(SCHEDULED, DRAFT, CampaignMaster.class, (entityWithResponse, toState) -> {
			return entityWithResponse.getEntity().getSchedule().getNormalizedStartDateTime()
					.after(Calendar.getInstance().getTime());
		}));
		GUARD_REGISTRY.add(new CampaignGuard(SCHEDULED, DEPLOYED, CampaignMaster.class,
				(entityWithResponse, toState) -> scheduledToDeployed(entityWithResponse)));

		GUARD_REGISTRY.add(new CampaignGuard(DEPLOYED, CLOSED, CampaignMaster.class, (e, t) -> true));
		GUARD_REGISTRY.add(new CampaignGuard(DISCARDED, DRAFT, CampaignMaster.class, (e, t) -> true));
		GUARD_REGISTRY.add(new CampaignGuard(SCHEDULED, DISCARDED, CampaignMaster.class, (e, t) -> true));
		GUARD_REGISTRY.add(new CampaignGuard(CLOSED, DRAFT, CampaignMaster.class, (e, t) -> true));
	}

	private boolean draftToXXX(EntityWithResponse<CampaignMaster> entityWithResponse,
			SprinttCampaignStatus targetState) {
		LOGGER.info("campaignEntity.getSchedule() is {} and campaignEntity.getEmailTemplate() is {}",
				entityWithResponse.getEntity().getSchedule(), entityWithResponse.getEntity().getEmailTemplate());
		LOGGER.info("campaignEntity {} normalized schedule start date is {} and current date is {}",
				entityWithResponse.getEntity().getCampaignId(),
				entityWithResponse.getEntity().getSchedule().getNormalizedStartDateTime(), new Date());
		if (entityWithResponse.getEntity().getSchedule().getNormalizedStartDateTime().before(new Date())) {
			entityWithResponse.getResp().setHttpStatus(HttpStatus.BAD_REQUEST);
			entityWithResponse.getResp().setMessage("Schedule date cannot be a past date.");
			return false;
		}
		if (entityWithResponse.getEntity().getCampaignStatusId().equals(SprinttCampaignStatus.SCHEDULED.getValue())
				&& (entityWithResponse.getEntity().getCampaignJobStatusId()
						.equals(CampaignJobStatus.SCHEDULED_FAILED_AFTER_CONTACT_LIST_UPLOADED.getValue()) ||
						entityWithResponse.getEntity().getCampaignJobStatusId()
						.equals(CampaignJobStatus.CONTACT_LIST_UPLOAD_COMPLETED.getValue()))) {
             return true;
		}
		if (!entityWithResponse.getEntity().getCampaignJobStatusId()
				.equals(CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue())
				&& entityWithResponse.getEntity().getCampaignStatusId().equals(targetState.getValue())) {
			entityWithResponse.getResp().setHttpStatus(HttpStatus.BAD_REQUEST);
			entityWithResponse.getResp().setMessage(CommonConstants.PATIENT_LIST_GENERATION_INPROGRESS_MSG);
			return false;
		}
		return true;
	}

	// added by JKT and Jyoti by backend process
	private boolean deployedToXXX(EntityWithResponse<CampaignMaster> entityWithResponse,
			SprinttCampaignStatus targetState) {
		LOGGER.info("campaignEntity.getSchedule() is {} and campaignEntity.getEmailTemplate() is {}",
				entityWithResponse.getEntity().getSchedule(), entityWithResponse.getEntity().getEmailTemplate());
		LOGGER.info("campaignEntity {} normalized schedule start date is {} and current date is {}",
				entityWithResponse.getEntity().getCampaignId(),
				entityWithResponse.getEntity().getSchedule().getNormalizedStartDateTime(), new Date());
		if (entityWithResponse.getEntity().getSchedule().getNormalizedStartDateTime().before(new Date())
				&& !entityWithResponse.getEntity().getCampaignJobStatusId()
						.equals(CampaignJobStatus.CONTACTS_UPLOAD_COMPLETED.getValue())
				&& entityWithResponse.getEntity().getCampaignStatusId().equals(targetState.getValue())) {
//entityWithResponse.getResp().setHttpStatus(HttpStatus.BAD_REQUEST);
//entityWithResponse.getResp().setMessage("Schedule date cannot be a past date.");
			return false;

		}
		return true;
	}

	private boolean draftToScheduled(EntityWithResponse<CampaignMaster> entityWithResponse) {
		return draftToXXX(entityWithResponse, DRAFT);
	}

	private boolean draftToDeployed(EntityWithResponse<CampaignMaster> entityWithResponse) {
		return draftToXXX(entityWithResponse, DRAFT);
	}

	private boolean scheduledToDeployed(EntityWithResponse<CampaignMaster> entityWithResponse) {
		return draftToXXX(entityWithResponse, SCHEDULED);
	}

	// added by JKT and Jyoti for backend process
	private boolean deployedToDeployed(EntityWithResponse<CampaignMaster> entityWithResponse) {
		return deployedToXXX(entityWithResponse, DEPLOYED);
	}

	@Override
	protected void registerTransitionTemplate() {
		setTransitionalEntityClazz(CampaignMaster.class);
		CampaignStateMachineConfig.registerTransitionTemplate(this);
	}

	@Override
	protected void registerTransitions() {

		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DRAFT, SCHEDULED, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DRAFT, DEPLOYED, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DRAFT, DISCARDED, CampaignMaster.class));

		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(SCHEDULED, DRAFT, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(SCHEDULED, DEPLOYED, CampaignMaster.class));

		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DEPLOYED, DRAFT, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DEPLOYED, CLOSED, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DEPLOYED, DISCARDED, CampaignMaster.class));

		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(DISCARDED, DRAFT, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(SCHEDULED, DISCARDED, CampaignMaster.class));
		TRANSITION_REGISTRY.add(new CampaignTransition<CampaignMaster>(CLOSED, DRAFT, CampaignMaster.class));
	}

	@Override
	protected <T extends CampaignMaster> boolean isValidTransition(CampaignTransition<T> transition) {
		return TRANSITION_REGISTRY.contains(transition);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends CampaignMaster> CampaignGuard getGuard(CampaignTransition<T> transition) {
		CampaignGuard tmpGuard = new CampaignGuard((CampaignTransition<CampaignMaster>) transition);
		for (CampaignGuard guard : GUARD_REGISTRY) {
			if (guard.equals(tmpGuard))
				return guard;
		}
		return null;
	}
}
