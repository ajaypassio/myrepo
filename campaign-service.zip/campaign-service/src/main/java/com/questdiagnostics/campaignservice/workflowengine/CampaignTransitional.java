package com.questdiagnostics.campaignservice.workflowengine;

import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;

public interface CampaignTransitional {
	SprinttCampaignStatus getCurrentState();
}
