package com.questdiagnostics.campaignservice.workflowengine;

import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.response.model.ResponseObjectModel;

public class EntityWithResponse<T extends CampaignMaster> {

	private T entity;
	
	private ResponseObjectModel resp;

	public EntityWithResponse(T entity, ResponseObjectModel resp) {
		super();
		this.entity = entity;
		this.resp = resp;
	}

	public T getEntity() {
		return entity;
	}

	public ResponseObjectModel getResp() {
		return resp;
	}
	
}
