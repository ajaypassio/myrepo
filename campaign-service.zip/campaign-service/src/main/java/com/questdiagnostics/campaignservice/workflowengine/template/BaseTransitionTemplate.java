package com.questdiagnostics.campaignservice.workflowengine.template;

import com.questdiagnostics.campaignservice.workflowengine.template.Guardable.BaseGuard;

public abstract class BaseTransitionTemplate {
	
	private Class<? extends TransitionalEntity> transitionalEntityClazz;
	
	protected abstract void registerGuards();

	protected abstract void registerTransitionTemplate();

	protected abstract void registerTransitions();
	
	protected abstract <T extends TransitionalEntity> boolean isValidTransition(Transition<T> transition);
	
	public abstract <T extends TransitionalEntity> BaseGuard getGuard(Transition<T> transition);

	protected void initialize() {
		registerTransitions();		
		registerGuards();
		registerTransitionTemplate();
	}
	
	protected <T extends TransitionalEntity> void setTransitionalEntityClazz(Class<T> clazz) {
		this.transitionalEntityClazz = clazz;
	}
	
	public Class<? extends TransitionalEntity> getTransitionalEntityClass() {
		return transitionalEntityClazz;
	}
}