package com.questdiagnostics.campaignservice.workflowengine.template;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DefaultStateMachineConfig {

	private DefaultStateMachineConfig() {
		throw new UnsupportedOperationException("Constructor not allowed.");
	}

	private static final Map<Class<? extends TransitionalEntity>, BaseTransitionTemplate> TRANSITION_TEMPLATE_REGISTRY = new ConcurrentHashMap<>();

	public static void registerTransitionTemplate(BaseTransitionTemplate transitionTemplate) {
		TRANSITION_TEMPLATE_REGISTRY.putIfAbsent(transitionTemplate.getTransitionalEntityClass(), transitionTemplate);
	}

	public static <U extends TransitionalEntity> BaseTransitionTemplate getTransitionTemplate(Class<U> clazz) {
		return TRANSITION_TEMPLATE_REGISTRY.get(clazz);
	}

}
