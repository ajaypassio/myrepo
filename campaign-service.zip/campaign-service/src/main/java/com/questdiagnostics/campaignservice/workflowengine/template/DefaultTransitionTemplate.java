package com.questdiagnostics.campaignservice.workflowengine.template;

import java.util.HashSet;
import java.util.Set;

import com.questdiagnostics.campaignservice.workflowengine.template.Guardable.BaseGuard;

/**
 * This class is for illustration purpose for creating a transition template.
 * Not used in any feature.
 * 
 * @author samarth.srivastava
 *
 */
public class DefaultTransitionTemplate extends BaseTransitionTemplate {

	private static final Set<BaseGuard> GUARD_REGISTRY = new HashSet<>();

	private static final Set<Transition<TransitionalEntity>> TRANSITION_REGISTRY = new HashSet<>();

	private static final BaseTransitionTemplate INSTANCE = new DefaultTransitionTemplate();

	private DefaultTransitionTemplate() {
		initialize();
	}

	public static BaseTransitionTemplate getInstance() {
		return INSTANCE;
	}

	@Override
	protected void registerTransitionTemplate() {
		setTransitionalEntityClazz(TransitionalEntity.class);
		DefaultStateMachineConfig.registerTransitionTemplate(this);
	}

	@Override
	protected void registerGuards() {
		GUARD_REGISTRY.add(new BaseGuard(State.BEGIN, State.INTERMEDIATE1, TransitionalEntity.class, (e, t) -> true));
		GUARD_REGISTRY.add(new BaseGuard(State.BEGIN, State.INTERMEDIATE2, TransitionalEntity.class, (e, t) -> true));
		GUARD_REGISTRY.add(new BaseGuard(State.INTERMEDIATE1, State.END, TransitionalEntity.class, (e, t) -> true));
		GUARD_REGISTRY.add(new BaseGuard(State.INTERMEDIATE2, State.END, TransitionalEntity.class, (e, t) -> false));
	}

	@Override
	protected void registerTransitions() {
		TRANSITION_REGISTRY
				.add(new Transition<TransitionalEntity>(State.BEGIN, State.INTERMEDIATE1, TransitionalEntity.class));
		TRANSITION_REGISTRY
				.add(new Transition<TransitionalEntity>(State.BEGIN, State.INTERMEDIATE2, TransitionalEntity.class));
		TRANSITION_REGISTRY
				.add(new Transition<TransitionalEntity>(State.INTERMEDIATE1, State.END, TransitionalEntity.class));
		TRANSITION_REGISTRY
				.add(new Transition<TransitionalEntity>(State.INTERMEDIATE2, State.END, TransitionalEntity.class));
	}

	@Override
	protected <T extends TransitionalEntity> boolean isValidTransition(Transition<T> transition) {
		return TRANSITION_REGISTRY.contains(transition);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends TransitionalEntity> BaseGuard getGuard(Transition<T> transition) {
		BaseGuard tmpGuard = new BaseGuard((Transition<TransitionalEntity>) transition);
		for (BaseGuard guard : GUARD_REGISTRY) {
			if (guard.equals(tmpGuard))
				return guard;
		}
		return null;
	}

}
