package com.questdiagnostics.campaignservice.workflowengine.template;

import java.util.function.BiPredicate;

public interface Guardable<T extends TransitionalEntity> {

	boolean verify(T entity);
	
	static class BaseGuard implements Guardable<TransitionalEntity> {
		private Transition<TransitionalEntity> transition;
		private BiPredicate<TransitionalEntity, State> guardCondition;
		
		BaseGuard(Transition<TransitionalEntity> transition) {
			this.transition = transition;
		}
		
		public BaseGuard(State fromState, State toState, Class<TransitionalEntity> transitioEntityClass,
				BiPredicate<TransitionalEntity, State> guardCondition) {
			transition = new Transition<>(fromState, toState, transitioEntityClass);
			this.guardCondition = guardCondition;
		}

		public boolean verify(TransitionalEntity entity) {
			return guardCondition.test(entity, transition.getToState());
		}
		
		Transition<TransitionalEntity> getTransition() {
			return transition;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((transition == null) ? 0 : transition.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			BaseGuard other = (BaseGuard) obj;
			if (transition == null) {
				if (other.transition != null)
					return false;
			} else if (!transition.equals(other.transition)) {
				return false;
			}
			return true;
		}
		
	}
}
