package com.questdiagnostics.campaignservice.workflowengine.template;

public enum State {
	BEGIN, INTERMEDIATE1, INTERMEDIATE2, END
}
