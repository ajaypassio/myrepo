package com.questdiagnostics.campaignservice.workflowengine.template;

import com.questdiagnostics.campaignservice.exception.FailedGuardException;
import com.questdiagnostics.campaignservice.exception.InvalidTransitionException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;

public class StateTransitionManager<T extends TransitionalEntity> {

	@SuppressWarnings("unchecked")
	private boolean verify(T target, State toState) throws WorkflowEngineException {
		
		BaseTransitionTemplate transtionTemplate = DefaultStateMachineConfig.getTransitionTemplate(target.getClass());
		
		Transition<T> transition = new Transition<>(target.getCurrentState(), toState, (Class<T>) target.getClass());
		
		if(!transtionTemplate.isValidTransition(transition)) {
			throw new InvalidTransitionException("Transition for " + target.getClass().getCanonicalName() + " from: "
					+ target.getCurrentState().name() + " state to: " + toState.name() + " state not allowed.");
		}
		
		return transtionTemplate.getGuard(transition).verify(target);
	}

	public T execute(T transitionEntity, State toState) throws WorkflowEngineException {
		if(!verify(transitionEntity, toState)) {
			throw new FailedGuardException("Verfication for " + transitionEntity + " failed for transition from: "
					+ transitionEntity.getCurrentState().name() + " state to: " + toState.name() + " state");
		}
		transitionEntity.setCurrentState(toState);
		
		// TODO - perform state-transition logging in database.
		return transitionEntity;
	}
}
