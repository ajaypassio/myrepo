package com.questdiagnostics.campaignservice.workflowengine.template;

public interface Transitional {
	State getCurrentState();
}
