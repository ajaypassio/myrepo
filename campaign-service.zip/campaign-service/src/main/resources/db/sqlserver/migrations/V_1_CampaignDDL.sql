CREATE TABLE [dbo].[CampaignMaster](
	[SprinttCampaignId] [bigint] IDENTITY(1,1) NOT NULL,
	[CampaignId] [varchar](512) NULL,
	[CampaignName] [varchar](512) NULL,
	[SegmentId] [bigint] NULL,
	[TrialId] [bigint] NOT NULL,
	[ScheduleId] [bigint] NULL,	
	[EmailTemplateId] [bigint] NULL,
	[CampaignStatusId] [int] NULL,
	[EloCampgnStatusId] [int] NULL,
	[CampaignJobStatusId] [int] NULL,
	[QuestionnaireId] [int] NULL,
	[InclusionCriteria] [text] NULL,
	[ExclusionCriteria] [text] NULL,
	[PortalLink] [text] NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	LastAction Varchar(100)  NULL,
    NextAction Varchar(100) NULL,
	Remarks [varchar](512) NULL,
PRIMARY KEY CLUSTERED 
(
	[SprinttCampaignId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[CampaignStatus](
    [CampaignStatusId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[StatusType] [varchar](50) NOT NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,	
	PRIMARY KEY CLUSTERED 
(
	[CampaignStatusId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[EmailTemplate](
    [EmailTemplateId] [bigint] IDENTITY(1,1) NOT NULL,  
    [TrialId] [bigint] NOT NULL,
	[DefaultEmailTemp] [int] NOT NULL,
	[EloquaEmailTempId] [int] NULL,
	[Name] [varchar](512) NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	PRIMARY KEY CLUSTERED 
(
	[EmailTemplateId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[Schedule](
    [ScheduleId] [bigint] IDENTITY(1,1) NOT NULL,   
    [TrialId] [bigint] NOT NULL,
	[DefaultSchedule] [int] NOT NULL,
	[StartDateTime] [datetimeoffset] NULL,	
	[EndDate][date] NULL,	
	[SchedulerTimeZone] [varchar](255) NULL, 
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	PRIMARY KEY CLUSTERED 
(
	[ScheduleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Reminder](
       [ReminderId] [bigint] IDENTITY(1,1) NOT NULL,
       [TrialId] [bigint] NOT NULL,
       [DefaultReminder] [int] NOT NULL,
       [RemindTo] [varchar](100) NULL,       
       [RemindOnDateTime] [datetimeoffset](7) NULL,
       [ReminderTimeZone] [varchar](255) NULL,       
       [CreatedBy] [varchar](255) NULL,
       [CreatedOn] [datetime2](0) NULL,
       [UpdatedBy] [varchar](255) NULL,
       [UpdatedOn] [datetime2](0) NULL,
	   SprinttCampaignId bigint NULL,
	PRIMARY KEY CLUSTERED 
(
	[ReminderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/*CREATE TABLE [dbo].[ParticipantStudySite_Trial_Id](
	[ParticipantId] [varchar](10) NULL,
	[TrialId] [bigint] NULL,
	[StudySiteId] [bigint] NULL,
	[ParticipantStatusId] [bigint] NULL,
	[ParticipantStudySiteId] [bigint] IDENTITY(1,1) NOT NULL,
	[SprinttCampaignId] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[StatusNotes] [varchar](255) NULL,
	[scoreJSON] [varchar](4000) NULL,
	[CreatedBy] [varchar](255) NULL,
	[Updatedby] [varchar](255) NULL,
	[Notes] [nvarchar](max) NULL,
	[SearchName] [varchar](250) NULL,
	[IsEmailOpened] int NULL,
	[IsEmailClicked] int NULL,
	[IsEmailInSpam] int NULL,
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO*/

CREATE TABLE [dbo].[Audit_Log](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EntityName] [varchar](255) NULL,
	[ActionPerformed] [varchar](255) NULL,
	[EntityContent] [text] NULL,
	[ModifiedBy] [varchar](255) NULL,
	[ModifiedDate] [datetime2](0) NULL,
	PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[CampaignAuditLog](
    [Id] [bigint] IDENTITY(1,1) NOT NULL,
	[SprinttCampaignId] [bigint] NOT NULL,
	[FromState] [int] NULL,
	[ToState] [int] NULL,
	[ModifiedBy] [varchar](255) NULL,
	[ModifiedDate] [datetime2](0) NULL,
	PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/*CREATE TABLE [dbo].[Participant](
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[EmailAddress] [varchar](250) NOT NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[TrialVisits] [bigint] NULL,
	[TrialSponsors] [varchar](2000) NULL,
	[ParticipantId] [varchar](50) NOT NULL,
	[ZipCode] [varchar](20) NULL,
	[ContactNumber] [varchar](20) NULL,
	[DOB] [datetime] NULL,
	[Gender] [varchar](10) NULL,
	[Address] [varchar](256) NULL,
	[SMS] [bit] NULL,
	[City] [varchar](512) NULL,
	[State] [varchar](512) NULL,
	[PhoneType] [varchar](20) NULL,
	[Voicemail] [bit] NULL,
	[PreferredTimeOfContact] [varchar](45) NULL,
	[Session] [varchar](10) NULL,
	[IsPreferredEmail] [bit] NULL,
	[IsPreferredPhone] [bit] NULL,
	[IsPreferredMail] [bit] NULL,	
	[PatientEncId] varchar(255) NOT NULL,
 CONSTRAINT [pk_participant] PRIMARY KEY CLUSTERED 
(
	[ParticipantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Participant] ADD [PatientEncId] varchar(255) NOT NULL
GO*/

