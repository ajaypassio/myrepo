 ALTER TABLE CampaignMaster
DROP COLUMN CreatedOn;

ALTER TABLE CampaignMaster
ADD  CreatedOn [varchar](50);