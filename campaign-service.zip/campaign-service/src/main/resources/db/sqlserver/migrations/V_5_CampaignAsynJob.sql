CREATE TABLE [dbo].[CampaignAsyncJob](
	[JobId] [bigint] IDENTITY(1,1) NOT NULL,
	[JobStatus] [tinyint] NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[CampaignId] [bigint] NOT NULL,
	[StartPos] [bigint] NOT NULL,
	[EndPos] [bigint] NOT NULL,
	[TotalRecordsProcessed] [int] NOT NULL,
	[BatchSize] [int] NOT NULL,
	[NoOfBatches] [int] NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[CreatedBy] [varchar](50) NULL,
	[UpdatedBy] [varchar](50) NULL,
	[NoOfRetries] [tinyint] NOT NULL,
	[Remarks] [varchar](1000) NULL,
	[Remarks2] [varchar](50) NULL,
	[JobType] [tinyint] NOT NULL,
 CONSTRAINT [PK_CampaignAsyncJob] PRIMARY KEY CLUSTERED 
(
	[JobId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_StartPos]  DEFAULT ((0)) FOR [StartPos]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_EndPos]  DEFAULT ((0)) FOR [EndPos]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_TotalRecordsProcessed]  DEFAULT ((0)) FOR [TotalRecordsProcessed]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_BatchSize]  DEFAULT ((0)) FOR [BatchSize]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_NoOfBatches]  DEFAULT ((0)) FOR [NoOfBatches]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_NoOfRetries]  DEFAULT ((0)) FOR [NoOfRetries]
GO

ALTER TABLE [dbo].[CampaignAsyncJob] ADD  CONSTRAINT [DF_CampaignAsyncJob_JobType]  DEFAULT ((0)) FOR [JobType]
GO




CREATE NONCLUSTERED INDEX [IX_AsyncCampaignJob_CreatedOn] ON [dbo].[CampaignAsyncJob]
(
	[CreatedOn] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AsyncCampaignJob_TrailCampaign] ON [dbo].[CampaignAsyncJob]
(
	[TrialId] ASC,
	[CampaignId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


CREATE TABLE [dbo].[CampaignAsyncJobBatch](
	[JobId] [bigint] NOT NULL,
	[BatchId] [bigint] IDENTITY(1,1) NOT NULL,
	[BatchStatus] [tinyint] NOT NULL,
	[BatchSize] [int] NOT NULL,
	[StartPos] [bigint] NOT NULL,
	[EndPos] [bigint] NOT NULL,
	[Remarks] [varchar](1000) NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[NoOfRetries] [tinyint] NOT NULL,
	[Remarks2] [varchar](50) NULL,
 CONSTRAINT [PK_CampaignAsyncJobBatch_1] PRIMARY KEY CLUSTERED 
(
	[BatchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CampaignAsyncJobBatch] ADD  CONSTRAINT [DF_CampaignAsyncJobBatch_StartPos]  DEFAULT ((0)) FOR [StartPos]
GO

ALTER TABLE [dbo].[CampaignAsyncJobBatch] ADD  CONSTRAINT [DF_CampaignAsyncJobBatch_EndPos]  DEFAULT ((0)) FOR [EndPos]
GO

ALTER TABLE [dbo].[CampaignAsyncJobBatch] ADD  CONSTRAINT [DF_CampaignAsyncJobBatch_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[CampaignAsyncJobBatch] ADD  CONSTRAINT [DF_CampaignAsyncJobBatch_NoOfRetries]  DEFAULT ((0)) FOR [NoOfRetries]
GO



CREATE NONCLUSTERED INDEX [IX_JobId_CampaignAsyncJobBatch] ON [dbo].[CampaignAsyncJobBatch]
(
	[JobId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO