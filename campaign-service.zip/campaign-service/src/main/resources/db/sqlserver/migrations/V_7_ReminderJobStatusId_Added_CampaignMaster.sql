ALTER TABLE CampaignMaster ADD ReminderJobStatusId INT NOT NULL DEFAULT(0);
