USE [pdr_participant_prod]

CREATE TABLE [dbo].[AsyncJobModReplicas](
	[ModValue] [smallint] NOT NULL,
	[CreatedOn] [datetime2](7) NOT NULL,
	[ForceMod] [bit] NOT NULL,
	[ServiceName] [varchar](100) NOT NULL,
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UpdatedOn] [datetime2](7) NULL,
 CONSTRAINT [PK_AsyncJobModReplicas] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UC_AsyncJobModReplicas_SN_MV] UNIQUE NONCLUSTERED 
(
	[ModValue] ASC,
	[ServiceName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AsyncJobModReplicas] ADD  CONSTRAINT [DF_Table_1_ModType]  DEFAULT ((1)) FOR [ModValue]
GO

ALTER TABLE [dbo].[AsyncJobModReplicas] ADD  CONSTRAINT [DF_AsyncJobModReplicas_ForceMod]  DEFAULT ((0)) FOR [ForceMod]
GO