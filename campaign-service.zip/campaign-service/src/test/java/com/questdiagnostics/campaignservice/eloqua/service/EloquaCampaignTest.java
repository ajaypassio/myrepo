package com.questdiagnostics.campaignservice.eloqua.service;


import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.questdiagnostics.campaignservice.request.model.EloquaCampaignRequest;

/**
 * Run the tests from local environment only because the current date/time may be different
 * @author samarth.srivastava
 *
 */

public class EloquaCampaignTest {

	//@Test
	public void testCreateCampaign() throws URISyntaxException, JsonProcessingException {
		RestTemplate restTemplate = new RestTemplateBuilder()
				.basicAuthorization("TestQuestDiagnosticsConsumer\\Samarth.Srivastava", "Eloqua@123").build();
		EloquaCampaignRequest reqEntity = new EloquaCampaignRequest();
		reqEntity.setType("Campaign");
		reqEntity.setCurrentStatus("Draft");
		reqEntity.setName("SPRINTT Test Multiple Campaign draft 123");
		reqEntity.addPermissions("Retrieve", "Delete", "Update", "Activate");
		reqEntity.setIsReadOnly("false");
		reqEntity.setCampaignCategory("contact");
		reqEntity.setCampaignType("");
		
		final String baseUrl = "https://secure.p04.eloqua.com/api/REST/2.0/assets/campaign";
	    URI url = new URI(baseUrl);
	    ObjectMapper mapper = new ObjectMapper();
	    String jsonString = mapper.writeValueAsString(reqEntity);
	    System.out.println(jsonString);
	    HttpHeaders eloquaHeaders = new HttpHeaders();
	    eloquaHeaders.setContentType(MediaType.APPLICATION_JSON);
	    HttpEntity<String> request = new HttpEntity<>(jsonString, eloquaHeaders);//, eloquaHeaders);
	    
		ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
		Assert.assertEquals(201, result.getStatusCodeValue());
	}
}
