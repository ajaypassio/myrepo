package com.questdiagnostics.campaignservice.eloqua.service.async;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.questdiagnostics.campaignservice.async.service.DiscardAsyncTaskService;
import com.questdiagnostics.campaignservice.async.service.ScheduleAsyncTaskService;
import com.questdiagnostics.campaignservice.async.task.DiscardAsyncTask;
import com.questdiagnostics.campaignservice.async.task.ScheduleAsyncTask;

//@SpringBootTest
//@RunWith(SpringRunner.class)
public class PrototypeBeanTest {

	//@Autowired
	private DiscardAsyncTaskService discardAsyncTaskService;
	
	//@Autowired
	private ScheduleAsyncTaskService scheduleAsyncTaskService;
	
	//@Test
	public void prototypeBeanTest() {
		DiscardAsyncTask dtask1 = discardAsyncTaskService.getDiscardTaskInstance();
		DiscardAsyncTask dtask2 = discardAsyncTaskService.getDiscardTaskInstance();
		
		Assert.assertTrue("New instance expected", dtask1 != dtask2);
		
		ScheduleAsyncTask sTask1 = scheduleAsyncTaskService.getScheduledTaskInstance();
		ScheduleAsyncTask sTask2 = scheduleAsyncTaskService.getScheduledTaskInstance();
		
		Assert.assertTrue("New instance expected", sTask1 != sTask2);
	}
	
}
