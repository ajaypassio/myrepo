package com.questdiagnostics.campaignservice.manager;

import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.enums.EloquaCampaignStatus;
import com.questdiagnostics.campaignservice.enums.SprinttCampaignStatus;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.model.CampaignMaster;
import com.questdiagnostics.campaignservice.model.EmailTemplate;
import com.questdiagnostics.campaignservice.model.Reminder;
import com.questdiagnostics.campaignservice.model.Schedule;
import com.questdiagnostics.campaignservice.response.model.Element;
import com.questdiagnostics.campaignservice.response.model.EloquaCampaignResponse;

/**
 * Run the tests from local environment only because the current date/time may
 * be different
 * 
 * @author samarth.srivastava
 *
 */
//@SpringBootTest
//@RunWith(SpringRunner.class)
public class CampaignManagerTest {

	//@Autowired
	private CampaignManager campaignManager;

	// Commented as it creates junk data in eloqua on each run
	//@Test
	public void testCreateCampaignInEloqua()
			throws JsonProcessingException, URISyntaxException, ParseException, EloquaException {
		CampaignMaster campaignData = new CampaignMaster();
		String campaignName = "testCampaign03072020" + (int) (Math.random() * 100.0);
		campaignData.setCampaignName(campaignName);
		campaignData.setTrialId(1L);
		// set campaign schedule
		Schedule schedule = new Schedule();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		schedule.setStartDateTime(sdf.parse("2020-03-18 13:10:30"));
		schedule.setTimezone("EST");
		campaignData.setSchedule(schedule);
		// set campaign email template
		EmailTemplate template = new EmailTemplate();
		template.setEloquaEmailTempId(64);
		campaignData.setEmailTemplate(template);
		// set campaign reminders
		Reminder reminder1 = new Reminder();
		reminder1.setRemindOnDateTime(sdf.parse("2020-03-20 13:10:30"));
		reminder1.setReminderTimeZone("EST");
		reminder1.setNonOpener(true);

		Reminder reminder2 = new Reminder();
		reminder2.setRemindOnDateTime(sdf.parse("2020-03-22 14:10:30"));
		reminder2.setReminderTimeZone("EST");
		reminder2.setNonClicked(true);

		Reminder reminder3 = new Reminder();
		reminder3.setRemindOnDateTime(sdf.parse("2020-03-24 14:10:30"));
		reminder3.setReminderTimeZone("EST");
		reminder3.setNonOpener(true);
		reminder3.setNonClicked(true);

		List<Reminder> reminders = new ArrayList<>();
		reminders.add(reminder2); // add the later date first
		reminders.add(reminder1);
		reminders.add(reminder3);
		campaignData.setReminders(reminders);
		EloquaCampaignResponse response = campaignManager.createCampaignInEloqua(campaignData);

		Assert.assertNotNull(response.getId());
		Assert.assertEquals(campaignName, response.getName());
		Assert.assertTrue(response.getElements().size() >= 3);
		// CampaignManager.deleteCampaign(response.getId()); // do cleanup
	}

	// @Test
	public void testGetCampaignInEloqua() throws JsonProcessingException, URISyntaxException, EloquaException {
		CampaignManager campaignManager = new CampaignManager();
		EloquaCampaignResponse response = campaignManager.getCampaignInEloqua("15");
		Assert.assertNotNull(response);
		Assert.assertNotNull(response.getId());
		Assert.assertEquals("15", response.getId());
	}

	//@Test
	public void testDeactivateCampaignInEloqua() throws EloquaException {
		CampaignMaster campaignData = new CampaignMaster();
		campaignData.setCampaignId("991");
		campaignData.setSprinttCampaignId(1L); // some random number
		EloquaCampaignResponse resp = campaignManager.deactivateCampaign(campaignData);
		Assert.assertNotNull(resp);
		Assert.assertEquals(campaignData.getCampaignId(), resp.getId());
		Assert.assertEquals(resp.getCurrentStatus().toLowerCase(), SprinttCampaignStatus.DRAFT.name().toLowerCase());
	}

	// @Test
	public void testActivateADraftCampaignInEloqua()
			throws JsonProcessingException, URISyntaxException, ParseException, EloquaException {
		CampaignMaster campaignData = new CampaignMaster();
		campaignData.setCampaignId("82");
		campaignData.setSprinttCampaignId(1L); // some random number
		// ensure that campaign is draft
		campaignManager.deactivateCampaign(campaignData);
		EloquaCampaignResponse resp = campaignManager.activateCampaign(campaignData);
		Assert.assertNotNull(resp);
		Assert.assertEquals(campaignData.getCampaignId(), resp.getId());
		Assert.assertEquals(resp.getCurrentStatus().toLowerCase(), EloquaCampaignStatus.ACTIVE.getType().toLowerCase());

		campaignManager.deactivateCampaign(campaignData); // do cleanup
	}

	// @Test
	public void testScheduleADraftCampaignInEloqua()
			throws JsonProcessingException, URISyntaxException, ParseException, EloquaException {
		CampaignMaster campaignData = new CampaignMaster();
		campaignData.setCampaignId("82");
		campaignData.setSprinttCampaignId(1L); // some random number
		Schedule schedule = new Schedule();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		schedule.setStartDateTime(sdf.parse("2020-02-27 13:10:30"));
		campaignData.setSchedule(schedule);
		CampaignManager campaignManager = new CampaignManager();
		// ensure that campaign is draft
		campaignManager.deactivateCampaign(campaignData);
		EloquaCampaignResponse resp = campaignManager.scheduleCampaign(campaignData);
		Assert.assertNotNull(resp);
		Assert.assertEquals(campaignData.getCampaignId(), resp.getId());
		Assert.assertEquals(resp.getCurrentStatus().toLowerCase(),
				EloquaCampaignStatus.SCHEDULED.getType().toLowerCase());
		campaignManager.deactivateCampaign(campaignData); // do cleanup
	}

	//@Test
	public void testUpdateDraftCampaignInEloqua()
			throws JsonProcessingException, URISyntaxException, ParseException, EloquaException {
		CampaignMaster campaignData = new CampaignMaster();
		campaignData.setCampaignId("82");
		campaignData.setCampaignName("testCampaign03022020_updated");
		campaignData.setSprinttCampaignId(1L); // some random number
		campaignData.setCampaignStatusId(SprinttCampaignStatus.DRAFT.getValue());
		campaignData.setSegmentId(23l);
		Schedule schedule = new Schedule();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		schedule.setStartDateTime(sdf.parse("2020-02-27 13:10:30"));
		schedule.setEndDate(sdf.parse("2020-03-27 13:10:30"));
		campaignData.setSchedule(schedule);
		EmailTemplate template = new EmailTemplate();
		template.setEloquaEmailTempId(62);
		campaignData.setEmailTemplate(template);
		CampaignManager campaignManager = new CampaignManager();
		EloquaCampaignResponse resp = campaignManager.updateDraftCampaignInEloqua(campaignData);
		Assert.assertNotNull(resp);
		Assert.assertEquals(campaignData.getCampaignId(), resp.getId());
		Assert.assertEquals(resp.getCurrentStatus().toLowerCase(), EloquaCampaignStatus.DRAFT.getType().toLowerCase());
		Assert.assertEquals(resp.getStartAt(), String.valueOf(schedule.getStartDateTime().getTime() / 1000));
		Assert.assertEquals(resp.getEndAt(), String.valueOf(schedule.getEndDate().getTime() / 1000));

		Assert.assertTrue(resp.getElements().size() == 3);
		// verify email schedule
		Element waitElement = resp.getElements().get(1);
		Assert.assertEquals("CampaignWaitAction", waitElement.getType());
		Assert.assertEquals(String.valueOf(schedule.getStartDateTime().getTime() / 1000), waitElement.getWaitUntil());
		// verify email template
		Element emailElement = resp.getElements().get(2);
		Assert.assertEquals("CampaignEmail", emailElement.getType());
		Assert.assertEquals("62", emailElement.getEmailId());
	}

	/**
	 * scenario invalid - scheduled campaign has be to be moved to draft first and
	 * then updated, followed by scheduling. All three are atomic tasks.
	 */
	// @Test
	public void testUpdateScheduledCampaignInEloqua()
			throws JsonProcessingException, URISyntaxException, ParseException, EloquaException {
		CampaignMaster campaignData = new CampaignMaster();
		CampaignManager campaignManager = new CampaignManager();
		campaignData.setCampaignId("82");
		campaignData.setSprinttCampaignId(1L); // some random number
		Schedule schedule = new Schedule();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		schedule.setStartDateTime(sdf.parse("2020-02-27 13:10:30"));
		campaignData.setSchedule(schedule);

		EloquaCampaignResponse resp = campaignManager.scheduleCampaign(campaignData);
		campaignData.setCampaignName("testCampaign03022020_scheduled_updated");
		campaignData.setCampaignStatusId(SprinttCampaignStatus.SCHEDULED.getValue());
		campaignData.setSegmentId(23l);
		schedule.setEndDate(sdf.parse("2020-03-25 13:10:30"));
		EmailTemplate template = new EmailTemplate();
		template.setEloquaEmailTempId(62);
		campaignData.setEmailTemplate(template);

		campaignManager.updateDraftCampaignInEloqua(campaignData);
		resp = campaignManager.getCampaignInEloqua(campaignData.getCampaignId());
		Assert.assertNotNull(resp);
		Assert.assertEquals(campaignData.getCampaignId(), resp.getId());
		Assert.assertEquals(EloquaCampaignStatus.SCHEDULED.getType().toLowerCase(),
				resp.getCurrentStatus().toLowerCase());
		Assert.assertEquals(String.valueOf(schedule.getStartDateTime().getTime() / 1000), resp.getStartAt());
		Assert.assertEquals(String.valueOf(schedule.getEndDate().getTime() / 1000), resp.getEndAt());

		Assert.assertTrue(resp.getElements().size() == 3);
		// verify email schedule
		Element waitElement = resp.getElements().get(1);
		Assert.assertEquals("CampaignWaitAction", waitElement.getType());
		Assert.assertEquals(String.valueOf(schedule.getStartDateTime().getTime() / 1000), waitElement.getWaitUntil());
		// verify email template
		Element emailElement = resp.getElements().get(2);
		Assert.assertEquals("CampaignEmail", emailElement.getType());
		Assert.assertEquals("62", emailElement.getEmailId());

	}

}
