package com.questdiagnostics.campaignservice.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;

import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.request.model.ContactListRequest;
import com.questdiagnostics.campaignservice.response.model.ContactListResponse;

//@SpringBootTest
//@RunWith(SpringRunner.class)
public class ContactListManagerTest {

	//@Autowired
	private ContactListManager contactListManager;
	
	// Commented because below test run would create junk data in eloqua
	// @Test
	public void testCreateContactListInEloqua() throws EloquaException {
		ContactListRequest req = new ContactListRequest();
		req.setName("Test Contact List 13022020");
		List<String> contactIdsAdded = new ArrayList<>();
		contactIdsAdded.add("27");
		contactIdsAdded.add("30");
		ContactListManager contactListManager=new ContactListManager();
		req.setMembershipAdditions(contactIdsAdded);
		ContactListResponse response = contactListManager.createContactListInEloqua(req);
		Assert.assertNotNull(response.getId());
		Assert.assertEquals(2, response.getCount());
	}

	// @Test
	public void testGetContactListFromEloqua() throws EloquaException {
		ContactListManager contactListManager=new ContactListManager();
		ContactListResponse response = contactListManager.getContactListFromEloqua("80");
		Assert.assertEquals("80", response.getId());
		Assert.assertNotNull(response.getName());
		Assert.assertNotNull(response.getCount());
	}

	
	//@Test
	public void testDeleteContactList() throws EloquaException {
		ContactListRequest contactListRequest = new ContactListRequest();
		contactListRequest.setId("298");
		contactListRequest.setName("1_991_participants");
		List<String> contactIds = new ArrayList<>();
		contactIds.add("112");
		contactListRequest.setMembershipDeletions(contactIds);
		ContactListResponse contactListResponse = contactListManager.updateContactListInEloqua(contactListRequest);
		Assert.assertEquals("298", contactListResponse.getId());
	}
}
