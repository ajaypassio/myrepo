package com.questdiagnostics.campaignservice.manager;

import java.net.URISyntaxException;

import org.junit.Assert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.request.model.ContactRequest;
import com.questdiagnostics.campaignservice.response.model.ContactResponse;

public class ContactManagerTest {

	// Commented because below test run would create junk data in eloqua
	//@Test
	public void testCreateContactInEloqua() throws JsonProcessingException, URISyntaxException, EloquaException {
		ContactRequest req = new ContactRequest();
		ContactManager contactManager=new ContactManager();
		req.setEmailAddress("samarth.srivastava@hcl.com");
		req.setFirstName("Samarth");
		req.setLastName("Srivastava");
		try {
			ContactResponse response = contactManager.createContactInEloqua(req);
			Assert.assertNotNull(response.getId());
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println(e.getLocalizedMessage());
			System.out.println(e.getMessage());
		}

	}
	

	//@Test
	public void testGetContactFromEloqua() throws JsonProcessingException, URISyntaxException, EloquaException {
		ContactManager contactManager=new ContactManager();
		ContactResponse response = contactManager.getContactFromEloqua("27");
		Assert.assertEquals("27", response.getId());
	}

}
