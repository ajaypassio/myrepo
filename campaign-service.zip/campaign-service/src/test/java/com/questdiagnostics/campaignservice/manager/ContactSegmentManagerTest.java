package com.questdiagnostics.campaignservice.manager;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.questdiagnostics.campaignservice.exception.EloquaException;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequest;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElement;
import com.questdiagnostics.campaignservice.request.model.ContactSegmentRequestElementList;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentResponse;
import com.questdiagnostics.campaignservice.response.model.ContactSegmentUpdateResponse;

/**
 * Run the tests from local environment only because the current date/time may be different
 * @author samarth.srivastava
 *
 */
//@SpringBootTest
//@RunWith(value = SpringRunner.class)
public class ContactSegmentManagerTest {

	//@Autowired
	private ContactSegmentManager contactSegmentManager;
	// Commented as it creates junk data in eloqua
	//@Test
	public void testCreateSegmentInEloqua() throws JsonProcessingException, URISyntaxException, EloquaException {
		ContactSegmentManager contactSegmentManager=new ContactSegmentManager();
		ContactSegmentResponse response = contactSegmentManager
				.createContactSegmentInEloqua("test14022020_Segment" + (int) (Math.random() * 100.0));
		Assert.assertNotNull(response.getId());
	}

	// Commented as it may interfere with a junk/existing data
	//@Test
	public void testUpdateContaceSegmentInEloqua() throws JsonProcessingException, URISyntaxException, EloquaException {
		ContactSegmentRequestElementList list = new ContactSegmentRequestElementList();
		list.setId("87");
		list.setName("Test Contact List 13022020");
		ContactSegmentRequestElement element = new ContactSegmentRequestElement();
		element.setList(list);
		List<ContactSegmentRequestElement> elements = new ArrayList<>();
		elements.add(element);
		ContactSegmentRequest req = new ContactSegmentRequest();
		req.setId("80");
		req.setName("test23012020_Segment46");
		req.setElements(elements);
		ContactSegmentUpdateResponse response = contactSegmentManager
				.updateContactSegmentInEloqua(req);
		Assert.assertNotNull(response.getId());
		Assert.assertNotNull(response.getElements());
		Assert.assertEquals("80", response.getId());
		Assert.assertEquals("test23012020_Segment46", response.getName());
		Assert.assertEquals("true", response.getElements().get(0).getIsIncluded());
		Assert.assertEquals("87", response.getElements().get(0).getList().getId());
		Assert.assertEquals("2", response.getElements().get(0).getList().getCount());
	}
	
	//@Test
	public void testGetSegmentFromEloqua() throws JsonProcessingException, URISyntaxException, EloquaException {
		ContactSegmentResponse response = contactSegmentManager.getContactSegmentFromEloqua("1066");
		Assert.assertEquals("1066", response.getId());
	}

}
