package com.questdiagnostics.campaignservice.workflowengine;

import static com.questdiagnostics.campaignservice.workflowengine.template.State.BEGIN;
import static com.questdiagnostics.campaignservice.workflowengine.template.State.END;
import static com.questdiagnostics.campaignservice.workflowengine.template.State.INTERMEDIATE1;
import static com.questdiagnostics.campaignservice.workflowengine.template.State.INTERMEDIATE2;

import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.questdiagnostics.campaignservice.exception.FailedGuardException;
import com.questdiagnostics.campaignservice.exception.InvalidTransitionException;
import com.questdiagnostics.campaignservice.exception.WorkflowEngineException;
import com.questdiagnostics.campaignservice.workflowengine.template.BaseTransitionTemplate;
import com.questdiagnostics.campaignservice.workflowengine.template.DefaultTransitionTemplate;
import com.questdiagnostics.campaignservice.workflowengine.template.State;
import com.questdiagnostics.campaignservice.workflowengine.template.StateTransitionManager;
import com.questdiagnostics.campaignservice.workflowengine.template.TransitionalEntity;

public class StateTransitionManagerTest {
	
	private StateTransitionManager<TransitionalEntity> stateTransitionManager;
	
	private TransitionalEntity sourceEntity;
	
	private TransitionalEntity targetEntity;

	@Before
	public void setUp() throws Exception {
		sourceEntity = new TransitionalEntity("testEntity", 1L);
		sourceEntity.setCreatedDate(new Date());
		sourceEntity.setCurrentState(BEGIN);
		
		targetEntity = new TransitionalEntity("testEntity", 1L);
		targetEntity.setCreatedDate(sourceEntity.getCreatedDate());
		
		stateTransitionManager = new StateTransitionManager<>();
		
		@SuppressWarnings("unused")
		BaseTransitionTemplate transitionTemplate = DefaultTransitionTemplate.getInstance();
	}

	@After
	public void tearDown() throws Exception {
		sourceEntity = null;
		targetEntity = null;
		stateTransitionManager = null;
	}
	
	private void configureSourceEntity(State state) {
		sourceEntity.setCurrentState(state);
	}

	
	@Test
	public void testValidTransitionWithVerifiedGuardPassesForBeginToIntermediate1() throws WorkflowEngineException {
		configureSourceEntity(BEGIN);
		targetEntity.setCurrentState(INTERMEDIATE1);
		
		Assert.assertEquals(targetEntity, stateTransitionManager.execute(sourceEntity, INTERMEDIATE1));
	}
	
	@Test
	public void testValidTransitionWithVerifiedGuardPassesForBeginToIntermediate2() throws WorkflowEngineException {
		configureSourceEntity(BEGIN);
		targetEntity.setCurrentState(INTERMEDIATE2);
		
		Assert.assertEquals(targetEntity, stateTransitionManager.execute(sourceEntity, INTERMEDIATE2));
	}
	
	@Test
	public void testValidTransitionWithVerifiedGuardPassesForIntermediate1ToEnd() throws WorkflowEngineException {
		configureSourceEntity(INTERMEDIATE1);
		targetEntity.setCurrentState(END);
		
		Assert.assertEquals(targetEntity, stateTransitionManager.execute(sourceEntity, END));
	}
	
	@Test(expected = FailedGuardException.class)
	public void testValidTransitionWithFailedGuardFailsForIntermediate2ToEnd() throws WorkflowEngineException {
		configureSourceEntity(INTERMEDIATE2);		
		targetEntity = stateTransitionManager.execute(sourceEntity, END);
	}
	
	@Test(expected = InvalidTransitionException.class)
	public void testInvalidTransitionFailsForBeginToEnd() throws WorkflowEngineException {
		configureSourceEntity(BEGIN);		
		targetEntity = stateTransitionManager.execute(sourceEntity, END);
	}
	
	@Test(expected = InvalidTransitionException.class)
	public void testInvalidTransitionFailsForIntermediate1ToIntermediate2() throws WorkflowEngineException {
		configureSourceEntity(INTERMEDIATE1);		
		targetEntity = stateTransitionManager.execute(sourceEntity, INTERMEDIATE2);
	}

}
