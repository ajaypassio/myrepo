
# Candidate Service
Candidate serivce source code for microservice
CI using Jenkins and Azure Conatainer service via Kubernetes

# docker build command
docker build . -t candidateservice:test --build-arg BUILD_ENV=cert-qa

# per avigo, we need to do a dummy commit to force a new image.
# Testing new Branch