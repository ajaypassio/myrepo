package com.avigosolutions.candidateservice;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Schedules;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.avigosolutions.candidateservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.candidateservice.async.service.SavedSearchAsyncService;

@SpringBootApplication
@EnableAsync
@EnableScheduling
public class CandidateServiceApplication {
	
	
	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;
	
	@Autowired
	SavedSearchAsyncService savedSearchAsyncService;
	
	
	public static void main(String[] args) {
		SpringApplication.run(CandidateServiceApplication.class, args);
	}
	
	
	@Bean(name = "canThreadPoolTaskExecutor")
	@DependsOn("asyncConfigLoaderBean")
    public Executor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(asyncConfigLoaderBean.getCorePoolSize());
        executor.setMaxPoolSize(asyncConfigLoaderBean.getMaxPoolSize());
        executor.setKeepAliveSeconds(asyncConfigLoaderBean.getKeepAliveSeconds());
        executor.setThreadNamePrefix(asyncConfigLoaderBean.getTheadPrefixName());
        executor.setQueueCapacity(asyncConfigLoaderBean.getQueueCapacity());
        executor.initialize();
        return executor;
    }
	
	@Bean(name = "batchThreadPoolTaskExecutor")
	@DependsOn("asyncConfigLoaderBean")
    public Executor threadPoolTaskExecutorForBatch() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(asyncConfigLoaderBean.getCorePoolSize());
        executor.setMaxPoolSize(asyncConfigLoaderBean.getMaxPoolSize());
        executor.setKeepAliveSeconds(asyncConfigLoaderBean.getKeepAliveSeconds());
        executor.setThreadNamePrefix(asyncConfigLoaderBean.getBatchThreadPrefixName());
        executor.setQueueCapacity(asyncConfigLoaderBean.getQueueCapacity());
        executor.initialize();
        return executor;
    }
	
	
	@Schedules({ 
		@Scheduled(initialDelayString = "${sprintt.savedsearch.batch.delay.initial}",fixedDelayString = "${sprintt.savedsearch.batch.delay.fixed}")
		//,@Scheduled(cron = "${sprintt.savedsearch.batch.cron.expression}")
		})	
	@DependsOn("savedSearchAsyncService")
	public void startBatch() {
		savedSearchAsyncService.batchProcessSaveSearch();
	}
	
	
	
	
}
