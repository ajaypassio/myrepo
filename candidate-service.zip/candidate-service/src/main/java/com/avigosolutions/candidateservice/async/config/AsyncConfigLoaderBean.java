package com.avigosolutions.candidateservice.async.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class AsyncConfigLoaderBean {
	
	@Value("${sprintt.savedsearch.async.processing.threadpool.size.initial}")
	private Integer corePoolSize;
	
	@Value("${sprintt.savedsearch.async.processing.threadpool.size.max}")
	private Integer maxPoolSize;
	
	@Value("${sprintt.savedsearch.async.processing.thread.prefix}")
	private String theadPrefixName;
	
	@Value("${sprintt.savedsearch.async.processing.thread.batch.prefix}")
	private String batchThreadPrefixName;
	
	@Value("${sprintt.savedsearch.async.processing.thread.keepalive.seconds}")
	private Integer keepAliveSeconds;
	
	@Value("${sprintt.savedsearch.async.processing.thread.queue.capacity}")
	private Integer queueCapacity;
	
	@Value("${sprintt.savedsearch.save.retry.attempts}")
	private Integer saveSearchRetryAttempts;
	
	@Value("${sprintt.savedsearch.save.retry.policy}")
	private Integer saveSearchRetryPolicy;
	
	@Value("${sprintt.savedsearch.save.retry.interval.initial}")
	private Integer saveSearchRetryIntervalInitial;
	
	@Value("${sprintt.savedsearch.save.retry.interval.max}")
	private Integer saveSearchRetryIntervalMax;
	
	@Value("${sprintt.savedsearch.save.retry.interval.multiplier}")
	private Integer saveSearchRetryIntervalMultiplier;
	
	@Value("${sprintt.savedsearch.sendpatients.retry.attempts}")
	private Integer sendPatientsRetryAttempts;	
	
	@Value("${sprintt.savedsearch.sendpatients.retry.policy}")
	private Integer sendPatientsRetryPolicy;	
	
	@Value("${sprintt.savedsearch.sendpatients.retry.interval.initial}")
	private Integer sendPatientsRetryIntervalInitial;
	
	@Value("${sprintt.savedsearch.sendpatients.retry.interval.max}")
	private Integer sendPatientsRetryIntervalMax;
	
	@Value("${sprintt.savedsearch.sendpatients.retry.interval.multiplier}")
	private Integer sendPatientsRetryIntervalMultiplier;
	
	@Value("${sprintt.savedsearch.batch.retry.attempts}")
	private Integer batchRetryAttempts;	
	
	@Value("${sprintt.savedsearch.batch.retry.policy}")
	private Integer batchRetryPolicy;	
	
	@Value("${sprintt.savedsearch.batch.retry.interval.initial}")
	private Integer batchRetryIntervalInitial;
	
	@Value("${sprintt.savedsearch.batch.retry.interval.max}")
	private Integer batchRetryIntervalMax;
	
	@Value("${sprintt.savedsearch.batch.retry.interval.multiplier}")
	private Integer batchRetryIntervalMultiplier;

	@Value("${sprintt.savedsearch.batch.delay.random.min}")
	private Integer batchRandomDelayMin;
	
	@Value("${sprintt.savedsearch.batch.delay.random.max}")
	private Integer batchRandomDelayMax;
	
	@Value("${sprintt.savedsearch.batch.delay.random.step}")
	private Integer batchRandomDelayStep;
	
	@Value("${sprintt.savedsearch.batch.reset.time.interval}")
	private Long batchResetInterval;
	
	
	public Integer getCorePoolSize() {
		return corePoolSize;
	}

	public Integer getMaxPoolSize() {
		return maxPoolSize;
	}

	public String getTheadPrefixName() {
		return theadPrefixName;
	}

	public String getBatchThreadPrefixName() {
		return batchThreadPrefixName;
	}

	public Integer getKeepAliveSeconds() {
		return keepAliveSeconds;
	}

	public Integer getQueueCapacity() {
		return queueCapacity;
	}

	public Integer getSaveSearchRetryAttempts() {
		return saveSearchRetryAttempts;
	}

	public Integer getSaveSearchRetryPolicy() {
		return saveSearchRetryPolicy;
	}

	public Integer getSaveSearchRetryIntervalInitial() {
		return saveSearchRetryIntervalInitial;
	}

	public Integer getSaveSearchRetryIntervalMax() {
		return saveSearchRetryIntervalMax;
	}

	public Integer getSaveSearchRetryIntervalMultiplier() {
		return saveSearchRetryIntervalMultiplier;
	}

	public Integer getSendPatientsRetryAttempts() {
		return sendPatientsRetryAttempts;
	}

	public Integer getSendPatientsRetryPolicy() {
		return sendPatientsRetryPolicy;
	}

	public Integer getSendPatientsRetryIntervalInitial() {
		return sendPatientsRetryIntervalInitial;
	}

	public Integer getSendPatientsRetryIntervalMax() {
		return sendPatientsRetryIntervalMax;
	}

	public Integer getSendPatientsRetryIntervalMultiplier() {
		return sendPatientsRetryIntervalMultiplier;
	}

	public Integer getBatchRetryAttempts() {
		return batchRetryAttempts;
	}

	public Integer getBatchRetryPolicy() {
		return batchRetryPolicy;
	}

	public Integer getBatchRetryIntervalInitial() {
		return batchRetryIntervalInitial;
	}

	public Integer getBatchRetryIntervalMax() {
		return batchRetryIntervalMax;
	}

	public Integer getBatchRetryIntervalMultiplier() {
		return batchRetryIntervalMultiplier;
	}

	public Integer getBatchRandomDelayMin() {
		return batchRandomDelayMin;
	}
	
	public Integer getBatchRandomDelayMax() {
		return batchRandomDelayMax;
	}
	
	public Integer getBatchRandomDelayStep() {
		return batchRandomDelayStep;
	}

	public Long getBatchResetInterval() {
		return batchResetInterval;
	}
	
	

}
