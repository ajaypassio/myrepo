package com.avigosolutions.candidateservice.async.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class ThreadPoolExecutorConfig {

	  	@Bean
	    public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
	        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	        executor.setCorePoolSize(6);
	        executor.setMaxPoolSize(6);
	        executor.setThreadNamePrefix("task_executor");
	        executor.initialize();
	        return executor;
	    }
}
