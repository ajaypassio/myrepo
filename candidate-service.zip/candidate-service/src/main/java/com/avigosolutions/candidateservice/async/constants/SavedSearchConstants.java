package com.avigosolutions.candidateservice.async.constants;

public class SavedSearchConstants {
	
	/*
	Initiated = Before sending the request to mongodb, 
	RetryInprogress - Failed but retry is going on, 
	Failed - If mongodb call failed even after the retries are exhausted , 
	Saved - search is saved in mongodb
	PatientPushInprogress - sending the patients to participant-service
	PatientPushRetryInprogress - If sending the participants got failed, the LastBatchId indicates for which  batch we are retrying
	PatientPushPartialFailed - If any of the batch failed, we will update the job with this status.
	PatientPushFailed - All batches failed
	Completed - Once all the participants are sent successfully to participant-service
	*/
	public static enum status{
		INITIATED(0),
		RETRY_INPROGRESS(1),
		FAILED(2),
		SAVED(3),
		PATIENT_PUSH_INPROGRESS(4),
		PATIENT_PUSH_RETRY_INPROGRESS(5),
		PATIENT_PUSH_PARTIAL_FAILED(6),
		PATIENT_PUSH_FAILED(7),
		COMPLETED(8);
		
		private int numVal;

		status(int numVal) {
	        this.numVal = numVal;
	    }

	    public int getNumVal() {
	        return numVal;
	    }
	};
	
	public static enum USER_STATUS{
		STARTED,
		INPROGRESS,
		FAILED,
		SAVED;
	};
	
	
	
	public final static Boolean BATCH_IN_PROCESS_TRUE=true;
	public final static Boolean BATCH_IN_PROCESS_FALSE=false;

}
