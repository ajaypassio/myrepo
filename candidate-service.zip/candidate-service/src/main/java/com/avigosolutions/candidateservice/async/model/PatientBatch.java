package com.avigosolutions.candidateservice.async.model;

public class PatientBatch {
	
	private Integer batchId;
	private Integer batchPatientCount;
	private boolean isBatchCompleted;
	
	
	public Integer getBatchId() {
		return batchId;
	}
	public void setBatchId(Integer batchId) {
		this.batchId = batchId;
	}
	public PatientBatch withBatchId(Integer batchId) {
		this.batchId = batchId;
		return this;
		
	}
	public Integer getBatchPatientCount() {
		return batchPatientCount;
	}
	public void setBatchPatientCount(Integer batchPatientCount) {
		this.batchPatientCount = batchPatientCount;
	}
	public PatientBatch withBatchPatientCount(Integer batchPatientCount) {
		this.batchPatientCount = batchPatientCount;
		return this;		
	}
	public boolean isBatchCompleted() {
		return isBatchCompleted;
	}
	public void setBatchCompleted(boolean isBatchCompleted) {
		this.isBatchCompleted = isBatchCompleted;
	}
	public PatientBatch withBatchCompleted(boolean isBatchCompleted) {
		this.isBatchCompleted = isBatchCompleted;
		return this;
	}
	
	
	@Override
	public String toString() {
		return "PatientBatch [batchId=" + batchId + ", batchPatientCount=" + batchPatientCount + ", isBatchCompleted="
				+ isBatchCompleted + "]";
	}
	
	
	
	

}
