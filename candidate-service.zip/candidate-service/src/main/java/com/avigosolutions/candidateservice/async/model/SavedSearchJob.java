package com.avigosolutions.candidateservice.async.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;

public class SavedSearchJob {
	
	@Id
	private String id;
	//@Column(name = "UserId", nullable = true)
	private String userId;
	//@Column(name = "JobStatus", nullable = true)
	private String jobStatus;
	

	//@Column(name = "SearchName", nullable = true)
	private String searchName;
	//@Column(name = "SearchCriteria", nullable = true)
	private String searchCriteria;
	//@Column(name = "TrialId", nullable = true)
	private Long trialId;
	//@Column(name = "LastBatchId", nullable = true)
	private Long lastBatchId;
	//@Column(name = "LastPatientId", nullable = true)
	private Long lastPatientId;	
	
	/*@CreatedDate
    @Temporal(TIMESTAMP)
    @Column(updatable=false)*/
    protected Date createdOn;

    /*@LastModifiedDate
    @Temporal(TIMESTAMP)*/
    protected Date updatedOn;
    
    private List<PatientBatch> patientBatchList;
    private boolean inProcess;
    private List<String> previousJobStatusList;
    private Integer totalBatchCount=0;
    
    
	public SavedSearchJob(String userId, String jobStatus, String searchName, String searchCriteria,
			Long trialId, Long lastBatchId,Long lastPatientId, Date createdOn, Date updatedOn) {
		super();
		//this.id = id;
		this.userId = userId;
		this.jobStatus = jobStatus;
		this.searchName = searchName;
		this.searchCriteria = searchCriteria;
		this.trialId = trialId;
		this.lastBatchId = lastBatchId;
		this.lastPatientId = lastPatientId;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
	}
	
	
	public String getId() {
		return id;
	}

	public void setId(String userId) {
		this.id = userId;
	}
	
	public SavedSearchJob withId(String id) {
		this.id = id;
		return this;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public SavedSearchJob withUserId(String userId) {
		this.userId = userId;
		return this;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	public SavedSearchJob withJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
		return this;
	}

	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	
	public SavedSearchJob withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public String getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(String searchCriteria) {
		this.searchCriteria = searchCriteria;
	}
	
	public SavedSearchJob withSearchCriteria(String searchCriteria) {
		this.searchCriteria = searchCriteria;
		return this;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	
	public SavedSearchJob withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	public Long getLastBatchId() {
		return lastBatchId;
	}

	public void setLastBatchId(Long lastBatchId) {
		this.lastBatchId = lastBatchId;
	}
	
	public SavedSearchJob withLastBatchId(Long lastBatchId) {
		this.lastBatchId = lastBatchId;
		return this;
	}

	public Long getLastPatientId() {
		return lastPatientId;
	}

	public void setLastPatientId(Long lastPatientId) {
		this.lastPatientId = lastPatientId;
	}
	
	public SavedSearchJob withLastPatientId(Long lastPatientId) {
		this.lastPatientId = lastPatientId;
		return this;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
     
	
	public SavedSearchJob withPatientBatchList(List<PatientBatch> patientBatch) {
		this.patientBatchList = patientBatch;
		return this;
	}


	public List<PatientBatch> getPatientBatchList() {
		return patientBatchList;
	}


	public void setPatientBatchList(List<PatientBatch> patientBatchList) {
		this.patientBatchList = patientBatchList;
	}


	public boolean isInProcess() {
		return inProcess;
	}


	public void setInProcess(boolean inProcess) {
		this.inProcess = inProcess;
	}
	
	public SavedSearchJob withInProcess(boolean inProcess) {
		this.inProcess = inProcess;
		return this;
	}


	public List<String> getPreviousJobStatusList() {
		return previousJobStatusList;
	}


	public void setPreviousJobStatusList(List<String> previousJobStatusList) {
		this.previousJobStatusList = previousJobStatusList;
	}
	
	public SavedSearchJob withPreviousJobStatusList(List<String> previousJobStatusList) {
		this.previousJobStatusList = previousJobStatusList;
		return this;
	}

	public Integer getTotalBatchCount() {
		return totalBatchCount;
	}


	public void setTotalBatchCount(Integer totalBatchCount) {
		this.totalBatchCount = totalBatchCount;
	}
	
	public SavedSearchJob withTotalBatchCount(Integer totalBatchCount) {
		this.totalBatchCount = totalBatchCount;
		return this;
	}

	@Override
	public String toString() {
		return "SavedSearchJob [id=" + id + ", userId=" + userId + ", jobStatus=" + jobStatus + ", searchName="
				+ searchName + ", trialId=" + trialId + ", lastBatchId="
				+ lastBatchId + ", totalBatchCount=" + totalBatchCount + ", lastPatientId=" + lastPatientId + ", createdOn="
				+ createdOn + ", updatedOn=" + updatedOn + ", patientBatchList=" + patientBatchList + ", inProcess="
				+ inProcess + "]";
	}
}
