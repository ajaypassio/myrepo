package com.avigosolutions.candidateservice.async.model;

public class SavedSearchJobResponseModel {

	private String userId;

	private String jobStatus;

	private String searchName;

	private Long trialId;	
    
	public SavedSearchJobResponseModel(String userId, String jobStatus, String searchName,Long trialId) {
		super();
		this.userId = userId;
		this.jobStatus = jobStatus;
		this.searchName = searchName;
		this.trialId = trialId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public SavedSearchJobResponseModel withUserId(String userId) {
		this.userId = userId;
		return this;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	public SavedSearchJobResponseModel withJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
		return this;
	}

	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}
	
	public SavedSearchJobResponseModel withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	
	public SavedSearchJobResponseModel withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}
	
	@Override
	public String toString() {
		return "SavedSearchJob [userId=" + userId + ", jobStatus=" + jobStatus + ", searchName="
				+ searchName + ", trialId=" + trialId + ", lastBatchId="
				+ "]";
	}
}
