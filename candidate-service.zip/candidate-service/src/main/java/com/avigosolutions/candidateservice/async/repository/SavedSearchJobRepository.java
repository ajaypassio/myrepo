package com.avigosolutions.candidateservice.async.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.avigosolutions.candidateservice.async.model.SavedSearchJob;

public interface SavedSearchJobRepository extends MongoRepository<SavedSearchJob, String>{
	public SavedSearchJob findBySearchName(String searchName);
	public SavedSearchJob findBySearchNameAndTrialId(String searchName, long trialId);
	public List<SavedSearchJob> findByTrialId(Long trialId);
	public List<SavedSearchJob> findByInProcessFalseAndJobStatusNotLike(String terminalStatus);
	public List<SavedSearchJob> findByInProcessTrueAndJobStatusNotLike(String terminalStatus);
}