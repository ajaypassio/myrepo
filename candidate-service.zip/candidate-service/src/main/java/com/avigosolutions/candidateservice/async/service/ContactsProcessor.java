package com.avigosolutions.candidateservice.async.service;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avigosolutions.candidateservice.model.Participant;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

public class ContactsProcessor implements Callable<String>{

	private String queueName;
	private List<Participant> contactsList;
	private CloudBlobContainer container;
	private CloudQueueClient queueClient;
	private String generatedUuid;
	private byte[] bytes;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public ContactsProcessor(String queueName, List<Participant> contactsList,  
								CloudBlobContainer container, CloudQueueClient queueClient, 
								String generatedUuid, byte[] bytes) {
		this.queueName= queueName;
		this.contactsList = contactsList;
		this.container = container;
		this.queueClient = queueClient;
		this.generatedUuid = generatedUuid;
		this.bytes = bytes;
	}
	
	@Override
	public String call() throws Exception {
		process();
		return "SUCCESS";
	}
	
	private void process()  throws Exception {
		logger.info("sendContactsThroughBlobStorage()  -----Start for ---"+queueName);
		
		CloudQueue queue =null;
		
		queue = queueClient.getQueueReference(queueName);
		queue.createIfNotExists();
			
		String pathWithoutContainerPS = queueName+"/"+generatedUuid +".json";
		CloudBlockBlob blob = container.getBlockBlobReference(pathWithoutContainerPS);
		logger.info("Queue Path without containers for  :"+queueName +"     "+pathWithoutContainerPS);

		HashMap<String, String> metaData = new HashMap<String,String>();
		metaData.put("TargetName", queueName);
		if(contactsList!=null) {
			metaData.put("MessageCount", String.valueOf(contactsList.size()));
		}
		metaData.put("Serializer", "JSON");
		blob.setMetadata(metaData);
		
		logger.info("Queue MetaData  "+queueName +"     "+metaData.toString());
		blob.uploadFromByteArray(bytes, 0, bytes.length);
		queue.addMessage(new CloudQueueMessage(pathWithoutContainerPS));
		
		logger.info("Blob/Queue sent with path for ----- "+queueName);
	}

}
