package com.avigosolutions.candidateservice.async.service;

import java.util.List;

import com.avigosolutions.candidateservice.model.Participant;

public interface ContactsTransferService {
	
	public void sendContactsThroughBlobStorage(List<Participant> contactsList, int batchId) throws Exception;

}
