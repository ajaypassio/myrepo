package com.avigosolutions.candidateservice.async.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.avigosolutions.candidateservice.model.Participant;
import com.google.gson.Gson;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.queue.CloudQueueClient;

@Service
public class ContactsTransferServiceImpl implements ContactsTransferService{

	
	@Value("${sprintt.candidate.service.blob.storage.connection.string}")
	String storageConnectionString;
	
	@Value("${sprintt.candidate.service.blob.storage.containerName}")
	String containerName;
	
	@Value("${sprintt.candidate.service.blob.storage.quenename.ps}")
	String queueNamePS;
	
	@Value("${sprintt.candidate.service.blob.storage.quenename.zyprr}")
	String queueNameZyprr;
	
	@Autowired
	ThreadPoolTaskExecutor threadPoolExecutor;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	

	@Override
	public void sendContactsThroughBlobStorage(List<Participant> contactsList, int batchId) throws Exception {
		
		logger.info("sendContactsThroughBlobStorage()  ----- Start batchId ---"+batchId);
		CloudStorageAccount storageAccount;
		
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;
		CloudQueueClient queueClient = null;
		
		String generatedUuid = UUID.randomUUID().toString();
		
		storageAccount = CloudStorageAccount.parse(storageConnectionString);
		logger.info("storage connection string = {}", storageConnectionString);
		blobClient = storageAccount.createCloudBlobClient();
		container = blobClient.getContainerReference(containerName);
		logger.info("container name: {}", containerName);
		container.createIfNotExists();

		queueClient = storageAccount.createCloudQueueClient();
		
		Gson gson = new Gson();
		String jsonContactsList = gson.toJson(contactsList);
		byte[] bytes = jsonContactsList.getBytes();
		
		List<String> queues = new ArrayList<>();
		queues.add(queueNamePS);
		queues.add(queueNameZyprr);
		for (String queueName : queues) {
			ContactsProcessor contactsProcessor = new ContactsProcessor(queueName, contactsList,
					container,queueClient,generatedUuid,bytes);
			Future<String> future = threadPoolExecutor.submit(contactsProcessor);
		}
		
		logger.info("sendContactsThroughBlobStorage() End -----  batchId ---"+batchId);
		
	}
	
	
	
	
}