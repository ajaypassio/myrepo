package com.avigosolutions.candidateservice.async.service;

import java.util.concurrent.Future;
import com.avigosolutions.candidateservice.model.SavedSearch;

public interface SavedSearchAsyncService {
	
	public Future<SavedSearch> saveSearch(SavedSearch searchToBeSaved,String userId);
	public void batchProcessSaveSearch();

}
