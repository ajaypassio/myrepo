package com.avigosolutions.candidateservice.async.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpHeaders;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.avigosolutions.candidateservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.candidateservice.async.config.RetryPolicyClassifier;
import com.avigosolutions.candidateservice.async.constants.SavedSearchConstants;
import com.avigosolutions.candidateservice.async.model.PatientBatch;
import com.avigosolutions.candidateservice.async.model.SavedSearchJob;
import com.avigosolutions.candidateservice.model.GeoPatient;
import com.avigosolutions.candidateservice.model.GeoPatientId;
import com.avigosolutions.candidateservice.model.MongoPageRequest;
import com.avigosolutions.candidateservice.model.Participant;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.model.SavedSearch;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo.PipelineQueryBuilderIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.parser.JSONContractParserIE;
import com.avigosolutions.candidateservice.repository.SavedSearchRepository;
import com.avigosolutions.candidateservice.service.PatientService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class SavedSearchAsyncServiceImpl implements SavedSearchAsyncService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	// @Value("${mongoSavedSearchCollectionName}")
	// private String mongoSavedSearchCollectionName;

	@Value("${sprintt.participant.service.url}")
	String participantServiceURL;

	@Value("${sprintt.participant.service.categoryurl}")
	String participantServiceCatURL;

	@Autowired
	PatientService patientService;

	@Autowired
	private SavedSearchRepository savedSearchRepository;

	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;

	@Autowired
	SavedSearchRetryListener savedSearchRetryListener;

	@Autowired
	SendPatientsRetryListener sendPatientsRetryListener;

	@Autowired
	SavedSearchJobLog savedSearchJobLog;

	@Autowired
	ContactsTransferService contactsTransferService;

	@Autowired
	private JSONContractParserIE jsonContractParser;

	@Autowired
	private PipelineQueryBuilderIE<Patient> queryBuilder;

	/*
	 * @Value("${mongoSearchCollectionName}") private String
	 * mongoSearchCollectionName;
	 */

	private MongoOperations mongoOperations;

	@Value("${mongoSavedSearchCollectionName}")
	private String mongoSavedSearchCollectionName;

	@Value("${sprintt.uuid}")
	String springUuid;

	@Value("${sprintt.savedsearch.pagesize}")
	private int pageSize;

	@Autowired
	public void setMongoOperations(MongoOperations mongoOperations) {
		this.mongoOperations = mongoOperations;
	}

	@Async("canThreadPoolTaskExecutor")
	public Future<SavedSearch> saveSearch(SavedSearch searchToBeSaved, String userId) {

		logger.info(">>>Start Async Processing of SavedSearch[Name=" + searchToBeSaved.getSearchName() + ",TrialId="
				+ searchToBeSaved.getTrialId() + "] with Thread id: " + Thread.currentThread().getId());
		SavedSearch ss = searchToBeSaved;
		try {
			Date d = new Date();
			this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.INITIATED.name(),
					searchToBeSaved.getSearchName(), searchToBeSaved.getTrialCriteriaStr(),
					Long.valueOf(searchToBeSaved.getTrialId()), 0L, 0L, d, d)
							.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE));
			searchToBeSaved.withGeoPatientId(new GeoPatientId());
			searchToBeSaved.setCreateDate(d);
			searchToBeSaved.setUpdateDate(d);

			ss = saveSearchToMongo(searchToBeSaved, userId, false);

			if (null == ss || null == ss.getGeoPatientId() || null == ss.getGeoPatientId().getPatientIds()
					|| ss.getGeoPatientId().getPatientIds().size() <= 0) {
				this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.FAILED.name(),
						searchToBeSaved.getSearchName(), searchToBeSaved.getTrialCriteriaStr(),
						Long.valueOf(searchToBeSaved.getTrialId()), 0L, 0L, d, d)
								.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_FALSE));
				return new AsyncResult<>(null);
			}

			sendPatients(ss, userId, false);

			logger.info(
					"<<<Completed Async Processing of SavedSearch[Name=" + searchToBeSaved.getSearchName() + ",TrialId="
							+ searchToBeSaved.getTrialId() + "] with Thread id: " + Thread.currentThread().getId());
		} catch (Exception e) {
			logger.error("Error occurred while executing the async task", e);
		}
		return new AsyncResult<>(ss);
	}

	@Async("batchThreadPoolTaskExecutor")
	public void batchProcessSaveSearch() {
		logger.info(">>>Start   " + Thread.currentThread().getId());
		TimerTask batchTask = new TimerTask() {

			public void run() {
				logger.info(">>> Starting the batch processing");
				batchProcess();
			}
		};
		Timer timer = new Timer("BatchTimer");
		long delay = getRandomDelay(asyncConfigLoaderBean.getBatchRandomDelayMin(),
				asyncConfigLoaderBean.getBatchRandomDelayMax(), asyncConfigLoaderBean.getBatchRandomDelayStep());
		logger.info(">>> A delay of " + delay + " millis is injected");
		timer.schedule(batchTask, delay);

	}

	private Integer getRandomDelay(Integer min, Integer max, Integer step) {
		int range = (int) ((max - min) / step);
		Integer scaled = new Random().nextInt(range) * step;
		Integer shifted = scaled + min;
		return shifted;
	}

	private void batchProcess() {
		resetProcessStatusForIdleJobs();
		List<SavedSearchJob> jobList = this.savedSearchJobLog.getJobsNotInProcessingAndNotInCompleted();

		if (null != jobList && jobList.size() > 0) {
			jobList.forEach(fjob -> {
				logger.info("BATCH PROCESSING: " + fjob.toString());
				SavedSearch ss = new SavedSearch().withTrialCriteriaStr(fjob.getSearchCriteria())
						.withTrialId(fjob.getTrialId()).withSearchName(fjob.getSearchName());
				try {
					Date d = new Date();
					this.savedSearchJobLog.addJobLog(fjob.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE));

					ss.setCreateDate(d);
					ss.setUpdateDate(d);

					boolean abort = false;
					// to try for jobs which are in SAVED state or state before it
					if (SavedSearchConstants.status.valueOf(fjob.getJobStatus()).getNumVal() <= 2) {
						ss.withGeoPatientId(new GeoPatientId());
						ss = saveSearchToMongo(ss, fjob.getUserId(), true);
						try {
							logger.info("Number of Patients==>" + ss.getGeoPatientId().getPatientIds().size());
							if (null == ss || null == ss.getGeoPatientId()
									|| null == ss.getGeoPatientId().getPatientIds()
									|| ss.getGeoPatientId().getPatientIds().size() <= 0) {
								this.savedSearchJobLog.addJobLog(new SavedSearchJob(fjob.getUserId(),
										SavedSearchConstants.status.FAILED.name(), ss.getSearchName(),
										ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()), 0L, 0L, d, d)
												.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_FALSE));
								abort = true;
							}
						} catch (Exception ex) {
							logger.error("Error occurred while executing the async batch task", ex);
						}
					}

					// to try for jobs which are in PATIENT_PUSH_FAILED state or state before it
					if (!abort && SavedSearchConstants.status.valueOf(fjob.getJobStatus()).getNumVal() <= 7) {
						ss = this.savedSearchRepository.findBySearchNameAndTrialId(fjob.getSearchName(),
								fjob.getTrialId());
						sendPatients(ss, fjob.getUserId(), true);
					}

					logger.info(
							"<<<Completed Async Batch Processing with Thread id: " + Thread.currentThread().getId());
				} catch (Exception e) {
					logger.error("Error occurred while executing the async batch task", e);
				}

			});
		}

	}

	private SavedSearch saveSearchToMongo(SavedSearch searchToBeSaved, String userId, Boolean batchProcessing) {
		logger.info("<<< Save Search Saved into DB: " + new Date());

		RetryTemplate retrySaveSearchTemplate = getRetrySaveSearchTemplate(batchProcessing);

		return retrySaveSearchTemplate.execute(context -> {
			context.setAttribute("searchToBeSaved", searchToBeSaved);
			context.setAttribute("userId", userId);
			SavedSearch ss = searchToBeSaved;
			// Changing the condition to add a new record everytime when save is clicked
			ss = this.savedSearchRepository.save(searchToBeSaved);

			logger.info(">>> Save Search Saved into DB: " + new Date());

			try {
				logger.info(">>> Form Patient Query for Search: " + new Date());

				String patientCollectionName = patientService.getPatientsCollectionName(searchToBeSaved.getTrialId());
				Map<String, String> criteriaMap = patientService.getCriterias(searchToBeSaved.getTrialCriteriaStr());
				String complete = patientService.getCompleteJSON(searchToBeSaved.getTrialCriteriaStr());

				/*
				 * BasicQuery basicQuery = new BasicQuery(criteriaMap.get(complete));
				 * basicQuery.fields().include("patient_id");
				 * basicQuery.fields().exclude("_id");
				 * 
				 * logger.info("Basic Query Before executing  >>>>>>>>>>>>" + basicQuery);
				 * 
				 * List<Patient> patientList = mongoOperations.find(basicQuery, Patient.class,
				 * patientCollectionName);
				 */
				ObjectMapper mapper = new ObjectMapper();
				List<Patient> inclusionPatients = null;
				List<Patient> exclusionPatients = null;
				SearchCriteriaGroupContainerIE inclusionCriteria = null;
				SearchCriteriaGroupContainerIE exclusionCriteria = null;
				inclusionCriteria = jsonContractParser.parseJSONInput(
						mapper.readTree(criteriaMap.get(complete)).get("IC"), ContainerType.INCLUSION_CRITERIA,false);
				exclusionCriteria = jsonContractParser.parseJSONInput(
						mapper.readTree(criteriaMap.get(complete)).get("EC"), ContainerType.EXCLUSION_CRITERIA,false);

				inclusionPatients = (inclusionCriteria == null || inclusionCriteria.isEmpty()) ? null
						: new ArrayList<>(queryBuilder.build(inclusionCriteria, null, patientCollectionName));
				if (!CollectionUtils.isEmpty(inclusionPatients)) {
					exclusionPatients = (exclusionCriteria == null || exclusionCriteria.isEmpty()) ? null
							: queryBuilder.build(exclusionCriteria, null, patientCollectionName);
					if (!CollectionUtils.isEmpty(exclusionPatients)) {
						inclusionPatients.removeAll(exclusionPatients);
					}
				}

				// Have to do save PatIds to Savedsearch after getting results.
				if (inclusionPatients != null && inclusionPatients.size() != 0) {
					List<String> patientIds = inclusionPatients.stream().map(Patient::getPatientId)
							.collect(Collectors.toList());
					GeoPatientId geoPatId = new GeoPatientId();
					geoPatId.withPatientIds(patientIds);
					ss.withGeoPatientId(geoPatId);
					logger.info("<<<<<<<<<<<<<<<<<<Basic Query After Size" + patientIds.size());
				}

			} catch (Exception e) {
				logger.error("Error populatePatients, Unable to push patientIDs", e);
				this.savedSearchRepository.delete(ss);
				this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.FAILED.name(),
						searchToBeSaved.getSearchName(), searchToBeSaved.getTrialCriteriaStr(),
						Long.valueOf(searchToBeSaved.getTrialId()), 0L, 0L, new Date(), new Date())
								.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_FALSE));
				return null;
			}

			ss = this.savedSearchRepository.save(ss);
			logger.info(">>>>SavedSearch Object saved in DB" + ss);
			ss = savedSearchRepository.findOne(searchToBeSaved.getId());
			logger.info(">>> Find saved search from DB: " + new Date());

			if (null != ss.getGeoPatientId() && null != ss.getGeoPatientId().getPatientIds()
					&& ss.getGeoPatientId().getPatientIds().size() > 0) {
				this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.SAVED.name(),
						searchToBeSaved.getSearchName(), searchToBeSaved.getTrialCriteriaStr(),
						Long.valueOf(searchToBeSaved.getTrialId()), 0L, 0L, new Date(), new Date())
								.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE));
			} else {
				this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.FAILED.name(),
						searchToBeSaved.getSearchName(), searchToBeSaved.getTrialCriteriaStr(),
						Long.valueOf(searchToBeSaved.getTrialId()), 0L, 0L, new Date(), new Date())
								.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_FALSE));
			}
			return ss;

		}, recover -> {
			this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.FAILED.name(),
					searchToBeSaved.getSearchName(), searchToBeSaved.getTrialCriteriaStr(),
					Long.valueOf(searchToBeSaved.getTrialId()), 0L, 0L, new Date(), new Date())
							.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_FALSE));
			return null;
		});
		// return searchToBeSaved;

	}

	private boolean isSavedSearchExists(SavedSearch ss) {
		SavedSearch sse = this.savedSearchRepository.findBySearchNameAndTrialId(ss.getSearchName(), ss.getTrialId());
		if (null != sse) {
			return true;
		}
		return false;
	}

	private boolean sendPatients(SavedSearch ss, String userId, boolean batchProcessing) {

		int start = 0;
		int total = ss.getGeoPatientId().getPatientIds().size();
		List<PatientBatch> batchList = new ArrayList<>();
		Long lastProcessedPatientId = 0L;
		boolean anyBatchFailed = false;
		boolean anyBatchPassed = false;

		RetryTemplate retrySendPatientsTemplate = getRetrySendPatientsTemplate(batchProcessing);

		do {
			logger.info("Start >>>" + start);
			logger.info(" Loop " + start + " >>> " + new Date());
			ss.withMongoPageRequest(new MongoPageRequest().withPageNumber(start).withPageSize(pageSize));
			int batchLastTried = start;
			List<PatientBatch> jobBatchList = this.savedSearchJobLog
					.getJobBySearchNameAndTrialId(ss.getSearchName(), ss.getTrialId()).getPatientBatchList();
			if ((batchProcessing && (null == jobBatchList || jobBatchList.size() <= 0))
					|| (batchProcessing && null != jobBatchList && jobBatchList.size() > 0
							&& jobBatchList.stream()
									.filter(b -> (b.getBatchId().intValue() == batchLastTried && !b.isBatchCompleted())
											|| b.getBatchId().intValue() != batchLastTried)
									.count() > 0)
					|| !batchProcessing) {

				String correlationId = UUID.randomUUID().toString();
				try {
					retrySendPatientsTemplate.execute(context -> {
						context.setAttribute("searchToBeSaved", ss);
						context.setAttribute("userId", userId);
						context.setAttribute("batch", batchLastTried);
						populatePatients(ss);
						return true;
					});

					logger.info(">>>Initiated participant service call for Batch:" + start);

					addBatchToList(new PatientBatch().withBatchId(start).withBatchCompleted(false)
							.withBatchPatientCount(ss.getGeoPatient().getFeatures().size()), batchList);
					this.savedSearchJobLog.addJobLog(
							new SavedSearchJob(userId, SavedSearchConstants.status.PATIENT_PUSH_INPROGRESS.name(),
									ss.getSearchName(), ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()),
									Long.valueOf(batchLastTried), lastProcessedPatientId, new Date(), new Date())
											.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE)
											.withPatientBatchList(batchList).withTotalBatchCount(getBatchCount(
													ss.getGeoPatientId().getPatientIds().size(), pageSize)));

					retrySendPatientsTemplate.execute(context -> {
						context.setAttribute("searchToBeSaved", ss);
						context.setAttribute("userId", userId);
						context.setAttribute("batch", batchLastTried);
						return sendPatientsToParticipantService(ss, correlationId, batchLastTried);
					});
					logger.info("<<<Completed participant service call for Batch:" + start);

					if (null != ss.getGeoPatient() && null != ss.getGeoPatient().getFeatures()
							&& ss.getGeoPatient().getFeatures().size() > 0) {
						lastProcessedPatientId = Long.valueOf(ss.getGeoPatient().getFeatures()
								.get(ss.getGeoPatient().getFeatures().size() - 1).getPatientId());
						addBatchToList(new PatientBatch().withBatchId(start).withBatchCompleted(true)
								.withBatchPatientCount(ss.getGeoPatient().getFeatures().size()), batchList);
						this.savedSearchJobLog.addJobLog(
								new SavedSearchJob(userId, SavedSearchConstants.status.PATIENT_PUSH_INPROGRESS.name(),
										ss.getSearchName(), ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()),
										Long.valueOf(batchLastTried), lastProcessedPatientId, new Date(), new Date())
												.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE)
												.withPatientBatchList(batchList));
					}
					anyBatchPassed = true;
				} catch (Exception e) {
					logger.error("Caught exception {}", e);
					anyBatchFailed = true;
					addBatchToList(new PatientBatch().withBatchId(start).withBatchCompleted(false)
							.withBatchPatientCount(ss.getGeoPatient().getFeatures().size()), batchList);
					this.savedSearchJobLog.addJobLog(
							new SavedSearchJob(userId, SavedSearchConstants.status.PATIENT_PUSH_PARTIAL_FAILED.name(),
									ss.getSearchName(), ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()),
									Long.valueOf(start), lastProcessedPatientId, new Date(), new Date())
											.withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE)
											.withPatientBatchList(batchList));
				}
			} else {
				logger.info(" Batch[Id=" + start
						+ "] is already in completed status or no batches present. So it is SKIPPED");
			}

			logger.info(" Loop " + start + " <<< " + new Date());
			start++;
			logger.info("End >>>" + start * pageSize);
		} while (((start * pageSize) - 1) < total);

		boolean jobProcessStatus = SavedSearchConstants.BATCH_IN_PROCESS_FALSE;
		updateFinalJobStatus(ss, batchList, lastProcessedPatientId, start - 1, userId, jobProcessStatus, anyBatchPassed,
				anyBatchFailed);
		return true;

	}

	private int getBatchCount(int totalpatients, int batchSize) {
		int countBatch500 = totalpatients / batchSize;
		int remain = totalpatients % batchSize;

		if (remain > 0) {
			countBatch500++;
		}

		logger.info("*******TotalBatch Count:" + countBatch500);
		return countBatch500;
	}

	private void updateFinalJobStatus(SavedSearch ss, List<PatientBatch> batchList, Long lastProcessedPatientId,
			int batch, String userId, boolean jobProcessStatus, Boolean anyBatchPassed, Boolean anyBatchFailed) {
		if (!anyBatchFailed && anyBatchPassed) {
			this.savedSearchJobLog.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.COMPLETED.name(),
					ss.getSearchName(), ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()), Long.valueOf(batch),
					lastProcessedPatientId, new Date(), new Date()).withPatientBatchList(batchList)
							.withInProcess(jobProcessStatus));
		} else if (anyBatchPassed) {
			this.savedSearchJobLog.addJobLog(
					new SavedSearchJob(userId, SavedSearchConstants.status.PATIENT_PUSH_PARTIAL_FAILED.name(),
							ss.getSearchName(), ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()),
							Long.valueOf(batch), lastProcessedPatientId, new Date(), new Date())
									.withPatientBatchList(batchList).withInProcess(jobProcessStatus));
		} else {
			this.savedSearchJobLog
					.addJobLog(new SavedSearchJob(userId, SavedSearchConstants.status.PATIENT_PUSH_FAILED.name(),
							ss.getSearchName(), ss.getTrialCriteriaStr(), Long.valueOf(ss.getTrialId()),
							Long.valueOf(batch), lastProcessedPatientId, new Date(), new Date())
									.withPatientBatchList(batchList).withInProcess(jobProcessStatus));
		}
	}

	/*
	 * Execute stored function populatePatients in the mongodb
	 */
	private String getPatientsQuery(SavedSearch search) {
		String patientCollectionName = patientService.getPatientsCollectionName(search.getTrialId());
		Map<String, String> criteriaMap = patientService.getCriterias(search.getTrialCriteriaStr());
		String complete = patientService.getCompleteJSON(search.getTrialCriteriaStr());
		// String criteria = criteriaMap.get(complete).replace("\"", "\\\"");

		/*
		 * String query = "db." + mongoSavedSearchCollectionName +
		 * ".find({_id: ObjectId(\"" + search.getId() + "\")})\r\n" +
		 * ".forEach(function(doc1) {\r\n" + "    db." + patientCollectionName +
		 * ".find(" + criteriaMap.get(complete) + ").forEach(function (doc2) {\r\n" +
		 * " delete doc2._id; \n" + "db." + mongoSavedSearchCollectionName +
		 * ".update({\"_id\": doc1._id },{ $push: {  \"geoPatientId.patientIds\": doc2.patient_id }});\r\n"
		 * + "}); \r\n" + "});";
		 */

		logger.info(">>>> TrialCriteriaStr - {}", search.getTrialCriteriaStr());

		logger.info("criteriaMap - {}", criteriaMap.get(complete));
		String query = "db." + patientCollectionName + ".find(" + criteriaMap.get(complete) + ")";
		logger.info("getPatientsQuery - {}", query);
		return query;
	}

	/*
	 * As saved search holds only patient Ids, we need to do customized pagination
	 */
	private void populatePatients(SavedSearch ss) {
		logger.info(">>>Started populatePatients method");
		Pageable pageable = null;
		MongoPageRequest pageRequest = ss.getMongoPageRequest();
		if (null != ss.getGeoPatientId() && null != ss.getGeoPatientId().getPatientIds()) {
			List<String> patientIdList = ss.getGeoPatientId().getPatientIds();
			if (pageRequest != null) {
				ss.getMongoPageRequest().withTotalRows(patientIdList.size());
				pageable = new PageRequest(pageRequest.getPageNumber(), pageRequest.getPageSize());
				int start = pageable.getOffset();
				int end = start + pageable.getPageSize();
				if (end < patientIdList.size())
					patientIdList = patientIdList.subList(start, end);
				else
					patientIdList = patientIdList.subList(start, patientIdList.size());
			}
			logger.info("Patient Id List Size:" + patientIdList.size());
			// Collections.sort(patientIdList);
			Query query = new Query();
			query.addCriteria(Criteria.where("patient_id").in(patientIdList));
			List<Patient> patientList = mongoOperations.find(query, Patient.class,
					patientService.getPatientsCollectionName(ss.getTrialId()));
			GeoPatient geoPatient = new GeoPatient();
			geoPatient.withFeatures(patientList);
			ss.withGeoPatient(geoPatient);

			// Pre-load scores JSON
			if (patientList != null) {
				patientList.forEach(p -> {
					p.withScoreJSONMap(p.getCriteria());
				});
			}
			logger.info("patientList List Size:" + patientList.size());
			logger.info("<<< Completed populatePatients method");
		}
	}

	private HttpHeaders getHttpHeaders(String correlationId) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("UUID", springUuid);
		headers.set("X-Requested-With", "XMLHttpRequest");
		headers.set("correlationId", correlationId);
		return headers;
	}

	// NOTE ---> This is a Rest Template call at the moment, however this will be
	// replaced by a Kafka message to make it loosely coupled
	// AND also not to be concerned with scenarios where Saved Search is DONE to
	// Mongo, however the save to Participant Service fails.
	// TODO: 1. Convert to message
	private boolean sendPatientsToParticipantService(SavedSearch ss, String correlationId, int batchId)
			throws Exception {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd-HH:mm");
		Set<Participant> participantSet = new HashSet<>();
		for (Patient p : ss.getGeoPatient().getFeatures()) {
			Participant participant = new Participant();

			participant.withAddress(p.getAddressLine1(), p.getAddressLine2()).withAge(p.getAge())
					.withCoordinates(p.getCoordinates()).withGender(p.getGender()).withGeometry(p.getGeometry())
					.withFirstName(p.getFirstName()).withLastName(p.getLastName()).withParticipantId(p.getPatientId())
					.withTrialId(ss.getTrialId()).withScoreJSON(p.getCriteria()).withZip(p.getZip())
					.withSearchName(ss.getSearchName() + "-" + simpleDateFormat.format(ss.getCreateDate()))
					.withEmail(p.getEmail()).withTrialName(ss.getTrialName()).withContactNumber(p.getPhoneNumber())
					.withState(p.getState()).withCity(p.getCity()).withInternalId(0L);
			participantSet.add(participant);
		}
		List<Participant> participants = new ArrayList<>(participantSet);

		contactsTransferService.sendContactsThroughBlobStorage(participants, batchId);
		return true;
	}

	private void addBatchToList(PatientBatch batch, List<PatientBatch> batchList) {
		if (null != batch) {
			if (batchList.stream().filter(b -> b.getBatchId().equals(batch.getBatchId())).count() <= 0) {
				batchList.add(batch);
			} else {
				batchList.forEach(b -> {
					if (b.getBatchId().equals(batch.getBatchId())) {
						b.setBatchCompleted(batch.isBatchCompleted());
					}
				});
			}
		}
	}

	public RetryTemplate getRetrySaveSearchTemplate(Boolean batchProcessing) {
		RetryTemplate retryTemplate = new RetryTemplate();

		if (!batchProcessing) {
			if (0 == asyncConfigLoaderBean.getSaveSearchRetryPolicy().intValue()) {
				FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
				backOffPolicy.setBackOffPeriod(asyncConfigLoaderBean.getSaveSearchRetryIntervalInitial() * 60L * 1000L);
				retryTemplate.setBackOffPolicy(backOffPolicy);
			} else {
				ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
				backOffPolicy
						.setInitialInterval(asyncConfigLoaderBean.getSaveSearchRetryIntervalInitial() * 60L * 1000L);
				backOffPolicy.setMaxInterval(asyncConfigLoaderBean.getSaveSearchRetryIntervalMax() * 60L * 1000L);
				backOffPolicy.setMultiplier(asyncConfigLoaderBean.getSaveSearchRetryIntervalMultiplier());
				retryTemplate.setBackOffPolicy(backOffPolicy);
			}

			retryTemplate.setRetryPolicy(new RetryPolicyClassifier(asyncConfigLoaderBean.getSaveSearchRetryAttempts()));
		} else {
			if (0 == asyncConfigLoaderBean.getBatchRetryPolicy().intValue()) {
				FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
				backOffPolicy.setBackOffPeriod(asyncConfigLoaderBean.getBatchRetryIntervalInitial() * 60L * 1000L);
				retryTemplate.setBackOffPolicy(backOffPolicy);
			} else {
				ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
				backOffPolicy.setInitialInterval(asyncConfigLoaderBean.getBatchRetryIntervalInitial() * 60L * 1000L);
				backOffPolicy.setMaxInterval(asyncConfigLoaderBean.getBatchRetryIntervalMax() * 60L * 1000L);
				backOffPolicy.setMultiplier(asyncConfigLoaderBean.getBatchRetryIntervalMultiplier());
				retryTemplate.setBackOffPolicy(backOffPolicy);
			}
			retryTemplate.setRetryPolicy(new RetryPolicyClassifier(asyncConfigLoaderBean.getBatchRetryAttempts()));

		}
		retryTemplate.registerListener(savedSearchRetryListener);

		return retryTemplate;
	}

	public RetryTemplate getRetrySendPatientsTemplate(Boolean batchProcessing) {
		RetryTemplate retryTemplate = new RetryTemplate();

		if (!batchProcessing) {
			if (0 == asyncConfigLoaderBean.getSendPatientsRetryPolicy().intValue()) {// 0
				FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
				backOffPolicy.setBackOffPeriod(asyncConfigLoaderBean.getSendPatientsRetryIntervalInitial() * 1000L);// 5
																													// --1
				retryTemplate.setBackOffPolicy(backOffPolicy);
			} else {
				ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
				backOffPolicy.setInitialInterval(asyncConfigLoaderBean.getSendPatientsRetryIntervalInitial() * 1000L);// 5
																														// --1
				backOffPolicy.setMaxInterval(asyncConfigLoaderBean.getSendPatientsRetryIntervalMax() * 1000L);// 80 --
																												// 15
				backOffPolicy.setMultiplier(asyncConfigLoaderBean.getSendPatientsRetryIntervalMultiplier()); // 2 --2
				retryTemplate.setBackOffPolicy(backOffPolicy);
			}

			retryTemplate
					.setRetryPolicy(new RetryPolicyClassifier(asyncConfigLoaderBean.getSendPatientsRetryAttempts()));// 5

		} else {
			if (0 == asyncConfigLoaderBean.getBatchRetryPolicy().intValue()) { // 0
				FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
				backOffPolicy.setBackOffPeriod(asyncConfigLoaderBean.getBatchRetryIntervalInitial() * 1000L);// 5
				retryTemplate.setBackOffPolicy(backOffPolicy);
			} else {
				ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
				backOffPolicy.setInitialInterval(asyncConfigLoaderBean.getBatchRetryIntervalInitial() * 1000L);// 5 --1
				backOffPolicy.setMaxInterval(asyncConfigLoaderBean.getBatchRetryIntervalMax() * 1000L); // 80 --15/20
				backOffPolicy.setMultiplier(asyncConfigLoaderBean.getBatchRetryIntervalMultiplier());// 1 --2
				retryTemplate.setBackOffPolicy(backOffPolicy);
			}
			retryTemplate.setRetryPolicy(new RetryPolicyClassifier(asyncConfigLoaderBean.getBatchRetryAttempts()));// 1
																													// --5

		}

		retryTemplate.registerListener(sendPatientsRetryListener);
		return retryTemplate;
	}

	private void resetProcessStatusForIdleJobs() {
		List<SavedSearchJob> jobList = this.savedSearchJobLog.getJobsInProcessingAndNotInCompleted();
		if (null != jobList && jobList.size() > 0) {
			jobList.forEach(fjob -> {
				logger.info("Checking whether Process Reset Required for: " + fjob.toString());

				try {
					// This is to set the InProcess as false and Job Status as Completed if all
					// batches are in completed state
					if (null != fjob.getPatientBatchList() && fjob.getPatientBatchList().size() > 0 && fjob
							.getPatientBatchList().stream().filter(bat -> !bat.isBatchCompleted()).count() <= 0L) {
						if (fjob.getPatientBatchList().size() == fjob.getTotalBatchCount()) {
							fjob.withInProcess(false);
							fjob.withJobStatus(SavedSearchConstants.status.COMPLETED.name());
						}
					}

					Date date1 = new Date();
					Date date2 = fjob.getUpdatedOn();

					// This is to set the InProcess as false if the job is not updated for
					// BatchReset Interval
					if (getDiffInMinutes(date1, date2) > asyncConfigLoaderBean.getBatchResetInterval()) {
						fjob.withInProcess(false);
					}
					this.savedSearchJobLog.addJobLog(fjob);

				} catch (Exception e) {
					logger.error("Error occurred while Checking for Process Reset", e);
				}

			});
		}
	}

	private long getDiffInMinutes(Date date1, Date date2) {
		long diff = Math.abs(date1.getTime() - date2.getTime());
		long diffMinutes = TimeUnit.MINUTES.convert(diff, TimeUnit.MILLISECONDS);
		// long diffHours = diff / (60 * 60 * 1000);
		logger.info("Diff between " + date1 + " and " + date2 + " is" + diffMinutes);
		return diffMinutes;
	}
}
