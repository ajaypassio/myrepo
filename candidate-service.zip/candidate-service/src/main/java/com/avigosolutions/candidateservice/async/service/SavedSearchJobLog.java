package com.avigosolutions.candidateservice.async.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.avigosolutions.candidateservice.async.constants.SavedSearchConstants;
import com.avigosolutions.candidateservice.async.model.PatientBatch;
import com.avigosolutions.candidateservice.async.model.SavedSearchJob;
import com.avigosolutions.candidateservice.async.model.SavedSearchJobResponseModel;
import com.avigosolutions.candidateservice.async.repository.SavedSearchJobRepository;

@Service
public class SavedSearchJobLog {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	SavedSearchJobRepository savedSearchJobRepository;
	
	@Async
	public void addJobLog(SavedSearchJob job) {		
		SavedSearchJob ssj = this.savedSearchJobRepository.findBySearchNameAndTrialId(job.getSearchName(), job.getTrialId());
		List<String> statusList = new ArrayList<>();
		logger.info("To add Job Entry==>"+job);
		try {
		if(ssj != null) {
			if(null != ssj.getPreviousJobStatusList()) {
				statusList = ssj.getPreviousJobStatusList();
			}				

			statusList.add(ssj.getJobStatus());
			job.setId(ssj.getId());
			logger.info("Job is existing. Job Details==>"+ssj);			
			
			if( null == job.getJobStatus() || job.getJobStatus().trim().isEmpty() || ssj.getJobStatus().equals(SavedSearchConstants.status.COMPLETED.name())) {
				job.setJobStatus(ssj.getJobStatus());
			}
			
			if( (job.getTotalBatchCount()== 0 || null == job.getTotalBatchCount() ) && ssj.getTotalBatchCount() > 0) {
				job.withTotalBatchCount(ssj.getTotalBatchCount());
			}
			
			if((null == job || null == job.getPatientBatchList() || job.getPatientBatchList().isEmpty() ) && null != ssj && null != ssj.getPatientBatchList() ) {
				job.setPatientBatchList(ssj.getPatientBatchList());
			}else {
				if(null != job.getPatientBatchList() && !job.getPatientBatchList().isEmpty() && null != ssj.getPatientBatchList() ) {
					ssj.getPatientBatchList().addAll(job.getPatientBatchList());
					job.setPatientBatchList(removeDuplicates(ssj.getPatientBatchList()));
				}				
				
			}
		}
		this.savedSearchJobRepository.save(job.withPreviousJobStatusList(statusList));
		}catch(Exception e) {
			logger.info("Adding Job entry is failed");
			logger.error("Adding Job entry is failed due to exception",e);
		}
		
	}
	
	private List<PatientBatch> removeDuplicates(List<PatientBatch> list) {
		List<PatientBatch> newPbList = new ArrayList<>();
		List<Integer> batchIds = list.stream().map(l->l.getBatchId()).distinct().collect(Collectors.toList());
		
		batchIds.forEach(bi->{	
			if(list.stream().filter(l->l.getBatchId().equals(bi)).count() > 1 && list.stream().filter(l->l.getBatchId().equals(bi) && l.isBatchCompleted()).count() >= 1) {
				newPbList.add(list.stream().filter(l->l.getBatchId().equals(bi)).findFirst().get().withBatchCompleted(true));
			}else {
				newPbList.add(list.stream().filter(l->l.getBatchId().equals(bi)).findFirst().get());
			}
			
		});
		return newPbList;
	}
	
	public List<SavedSearchJobResponseModel> getJobStatusByTrialId(Long trialId) {		
		List<SavedSearchJob> ssjList = this.savedSearchJobRepository.findByTrialId(trialId);
		if(null != ssjList && ssjList.size() > 0) {
			List<SavedSearchJobResponseModel> ssjResList = ssjList.stream().map(ssj->new SavedSearchJobResponseModel(ssj.getUserId(),ssj.getJobStatus(),ssj.getSearchName(),ssj.getTrialId())).collect(Collectors.toList());
			logger.info("Job Entries received==>"+ssjList.size());
			return ssjResList;
		}
		
		return new ArrayList<>();
		
	}
	
	public SavedSearchJobResponseModel getJobStatusBySearchNameAndTrialId(String searchName, Long trialId) {		
		SavedSearchJob ssj = this.savedSearchJobRepository.findBySearchNameAndTrialId(searchName, trialId);
		
		SavedSearchJobResponseModel model = new SavedSearchJobResponseModel("","",searchName,trialId);;
		if(null != ssj) {
			logger.info("Job details==>"+ssj.toString());
			model = new SavedSearchJobResponseModel(ssj.getUserId(),ssj.getJobStatus(),ssj.getSearchName(),ssj.getTrialId());
		}else {
			logger.info("No job found with given SearchName:"+searchName+" and TrialId:"+trialId);
		}
		return model;
		
	}
	
	public SavedSearchJob getJobBySearchNameAndTrialId(String searchName, Long trialId) {		
		SavedSearchJob ssj = this.savedSearchJobRepository.findBySearchNameAndTrialId(searchName, trialId);		
		if(null != ssj)
			logger.info("Job details==>"+ssj.toString());			
		return ssj;		
	}
	
	public List<SavedSearchJob> getJobsNotInProcessingAndNotInCompleted() {		
		List<SavedSearchJob> jobList = this.savedSearchJobRepository.findByInProcessFalseAndJobStatusNotLike(SavedSearchConstants.status.COMPLETED.name());	
		if( null != jobList && jobList.size() > 0) {
			logger.info("Job size()==>"+jobList.size());
			logger.info("Job(s)==>"+jobList);
		}
			
		return jobList;		
	}
	
	public List<SavedSearchJob> getJobsInProcessingAndNotInCompleted() {		
		List<SavedSearchJob> jobList = this.savedSearchJobRepository.findByInProcessTrueAndJobStatusNotLike(SavedSearchConstants.status.COMPLETED.name());	
		if( null != jobList && jobList.size() > 0) {
			logger.info("Job size()==>"+jobList.size());
			logger.info("Job(s)==>"+jobList);
		}
			
		return jobList;		
	}

}
