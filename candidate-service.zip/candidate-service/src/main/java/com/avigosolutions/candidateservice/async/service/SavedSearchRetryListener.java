package com.avigosolutions.candidateservice.async.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.listener.RetryListenerSupport;
import org.springframework.stereotype.Component;

import com.avigosolutions.candidateservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.candidateservice.async.constants.SavedSearchConstants;
import com.avigosolutions.candidateservice.async.model.SavedSearchJob;
import com.avigosolutions.candidateservice.model.SavedSearch;

@Component
public class SavedSearchRetryListener extends RetryListenerSupport {

	@Autowired
	SavedSearchJobLog savedSearchJobLog;

	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public <T, E extends Throwable> void close(RetryContext context, RetryCallback<T, E> callback,
			Throwable throwable) {
		logger.info("==>Retry activity is completed.");
		super.close(context, callback, throwable);
	}

	@Override
	public <T, E extends Throwable> void onError(RetryContext context, RetryCallback<T, E> callback,
			Throwable throwable) {
		logger.info("Retry attempt:" + context.getRetryCount() + " failed due to " + throwable.getMessage());
		SavedSearch savedSearch = (SavedSearch) context.getAttribute("searchToBeSaved");
		String userId = (String) context.getAttribute("userId");
		if(asyncConfigLoaderBean.getSaveSearchRetryAttempts() > context.getRetryCount()) {
			savedSearchJobLog.addJobLog(
					new SavedSearchJob(userId, SavedSearchConstants.status.RETRY_INPROGRESS.name(), savedSearch.getSearchName(), savedSearch.getTrialCriteriaStr(),
							Long.valueOf(savedSearch.getTrialId()), 0L, 0L, new Date(), new Date()).withInProcess(SavedSearchConstants.BATCH_IN_PROCESS_TRUE));
		}
		
		super.onError(context, callback, throwable);
	}

	@Override
	public <T, E extends Throwable> boolean open(RetryContext context, RetryCallback<T, E> callback) {
		logger.info("==>Retry activity is initiated.");
		return super.open(context, callback);
	}
}