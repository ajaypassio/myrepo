/**
 * 
 */
package com.avigosolutions.candidateservice.constants;

/**
 * @author Ajay Kumar
 *
 */
public class Constants {	

	private Constants() {
		
	}
	public static final String PATIENT_ID = "patient_id";
	public static final String LONGITUDE = "lng";
	public static final String LATITUDE = "lat";
	public static final String EID = "eid";
	
	public static final String TRIAL="T";
	public static final String CAMPAIGN_FILE_NAME="CampaignPatientList";
	public static final String CAMPAIGN_FILE_FOLDER="Trial-Campaign";
	public static final String CAMPAIGN_FILE_FORMAT=".csv";
	
	public static final String COMMA = ",";
	public static final String NEW_LINE = "\n";	
	public static final String UNDERSCORE = "_";
	public static final String BACKSLASH = "/";
}
