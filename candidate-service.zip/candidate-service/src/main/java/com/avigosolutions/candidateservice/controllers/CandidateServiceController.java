package com.avigosolutions.candidateservice.controllers;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.candidateservice.model.CampaignModel;
//import com.microsoft.azure.storage.core.Logger;
import com.avigosolutions.candidateservice.model.Candidate;
import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.DownloadCSVPatient;
import com.avigosolutions.candidateservice.model.GeoCandidate;
import com.avigosolutions.candidateservice.model.LabRecords;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.model.PatientDetails;
import com.avigosolutions.candidateservice.model.SearchModel;
import com.avigosolutions.candidateservice.service.CampaignPatientHelper;
import com.avigosolutions.candidateservice.service.CandidateService;
import com.avigosolutions.candidateservice.service.PatientService;

@Controller
@RequestMapping(path = "")
public class CandidateServiceController {

	@Autowired
	private CandidateService candidateService;

	@Autowired
	private PatientService patientService;
	
	@Autowired
	CampaignPatientHelper campaignPatientHelper;

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Value("${sprinnt.search.geo.data.fields}")
	private String searchGeoDataFields;

	@ResponseBody
	@RequestMapping(path = "/candidates/{trialId}", method = RequestMethod.GET)
	public ResponseEntity<List<Candidate>> getCandidatesByTrial(@PathVariable Long trialId) {
		Optional<List<Candidate>> optionalCandidateListByTrial = candidateService.getCandidatesByTrial(trialId);
		ResponseEntity<List<Candidate>> relc = optionalCandidateListByTrial
				.map(clist -> new ResponseEntity<List<Candidate>>(clist, HttpStatus.OK))
				.orElse(new ResponseEntity<List<Candidate>>(HttpStatus.NOT_FOUND));
		return relc;

	}

	@ResponseBody
	@RequestMapping(path = "/geo-candidates/{trialId}", method = RequestMethod.GET)
	public ResponseEntity<GeoCandidate> getGeoCandidatesByTrial(@PathVariable Long trialId) {
		Optional<GeoCandidate> optionalGeoCandidateByTrial = candidateService.getGeoCandidatesByTrial(trialId);
		ResponseEntity<GeoCandidate> relc = optionalGeoCandidateByTrial
				.map(gc -> new ResponseEntity<GeoCandidate>(gc, HttpStatus.OK))
				.orElse(new ResponseEntity<GeoCandidate>(HttpStatus.NOT_FOUND));
		return relc;

	}

	@ResponseBody
	@RequestMapping(path = "/faceted-search/{trialId}/{iteration}", method = RequestMethod.POST)
	public ResponseEntity<CriteriaCounts> getFacetedSearchResults(@PathVariable Long trialId,
			@PathVariable int iteration, @RequestBody String trialJson) {
		logger.info("getFacetedSearchResults trialId: " + trialId + " iteration: " + iteration + " trialJson: "
				+ trialJson);
		CriteriaCounts cc = candidateService.getFacetedSearchResults(trialId, iteration, trialJson);
		if (cc != null)
			return new ResponseEntity<CriteriaCounts>(cc, HttpStatus.OK);
		return new ResponseEntity<CriteriaCounts>(HttpStatus.NOT_FOUND);

	}

	@ResponseBody
	@RequestMapping(path = "/search/{trialId}", method = RequestMethod.POST)
	public ResponseEntity<CriteriaCounts> getFacetedSearchResults(@PathVariable Long trialId,
			@RequestBody SearchModel searchModel) {
		logger.info("*********** getFacetedSearchResults trialId: " + trialId);
		logger.info("<<< getFaceted:" + new Date());
		searchModel.withTrialId(trialId);
		CriteriaCounts cc = patientService.getCriteriaCountMapAndPatients(searchModel);
		if (cc != null) {
			if (null != cc.getGeoPatient() && null != cc.getGeoPatient().getFeatures()) {
				cc.getGeoPatient().getFeatures().stream().forEach(p -> p.setLabRecords(null));
				cc.getGeoPatient().getFeatures().stream().forEach(p -> p.setDiagnosisRecords(null));
			}
			logger.info(">>> getFaceted:" + new Date());
			return new ResponseEntity<CriteriaCounts>(cc, HttpStatus.OK);
		}
		return new ResponseEntity<CriteriaCounts>(cc, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/search/count/{trialId}", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Integer>> getFacetedSearchCounts(@PathVariable Long trialId,
			@RequestBody SearchModel searchModel) {
		logger.info("<<< getFaceted: TrialId=["+trialId+"] Date=[" + new Date()+"]");
		searchModel.withTrialId(trialId);
		Map<String, Integer> cc = patientService.getCriteriaCountMap(searchModel.getTrialId(),
				searchModel.getTrailJSON());
		if (cc != null) {
			logger.info(">>> getFaceted:" + new Date());
			return new ResponseEntity<Map<String, Integer>>(cc, HttpStatus.OK);
		}
		return new ResponseEntity<Map<String, Integer>>(cc, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/patients/{trialId}/{patientId}", method = RequestMethod.GET)
	public ResponseEntity<PatientDetails> getPatient(@PathVariable long trialId, @PathVariable String patientId) {
		PatientDetails patient = patientService.findByPatientId(patientId, trialId);
		if (patient != null)
			return new ResponseEntity<PatientDetails>(patient, HttpStatus.OK);
		return new ResponseEntity<PatientDetails>(HttpStatus.NOT_FOUND);
	}

	@ResponseBody
	@RequestMapping(path = "/patients/labreport/{trialId}/{patientId}", method = RequestMethod.GET)
	public ResponseEntity<List<LabRecords>> getPatientLabReport(@PathVariable long trialId,
			@PathVariable String patientId) {
		List<LabRecords> labRecords = patientService.findLabReportByPatientIdAndTrialId(patientId, trialId);
		if (labRecords != null)
			return new ResponseEntity<List<LabRecords>>(labRecords, HttpStatus.OK);
		return new ResponseEntity<List<LabRecords>>(HttpStatus.NOT_FOUND);
	}

	@ResponseBody
	@RequestMapping(path = "/search/test/performance", method = RequestMethod.GET)
	public ResponseEntity<String> getTestPerformance() {
		String response = patientService.testServiceMethodCallPerformance("all_patients");
		return new ResponseEntity<String>(response, HttpStatus.NOT_FOUND);
	}

	@ResponseBody
	@RequestMapping(path = "/search/test/rest/performance", method = RequestMethod.GET)
	public ResponseEntity<String> callTestPerformanceRest() {
		String response = patientService.testRestAPIPerformace("all_patients");
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/search/test/reduced/performance", method = RequestMethod.GET)
	public ResponseEntity<String> getTestReducedCollectionDataPerformance() {
		String response = patientService.testServiceMethodCallPerformance("all_patients_reduced");
		return new ResponseEntity<String>(response, HttpStatus.NOT_FOUND);
	}

	@ResponseBody
	@RequestMapping(path = "/search/test/rest/reduced/performance", method = RequestMethod.GET)
	public ResponseEntity<String> callTestReducedCollectionDataPerformanceRest() {

		String response = patientService.testRestAPIPerformace("all_patients_reduced");
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/search/geodata/{trialId}", method = RequestMethod.POST)
	public ResponseEntity<CriteriaCounts> getGeoDataSearchResults(@PathVariable Long trialId,
			@RequestBody SearchModel searchModel) {
		logger.info("*********** getFacetedSearchResults trialId: " + trialId);
		logger.info("<<< getFaceted:" + new Date());
		searchModel.withTrialId(trialId);
		CriteriaCounts cc = patientService.getCriteriaCountMapAndPatientsGeoData(searchModel,searchGeoDataFields);
		if (cc != null) {
			if (null != cc.getGeoPatient() && null != cc.getGeoPatient().getFeatures()) {
				cc.getGeoPatient().getFeatures().stream().forEach(p -> p.setLabRecords(null));
				cc.getGeoPatient().getFeatures().stream().forEach(p -> p.setDiagnosisRecords(null));
			}
			logger.info(">>> getFaceted:" + new Date());
			return new ResponseEntity<CriteriaCounts>(cc, HttpStatus.OK);
		}
		return new ResponseEntity<CriteriaCounts>(cc, HttpStatus.OK);
	}	
	/*
	 * This end point will be used to download patient list in csv format.
	 */
	@ResponseBody
	@RequestMapping(path = "/search/download/{trialId}", method = RequestMethod.POST)
	public ResponseEntity<List<DownloadCSVPatient>> getFacetedSearchResultsDownload(@PathVariable Long trialId,
			@RequestBody SearchModel searchModel) {
		logger.info("Download process started for quest patient list of trial id: {} ", trialId);
		searchModel.withTrialId(trialId);
		CriteriaCounts cc = patientService.getCriteriaCountMapAndPatients(searchModel);
		List<DownloadCSVPatient> downloadCsvPatientList = null;
		if (cc != null) {
			if (null != cc.getGeoPatient() && null != cc.getGeoPatient().getFeatures()) {
				downloadCsvPatientList = new ArrayList<>();
				for (Patient p : cc.getGeoPatient().getFeatures()) {
					DownloadCSVPatient patient = new DownloadCSVPatient();
					patient.setRanking(p.getRanking());
					patient.setTempId(p.getTempId());
					patient.setZip(p.getZip());
					patient.setScore(p.getScore());
					downloadCsvPatientList.add(patient);
				}
				logger.info("Download process completed for quest patient list size {} of trial id: {} ",
						downloadCsvPatientList.size(), trialId);
			}
		}
		return new ResponseEntity<List<DownloadCSVPatient>>(downloadCsvPatientList, HttpStatus.OK);
	}
	
	@PostMapping(value = "/search/populateCampaign")
	public ResponseEntity<Boolean> createDraftSprinttCampaign(@RequestHeader HttpHeaders headers,
			@RequestBody CampaignModel campaignModel){
		return new ResponseEntity<>(campaignPatientHelper.populateCampaignPatient(campaignModel), HttpStatus.OK);
	}
}
