package com.avigosolutions.candidateservice.controllers;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.candidateservice.async.model.SavedSearchJobResponseModel;
import com.avigosolutions.candidateservice.model.SavedSearch;
import com.avigosolutions.candidateservice.response.model.SavedSearchResponse;
import com.avigosolutions.candidateservice.service.PatientService;
import com.avigosolutions.candidateservice.service.SavedSearchService;

@Controller
@RequestMapping(path = "")
public class SavedSearchController {

	@Value("${sprinnt.search.geo.data.fields}")
	private String searchGeoDataFields;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	PatientService patientService;

	@Autowired
	private SavedSearchService savedSearchService;

	@ResponseBody
	@RequestMapping(path = "/savedsearch/{trialId}", method = RequestMethod.POST)
	public ResponseEntity<SavedSearch> createSavedSearch(@PathVariable Long trialId,
			@RequestBody SavedSearch savedSearch, @RequestHeader("uuid") String userId) {
		savedSearch.withTrialId(trialId);
		logger.info("createSavedSearch searchToBeSaved: " + trialId);
		logger.info("saved Search trial json: " + savedSearch.getTrialCriteriaStr());
		if (savedSearch.getCriteriaNameToCountMap().size() <= 1) {
			savedSearch.withCriteriaNameToCountMap(patientService.getCriteriaCountMap(trialId,
					savedSearch.getTrialCriteriaStr(), savedSearch.getTotalCandidates()));
		}
		boolean ss = savedSearchService.save(savedSearch, userId);
		if (!ss) {
			logger.error("createSavedSearch  ******returning null/error response");
			return new ResponseEntity<SavedSearch>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<SavedSearch>(savedSearch, HttpStatus.ACCEPTED);
	}

	@ResponseBody
	@RequestMapping(path = "/savedsearch/trigger/{searchId}", method = RequestMethod.POST)
	public ResponseEntity<SavedSearch> getSavedSearch(@PathVariable String searchId,
			@RequestBody SavedSearch savedSearch) {
		savedSearch.setId(searchId);
		logger.info("getSavedSearch searchName: " + savedSearch.getSearchName() + " savedSearchId :  " + searchId
				+ "  trialId: " + savedSearch.getTrialId());
		SavedSearch ss = savedSearchService.findBySearchNameAndTrialId(savedSearch, "");
		if (ss == null) {
			logger.error("getSavedSearch searchName: " + savedSearch.getSearchName() + " savedSearchId :  " + searchId
					+ "  trialId: " + savedSearch.getTrialId() + " ******returning null/error response");
			return new ResponseEntity<SavedSearch>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<SavedSearch>(savedSearchService.updateId(ss), HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/savedsearch/{trialId}/{updatedDate}", method = RequestMethod.GET)
	public ResponseEntity<List<SavedSearch>> getSavedSearchByTrialId(@PathVariable long trialId, @PathVariable long updatedDate) {
		logger.info("getSavedSearchByTrialId trialId: " + trialId);
		Date date = new Date(updatedDate);
		List<SavedSearch> ss = savedSearchService.getSavedSearchByTrialId(trialId,date);
		if (ss == null || ss.size() == 0) {
			logger.error("getSavedSearchByTrialId trialId: " + trialId + " ******returning null/error response");
			return new ResponseEntity<List<SavedSearch>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<SavedSearch>>(ss, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/savedsearch/page/{trialId}", method = RequestMethod.GET)
	public ResponseEntity<SavedSearchResponse> getSavedSearchByTrialIdByPage(@PathVariable long trialId,
			@RequestParam int start, @RequestParam int pageSize) {
		logger.info("getSavedSearchByTrialIdByPage trialId: " + trialId);
		SavedSearchResponse savedSearchResponse = savedSearchService.getSeavedSearchByTrialIdByPage(trialId, start,
				pageSize);

		return new ResponseEntity<SavedSearchResponse>(savedSearchResponse, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/savedsearch/jobstatus/{trialId}", method = RequestMethod.GET)
	public ResponseEntity<List<SavedSearchJobResponseModel>> getSavedSearchJobStatusByTrialId(
			@PathVariable long trialId) {
		logger.info("getSavedSearchJobStatusByTrialId trialId: " + trialId);
		List<SavedSearchJobResponseModel> ss = savedSearchService.getJobStatusByTrialId(trialId);
		if (ss == null || ss.size() == 0) {
			logger.error(
					"getSavedSearchJobStatusByTrialId trialId: " + trialId + " ******returning null/error response");
			return new ResponseEntity<List<SavedSearchJobResponseModel>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<SavedSearchJobResponseModel>>(ss, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/savedsearch/jobstatus/{trialId}/{searchName}", method = RequestMethod.GET)
	public ResponseEntity<SavedSearchJobResponseModel> getSavedSearchJobStatusByTrialId(@PathVariable long trialId,
			@PathVariable String searchName) {
		logger.info("getSavedSearchJobStatusByTrialId trialId: " + trialId);
		SavedSearchJobResponseModel ss = savedSearchService.getJobStatusBySearchNameAndTrialId(searchName, trialId);
		if (ss == null) {
			logger.error(
					"getSavedSearchJobStatusByTrialId trialId: " + trialId + " ******returning null/error response");
			return new ResponseEntity<SavedSearchJobResponseModel>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<SavedSearchJobResponseModel>(ss, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/savedsearch/geodata/trigger/{searchId}", method = RequestMethod.POST)
	public ResponseEntity<SavedSearch> getSavedSearchPatientGeoData(@PathVariable String searchId,
			@RequestBody SavedSearch savedSearch) {
		savedSearch.setId(searchId);
		logger.info("getSavedSearch searchId: " + searchId + " trialId: " + savedSearch.getTrialId()
				+ "getSavedSearch searchName: " + savedSearch.getSearchName());
		SavedSearch ss = savedSearchService.findBySearchNameAndTrialId(savedSearch, searchGeoDataFields);
		if (ss == null) {
			logger.error("getSavedSearch searchName: " + savedSearch.getSearchName() + "  searchId: " + searchId
					+ " trialId: " + savedSearch.getTrialId() + " ******returning null/error response");
			return new ResponseEntity<SavedSearch>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<SavedSearch>((ss), HttpStatus.OK);

	}
}
