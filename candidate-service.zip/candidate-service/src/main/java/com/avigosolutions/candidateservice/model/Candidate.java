package com.avigosolutions.candidateservice.model;
/*
 *     {
      "id": 1,
      "avator": "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_640.png",
      "first_name": "Thomas",
      "last_name": "Andreson",
      "gender": "Male",
      "dob": "05/18/1980",
      "age": 36,
      "stage": "Prescreened",
      "address": "181 Augusta Dr., Medford, NY 11763",
      "coordinates": [
        -71.05977,
        42.35843
      ]
    },

 */

import java.util.List;

import org.quickgeo.Place;
import org.quickgeo.PostalDbFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.opencsv.bean.CsvBindByPosition;


public class Candidate {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	//@CsvBindByName(column = "id", required = true)
	@CsvBindByPosition(position = 0)
	private int id;
	private Long patientId;
		
	//@CsvBindByName
	@CsvBindByPosition(position = 3)
	private String gender;
	
	//private Date dateOfBirth;
	
	//@CsvBindByName
	@CsvBindByPosition(position = 2)
	private int age;
	
	// TODO change to Address object
	//@CsvBindByName
	@CsvBindByPosition(position = 4)
	private String address;
	
	//@CsvBindByName
	@CsvBindByPosition(position = 5)
	private String zipcode;
	
	//@CsvBindByName
	@CsvBindByPosition(position = 1)
	private String name;
	
	
	@Autowired
	@JsonIgnore
	private Coordinates coordinates;
	
	@Autowired
	private Geometry geometry;
	
	public String getZipcode() {
		return zipcode;
	}
	
	public void setZipcode(String zipcode) {
		withZipcode(zipcode);
	}

	public Candidate withZipcode(String zipcode) {
		this.zipcode = zipcode.trim();
		// In memory lookup is faster than contacting a web service (for ex: Google Geocoder)
		// https://github.com/kickroot/quickgeo
		// alternative: https://gist.github.com/erichurst/7882666
		
		List<Place> listPlace = PostalDbFactory.getPostalDb().byPostalCode(this.zipcode);
		 
		coordinates = new Coordinates().withLatitude (listPlace != null && listPlace.size() > 0 ? listPlace.get(0).getLatitude() : 0.0)
				   					   .withLongitude(listPlace != null && listPlace.size() > 0 ?  listPlace.get(0).getLongitude() : 0.0);
		//geometry = new Geometry().withPoint(new Point().withCoordinates(coordinates));
		geometry = new Geometry().withType("Point").withCoordinates(coordinates);
		return this;
	}

	public String getName() {
		return name;
	}

	public Candidate withName(String name) {
		this.name = name;
		return this;
	}

	

	public int getId() {
		return id;
	}

	public Candidate withId(int id) {
		this.id = id;
		return this;
	}

	public Long getPatientId() {
		return patientId;
	}

	public Candidate withPatientId(Long patientId) {
		this.patientId = patientId;
		return this;
	}


	public String getGender() {
		return gender;
	}

	public Candidate withGender(String gender) {
		this.gender = gender;
		return this;
	}

//	public Date getDateOfBirth() {
//		return dateOfBirth;
//	}
//
//	public Candidate withDateOfBirth(Date dateOfBirth) {
//		this.dateOfBirth = dateOfBirth;
//		return this;
//	}

	public int getAge() {
		return age;
	}

	public Candidate withAge(int age) {
		this.age = age;
		return this;
	}

	public String getAddress() {
		return address;
	}

	public Candidate withAddress(String address) {
		this.address = address;
		return this;
	}

	public Coordinates getCoordinates() {
		return coordinates;
	}

	private Candidate withCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
		return this;
	}
	
	public Geometry getGeometry() {
		return geometry;
	}

	private Candidate withCoordinates(Geometry geometry) {
		this.geometry = geometry;
		return this;
	}
	
	@Override
	public String toString() {
		return "Candidate [id=" + id + ", patientId=" + patientId + ", gender=" + gender + 
				", dateOfBirth=" + age + ", address=" + address + ", coordinates=" + coordinates + "]";
	}

	
		
}
