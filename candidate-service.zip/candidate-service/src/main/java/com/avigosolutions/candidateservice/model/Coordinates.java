package com.avigosolutions.candidateservice.model;

public class Coordinates {
	@Override
	public String toString() {
		return "Coordinates [longitude=" + longitude + ", latitude=" + latitude + "]";
	}
	private double longitude;
	private double latitude;
	public double getLongitude() {
		return longitude;
	}
	public Coordinates withLongitude(double longitude) {
		this.longitude = longitude;
		return this;
	}
	public double getLatitude() {
		return latitude;
	}
	public Coordinates withLatitude(double latitude) {
		this.latitude = latitude;
		return this;
	}
}
