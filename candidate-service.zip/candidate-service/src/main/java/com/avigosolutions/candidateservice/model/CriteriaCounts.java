package com.avigosolutions.candidateservice.model;

import java.util.Map;

public class CriteriaCounts {
	Map<String, Integer> criteriaNameToCountMap;
	private GeoCandidate geoCandidate;
	private GeoPatient geoPatient;
	private int totalCount;
	private int totalCandidates;
	private MongoPageRequest mongoPageRequest;

	public Map<String, Integer> getCriteriaNameToCountMap() {
		return criteriaNameToCountMap;
	}

	public CriteriaCounts withCriteriaNameToCountMap(Map<String, Integer> criteriaNameToCountMap) {
		this.criteriaNameToCountMap = criteriaNameToCountMap;
		return this;
	}

	public GeoCandidate getGeoCandidate() {
		return geoCandidate;
	}

	public CriteriaCounts withGeoCandidate(GeoCandidate geoCandidate) {
		this.geoCandidate = geoCandidate;
		return this;
	}

	public GeoPatient getGeoPatient() {
		return geoPatient;
	}

	public CriteriaCounts withGeoPatient(GeoPatient geoPatient) {
		this.geoPatient = geoPatient;
		return this;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public CriteriaCounts withTotalCount(int totalCount) {
		this.totalCount = totalCount;
		if(mongoPageRequest != null) {
			mongoPageRequest.withTotalRows(totalCount);
		}
		return this.withTotalCandidates(totalCount);
	}
	
	public int getTotalCandidates() {
		return totalCandidates;
	}

	public void setTotalCandidates(int totalCandidates) {
		this.totalCandidates = totalCandidates;
	}
	
	public CriteriaCounts withTotalCandidates(int totalCandidates) {
		this.totalCandidates = totalCandidates;
		return this;
	}

	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}
	public CriteriaCounts withMongoPageRequest(MongoPageRequest pageable) {
		this.mongoPageRequest = pageable;
		return this;
	}

}
