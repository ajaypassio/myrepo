package com.avigosolutions.candidateservice.model;

public class DiagnosisRecords {
	private int year;
	private String icdCode;
	private String icdCodeSet;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getIcdCode() {
		return icdCode;
	}

	public void setIcdCode(String icdCode) {
		this.icdCode = icdCode;
	}

	public String getIcdCodeSet() {
		return icdCodeSet;
	}

	public void setIcdCodeSet(String icdCodeSet) {
		this.icdCodeSet = icdCodeSet;
	}
}
