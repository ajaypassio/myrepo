package com.avigosolutions.candidateservice.model;

import org.springframework.data.annotation.Transient;

public class DownloadCSVPatient {

	@Transient
	private Integer tempId = 0;

	private String score = "100%";

	private String ranking = "1";

	private String zip;

	/**
	 * @return the tempId
	 */
	public Integer getTempId() {
		return tempId;
	}

	/**
	 * @param tempId the tempId to set
	 */
	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}

	/**
	 * @return the score
	 */
	public String getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(String score) {
		this.score = score;
	}

	/**
	 * @return the ranking
	 */
	public String getRanking() {
		return ranking;
	}

	/**
	 * @param ranking the ranking to set
	 */
	public void setRanking(String ranking) {
		this.ranking = ranking;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip the zip to set
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	

}
