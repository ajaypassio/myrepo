package com.avigosolutions.candidateservice.model;

import java.util.List;

public class GeoCandidate {
	String type = "FeatureCollection";
	
	List<Candidate> features;

	public String getType() {
		return type;
	}
	
	public List<Candidate> getFeatures() {
		return features;
	}

	public GeoCandidate withFeatures(List<Candidate> features) {
		this.features = features;
		return this;
	}
	

}
