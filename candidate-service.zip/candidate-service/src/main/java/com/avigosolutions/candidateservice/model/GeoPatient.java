package com.avigosolutions.candidateservice.model;

import java.util.List;

public class GeoPatient {
	String type = "FeatureCollection";
	
	List<Patient> features;

	public String getType() {
		return type;
	}
	
	public List<Patient> getFeatures() {
		return features;
	}

	public GeoPatient withFeatures(List<Patient> features) {
		this.features = features;
		return this;
	}
}
