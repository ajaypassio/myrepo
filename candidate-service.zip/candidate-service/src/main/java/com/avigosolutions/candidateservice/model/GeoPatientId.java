package com.avigosolutions.candidateservice.model;

import java.util.ArrayList;
import java.util.List;

public class GeoPatientId {
	String type = "PatientIDCollection";
	
	List<String> patientIds = new ArrayList<>();

	public String getType() {
		return type;
	}
	
	public List<String> getPatientIds() {
		return patientIds;
	}

	public GeoPatientId withPatientIds(List<String> patientIds) {
		this.patientIds = patientIds;
		return this;
	}
}
