package com.avigosolutions.candidateservice.model;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Geometry {

	@Override
	public String toString() {
		return "Geometry [type=" + type + ", coordinates=" + coordinates + ", latLong=" + Arrays.toString(latLong)
				+ "]";
	}
	private String type;

	public String getType() {
		return type;
	}

	public Geometry withType(String type) {
		this.type = type;
		return this;
	}
	@JsonIgnore
	private Coordinates coordinates;

	public Coordinates getCoordinates() {
		return coordinates;
	}

	public Geometry withCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
		this.latLong[0] = coordinates.getLongitude();
		this.latLong[1] = coordinates.getLatitude();
		return this;
	}
	
	@JsonProperty("coordinates")
	private double[] latLong = new double[2];

	public double[] getLatLong() {
		return latLong;
	}

}
