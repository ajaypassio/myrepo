package com.avigosolutions.candidateservice.model;

public class LabRecords {
	private String clinicName;
	private String phyName;
	private int year;
	private String testName;
	private String testValue;
	private String testValueStr;
	private String testUnit;
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getTestValue() {
		return testValue;
	}
	public void setTestValue(String testValue) {
		this.testValue = testValue;
	}
	
	@Override
	public String toString() {
		return "LabRecords [clinicName=" + clinicName + ", phyName=" + phyName + ", year=" + year + ", testName="
				+ testName + ", testValue=" + testValue + ", testUnit=" + testUnit + "]";
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getPhyName() {
		return phyName;
	}
	public void setPhyName(String phyName) {
		this.phyName = phyName;
	}
	public String getClinicName() {
		return clinicName;
	}
	public void setClinicName(String clinicName) {
		this.clinicName = clinicName;
	}
	public String getTestUnit() {
		return testUnit;
	}
	public void setTestUnit(String testUnit) {
		this.testUnit = testUnit;
	}
	public String getTestValueStr() {
		return testValueStr;
	}
	public void setTestValueStr(String testValueStr) {
		this.testValueStr = testValueStr;
	}
	

}
