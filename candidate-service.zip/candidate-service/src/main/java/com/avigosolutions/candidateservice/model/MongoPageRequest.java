package com.avigosolutions.candidateservice.model;

public class MongoPageRequest{

	private int pageSize;
	private int pageNumber;
	private long totalRows;
	
	public int getPageSize() {
		return pageSize;
	}
	public MongoPageRequest withPageSize(int pageSize) {
		this.pageSize = pageSize;
		return this;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public MongoPageRequest withPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
		return this;
	}
	public long getTotalRows() {
		return totalRows;
	}
	public MongoPageRequest withTotalRows(long totalRows) {
		this.totalRows = totalRows;
		return this;
	}

}
