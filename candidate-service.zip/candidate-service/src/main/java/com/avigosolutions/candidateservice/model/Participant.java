package com.avigosolutions.candidateservice.model;

import java.util.Map;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Purpose of this class is to use as a POJO/Model to persist in RDBMS
 * 
 * @author jawahar
 *
 */

public class Participant {

	private String firstName = "";
	private String lastName = "";
	private int age;
	private String gender;
	private String address;
	@JsonProperty("zipCode")
	private String zip;
	private String participantId;
	private long trialId;
	private String scoreJSON;
	private String searchName;
	@JsonProperty("emailAddress")
	private String email;
	private String trialName;
	private String contactNumber;
	
	private Long internalId;

	public Long getInternalId() {
		return internalId;
	}

	public void setInternalId(Long internalId) {
		this.internalId = internalId;
	}
	
	public Participant withInternalId(Long internalId) {
		this.internalId = internalId;
		return this;
	}

	private String state;
	private String city;

	public String getState() {
		return state;
	}

	public String getCity() {
		return city;
	}

	public Participant withCity(String city) {
		this.city = city;
		return this;
	}

	public Participant withState(String state) {
		this.state = state;
		return this;
	}

	private Coordinates coordinates;

	private Geometry geometry;

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String name) {
		this.lastName = name;
	}

	public Participant withLastName(String name) {
		this.lastName = name;
		return this;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Participant withAge(int age) {
		this.age = age;
		return this;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Participant withGender(String gender) {
		this.gender = gender;
		return this;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Participant withAddress(String address) {
		this.address = address;
		return this;
	}

	public Participant withAddress(String address1, String address2) {
		if (address1 == null) {
			this.address = address2;
		} else if (address2 == null) {
			this.address = address1;
		} else {
			this.address = address1 + ", " + address2;
		}
		return this;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public Participant withZip(String zip) {
		this.zip = zip;
		return this;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public Participant withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public Coordinates getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
	}

	public Participant withCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
		return this;
	}

	public Geometry getGeometry() {
		return geometry;
	}

	public void setGeometry(Geometry geometry) {
		this.geometry = geometry;
	}

	public Participant withGeometry(Geometry geometry) {
		this.geometry = geometry;
		return this;
	}

	public long getTrialId() {
		return trialId;
	}

	public Participant withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public String getFirstName() {
		return firstName;
	}

	public Participant withFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}

	// Split first name and last name
	public Participant withName(String name) {
		if (name != null) {
			String names[] = name.split(" ");
			this.firstName = names[0];
			for (int i = 1; i < names.length; i++) {
				this.lastName = this.lastName + names[i] + " ";
			}
			this.lastName = this.lastName != null ? this.lastName : this.lastName.trim();
		}
		return this;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((participantId == null) ? 0 : participantId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Participant other = (Participant) obj;
		if (participantId == null) {
			if (other.participantId != null)
				return false;
		} else if (!participantId.equals(other.participantId)) {
			return false;
		}
		return true;
	}

	public String getScoreJSON() {
		return scoreJSON;
	}

	public Participant withScoreJSON(Map<String, String> scoreJSON) {
		// Remove unnecessary quotes
		String json = ((new JSONObject(scoreJSON).toString().replace("\\\"", "\"")).replace("\"{", "{")).replace("}\"",
				"}");
		this.scoreJSON = json;
		return this;
	}

	public Participant withScoreJSON(String scoreJSON) {
		this.scoreJSON = scoreJSON;
		return this;
	}

	public String getSearchName() {
		return searchName;
	}

	public Participant withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public String getEmail() {
		return email;
	}

	public Participant withEmail(String email) {
		this.email = email;
		return this;
	}

	public String getTrialName() {
		return trialName;
	}

	public Participant withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public Participant withContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
		return this;
	}

}
