package com.avigosolutions.candidateservice.model;

import java.util.ArrayList;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Patient {

	private String firstName;
	private String lastName;
	private int age;
	private String gender;
	private String addressLine1;
	
	private String addressLine2;
	private String zip;
	private String patient_id;

	@Transient
	private Integer tempId = 0;
	private String email;
	private String phoneNumber;

	private String state;
	private String city;

	private float lat;

	private float lng;
	private String eid;
	private String stateCity;
	private String race;
	private String ethnicity;

	public String getState() {
		return state;
	}

	public float getLng() {
		return lng;
	}

	public void setLng(float lng) {
		this.lng = lng;
		withLng(lng);
	}

	public Patient withLng(float lng) {
		this.lng = lng;
		coordinates = new Coordinates().withLatitude(lat).withLongitude(lng);
		geometry = new Geometry().withType("Point").withCoordinates(coordinates);
		return this;
	}

	public float getLat() {
		return lat;
	}

	public Patient withLat(float lat) {
		this.lat = lat;
		return this;
	}

	public String getCity() {
		return city;
	}

	public Patient withCity(String city) {
		this.city = city;
		return this;
	}

	public Patient withState(String state) {
		this.state = state;
		return this;
	}
	
	public String getEid() {
		return eid;
	}

	public Patient withEid(String eid) {
		this.eid = eid;
		return this;
	}
	
	public String getStateCity() {
		return stateCity;
	}

	public Patient withStateCity(String stateCity) {
		this.stateCity = stateCity;
		return this;
	}
	
	public String getRace() {
		return race;
	}

	public Patient withRace(String race) {
		this.race = race;
		return this;
	}

	public String getEthnicity() {
		return ethnicity;
	}

	public Patient withEthnicity(String ethnicity) {
		this.ethnicity = ethnicity;
		return this;
	}
	// private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	@JsonIgnore
	private Coordinates coordinates;

	@Autowired
	//@JsonIgnore
	private Geometry geometry;

	@JsonIgnore

	private Map<String, String> criteria;

	@Transient
	private String scoreJSON;
	
	private String score;
	
	private String ranking;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty("labRecords")
	private ArrayList<LabRecords> labRecords;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty("diagnosisRecords")
	private ArrayList<DiagnosisRecords> diagnosisRecords;

	// default ctor needed otherwise throws error when objs are returned as part of
	// REST
	public Patient() {

	}

	// This ctor is needed to populate zip (and hence the Geometry - lat/long).
	// See:
	// https://stackoverflow.com/questions/14624982/how-exactly-does-spring-data-mongodb-handle-constructors-when-rehydrating-object
	// explanation from Oliver Gierke
	@PersistenceConstructor
	public Patient(Float lng, Float lat) {
		if(lng==null || lng.isNaN()) {
			lng=0F;
		}
		if(lat==null || lat.isNaN()) {
			lat=0F;
		}
		this.lng = lng;
		this.lat = lat;

		withLng(lng);
	}

	public Coordinates getCoordinates() {
		return coordinates;
	}

	public Geometry getGeometry() {
		return geometry;
	}
	
	public Patient withGeometry(Geometry geometry) {
		this.geometry=geometry;
		return this;
	}

	public String getPatientId() {
		return patient_id;
	}

	// @JsonSetter("patient_id")
	public void setPatientId(String patientId) {
		this.patient_id = patientId;
	}

	public Patient withPatientId(String patientId) {
		this.patient_id = patientId;
		return this;
	}

	public Integer getTempId() {
		return tempId;
	}

	public void setTempId(Integer tempId) {
		this.tempId = tempId;
	}

	public Patient withTempId(Integer tempId) {
		this.tempId = tempId;
		return this;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Patient withAge(int age) {
		this.age = age;
		return this;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Patient withGender(String gender) {
		this.gender = gender;
		return this;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
		withZip(zip);
	}

	public Patient withZip(String zip) {
		// Collection has lat long details
		/*
		 * if (zip != null) { if (this.zip == null) this.zip = zip; List<Place>
		 * listPlace = PostalDbFactory.getPostalDb().byPostalCode(this.zip); coordinates
		 * = new Coordinates() .withLatitude(listPlace != null && listPlace.size() > 0 ?
		 * listPlace.get(0).getLatitude() : 0.0) .withLongitude(listPlace != null &&
		 * listPlace.size() > 0 ? listPlace.get(0).getLongitude() : 0.0); geometry = new
		 * Geometry().withType("Point").withCoordinates(coordinates);
		 * 
		 * } else System.err.println("Patient withZipcode geometry null zip");
		 */
		this.zip = zip;
		return this;
	}

	public Map<String, String> getCriteria() {
		return criteria;
	}

	public void setCriteria(Map<String, String> criteria) {
		this.criteria = criteria;
	}

	public Patient withCriteria(Map<String, String> criteria) {
		this.criteria = criteria;
		return this;
	}

	@JsonProperty("diagnosisRecords")
	public ArrayList<DiagnosisRecords> getDiagnosisRecords() {
		return diagnosisRecords;
	}

	@JsonProperty("diagnosisRecords")
	public void setDiagnosisRecords(ArrayList<DiagnosisRecords> diagnosisRecords) {
		this.diagnosisRecords = diagnosisRecords;
	}

	@JsonProperty("labRecords")
	public ArrayList<LabRecords> getLabRecords() {
		return labRecords;
	}

	@JsonProperty("labRecords")
	public void setLabRecords(ArrayList<LabRecords> labRecords) {
		this.labRecords = labRecords;
	}

	public String getScoreJSON() {
		return scoreJSON;
	}

	public Patient withScoreJSON(String scoreJSON) {
		this.scoreJSON = scoreJSON;
		return this;
	}

	public Patient withScoreJSONMap(Map<String, String> scoreJSON) {
		// Remove unnecessary quotes
		String json = ((new JSONObject(scoreJSON).toString().replace("\\\"", "\"")).replace("\"{", "{")).replace("}\"",
				"}");
		this.scoreJSON = json;
		return this;
	}

	@Override
	public String toString() {
		return "Patient [name=" + firstName + ", age=" + age + ", gender=" + gender + ", address=" + addressLine1
				+ ", zip=" + zip + ", patient_id=" + patient_id + ", criteria=" + criteria + ", labRecords="
				+ labRecords + "]";
	}

	public String getFirstName() {
		return firstName;
	}

	public Patient withFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}

	public String getLastName() {
		return lastName;
	}

	public Patient withLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}

	public String getEmail() {
		return email;
	}

	public Patient withEmail(String email) {
		this.email = email;
		return this;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public Patient withPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	
	public String getAddressLine1() {
		return addressLine1;
	}

	
	public Patient withAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
		return this;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public Patient withAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
		return this;
	}

	/**
	 * @return the score
	 */
	public String getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public Patient withScore(String score) {
		this.score = score;
		return this;
	}

	/**
	 * @return the ranking
	 */
	public String getRanking() {
		return ranking;
	}

	/**
	 * @param ranking the ranking to set
	 */
	public Patient withRanking(String ranking) {
		this.ranking = ranking;
		return this;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((patient_id == null) ? 0 : patient_id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		if (patient_id == null) {
			if (other.patient_id != null)
				return false;
		} else if (!patient_id.equals(other.patient_id))
			return false;
		return true;
	}
}
