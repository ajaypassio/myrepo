package com.avigosolutions.candidateservice.model;

import java.util.ArrayList;

public class PatientDetails {
	private Patient patient;
	private ArrayList<LabRecords> labRecords;
	
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
		labRecords = patient.getLabRecords();
	}
	public PatientDetails withPatient(Patient patient) {
		this.patient = patient;
		this.labRecords = patient.getLabRecords();
		return this;
	}
	
	public ArrayList<LabRecords> getLabRecords() {
		return labRecords;
	}
	//@JsonProperty("lab-records")
	public void setLabRecords(ArrayList<LabRecords> labRecords) {
		this.labRecords = labRecords;
	}
	
	@Override
	public String toString() {
		return "PatientDetails [patient=" + patient + ", labRecords=" + labRecords + "]";
	}

}
