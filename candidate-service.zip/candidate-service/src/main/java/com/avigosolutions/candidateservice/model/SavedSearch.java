package com.avigosolutions.candidateservice.model;

import java.util.Date;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

//@Document(collection="savedSearchTest")
public class SavedSearch {

	@Id
	private String id;

	private String searchName;

	private long trialId;

	private Date createDate;
	private Date updateDate;
	// private JsonNode criteriaStr;
	private String criteriaStr;
	private String trialCriteriaStr;

	// private CriteriaCounts criteriaCounts;
	private Map<String, Integer> criteriaNameToCountMap;
	// This collection only holds patient IDs, For now not using it
	private GeoPatientId geoPatientId;

	@Transient
	private GeoPatient geoPatient;

	@Transient
	private MongoPageRequest mongoPageRequest;

	@Transient
	private String jobStatus;
	
	@Transient
	private String crmStatus;
	
	private String trialName;
	
	private Integer totalCandidates;

	public Map<String, Integer> getCriteriaNameToCountMap() {
		return criteriaNameToCountMap;
	}

	public SavedSearch withCriteriaNameToCountMap(Map<String, Integer> criteriaNameToCountMap) {
		this.criteriaNameToCountMap = criteriaNameToCountMap;
		return this;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSearchName() {
		return searchName;
	}

	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}

	public SavedSearch withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public long getTrialId() {
		return trialId;
	}

	public void setTrialId(long trialId) {
		this.trialId = trialId;
	}

	public SavedSearch withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public GeoPatientId getGeoPatientId() {
		return geoPatientId;
	}

	public SavedSearch withGeoPatientId(GeoPatientId geoPatientId) {
		this.geoPatientId = geoPatientId;
		return this;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	// public CriteriaCounts getCriteriaCounts() {
	// return criteriaCounts;
	// }
	//
	// public void setCriteriaCounts(CriteriaCounts criteriaCounts) {
	// this.criteriaCounts = criteriaCounts;
	// }
	//
	// public SavedSearch withCriteriaCounts(CriteriaCounts criteriaCounts) {
	// this.criteriaCounts = criteriaCounts;
	// return this;
	// }

	// @Override
	// public String toString() {
	// return "SavedSearch [id=" + id + ", searchName=" + searchName + ", trialId="
	// + trialId + ", criteriaCounts="
	// + criteriaCounts + "]";
	// }
	public String getCriteriaStr() {
		return criteriaStr;
	}

	public void setCriteriaStr(String criteriaStr) {
		this.criteriaStr = criteriaStr;
	}

	public SavedSearch withCriteriaStr(String criteriaStr) {
		this.criteriaStr = criteriaStr;
		return this;
	}

	public GeoPatient getGeoPatient() {
		return geoPatient;
	}

	public SavedSearch withGeoPatient(GeoPatient geoPatient) {
		this.geoPatient = geoPatient;
		return this;
	}

	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}

	public SavedSearch withMongoPageRequest(MongoPageRequest pageable) {
		this.mongoPageRequest = pageable;
		return this;
	}

	public String getTrialCriteriaStr() {
		return trialCriteriaStr;
	}

	public SavedSearch withTrialCriteriaStr(String trialCriteriaStr) {
		this.trialCriteriaStr = trialCriteriaStr;
		return this;
	}

	public String getTrialName() {
		return trialName;
	}

	public SavedSearch withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public SavedSearch withJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
		return this;
	}

	@Override
	public String toString() {
		return "SavedSearch [id=" + id + ", searchName=" + searchName + ", trialId=" + trialId + ", createDate="
				+ createDate + ", updateDate=" + updateDate + ", criteriaStr=" + criteriaStr + ", trialCriteriaStr="
				+ trialCriteriaStr + ", criteriaNameToCountMap=" + criteriaNameToCountMap + ", geoPatientId="
				+ geoPatientId + ", geoPatient=" + geoPatient + ", mongoPageRequest=" + mongoPageRequest
				+ ", jobStatus=" + jobStatus + ", trialName=" + trialName + ", totalCandidates=" + totalCandidates
				+ "]";
	}

	public String getCrmStatus() {
		return crmStatus;
	}

	public void setCrmStatus(String crmStatus) {
		this.crmStatus = crmStatus;
	}

	public Integer getTotalCandidates() {
		return totalCandidates;
	}

	public void setTotalCandidates(Integer totalCandidates) {
		this.totalCandidates = totalCandidates;
	}
	
	public SavedSearch withTotalCandidates(Integer totalCandidates) {
		this.totalCandidates = totalCandidates;
		return this;
	}

}
