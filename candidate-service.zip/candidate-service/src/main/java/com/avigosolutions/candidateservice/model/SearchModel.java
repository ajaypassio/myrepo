package com.avigosolutions.candidateservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchModel {

	private long trialId;

	private String trailJSON;

	private MongoPageRequest mongoPageRequest;
	
	private String difference = "false";

	private boolean hasAggregation = false;
	
	@JsonProperty("hasExport")
	private boolean hasExport = false;

	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}

	public SearchModel withMongoPageRequest(MongoPageRequest pageable) {
		this.mongoPageRequest = pageable;
		return this;
	}

	public long getTrialId() {
		return trialId;
	}

	public SearchModel withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public String getTrailJSON() {
		return trailJSON;
	}

	public SearchModel withTrailJSON(String trailJSON) {
		this.trailJSON = trailJSON;
		return this;
	}

	public boolean getHasAggregation() {
		return hasAggregation;
	}

	public SearchModel withHasAggregation(boolean hasAggregation) {
		this.hasAggregation = hasAggregation;
		return this;
	}

	public String getDifference() {
		return difference;
	}
	
	public SearchModel withGetDifference(String difference) {
		this.difference = difference;
		return this;
	}

	/**
	 * @return the hasExport
	 */
	public boolean isHasExport() {
		return hasExport;
	}

	/**
	 * @param hasExport the hasExport to set
	 */
	public void setHasExport(boolean hasExport) {
		this.hasExport = hasExport;
	}
	
}
