
package com.avigosolutions.candidateservice.mongodb.querybuilder.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "criteriaId",
    "score",
    "passCriteria"
})
public class Criterium {

    @JsonProperty("criteriaId")
    private String id;
    @JsonProperty("score")
    private String score;
    @JsonProperty("passCriteria")
    private Boolean passCriteria;
    
    @JsonProperty("criteriaId")
    public String getId() {
        return id;
    }

    @JsonProperty("criteriaId")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("score")
    public String getScore() {
        return score;
    }

    @JsonProperty("score")
    public void setScore(String score) {
        this.score = score;
    }

    @JsonProperty("passCriteria")
    public Boolean getPassCriteria() {
        return passCriteria;
    }

    @JsonProperty("passCriteria")
    public void setPassCriteria(Boolean passCriteria) {
        this.passCriteria = passCriteria;
    }

}
