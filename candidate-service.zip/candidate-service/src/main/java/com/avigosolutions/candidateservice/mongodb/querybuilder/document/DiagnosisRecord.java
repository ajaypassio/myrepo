
package com.avigosolutions.candidateservice.mongodb.querybuilder.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dateOfService",
    "icdCode",
    "icdCodeSet"
})
public class DiagnosisRecord {

    @JsonProperty("dateOfService")
    private String dateOfService;
    @JsonProperty("icdCode")
    private String icdCode;
    @JsonProperty("icdCodeSet")
    private String icdCodeSet;
   
    @JsonProperty("dateOfService")
    public String getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    @JsonProperty("icdCode")
    public String getIcdCode() {
        return icdCode;
    }

    @JsonProperty("icdCode")
    public void setIcdCode(String icdCode) {
        this.icdCode = icdCode;
    }

    @JsonProperty("icdCodeSet")
    public String getIcdCodeSet() {
        return icdCodeSet;
    }

    @JsonProperty("icdCodeSet")
    public void setIcdCodeSet(String icdCodeSet) {
        this.icdCodeSet = icdCodeSet;
    }

}
