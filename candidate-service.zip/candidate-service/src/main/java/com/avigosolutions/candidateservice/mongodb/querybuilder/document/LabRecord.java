
package com.avigosolutions.candidateservice.mongodb.querybuilder.document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "clinicAddress2",
    "dateOfService",
    "clinicAddress1",
    "testValue",
    "testValueStr",
    "clinicZip",
    "clinicCity",
    "testName",
    "phyName",
    "clinicState",
    "testUnit",
    "clinicName",
    "phyNPI"
})
public class LabRecord {

    @JsonProperty("clinicAddress2")
    private String clinicAddress2;
    @JsonProperty("dateOfService")
    private String dateOfService;
    @JsonProperty("clinicAddress1")
    private String clinicAddress1;
    @JsonProperty("testValue")
    private Double testValue;
    @JsonProperty("testValueStr")
    private String testValueStr;
    @JsonProperty("clinicZip")
    private String clinicZip;
    @JsonProperty("clinicCity")
    private String clinicCity;
    @JsonProperty("testName")
    private String testName;
    @JsonProperty("phyName")
    private String phyName;
    @JsonProperty("clinicState")
    private String clinicState;
    @JsonProperty("testUnit")
    private String testUnit;
    @JsonProperty("clinicName")
    private String clinicName;
    @JsonProperty("phyNPI")
    private String phyNPI;
    
    @JsonProperty("clinicAddress2")
    public String getClinicAddress2() {
        return clinicAddress2;
    }

    @JsonProperty("clinicAddress2")
    public void setClinicAddress2(String clinicAddress2) {
        this.clinicAddress2 = clinicAddress2;
    }

    @JsonProperty("dateOfService")
    public String getDateOfService() {
        return dateOfService;
    }

    @JsonProperty("dateOfService")
    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    @JsonProperty("clinicAddress1")
    public String getClinicAddress1() {
        return clinicAddress1;
    }

    @JsonProperty("clinicAddress1")
    public void setClinicAddress1(String clinicAddress1) {
        this.clinicAddress1 = clinicAddress1;
    }

    @JsonProperty("testValue")
    public Double getTestValue() {
        return testValue;
    }

    @JsonProperty("testValue")
    public void setTestValue(Double testValue) {
        this.testValue = testValue;
    }

    @JsonProperty("clinicZip")
    public String getClinicZip() {
        return clinicZip;
    }

    @JsonProperty("clinicZip")
    public void setClinicZip(String clinicZip) {
        this.clinicZip = clinicZip;
    }

    @JsonProperty("clinicCity")
    public String getClinicCity() {
        return clinicCity;
    }

    @JsonProperty("clinicCity")
    public void setClinicCity(String clinicCity) {
        this.clinicCity = clinicCity;
    }

    @JsonProperty("testName")
    public String getTestName() {
        return testName;
    }

    @JsonProperty("testName")
    public void setTestName(String testName) {
        this.testName = testName;
    }

    @JsonProperty("phyName")
    public String getPhyName() {
        return phyName;
    }

    @JsonProperty("phyName")
    public void setPhyName(String phyName) {
        this.phyName = phyName;
    }

    @JsonProperty("clinicState")
    public String getClinicState() {
        return clinicState;
    }

    @JsonProperty("clinicState")
    public void setClinicState(String clinicState) {
        this.clinicState = clinicState;
    }

    @JsonProperty("testUnit")
    public String getTestUnit() {
        return testUnit;
    }

    @JsonProperty("testUnit")
    public void setTestUnit(String testUnit) {
        this.testUnit = testUnit;
    }

    @JsonProperty("clinicName")
    public String getClinicName() {
        return clinicName;
    }

    @JsonProperty("clinicName")
    public void setClinicName(String clinicName) {
        this.clinicName = clinicName;
    }

    @JsonProperty("phyNPI")
    public String getPhyNPI() {
        return phyNPI;
    }

    @JsonProperty("phyNPI")
    public void setPhyNPI(String phyNPI) {
        this.phyNPI = phyNPI;
    }

	public String getTestValueStr() {
		return testValueStr;
	}

	public void setTestValueStr(String testValueStr) {
		this.testValueStr = testValueStr;
	}

}
