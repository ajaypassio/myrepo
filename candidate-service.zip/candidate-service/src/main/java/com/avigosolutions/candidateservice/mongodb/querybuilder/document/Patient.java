
package com.avigosolutions.candidateservice.mongodb.querybuilder.document;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "addressLine2",
    "addressLine1",
    "lng",
    "cellPhoneNumber",
    "city",
    "zip",
    "middleName",
    "dateOfBirth",
    "state",
    "phoneNumber",
    "criteria",
    "email",
    "labRecords",
    "_dev_or_prod",
    "diagnosisRecords",
    "lat",
    "distance",
    "firstName",
    "gender",
    "age",
    "patient_id",
    "lastName",
    "country"
})
public class Patient {

    @JsonProperty("addressLine2")
    private String addressLine2;
    @JsonProperty("addressLine1")
    private String addressLine1;
    @JsonProperty("lng")
    private Double lng;
    @JsonProperty("cellPhoneNumber")
    private String cellPhoneNumber;
    @JsonProperty("city")
    private String city;
    @JsonProperty("zip")
    private String zip;
    @JsonProperty("middleName")
    private String middleName;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("state")
    private String state;
    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("criteria")
    private Criterium criteria = null;
    @JsonProperty("email")
    private String email;
    @JsonProperty("labRecords")
    private List<LabRecord> labRecords = null;
    @JsonProperty("_dev_or_prod")
    private String devOrProd;
    @JsonProperty("diagnosisRecords")
    private List<DiagnosisRecord> diagnosisRecords = null;
    @JsonProperty("lat")
    private Double lat;
    @JsonProperty("distance")
    private String distance;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("age")
    private Integer age;
    @JsonProperty("patient_id")
    private String patientId;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("country")
    private String country;
   
    @JsonProperty("addressLine2")
    public String getAddressLine2() {
        return addressLine2;
    }

    @JsonProperty("addressLine2")
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    @JsonProperty("addressLine1")
    public String getAddressLine1() {
        return addressLine1;
    }

    @JsonProperty("addressLine1")
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    @JsonProperty("lng")
    public Double getLng() {
        return lng;
    }

    @JsonProperty("lng")
    public void setLng(Double lng) {
        this.lng = lng;
    }

    @JsonProperty("cellPhoneNumber")
    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }

    @JsonProperty("cellPhoneNumber")
    public void setCellPhoneNumber(String cellPhoneNumber) {
        this.cellPhoneNumber = cellPhoneNumber;
    }

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("zip")
    public String getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(String zip) {
        this.zip = zip;
    }

    @JsonProperty("middleName")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("dateOfBirth")
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    @JsonProperty("dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phoneNumber")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("criteria")
    public Criterium getCriteria() {
        return criteria;
    }

    @JsonProperty("criteria")
    public void setCriteria(Criterium criteria) {
        this.criteria = criteria;
    }

    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("labRecords")
    public List<LabRecord> getLabRecords() {
        return labRecords;
    }

    @JsonProperty("labRecords")
    public void setLabRecords(List<LabRecord> labRecords) {
        this.labRecords = labRecords;
    }

    @JsonProperty("_dev_or_prod")
    public String getDevOrProd() {
        return devOrProd;
    }

    @JsonProperty("_dev_or_prod")
    public void setDevOrProd(String devOrProd) {
        this.devOrProd = devOrProd;
    }

    @JsonProperty("diagnosisRecords")
    public List<DiagnosisRecord> getDiagnosisRecords() {
        return diagnosisRecords;
    }

    @JsonProperty("diagnosisRecords")
    public void setDiagnosisRecords(List<DiagnosisRecord> diagnosisRecords) {
        this.diagnosisRecords = diagnosisRecords;
    }

    @JsonProperty("lat")
    public Double getLat() {
        return lat;
    }

    @JsonProperty("lat")
    public void setLat(Double lat) {
        this.lat = lat;
    }

    @JsonProperty("distance")
    public String getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(String distance) {
        this.distance = distance;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("age")
    public Integer getAge() {
        return age;
    }

    @JsonProperty("age")
    public void setAge(Integer age) {
        this.age = age;
    }

    @JsonProperty("patient_id")
    public String getPatientId() {
        return patientId;
    }

    @JsonProperty("patient_id")
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("country")
    public String getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(String country) {
        this.country = country;
    }

}
