package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container;

import org.springframework.data.mongodb.core.query.Criteria;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class AbstractContainer implements Container {

	@JsonIgnore
	private Criteria preUnwindContainerCriteria;
	
	@JsonIgnore
	private Criteria containerCriteria;
	
	@JsonProperty("containerType")
	private ContainerType containerType;
	
	@JsonProperty("logicalOperator")
	private LogicalOperator logicalOperator;
	
	protected AbstractContainer() {}
	
	protected AbstractContainer(ContainerType containerType) {
		this.containerType = containerType;
	}

	public Criteria getPreUnwindContainerCriteria() {
		return preUnwindContainerCriteria;
	}

	public void setPreUnwindContainerCriteria(Criteria preUnwindContainerCriteria) {
		this.preUnwindContainerCriteria = preUnwindContainerCriteria;
	}

	@Override
	public Criteria getContainerCriteria() {
		return containerCriteria;
	}

	public void setContainerCriteria(Criteria containerCriteria) {
		this.containerCriteria = containerCriteria;
	}

	public void setLogicalOperator(LogicalOperator logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	@Override
	public LogicalOperator getLogicalOperator() {
		return logicalOperator;
	}

	@Override
	public ContainerType getContainerType() {
		return containerType;
	}

	public void setContainerType(ContainerType containerType) {
		this.containerType = containerType;
	}
	
}