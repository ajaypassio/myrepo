package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container;

import java.util.LinkedList;
import java.util.Queue;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
	"containerType",
	"logicalOperator",
	"containerQueue"
})
public class BaseContainer<T extends AbstractContainer> extends AbstractContainer {

	protected BaseContainer(ContainerType containerType) {
		super(containerType);
	}
	
	private Queue<T> containerQueue = new LinkedList<>();

	protected Queue<T> getContainerQueue() {
		return containerQueue;
	}

	@JsonIgnore
	@Override
	public boolean isEmpty() {
		return containerQueue.isEmpty();
	}

	@Override
	public int size() {
		return containerQueue.size();
	}

	public boolean offer(T container) {
		return containerQueue.offer(container);
	}

	public T poll() {
		return containerQueue.poll();
	}

	public T peek() {
		return containerQueue.peek();
	}

}
