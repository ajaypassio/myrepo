package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container;

import org.springframework.data.mongodb.core.query.Criteria;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.LogicalOperator;

public interface Container {

	ContainerType getContainerType();
	
	LogicalOperator getLogicalOperator();
	
	Criteria getContainerCriteria();
	
	boolean isEmpty();
	
	int size();
}
