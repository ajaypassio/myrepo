package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container;

import java.util.Queue;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("eqcLogicalGroupContainer")
@JsonTypeInfo(include=As.WRAPPER_OBJECT, use=JsonTypeInfo.Id.NAME)
@JsonIgnoreProperties(value = {"containerType"})
public class EQCLogicalGroupContainerIE extends BaseContainer<ExpressionQueueContainerIE> {

	public EQCLogicalGroupContainerIE(ContainerType cType) {
		super(cType);
		setLogicalOperator(LogicalOperator.AND);
	}
	
	@JsonProperty("eQCLGCContainerQueue")
	@Override
	protected Queue<ExpressionQueueContainerIE> getContainerQueue() {
		return super.getContainerQueue();
	}

	@Override
	public String toString() {
		return "EQCLogicalGroupContainerIE [containerCriteria=" + getContainerCriteria() + ", logicalOperator="
				+ getLogicalOperator() + ", containerType=" + getContainerType() + ", containerQueue="
				+ getContainerQueue() + "]";
	}
	
	public EQCLogicalGroupContainerIE clone() throws CloneNotSupportedException {
		EQCLogicalGroupContainerIE clone = new EQCLogicalGroupContainerIE(this.getContainerType());
		clone.setContainerCriteria(this.getContainerCriteria());
		clone.setLogicalOperator(this.getLogicalOperator());
		clone.setPreUnwindContainerCriteria(this.getPreUnwindContainerCriteria());
		
		return clone;
	}
}
