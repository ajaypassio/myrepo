package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container;

import java.util.Queue;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("sccLogicalGroupContainer")
@JsonTypeInfo(include=As.WRAPPER_OBJECT, use=JsonTypeInfo.Id.NAME)
@JsonIgnoreProperties(value = {"containerType"})
public class SCCLogicalGroupContainerIE extends BaseContainer<SearchCriteriaContainerIE> {

	public SCCLogicalGroupContainerIE(ContainerType containerType) {
		super(containerType);
		setLogicalOperator(LogicalOperator.AND);
	}
	
	@JsonProperty("sCCLGContainerQueue")
	@Override
	protected Queue<SearchCriteriaContainerIE> getContainerQueue() {
		return super.getContainerQueue();
	}

	@Override
	public String toString() {
		return "SCCLogicalGroupContainerIE [containerType=" + getContainerType() + ", containerCriteria="
				+ getContainerCriteria() + ", logicalOperator=" + getLogicalOperator() + ", containerQueue="
				+ getContainerQueue() + "]";
	}
	
}
