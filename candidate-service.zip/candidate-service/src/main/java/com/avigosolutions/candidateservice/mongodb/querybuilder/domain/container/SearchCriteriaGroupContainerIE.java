package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container;

import java.util.Queue;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("searchCriteriaGroup")
@JsonTypeInfo(include=As.WRAPPER_OBJECT, use=JsonTypeInfo.Id.NAME)
public class SearchCriteriaGroupContainerIE extends BaseContainer<SCCLogicalGroupContainerIE> {

	public SearchCriteriaGroupContainerIE(ContainerType containerType) {
		super(containerType);
		setLogicalOperator(LogicalOperator.OR);
	}

	@JsonProperty("sCGContainerQueue")
	@Override
	protected Queue<SCCLogicalGroupContainerIE> getContainerQueue() {
		return super.getContainerQueue();
	}
	
	@Override
	public String toString() {
		return "SearchCriteriaGroupContainerIE [containerType=" + getContainerType()
				+ ", containerCriteria=" + getContainerCriteria() + ", logicalOperator="
				+ getLogicalOperator() + ", containerQueue=" + getContainerQueue() + "]";
	}

}
