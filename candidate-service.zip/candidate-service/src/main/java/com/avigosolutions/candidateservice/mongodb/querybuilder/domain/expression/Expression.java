package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Expression {

	@JsonProperty("leftOperand")
	private Operand<?> leftOperand;
	
	@JsonProperty("operator")
	private Operator operator;
	
	@JsonProperty("rightOperand")
	private Operand<?> rightOperand;
	
	
	public Expression() {
		//default constructor
	}

	public <T, E> Expression(Operand<T> leftOperand, Operator operator, Operand<E> rightOperand) {
		this.leftOperand = leftOperand;
		this.operator = operator;
		this.rightOperand = rightOperand;
	}

	public Operand<?> getLeftOperand() {
		return leftOperand;
	}

	public Operator getOperator() {
		return operator;
	}

	public Operand<?> getRightOperand() {
		return rightOperand;
	}

	public Expression setLeftOperand(Operand<?> leftOperand) {
		this.leftOperand = leftOperand;
		return this;
	}

	public Expression setOperator(Operator operator) {
		this.operator = operator;
		return this;
	}

	public Expression setRightOperand(Operand<?> rightOperand) {
		this.rightOperand = rightOperand;
		return this;
	}

	@Override
	public String toString() {
		return "Expression [leftOperand=" + leftOperand + ", operator=" + operator.getOpString() + ", rightOperand="
				+ rightOperand + "]";
	}

}
