package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression;

import org.springframework.data.mongodb.core.query.Criteria;

public enum LogicalOperator implements Operator {

	AND("$and", "andOperator", Criteria[].class, 1), OR("$or", "orOperator", Criteria[].class, 0),
	NOT("$not", "not", Criteria[].class, 2);

	private String methodName;
	private String opString;
	private Class<?> argClass;
	private int precedence;

	private LogicalOperator(String opString, String methodName, Class<?> argClass, int precedence) {
		this.opString = opString;
		this.methodName = methodName;
		this.argClass = argClass;
		this.precedence = precedence;
	}

	@Override
	public String getOpString() {
		return opString;
	}

	@Override
	public String getMethodName() {
		return methodName;
	}

	@Override
	public OperatorType getType() {
		return OperatorType.LOGICAL;
	}

	public Class<?> getArgClass() {
		return argClass;
	}

	@Override
	public int getPrecedence() {
		return precedence;
	}

}
