package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonValue;

public class Operand<T> {

	private T value;
	
	public Operand(T value) {
		this.value = value;
	}

	@JsonValue
	public T getValue() {
		return value;
	}
	
	@JsonIgnore
	public Class<?> getType() {
		return value.getClass();
	}

	@Override
	public String toString() {
		return "Operand [value=" + value + "]";
	}
	
}
