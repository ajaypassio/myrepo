package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression;

public interface Operator {

	String getMethodName();
	
	String getOpString();
	
	OperatorType getType();
	
	Class<?> getArgClass();
	
	default int getPrecedence() {
		return 0;
	}
}
