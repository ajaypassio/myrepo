package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression;

public enum OperatorType {

	COMPARISON, LOGICAL, ARRAY, ELEMENT, AGGREGATION_PIPELINE;
}
