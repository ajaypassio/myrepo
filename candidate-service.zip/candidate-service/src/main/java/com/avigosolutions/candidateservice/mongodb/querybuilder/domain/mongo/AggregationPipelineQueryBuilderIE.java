package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo;

import java.lang.reflect.InvocationTargetException;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.SkipOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.AbstractContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.BaseContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType.ModuleName;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ExpressionQueueContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Expression;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Operand;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Operator;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor.DocumentFieldHelper;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor.DocumentFieldHelper.FieldExpressionComposite;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor.DocumentFieldIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor.ProcessorIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.util.RuntimeHelperIE;

public abstract class AggregationPipelineQueryBuilderIE<R> implements PipelineQueryBuilderIE<R> {

	/** 1. Used as a queue for unwind and post-unwind match, group, project aggregation operations
	 *  2. used as a stack for pre-unwind match/elemMatch aggregation operation
	 *  3. Processed as a queue when building pipeline operations
	 */
	private static final ThreadLocal<Deque<AggregationOperation>> aggregationPipelineTL = ThreadLocal
			.withInitial(LinkedList::new);
	
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	@Qualifier("fieldProcessorIE")
	private ProcessorIE<String, DocumentFieldIE> processorIE;
	
	@Override
	public List<R> build(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			Pageable pageRequestData, String collectionName) {
		Map<String, AggregationOperation> unwindOperationMap = new TreeMap<>((s1, s2) -> s1.length() - s2.length());		
		processContainer(searchCriteriaGroupContainer, unwindOperationMap, null, null);
		createPreUnwindMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		if(!CollectionUtils.isEmpty(unwindOperationMap)) {
			createMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		}
		createGroupsAndProjections(searchCriteriaGroupContainer, collectionName);
		return getResults(buildAggregation(pageRequestData), collectionName);
	}
	
	@Override
	public List<String> buildForId(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			Pageable pageRequestData, String collectionName) {
		Map<String, AggregationOperation> unwindOperationMap = new TreeMap<>((s1, s2) -> s1.length() - s2.length());		
		processContainer(searchCriteriaGroupContainer, unwindOperationMap, null, null);
		createPreUnwindMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		if(!CollectionUtils.isEmpty(unwindOperationMap)) {
			createMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		}
		createGroupsAndProjectionsForId(searchCriteriaGroupContainer);
		return getResultsForId(buildAggregation(pageRequestData), collectionName);
	}
	
	@Override
	public Long count(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			String collectionName) {
		Map<String, AggregationOperation> unwindOperationMap = new TreeMap<>((s1, s2) -> s1.length() - s2.length());		
		processContainer(searchCriteriaGroupContainer, unwindOperationMap, null, null);
		createPreUnwindMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		if(!CollectionUtils.isEmpty(unwindOperationMap)) {
			createMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		}
		createGroupsAndProjectionsForCount(searchCriteriaGroupContainer);
		return 0L;
	}
	
	protected abstract List<R> getResults(Aggregation agg, String collectionName);
	
	protected abstract List<String> getResultsForId(Aggregation agg, String collectionName);
	
	protected abstract Long getCount(Aggregation agg, String collectionName);
	
	private Aggregation buildAggregation(Pageable pageRequestData) {
		Queue<AggregationOperation> pipeline = addPagination(pageRequestData);
		AggregationOperation[] pipelineArr = pipeline.toArray(new AggregationOperation[pipeline.size()]);
		
		return Aggregation.newAggregation(pipelineArr).
				withOptions((Aggregation.newAggregationOptions().allowDiskUse(true).build()));
	}
	
	private Queue<AggregationOperation> addPagination(Pageable pagination) {
		Queue<AggregationOperation> pipeline = aggregationPipelineTL.get();
		if(pagination != null) {
			pipeline.add(new SkipOperation((long)(pagination.getPageNumber() * pagination.getPageSize())));
			pipeline.add(new LimitOperation((long)pagination.getPageSize()));
		}
		return pipeline;
	}
	
	protected void cleanUpThreadLocal() {
		aggregationPipelineTL.remove();
	} 
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private <T extends AbstractContainer> void processContainer(BaseContainer<T> container,
			Map<String, AggregationOperation> unwindOperationMap, Queue<Criteria> rootContainerCriteriaQ,
			Queue<Criteria> rootPreUnwindCriteriaQ) {
		boolean processSpecific = processSpecific(container, unwindOperationMap, rootContainerCriteriaQ, rootPreUnwindCriteriaQ);		
		Queue<Criteria> embeddedContainerCriteriaQ = new LinkedList<>();
		Queue<Criteria> embeddedContainerPreUnwindCriteriaQ = new LinkedList<>();
		while (container.peek() != null) {
			T embeddedContainer = container.poll(); 
			if (embeddedContainer instanceof BaseContainer) {
				processContainer((BaseContainer) embeddedContainer, unwindOperationMap,
						embeddedContainerCriteriaQ, embeddedContainerPreUnwindCriteriaQ);
			} else { // instance of EQC
				processExpressionQueueContainer((ExpressionQueueContainerIE) embeddedContainer,
						unwindOperationMap, embeddedContainerCriteriaQ, embeddedContainerPreUnwindCriteriaQ, processSpecific);
			}
		}
		
		prepareContainerCriteria(container, embeddedContainerPreUnwindCriteriaQ, true);
		prepareContainerCriteria(container, embeddedContainerCriteriaQ, false);		

		if (rootContainerCriteriaQ != null) {
			rootContainerCriteriaQ.offer(container.getContainerCriteria());
		}
		if (rootPreUnwindCriteriaQ != null) {
			rootPreUnwindCriteriaQ.offer(container.getPreUnwindContainerCriteria());
		}		
	}

	private void prepareContainerCriteria(AbstractContainer container, Queue<Criteria> criteriaQ, boolean preUnwind) {
		if(criteriaQ.size() == 1) {
			if(preUnwind) {
				container.setPreUnwindContainerCriteria(criteriaQ.poll());
			} else {
				container.setContainerCriteria(criteriaQ.poll());
			}
		} else {
			if(preUnwind) {
				container.setPreUnwindContainerCriteria(
						createCriteriaForLogicalOp(container.getLogicalOperator(), criteriaQ));
			} else {
				container.setContainerCriteria(
						createCriteriaForLogicalOp(container.getLogicalOperator(), criteriaQ));
			}
		}
	}
	
	protected abstract <T extends AbstractContainer> boolean processSpecific(BaseContainer<T> container,
			Map<String, AggregationOperation> unwindOperationMap, Queue<Criteria> containerCriteriaQ,
			Queue<Criteria> rootPreUnwindCriteriaQ);
	
	private void processExpressionQueueContainer(ExpressionQueueContainerIE expressionQueueContainer,
			Map<String, AggregationOperation> unwindOperationMap, Queue<Criteria> containerCriteriaQ,
			Queue<Criteria> preUnwindContainerCriteriaQ, boolean processSpecific) {
		int eQCSize = expressionQueueContainer.size();
		Queue<Criteria> criteriaQEQC = new LinkedList<>();
		Queue<Criteria> criteriaQEQCPreUnwind = new LinkedList<>();
		Queue<FieldExpressionComposite> fieldPathPriorityQ = new PriorityQueue<>(
				(s1, s2) -> s1.getField().getPathSize() - s2.getField().getPathSize());			
		String minArrPath = null;
		while (expressionQueueContainer.peek() != null) {
			Expression expression = expressionQueueContainer.poll();
			Operand<?> lOperand = expression.getLeftOperand();
			DocumentFieldIE field = processorIE.process((String) lOperand.getValue(), getDocumentClassName(),
					expressionQueueContainer.getContainerType());
			// 3.2 Prepare pre-unwind match operation, check if field is inside an array.
			// If yes, then prepare minimum array path for the expression queue and compensate the field paths.
			FieldExpressionComposite fieldExpressionComposite = new FieldExpressionComposite(field, expression);
			minArrPath = DocumentFieldHelper.determineMinArrPath(fieldExpressionComposite, minArrPath);
			fieldPathPriorityQ.offer(fieldExpressionComposite);
			
			if (field.isFieldInArray()) {
				// 4. Create unwind operation for each stage if field at non-root level 
				// (cache path in current thread avoid duplicate unwinding) non-root field
				createUnwindStages(field, unwindOperationMap, processSpecific);
			}
			createCriteriaForExpression(field, expression, criteriaQEQC);
		}
		
		createCriteriaForElemMatchOperation(fieldPathPriorityQ, criteriaQEQCPreUnwind);
				
		if (eQCSize == 1) {
			expressionQueueContainer.setContainerCriteria(criteriaQEQC.poll());
			expressionQueueContainer.setPreUnwindContainerCriteria(criteriaQEQCPreUnwind.poll());
		} else {
			expressionQueueContainer.setContainerCriteria(
					createCriteriaForLogicalOp(expressionQueueContainer.getLogicalOperator(), criteriaQEQC));
			
			expressionQueueContainer.setPreUnwindContainerCriteria(criteriaQEQCPreUnwind.size() == 1
					? criteriaQEQCPreUnwind.poll()
					: createCriteriaForLogicalOp(expressionQueueContainer.getLogicalOperator(), criteriaQEQCPreUnwind));
			 
		}
		containerCriteriaQ.offer(expressionQueueContainer.getContainerCriteria());
		preUnwindContainerCriteriaQ.offer(expressionQueueContainer.getPreUnwindContainerCriteria());
	}
	
	protected abstract ModuleName getModuleName();

	/**
	 * Creates unwind stage(s) and cache it for field path
	 * @param field
	 * @param unwindOperationMap
	 */
	private void createUnwindStages(DocumentFieldIE field, Map<String, AggregationOperation> unwindOperationMap,
			boolean processSpecific) {
		Queue<AggregationOperation> currentPipeline = aggregationPipelineTL.get();
		if(unwindOperationMap.get(field.getPath()) == null) {
			// unwind recursively to the field and add unwind operation to the pipeline only if it doesn't exist in the map
			// check for each parent map in the map - if it exists don't add unwind
			List<String> pathElements = field.getPathElements("\\.");
			String currentPath = pathElements.get(0);
			int size = pathElements.size();
			for(int i = 1; i < size; i++) {
				if(unwindOperationMap.get(currentPath) == null) {
					AggregationOperation unwindOp = Aggregation.unwind(currentPath, preserveNullOrEmptyArrays(field));
					unwindOperationMap.put(currentPath, unwindOp);
					// add to pipeline					
					currentPipeline.offer(unwindOp);
				}
				currentPath = currentPath + "." + pathElements.get(i);
			}
			AggregationOperation unwindOp = Aggregation.unwind(field.getPath(), preserveNullOrEmptyArrays(field));
			currentPipeline.offer(unwindOp);
			unwindOperationMap.put(field.getPath(), unwindOp);
		} // else do nothing; unwind operation for the path already added.	
		// To be done in subclass
		if(processSpecific)
			unwindSpecific(field, unwindOperationMap, currentPipeline);				
	}
	
	protected boolean preserveNullOrEmptyArrays(DocumentFieldIE field) {
		return true;
	}
	
	private void createCriteriaForExpression(DocumentFieldIE field, Expression expression, Queue<Criteria> criteriaQ) {
		Criteria criteria = new Criteria(getSpecificCriteria(field));
		try {
			criteria = RuntimeHelperIE.invokeMethodOnInstance(criteria, expression.getOperator().getMethodName(),
							expression.getRightOperand().getValue(), expression.getOperator().getArgClass());
			//expression.getRightOperand().getValue().getClass()); introduces more tight coupling
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			logger.error("Caught exception in createCriteriaForExpression: {}", e.getMessage());
		}
		criteriaQ.offer(criteria);
	}
	
	private void createCriteriaForElemMatchOperation(Queue<FieldExpressionComposite> fieldExpressionCompositeQ,
			Queue<Criteria> criteriaQ) {
		String minArrPath = fieldExpressionCompositeQ.peek().getMinArrPath();
		/** Assumption: minArrPath will remain same for all the entries of the fieldExpressionQ 
		 * because either the fields will be at the root level or they will have a minimum common parent **/
		
		if(StringUtils.isEmpty(minArrPath)) { // fields at root-level
			while(fieldExpressionCompositeQ.peek() != null) {
				FieldExpressionComposite fieldExpressionComposite = fieldExpressionCompositeQ.poll();
				createCriteriaForExpression(fieldExpressionComposite.getField(),
						fieldExpressionComposite.getExpression(), criteriaQ);
			}			
		} else { // fields at non-root level, candidate for elemMatch
			Criteria criteria = Criteria.where(fieldExpressionCompositeQ.peek().getMinArrPath());
			Criteria innerCriteria = null;
			while(fieldExpressionCompositeQ.peek() != null) {
				FieldExpressionComposite fEC = fieldExpressionCompositeQ.poll();
				if(innerCriteria == null) {
					innerCriteria = Criteria.where(fEC.getRelativePath());
				} else {
					innerCriteria = innerCriteria.and(fEC.getRelativePath());
				}
				try {
					innerCriteria = RuntimeHelperIE.invokeMethodOnInstance(innerCriteria, fEC.getExpression().getOperator().getMethodName(),
							 fEC.getExpression().getRightOperand().getValue(),  fEC.getExpression().getOperator().getArgClass());
						
				} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
					logger.error("Caught exception in createCriteriaForElemMatchOperation: {}", e.getMessage());
				}				
			}
			if(innerCriteria != null) {
				criteria.elemMatch(innerCriteria);
				criteriaQ.offer(criteria);
			}
		}
	}
	
	private Criteria createCriteriaForLogicalOp(Operator logicalOp, Queue<Criteria> criteriaQ) {
		if(logicalOp == null || criteriaQ == null)
			return null;

		Criteria criteria = new Criteria();
		try {
			criteria = RuntimeHelperIE.invokeMethodOnInstance(criteria, logicalOp.getMethodName(), 
					criteriaQ.toArray(new Criteria[criteriaQ.size()]), Criteria[].class);
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			logger.error("Caught exception in createCriteriaForLogicalOp: {}", e.getMessage());
		}
		return criteria;
	}
	
	protected String getSpecificCriteria(DocumentFieldIE field) {
		return StringUtils.isEmpty(field.getFullPath()) ? field.getName() : field.getFullPath();
	}
	
	protected abstract void unwindSpecific(DocumentFieldIE field, Map<String, AggregationOperation> unwindOperationMap,
			Queue<AggregationOperation> pipeline);
	
	private void createPreUnwindMatchOperationForSearchCriteriaGroupContainer(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		// Add to current pipeline
		(aggregationPipelineTL.get())
				.push(Aggregation.match(searchCriteriaGroupContainer.getPreUnwindContainerCriteria()));
	}
	
	private void createMatchOperationForSearchCriteriaGroupContainer(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		// Add to current pipeline
		(aggregationPipelineTL.get()).offer(Aggregation.match(searchCriteriaGroupContainer.getContainerCriteria()));
	}
	
	private void createGroupsAndProjections(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			String collectionName) {
		Queue<AggregationOperation> projectionQ = createSpecific(searchCriteriaGroupContainer, collectionName);
		if (projectionQ != null) {
			while (projectionQ.peek() != null) {
				(aggregationPipelineTL.get()).offer(projectionQ.poll());
			}
		}
	}
	
	private void createGroupsAndProjectionsForId(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		Queue<AggregationOperation> projectionQ = createForIdSpecific(searchCriteriaGroupContainer);
		if (projectionQ != null) {
			while (projectionQ.peek() != null) {
				(aggregationPipelineTL.get()).offer(projectionQ.poll());
			}
		}
	}
	
	private void createGroupsAndProjectionsForCount(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		Queue<AggregationOperation> projectionQ = createCountSpecific(searchCriteriaGroupContainer);
		if(projectionQ != null) {
			while(projectionQ.peek() != null) {
				(aggregationPipelineTL.get()).offer(projectionQ.poll());
			}
		}
	}
	
	protected abstract Queue<AggregationOperation> createSpecific(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer, String collectionName);
	
	protected abstract Queue<AggregationOperation> createForIdSpecific(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer);	
	
	protected abstract Queue<AggregationOperation> createCountSpecific(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer);
	
	protected abstract Map<String,String> getCampaignPatientResults(Map<String,String> map,Aggregation agg, String collectionName);
	
	@Override
	public Map<String,String> buildMap(Map<String,String> map,SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			Pageable pageRequestData, String collectionName) {
		Map<String, AggregationOperation> unwindOperationMap = new TreeMap<>((s1, s2) -> s1.length() - s2.length());		
		processContainer(searchCriteriaGroupContainer, unwindOperationMap, null, null);
		createPreUnwindMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		if(!CollectionUtils.isEmpty(unwindOperationMap)) {
			createMatchOperationForSearchCriteriaGroupContainer(searchCriteriaGroupContainer);
		}
		createGroupsAndProjections(searchCriteriaGroupContainer, collectionName);
		return getCampaignPatientResults(map,buildAggregation(pageRequestData), collectionName);
	}
}