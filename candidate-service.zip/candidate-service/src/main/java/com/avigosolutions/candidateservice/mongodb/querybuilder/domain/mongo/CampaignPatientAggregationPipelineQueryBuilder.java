package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.CountOperation;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.avigosolutions.candidateservice.constants.Constants;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.mongodb.querybuilder.document.QueryCount;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.AbstractContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.BaseContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType.ModuleName;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor.DocumentFieldIE;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

@Component
public class CampaignPatientAggregationPipelineQueryBuilder
		extends AggregationPipelineQueryBuilderIE<Map<String, String>> {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static final String AGGREGATION_LOG = "builded aggregation for campaign patient query : {}";

	private static final String DOCUMENT_CLASS_NAME = Patient.class.getCanonicalName();

	@Override
	protected Map<String, String> getCampaignPatientResults(Map<String, String> map, Aggregation agg,
			String collectionName) {
		super.cleanUpThreadLocal();
		logger.info(AGGREGATION_LOG, agg);
		return convertRawResultsToMap(map, mongoTemplate.aggregate(agg, collectionName, String.class).getRawResults());
	}

	private Map<String, String> convertRawResultsToMap(Map<String, String> patientsMap, DBObject mongodDocument) {
		BasicDBObject basicDBObject = (BasicDBObject) mongodDocument;
		BasicDBList basicDBList = (BasicDBList) basicDBObject.get("result");
		if (!CollectionUtils.isEmpty(basicDBList)) {
			for (Object basicDBChildObject : basicDBList) {
				BasicDBObject entry = (BasicDBObject) basicDBChildObject;
				String patientId = this.extractDataFromDBEntry(entry, Constants.PATIENT_ID);
				if (patientsMap.containsKey(patientId)) {
					patientsMap.remove(patientId);
				} else {
					patientsMap.put(patientId,
							String.join(Constants.COMMA, patientId,
									String.valueOf(this.<Double>extractDataFromDBEntry(entry, Constants.LONGITUDE)),
									String.valueOf(this.<Double>extractDataFromDBEntry(entry, Constants.LATITUDE)),
									this.extractDataFromDBEntry(entry, Constants.EID)));
				}
			}
		}
		return patientsMap;
	}

	@SuppressWarnings("unchecked")
	private <T> T extractDataFromDBEntry(BasicDBObject dbEntry, String key) {
		T returnValue = null;
		BasicDBList embeddedDBList = (BasicDBList) dbEntry.get(key);
		if (!CollectionUtils.isEmpty(embeddedDBList)) {
			Object objVal = embeddedDBList.get(0);
			if (objVal == null) {
				return null;
			} else if (objVal instanceof String) {
				returnValue = ((T) (String) objVal);
			} else if (objVal instanceof Integer) {
				returnValue = ((T) (Integer) objVal);
			} else if (objVal instanceof Double) {
				returnValue = ((T) (Double) objVal);
			}
		}
		return returnValue;
	}

	@Override
	protected List<String> getResultsForId(Aggregation agg, String collectionName) {
		super.cleanUpThreadLocal();
		logger.info(AGGREGATION_LOG, agg);
		return (mongoTemplate.aggregate(agg, collectionName, String.class)).getMappedResults();
	}

	@Override
	protected Long getCount(Aggregation agg, String collectionName) {
		super.cleanUpThreadLocal();
		logger.info(AGGREGATION_LOG, agg);
		QueryCount queryCount = mongoTemplate.aggregate(agg, collectionName, QueryCount.class).getMappedResults()
				.get(0);
		return Long.valueOf("" + queryCount.getCount());
	}

	@Override
	public String getDocumentClassName() {
		return DOCUMENT_CLASS_NAME;
	}

	@Override
	protected ModuleName getModuleName() {
		return ModuleName.INCLUSION_EXCLUSION;
	}

	@Override
	protected void unwindSpecific(DocumentFieldIE field, Map<String, AggregationOperation> map,
			Queue<AggregationOperation> pipeline) {
		// no-op
	}

	@Override
	protected <T extends AbstractContainer> boolean processSpecific(BaseContainer<T> container,
			Map<String, AggregationOperation> unwindOperationMap, Queue<Criteria> containerCriteriaQ,
			Queue<Criteria> rootPreUnwindCriteriaQ) {
		return false;
	}

	@Override
	protected Queue<AggregationOperation> createSpecific(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			String collectionName) {
		Queue<AggregationOperation> projections = new LinkedList<>();
		createGroupOperation(projections);
		createFinalProjection(projections);
		return projections;
	}

	@Override
	protected Queue<AggregationOperation> createForIdSpecific(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		Queue<AggregationOperation> projections = new LinkedList<>();
		createGroupOperationForId(projections);
		createFinalProjectionForId(projections);
		return projections;
	}

	private void createGroupOperation(Queue<AggregationOperation> projections) {
		GroupOperation groupOperationOne = Aggregation.group(Constants.PATIENT_ID)
				.push(new BasicDBObject("id", "$" + Constants.PATIENT_ID).append(Constants.LATITUDE, "$lat")
						.append(Constants.LONGITUDE, "$lng").append(Constants.EID, "$eid"))
				.as("patient");
		projections.offer(groupOperationOne);
	}

	private void createGroupOperationForId(Queue<AggregationOperation> projections) {
		GroupOperation groupOperationOne = Aggregation.group(Constants.PATIENT_ID)
				.push(new BasicDBObject("id", "$" + Constants.PATIENT_ID)).as("patient");
		projections.offer(groupOperationOne);
	}

	private void createFinalProjectionForId(Queue<AggregationOperation> projections) {
		ProjectionOperation projection = Aggregation.project().and("patient.id").as(Constants.PATIENT_ID)
				.andExclude("_id");
		projections.offer(projection);
	}

	private void createFinalProjection(Queue<AggregationOperation> projections) {
		ProjectionOperation projection = Aggregation.project().and("patient.id").as(Constants.PATIENT_ID)
				.and("patient.lat").as(Constants.LATITUDE).and("patient.lng").as(Constants.LONGITUDE).and("patient.eid").as(Constants.EID).andExclude("_id");
		projections.offer(projection);
	}

	@Override
	protected Queue<AggregationOperation> createCountSpecific(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		Queue<AggregationOperation> projections = new LinkedList<>();
		createBasicGroupOperation(projections);
		createCountOperation(projections);
		return projections;
	}

	private void createBasicGroupOperation(Queue<AggregationOperation> projections) {
		GroupOperation groupOperationOne = Aggregation.group(Constants.PATIENT_ID);
		projections.offer(groupOperationOne);
	}

	private void createCountOperation(Queue<AggregationOperation> projections) {
		CountOperation countOperation = Aggregation.count().as("count");
		projections.offer(countOperation);
	}

	@Override
	protected List<Map<String, String>> getResults(Aggregation agg, String collectionName) {
		return null;
	}

}
