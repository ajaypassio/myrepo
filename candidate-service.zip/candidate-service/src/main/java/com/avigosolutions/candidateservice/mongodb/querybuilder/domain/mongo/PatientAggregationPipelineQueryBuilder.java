package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.CountOperation;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.mongodb.querybuilder.document.QueryCount;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.AbstractContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.BaseContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType.ModuleName;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor.DocumentFieldIE;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

@Component
public class PatientAggregationPipelineQueryBuilder extends AggregationPipelineQueryBuilderIE<Patient> {

	@Autowired
	private MongoTemplate mongoTemplate;

	private static final String PATIENT_ID = "patient_id";
	private static final String ZIP = "zip";
	private static final String EMAIL = "email";
	private static final String SCORE = "score";
	private static final String FIRST_NAME = "firstName";
	private static final String LAST_NAME = "lastName";
	private static final String AGE = "age";
	private static final String GENDER = "gender";
	private static final String ADDRESS_LINE1 = "addressLine1";
	private static final String ADDRESS_LINE2 = "addressLine2";
	private static final String CITY = "city";
	private static final String STATE = "state";
	private static final String LATITUDE = "lat";
	private static final String LONGITUDE = "lng";
	private static final String PHONE_NUMBER = "phoneNumber";
	private static final String RANKING = "ranking";
	private static final String PATIENT_SCORE = "score";
	private static final String EID = "eid";
	private static final String STATE_CITY = "stateCity";
	private static final String RACE = "race";
	private static final String ETHNICITY = "ethnicity";

	private static final String AGGREGATION_LOG = "builded aggregation : {}";

	private static final String DOCUMENT_CLASS_NAME = Patient.class.getCanonicalName();

	@Override
	protected List<Patient> getResults(Aggregation agg, String collectionName) {
		super.cleanUpThreadLocal();
		logger.info(AGGREGATION_LOG, agg);
		return convertRawResultsToList(mongoTemplate.aggregate(agg, collectionName, Patient.class).getRawResults());
	}

	private List<Patient> convertRawResultsToList(DBObject mongodDocument) {
		BasicDBObject basicDBObject = (BasicDBObject) mongodDocument;
		BasicDBList basicDBList = (BasicDBList) basicDBObject.get("result");
		final List<Patient> patients = new ArrayList<>();
		if (!CollectionUtils.isEmpty(basicDBList)) {
			basicDBList.forEach(basicDBChildObject -> {
				BasicDBObject entry = (BasicDBObject) basicDBChildObject;
				Patient patient = new Patient();
				patient.withPatientId(extractDataFromDBEntry(entry, PATIENT_ID))
						.withZip(this.<String>extractDataFromDBEntry(entry, ZIP))
						.withEmail(this.<String>extractDataFromDBEntry(entry, EMAIL))
						.withScoreJSON(this.<String>extractDataFromDBEntry(entry, SCORE))
						.withFirstName(this.<String>extractDataFromDBEntry(entry, FIRST_NAME))
						.withLastName(this.<String>extractDataFromDBEntry(entry, LAST_NAME))
						.withAge(this.<Integer>extractDataFromDBEntry(entry, AGE))
						.withGender(this.<String>extractDataFromDBEntry(entry, GENDER))
						.withAddressLine1(this.<String>extractDataFromDBEntry(entry, ADDRESS_LINE1))
						.withAddressLine2(this.<String>extractDataFromDBEntry(entry, ADDRESS_LINE2))
						.withState(this.<String>extractDataFromDBEntry(entry, STATE))
						.withCity(this.<String>extractDataFromDBEntry(entry, CITY))
						.withLat(this.<Double>extractDataFromDBEntry(entry, LATITUDE).floatValue())
						.withLng(this.<Double>extractDataFromDBEntry(entry, LONGITUDE).floatValue())
						.withScore(this.<String>extractDataFromDBEntry(entry, PATIENT_SCORE))
						.withRanking(this.<String>extractDataFromDBEntry(entry, RANKING))
						.withEid(this.<String>extractDataFromDBEntry(entry, EID))
						.withStateCity(this.<String>extractDataFromDBEntry(entry, STATE_CITY))
						.withRace(this.<String>extractDataFromDBEntry(entry, RACE))
				        .withEthnicity(this.<String>extractDataFromDBEntry(entry, ETHNICITY));
				patients.add(patient);
			});
		}
		return patients;
	}

	@SuppressWarnings("unchecked")
	private <T> T extractDataFromDBEntry(BasicDBObject dbEntry, String key) {
		T returnValue = null;
		BasicDBList embeddedDBList = (BasicDBList) dbEntry.get(key);
		if (!CollectionUtils.isEmpty(embeddedDBList)) {
			Object objVal = embeddedDBList.get(0);
			if (objVal == null) {
				return null;
			} else if (objVal instanceof String) {
				returnValue = ((T) (String) objVal);
			} else if (objVal instanceof Integer) {
				returnValue = ((T) (Integer) objVal);
			} else if (objVal instanceof Double) {
				returnValue = ((T) (Double) objVal);
			}
		}
		return returnValue;
	}

	@Override
	protected List<String> getResultsForId(Aggregation agg, String collectionName) {
		super.cleanUpThreadLocal();
		logger.info(AGGREGATION_LOG, agg);
		return (mongoTemplate.aggregate(agg, collectionName, String.class)).getMappedResults();
	}

	@Override
	protected Long getCount(Aggregation agg, String collectionName) {
		super.cleanUpThreadLocal();
		logger.info(AGGREGATION_LOG, agg);
		QueryCount queryCount = mongoTemplate.aggregate(agg, collectionName, QueryCount.class).getMappedResults()
				.get(0);
		return Long.valueOf("" + queryCount.getCount());
	}

	@Override
	public String getDocumentClassName() {
		return DOCUMENT_CLASS_NAME;
	}

	@Override
	protected ModuleName getModuleName() {
		return ModuleName.INCLUSION_EXCLUSION;
	}

	@Override
	protected void unwindSpecific(DocumentFieldIE field, Map<String, AggregationOperation> map,
			Queue<AggregationOperation> pipeline) {
		// no-op
	}

	@Override
	protected <T extends AbstractContainer> boolean processSpecific(BaseContainer<T> container,
			Map<String, AggregationOperation> unwindOperationMap, Queue<Criteria> containerCriteriaQ,
			Queue<Criteria> rootPreUnwindCriteriaQ) {
		return false;
	}

	@Override
	protected Queue<AggregationOperation> createSpecific(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer,
			String collectionName) {
		Queue<AggregationOperation> projections = new LinkedList<>();
		createGroupOperation(projections, collectionName);
		createFinalProjection(projections);
		return projections;
	}

	@Override
	protected Queue<AggregationOperation> createForIdSpecific(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		Queue<AggregationOperation> projections = new LinkedList<>();
		createGroupOperationForId(projections);
		createFinalProjectionForId(projections);
		return projections;
	}

	private void createGroupOperation(Queue<AggregationOperation> projections, String collectionName) {
		GroupOperation groupOperationOne = Aggregation.group(PATIENT_ID).push(new BasicDBObject("id", "$" + PATIENT_ID)
				.append(ZIP, "$zip").append(EMAIL, "$email").append(SCORE, "$criteria." + collectionName + ".score")
				.append(FIRST_NAME, "$firstName").append(LAST_NAME, "$lastName").append(AGE, "$age")
				.append(GENDER, "$gender").append(ADDRESS_LINE1, "$addressLine1").append(ADDRESS_LINE2, "$addressLine2")
				.append(STATE, "$state").append(CITY, "$city").append(LATITUDE, "$lat").append(LONGITUDE, "$lng")
				.append(PHONE_NUMBER, "$phoneNumber").append(RANKING, "$ranking").append(EID, "$eid").append(STATE_CITY, "$stateCity").append(RACE, "$race").append(ETHNICITY, "$ethnicity").append(PATIENT_SCORE, "$score"))
				.as("patient");
		projections.offer(groupOperationOne);
	}

	private void createGroupOperationForId(Queue<AggregationOperation> projections) {
		GroupOperation groupOperationOne = Aggregation.group(PATIENT_ID).push(new BasicDBObject("id", "$" + PATIENT_ID))
				.as("patient");
		projections.offer(groupOperationOne);
	}

	private void createFinalProjectionForId(Queue<AggregationOperation> projections) {
		ProjectionOperation projection = Aggregation.project().and("patient.id").as(PATIENT_ID).andExclude("_id");
		projections.offer(projection);
	}

	private void createFinalProjection(Queue<AggregationOperation> projections) {
		ProjectionOperation projection = Aggregation.project().and("patient.id").as(PATIENT_ID).and("patient.zip")
				.as(ZIP).and("patient.email").as(EMAIL).and("patient.score").as(SCORE).and("patient.firstName")
				.as(FIRST_NAME).and("patient.lastName").as(LAST_NAME).and("patient.age").as(AGE).and("patient.gender")
				.as(GENDER).and("patient.addressLine1").as(ADDRESS_LINE1).and("patient.addressLine2").as(ADDRESS_LINE2)
				.and("patient.state").as(STATE).and("patient.city").as(CITY).and("patient.lat").as(LATITUDE)
				.and("patient.lng").as(LONGITUDE).and("patient.phoneNumber").as(PHONE_NUMBER).and("patient.ranking")
				.as(RANKING).and("patient.eid").as(EID).and("patient.stateCity").as(STATE_CITY).and("patient.race").as(RACE).and("patient.ethnicity").as(ETHNICITY).and("patient.score").as(PATIENT_SCORE).andExclude("_id");
		projections.offer(projection);
	}

	@Override
	protected Queue<AggregationOperation> createCountSpecific(
			SearchCriteriaGroupContainerIE searchCriteriaGroupContainer) {
		Queue<AggregationOperation> projections = new LinkedList<>();
		createBasicGroupOperation(projections);
		createCountOperation(projections);
		return projections;
	}

	private void createBasicGroupOperation(Queue<AggregationOperation> projections) {
		GroupOperation groupOperationOne = Aggregation.group(PATIENT_ID);
		projections.offer(groupOperationOne);
	}

	private void createCountOperation(Queue<AggregationOperation> projections) {
		CountOperation countOperation = Aggregation.count().as("count");
		projections.offer(countOperation);
	}

	@Override
	protected Map<String, String> getCampaignPatientResults(Map<String,String> map,Aggregation agg, String collectionName) {
		return null;
	}

}
