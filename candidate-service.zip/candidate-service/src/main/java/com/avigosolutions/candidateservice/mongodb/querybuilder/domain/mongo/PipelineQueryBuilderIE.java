package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;

public interface PipelineQueryBuilderIE<R> {

	List<R> build(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer, Pageable pageRequestData, String collectionName);
	
	List<String> buildForId(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer, Pageable pageRequestData, String collectionName);
	
	Long count(SearchCriteriaGroupContainerIE searchCriteriaGroupContainer, String collectionName);
	
	String getDocumentClassName();
	
	Map<String,String> buildMap(Map<String,String> map,SearchCriteriaGroupContainerIE searchCriteriaGroupContainer, Pageable pageRequestData, String collectionName);
}