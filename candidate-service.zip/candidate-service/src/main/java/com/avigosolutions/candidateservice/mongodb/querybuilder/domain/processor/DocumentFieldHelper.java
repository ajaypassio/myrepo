package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor;

import org.springframework.util.StringUtils;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Expression;

public class DocumentFieldHelper {

	public static String determineMinArrPath(FieldExpressionComposite fieldExpressionComposite,
			String currentArrayPath) {
		if (StringUtils.isEmpty(currentArrayPath)) {
			fieldExpressionComposite.setMinArrPath(fieldExpressionComposite.getField().getPath());
			fieldExpressionComposite.setRelativePath(fieldExpressionComposite.getField().getName());
			currentArrayPath = fieldExpressionComposite.getField().getPath();
		} else {
			if (currentArrayPath.length() >= fieldExpressionComposite.getField().getPathSize()) {
				currentArrayPath = fieldExpressionComposite.getField().getPath();
			}
			fieldExpressionComposite.setMinArrPath(currentArrayPath);
			fieldExpressionComposite
					.setRelativePath(determineRelativePath(currentArrayPath, fieldExpressionComposite.getField()));
		}
		return currentArrayPath;
	}

	private static String determineRelativePath(String currentArrayPath, DocumentFieldIE field) {
		// case 1 - currentArrPath and field path are at the same level
		if (currentArrayPath.length() == field.getPathSize()) {
			return field.getName();
		} else if (currentArrayPath.length() < field.getPathSize()) { // case 2 - field at a deeper level than
																		// currentArrPath
			String relPath = field.getFullPath().replaceAll(currentArrayPath, "");
			if (relPath.startsWith(".")) {
				relPath = relPath.substring(1, relPath.length());
			}
			return relPath;
		} else { // won't happen
			return null;
		}
	}

	public static class FieldExpressionComposite {
		private DocumentFieldIE field;
		private Expression expression;
		private String minArrPath;
		private String relativePath;

		public FieldExpressionComposite(DocumentFieldIE field, Expression expression) {
			this.field = field;
			this.expression = expression;
		}

		public String getMinArrPath() {
			return minArrPath;
		}

		public void setMinArrPath(String minArrPath) {
			this.minArrPath = minArrPath;
		}

		public String getRelativePath() {
			return relativePath;
		}

		public void setRelativePath(String relativePath) {
			this.relativePath = relativePath;
		}

		public DocumentFieldIE getField() {
			return field;
		}

		public Expression getExpression() {
			return expression;
		}

	}
}
