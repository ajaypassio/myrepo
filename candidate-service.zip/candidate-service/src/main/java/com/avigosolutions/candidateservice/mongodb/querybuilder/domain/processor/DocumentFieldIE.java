package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor;

import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

public class DocumentFieldIE {
	
	private String name;
	private String path;
	private List<String> pathElements;
	private String fullPath;

	public DocumentFieldIE(String name, String path) {
		this.name = name;
		this.path = path;
		// if field is at root level, then path and full-path are empty
		this.fullPath = StringUtils.isEmpty(path) ? path : path + "." + name;
	}

	public String getPath() {
		return path;
	}
	
	public String getName() {
		return name;
	}

	public String getFullPath() {
		return fullPath;
	}

	public List<String> getPathElements(String splitter) {
		return Arrays.asList(path.split(splitter));
	}
	
	public boolean isFieldInArray() {
		return !StringUtils.isEmpty(fullPath);
	}
	
	public int getPathElementsSize() {
		return pathElements == null ? 0 : pathElements.size();
	}
	
	public int getPathSize() {
		return StringUtils.isEmpty(path) ? 0 : path.length();
	}

	@Override
	public String toString() {
		return "DocumentFieldIE [name=" + name + ", path=" + path + ", pathElements=" + pathElements + ", fullPath="
				+ fullPath + "]";
	}
}
