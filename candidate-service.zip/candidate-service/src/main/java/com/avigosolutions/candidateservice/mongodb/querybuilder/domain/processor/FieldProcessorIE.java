package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;
import com.avigosolutions.candidateservice.mongodb.querybuilder.util.RuntimeHelperIE;

@Service("fieldProcessorIE")
public class FieldProcessorIE implements ProcessorIE<String, DocumentFieldIE> {
	
	private static final Logger logger = LoggerFactory.getLogger(FieldProcessorIE.class);

	private final Map<String, DocumentFieldIE> documentFieldCache = new ConcurrentHashMap<>();
	
	@Override
	public DocumentFieldIE process(String arg, String className, ContainerType cType) {
		String field = ContainerType.getFieldName(arg, cType);
		DocumentFieldIE docField = documentFieldCache.get(field);
		if(docField == null) {
			docField = new DocumentFieldIE(field , getFieldPath(field, className));
			documentFieldCache.put(arg, docField);
		}
		return docField;
	}
	
	private String getFieldPath(String field, String className) {		
		try {
			return RuntimeHelperIE.getFieldPath(field, className);
		} catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException e) {
			logger.error("Caught exception: {}", e.getMessage());
			return null;
		}		
	}
	
	public DocumentFieldIE getDocumentField(String key) {
		return documentFieldCache.get(key);
	}

}
