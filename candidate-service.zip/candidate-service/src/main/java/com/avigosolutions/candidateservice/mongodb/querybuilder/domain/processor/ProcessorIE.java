package com.avigosolutions.candidateservice.mongodb.querybuilder.domain.processor;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;

public interface ProcessorIE<T, R> {
	
	R process(T arg, String className, ContainerType cType);
}
