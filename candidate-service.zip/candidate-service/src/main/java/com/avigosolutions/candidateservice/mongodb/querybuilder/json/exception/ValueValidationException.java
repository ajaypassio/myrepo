package com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception;

public class ValueValidationException extends InputValidationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValueValidationException() {
		// default constructor
	}

	public ValueValidationException(String message) {
		super(message);
	}

	public ValueValidationException(Throwable cause) {
		super(cause);
	}

	public ValueValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
