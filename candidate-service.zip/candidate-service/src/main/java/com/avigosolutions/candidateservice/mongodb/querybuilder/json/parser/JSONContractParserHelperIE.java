package com.avigosolutions.candidateservice.mongodb.querybuilder.json.parser;

import static com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType.getContainerType;
import static com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType.ModuleName.INCLUSION_EXCLUSION;

import java.util.Iterator;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.AbstractContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.BaseContainer;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.Container;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.EQCLogicalGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ExpressionQueueContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SCCLogicalGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.ComparisonOperator;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Expression;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Operand;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Operator;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.InputValidationException;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.validation.InputValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.DoubleNode;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.node.LongNode;
import com.fasterxml.jackson.databind.node.TextNode;

public class JSONContractParserHelperIE {

	private static final String TYPE_IE = "type";
	private static final String DEMOGRAPHICS_IE = "Demographics";
	private static final String FIELD_LABEL = "fieldLabel";
	private static final String FIELD_VALUE = "fieldValue";
	private static final String VALUE = "value";
	private static final String VALUESTR = "valuestr";
	private static final String RANGE = "range";
	// Use below when data type is governed by UI. private static final String
	// VALUE_TYPE = "valueType";

	private JSONContractParserHelperIE() {
		throw new UnsupportedOperationException("instantiation not allowed.");
	}

	private static <T extends AbstractContainer> BaseContainer<T> processContainerForSingleQueueEntry(
			BaseContainer<T> container) {
		if (!container.isEmpty() && container.size() == 1) {
			container.setLogicalOperator(null);
		}
		return container;
	}

	static Container getSCCLogicalGroupContainers(BaseContainer<SCCLogicalGroupContainerIE> criteriaGroupContainer,
			JsonNode node, boolean isNonEID) throws InputValidationException {
		if (node != null && node.fieldNames().hasNext()) {
			Iterator<String> itr = node.fieldNames();
			while (itr.hasNext()) {
				String currentField = itr.next();
				JsonNode currentNode = node.get(currentField);
				BaseContainer<SearchCriteriaContainerIE> sccLogicalGroupContainer = new SCCLogicalGroupContainerIE(
						getContainerType(currentField, SCCLogicalGroupContainerIE.class, INCLUSION_EXCLUSION));
				if (currentNode != null && currentNode.isArray() && currentNode.size() > 0) {
					SCCLogicalGroupContainerIE sCCLogicalGroupContainer = getSearchCriteriaContainers(
							sccLogicalGroupContainer, currentNode, isNonEID);
					if (!sCCLogicalGroupContainer.isEmpty()) {
						criteriaGroupContainer.offer(sCCLogicalGroupContainer);
					}
				}
			}
		}
		return processContainerForSingleQueueEntry(criteriaGroupContainer);
	}

	private static SCCLogicalGroupContainerIE getSearchCriteriaContainers(
			BaseContainer<SearchCriteriaContainerIE> sccLogicalGroupContainer, JsonNode jsonNode, boolean isNonEID)
			throws InputValidationException {
		for (int i = 0; i < jsonNode.size(); i++) {
			JsonNode currentNode = jsonNode.get(i);
			if (currentNode != null && currentNode.fieldNames().hasNext()) {
				Iterator<String> itr = currentNode.fieldNames();
				while (itr.hasNext()) {
					String currentField = itr.next();
					ContainerType cType = getContainerType(currentField, SearchCriteriaContainerIE.class,
							INCLUSION_EXCLUSION);

					SearchCriteriaContainerIE searchCriteriaContainer = getEQCLogicalGroupContainers(
							new SearchCriteriaContainerIE(cType), currentNode.get(currentField), isNonEID);
					if (!searchCriteriaContainer.isEmpty()) {
						sccLogicalGroupContainer.offer(searchCriteriaContainer);
					}
				}
			}
		}
		return (SCCLogicalGroupContainerIE) processContainerForSingleQueueEntry(sccLogicalGroupContainer);
	}

	private static SearchCriteriaContainerIE getEQCLogicalGroupContainers(
			BaseContainer<EQCLogicalGroupContainerIE> searchCriteriaContainer, JsonNode node, boolean isNonEID)
			throws InputValidationException {
		if (node != null && node.fieldNames().hasNext()) {
			Iterator<String> itr = node.fieldNames();
			while (itr.hasNext()) {
				String currentField = itr.next();
				JsonNode currentNode = node.get(currentField);
				BaseContainer<ExpressionQueueContainerIE> eqcLogicalGroupContainer = new EQCLogicalGroupContainerIE(
						getContainerType(currentField, EQCLogicalGroupContainerIE.class, INCLUSION_EXCLUSION));
				if (currentNode != null && currentNode.isArray() && currentNode.size() > 0) {
					EQCLogicalGroupContainerIE eQCLogicalGroupContainer = getExpressionQueueContainers(
							eqcLogicalGroupContainer, currentNode, isNonEID);
					if (!eQCLogicalGroupContainer.isEmpty()) {
						searchCriteriaContainer.offer(eQCLogicalGroupContainer);
					}
				}
			}
		}
		return (SearchCriteriaContainerIE) processContainerForSingleQueueEntry(searchCriteriaContainer);
	}

	private static EQCLogicalGroupContainerIE getExpressionQueueContainers(
			BaseContainer<ExpressionQueueContainerIE> eqcLogicalGroupContainer, JsonNode jsonNode, boolean isNonEID)
			throws InputValidationException {
		boolean flagProcessed = false;
		for (int i = 0; i < jsonNode.size(); i++) {
			JsonNode currentNode = jsonNode.get(i);
			if (currentNode != null && currentNode.fieldNames().hasNext()) {
				Iterator<String> itr = currentNode.fieldNames();
				while (itr.hasNext()) {
					String currentField = itr.next();
					if (currentField.equals(TYPE_IE)) {
						ContainerType cType = currentNode.get(TYPE_IE).asText().equalsIgnoreCase(DEMOGRAPHICS_IE)
								? ContainerType.DEMOGRAPHICS_IE
								: null;
						String subType = itr.next();
						JsonNode node = currentNode.get(subType);
						if (node != null && node.fieldNames().hasNext()) {
							Iterator<String> itrInner = node.fieldNames();
							String currentFieldInner = itrInner.next();
							if (cType == null) {
								cType = getContainerType(currentFieldInner, ExpressionQueueContainerIE.class,
										INCLUSION_EXCLUSION);
							}
							ExpressionQueueContainerIE expressionQueueContainer = getExpressionQueue(
									new ExpressionQueueContainerIE(cType), currentFieldInner,
									node.get(currentFieldInner), isNonEID);
							if (!expressionQueueContainer.isEmpty()) {
								eqcLogicalGroupContainer.offer(expressionQueueContainer);
								if (!flagProcessed && expressionQueueContainer.getContainerType().equals(ContainerType.DEMOGRAPHICS_IE)) {
									if (isNonEID) {
										ExpressionQueueContainerIE eidExpressionQueueContainer = new ExpressionQueueContainerIE(
												ContainerType.DEMOGRAPHICS_IE);
										eidExpressionQueueContainer.offer(getEIDExpression(false));
										eqcLogicalGroupContainer.offer(eidExpressionQueueContainer);
										flagProcessed = true;
									} else {
										ExpressionQueueContainerIE eidExpressionQueueContainer = new ExpressionQueueContainerIE(
												ContainerType.DEMOGRAPHICS_IE);
										eidExpressionQueueContainer.offer(getEIDExpression(true));
										eqcLogicalGroupContainer.offer(eidExpressionQueueContainer);
										flagProcessed = true;
									}
								}
							}
						}
					}
				}
			}
		}

		return (EQCLogicalGroupContainerIE) eqcLogicalGroupContainer;
	}

	private static ExpressionQueueContainerIE getExpressionQueue(ExpressionQueueContainerIE expressionQueueContainer,
			String subType, JsonNode jsonNode, boolean isNonEID) throws InputValidationException {
		ContainerType cType = expressionQueueContainer.getContainerType();
		switch (cType) {
		case DEMOGRAPHICS_IE:
			prepareDemographicsIEExpressions(subType, jsonNode, expressionQueueContainer);
			break;
		case LAB_RESULTS_IE:
			if (!isNonEID)
				prepareLabResultsIEExpressionsNew(jsonNode, expressionQueueContainer);
			break;
		case DIAGNOSTICS_IE:
			if (!isNonEID)
				prepareDiagnosticsIEExpressionsNew(jsonNode, expressionQueueContainer);
			break;
		case COMMON_TIME_IE:
			break;
		default:
			break;

		}
		return expressionQueueContainer;
	}

	private static void prepareDiagnosticsIEExpressionsNew(JsonNode jsonNode, ExpressionQueueContainerIE eQContainer)
			throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			int index = 0;
			// diag node
			JsonNode diagNode = jsonNode.get(index);
			Expression diagIcdCodeExpression = new Expression();
			String diagFieldLabel = diagNode.get(FIELD_LABEL).asText();

			// ICD code diag expression
			diagIcdCodeExpression.setLeftOperand(getLHOperand(diagFieldLabel));
			diagIcdCodeExpression.setRightOperand(getRHOperand(diagNode.get(FIELD_VALUE), false));
			diagIcdCodeExpression.setOperator(ComparisonOperator.EQ);
			eQContainer.offer(diagIcdCodeExpression);
			// ICD code set expression
			Expression diagIcdCodeSetExpression = new Expression();
			JsonNode icdCodeSetNode = jsonNode.get(++index);
			diagIcdCodeSetExpression.setOperator(ComparisonOperator.EQ);
			diagIcdCodeSetExpression.setLeftOperand(getLHOperand(icdCodeSetNode.get(FIELD_LABEL).asText()));
			diagIcdCodeSetExpression.setRightOperand(getRHOperand(icdCodeSetNode.get(FIELD_VALUE), false));
			eQContainer.offer(diagIcdCodeSetExpression);
		}
	}

	private static void prepareLabResultsIEExpressionsNew(JsonNode jsonNode, ExpressionQueueContainerIE eQContainer)
			throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			int index = 0;
			// lab test name node
			JsonNode labTestNameNode = jsonNode.get(index);
			Expression labTestNameExpression = new Expression();
			labTestNameExpression.setLeftOperand(getLHOperand(labTestNameNode.get(FIELD_LABEL).asText()));
			labTestNameExpression.setRightOperand(getRHOperand(labTestNameNode.get(FIELD_VALUE), false));
			labTestNameExpression.setOperator(ComparisonOperator.EQ);
			eQContainer.offer(labTestNameExpression);
			// lab test condition
			JsonNode labTestConditionNode = jsonNode.get(++index);
			String labTestConditionValue = labTestConditionNode.get(FIELD_VALUE).asText();
			// JsonNode labTestValueTypeNode = jsonNode.get(++index);
			// String labTestValueType = labTestValueTypeNode.get(FIELD_VALUE).asText();
			// check if result comment text is there
			if (!labTestConditionValue.equalsIgnoreCase("resultCommentText")) {
				JsonNode labTestValueTypeNode = jsonNode.get(++index);
				String labTestValueType = labTestValueTypeNode.get(FIELD_VALUE).asText();
				if (labTestValueType.equalsIgnoreCase("Other")) {
					Expression labTestValueExpression = new Expression();

					// lab test value multiplier
					++index;
					if (labTestConditionValue.equalsIgnoreCase(RANGE)) {
						JsonNode minValueNode = jsonNode.get(++index);
						labTestValueExpression.setLeftOperand(getLHOperand(labTestValueType));
						Expression minValExpression = new Expression();
						minValExpression.setLeftOperand(getLHOperand(labTestValueType));
						minValExpression.setOperator(ComparisonOperator.GTE);
						minValExpression.setRightOperand(getRHOperand(minValueNode.get(FIELD_VALUE), false));
						eQContainer.offer(minValExpression);

						JsonNode maxValueNode = jsonNode.get(++index);
						labTestValueExpression.setOperator(ComparisonOperator.LTE);
						labTestValueExpression.setRightOperand(getRHOperand(maxValueNode.get(FIELD_VALUE), false));
						eQContainer.offer(labTestValueExpression);
					} else {
						// lab test value node
						labTestValueExpression.setLeftOperand(getLHOperand(labTestValueType));
						labTestValueExpression.setOperator(getOperator(labTestConditionValue));
						JsonNode valueNode = jsonNode.get(++index);
						//Handling number and string values for result test value
						if (labTestConditionValue.equalsIgnoreCase("eq")) {
							Operand<?> rightOperand = null;
							String customizeNumberRegex = "([+-])?(\\s*)?(\\d*\\.)?(\\d+)";
							if (valueNode.get(FIELD_VALUE).asText().matches(customizeNumberRegex)) {
								String fieldValue = valueNode.get(FIELD_VALUE).asText().replace("+", "").trim();
								rightOperand = new Operand<>(Double.valueOf(fieldValue));
							} else {
								//We are replace otherStr incase of string value type. We match the container type.
								labTestValueExpression.setLeftOperand(getLHOperand("otherStr"));
								rightOperand = new Operand<>(valueNode.get(FIELD_VALUE).asText().trim());
							}
							labTestValueExpression.setRightOperand(rightOperand);
						} else {
							labTestValueExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE), false));
						}
						//labTestValueExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE), false));
						eQContainer.offer(labTestValueExpression);
					}
					// lab test unit node
					JsonNode labTestUnitNode = jsonNode.get(++index);
					Expression labTestUnitExpression = new Expression();
					labTestUnitExpression.setLeftOperand(getLHOperand(labTestUnitNode.get(FIELD_LABEL).asText()));
					labTestUnitExpression.setRightOperand(getRHOperand(labTestUnitNode.get(FIELD_VALUE), false));
					labTestUnitExpression.setOperator(ComparisonOperator.EQ);
					eQContainer.offer(labTestUnitExpression);
				}
			}
		}
	}

	private static void prepareDemographicsIEExpressions(String subType, JsonNode jsonNode,
			ExpressionQueueContainerIE eQContainer) throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			Expression demographicsExpression = new Expression();
			demographicsExpression.setLeftOperand(new Operand<>(subType));
			JsonNode conditionNode = jsonNode.get(0);

			if (subType.equalsIgnoreCase("age")) {
				if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase(RANGE)) {
					JsonNode minNode = jsonNode.get(1);
					Expression demographicsExpression0 = new Expression();
					demographicsExpression0.setLeftOperand(new Operand<>(subType));
					demographicsExpression0.setOperator(ComparisonOperator.GTE);
					demographicsExpression0.setRightOperand(getRHOperand(minNode.get(FIELD_VALUE), false));
					eQContainer.offer(demographicsExpression0);
					JsonNode maxNode = jsonNode.get(2);
					demographicsExpression.setOperator(ComparisonOperator.LTE);
					demographicsExpression.setRightOperand(getRHOperand(maxNode.get(FIELD_VALUE), false));
				} else {
					demographicsExpression.setOperator(getOperator(conditionNode.get(FIELD_VALUE).asText()));
					JsonNode valueNode = jsonNode.get(1);
					demographicsExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE),
							isRHOperandAnArray(demographicsExpression.getOperator())));
				}
				eQContainer.offer(demographicsExpression);
			} else if (subType.equalsIgnoreCase("gender")) {
				demographicsExpression.setOperator(ComparisonOperator.IN);
				demographicsExpression.setRightOperand(getRHOperand(jsonNode.get(1).get(FIELD_VALUE), true));
				eQContainer.offer(demographicsExpression);
			} else if (subType.equalsIgnoreCase("location")) {
				if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("state")
						|| conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("stateCity")) {
					demographicsExpression.setLeftOperand(getLHOperand(conditionNode.get(FIELD_VALUE).asText()));
					demographicsExpression.setOperator(ComparisonOperator.IN);
					JsonNode valueNode = jsonNode.get(1);
					demographicsExpression.setRightOperand(getRHOperandStateCity(valueNode.get(FIELD_VALUE), true));
					eQContainer.offer(demographicsExpression);
				}
			}
			else if ((subType.equalsIgnoreCase("race")||(subType.equalsIgnoreCase("ethnicity")))) {
				/*demographicsExpression.setOperator(ComparisonOperator.EQ);
				demographicsExpression.setRightOperand(getRHOperand(jsonNode.get(0).get(FIELD_VALUE), false));
				eQContainer.offer(demographicsExpression);*/
				demographicsExpression.setOperator(ComparisonOperator.IN);
				demographicsExpression.setRightOperand(getRHOperand(jsonNode.get(1).get(FIELD_VALUE), true));
				eQContainer.offer(demographicsExpression);
			}
		}
	}

	private static Expression getEIDExpression(boolean isEID) {
		Expression eidExpression = new Expression();
		eidExpression.setLeftOperand(new Operand<>("eid"));
		eidExpression.setOperator(ComparisonOperator.EQ);
		eidExpression.setRightOperand(isEID ? new Operand<>("y") : new Operand<>("n"));
		return eidExpression;
	}

	private static boolean isRHOperandAnArray(Operator op) {
		if (op instanceof ComparisonOperator) {
			return op == ComparisonOperator.IN;
		}
		return false;
	}

	private static Operand<String> getLHOperand(String value) {
		return new Operand<>(value);
	}

	private static Operator getOperator(String field) {
		// default operation
		return ComparisonOperator.valueOf(field.toUpperCase());
	}

	private static Operand<?> getRHOperand(JsonNode value, boolean isArray) throws InputValidationException {
		Class<?> valueClass = value.getClass();
		Operand<?> operand = null;
		Object val = null;
		Object[] valArr = null;
		// validate value for allowed characters
		if (valueClass == IntNode.class) {
			InputValidator.validateValue(Integer.valueOf(value.asInt()));
			val = Integer.valueOf(value.asInt());
		}
		if (valueClass == LongNode.class) {
			InputValidator.validateValue(Long.valueOf(value.asLong()));
			val = Long.valueOf(value.asLong());
		}
		if (valueClass == DoubleNode.class) {
			InputValidator.validateValue(Double.valueOf(value.asDouble()));
			val = Double.valueOf(value.asDouble());
		}
		if (valueClass == TextNode.class) {
			String str = value.asText();
			InputValidator.validateValue(str);
			if (str.contains(",")) {
				valArr = value.asText().split(",");
			} else if (isArray) {
				valArr = new Object[] { value.asText() };
			} else {
				val = value.asText();
			}
		}

		operand = valArr == null ? new Operand<>(val) : new Operand<>(valArr);
		return operand;
	}

	private static Operand<?> getRHOperandStateCity(JsonNode value, boolean isArray) throws InputValidationException {
		Class<?> valueClass = value.getClass();
		Operand<?> operand = null;
		Object val = null;
		Object[] valArr = null;
		// validate value for allowed characters
		if (valueClass == IntNode.class) {
			InputValidator.validateValue(Integer.valueOf(value.asInt()));
			val = Integer.valueOf(value.asInt());
		}
		if (valueClass == LongNode.class) {
			InputValidator.validateValue(Long.valueOf(value.asLong()));
			val = Long.valueOf(value.asLong());
		}
		if (valueClass == DoubleNode.class) {
			InputValidator.validateValue(Double.valueOf(value.asDouble()));
			val = Double.valueOf(value.asDouble());
		}
		if (valueClass == TextNode.class) {
			String str = value.asText().toUpperCase();
			InputValidator.validateValue(str);
			if (str.contains(",")) {
				valArr = value.asText().toUpperCase().split(",");
			} else if (isArray) {
				valArr = new Object[] { value.asText().toUpperCase() };
			} else {
				val = value.asText().toUpperCase();
			}
		}

		operand = valArr == null ? new Operand<>(val) : new Operand<>(valArr);
		return operand;
	}
}
