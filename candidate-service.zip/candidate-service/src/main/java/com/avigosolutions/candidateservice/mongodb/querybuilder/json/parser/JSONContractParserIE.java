package com.avigosolutions.candidateservice.mongodb.querybuilder.json.parser;

import static com.avigosolutions.candidateservice.mongodb.querybuilder.json.parser.JSONContractParserHelperIE.getSCCLogicalGroupContainers;

import org.springframework.stereotype.Component;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.InputValidationException;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class JSONContractParserIE {
	
	public SearchCriteriaGroupContainerIE parseJSONInput(JsonNode rootNode, ContainerType cType, boolean isNonEID) throws InputValidationException {
		return (SearchCriteriaGroupContainerIE) getSCCLogicalGroupContainers(new SearchCriteriaGroupContainerIE(cType),
				rootNode, isNonEID);
	}
}
