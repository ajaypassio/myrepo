package com.avigosolutions.candidateservice.mongodb.querybuilder.json.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.FieldValidationException;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.InputValidationException;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.ValueValidationException;

/**
 * This class validated the JSON field(s) and value(s) for valid values. The
 * purpose is to prevent any kind of (No)SQL injection (of Mongodb).
 * 
 * @author samarth.srivastava
 *
 */
public class InputValidator {

	private InputValidator() {
		throw new UnsupportedOperationException("instantiation not allowed.");
	}

	// field can belong to the character class \w (a word character [a-zA-Z_0-9]);
	// acceptable pattern is \w+
	private static final Pattern FIELD_PATTERN = Pattern.compile("\\w+");

	// text value can be a belong to the class [a-zA-Z_0-9.,-]
	private static final Pattern VALUE_PATTERN = Pattern.compile("[a-zA-Z_0-9.,()%\\s-/]+");

	public static void validateField(String fieldStr) throws InputValidationException {
		Matcher matcher = FIELD_PATTERN.matcher(fieldStr);
		if (!matcher.matches()) {
			throw new FieldValidationException("Field string pattern mismatch for field: " + fieldStr);
		}
	}

	public static <T> void validateValue(T value) throws InputValidationException {
		if (value == null)
			return;
		if (value instanceof String) {
			validateStringValue((String) value);
		}
		if (value instanceof Number) {
			validateNumberValue((Number) value);
		}
	}

	private static void validateNumberValue(Number n) throws InputValidationException {
		// not performing number validations as of now
		/*
		 * if(n instanceof Integer) { throw new
		 * ValueValidationException("Integer value not allowed: " + n); } if (n
		 * instanceof Long) { throw new
		 * ValueValidationException("Long value not allowed: " + n); } if(n instanceof
		 * Double) { throw new ValueValidationException("Double value not allowed: " +
		 * n); }
		 */
		return;
	}

	private static void validateStringValue(String valueStr) throws InputValidationException {
		Matcher matcher = VALUE_PATTERN.matcher(valueStr);
		if (!matcher.matches()) {
			throw new ValueValidationException("Value string pattern mismatch for value: " + valueStr);
		}
	}

}
