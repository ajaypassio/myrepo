package com.avigosolutions.candidateservice.mongodb.querybuilder.util;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Expression;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Operand;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.expression.Operator;

public class ExpressionUtilIE {

	private ExpressionUtilIE() {
		throw new UnsupportedOperationException("Instantiation not allowed.");
	}
	
	/**
	 * Applies precedence rules on a queue of operands and operators, which vary in alternate order.
	 * After applying, result is an Expression which may have embedded expressions in the operands
	 * according to rules of precedence of logical operators (only [AND, OR] supported).
	 * @param expression a queue containing operands and operators (logical only) 
	 */
	@SuppressWarnings("unchecked")
	public static <T> Expression applyPrecedence(Queue<?> values) {
		// base case(s)
		if(values == null || values.isEmpty() || values.size() == 1) {
			return null;
		}
		if(!(values.peek() == LogicalOperator.NOT || values.peek() instanceof Operand)) {
			throw new IllegalArgumentException("first element must either be a NOT operator or an operand.");
		}
		
		Deque<Operand<T>> operandStack = new LinkedList<>();
		Deque<Operator> operatorStack = new LinkedList<>();
		Expression expression = new Expression();
		while (values.peek() != null) {
			Object value = values.poll();
			if (value instanceof Operand) {
				expression = processOperand((Operand<T>) value, operandStack, operatorStack, expression);
			} else if(value instanceof Operator) {
				operatorStack.push((Operator) value);
			}
		}
		return expression;
	}

	private static <T> Expression processOperand(Operand<T> operand, Deque<Operand<T>> operandStack,
			Deque<Operator> operatorStack, Expression expression) {
		Operand<T> lastOperand = operandStack.peekFirst();
		Operator lastOperator = operatorStack.peekFirst();

		operandStack.push(operand);
		if (lastOperand == null) {
			// first operand encountered. Add as LHOperand in expression
			expression.setLeftOperand(operand);
		} else {
			// an operand already exists, check for Operator and RHOperand in expression
			if (expression.getRightOperand() == null) {
				expression.setOperator(lastOperator);
				expression.setRightOperand(operand);
			} else { // RHO in expression already exists
				// compare precedence of previous 2 operators
				lastOperator = operatorStack.pop();
				Operator secondLastOperator = operatorStack.peekFirst();
				// restore operator stack
				operatorStack.push(lastOperator);
				if (lastOperator.getPrecedence() <= secondLastOperator.getPrecedence()) {
					// e.g. A AND B OR C, A OR B OR C, A AND B AND C - left to right precedence
					return new Expression(new Operand<Expression>(expression), lastOperator, operand);
				} else if (lastOperator.getPrecedence() > secondLastOperator.getPrecedence()) {
					// e.g. A OR B AND C
					return expression.setRightOperand(
							new Operand<Expression>(new Expression(lastOperand, lastOperator, operand)));
				}
			}
		}
		return expression;
	}
	
	public static String extractStringExpression(Expression expression) {
		String leftOperand = getOperand(expression.getLeftOperand());
		Operator operator = expression.getOperator();
		String rightOperand = getOperand(expression.getRightOperand());
		return prepareStringExpression(leftOperand, operator, rightOperand);
	}
	
	private static <T> String getOperand(Operand<T> operand) {
		if(operand.getType().equals(String.class)) {
			return (String)operand.getValue();
		} else if (operand.getType().equals(Expression.class)) {
			return extractStringExpression((Expression)operand.getValue());
		}
		return null;
	}
	
	private static String prepareStringExpression(String leftOperand, Operator operator, String rightOperand) {
		if(operator instanceof LogicalOperator) {
			String operatorStr = null;
			if(operator == LogicalOperator.AND) {
				operatorStr = "$and : [";
			} else if(operator == LogicalOperator.OR) {
				operatorStr = "$or : [";
			} 
			return operatorStr + leftOperand + ", " + rightOperand + "]";
		}
		return null;
	}
	
	
}
