package com.avigosolutions.candidateservice.mongodb.querybuilder.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Deque;
import java.util.LinkedList;

public class RuntimeHelperIE {
	
	private RuntimeHelperIE() { 
		throw new UnsupportedOperationException("instantiation not allowed."); 
	}
	 		
	@SuppressWarnings("unchecked")
	public static <T, A, R> R invokeMethodOnInstance(T t, String methodName, A args, Class<?> ...paramterTypes) throws IllegalAccessException,
	InvocationTargetException, NoSuchMethodException {
		Method methodToInvoke = t.getClass().getMethod(methodName, paramterTypes);

		return (R) methodToInvoke.invoke(t, new Object[] {args});
	}
	
	public static String getFieldPath(String targetFieldName, String clazzName) 
			throws IllegalAccessException, InvocationTargetException, ClassNotFoundException {
		Class<?> clazz = Class.forName(clazzName);
		Deque<String> pathStack = new LinkedList<>();
		// root node
		Node<Class<?>> root = new Node<>(null, clazz);

		pathStack = getFieldPath(targetFieldName, clazz, pathStack, root);
		StringBuilder pathBuilder = new StringBuilder();

		if(pathStack.peekLast() != null) {
			pathBuilder.append(pathStack.pollLast());
			while(pathStack.peekLast() != null) {
				pathBuilder.append(".").append(pathStack.pollLast());
			}
		}

		return pathBuilder.toString();
	}

	/**
	 * Finds field path using backtracking(depth-first search) algorithm.
	 * 1. Implements backtracking algorithm for determining field path in the given class recursively going in member classes.
	 * 1.1 It searches all fields/fields' declared annotation(s) for the matching target field name.
	 * 2. If field type has a generic and belongs to the same package as member class then do a depth-first search of this class.
	 * 3. If no generic type belonging to member package found and field also not found then return back.
	 * 4. Uses a stack to track depth/path
	 * @param targetFieldName
	 * @param clazz
	 * @param traversedPath
	 * @param parent
	 * @return the final traversed path as a stack with target node's parent node at the head.
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 */
	private static Deque<String> getFieldPath(String targetFieldName, Class<?> clazz, Deque<String> traversedPath, Node<Class<?>> parent) 
			throws IllegalAccessException, InvocationTargetException {
		for(Field field : clazz.getDeclaredFields()) {
			if(inspectFieldForTarget(targetFieldName, field, traversedPath, false)) {
				// solution found - base case
				parent.setOnPath(true);
				return traversedPath;
			}
			Class<?> parameterizedTypeClass = null;
			try {
				Type fieldType = field.getGenericType();
				if(fieldType instanceof ParameterizedType) {
					parameterizedTypeClass = (Class<?>) ((ParameterizedType)fieldType).getActualTypeArguments()[0];
					// not supporting other package scanning as of now. All classes must be in same package.
					if(parameterizedTypeClass.getPackage().getName().equals(clazz.getPackage().getName())) {
						inspectFieldForTarget(targetFieldName, field, traversedPath, true);
						Node<Class<?>> node = new Node<>(parent, parameterizedTypeClass);						
						traversedPath = getFieldPath(targetFieldName, parameterizedTypeClass, traversedPath, node);
					}
				}								
			} catch (ClassCastException cce) {
				// It's a bit of hack here but never follow the practice of swallowing exception.
				// thrown for fields which have parameterized type containing '?'.
			}
		}
		// nothing found in the node. Mark it as a dead-end and remove the node from the traversed path to the junction point.
		if(!parent.isOnPath()) {
			parent.setDeadEnd(true);
			if(traversedPath.peek() != null) {
				traversedPath.pop();
			}
		}		

		return traversedPath;
	}

	private static boolean inspectFieldForTarget(String target, Field field, Deque<String> path, boolean push) 
			throws IllegalAccessException, InvocationTargetException {
		// add field name to traversedPath
		if (field.getAnnotations().length > 0) {
			// Check annotations declared on the field, invoke the first "value" method on
			// the annotation,
			// wherever it is encountered first and push it
			for (Annotation fieldAnnotation : field.getAnnotations()) {
				Class<? extends Annotation> annotationType = fieldAnnotation.annotationType();
				for (Method method : annotationType.getDeclaredMethods()) {
					if (method.getName().equalsIgnoreCase("value")) {
						Object obj = method.invoke(fieldAnnotation, (Object[]) null);
						if (obj instanceof String) {
							String currentInvocation = (String) obj;
							if (push) {
								path.push(currentInvocation);
							} else if (currentInvocation.equalsIgnoreCase(target)) {
								return true;
							}
						}
					}
				}
			}
		} else {
			if (push) {
				path.push(field.getName());
			} else if (field.getName().equalsIgnoreCase(target)) {
				return true;
			}
		}
		return false;
	}                                 

}
