package com.avigosolutions.candidateservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.avigosolutions.candidateservice.model.SavedSearch;

public interface SavedSearchRepository extends MongoRepository<SavedSearch, String> {
	public SavedSearch findBySearchName(String searchName);

	public SavedSearch findBySearchNameAndTrialId(String searchName, long trialId);

	public Page<SavedSearch> findByTrialId(long trialId, Pageable page);

	public List<SavedSearch> findByTrialId(long trialId);

	public void deleteBySearchNameAndTrialId(String searchName, long trialId);

}
