package com.avigosolutions.candidateservice.response.model;

import java.util.List;

import com.avigosolutions.candidateservice.model.SavedSearch;

public class SavedSearchResponse {

	private List<SavedSearch> savedSearchList;
	private long total;

	public List<SavedSearch> getSavedSearchList() {
		return savedSearchList;
	}

	public SavedSearchResponse withSavedSearchList(List<SavedSearch> savedSearchList) {
		this.savedSearchList = savedSearchList;
		return this;
	}

	public long getTotal() {
		return total;
	}

	public SavedSearchResponse withTotal(long total) {
		this.total = total;
		return this;
	}
}
