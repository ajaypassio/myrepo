/**
 * 
 */
package com.avigosolutions.candidateservice.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.avigosolutions.candidateservice.constants.Constants;
import com.avigosolutions.candidateservice.model.CampaignModel;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo.CampaignPatientAggregationPipelineQueryBuilder;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.InputValidationException;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.parser.JSONContractParserIE;
import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

/**
 * @author Ajay Kumar
 *
 */
@Component
public class CampaignPatientHelper {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.campaign.patient.blob.storage.connection.string}")
	String storageConnectionString;

	@Value("${sprintt.campaign.patient.blob.storage.containerName}")
	String containerName;

	@Value("${mongoSearchCollectionName}")
	private String mongoSearchCollectionName;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private JSONContractParserIE jsonContractParser;

	@Autowired	
	private CampaignPatientAggregationPipelineQueryBuilder queryBuilder;

	public Boolean populateCampaignPatient(CampaignModel campaignModel) {
		try {
			byte[] payloadBytes = generateCampaignPatients(campaignModel).toString().getBytes(StandardCharsets.UTF_8);
			CloudBlobContainer container = getContainer();

			String fileNeme = new StringBuilder(Constants.TRIAL).append(Constants.UNDERSCORE)
					.append(campaignModel.getTrialId()).append(Constants.UNDERSCORE)
					.append(campaignModel.getChannel()).append(Constants.UNDERSCORE)
					.append(campaignModel.getSprinttCampaignId()).append(Constants.UNDERSCORE)
					.append(Constants.CAMPAIGN_FILE_NAME).append(Constants.CAMPAIGN_FILE_FORMAT).toString();

			String filePath = new StringBuilder(Constants.CAMPAIGN_FILE_FOLDER).append(Constants.BACKSLASH)
					.append(fileNeme).toString();
			logger.info("Campaign File Path : {} ", filePath);
			CloudBlockBlob blob = container.getBlockBlobReference(filePath);
			blob.uploadFromByteArray(payloadBytes, 0, payloadBytes.length);
		} catch (InvalidKeyException | URISyntaxException | StorageException | IOException e) {
			logger.error("Error occurred while adding file in campaign patient conatiner : {} ", e);
			return Boolean.FALSE;
		}
		logger.info("Campaign patient generation is successfully completed");
		return Boolean.TRUE;
	}

	public StringBuilder generateCampaignPatients(CampaignModel campaignModel) {

		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> inclusionPatients = new HashMap<>();
		Map<String, String> inclusionPatientsNonEid = new HashMap<>();
		String collectionName = getPatientsCollectionName(campaignModel.getTrialId());
		// Inclusion Criteria, Exclusion Criteria - if difference is true
		if (campaignModel.isDifference() && (!StringUtils.isEmpty(campaignModel.getInclusionCriteria())
				|| !StringUtils.isEmpty(campaignModel.getExclusionCriteria()))) {
			SearchCriteriaGroupContainerIE inclusionCriteria = null;
			SearchCriteriaGroupContainerIE exclusionCriteria = null;
			SearchCriteriaGroupContainerIE inclusionCriteriaNonEid = null;
			SearchCriteriaGroupContainerIE exclusionCriteriaNonEid = null;
			try {
				inclusionCriteria = jsonContractParser.parseJSONInput(
						mapper.readTree(campaignModel.getInclusionCriteria()), ContainerType.INCLUSION_CRITERIA,false);
				inclusionCriteriaNonEid = jsonContractParser.parseJSONInput(
						mapper.readTree(campaignModel.getInclusionCriteria()), ContainerType.INCLUSION_CRITERIA,true);
                if(!StringUtils.isEmpty(campaignModel.getExclusionCriteria())) {
				exclusionCriteria = jsonContractParser.parseJSONInput(
						mapper.readTree(campaignModel.getExclusionCriteria()), ContainerType.EXCLUSION_CRITERIA,false);
				exclusionCriteriaNonEid = jsonContractParser.parseJSONInput(
						mapper.readTree(campaignModel.getExclusionCriteria()), ContainerType.EXCLUSION_CRITERIA,true);
                }
			} catch (InputValidationException | IOException e) {
				logger.error("Caught exception during fetch campaign patient data : {}", e);
			}
			inclusionPatients = (inclusionCriteria == null || inclusionCriteria.isEmpty()) ? inclusionPatients
					: queryBuilder.buildMap(inclusionPatients, inclusionCriteria, null, collectionName);
			inclusionPatientsNonEid = (inclusionCriteriaNonEid == null || inclusionCriteriaNonEid.isEmpty()) ? inclusionPatientsNonEid
					: queryBuilder.buildMap(inclusionPatientsNonEid, inclusionCriteriaNonEid, null, collectionName);
			if (!CollectionUtils.isEmpty(inclusionPatients)) {
				inclusionPatients = (exclusionCriteria == null || exclusionCriteria.isEmpty()) ? inclusionPatients
						: queryBuilder.buildMap(inclusionPatients, exclusionCriteria, null, collectionName);
			}
			if (!CollectionUtils.isEmpty(inclusionPatientsNonEid)) {
				inclusionPatientsNonEid = (exclusionCriteriaNonEid == null || exclusionCriteriaNonEid.isEmpty()) ? inclusionPatientsNonEid
						: queryBuilder.buildMap(inclusionPatientsNonEid, exclusionCriteriaNonEid, null, collectionName);
				inclusionPatients.putAll(inclusionPatientsNonEid);
			}

			return new StringBuilder(String.join(Constants.NEW_LINE, inclusionPatients.values()));
		} else {
			return populateCampaignPatientData(collectionName);
		}
	}

	private StringBuilder populateCampaignPatientData(String collectionName) {
		BasicDBObject query = new BasicDBObject();
		BasicDBObject fields = new BasicDBObject(Constants.PATIENT_ID, "1").append(Constants.LONGITUDE, "1")
				.append(Constants.LATITUDE, "1").append(Constants.EID, "1");
		DBCursor cursor = mongoTemplate.getDb().getCollectionFromString(collectionName).find(query, fields);
		StringBuilder builder = new StringBuilder();
		while (cursor.hasNext()) {
			DBObject dbObject = cursor.next();
			builder.append(String.join(Constants.COMMA, (String) dbObject.get(Constants.PATIENT_ID),
					String.valueOf(dbObject.get(Constants.LONGITUDE)),
					String.valueOf(dbObject.get(Constants.LATITUDE)),String.valueOf(dbObject.get(Constants.EID))));
			builder.append(Constants.NEW_LINE);
		}
		return builder;
	}

	private String getPatientsCollectionName(long trailID) {
		if (!StringUtils.isEmpty(mongoSearchCollectionName)) {
			return mongoSearchCollectionName;
		}
		return "T_" + trailID;
	}

	private CloudBlobContainer getContainer() throws InvalidKeyException, URISyntaxException, StorageException {
		logger.info("Campaign patient generation container");
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;

		storageAccount = CloudStorageAccount.parse(storageConnectionString);
		logger.info("Campaign Patient getStorageConnectionString : {} ", storageConnectionString);
		blobClient = storageAccount.createCloudBlobClient();
		container = blobClient.getContainerReference(containerName);
		container.createIfNotExists();
		return container;

	}

}
