package com.avigosolutions.candidateservice.service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import com.avigosolutions.candidateservice.model.Candidate;
import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.GeoCandidate;

public interface CandidateService {

	public Optional<List<Candidate>> getCandidatesByTrial(Long trialId);

	public Optional<GeoCandidate> getGeoCandidatesByTrial(Long trialId);
	public CriteriaCounts getFacetedSearchResults(Long trialId, int iteration, String bigDataJson);

}
