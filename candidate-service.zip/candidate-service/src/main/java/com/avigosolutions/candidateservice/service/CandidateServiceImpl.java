package com.avigosolutions.candidateservice.service;

//import static org.hamcrest.CoreMatchers.instanceOf;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.candidateservice.model.Candidate;
import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.GeoCandidate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.primitives.Ints;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.OperationContext;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

//////////////////////////////// This class is deprecated. This was an interim implementation that will be removed ////////////////////////////////////
// Original purpose of this class was to use an interim/temporary implementation using Blob Storage for persistence //
// Use Patient Service for the current implementation of faceted search and saved search
@Deprecated
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CandidateServiceImpl implements CandidateService {

	@Override
	public Optional<List<Candidate>> getCandidatesByTrial(Long trialId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<GeoCandidate> getGeoCandidatesByTrial(Long trialId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CriteriaCounts getFacetedSearchResults(Long trialId, int iteration, String bigDataJson) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * private Logger logger = LoggerFactory.getLogger(this.getClass()); //
	 * DefaultEndpointsProtocol=https;AccountName=dgxsprinttdev;AccountKey=
	 * d9WEwXPITL/h8zHDLovVmORBU5Jh3g924wKOgNTzzQ9PcJ+
	 * Dzo7eOu4ORhosgaxXHjlue0Nct17SgGRqTfbgqg==;EndpointSuffix=core.windows.net
	 * private static final String storageConnectionString =
	 * "DefaultEndpointsProtocol=http;" + "AccountName=dgxsprinttdev;" +
	 * "AccountKey=d9WEwXPITL/h8zHDLovVmORBU5Jh3g924wKOgNTzzQ9PcJ+Dzo7eOu4ORhosgaxXHjlue0Nct17SgGRqTfbgqg==";
	 * static String BLOB_CONTAINER_NAME = "bigdata" //"bigdata/js-output"
	 * //"bigdata/jawahar"
	 * 
	 * ; static String BLOB_DIRECTORY_PREFIX = "pdr-2/output/trial-";
	 * //"js-output/trial-"; private static String SPARK_OUTPUT_FILE_PREFIX =
	 * "part-"; private static String COUNTS_FOLDER = "counts";
	 * 
	 * 
	 * @Override public Optional<List<Candidate>> getCandidatesByTrial(Long trialId)
	 * { // return Optional.ofNullable(getCandidateListFromMemory(trialId,
	 * csvFilename));
	 * 
	 * return Optional.ofNullable(readFromAzureBlobStorage(trialId, 0))
	 * .map(csvFilenameList -> getCandidateListFromCSV(trialId, csvFilenameList));
	 * 
	 * // The above code can be written in a verbose manner: //
	 * Optional<List<String>> optFilenameList =
	 * Optional.ofNullable(readFromAzureBlobStorage(trialId)); //
	 * Optional<List<Candidate>> optCandidateList = //
	 * optFilenameList.map(csvFilenameList -> getCandidateListFromCSV(trialId,
	 * csvFilenameList)); // return optCandidateList; }
	 * 
	 * @Override public Optional<GeoCandidate> getGeoCandidatesByTrial(Long trialId)
	 * {
	 * 
	 * return Optional.ofNullable(getGeoCandidate(trialId, 0)) //map(csvFilenameList
	 * -> getCandidateListFromCSV(trialId, csvFilenameList)) ; }
	 * 
	 * // Following methods are intentionally made "package private" and not private
	 * - so we can test via JUnit // There is a school of thought that JUnit testing
	 * should only be done on public methods, however we have reads from Azure
	 * Storage and // processing of objects from CSV which have to be tested.
	 * List<Candidate> getCandidateListFromCSV(Long trialId, List<String>
	 * csvFilenameList) {
	 * 
	 * List<Candidate> candidateList = new ArrayList<>(); for(String csvFilename:
	 * csvFilenameList) { try { Reader reader =
	 * Files.newBufferedReader(Paths.get(csvFilename)); //Reader reader =
	 * Files.newBufferedReader(Paths.get(getClass().getClassLoader().getResource(
	 * "trial-1.csv").toURI())); //Path path = Paths.get(getClass().getClassLoader()
	 * // .getResource("fileTest.txt").toURI()); //Reader reader = new
	 * BufferedReader(new
	 * InputStreamReader(getClass().getResourceAsStream(SAMPLE_CSV_FILE_PATH)));
	 * 
	 * CsvToBean<Candidate> csvToBean = new CsvToBeanBuilder<Candidate>(reader)
	 * .withType(Candidate.class) .withSeparator('|')
	 * .withIgnoreLeadingWhiteSpace(true) .build() ; List<Candidate>
	 * tempCandidateList = csvToBean.parse(); List<Candidate> newList =
	 * Stream.concat(candidateList.stream(), tempCandidateList.stream())
	 * .collect(Collectors.toList()); candidateList = newList; } catch (Exception e)
	 * { logger.error("Error in getCandidateListFromCSV for trial id: " + trialId +
	 * " csvFile: " + csvFilename + " Message: " + e.getMessage() + " \n" + e); } }
	 * return candidateList;
	 * 
	 * }
	 * 
	 * List<String> readFromAzureBlobStorage(Long trialId, int iteration) {
	 * logger.info("readFromAzureBlobStorage Trial Id: " + trialId); //
	 * "{\"CloudHub.Azure.Storage.Blobs\":{\"connectionString\":\"BlobEndpoint=https://dgxsprinttdev.blob.core.windows.net;SharedAccessSignature=sv=2017-04-17&ss=b&srt=co&sp=rl&st=2017-11-11T16%3A16%3A51Z&se=2017-11-12T16%3A31%3A51Z&sig=hTSnKBzHQdkvfcRpI67jJMtf%2FqHvXV7H1GZ%2FzG4RYWQ%3D\",\"containerName\":\"bigdata\",\"accountUri\":\"https://dgxsprinttdev.blob.core.windows.net\",\"sourceFolder\":\"\",\"items\":[{\"relativePath\":\"hive_patient_master_dd-1lab-20171016-140000.csv\",\"snapshot\":\"\"}],\"sasToken\":\"sv=2017-04-17&ss=b&srt=co&sp=rl&st=2017-11-11T16%3A16%3A51Z&se=2017-11-12T16%3A31%3A51Z&sig=hTSnKBzHQdkvfcRpI67jJMtf%2FqHvXV7H1GZ%2FzG4RYWQ%3D\"}}"
	 * 
	 * //String blobContainerByTrail = blobContainerName + "/trial-" + trialId +
	 * "/"; String blobContainerByTrail = BLOB_CONTAINER_NAME;
	 * //blobContainerByTrail = blobContainerName; final List<String> fileNameList =
	 * new ArrayList<String>(); try { // Retrieve storage account from
	 * connection-string. CloudStorageAccount storageAccount =
	 * CloudStorageAccount.parse(storageConnectionString);
	 * 
	 * // Create the blob client. CloudBlobClient blobClient =
	 * storageAccount.createCloudBlobClient();
	 * OperationContext.setLoggingEnabledByDefault(true); logger.info("Container: "
	 * + blobContainerByTrail); // Retrieve reference to a previously created
	 * container. CloudBlobContainer container =
	 * blobClient.getContainerReference(blobContainerByTrail); CloudBlobDirectory
	 * dir = container.getDirectoryReference(BLOB_DIRECTORY_PREFIX + trialId + "/" +
	 * iteration + "/patients"); // Loop through each blob item in the container. //
	 * for (ListBlobItem blobItem: dir.listBlobs()) { // logger.info("In For: " +
	 * blobItem.toString() + " uri: " + blobItem.getUri().toString()); // if
	 * (blobItem instanceof CloudBlob) { // // CloudBlob blob = (CloudBlob)
	 * blobItem; // String fileName =
	 * Paths.get(blob.getName()).getFileName().toString(); // if
	 * (fileName.startsWith(SPARK_OUTPUT_FILE_PREFIX)) { // // String outFile =
	 * System.getProperty("java.io.tmpdir") + File.separator + fileName; //
	 * logger.info("FOUND: " + blob.getName() + " out: " + outFile + " p: " +
	 * fileName); // // blob.downloadToFile(outFile); // fileNameList.add(outFile);
	 * // } // // } // } logger.info("------readFromAzureBlobStorage Trial Id: " +
	 * trialId + " dir: " + dir.getUri().getPath()); Stream<ListBlobItem> streamLBI
	 * = StreamSupport.stream(dir.listBlobs().spliterator(), false); //final
	 * List<String> strList = new ArrayList<>(); streamLBI .filter(lbi -> lbi
	 * instanceof CloudBlob) .map(lbi -> (CloudBlob) lbi) .filter(cb ->
	 * Paths.get(cb.getName()).getFileName().toString().startsWith(
	 * SPARK_OUTPUT_FILE_PREFIX)) //.map(cb -> System.getProperty("java.io.tmpdir")
	 * + File.separator + Paths.get(cb.getName()).getFileName().toString())
	 * //.collect(Collectors.toList()) // if we do the above 2 statements, we no
	 * longer have access to CloudBlob and hence can't download the file .forEach(cb
	 * -> downloadFileAndAddToList(cb, fileNameList, trialId)); //forEach has to be
	 * the last operation because we need to download the file ; } catch
	 * (InvalidKeyException | URISyntaxException | StorageException | IOException |
	 * NoSuchElementException e) {
	 * logger.error("Error in readFromAzureBlobStorage for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e)); //fileNameList = null; } return
	 * fileNameList; }
	 * 
	 * 
	 * private void downloadFileAndAddToList(CloudBlob cb, List<String>
	 * fileNameList, Long trialId) { String fileName =
	 * Paths.get(cb.getName()).getFileName().toString(); String outFile =
	 * System.getProperty("java.io.tmpdir") + File.separator + fileName;
	 * logger.info("downloadFileAndAddToList: " + cb.getName() + " out: " + outFile
	 * + " p: " + fileName);
	 * 
	 * try { cb.downloadToFile(outFile); } catch (StorageException | IOException e)
	 * { logger.error("Error in downloadFileAndAddToList for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e)); } fileNameList.add(outFile);
	 * 
	 * } void putCriteriaJSON(Long trialId, int folderId) { // Retrieve storage
	 * account from connection-string. try { CloudBlobDirectory dir =
	 * getDirectoryReference("trial-" + trialId + "/" + folderId, trialId); //
	 * CloudBlockBlob blockBlob = dir.getBlockBlobReference("big-data.json"); //
	 * blockBlob.uploadFromFile("c:\\dev\\big-data.json"); // logger.info("---->" +
	 * dir.getContainer().getName()); //
	 * logger.info(dir.getParent().getUri().getPath());
	 * 
	 * // for (ListBlobItem blobItem: dir.getContainer().listBlobs()) { //
	 * logger.info("In For: " + blobItem.toString() + " uri: " +
	 * blobItem.getUri().toString()); //// if (blobItem instanceof
	 * CloudBlobDirectory) { //// CloudBlobDirectory cbd = (CloudBlobDirectory)
	 * blobItem; //// logger.info(cbd.getUri().toString() + " -- " +
	 * cbd.getStorageUri().toString()); //// } // } } catch (Exception e) {
	 * logger.error("Error in putCriteriaJSON for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e)); //fileNameList = null; }
	 * 
	 * } void getLargestFolderName(Long trialId) { CloudBlobDirectory dir =
	 * //getDirectoryReference("trial-" + trialId, trialId);
	 * getDirectoryReference("", trialId); try { // Stream<ListBlobItem> streamLBI =
	 * StreamSupport.stream(dir.listBlobs().spliterator(), false); // streamLBI //
	 * .filter(lbi -> lbi instanceof CloudBlobDirectory) // .map(lbi ->
	 * (CloudBlobDirectory) lbi) // //.filter(cbd -> Paths.get(cbd.) // //.map(cb ->
	 * System.getProperty("java.io.tmpdir") + File.separator +
	 * Paths.get(cb.getName()).getFileName().toString()) //
	 * //.collect(Collectors.toList()) // if we do the above 2 statements, we no
	 * longer have access to CloudBlob and hence can't download the file //
	 * //.forEach(cb -> downloadFileAndAddToList(cb, fileNameList, trialId));
	 * //forEach has to be the last operation because we need to download the file
	 * // .forEach(cbd -> logger.info(cbd.getUri().toString() + " -- " +
	 * cbd.getStorageUri().toString())); // ; for (ListBlobItem blobItem:
	 * dir.listBlobs()) { logger.info("In For: " + blobItem.toString() + " uri: " +
	 * blobItem.getUri().toString()); if (blobItem instanceof CloudBlobDirectory) {
	 * CloudBlobDirectory cbd = (CloudBlobDirectory) blobItem;
	 * logger.info(cbd.getUri().toString() + " -- " +
	 * cbd.getStorageUri().toString()); } }
	 * 
	 * 
	 * } catch (Exception e) {
	 * logger.error("Error in getLargestFolderName for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e)); //fileNameList = null; }
	 * 
	 * 
	 * } private CloudBlobDirectory getDirectoryReference(String directoryName, Long
	 * trialId) { try { CloudStorageAccount storageAccount =
	 * CloudStorageAccount.parse(storageConnectionString);
	 * 
	 * // Create the blob client. CloudBlobClient blobClient =
	 * storageAccount.createCloudBlobClient();
	 * OperationContext.setLoggingEnabledByDefault(true); // Retrieve reference to a
	 * previously created container. CloudBlobContainer container =
	 * blobClient.getContainerReference(BLOB_CONTAINER_NAME + "/");
	 * CloudBlobDirectory dir = container.getDirectoryReference(directoryName);
	 * return dir; } catch (InvalidKeyException | URISyntaxException |
	 * StorageException | IOException | NoSuchElementException e) {
	 * logger.error("Error in getDirectoryReference for trial id: " + trialId +
	 * " dir: " + directoryName + " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e)); //fileNameList = null; return
	 * null; }
	 * 
	 * } List<Candidate> getCandidateListFromMemory(Long trialId, String
	 * csvFilename) {
	 * 
	 * List<Candidate> candidateList = null; candidateList = Arrays.asList( new
	 * Candidate().withName("Cedric Sandars") .withGender("Male")
	 * .withAddress("124 Main St., Boston, MA") .withZipcode("02215") .withAge(30)
	 * //.withCoordinates(new Coordinates().withLatitude(
	 * -71.05977).withLongitude(42.35843)) .withId(1) .withPatientId(1234L) , new
	 * Candidate().withName("Joan Smith") .withGender("Female")
	 * .withAddress("124 Main St., Natick, MA") .withZipcode("03060") .withAge(40)
	 * //.withCoordinates(new Coordinates().withLatitude(
	 * -71.05977).withLongitude(42.35843)) .withId(2) .withPatientId(4567L)
	 * 
	 * 
	 * 
	 * 
	 * ); return candidateList;
	 * 
	 * } GeoCandidate getGeoCandidateFromMemory(Long trialId) { List<Candidate>
	 * candidateList = getCandidateListFromMemory(trialId, null); return new
	 * GeoCandidate().withFeatures(candidateList); } GeoCandidate
	 * getGeoCandidate(Long trialId, int iteration) {
	 * logger.info("START getGeoCandidate for: " + trialId); List<String>
	 * csvFilenameList = readFromAzureBlobStorage(trialId, iteration);
	 * List<Candidate> candidateList = getCandidateListFromCSV(trialId,
	 * csvFilenameList); logger.info("END getGeoCandidate for: " + trialId); return
	 * new GeoCandidate().withFeatures(candidateList); } private String
	 * returnStackTraceAsString(Exception e) { StringWriter sw = new StringWriter();
	 * e.printStackTrace(new PrintWriter(sw)); return sw.toString(); }
	 * 
	 * Map<String, Integer> criteriaToCountMap = new HashMap<>(); private
	 * List<String[]> processCountsFile(String fileName){ List<String[]> records =
	 * null; try (Reader reader = Files.newBufferedReader(Paths.get(fileName));
	 * CSVReader csvReader = new CSVReader(reader); ) { records =
	 * csvReader.readAll(); boolean firstTime = true; int i = 0; String[] header =
	 * null; for (String[] record : records) { if (firstTime) { //i = 0; header =
	 * record; firstTime = false; continue; } for (String cell : record) {
	 * logger.info(header[i] + "---" + cell); if
	 * (criteriaToCountMap.containsKey(header[i])) {
	 * criteriaToCountMap.put(header[i], Integer.parseInt(cell) +
	 * criteriaToCountMap.get(header[i])); } else criteriaToCountMap.put(header[i],
	 * Integer.parseInt(cell));
	 * 
	 * 
	 * i++;
	 * 
	 * } } } catch (IOException e) {
	 * logger.error("Error in downloadSparkOutputFiles for file: " + fileName +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * } return records; } private List<String>
	 * downloadSparkOutputFiles(CloudBlobDirectory cbd, List<String> fileNameList,
	 * Long trialId) { Stream<ListBlobItem> streamLBI; //final List<String>
	 * fileNameList = new ArrayList<String>(); try { streamLBI =
	 * StreamSupport.stream(cbd.listBlobs().spliterator(), false); streamLBI
	 * .filter(lbi -> lbi instanceof CloudBlob) .map(lbi -> (CloudBlob) lbi)
	 * .filter(cb -> Paths.get(cb.getName()).getFileName().toString().startsWith(
	 * SPARK_OUTPUT_FILE_PREFIX)) //.map(cb -> System.getProperty("java.io.tmpdir")
	 * + File.separator + Paths.get(cb.getName()).getFileName().toString())
	 * //.collect(Collectors.toList()) // if we do the above 2 statements, we no
	 * longer have access to CloudBlob and hence can't download the file .forEach(cb
	 * -> downloadFileAndAddToList(cb, fileNameList, trialId)); //forEach has to be
	 * the last operation because we need to download the file ; } catch (Exception
	 * e) { logger.error("Error in downloadSparkOutputFiles for trial id: " +
	 * trialId + " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * } return fileNameList; }
	 * 
	 * CloudBlobDirectory getMaxFoldername(Long trialId) {
	 * logger.info("getMaxFoldername Trial Id: " + trialId); //
	 * "{\"CloudHub.Azure.Storage.Blobs\":{\"connectionString\":\"BlobEndpoint=https://dgxsprinttdev.blob.core.windows.net;SharedAccessSignature=sv=2017-04-17&ss=b&srt=co&sp=rl&st=2017-11-11T16%3A16%3A51Z&se=2017-11-12T16%3A31%3A51Z&sig=hTSnKBzHQdkvfcRpI67jJMtf%2FqHvXV7H1GZ%2FzG4RYWQ%3D\",\"containerName\":\"bigdata\",\"accountUri\":\"https://dgxsprinttdev.blob.core.windows.net\",\"sourceFolder\":\"\",\"items\":[{\"relativePath\":\"hive_patient_master_dd-1lab-20171016-140000.csv\",\"snapshot\":\"\"}],\"sasToken\":\"sv=2017-04-17&ss=b&srt=co&sp=rl&st=2017-11-11T16%3A16%3A51Z&se=2017-11-12T16%3A31%3A51Z&sig=hTSnKBzHQdkvfcRpI67jJMtf%2FqHvXV7H1GZ%2FzG4RYWQ%3D\"}}"
	 * CloudBlobDirectory dir = null; CloudBlobDirectory cbdir = null; try { //
	 * Retrieve storage account from connection-string. // CloudStorageAccount
	 * storageAccount = CloudStorageAccount.parse(storageConnectionString); // // //
	 * Create the blob client. // CloudBlobClient blobClient =
	 * storageAccount.createCloudBlobClient(); //
	 * OperationContext.setLoggingEnabledByDefault(true); //
	 * logger.info("Container: " + blobContainerByTrail); // // Retrieve reference
	 * to a previously created container. // CloudBlobContainer container =
	 * blobClient.getContainerReference(blobContainerByTrail); // CloudBlobDirectory
	 * dir = container.getDirectoryReference(BLOB_DIRECTORY_PREFIX + trialId); dir =
	 * getDirectoryReference(BLOB_DIRECTORY_PREFIX + trialId, trialId);
	 * Stream<ListBlobItem> streamLBI =
	 * StreamSupport.stream(dir.listBlobs().spliterator(), false); cbdir = streamLBI
	 * .filter(lbi -> lbi instanceof CloudBlobDirectory) .map(lbi ->
	 * (CloudBlobDirectory) lbi) .filter(cbd ->
	 * Ints.tryParse(CandidateServiceImpl.getParentDirPath(cbd)) != null)
	 * //.max(Comparator.comparingInt(cbb ->
	 * Integer.parseInt(cbd.getUri().getPath()))) .reduce((cbd1,cbd2) ->
	 * Ints.tryParse(CandidateServiceImpl.getParentDirPath(cbd1)) >
	 * Ints.tryParse(CandidateServiceImpl.getParentDirPath(cbd2)) ? cbd1 : cbd2)
	 * 
	 * .orElse(null); // if (cbdir != null) { // logger.info("Found Max: " +
	 * cbdir.getUri()); // final List<String> fileNameList = new ArrayList<>(); //
	 * Stream<ListBlobItem> streamLBI2 =
	 * StreamSupport.stream(cbdir.listBlobs().spliterator(), false); // streamLBI2
	 * // .filter(lbi -> lbi instanceof CloudBlobDirectory) // .map(cbd ->
	 * (CloudBlobDirectory) cbd) // .filter(cbd ->
	 * CandidateServiceImpl.getParentDirPath(cbd).equals(COUNTS_FOLDER)) //
	 * .forEach(cbd -> { // logger.info("INSIDE: " +
	 * CandidateServiceImpl.getParentDirPath(cbd)); // downloadSparkOutputFiles(cbd,
	 * fileNameList, trialId); // } // ) // ; // fileNameList.stream() //
	 * .forEach(fname -> processCountsFile(fname) ); //
	 * criteriaToCountMap.forEach((key, val) -> logger.info("Key: " + key + " val: "
	 * + val)); // return cbdir; // } // else //
	 * logger.error("---- Max Dir not found ---");
	 * 
	 * } catch (Exception e) {
	 * logger.error("Error in getMaxFoldername for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * } logger.info("getMaxFoldername returning: " + cbdir.getUri().getPath() +
	 * " for trialId: " + trialId); return cbdir; } CloudBlobDirectory
	 * getFoldernameByIteration(Long trialId, int iteration) {
	 * logger.info("getFoldernameByIteration Trial Id: " + trialId +
	 * " and iteration: " + iteration); CloudBlobDirectory dir = null;
	 * CloudBlobDirectory cbdir = null; try { dir =
	 * getDirectoryReference(BLOB_DIRECTORY_PREFIX + trialId + "/" + iteration,
	 * trialId);
	 * 
	 * } catch (Exception e) {
	 * logger.error("Error in getFoldernameByIteration for trial id: " + trialId +
	 * " iteration: " + iteration + " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * } logger.info("getFoldernameByIteration returning: " + dir.getUri().getPath()
	 * + " for trialId: " + trialId); return dir; } private CriteriaCounts
	 * processCountsFolder (CloudBlobDirectory cbdir, Long trialId) { CriteriaCounts
	 * cc = null; criteriaToCountMap = new HashMap<>(); try { if (cbdir != null) {
	 * logger.info("processCountsFolder: " + cbdir.getUri()); final List<String>
	 * fileNameList = new ArrayList<>(); Stream<ListBlobItem> streamLBI2 =
	 * StreamSupport.stream(cbdir.listBlobs().spliterator(), false); streamLBI2
	 * .filter(lbi -> lbi instanceof CloudBlobDirectory) .map(cbd ->
	 * (CloudBlobDirectory) cbd) .filter(cbd ->
	 * CandidateServiceImpl.getParentDirPath(cbd).equals(COUNTS_FOLDER))
	 * .forEach(cbd -> { logger.info("INSIDE: " +
	 * CandidateServiceImpl.getParentDirPath(cbd)); downloadSparkOutputFiles(cbd,
	 * fileNameList, trialId); } ) ; fileNameList.stream() .forEach(fname ->
	 * processCountsFile(fname) ); criteriaToCountMap.forEach((key, val) ->
	 * logger.info("processCountsFolder Key: " + key + " val: " + val)); cc = new
	 * CriteriaCounts().withCriteriaNameToCountMap(criteriaToCountMap);
	 * 
	 * } else logger.error("---- processCountsFolder NOT FOUND ---"); } catch
	 * (Exception e) {
	 * logger.error("Error in readFromAzureBlobStorage for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * } return cc; }
	 * 
	 * @Override public CriteriaCounts getFacetedSearchResults(Long trialId, int
	 * iteration, String bigDataJson) { //CloudBlobDirectory cbd =
	 * getMaxFoldername(trialId); CloudBlobDirectory cbd =
	 * getFoldernameByIteration(trialId, iteration); CriteriaCounts cc =
	 * processCountsFolder(cbd, trialId); if (cc != null)
	 * cc.getCriteriaNameToCountMap().forEach((key, val) -> logger.info("Key: " +
	 * key + " val: " + val)); GeoCandidate gc = getGeoCandidate(trialId,
	 * iteration); cc.withGeoCandidate(gc); return cc; }
	 * 
	 * public void writeBigDataJson(Long trialId) { try { String bigDataJson =
	 * getTrialById(trialId); CloudBlobDirectory cbd = getMaxFoldername(trialId);
	 * logger.info("Writing big data json to: " + cbd.getUri()); CloudBlockBlob blob
	 * = cbd.getBlockBlobReference("bigdata.json"); blob.uploadText(bigDataJson); }
	 * catch (Exception e) {
	 * logger.error("Error in readFromAzureBlobStorage for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * }
	 * 
	 * } public String doFacetedSearch(Long trialId, String bigDataJson) { String
	 * blobStr = null; try { CloudBlobDirectory cbd = getMaxFoldername(trialId);
	 * 
	 * logger.info("Writing big data json to: " + cbd.getUri()); CloudBlockBlob blob
	 * = cbd.getBlockBlobReference("bigdata.json"); blob.uploadText(bigDataJson);
	 * blobStr = blob.getUri().getPath(); } catch (Exception e) {
	 * logger.error("Error in doFacetedSearch for trial id: " + trialId +
	 * " Message: " + e.getMessage() + " \n");
	 * 
	 * logger.error(returnStackTraceAsString(e));
	 * 
	 * } return blobStr; } public String getTrialById(Long trialId) { // TODO - HARD
	 * CODED trialId!!! final String uri = "http://localhost:9001/api/v1/trials/" +
	 * 1; RestTemplate restTemplate = new RestTemplate(); // ClinicalTrial ct =
	 * restTemplate.getForObject(uri, ClinicalTrial.class); ResponseEntity<String>
	 * resp = restTemplate.getForEntity(uri, String.class); ObjectMapper mapper =
	 * new ObjectMapper(); JsonNode root; String bigDataJsonStr = null; try { root =
	 * mapper.readTree(resp.getBody()); logger.info(resp.getBody()); JsonNode
	 * bigDataJson = root.path("trialJson"); bigDataJsonStr = bigDataJson.asText();
	 * logger.info("bigData: " + bigDataJsonStr);
	 * 
	 * } catch (JsonProcessingException e) { e.printStackTrace(); } catch
	 * (IOException e) { e.printStackTrace(); } return bigDataJsonStr;
	 * 
	 * }
	 * 
	 * public void getCriteriaCounts(Long trialId) { CloudBlobDirectory cbd =
	 * getMaxFoldername(trialId); } public static String
	 * getParentDirPath(CloudBlobDirectory cbd) { File f = new
	 * File(cbd.getUri().getPath()); return f.getName().toString(); } public static
	 * int compareDirByName(CloudBlobDirectory cbd1, CloudBlobDirectory cbd2) { int
	 * x = Ints.tryParse(cbd1.getUri().getPath()); int y =
	 * Ints.tryParse(cbd2.getUri().getPath()); return x - y; } public String
	 * getIntDirName(CloudBlobDirectory cbd) { logger.info("In getIntDirName: " +
	 * cbd.getUri().getPath()); return cbd.getUri().getPath(); }
	 */
	
}
