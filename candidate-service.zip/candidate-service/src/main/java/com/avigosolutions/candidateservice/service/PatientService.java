package com.avigosolutions.candidateservice.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.LabRecords;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.model.PatientDetails;
import com.avigosolutions.candidateservice.model.SearchModel;

public interface PatientService {
	// j public List<Patient> getPatients();
	public CriteriaCounts getCriteriaCountMapAndPatients(SearchModel searchModel);

	public PatientDetails findByPatientId(String patientId, long trialID);

	public String getPatientsCollectionName(long trailID);

	Map<String, String> getCriterias(String trialJson);

	String getCompleteJSON(String trialJson);

	public List<LabRecords> findLabReportByPatientIdAndTrialId(String patientId, long trialID);

	public String testServiceMethodCallPerformance(String collectionName);

	public String testRestAPIPerformace(String collectionName);

	Map<String, Integer> getCriteriaCountMap(Long trialId, String trialJson);
	
	Map<String, Integer> getCriteriaCountMap(Long trialId, String trialJson, Integer totalCandidates);
	
	CriteriaCounts getCriteriaCountsAndPatients(Long trialId, String trialJson, Pageable page, boolean hasAggregation,
			String fields, boolean isDifferent,boolean hasExport);

	CriteriaCounts getCriteriaCountMapAndPatientsGeoData(SearchModel searchModel, String fields);

	void setPatientsCoordinates(List<Patient> patients);

}
