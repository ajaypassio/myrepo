package com.avigosolutions.candidateservice.service;

import java.io.IOException;
import java.net.URI;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.quickgeo.Place;
import org.quickgeo.PostalDbFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.avigosolutions.candidateservice.model.Coordinates;
import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.GeoPatient;
import com.avigosolutions.candidateservice.model.Geometry;
import com.avigosolutions.candidateservice.model.LabRecords;
import com.avigosolutions.candidateservice.model.MongoPageRequest;
import com.avigosolutions.candidateservice.model.PatientDetails;
import com.avigosolutions.candidateservice.model.SearchModel;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.ContainerType;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.domain.mongo.PipelineQueryBuilderIE;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.exception.InputValidationException;
import com.avigosolutions.candidateservice.mongodb.querybuilder.json.parser.JSONContractParserIE;
import com.avigosolutions.candidateservice.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.mongodb.BasicDBObject;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class PatientServiceImpl implements PatientService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private static String COMPLETE_TAG = "complete";

	// @Autowired
	private MongoOperations mongoOperations;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private JSONContractParserIE jsonContractParser;

	@Autowired
	private PipelineQueryBuilderIE<Patient> queryBuilder;

	@Autowired
	public void setMongoOperations(MongoOperations mongoOperations) {
		logger.info("##### calling setMongoOperations: " + mongoOperations.toString());
		this.mongoOperations = mongoOperations;
	}

	@Value("${mongoSearchCollectionName}")
	private String mongoSearchCollectionName;

	private ThreadLocal<String> strTagForCompleteJson = new ThreadLocal<>();

	private ThreadLocal<String> collectionName = new ThreadLocal<>();

	@Autowired
	RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	/*
	 * If configuration for mongoSearchCollectionName is empty use dynamic
	 * collection name i.e. T_TrialID
	 */
	private void initPatientsCollectionName(String name) {
		if (StringUtils.isEmpty(mongoSearchCollectionName)) {
			collectionName.set(name);
		} else {
			collectionName.set(mongoSearchCollectionName);
		}
	}

	private String getPatientsCollectionName() {
		if (!StringUtils.isEmpty(mongoSearchCollectionName)) {
			return mongoSearchCollectionName;
		}
		return collectionName.get();
	}

	public String getPatientsCollectionName(long trailID) {
		if (!StringUtils.isEmpty(mongoSearchCollectionName)) {
			return mongoSearchCollectionName;
		}
		return "T_" + trailID;
	}

	@Override
	public CriteriaCounts getCriteriaCountMapAndPatientsGeoData(SearchModel searchModel, String fields) {
		logger.info(">>>> Criteria count");
		MongoPageRequest pageRequest = searchModel.getMongoPageRequest();
		Pageable page = null;
		if (pageRequest != null) {
			page = new PageRequest(pageRequest.getPageNumber(), pageRequest.getPageSize());
		}
		logger.info(">>>> Criteria Count Pagination Values");
		logger.info(">>>> Page Number:" + pageRequest.getPageNumber());
		logger.info(">>>> Page Size:" + pageRequest.getPageSize());
		return getCriteriaCountsAndPatients(searchModel.getTrialId(), searchModel.getTrailJSON(), page,
				searchModel.getHasAggregation(), fields, Boolean.valueOf(searchModel.getDifference()),searchModel.isHasExport());
	}

	@Override
	public CriteriaCounts getCriteriaCountMapAndPatients(SearchModel searchModel) {
		logger.info(">>>> Criteria count");
		MongoPageRequest pageRequest = searchModel.getMongoPageRequest();
		Pageable page = null;
		if (pageRequest != null) {
			page = new PageRequest(pageRequest.getPageNumber(), pageRequest.getPageSize());
		}
		logger.info(">>>> Criteria Count Pagination Values");
		logger.info(">>>> Page Number:" + pageRequest.getPageNumber());
		logger.info(">>>> Page Size:" + pageRequest.getPageSize());
		return updateId(
				getCriteriaCountsAndPatients(searchModel.getTrialId(), searchModel.getTrailJSON(), page,
						searchModel.getHasAggregation(), "", Boolean.valueOf(searchModel.getDifference()),searchModel.isHasExport()),
				searchModel);
	}

	private CriteriaCounts updateId(CriteriaCounts cc, SearchModel searchModel) {
		logger.info("*************Started updating TempId for each patients***********");
		int pageNumber = searchModel.getMongoPageRequest().getPageNumber();
		int pageSize = searchModel.getMongoPageRequest().getPageSize();
		int count = (pageNumber * pageSize) + 1;

		if (null != cc && null != cc.getGeoPatient() && null != cc.getGeoPatient().getFeatures()
				&& cc.getGeoPatient().getFeatures().size() > 0) {
			for (Patient p : cc.getGeoPatient().getFeatures()) {
				p.withTempId(count++);
			}
			;
		}

		return cc;

	}

	@Override
	public CriteriaCounts getCriteriaCountsAndPatients(Long trialId, String trialJson, Pageable page,
			boolean hasAggregation, String fields, boolean isDifferent,boolean hasExport) {
		// String trialJson = TrialJsonHelper.getMongoJSON2();
		logger.info("<<<< GetCriteria Count" + new Date());
		logger.debug("\n******* INPUT JSON: " + trialJson + "\n\n");
		Map<String, String> mapCriteriaStrToJson = getCriterias(trialJson);
		Optional<Pageable> optPage = Optional.ofNullable(page);
		CriteriaCounts cc = populateCountsAndPatients(mapCriteriaStrToJson, optPage, getPatientsCollectionName(),
				hasAggregation, fields, isDifferent,hasExport);
		if (cc != null)
			printResults(cc);
		/*
		 * else { cc=new CriteriaCounts(); }
		 */
		logger.info(">>>> GetCriteria Count" + new Date());

		return cc;
	}

	@Override
	public Map<String, Integer> getCriteriaCountMap(Long trialId, String trialJson) {

		logger.info("<<<< GetCriteria Count" + new Date());
		logger.info("\n******* INPUT JSON: " + trialJson + "\n\n");
		Map<String, String> mapCriteriaStrToJson = getCriterias(trialJson);
		Map<String, Integer> cc = populateCounts(mapCriteriaStrToJson, getPatientsCollectionName());
		if (cc != null)
			printResults(cc);
		logger.info(">>>> GetCriteria Count" + new Date());

		return cc;
	}

	@Override
	public Map<String, Integer> getCriteriaCountMap(Long trialId, String trialJson, Integer totalCandidates) {

		logger.info("<<<< GetCriteria Count" + new Date());
		logger.info("\n******* INPUT JSON: " + trialJson + "\n\n");
		Map<String, String> mapCriteriaStrToJson = getCriterias(trialJson);
		Map<String, Integer> cc = populateCounts(mapCriteriaStrToJson, getPatientsCollectionName(), totalCandidates);
		if (cc != null)
			printResults(cc);
		logger.info(">>>> GetCriteria Count" + new Date());

		return cc;
	}

	@Override
	public Map<String, String> getCriterias(String trialJson) {
		@SuppressWarnings("unchecked")
		List<String> tempStrList = JsonPath.using(Configuration.defaultConfiguration()).parse(trialJson)
				.read("$.criterias", List.class);

		String tTagForCompleteJson = JsonPath.using(Configuration.defaultConfiguration()).parse(trialJson)
				.read(COMPLETE_TAG);
		strTagForCompleteJson.set(tTagForCompleteJson);
		// Initialize Patient's collection name;
		initPatientsCollectionName(tTagForCompleteJson);
		Map<String, String> mapCriteriaStrToJson = new HashMap<>();
		tempStrList.stream()
				// .map(cr -> "criteria_" + cr)
				.forEach(cr -> getCriteriaJson(cr, trialJson, mapCriteriaStrToJson));
		return mapCriteriaStrToJson;
	}

	@Override
	public String getCompleteJSON(String trialJson) {
		String tTagForCompleteJson = JsonPath.using(Configuration.defaultConfiguration()).parse(trialJson)
				.read(COMPLETE_TAG);
		return tTagForCompleteJson;
	}

	private void getCriteriaJson(String criteria, String trialJson, Map<String, String> mapCriteriaStrToJson) {
		DocumentContext jsonContext = JsonPath.parse(trialJson);
		logger.info("===getCriteriaJson: $." + criteria + " complete: " + strTagForCompleteJson.get() + "\ntrialJson: "
				+ trialJson);
		BasicDBObject bdo;
		try {
			// https://stackoverflow.com/questions/22870584/convert-from-linkedhashmap-to-json-string
			bdo = new BasicDBObject(jsonContext.read("$." + criteria));
		} catch (PathNotFoundException pnfe) {
			logger.error("!!!!! PathNotFoundException: for criteria: " + criteria + " complete: "
					+ strTagForCompleteJson.get() + "\ntrialJson: " + trialJson);
			return;
		}
		mapCriteriaStrToJson.put(criteria, bdo.toJson());

	}

	private CriteriaCounts populateCountsAndPatients(Map<String, String> mapCriteriaStrToJsonStr,
			Optional<Pageable> pageable, String collectionName, boolean hasAggregation, String fields,
			boolean isDifferent,boolean hasExport ) {
		logger.info("Pouplate Count and Patients >>>" + new Date());
		try {
			GeoPatient geoPatient = new GeoPatient();
			CriteriaCounts cc = new CriteriaCounts();
			Map<String, Integer> criteriaNameToCountMap = new HashMap<>();
			cc.withGeoPatient(geoPatient);
			cc.withCriteriaNameToCountMap(criteriaNameToCountMap);
			ObjectMapper mapper = new ObjectMapper();
			logger.info(">>>> Before Query Pagination Values");
			logger.info(">>> Page Number: {}", pageable.get().getPageNumber());
			logger.info(">>> Page Size: {}", pageable.get().getPageSize());

			mapCriteriaStrToJsonStr.forEach((criteriaNm, jsonStr) -> {
				if (criteriaNm.equals(strTagForCompleteJson.get())) {
					try {
						List<Patient> inclusionPatients = null;
						List<Patient> exclusionPatients = null;
						List<Patient> inclusionPatientsNonEid = null;
						List<Patient> exclusionPatientsNonEid = null;
						int count = 0;
						// Inclusion Criteria, Exclusion Criteria - if difference is true

						if (isDifferent) {
							SearchCriteriaGroupContainerIE inclusionCriteria = null;
							SearchCriteriaGroupContainerIE exclusionCriteria = null;
							SearchCriteriaGroupContainerIE inclusionCriteriaNonEid = null;
							SearchCriteriaGroupContainerIE exclusionCriteriaNonEid = null;
							inclusionCriteria = jsonContractParser.parseJSONInput(mapper.readTree(jsonStr).get("IC"),
									ContainerType.INCLUSION_CRITERIA,false);
							exclusionCriteria = jsonContractParser.parseJSONInput(mapper.readTree(jsonStr).get("EC"),
									ContainerType.EXCLUSION_CRITERIA,false);
							inclusionCriteriaNonEid = jsonContractParser.parseJSONInput(mapper.readTree(jsonStr).get("IC"),
									ContainerType.INCLUSION_CRITERIA,true);
							exclusionCriteriaNonEid = jsonContractParser.parseJSONInput(mapper.readTree(jsonStr).get("EC"),
									ContainerType.EXCLUSION_CRITERIA,true);

							inclusionPatients = (inclusionCriteria == null || inclusionCriteria.isEmpty()) ? null
									: new ArrayList<>(queryBuilder.build(inclusionCriteria, null, collectionName));
							inclusionPatientsNonEid = (inclusionCriteriaNonEid == null || inclusionCriteriaNonEid.isEmpty()) ? null
									: new ArrayList<>(queryBuilder.build(inclusionCriteriaNonEid, null, collectionName));
							if (!CollectionUtils.isEmpty(inclusionPatients)) {
								exclusionPatients = (exclusionCriteria == null || exclusionCriteria.isEmpty()) ? null
										: queryBuilder.build(exclusionCriteria, null, collectionName);
								if (!CollectionUtils.isEmpty(exclusionPatients)) {
									inclusionPatients.removeAll(exclusionPatients);
								}
							}
							if (!CollectionUtils.isEmpty(inclusionPatientsNonEid)) {
								exclusionPatientsNonEid = (exclusionCriteriaNonEid == null || exclusionCriteriaNonEid.isEmpty()) ? null
										: queryBuilder.build(exclusionCriteriaNonEid, null, collectionName);
								if (!CollectionUtils.isEmpty(exclusionPatientsNonEid)) {
									inclusionPatientsNonEid.removeAll(exclusionPatientsNonEid);
								}
								inclusionPatients.addAll(inclusionPatientsNonEid);
							}
							if (!CollectionUtils.isEmpty(inclusionPatients)) {
								count = inclusionPatients.size();
								if (!hasExport)
									inclusionPatients = getPaginatedList(inclusionPatients, pageable.get());
							}
						} else { // no changes, get results without any filters
							count = (int) mongoTemplate.getDb().getCollectionFromString(collectionName).getCount();
							logger.info("\nCriteria : {}, count: {}, mongoSearchCollectionName: {}", criteriaNm, count,
									collectionName);
							if (!hasExport) {
								Query patientsQuery = new Query().with(pageable.get());
								inclusionPatients = mongoTemplate.find(patientsQuery, Patient.class, collectionName);
							} else {
								inclusionPatients = mongoTemplate.findAll(Patient.class, collectionName);
							}
						}

						setPatientsCoordinates(inclusionPatients);
						logger.info(">>> Patients Count: {}", count);
						cc.withTotalCount(count);
						geoPatient.withFeatures(inclusionPatients);
						logger.info(">>>> criteria Name and count: " + criteriaNm + " count: " + count
								+ " criteriaNameToCountMap size: " + criteriaNameToCountMap.size());

					} catch (InputValidationException | IOException e) {
						logger.error("Caught exception populateCountsAndPatients: {}", e.getMessage());
					}
				}
				/*
				 * BasicQuery basicQuery = new BasicQuery(jsonStr);
				 * 
				 * 
				 * if (criteriaNm.equals(strTagForCompleteJson.get())) { if (hasAggregation) {
				 * count = (int) mongoOperations.count(basicQuery, collectionName); // If
				 * criteria not changed then get all else go to QB for getting count //count =
				 * queryBuilder.count(searchCriteriaGroupContainer, collectionName)
				 * logger.info("\nCriteria : " + criteriaNm + " count: " + count +
				 * " mongoSearchCollectionName: " + collectionName + " and its Json : " +
				 * jsonStr); criteriaNameToCountMap.put(criteriaNm, count); } if
				 * (pageable.isPresent()) { basicQuery.with(pageable.get()); } if
				 * (!fields.isEmpty()) { for (String key : fields.split(","))
				 * basicQuery.fields().include(key); } List<Patient> patients =
				 * mongoOperations.find(basicQuery, Patient.class, collectionName); if (patients
				 * != null) {
				 * 
				 * setPatientsCoordinates(patients); logger.info(">>> Patients Count" +
				 * patients.size()); } geoPatient.withFeatures(patients);
				 * cc.withTotalCount(count); logger.info(">>>> criteria Name and count: " +
				 * criteriaNm + " count: " + patients.size() + " criteriaNameToCountMap size: "
				 * + criteriaNameToCountMap.size() + " query: " + basicQuery.toString()); }
				 */
			});

			logger.info("Pouplate Count and Patients <<<" + new Date());
			return cc;
		} catch (Exception ex) {
			logger.error("Caught exception: {}", ex);
		} finally {
			logger.info(">>>> Pouplate Count and Patients" + new Date());
		}
		return null;
	}

	private List<Patient> getPaginatedList(List<Patient> list, Pageable pagination) {
		int pageNum = pagination.getPageNumber();
		int pageSize = pagination.getPageSize();
		int from = pageNum * pageSize;
		int to = from + pageSize;
		return getSlice(list.stream(), from, to).collect(Collectors.toList());
	}

	// Generic function to get Slice of a Stream from fromIndex to toIndex
	private Stream<Patient> getSlice(Stream<Patient> stream, int fromIndex, int toIndex) {
		return stream
				// specify the number of elements to skip
				.skip(fromIndex)
				// specify the no. of elements the stream should be limited
				.limit(toIndex - fromIndex);
	}

	@Override
	public void setPatientsCoordinates(List<Patient> patients) {
		// Populate lat lng if it is not updated from mongo
		patients.forEach(f -> {
			f.withScoreJSONMap(f.getCriteria());
			if (f.getLat() <= 0 || f.getLng() <= 0) {
				String zip = f.getZip();
				if (zip != null) {
					List<Place> listPlace = PostalDbFactory.getPostalDb().byPostalCode(zip);
					Coordinates coordinates = new Coordinates()
							.withLatitude(
									listPlace != null && listPlace.size() > 0 ? listPlace.get(0).getLatitude() : 0.0)
							.withLongitude(
									listPlace != null && listPlace.size() > 0 ? listPlace.get(0).getLongitude() : 0.0);

					f.withGeometry(new Geometry().withType("Point").withCoordinates(coordinates));
				}
			}
		});
	}

	private Map<String, Integer> populateCounts(Map<String, String> mapCriteriaStrToJsonStr, String collectionName) {
		logger.info("<<< Pouplate Count " + new Date());
		try {
			GeoPatient geoPatient = new GeoPatient();
			CriteriaCounts cc = new CriteriaCounts();
			Map<String, Integer> criteriaNameToCountMap = new HashMap<>();
			cc.withGeoPatient(geoPatient);
			cc.withCriteriaNameToCountMap(criteriaNameToCountMap);

			logger.info(">>>> Before Query");

			mapCriteriaStrToJsonStr.forEach((criteriaNm, jsonStr) -> {
				BasicQuery basicQuery = new BasicQuery(jsonStr);
				int count = 0;

				count = (int) mongoOperations.count(basicQuery, collectionName);
				logger.info("\nCriteria : " + criteriaNm + "| JSON: " + jsonStr + " |  count: " + count
						+ " mongoSearchCollectionName: " + collectionName + " and its Json : " + jsonStr);
				criteriaNameToCountMap.put(criteriaNm, count);

			});

			logger.info(">>> Pouplate Count" + new Date());
			return criteriaNameToCountMap;
		} catch (Exception ex) {
			logger.debug(ex.getMessage());

		} finally {
			logger.info(">>> Pouplate Count" + new Date());
		}
		return null;
	}

	private Map<String, Integer> populateCounts(Map<String, String> mapCriteriaStrToJsonStr, String collectionName, Integer totalCandidates) {
		logger.info("<<< Pouplate Count " + new Date());
		try {
			GeoPatient geoPatient = new GeoPatient();
			CriteriaCounts cc = new CriteriaCounts();
			Map<String, Integer> criteriaNameToCountMap = new HashMap<>();
			cc.withGeoPatient(geoPatient);
			cc.withCriteriaNameToCountMap(criteriaNameToCountMap);

			logger.info(">>>> Before Query");

			mapCriteriaStrToJsonStr.forEach((criteriaNm, jsonStr) -> {
				logger.info("\nCriteria : " + criteriaNm + "| JSON: " + jsonStr + " |  count: " + totalCandidates
						+ " mongoSearchCollectionName: " + collectionName + " and its Json : " + jsonStr);
				criteriaNameToCountMap.put(criteriaNm, totalCandidates);

			});

			logger.info(">>> Pouplate Count" + new Date());
			return criteriaNameToCountMap;
		} catch (Exception ex) {
			logger.debug(ex.getMessage());

		} finally {
			logger.info(">>> Pouplate Count" + new Date());
		}
		return null;
	}
	
	private CriteriaCounts populateCountAndPatientsByCriteria(Map<String, String> mapCriteriaStrToJsonStr,
			Optional<Pageable> pageable, String collectionName) {
		// logger.info("Pouplate Count and Patients >>>" + new Date());
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd");
		String dtString = dateFormat.format(new Date());
		try {
			GeoPatient geoPatient = new GeoPatient();
			CriteriaCounts cc = new CriteriaCounts();
			Map<String, Integer> criteriaNameToCountMap = new HashMap<>();
			cc.withGeoPatient(geoPatient);
			cc.withCriteriaNameToCountMap(criteriaNameToCountMap);
			StringBuilder logString = new StringBuilder();
			mapCriteriaStrToJsonStr.forEach((criteriaNm, jsonStr) -> {
				Date countStart = new Date();
				BasicQuery basicQuery = new BasicQuery(jsonStr);

				logString.append("Count Query >>>" + new Date());
				logString.append("\nName:\t" + criteriaNm);
				logString.append("\tJson:\t" + jsonStr);
				int count = (int) mongoOperations.count(basicQuery, collectionName);
				long timeDiff = Math.abs(countStart.getTime() - new Date().getTime());
				logString.append("\tDuration:\t" + timeDiff);
				logString.append("\tCount:\t" + count);

				criteriaNameToCountMap.put(criteriaNm, count);

				if (criteriaNm.equals(strTagForCompleteJson.get())) {
					if (pageable.isPresent()) {
						basicQuery.with(pageable.get());
					}

					// logger.info("Get patients data >>>" + new Date());
					List<Patient> patients = mongoOperations.find(basicQuery, Patient.class, collectionName);
					// logger.info("Get patients data <<<" + new Date());

					if (patients != null) {
						patients.forEach(p -> {
							p.withScoreJSONMap(p.getCriteria());
						});
					}

					geoPatient.withFeatures(patients);
					cc.withTotalCount(count);
				}
			});
			// Performance test
			CommonUtil.saveLogFile(logString.toString(), collectionName + "_Count" + dtString);
			return cc;
		} catch (Exception ex) {
			logger.debug(ex.getMessage());

		} finally {
			// logger.info(">>>> Pouplate Count Only" + new Date());
		}
		return null;
	}

	private List<Patient> populatePatientsByCriteria(String strTagForCompleteJson, Optional<Pageable> pageable,
			String collectionName) {
		// logger.info("Pouplate Patients Only >>>" + new Date());
		try {

			BasicQuery basicQuery = new BasicQuery(strTagForCompleteJson);
			if (pageable.isPresent()) {
				basicQuery.with(pageable.get());
			}

			// logger.info("Get patients data >>>" + new Date());
			List<Patient> patients = mongoOperations.find(basicQuery, Patient.class, collectionName);
			// logger.info("Get patients data <<<" + new Date());

			if (patients != null) {
				patients.forEach(p -> {
					p.withScoreJSONMap(p.getCriteria());
				});
			}
			// logger.info("Pouplate Patients Only <<<" + new Date());
			return patients;
		} catch (Exception ex) {
			// logger.debug(ex.getMessage());

		} finally {
			// logger.info(">>>> Pouplate Count and Patients" + new Date());
		}
		return null;
	}

	private void printResults(CriteriaCounts cc) {
		/*
		 * logger.info("^^^^^Number of patients returned: " +
		 * cc.getGeoPatient().getFeatures().size() + " count: " +
		 * cc.getCriteriaNameToCountMap().size());
		 */
		Map<String, Integer> criteriaNameToCountMap = cc.getCriteriaNameToCountMap();
		criteriaNameToCountMap
				.forEach((criteriaNm, count) -> logger.info("criteria name: " + criteriaNm + " count: " + count));

	}

	private void printResults(Map<String, Integer> criteriaCountMap) {
		criteriaCountMap
				.forEach((criteriaNm, count) -> logger.info("criteria name: " + criteriaNm + " count: " + count));

	}

	@Override
	public PatientDetails findByPatientId(String patientId, long trialId) {
		initPatientsCollectionName("T_" + trialId);
		BasicQuery bq = new BasicQuery("{'patient_id': '" + patientId + "'}");
		Patient p = mongoOperations.findOne(bq, Patient.class, getPatientsCollectionName(trialId));
		PatientDetails pd = new PatientDetails().withPatient(p);
		return pd;
	}

	@Override
	public List<LabRecords> findLabReportByPatientIdAndTrialId(String patientId, long trialId) {

		List<LabRecords> labRecords = null;
		initPatientsCollectionName("T_" + trialId);
		BasicQuery bq = new BasicQuery("{'patient_id': '" + patientId + "'}");
		Patient p = mongoOperations.findOne(bq, Patient.class, getPatientsCollectionName(trialId));
		PatientDetails pd = new PatientDetails().withPatient(p);
		if (null != pd)
			labRecords = pd.getLabRecords();

		return labRecords;
	}

	@Override
	public String testServiceMethodCallPerformance(String collectionName) {
		StringBuilder logString = new StringBuilder();
		// String criteria = "{\"age\":{\"$gt\":18}}";
		String trialJson = "{\"349\":{\"$and\":[{\"$or\":[{\"gender\":\"M\"},{\"gender\":\"F\"}]},{\"age\":{\"$gte\":18}}]},\"350\":{\"diagnosisRecords\":{\"$not\":{\"$elemMatch\":{\"$or\":[{\"icdCode\":{\"$regex\":\"^Z22.\"},\"icdCodeSet\":10}]}}}},\"complete\":\"T_11\",\"T_11\":{\"$and\":[{\"$and\":[{\"$or\":[{\"gender\":\"M\"},{\"gender\":\"F\"}]},{\"age\":{\"$gte\":18}}]},{\"diagnosisRecords\":{\"$not\":{\"$elemMatch\":{\"$or\":[{\"icdCode\":{\"$regex\":\"^Z22.\"},\"icdCodeSet\":10}]}}}}]},\"criterias\":[\"349\",\"350\",\"T_11\"]}";
		// String trialJson =
		// "{\"366\":{\"age\":{\"$gte\":100}},\"404\":{\"gender\":{\"$ne\":\"F\"}},\"complete\":\"T_11\",\"T_11\":{\"$and\":[{\"age\":{\"$gte\":100}},{\"gender\":{\"$ne\":\"F\"}}]},\"criterias\":[\"366\",\"404\",\"T_11\"]}";
		// String
		// trialJson="{\"510\":{\"$or\":[{\"gender\":\"M\"},{\"gender\":\"F\"}]},\"complete\":\"T_16\",\"T_16\":{\"$and\":[{\"$or\":[{\"gender\":\"M\"},{\"gender\":\"F\"}]}]},\"criterias\":[\"510\",\"T_16\"]}";
		Pageable page = null;
		int pageIndex = 0;
		int pageSize = 10;
		int iterationIndex = 0;
		// logger.debug("Program Started with " + pageSize + "\n");
		DateFormat dateFormat = new SimpleDateFormat("yyyy_mm_dd_hh_mm");
		String dtString = dateFormat.format(new Date());
		Map<String, String> mapCriteriaStrToJson = getCriterias(trialJson);
		while (iterationIndex < 1) {
			// logger.info("\nIteration:" + iterationIndex);
			pageIndex = 0;
			logString = new StringBuilder();
			while (pageIndex < 50) {

				// logger.info("\nPage:" + pageIndex);
				logString.append("\nIteration:" + iterationIndex);
				logString.append("\tPage:" + pageIndex);
				logString.append("\tStartedAt :" + new Date());
				Date startDate = new Date();
				page = new PageRequest(pageIndex, pageSize);
				Optional<Pageable> optPage = Optional.ofNullable(page);
				// If pageIndex=0
				// calling count + patients data
				if (pageIndex == 0) {
					populateCountAndPatientsByCriteria(mapCriteriaStrToJson, optPage, getPatientsCollectionName());
				} else {
					List<Patient> cc = populatePatientsByCriteria(mapCriteriaStrToJson.get(strTagForCompleteJson.get()),
							optPage, getPatientsCollectionName());
					if (cc != null)
						logString.append("\tPatient Count: " + cc.size());
				}
				pageIndex += 10 / 3;
				// if (pageIndex > 30)
				// pageIndex = 0;

				long timeDiff = Math.abs(startDate.getTime() - new Date().getTime());
				logString.append("\tDuration:\t" + timeDiff);
			}
			iterationIndex += 1;
			CommonUtil.saveLogFile(logString.toString(), collectionName + "_Service_Test" + dtString);
		}
		// logger.debug("Program Ended\n");
		// logger.info(logString.toString());
		CommonUtil.saveLogFile(logString.toString(), "Service_Test" + dateFormat.format(new Date()));
		return logString.toString();
	}

	@Override
	public String testRestAPIPerformace(String collectionName) {
		HttpEntity<Object> entity = null;
		SearchModel searchModel = new SearchModel();
		searchModel.withTrailJSON(
				"{\"349\":{\"$and\":[{\"$or\":[{\"gender\":\"M\"},{\"gender\":\"F\"}]},{\"age\":{\"$gte\":18}}]},\"350\":{\"diagnosisRecords\":{\"$not\":{\"$elemMatch\":{\"$or\":[{\"icdCode\":{\"$regex\":\"^Z22.\"},\"icdCodeSet\":10}]}}}},\"complete\":\"T_11\",\"T_11\":{\"$and\":[{\"$and\":[{\"$or\":[{\"gender\":\"M\"},{\"gender\":\"F\"}]},{\"age\":{\"$gte\":18}}]},{\"diagnosisRecords\":{\"$not\":{\"$elemMatch\":{\"$or\":[{\"icdCode\":{\"$regex\":\"^Z22.\"},\"icdCodeSet\":10}]}}}}]},\"criterias\":[\"349\",\"350\",\"T_11\"]}");

		searchModel.withTrialId(11L);
		int pageIndex = 0;
		MongoPageRequest pageRequest = new MongoPageRequest();
		StringBuilder logString = new StringBuilder();
		URI uri = UriComponentsBuilder.fromUriString("http://localhost:8002/api/v1/search/11").build().toUri();
		DateFormat dateFormat = new SimpleDateFormat("yyyy_mm_dd_hh_mm");
		String dtString = dateFormat.format(new Date());
		int iterationIndex = 0;
		while (iterationIndex < 100) {
			pageIndex = 0;
			logString = new StringBuilder();
			while (pageIndex < 100) {
				logger.info("\nIteration:" + pageIndex);
				pageRequest.withPageNumber(pageIndex).withPageSize(10);
				searchModel.withMongoPageRequest(pageRequest);

				entity = new HttpEntity<Object>(searchModel, CommonUtil.getHttpHeaders());
				logString.append("\nIteration:" + pageIndex);
				logString.append("\tPage:" + pageIndex);
				logString.append("\tStartedAt :" + new Date());
				Date startDate = new Date();
				ResponseEntity<CriteriaCounts> response = restTemplate.exchange(uri, HttpMethod.POST, entity,
						CriteriaCounts.class);
				// Log.info(String.valueOf(response));
				if (response.getBody() != null)
					logString.append("\tPatient Count: " + response.getBody().getGeoPatient().getFeatures().size());
				else {
					logString.append("\tPatient Count: 0");
				}
				long timeDiff = Math.abs(startDate.getTime() - new Date().getTime());
				logString.append("\tDuration:\t" + timeDiff);
				pageIndex++;
			}
			CommonUtil.saveLogFile(logString.toString(), collectionName + "_Service_API_Test" + dtString);
			// break;
		}
		return "completed";

	}

}
