package com.avigosolutions.candidateservice.service;

import java.util.Date;
import java.util.List;

import com.avigosolutions.candidateservice.async.model.SavedSearchJobResponseModel;
import com.avigosolutions.candidateservice.model.SavedSearch;
import com.avigosolutions.candidateservice.response.model.SavedSearchResponse;

public interface SavedSearchService {

	public SavedSearch findOne(String id);

	public SavedSearch findBySearchName(String searchName);

	public List<SavedSearch> findAll();

	// public SavedSearch save(SavedSearch searchToBeSaved);
	public boolean save(SavedSearch searchToBeSaved, String userId);

	public List<SavedSearch> getSavedSearchByTrialId(long trialId, Date updatedDate);

	public SavedSearch updateId(SavedSearch savedSearch);

	public List<SavedSearchJobResponseModel> getJobStatusByTrialId(Long trialId);

	public SavedSearchJobResponseModel getJobStatusBySearchNameAndTrialId(String searchName, Long trialId);

	SavedSearch findBySearchNameAndTrialId(SavedSearch savedSearch, String fields);
	
	public SavedSearchResponse getSeavedSearchByTrialIdByPage(long trialId,int start,int pageSize);

}
