package com.avigosolutions.candidateservice.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.candidateservice.async.constants.SavedSearchConstants;
import com.avigosolutions.candidateservice.async.model.SavedSearchJobResponseModel;
import com.avigosolutions.candidateservice.async.service.SavedSearchAsyncService;
import com.avigosolutions.candidateservice.async.service.SavedSearchJobLog;
import com.avigosolutions.candidateservice.model.CRMCategory;
import com.avigosolutions.candidateservice.model.GeoPatient;
import com.avigosolutions.candidateservice.model.MongoPageRequest;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.model.SavedSearch;
import com.avigosolutions.candidateservice.repository.SavedSearchRepository;
import com.avigosolutions.candidateservice.response.model.SavedSearchResponse;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class SavedSearchServiceImpl implements SavedSearchService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.participant.service.url}")
	String participantServiceURL;

	@Value("${sprintt.participant.service.categoryurl}")
	String participantServiceCatURL;

	@Value("${sprintt.uuid}")
	String springUuid;

	@Autowired
	PatientService patientService;
	

	@Autowired
	private SavedSearchRepository savedSearchRepository;

	@Autowired
	SavedSearchAsyncService savedSearchAsyncService;

	@Autowired
	SavedSearchJobLog savedSearchJobLog;

	private MongoOperations mongoOperations;

	@Value("${mongoSavedSearchCollectionName}")
	private String mongoSavedSearchCollectionName;

	@Autowired
	public void setMongoOperations(MongoOperations mongoOperations) {
		this.mongoOperations = mongoOperations;
	}

	@Override
	public SavedSearch findOne(String id) {
		return savedSearchRepository.findOne(id);
	}

	@Override
	public SavedSearch findBySearchName(String searchName) {
		return savedSearchRepository.findBySearchName(searchName);
	}

	@Override
	public List<SavedSearch> findAll() {
		return savedSearchRepository.findAll();
	}

	@Override
	public boolean save(SavedSearch searchToBeSaved, String userId) {
		if (searchToBeSaved == null || StringUtils.isEmpty(searchToBeSaved.getSearchName())
				|| searchToBeSaved.getTrialId() <= 0 || searchToBeSaved.getTrialId() == Long.MAX_VALUE) {
			logger.error("SavedSearch **save** returning null, invalid input parameters");
			return false;
		}
		// If already exist return then don't allow.
		SavedSearch searchExisting = savedSearchRepository.findBySearchNameAndTrialId(searchToBeSaved.getSearchName(),
				searchToBeSaved.getTrialId());
		//Commenting code to check for Savedsearch with name and trial id exists as we are saving everytime.
		/*if (searchExisting != null) {
			logger.error("SavedSearch with Name:" + searchToBeSaved.getSearchName()
					+ " is already existing for TrialId:" + searchToBeSaved.getTrialId());
			return false;
		}*/

		try {
			savedSearchAsyncService.saveSearch(searchToBeSaved, userId);
		} catch (Exception e) {
			logger.error("Error occurred:", e);
			logger.info("Error ocurred while invoking async savesearch:" + e.getMessage());
			return false;
		}

		logger.info("Saved search accepted..........");
		return true;
	}

	/*
	 * As saved search holds only patient Ids, we need to do customized pagination
	 */
	private void populatePatients(SavedSearch ss, String fields) {
		Pageable pageable = null;
		MongoPageRequest pageRequest = ss.getMongoPageRequest();
		if (null != ss.getGeoPatientId() && null != ss.getGeoPatientId().getPatientIds()) {
			List<String> patientIdList = ss.getGeoPatientId().getPatientIds();
			if (pageRequest != null) {
				ss.getMongoPageRequest().withTotalRows(patientIdList.size());
				pageable = new PageRequest(pageRequest.getPageNumber(), pageRequest.getPageSize());
				int start = pageable.getOffset();
				int end = start + pageable.getPageSize();
				if (end < patientIdList.size())
					patientIdList = patientIdList.subList(start, end);
				else
					patientIdList = patientIdList.subList(start, patientIdList.size());
			}
			logger.info("Patient Id List Size:" + patientIdList.size());
			// Collections.sort(patientIdList);
			Query query = new Query();
			query.addCriteria(Criteria.where("patient_id").in(patientIdList));
			if (!fields.isEmpty()) {
				for (String key : fields.split(","))
					query.fields().include(key);
			}
			List<Patient> patientList = mongoOperations.find(query, Patient.class,
					patientService.getPatientsCollectionName(ss.getTrialId()));
			if (null != patientList && patientList.size() > 0) {
				patientService.setPatientsCoordinates(patientList);
			}
			GeoPatient geoPatient = new GeoPatient();
			geoPatient.withFeatures(patientList);
			ss.withGeoPatient(geoPatient);

			logger.info("patientList List Size:" + patientList.size());
			//logger.info("patient info size and info" + ss.getGeoPatient().getFeatures().get(5) + "   "+ss.getGeoPatient().getFeatures());
			// Pre-load scores JSON
			if (patientList != null) {
				patientList.forEach(p -> {
					p.withScoreJSONMap(p.getCriteria());
				});
			}
			logger.info("patientList List Size:" + patientList.size());
		}
	}

	private HttpHeaders getHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("UUID", springUuid);
		headers.set("X-Requested-With", "XMLHttpRequest");
		return headers;
	}

	@Override
	public SavedSearch findBySearchNameAndTrialId(SavedSearch savedSearch, String fields) {
		SavedSearch search = new SavedSearch();
		
		ObjectId id= new ObjectId(savedSearch.getId());   
		search = mongoOperations.findById(id, SavedSearch.class,mongoSavedSearchCollectionName);
		logger.info("**************SavedSearch name : ****" + search.getSearchName() +" trialId : ----- " + 	search.getTrialId());
		
		if (search == null) {
			return null;
		}
		search.withMongoPageRequest(savedSearch.getMongoPageRequest());
		populatePatients(search, fields);

		logger.info("**************getSavedSearch****" + search);
		logger.info("**************getSavedSearch****" + search.getGeoPatient().getFeatures().size() + "to string >>>>>>"+ search.getGeoPatient().getFeatures().toString());
		if (search.getGeoPatient() == null)
			search.withGeoPatient(new GeoPatient().withFeatures(new ArrayList<Patient>()));

		search.withJobStatus("");
		return search;
	}

	/*
	 * We will not be sending patients list. (non-Javadoc)
	 * 
	 * @see
	 * com.avigosolutions.candidateservice.service.SavedSearchService#findByTrialId(
	 * long)
	 */
	@Override
	public List<SavedSearch> getSavedSearchByTrialId(long trialId, Date updatedDate) {
		BasicQuery basicQuery = new BasicQuery("{\"trialId\":" + trialId + "}");
		basicQuery.fields().include("searchName");
		basicQuery.fields().include("createDate");
		basicQuery.fields().include("trialId");
		List<SavedSearch> searchResults = mongoOperations.find(basicQuery, SavedSearch.class,
				mongoSavedSearchCollectionName);
		
		List<SavedSearch> savedSearchList = searchResults.stream().filter(f -> (updatedDate.compareTo(f.getCreateDate()) <= 0)).collect(Collectors.toList());
		List<SavedSearchJobResponseModel> savedSearchStatusList = getJobStatusByTrialId(trialId);
		savedSearchList.forEach(x -> {
			if (null != savedSearchStatusList && savedSearchStatusList.size() > 0) {
				updateJobStatus(x, savedSearchStatusList);
			} else {
				x.setJobStatus("");
			}

		});
		return savedSearchList;
	}

	@Override
	public SavedSearchResponse getSeavedSearchByTrialIdByPage(long trialId, int start, int pageSize) {
		SavedSearchResponse savedSearchResponse = new SavedSearchResponse();
		Page<SavedSearch> searchResults = savedSearchRepository.findByTrialId(trialId,
				new PageRequest(start, pageSize));
		List<SavedSearch> lstSavedSearch = searchResults.getContent();
		List<SavedSearchJobResponseModel> savedSearchStatusList = getJobStatusByTrialId(trialId);
		lstSavedSearch.forEach(x -> {
			x.withGeoPatient(null);
			// x.withGeoPatientId(null);
			// x.withTrialCriteriaStr(null);
			// x.withCriteriaStr(null);
			// x.withCriteriaNameToCountMap(null);
			if (null != savedSearchStatusList && savedSearchStatusList.size() > 0) {
				updateJobStatus(x, savedSearchStatusList);
			} else {
				x.setJobStatus("");
			}

		});
		savedSearchResponse.withSavedSearchList(lstSavedSearch).withTotal(searchResults.getTotalElements());
		return savedSearchResponse;
	}

	private void updateJobStatus(SavedSearch savedSearch, List<SavedSearchJobResponseModel> savedSearchStatusList) {

		Optional<SavedSearchJobResponseModel> ssModelOptional = savedSearchStatusList.stream()
				.filter(ssl -> ssl.getSearchName().equals(savedSearch.getSearchName())).findFirst();

		if (ssModelOptional.isPresent()) {
			SavedSearchJobResponseModel ssModel = ssModelOptional.get();

			if (SavedSearchConstants.status.INITIATED.name().equals(ssModel.getJobStatus())) {
				savedSearch.setJobStatus(SavedSearchConstants.USER_STATUS.STARTED.name());
			} else if (SavedSearchConstants.status.FAILED.name().equals(ssModel.getJobStatus())
					|| SavedSearchConstants.status.PATIENT_PUSH_FAILED.name().equals(ssModel.getJobStatus())) {
				savedSearch.setJobStatus(SavedSearchConstants.USER_STATUS.FAILED.name());
			} else if (SavedSearchConstants.status.COMPLETED.name().equals(ssModel.getJobStatus())) {
				savedSearch.setJobStatus(SavedSearchConstants.USER_STATUS.SAVED.name());
			} else {
				savedSearch.setJobStatus(SavedSearchConstants.USER_STATUS.INPROGRESS.name());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avigosolutions.candidateservice.service.SavedSearchService#updateId(com.
	 * avigosolutions.candidateservice.model.SavedSearch)
	 */
	public SavedSearch updateId(SavedSearch ss) {
		logger.info("*************Started updating TempId for each patients***********");
		int pageNumber = ss.getMongoPageRequest().getPageNumber();
		int pageSize = ss.getMongoPageRequest().getPageSize();
		int count = (pageNumber * pageSize) + 1;

		if (null != ss && null != ss.getGeoPatient() && null != ss.getGeoPatient().getFeatures()
				&& ss.getGeoPatient().getFeatures().size() > 0) {
			for (Patient p : ss.getGeoPatient().getFeatures()) {
				p.withTempId(count++);
			}
			;
		}

		return ss;

	}

	@Override
	public List<SavedSearchJobResponseModel> getJobStatusByTrialId(Long trialId) {
		return savedSearchJobLog.getJobStatusByTrialId(trialId);
	}

	@Override
	public SavedSearchJobResponseModel getJobStatusBySearchNameAndTrialId(String searchName, Long trialId) {
		return savedSearchJobLog.getJobStatusBySearchNameAndTrialId(searchName, trialId);
	}

}
