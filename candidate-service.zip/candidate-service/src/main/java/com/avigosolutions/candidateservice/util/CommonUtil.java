package com.avigosolutions.candidateservice.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CommonUtil {
	
	static String sprinttUuid;
	
	@Value("${sprintt.uuid}")
	public void setUUID(String uuid) {
		sprinttUuid = uuid;
	}
	
	/** The object mapper. */
	ObjectMapper objectMapper = new ObjectMapper();
	
	public static HttpHeaders getHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("UUID", sprinttUuid);
		headers.set("X-Requested-With", "XMLHttpRequest");
		return headers;
	}

	public static String saveLogFile(String logString, String fileName) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_mm_dd_hh_mm");
		// to convert Date to String, use format method of SimpleDateFormat class.
		String strDate = dateFormat.format(new Date());
		if (fileName!=null && !fileName.isEmpty())
			strDate = fileName;
		File file = new File("logs/Log_" + strDate + ".log");
		try {
			if (file!=null && !file.exists()) {
				file.createNewFile();
			}
			FileWriter writer = new FileWriter(file,true);
			writer.write(logString.toString());
			writer.flush();
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "DONE";
	}
	/**
	 * Convert object to String.
	 * 
	 * @param <T>
	 * @param data
	 * @param classType
	 * @return
	 */
	public String convertObjectToString(Object requestAttribute) {
		try {
			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			return objectMapper.writeValueAsString(requestAttribute);
		} catch (final IOException exception) {
		}
		return null;
	}
}
