/*
 * Sample only, not integrated with flyway
 * Need to run this script on required db.
 */

db.createCollection("savedSearch");

db.savedSearch.createIndex(
   { trialId: 1, searchName: 1 } );

db.system.js.save(
   {
     _id: "populatePatients",
     value : 
       function(sid, pCollection, sCollection, fCriteria) {
    	var searchID = ObjectId(sid);
		db.getCollection(pCollection).find(JSON.parse(fCriteria)).forEach(function (doc2) {
		 		db.getCollection(sCollection).update({_id: searchID },{ $push: {  "geoPatientId.patientIds": doc2.patient_id }});
                });
        }
   }
);