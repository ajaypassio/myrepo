package com.avigosolutions.candidateservice.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.candidateservice.model.Candidate;
import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.GeoCandidate;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
//@Transactional
public class CandidateServiceApplicationTests {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//@Autowired
	private CandidateServiceImpl candidateService;
	//@Before
	public void setup() {
		//candidateService.BLOB_CONTAINER_NAME = "bigdata";
		//candidateService.BLOB_DIRECTORY_PREFIX = "js-output/trial-";
	}

	/*
	@After
	public void tearDown() {
		
	}
	@Test
	public void test_getCandidateListFromMemory() {
		List<Candidate> candidateList = candidateService.getCandidateListFromMemory(1L, null);
		Assert.assertNotNull("test_getCandidateListFromMemory failure, candidate list not expected to be null", candidateList);
		Assert.assertTrue("test_getCandidateListFromMemory candidate list should have a size of 2", candidateList.size() == 2);
	}
	
	@Test
	public void test_getGeoCandidateFromMemory() {
		GeoCandidate geoCandidate = candidateService.getGeoCandidateFromMemory(1L);
		Assert.assertNotNull("test_getGeoCandidateFromMemory failure, candidate list not expected to be null", geoCandidate);
		Assert.assertTrue("test_getGeoCandidateFromMemory Geo candidate list should have a size of 2", geoCandidate.getFeatures().size() == 2);
		Assert.assertTrue("test_getGeoCandidateFromMemory Geo candidate should have correct type", geoCandidate.getType().equals("FeatureCollection"));
	}
	
	@Test
	public void test_getCandidatesByTrial() {
		Optional<List<Candidate>> optCandidateList = candidateService.getCandidatesByTrial(1L);
		Assert.assertTrue("test_getCandidatesByTrial candidate list is present", optCandidateList.isPresent());
		Assert.assertTrue("test_getCandidatesByTrial candidate must have size > 1 ", optCandidateList.get().size() > 1);
	}
	
	@Test
	public void test_getGeoCandidatesByTrial() {
		logger.info("----------test_getGeoCandidatesByTrial-----------------");
		Optional<GeoCandidate> optGeoCandidate = candidateService.getGeoCandidatesByTrial(1L);
		Assert.assertTrue("test_getGeoCandidatesByTrial candidate list is present", optGeoCandidate.isPresent());
		Assert.assertTrue("test_getGeoCandidatesByTrial candidate must have size > 1 got: " + optGeoCandidate.get().getFeatures().size(), 
				optGeoCandidate.get().getFeatures().size() > 1);
		Assert.assertTrue("test_getGeoCandidatesByTrial Geo candidate should have correct type", optGeoCandidate.get().getType().equals("FeatureCollection"));
	}
	
	@Test
	public void test_getCandidatesByTrial_withInvalidTrialId() {
		Optional<List<Candidate>> optCandidateList = candidateService.getCandidatesByTrial(Long.MAX_VALUE);
		List<Candidate> candidateList = null;
		if (optCandidateList.isPresent())
			candidateList = optCandidateList.get();
					
		Assert.assertFalse("test_getCandidatesByTrial_withInvalidTrialId candidate list with invalid trial id should not be present", 
				candidateList != null && candidateList.size() > 0);
		
	}
	
	@Test
	public void test_getGeoCandidatesByTrial_withInvalidTrialId() {
		Optional<GeoCandidate> optGeoCandidate = candidateService.getGeoCandidatesByTrial(Long.MAX_VALUE);
		List<Candidate> candidateList = null;
		if (optGeoCandidate.isPresent())
			candidateList = optGeoCandidate.get().getFeatures();
					
		Assert.assertFalse("test_getGeoCandidatesByTrial_withInvalidTrialId Geo candidate list with invalid trial id should not be present", 
				candidateList != null && candidateList.size() > 0);
		
	}

	@Test
	public void test_getCandidateListFromCSV() {
		Long trialId = 1L;
		// For testing this is ok to use hard coded path for the csv file
		final String csvFilename = "src/main/resources/" + "trial-" + trialId + ".csv"; 
		List<String> csvFilenameList = new ArrayList<>();
		csvFilenameList.add(csvFilename);
		List<Candidate> candidateList = candidateService.getCandidateListFromCSV(trialId, csvFilenameList);
		Assert.assertNotNull("test_getCandidateListFromCSV candidate list must not be null", candidateList);
		Assert.assertTrue("test_getCandidateListFromCSV candidate must have size == 6, Got: " + candidateList.size(), candidateList.size() == 6);
		
	}
	
	@Test
	public void test_getCandidateListFromCSV_withInvalidTrialId() {
		Long trialId = Long.MAX_VALUE;
		final String csvFilename = "src/main/resources/" + "trial-" + trialId + ".csv"; 
		List<String> csvFilenameList = new ArrayList<>();
		csvFilenameList.add(csvFilename);
		
		List<Candidate> candidateList = candidateService.getCandidateListFromCSV(trialId, csvFilenameList);
		Assert.assertTrue("test_getCandidateListFromCSV_withInvalidTrialId candidate must have size == 0, Got: " + candidateList.size(), candidateList.size() == 0);
	}
	
	@Test
	public void test_readFromAzureBlobStorage() {
		Long trialId = 1L;
//		candidateService.BLOB_CONTAINER_NAME = "bigdata";
//		candidateService.BLOB_DIRECTORY_PREFIX = "js-output/trial-";
		List<String> fileNameList = candidateService.readFromAzureBlobStorage(trialId);
		System.out.println("test_readFromAzureBlobStorage, num of files: " + fileNameList.size() + " files: " + fileNameList);
		Assert.assertTrue("test_readFromAzureBlobStorage candidate must have size > 0, Got: " + fileNameList.size(), fileNameList.size() > 0);		
	}
	
	@Test
	public void test_readFromAzureBlobStorageWithInvalidTrialId() {
		Long trialId = Long.MAX_VALUE;
		List<String> fileNameList = candidateService.readFromAzureBlobStorage(trialId);
		
		Assert.assertTrue("test_readFromAzureBlobStorageWithInvalidTrialId candidate must have size == 0, Got: " + fileNameList.size(), fileNameList.size() == 0);		
	}
	
	@Test  //(expected = NoSuchElementException.class) 
	public void test_readFromAzureBlobStorageWithInvalidBlobContainer() {
		Long trialId = 1L;
		candidateService.BLOB_CONTAINER_NAME = "bigdata2";
		List<String> fileNameList = null;
		try {
			 fileNameList = candidateService.readFromAzureBlobStorage(trialId);
		}
		catch (NoSuchElementException ne) {
			
		}
		Assert.assertTrue("test_readFromAzureBlobStorageWithInvalidTrialId fileNameList should be empty: ", fileNameList.isEmpty());		
	}
	*/
	//@Test
	public void test_putCriteriaJSON() {
		Long trialId = 12345L;
		//candidateService.putCriteriaJSON(trialId, 0);
	}
	//@Test
	public void test_getLargestFolderName() {
		Long trialId = 12345L;
//		candidateService.getLargestFolderName(trialId);
	}
	@Test
	public void test_getFacetedSearchResults() {
		Long trialId = 12345L;
		//candidateService.BLOB_CONTAINER_NAME = "bigdata";
		//candidateService.BLOB_DIRECTORY_PREFIX = "jawahar/trial-";
		//candidateService.BLOB_DIRECTORY_PREFIX = "js-output/trial-";
//		CloudBlobDirectory dir = candidateService.getMaxFoldername(trialId);
//		Assert.assertNotNull("test_getMaxFoldername return shouldn't be null", dir);
//		CriteriaCounts cc =  candidateService.getFacetedSearchResults(trialId, 1, "");
//		assertNotNull("getFacetedSearchResults counts shouln't be null", cc);
//		assertNotNull("getFacetedSearchResults key value shouldn't be null", cc.getCriteriaNameToCountMap());
//		assertTrue("getFacetedSearchResults should have keys: " + cc.getCriteriaNameToCountMap().keySet().size(), cc.getCriteriaNameToCountMap().keySet().size() > 1);
//		assertTrue("getFacetedSearchResults GeoCandidate: " + cc.getGeoCandidate().getFeatures().size(), cc.getGeoCandidate().getFeatures().size() > 1);
//		Assert.assertTrue("getFacetedSearchResults Geo candidate should have correct type", cc.getGeoCandidate().getType().equals("FeatureCollection"));		
	}
	
	//@Test
	public void test_writeBigDataJson() {
		Long trialId = 12345L;
		//candidateService.BLOB_CONTAINER_NAME = "bigdata";
		//candidateService.BLOB_DIRECTORY_PREFIX = "jawahar/trial-";
		//candidateService.writeBigDataJson(trialId);
	}
	
	//@Test
	public void test_doFacetedSearch() {
//		Long trialId = 12345L;
//		candidateService.BLOB_CONTAINER_NAME = "bigdata";
//		candidateService.BLOB_DIRECTORY_PREFIX = "jawahar/trial-";
//		String bigDataJson = "{\\\"jawahar-all\\\": [{\\\"resource\\\": {\\\"properties\\\": [\\\"DiseaseSymptomsAndSigns\\\"], \\\"resourceType\\\": [\\\"Condition\\\"], \\\"cannotEvalute\\\": true}, \\\"description\\\": \\\"Patient is at high risk for a future cardiovascular event if at least one of the following criteria\\\"}, {\\\"resource\\\": {\\\"properties\\\": [\\\"Diet\\\", \\\"time\\\", \\\"TherapyOrSurgery\\\"], \\\"resourceType\\\": [\\\"CarePlan\\\", \\\"Procedure\\\"], \\\"cannotEvalute\\\": true}, \\\"description\\\": \\\"Patient must be on a stable diet and statin* therapy at least 4 weeks prior to randomization (Visit 2) and meet the following criteria\\\"}, {\\\"resource\\\": {\\\"expression\\\": \\\"( {0} == \\\\\\\"M\\\\\\\" or {0} == \\\\\\\"F\\\\\\\") and {1} >= 18\\\", \\\"properties\\\": [\\\"gender\\\", \\\"age\\\"], \\\"resourceType\\\": [\\\"Patient\\\"]}, \\\"description\\\": \\\"Men or women with age rage specified in the condition \\\"}, {\\\"resource\\\": {\\\"expression\\\": \\\" {0} == \\\\\\\"Cholesterol in LDL\\\\\\\" and {1} >= 150 and {1} <= 190\\\", \\\"properties\\\": [\\\"testName\\\", \\\"testValue\\\"], \\\"resourceType\\\": [\\\"Observation\\\"]}, \\\"description\\\": \\\"LDL-C value should match as defined in condition\\\"}, {\\\"resource\\\": {\\\"expression\\\": \\\" {0} == \\\\\\\"Triglyceride\\\\\\\" and {1} >= 180 and {1} <= 500\\\", \\\"properties\\\": [\\\"testName\\\", \\\"testValue\\\"], \\\"resourceType\\\": [\\\"Observation\\\"]}, \\\"description\\\": \\\"TG level and HDL-C for men or women as defined in condition\\\"}, {\\\"resource\\\": {\\\"properties\\\": [\\\"DiseaseSymptomsAndSigns\\\"], \\\"resourceType\\\": [\\\"Condition\\\"], \\\"cannotEvalute\\\": true}, \\\"description\\\": \\\"Hypertension\\\"}, {\\\"resource\\\": {\\\"properties\\\": [\\\"PharmaceuticalSubstanceOrDrug\\\"], \\\"resourceType\\\": [\\\"Procedure\\\"], \\\"cannotEvalute\\\": true}, \\\"description\\\": \\\"Allergy or intolerance to acids or drugs as defined in condition\\\"}, {\\\"resource\\\": {\\\"properties\\\": [\\\"PharmaceuticalSubstanceOrDrug\\\", \\\"time\\\"], \\\"resourceType\\\": [\\\"Procedure\\\"], \\\"cannotEvalute\\\": true}, \\\"description\\\": \\\"Use of drugs within time period as defined in condition\\\"}], \\\"description\\\": \\\"Evaluation of Major Cardiovascular Events in Patients With, or at High Risk for, Cardiovascular Disease Who Are Statin Intolerant Treated With Bempedoic Acid (ETC-1002) or Placebo (CLEAR Outcomes)\\\"}";
//		//String s = candidateService.doFacetedSearch(trialId, bigDataJson);
//		as//sertNotNull("test_doFacetedSearch should write to the blob storage", s);
	}
	
	////@Test
	public void test_getGeoCandidatesByTrial() {
		logger.info("----------test_getGeoCandidatesByTrial-----------------");
		//Optional<GeoCandidate> optGeoCandidate = candidateService.getGeoCandidatesByTrial(1L);
		Optional<GeoCandidate> optGeoCandidate = candidateService.getGeoCandidatesByTrial(1L);
		Assert.assertTrue("test_getGeoCandidatesByTrial candidate list is present", optGeoCandidate.isPresent());
		Assert.assertTrue("test_getGeoCandidatesByTrial candidate must have size > 1 got: " + optGeoCandidate.get().getFeatures().size(), 
				optGeoCandidate.get().getFeatures().size() > 1);
		Assert.assertTrue("test_getGeoCandidatesByTrial Geo candidate should have correct type", optGeoCandidate.get().getType().equals("FeatureCollection"));
	}
	

}
