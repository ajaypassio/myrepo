package com.avigosolutions.candidateservice.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.avigosolutions.candidateservice.model.CriteriaCounts;
import com.avigosolutions.candidateservice.model.LabRecords;
import com.avigosolutions.candidateservice.model.MongoPageRequest;
import com.avigosolutions.candidateservice.model.Patient;
import com.avigosolutions.candidateservice.model.PatientDetails;
import com.avigosolutions.candidateservice.model.SearchModel;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
public class PatientServiceApplicationTests {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	//@Autowired
	private PatientServiceImpl patientService;
	//@Autowired
	private static MongoOperations mongoOperations;
	private static String patientId = "164592922";

	public static long TEST_TRIAL_ID = 1000;

	// @Test
	// j
	// public void test_getPatients() {
	// List<Patient> patients = patientService.getPatients();
	// assertNotNull("test_getPatients patients shouldn't be null", patients);
	// assertTrue("test_getPatients should have size > 0: " + patients.size(),
	// patients.size() > 0);
	// logger.info("size: " + patients.size() + " -----\n " +
	// patients.get(0).toString());
	// }

	//@BeforeClass
	public static void setup_SavedSearch() {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringTestMongoConfig.class);
		mongoOperations = (MongoOperations) ctx.getBean("mongoTemplate");
		// Query query = new Query(Criteria.where("patient_id").is(patientId));
		// mongoOperations.findAllAndRemove(query, "patient");
		BasicQuery bq = new BasicQuery("{'patient_id': '" + patientId + "'}");
		Patient p = mongoOperations.findOne(bq, Patient.class, "patient");
		if (p == null) {
			LabRecords lrd1 = new LabRecords();
			lrd1.setTestName("LDL-CHOLESTEROL");
			lrd1.setTestValue("160");
			LabRecords lrd2 = new LabRecords();
			lrd2.setTestName("TRIGLYCERIDES");
			lrd2.setTestValue("190");
			LabRecords lrd3 = new LabRecords();
			lrd3.setTestName("HDL CHOLESTEROL");
			lrd3.setTestValue("32");
			Patient patient = new Patient().withPatientId(patientId).withGender("M").withAge(50);
			ArrayList<LabRecords> recordList = new ArrayList<>();
			recordList.add(lrd1);
			recordList.add(lrd2);
			recordList.add(lrd3);
			patient.setLabRecords(recordList);
			mongoOperations.save(patient);
		}

	}

	// @Test
	public void test_getCriteriaCounts() {
		Long trialId = TEST_TRIAL_ID;
		String trialJson = TrialJsonHelper.getMongoJSON3();
		SearchModel searchModel = new SearchModel();
		searchModel.withTrialId(trialId).withTrailJSON(trialJson);
		CriteriaCounts cc = patientService.getCriteriaCountMapAndPatients(searchModel);
		assertNotNull("test_getCriteriaCounts shouldn't have a null Criteria Counts", cc);
		assertNotNull("test_getCriteriaCounts shouldn't have a null GeoPatient", cc.getGeoPatient());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Patient List", cc.getGeoPatient().getFeatures());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map", cc.getCriteriaNameToCountMap());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map Criteria Key",
				cc.getCriteriaNameToCountMap().keySet());
		assertTrue(
				"test_getCriteriaCounts Counts Map Criteria should have size > 0: "
						+ cc.getCriteriaNameToCountMap().keySet().size(),
				cc.getCriteriaNameToCountMap().keySet().size() > 0);
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map Counts Value",
				cc.getCriteriaNameToCountMap().values());
		assertTrue(
				"test_getCriteriaCounts Counts Map Counts value should have size > 0: "
						+ cc.getCriteriaNameToCountMap().values().size(),
				cc.getCriteriaNameToCountMap().values().size() > 0);

	}

	//@Test
	public void test_getPageCriteriaCountsGeoData() {
		Long trialId = TEST_TRIAL_ID;
		String trialJson = TrialJsonHelper.getMongoJSON3();
		SearchModel searchModel = new SearchModel();
		MongoPageRequest pageRequest = new MongoPageRequest();
		pageRequest.withPageNumber(0).withPageSize(4);
		searchModel.withTrialId(trialId).withTrailJSON(trialJson).withMongoPageRequest(pageRequest);
		searchModel.withHasAggregation(true);
		CriteriaCounts cc = patientService.getCriteriaCountMapAndPatientsGeoData(searchModel, "patient_id,lat,lng");
		assertNotNull("test_getCriteriaCounts shouldn't have a null Criteria Counts", cc);
		assertNotNull("test_getCriteriaCounts shouldn't have a null GeoPatient", cc.getGeoPatient());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Patient List", cc.getGeoPatient().getFeatures());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map", cc.getCriteriaNameToCountMap());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map Criteria Key",
				cc.getCriteriaNameToCountMap().keySet());
		assertTrue(
				"test_getCriteriaCounts Counts Map Criteria should have size > 0: "
						+ cc.getCriteriaNameToCountMap().keySet().size(),
				cc.getCriteriaNameToCountMap().keySet().size() > 0);
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map Counts Value",
				cc.getCriteriaNameToCountMap().values());
		assertTrue(
				"test_getCriteriaCounts Counts Map Counts value should have size > 0: "
						+ cc.getCriteriaNameToCountMap().values().size(),
				cc.getCriteriaNameToCountMap().values().size() > 0);

	}

	// @Test
	public void test_getPageCriteriaCounts() {
		Long trialId = TEST_TRIAL_ID;
		String trialJson = TrialJsonHelper.getMongoJSON3();
		SearchModel searchModel = new SearchModel();
		MongoPageRequest pageRequest = new MongoPageRequest();
		pageRequest.withPageNumber(0).withPageSize(4);
		searchModel.withTrialId(trialId).withTrailJSON(trialJson).withMongoPageRequest(pageRequest);
		CriteriaCounts cc = patientService.getCriteriaCountMapAndPatients(searchModel);
		assertNotNull("test_getCriteriaCounts shouldn't have a null Criteria Counts", cc);
		assertNotNull("test_getCriteriaCounts shouldn't have a null GeoPatient", cc.getGeoPatient());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Patient List", cc.getGeoPatient().getFeatures());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map", cc.getCriteriaNameToCountMap());
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map Criteria Key",
				cc.getCriteriaNameToCountMap().keySet());
		assertTrue(
				"test_getCriteriaCounts Counts Map Criteria should have size > 0: "
						+ cc.getCriteriaNameToCountMap().keySet().size(),
				cc.getCriteriaNameToCountMap().keySet().size() > 0);
		assertNotNull("test_getCriteriaCounts shouldn't have a null Counts Map Counts Value",
				cc.getCriteriaNameToCountMap().values());
		assertTrue(
				"test_getCriteriaCounts Counts Map Counts value should have size > 0: "
						+ cc.getCriteriaNameToCountMap().values().size(),
				cc.getCriteriaNameToCountMap().values().size() > 0);

	}

	//@Test
	public void test_findByPatientId() {

		//TODO test is broken
		// // "6356";
		// // List<Patient> patients = patientService.findByPatientId(patientId);
		// PatientDetails patient = patientService.findByPatientId(patientId, TEST_TRIAL_ID);

		// assertNotNull("test_findByPatientId shouldn't have a null Patient", patient);

		// logger.info("Patient: " + patient.toString());

	}

}
