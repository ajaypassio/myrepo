package com.avigosolutions.candidateservice.service;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.avigosolutions.candidateservice.async.model.SavedSearchJobResponseModel;
import com.avigosolutions.candidateservice.async.service.SavedSearchAsyncService;
import com.avigosolutions.candidateservice.model.GeoPatientId;
import com.avigosolutions.candidateservice.model.SavedSearch;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @ConfigurationProperties(prefix="ss")
public class SavedSearchServiceApplicationTests {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//@Autowired
	private SavedSearchService savedSearchService;
	
	//@Autowired
	SavedSearchAsyncService savedSearchAsyncService;
	
	//@Autowired
	private static MongoOperations mongoOperations;
	
	//@Value("${mongoSavedSearchCollectionName}")
	private String mongoSavedSearchCollectionName;
	
//	@Autowired
//	private PlatformTransactionManager transactionManager;
	
	public static long TEST_TRIAL_ID = 10;
	public static String TEST_SAVED_SEARCH_NAME = "MyTest";
	public static String TEST_SAVED_SEARCH_NAME_FOR_UPDATE = "MyTest update";
	public static String TEST_SAVED_SEARCH_NAME_FOR_SAVE = "MyTest save";
	public static String TEST_SAVED_SEARCH_NAME_FOR_DELETE = "MyTest delete";
	public static String COLLECTION_NAME = "savedSearch";
	public static String COLLECTION_NAME_JOB = "savedSearchJob";
	
	//@Value("${sprintt.participant.service.url}")
	String participantServiceURL;
	
	//@BeforeClass
	public static void setup_SavedSearch() {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringTestMongoConfig.class);
		mongoOperations = (MongoOperations) ctx.getBean("mongoTemplate");
		Query query = new Query(Criteria.where("searchName").regex(TEST_SAVED_SEARCH_NAME + ".*"));
		mongoOperations.findAllAndRemove(query, COLLECTION_NAME);
		
		long trialId = TEST_TRIAL_ID;
		String searchName = TEST_SAVED_SEARCH_NAME;
		SavedSearch ss1 = new SavedSearch().withSearchName(searchName).withTrialId(trialId);
		mongoOperations.save(ss1, COLLECTION_NAME);
		
		SavedSearch ss2 = new SavedSearch().withSearchName(TEST_SAVED_SEARCH_NAME_FOR_UPDATE).withTrialId(trialId);
		List<String> patientIdList = Arrays.asList(
				"164592922", "433129060"
			);
		GeoPatientId gp = new GeoPatientId().withPatientIds(patientIdList);
		ss2.withGeoPatientId(gp);
		mongoOperations.save(ss2, COLLECTION_NAME);
		
		SavedSearch ss3 = new SavedSearch().withSearchName(TEST_SAVED_SEARCH_NAME_FOR_DELETE).withTrialId(trialId);
		//ss3.setCreateDate(new Date());
		//ss3.setUpdateDate(new Date());
		mongoOperations.save(ss3, COLLECTION_NAME);
	}
	//@AfterClass
	public static void cleanup_SavedSearch() {
		Query query = new Query(Criteria.where("searchName").regex(TEST_SAVED_SEARCH_NAME + ".*"));
		//mongoOperations.remove(query, "savedSearchTest");
	}
	//@Test
	public void test_setup() {
		assertNotNull("test_setup mongoOperations shouldn't be null", mongoOperations);
		assertNotNull("test_setup mongoSavedSearchCollectionName shouldn't be null", mongoSavedSearchCollectionName);
	}
	
	//@Test
	public void test_save() {
		SavedSearch ss1 = createSavedSearch(TEST_SAVED_SEARCH_NAME_FOR_SAVE);
		ss1.withTrialCriteriaStr(getJSON3());
		boolean ss2 = savedSearchService.save(ss1,"user");
		
		assertTrue(ss2);
	}
	
	//@Test
	public void test_saveAsync() throws Exception {
		// TODO: test is broken, needs fix 
		//SavedSearch ss1 = createSavedSearch(TEST_SAVED_SEARCH_NAME_FOR_SAVE);
		// ss1.withTrialCriteriaStr(getJSON3());
		// Future<SavedSearch> result = savedSearchAsyncService.saveSearch(ss1,"user");
		// SavedSearch ss = result.get();
		// Thread.sleep(10000);
		// assertNotNull(ss);	
	}
	
//	@Test
	public void testGetJobStatusByTrialId() throws Exception {
		List<SavedSearchJobResponseModel> result = savedSearchService.getJobStatusByTrialId(TEST_TRIAL_ID);
		assertNotNull(result);
		assertNotNull(result.get(0).getTrialId());
	}
	
//	@Test
	public void testGetJobStatusBySearchNameAndTrialId() throws Exception {
		SavedSearchJobResponseModel result = savedSearchService.getJobStatusBySearchNameAndTrialId(TEST_SAVED_SEARCH_NAME_FOR_SAVE,TEST_TRIAL_ID);
		assertNotNull(result);
		assertNotNull(result.getTrialId());
	}
	
	private SavedSearch createSavedSearch(String savedSearchName) {		
		
		List<String> patientIdList = Arrays.asList(
					"1025975991", "433129060"
				);
		GeoPatientId gp = new GeoPatientId().withPatientIds(patientIdList);
		
		Map<String, Integer> criteriaNameToCountMap = new HashMap<>();
		criteriaNameToCountMap.put("T10", 51);
		criteriaNameToCountMap.put("289", 2150);
		String criteriaStr = "\"labRecords\":{\"$elemMatch\":{\"testName\":\"Cholesterol.in LDL:MCnc:Pt:Ser/Plas:Qn\",\"testValue\":{\"$gte\":60,\"$lt\":190}}}";
		// CriteriaCounts cc = new CriteriaCounts().withGeoPatient(gp).withCriteriaNameToCountMap(criteriaNameToCountMap);
		SavedSearch ss = new SavedSearch().withSearchName(savedSearchName)
										  .withTrialId(TEST_TRIAL_ID)
										  .withCriteriaNameToCountMap(criteriaNameToCountMap)
										  .withGeoPatientId(gp)
										  .withCriteriaStr(criteriaStr)
										  .withTrialCriteriaStr(TrialJsonHelper.getMongoJSON3());
		
		return ss;
	}
	
	// @Test
	// public void test_saveWithNull() {
	// 	boolean ss = savedSearchService.save(null,"user");		
	// 	assertFalse(ss);
		
	// }
	
	// @Test
	// public void test_saveWithNullSearchName() {
	// 	SavedSearch ss1 = createSavedSearch(TEST_SAVED_SEARCH_NAME_FOR_SAVE);
	// 	ss1.setSearchName(null);
	// 	boolean ss2 = savedSearchService.save(ss1,"user");		
	// 	assertFalse(ss2);
		
	// }
	// @Test
	// public void test_saveWithInvalidTrialId() {
	// 	SavedSearch ss1 = createSavedSearch(TEST_SAVED_SEARCH_NAME_FOR_SAVE);
	// 	ss1.setTrialId(Long.MAX_VALUE);
	// 	boolean ss2 = savedSearchService.save(ss1,"user");
	// 	assertFalse(ss2);		
	// }

	// @Test
	// public void test_findBySearchName() {
	// 	SavedSearch ss = savedSearchService.findBySearchName(TEST_SAVED_SEARCH_NAME);

	// 	//SavedSearch ss = savedSearchService.findOne("5a370e8376ee5a3cd4653c89");
	// 	assertNotNull("test_findBySearchName SavedSearch shouldn't be null", ss);
	// 	assertNotNull("test_findBySearchName trialId shouldn't be null", ss.getTrialId());
	// 	logger.info("*****test_findBySearchName: " + ss.getSearchName() + " trialId: " + ss.getTrialId());
	
	// }
	
	// @Test
	// public void test_rename() {
	// 	long trialId = TEST_TRIAL_ID;
	// 	String searchName = TEST_SAVED_SEARCH_NAME_FOR_UPDATE;
	// 	SavedSearch ss1 = createSavedSearch(searchName);
	// 	String newName = searchName + " 2";
	// 	ss1.setSearchName(newName);
	// 	SavedSearch ss2 = savedSearchService.update(ss1, trialId, searchName);
		
	// 	assertNotNull("test_update SavedSearch shouldn't be null", ss2);
	// 	assertNotNull("test_update trialId shouldn't be null", ss2.getTrialId());
	// 	assertTrue("test_update trialId should be: " + TEST_TRIAL_ID, ss2.getTrialId() == TEST_TRIAL_ID);
	// 	assertTrue("test_update searchName should be: " + newName, ss2.getSearchName().equals(newName));
	// 	assertNotNull("test_update SavedSearch criteriaNameToCountMap shouldn't be null", ss2.getCriteriaNameToCountMap());
	// 	assertTrue("test_update criteriaNameToCountMap should be >0: " + ss2.getCriteriaNameToCountMap().size(), ss2.getCriteriaNameToCountMap().size() > 0);
	// 	assertNotNull("test_update SavedSearch crtieriaStr (JSON) shouldn't be null", ss2.getCriteriaStr());
		
	// 	//assertNotNull("test_update SavedSearch createDate shouldn't be null", ss2.getCreateDate());
	// 	assertTrue("test_update SavedSearch date should be >now: " + ss2.getCreateDate(), ss2.getUpdateDate().before(new Date()));
		
	// 	logger.info("----- test_update: " + ss2.getSearchName() + " trialId: " + ss2.getTrialId() + " updateDate: " + ss2.getUpdateDate() + " orig updateDate: " + ss1.getUpdateDate());		
		
	// }
	// @Test
	// public void test_update() {
		
	// 	//TODO: test is broken, needs fix
	// 	// long trialId = TEST_TRIAL_ID;
	// 	// String searchName = TEST_SAVED_SEARCH_NAME_FOR_UPDATE;
	// 	// SavedSearch ss1 = createSavedSearch(searchName);
	// 	// String updatedName = searchName + " 2";
	// 	// ss1.setSearchName(updatedName);
	// 	// SavedSearch ss2 = savedSearchService.update(ss1, trialId, searchName);
		
	// 	// assertNotNull("test_update SavedSearch shouldn't be null", ss2);
	// 	// assertNotNull("test_update trialId shouldn't be null", ss2.getTrialId());
	// 	// assertTrue("test_update trialId should be: " + TEST_TRIAL_ID, ss2.getTrialId() == TEST_TRIAL_ID);
	// 	// assertTrue("test_update searchName should be: " + updatedName, ss2.getSearchName().equals(updatedName));
	// 	// assertNotNull("test_update SavedSearch criteriaNameToCountMap shouldn't be null", ss2.getCriteriaNameToCountMap());
	// 	// assertTrue("test_update criteriaNameToCountMap should be >0: " + ss2.getCriteriaNameToCountMap().size(), ss2.getCriteriaNameToCountMap().size() > 0);
	// 	// assertNotNull("test_update SavedSearch crtieriaStr (JSON) shouldn't be null", ss2.getCriteriaStr());
		
	// 	// //assertNotNull("test_update SavedSearch createDate shouldn't be null", ss2.getCreateDate());
	// 	// assertTrue("test_update SavedSearch date should be >now: " + ss2.getCreateDate(), ss2.getUpdateDate().before(new Date()));
		
	// 	// logger.info("----- test_update: " + ss2.getSearchName() + " trialId: " + ss2.getTrialId() + " updateDate: " + ss2.getUpdateDate() + " orig updateDate: " + ss1.getUpdateDate());		
		
	// }
	
	// @Test
	// public void test_updateWithInvalidTrialId() {
	// 	long trialId = Long.MAX_VALUE;
	// 	String searchName = TEST_SAVED_SEARCH_NAME_FOR_UPDATE;
	// 	SavedSearch ss1 = createSavedSearch(searchName);
	// 	String updatedName = searchName + " 2";
	// 	ss1.setSearchName(updatedName);
	// 	SavedSearch ss2 = savedSearchService.update(ss1, trialId, searchName);
		
	// 	assertNull("test_updateWithInvalidTrialId update should be null", ss2);	
		
	// }
	// @Test
	// public void test_updateWithInvalidSearchName() {
	// 	long trialId = TEST_TRIAL_ID;
	// 	String searchName = TEST_SAVED_SEARCH_NAME_FOR_UPDATE + " Invalid Search Name";
	// 	SavedSearch ss1 = createSavedSearch(searchName);
	// 	String updatedName = searchName + " 2";
	// 	ss1.setSearchName(updatedName);
	// 	SavedSearch ss2 = savedSearchService.update(ss1, trialId, searchName);
		
	// 	assertNull("test_updateWithInvalidSearchName update should be null", ss2);	
		
	// }
	// //@Test
	// public void test_findAll() {
	// 	List<SavedSearch> ssList = savedSearchService.findAll();
		
	// 	assertNotNull("test_findAll SavedSearch shouldn't be null", ssList);
	// 	assertTrue("test_findAll should have size > 0: " + ssList.size(), ssList.size() > 0);
	// 	assertNotNull("test_findAll trialId shouldn't be null", ssList.get(0).getTrialId());
	// 	logger.info("%%%%% test_findAll: size: " + ssList.size() + " 0th elem: " + ssList.get(0).toString());		
	// }
	// @Test
	// public void test_findBySearchNameAndTrialId() {
	// 	long trialId = TEST_TRIAL_ID;
	// 	String searchName = TEST_SAVED_SEARCH_NAME_FOR_UPDATE;
	// 	SavedSearch savedSearch = new SavedSearch();
	// 	savedSearch.withTrialId(trialId).withSearchName(searchName);
	// 	SavedSearch ss = savedSearchService.findBySearchNameAndTrialId(savedSearch,"");
		
	// 	assertNotNull("test_findBySearchNameAndTrialId SavedSearch shouldn't be null", ss);
	// 	assertTrue("test_findBySearchNameAndTrialId trialId should be: " + TEST_TRIAL_ID, ss.getTrialId() == TEST_TRIAL_ID);
	// 	assertTrue("test_findBySearchNameAndTrialId searchName should be: " + searchName, ss.getSearchName().equals(searchName));
	// 	logger.info("%%%%% test_findBySearchNameAndTrialId: elem: " + ss.getSearchName() + " trialId: " + ss.getTrialId());		
	// }
	// @Test
	// public void test_findBySearchNameAndInvalidTrialId() {
	// 	long trialId = Long.MAX_VALUE;
	// 	String searchName = TEST_SAVED_SEARCH_NAME;
	// 	SavedSearch savedSearch = new SavedSearch();
	// 	savedSearch.withTrialId(trialId).withSearchName(searchName);
	// 	SavedSearch ss = savedSearchService.findBySearchNameAndTrialId(savedSearch,"");
		
	// 	assertNull("test_findBySearchNameAndInvalidTrialId SavedSearch should be null", ss);				
	// }
	// @Test
	// public void test_findByInvalidSearchNameAndTrialId() {
	// 	long trialId = TEST_TRIAL_ID;
	// 	String searchName = TEST_SAVED_SEARCH_NAME + "InvalidName";
	// 	SavedSearch savedSearch = new SavedSearch();
	// 	savedSearch.withTrialId(trialId).withSearchName(searchName);
	// 	SavedSearch ss = savedSearchService.findBySearchNameAndTrialId(savedSearch,"");
		
	// 	assertNull("test_findByInvalidSearchNameAndTrialId SavedSearch should be null", ss);				
	// }
	// @Test
	// public void test_findByTrialId() {
	// 	long trialId = TEST_TRIAL_ID;
		
	// 	List<SavedSearch> searchNameList = savedSearchService.getSavedSearchByTrialId(trialId);
		
	// 	assertNotNull("test_findByTrialId SavedSearch shouldn't be null", searchNameList);
	// 	assertTrue("test_findAll should have size > 0: " + searchNameList.size(), searchNameList.size() > 0);
	// 	logger.info("%%%%% test_findByTrialId: " + searchNameList);	
	// }
	// //@Rollback
	// @Test
	// public void test_delete() {
	// 	String searchName = TEST_SAVED_SEARCH_NAME_FOR_DELETE;
	// 	long trialId = TEST_TRIAL_ID;
		
	// 	savedSearchService.delete(searchName, trialId);
		
	// 	assertNull("##### test_delete shouldn't find SavesSearch with name: " + searchName, savedSearchService.findBySearchName(searchName));	
	// }
	
	private static String getJSON() {
		return "{  \"288\": {    \"$or\": [      {        \"gender\": \"M\",        \"labRecords\": {          \"$elemMatch\": {            \"testName\": \"Cholesterol in HDL\",            \"testValue\": {              \"$lt\": 42            }          }        }      },      {        \"gender\": \"F\",        \"labRecords\": {          \"$elemMatch\": {            \"testName\": \"Cholesterol in HDL\",            \"testValue\": {              \"$lt\": 47            }          }        }      }    ]  },  \"289\": {    \"$or\": [      {        \"$or\": [          {            \"gender\": \"M\"          },          {            \"gender\": \"F\"          }        ]      },      {        \"age\": {          \"$gte\": 18        }      }    ]  },  \"292\": {    \"$or\": [      {        \"age\": {          \"$eq\": 50        },        \"gender\": \"M\"      },      {        \"age\": {          \"$gt\": 60        },        \"gender\": \"F\"      }    ]  },  \"293\": {    \"labRecords\": {      \"$elemMatch\": {        \"testName\": \"Cholesterol in LDL\",        \"testValue\": {          \"$gte\": 150,          \"$lte\": 190        }      }    }  },  \"T_10\": {    \"$and\": [      {        \"labRecords\": {          \"$elemMatch\": {            \"testName\": \"Triglyceride\",            \"testValue\": {              \"$gt\": 180            }          }        }      },      {        \"$or\": [          {            \"gender\": \"M\",            \"labRecords\": {              \"$elemMatch\": {                \"testName\": \"Cholesterol in HDL\",                \"testValue\": {                  \"$lt\": 42                }              }            }          },          {            \"gender\": \"F\",            \"labRecords\": {              \"$elemMatch\": {                \"testName\": \"Cholesterol in HDL\",                \"testValue\": {                  \"$lt\": 47                }              }            }          }        ]      },      {        \"$or\": [          {            \"$or\": [              {                \"gender\": \"M\"              },              {                \"gender\": \"F\"              }            ]          },          {            \"age\": {              \"$gte\": 18            }          }        ]      },      {        \"$or\": [          {            \"age\": {              \"$eq\": 50            },            \"gender\": \"M\"          },          {            \"age\": {              \"$gt\": 60            },            \"gender\": \"F\"          }        ]      },      {        \"labRecords\": {          \"$elemMatch\": {            \"testName\": \"Cholesterol in LDL\",            \"testValue\": {              \"$gte\": 150,              \"$lte\": 190            }          }        }      }    ]  },  \"complete\": \"T_10\",  \"criterias\": [    \"288\",    \"289\",    \"292\",    \"293\",    \"291\",    \"T_10\"  ]}";
	}
	
	private static String getJSON2() {
		return "{\"331\": {\"$and\": [{\"$or\": [{\"gender\": \"M\"}, {\"gender\": \"F\"}]}, {\"age\": {\"$gte\": 18}}]}, \"T_11\": {\"$and\": [{\"$and\": [{\"$or\": [{\"gender\": \"M\"}, {\"gender\": \"F\"}]}, {\"age\": {\"$gte\": 18}}]}]}, \"complete\": \"T_11\", \"criterias\": [\"331\", \"T_11\"]}";
	}
	
	private static String getJSON3() {
		return "{\"344\": {\"$and\": [{\"$or\": [{\"gender\": \"M\"}, {\"gender\": \"F\"}]}, {\"age\": {\"$gte\": 99}}]}, \"T_11\": {\"$and\": [{\"$and\": [{\"$or\": [{\"gender\": \"M\"}, {\"gender\": \"F\"}]}, {\"age\": {\"$gte\": 99}}]}]}, \"complete\": \"T_11\", \"criterias\": [\"344\", \"T_11\"]}";
	}
}
