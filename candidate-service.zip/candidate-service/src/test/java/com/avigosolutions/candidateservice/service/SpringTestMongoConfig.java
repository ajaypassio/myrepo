package com.avigosolutions.candidateservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
// For annotations used, see: http://www.baeldung.com/configuration-properties-in-spring-boot
// @Configuration
// @PropertySource("classpath:application-test.properties")
// @ConfigurationProperties(prefix="ss")
public class SpringTestMongoConfig {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	// @Value("${spring.data.mongodb.uri}")
	// private String mongoURI;
	
	// @Value("${spring.data.mongodb.database}")
	// private String dbName;
	
	// @Value("${mongoSavedSearchCollectionName}")
	// public String collName;
	
	// public @Bean
	// MongoTemplate mongoTemplate() throws Exception {
	// 	//MongoTemplate mongoTemplate = new MongoTemplate(new MongoClient(new MongoClientURI(env.getProperty("spring.data.mongodb.uri"))), dbName);
	// 	logger.info("----------------- In mongoTemplate: URI: " + mongoURI + " dbName: " + dbName + " collName: " + collName);
	// 	MongoTemplate mongoTemplate = new MongoTemplate(new MongoClient(new MongoClientURI(mongoURI)), dbName);	
	// 	return mongoTemplate;
	// }
}
