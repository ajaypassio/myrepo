package com.questdiagnostics.clinicianservice;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@Configuration
@EnableWebMvc
@EnableSwagger2
public class ClinicianServiceConfiguration extends WebMvcConfigurerAdapter {
	
	@Value("${restTemplate.timeOut}")
	private int timeOut;
	
	@Bean
	public Docket docConfig() {
		return new Docket(DocumentationType.SWAGGER_2)
					.select()
					// .apis(Predicates.not(RequestHandlerSelectors.basePackage("org.springframework.boot")))
					.apis(RequestHandlerSelectors.basePackage("com.questdiagnostics.clinicianservice")) // interested only in questdiagnostics controllers
					.paths(PathSelectors.any())
					.build()
					.apiInfo(restApiInfo())
					// .pathMapping("/api") // TODO Fix with right version of Swagger and/or change path
					.directModelSubstitute(LocalDate.class, String.class) // replace local date with String
					.genericModelSubstitutes(ResponseEntity.class)        // we don't want ResponseEntity (spring specific), we want the data that's wrapped inside
					;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    registry.addResourceHandler("swagger-ui.html")
	      .addResourceLocations("classpath:/META-INF/resources/");
	 
	    registry.addResourceHandler("/webjars/**")
	      .addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
	

	
	private ApiInfo restApiInfo() {
		
		return new ApiInfo("Clinician Service API", "Helps Analyst to obtain a list of clinicians that match search parameter of patients", 
				"API TOS", "Terms of service", 
				new Contact("Quest Diagnostics", "www.questdiagnostics.com", ""), "", "",
				Collections.emptyList());
	}
	
	// log all incoming requests
		@Bean
		public CommonsRequestLoggingFilter logFilter() {
			CommonsRequestLoggingFilter filter = new CommonsRequestLoggingFilter();
			filter.setIncludeQueryString(true);
			filter.setIncludePayload(true);
			filter.setMaxPayloadLength(10000);
			filter.setIncludeHeaders(true);
			filter.setBeanName("Date: " + new Date());
			filter.setAfterMessagePrefix("<<<<<<< REQUEST DATA : ");
			filter.setBeforeMessagePrefix(">>>>> REQUEST DATA : ");
			return filter;
		}
		
		@Bean
		public RestTemplate restTemplate(RestTemplateBuilder builder)
				throws NoSuchAlgorithmException, KeyManagementException {

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };
			SSLContext sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
			CloseableHttpClient httpClient = HttpClients.custom().setSSLContext(sslContext)
					.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
			HttpComponentsClientHttpRequestFactory customRequestFactory = new HttpComponentsClientHttpRequestFactory();
			customRequestFactory.setHttpClient(httpClient);
			customRequestFactory.setConnectTimeout(timeOut);
			customRequestFactory.setReadTimeout(timeOut);
			RestTemplate restTemplate = builder.requestFactory(() -> customRequestFactory).build();
			return restTemplate;
		}
}
