package com.questdiagnostics.clinicianservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;

@Configuration
@EnableAutoConfiguration(exclude = { MongoAutoConfiguration.class, MongoDataAutoConfiguration.class })
public class SpringMongoConfig extends AbstractMongoConfiguration {

	@Autowired
	private Environment env;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${spring.data.mongodb.database}")
	private String dbName;

	@Value("${sprintt.ssl.enabled}")
	private boolean sslEnabled;

	@Override
	protected String getDatabaseName() {
		return dbName;
	}

	@Value("${mongoQuestCollectionName}")
	private String mongoQuestCollectionName;
	
	@Value("${questClinicianMasterCollectionName}")
	private String questClinicianMasterCollectionName;

	@Value("${mongoNPI1572CollectionName}")
	private String mongoNPI1572CollectionName;

	@Value("${mongoCROCollectionName}")
	private String mongoCROCollectionName;

	@Bean
	public MongoTemplate mongoTemplate() throws Exception {
		MongoTemplate mongoTemplate = new MongoTemplate(mongoClient(), getDatabaseName());
		if (!mongoTemplate.getCollectionNames().contains(mongoQuestCollectionName)) {
			mongoTemplate.createCollection(mongoQuestCollectionName);
		}
		if (!mongoTemplate.getCollectionNames().contains(questClinicianMasterCollectionName)) {
			mongoTemplate.createCollection(questClinicianMasterCollectionName);
		}
		if (!mongoTemplate.getCollectionNames().contains(mongoNPI1572CollectionName)) {
			mongoTemplate.createCollection(mongoNPI1572CollectionName);
		}
		if (!mongoTemplate.getCollectionNames().contains(mongoCROCollectionName)) {
			mongoTemplate.createCollection(mongoCROCollectionName);
		}
		return mongoTemplate;
	}

	@Bean
	public MongoClientOptions mongoClientOptions() {
		System.setProperty("javax.net.ssl.trustStore", env.getProperty("server.ssl.trust-store"));
		System.setProperty("javax.net.ssl.trustStorePassword", env.getProperty("server.ssl.trust-store-password"));
		MongoClientOptions.Builder builder = MongoClientOptions.builder();
		MongoClientOptions options = builder.sslEnabled(true).sslInvalidHostNameAllowed(true).build();
		return options;
	}

	public MongoClientOptions.Builder mongoClientOptionsBuilder() {
		System.setProperty("javax.net.ssl.trustStore", env.getProperty("server.ssl.trust-store"));
		System.setProperty("javax.net.ssl.trustStorePassword", env.getProperty("server.ssl.trust-store-password"));
		MongoClientOptions.Builder builder = MongoClientOptions.builder();
		builder.sslEnabled(true).sslInvalidHostNameAllowed(true).build();
		return builder;
	}

	@Override
	public MongoClient mongoClient() {
		String uri = env.getProperty("spring.data.mongodb.uri");
		logger.debug("==> Mongo:" + uri + " <==");
		if (!sslEnabled) {
			logger.info("==> NON SSL Mongo <==");
			MongoClientURI mcURI = new MongoClientURI(uri);
			return new MongoClient(mcURI);
		} else {
			logger.info("==> SSL Mong0 <==");
			MongoClientURI mcURI = new MongoClientURI(uri, mongoClientOptionsBuilder());
			return new MongoClient(mcURI);
		}
	}
}
