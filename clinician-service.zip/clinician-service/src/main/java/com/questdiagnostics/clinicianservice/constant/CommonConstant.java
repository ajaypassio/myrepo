/**
 * 
 */
package com.questdiagnostics.clinicianservice.constant;

/**
 * @author ajaykuma
 *
 */
/**
 * Instantiates a new common constants.
 */
public class CommonConstant {

	/** The Constant QUEST. */
	public static final String QUEST = "one";

	/** The Constant QUEST. */
	public static final String NPI_1572 = "two";

	/** The Constant QUEST. */
	public static final String CRO = "three";

	/** The Constant QUEST. */
	public static final String QUEST_NPI_1572 = "four";
	/** The Constant QUEST. */
	public static final String QUEST_CRO = "five";
	/** The Constant QUEST. */
	public static final String NPI_1572_CRO = "six";
	/** The Constant QUEST. */
	public static final String QUEST_NPI_1572_CRO = "seven";

	public static final String QUEST_NPI_1572_SOURCE = "Quest & 1572";
	public static final String QUEST_CRO_SOURCE = "Quest & CRO";
	public static final String QUEST_NPI_1572_CRO_SOURCE = "Quest, 1572 & CRO";
	public static final String NPI_1572_CRO_SOURCE = "1572 & CRO";
	
	public static final String SOURCE_QUEST="QUEST";
	public static final String COLLECTION="Data1";
	public static final String TRUE="true";
	public static final String FALSE="false";
	public static final String SUCCESS= "SUCCESS";
	public static final String USER_COLLECTION_NOT_FOUND="User collection not found";
	
	public static final String UNDER_SCORE="_";	
	public static final String EMPTY_STRING = "";	
	public static final String CAMPAIGN_COL_SUFFIX="campaign";
	public static final String CAMPAIGN_COL_BATCH_SUFFIX="batch";
	public static final String USERNAME_NPI_VALIDATION="Campaign user name and NPI are mandatory";
	public static final String SOURCE_QUEST1572="Quest and 1572";
	public static final String REQUESTED_OPERATION_FAILED  = "Requested operation failed";
	public static final String COLLECTION_NAME_BLANK  = "Collection Name is blank or null.";
	public static final String USERNAME_CAMPAIGNID_VALIDATION="Campaign user name and CampaignId are mandatory";
	public static final String BATCH_SUCCESS="Success";
	public static final String BATCH_FAIL="Failed";
	public static final int Schedule_Failed = 5;
	public static final String NO_DATA_AVAILABLE= "No Data Available";
}
