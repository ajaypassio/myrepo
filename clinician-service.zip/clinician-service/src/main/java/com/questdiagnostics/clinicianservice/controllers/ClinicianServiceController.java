package com.questdiagnostics.clinicianservice.controllers;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;
import com.questdiagnostics.clinicianservice.service.CROClinicianService;
import com.questdiagnostics.clinicianservice.strategy.QueryStartegy;
import com.questdiagnostics.clinicianservice.strategy.StrategyContext;
import com.questdiagnostics.clinicianservice.util.DownloadCSVHelper;

@RestController
public class ClinicianServiceController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private StrategyContext context;

	@Autowired
	private CROClinicianService croService;

	@Resource(name = "QuestStrategy")
	QueryStartegy questStrategy;

	@Resource(name = "CROStrategy")
	QueryStartegy croStrategy;

	@Resource(name = "NPI1572Strategy")
	QueryStartegy npi1572Strategy;

	@Resource(name = "DefaultStrategy")
	QueryStartegy defaultStrategy;

	@Resource(name = "QuestCroStrategy")
	QueryStartegy questCroStrategy;

	@Resource(name = "NPI1572CroStrategy")
	QueryStartegy npi1572CroStrategy;

	@Resource(name = "Quest1572AndCROStrategy")
	QueryStartegy questCroNpi1572Strategy;

	@RequestMapping(path = "/clinician/search", method = RequestMethod.POST)
	public ResponseEntity<ClinicianResponse> getFilteredClinician(@RequestBody QueryModel queryModel) {
		logger.debug("Process started for getFilteredClinician on controller");
		setStrategyContext(queryModel);
		/* process the data */
		ClinicianResponse clinician = context.processQueryFilter(queryModel);

		List<String> croProjectList = croService.getDistinctCroProject();
		if (croProjectList != null && croProjectList.size() > 0)
			clinician.setCroProject(croProjectList);

		if (clinician != null)
			return new ResponseEntity<ClinicianResponse>(clinician, HttpStatus.OK);
		return new ResponseEntity<ClinicianResponse>(HttpStatus.NOT_FOUND);
	}

	private void setStrategyContext(QueryModel queryModel) {
		if (queryModel.getSource().equals(CommonConstant.QUEST))
			context.setQueryStartegy(questStrategy);
		else if (queryModel.getSource().equals(CommonConstant.NPI_1572))
			context.setQueryStartegy(npi1572Strategy);
		else if (queryModel.getSource().equals(CommonConstant.CRO))
			context.setQueryStartegy(croStrategy);
		else if (queryModel.getSource().equals(CommonConstant.QUEST_NPI_1572))
			context.setQueryStartegy(defaultStrategy);
		else if (queryModel.getSource().equals(CommonConstant.QUEST_CRO))
			context.setQueryStartegy(questCroStrategy);
		else if (queryModel.getSource().equals(CommonConstant.NPI_1572_CRO))
			context.setQueryStartegy(npi1572CroStrategy);
		else if (queryModel.getSource().equals(CommonConstant.QUEST_NPI_1572_CRO))
			context.setQueryStartegy(questCroNpi1572Strategy);
	}

	@RequestMapping(path = "/download", method = RequestMethod.POST, produces = "application/octet-stream")
	public void downloadCSV(@RequestBody QueryModel queryModel, HttpServletResponse response) throws IOException {
		logger.info("Process started for downloadCSV on controller");
		response.setContentType("text/csv");
		response.setHeader("Content-Disposition", "attachment; file=customers.csv");
		setStrategyContext(queryModel);
		ClinicianResponse clinician = context.processQueryFilter(queryModel);
		List<ClinicianModel> customers = (List<ClinicianModel>) clinician.getData();
		DownloadCSVHelper.writeObjectToCSV(response.getWriter(), customers);
	}

}