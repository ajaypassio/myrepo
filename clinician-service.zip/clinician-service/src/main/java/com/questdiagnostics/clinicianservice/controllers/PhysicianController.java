package com.questdiagnostics.clinicianservice.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignCSVRequestModel;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignRequestModel;
import com.questdiagnostics.clinicianservice.model.PhysicianRequestModel;
import com.questdiagnostics.clinicianservice.model.ResponseObjectModel;
import com.questdiagnostics.clinicianservice.model.UpdateNoteRequest;
import com.questdiagnostics.clinicianservice.service.PhysicianService;

@Controller
@RequestMapping(path = "/physicians")
public class PhysicianController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	PhysicianService physicianService;

	@PostMapping(value = "/userCriteria")
	public ResponseEntity<ResponseObjectModel> getPhysicianResults(
			@RequestBody PhysicianRequestModel physicianRequestModel) {
		logger.debug("Process started for getPhysicianResults in controller");
		ResponseObjectModel responseObjectmodel = physicianService.getPhysicianData(physicianRequestModel);
		if (responseObjectmodel != null)
			return new ResponseEntity<ResponseObjectModel>(responseObjectmodel, HttpStatus.OK);
		return new ResponseEntity<ResponseObjectModel>(HttpStatus.NOT_FOUND);
	}

	@PostMapping(value = "/fetchPhysicianCampaignData")
	public ResponseEntity<ResponseObjectModel> getPhysicianCampaignData(
			@RequestBody PhysicianCampaignRequestModel physicianCampaignRequestModel) {		
		ResponseObjectModel responseObjectModel = null;
		if (physicianCampaignRequestModel.isViewHistory()) {
			responseObjectModel = physicianService.getPhysicianCampaignFetchHistory(physicianCampaignRequestModel);
		} else {
			responseObjectModel = physicianService.getPhysicianCampaignData(physicianCampaignRequestModel);
		}
		if (responseObjectModel != null)
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);

	}

	@PostMapping(value = "/updatePhysicianNote")
	public ResponseEntity<ResponseObjectModel> updatePhysicianNote(@RequestBody UpdateNoteRequest updateNote) {
		logger.info(" process started to update note for npi :{} ",updateNote.getNpi());
		ResponseObjectModel responseObjectModel = null;
		responseObjectModel = physicianService.updatePhysicianNote(updateNote);
		if (responseObjectModel != null)
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);

	}
	
	@PostMapping(value = "/exportCSVuserCriteria")
	public ResponseEntity<ResponseObjectModel> exportCSVuserCriteria(@RequestBody PhysicianRequestModel physicianRequestModel) {
		long start = System.currentTimeMillis();
		logger.info("PROCESSING Start {} : method : {}", start ,Thread.currentThread().getStackTrace()[1].getMethodName());
		
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			
			if (physicianRequestModel.getSource().equalsIgnoreCase("QUEST") && StringUtils.isEmpty(physicianRequestModel.getSpeciality())
					&& StringUtils.isEmpty(physicianRequestModel.getState())) {
				responseObjectModel = physicianService.getCsvSASUrl(physicianRequestModel);
			} else {
				responseObjectModel = physicianService.getPhysicianCSVData(physicianRequestModel);
			}
			logger.info("PROCESSING end : {}: method : {}", (System.currentTimeMillis() - start),
					Thread.currentThread().getStackTrace()[1].getMethodName());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : exportCSVuserCriteria method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			responseObjectModel.setMessage(CommonConstant.REQUESTED_OPERATION_FAILED);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping(value = "/exportCSVPhysicianCampaignData")
	public ResponseEntity<ResponseObjectModel> exportCSVPhysicianCampaignData(@RequestBody PhysicianCampaignCSVRequestModel physicianCampaignCSVRequestModel) {
		long start = System.currentTimeMillis();
		logger.info("PROCESSING Start {} : method : {}", start ,Thread.currentThread().getStackTrace()[1].getMethodName());
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = physicianService.getPhysicianCampaignDataForCSV(physicianCampaignCSVRequestModel);
			logger.info("PROCESSING end : {}: method : {}", (System.currentTimeMillis() - start),Thread.currentThread().getStackTrace()[1].getMethodName());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : exportCSVPhysicianCampaignData method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			responseObjectModel.setMessage(CommonConstant.REQUESTED_OPERATION_FAILED);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping(value = "/getCampaignBatchStatus")
	public ResponseEntity<ResponseObjectModel> getCampaignBatchStatus(
			@RequestBody List<PhysicianCampaignMaster> physicianCampaignMaster) {
		logger.debug("Process started for getCampaignBatchStatus in controller");
		ResponseObjectModel responseObjectmodel = physicianService
				.getPhysicianCampaignBatchStatus(physicianCampaignMaster);
		return new ResponseEntity<ResponseObjectModel>(responseObjectmodel, HttpStatus.OK);
	}
}
