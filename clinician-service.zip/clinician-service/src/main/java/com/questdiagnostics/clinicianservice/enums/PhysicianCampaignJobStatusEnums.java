package com.questdiagnostics.clinicianservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PhysicianCampaignJobStatusEnums {

	CampaignCreationInitiated("CampaignCreationInitiated", 1),
	CampaignCreationCompleted("CampaignCreationCompleted", 2),
	CampaignCreationFailed("CampaignCreationFailed", 3),
	NPIAssociationCompleted("NPIAssociationCompleted",4),
	NPIAssociationFailed("NPIAssociationFailed",5),
	ImportSyncInitiated("ImportSyncInitiated", 6),
	ImportSyncFailed("ImportSyncFailed", 7),
	ImportSyncPending("ImportSyncPending", 8),
	ExportSyncFailed("ExportSyncFailed", 9),
	ExportSyncPending("ExportSyncPending", 10),
	ExportSyncPendingFailed("ExportSyncPendingFailed", 11),
	ExportSyncCompleted("ExportSyncCompleted", 12),
	CLUInitiated("CLUInitiated", 13),
	CLUCompleted("CLUCompleted", 14),
	CLUFailed("CLUFailed", 15);

	/** The value. */
	private final String type;
	private final Integer value;

	PhysicianCampaignJobStatusEnums(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static PhysicianCampaignJobStatusEnums getStatusOf(int value) {
		for (PhysicianCampaignJobStatusEnums status : PhysicianCampaignJobStatusEnums.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static PhysicianCampaignJobStatusEnums getStatusOf(String type) {
		for (PhysicianCampaignJobStatusEnums status : PhysicianCampaignJobStatusEnums.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}
}
