package com.questdiagnostics.clinicianservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PhysicianCampaignStatusEnums {

	Creation_Initiated("Creation_Initiated", 1),
	Creation_Completed("Creation_Completed", 2),
	Creation_Failed("Creation_Failed", 3),
	Schedule_Initiated("Schedule_Initiated", 4),
	Schedule_Failed("Schedule_Failed", 5),
	Schedule_Completed("Schedule_Completed", 6);

	/** The value. */
	private final String type;
	private final Integer value;

	PhysicianCampaignStatusEnums(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static PhysicianCampaignStatusEnums getStatusOf(int value) {
		for (PhysicianCampaignStatusEnums status : PhysicianCampaignStatusEnums.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static PhysicianCampaignStatusEnums getStatusOf(String type) {
		for (PhysicianCampaignStatusEnums status : PhysicianCampaignStatusEnums.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}

}
