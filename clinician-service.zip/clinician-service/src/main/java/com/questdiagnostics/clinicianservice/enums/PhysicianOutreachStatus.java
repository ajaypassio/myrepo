package com.questdiagnostics.clinicianservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PhysicianOutreachStatus {


	OutreachPending("OutreachPending", 1),
	OutreachCompleted("OutreachCompleted", 2),
	NotApplicable("NotApplicable", 3),
	OutreachDenied("OutreachDenied", 4),
	OutreachInitiated("OutreachInitiated", 5),
	NotEligible("NotEligible",6);

	/** The value. */
	private final String type;
	private final Integer value;

	PhysicianOutreachStatus(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static PhysicianOutreachStatus getStatusOf(int value) {
		for (PhysicianOutreachStatus status : PhysicianOutreachStatus.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static PhysicianOutreachStatus getStatusOf(String type) {
		for (PhysicianOutreachStatus status : PhysicianOutreachStatus.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}
}