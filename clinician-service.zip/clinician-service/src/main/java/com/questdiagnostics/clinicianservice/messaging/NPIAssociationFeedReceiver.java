package com.questdiagnostics.clinicianservice.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignStatusEnums;
import com.questdiagnostics.clinicianservice.messaging.util.PhysicianCommonUtil;
import com.questdiagnostics.clinicianservice.model.NPIAssociationRequest;

@Component
public class NPIAssociationFeedReceiver {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private NPIAssociationProcessor npiAssociationProcessor;

	@Autowired
	PhysicianCommonUtil physicianCommonUtil;

	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureAccountNamePhysician;

	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureAccountKeyPhysician;

	@Value("${sprintt.npiassociation.queuename}")
	private String queueName;

	private Boolean isProcessing = Boolean.FALSE;

	@Scheduled(fixedDelayString = "${scheduler.npiassociation.process}")
	public void registerReceiverProcess() {
		logger.info("Receive NPI Association  message started----");
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		NPIAssociationRequest npiAssociationRequest = null;
		if (Boolean.FALSE.equals(isProcessing)) {
			try {
				storageAccount = CloudStorageAccount.parse(getStorageConnectionString());
				queueClient = storageAccount.createCloudQueueClient();
				queue = queueClient.getQueueReference(queueName);
				queue.createIfNotExists();
				// Peek at the next message.
				Iterable<CloudQueueMessage> listOfMessages = queue.retrieveMessages(1);
				for (CloudQueueMessage peekedMessage : listOfMessages) {
					ObjectMapper mapper = new ObjectMapper();
					npiAssociationRequest = mapper.readValue(peekedMessage.getMessageContentAsString(),
							NPIAssociationRequest.class);
					logger.info("Consumed npiAssociationRequest : {} ", npiAssociationRequest);
					isProcessing = Boolean.TRUE;
					isProcessing = npiAssociationProcessor.processNPIAssociation(npiAssociationRequest);
					queue.deleteMessage(peekedMessage);
				}
			} catch (Exception exception) {
				logger.error("Processing failed of npi association message from queue: {} ", exception);
				if (!ObjectUtils.isEmpty(npiAssociationRequest)) {
					String campaignBatchCollectionName = null;
					try {
						campaignBatchCollectionName = physicianCommonUtil.buildCollection(npiAssociationRequest,
								CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX);
						physicianCommonUtil.updateCampaignJobStatus(campaignBatchCollectionName,
								PhysicianCampaignJobStatusEnums.NPIAssociationFailed.getValue(),
								npiAssociationRequest.getSprinttCampaignId());

						// update campaign status as Scheduled Failed
						physicianCommonUtil.updateCampaignStatus(npiAssociationRequest.getSprinttCampaignId(),
								PhysicianCampaignStatusEnums.Schedule_Failed.getValue());

					} catch (Exception e) {
						logger.error("Processing failed of npi association with exception :{}", e);
					}

				}
			}
		}
	}

	private String getStorageConnectionString() {
		String storageConnectionString = "DefaultEndpointsProtocol=https;" + "AccountName=" + azureAccountNamePhysician
				+ ";AccountKey=" + azureAccountKeyPhysician + ";" + "EndpointSuffix=core.windows.net";

		return storageConnectionString;
	}
}
