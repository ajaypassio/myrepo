package com.questdiagnostics.clinicianservice.messaging;

import static com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums.NPIAssociationCompleted;
import static com.questdiagnostics.clinicianservice.enums.PhysicianOutreachStatus.OutreachInitiated;
import static com.questdiagnostics.clinicianservice.enums.PhysicianOutreachStatus.OutreachPending;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums;
import com.questdiagnostics.clinicianservice.messaging.util.PhysicianCommonUtil;
import com.questdiagnostics.clinicianservice.model.CampaignBatchData;
import com.questdiagnostics.clinicianservice.model.NPIAssociationRequest;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;

@Component
public class NPIAssociationProcessor {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private MongoTemplate template;

	@Autowired
	private PhysicianCommonUtil commonUtil;

	public Boolean processNPIAssociation(NPIAssociationRequest npiAssociationRequest) throws Exception {
		logger.info("npi association process started for the campaign id : {} and user name :{} ",
				npiAssociationRequest.getSprinttCampaignId(), npiAssociationRequest.getCampaignUserName());
		String campaignCollectionName = commonUtil.buildCollection(npiAssociationRequest,
				CommonConstant.CAMPAIGN_COL_SUFFIX);
		String campaignBatchCollectionName = commonUtil.buildCollection(npiAssociationRequest,
				CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX);
		if (!StringUtils.isEmpty(campaignCollectionName)) {
			if (npiAssociationRequest.isAllSelected() && npiAssociationRequest.getNpis().isEmpty()) {
				// Update records email outreach selected and mark status outreach initiated
				Query updateQuery = new Query(
						Criteria.where("displayCampaignRecord.currentStatus.em").is(OutreachPending.getValue()));
				Update update = new Update();
				update.set("displayCampaignRecord.isSelected", 1);
				update.set("displayCampaignRecord.currentStatus.em", OutreachInitiated.getValue());
				int recordsUpdated = template
						.bulkOps(BulkOperations.BulkMode.UNORDERED, PhysicianCampaignData.class, campaignCollectionName)
						.updateMulti(updateQuery, update).execute().getModifiedCount();
				logger.info("Updated {} records in the campaign collection with email outreach status as selected",
						recordsUpdated);
			} else {
				for (Long npi : npiAssociationRequest.getNpis()) {
					// Update records email outreach selected and mark status outreach initiated
					Query updateQuery = new Query(Criteria.where("displayCampaignRecord.npi").is(npi));
					Update update = new Update();
					update.set("displayCampaignRecord.isSelected", 1);
					update.set("displayCampaignRecord.currentStatus.em", OutreachInitiated.getValue());
					template.updateFirst(updateQuery, update, campaignCollectionName);
					logger.debug("npi updated with selected for email outreach {} ", npi);
				}
			}

			// update campaign batch status to npi association completed
			upsertCampaignJobStatus(NPIAssociationCompleted, CampaignBatchData.class,
					npiAssociationRequest.getSprinttCampaignId(), campaignBatchCollectionName);
		}

		return Boolean.FALSE;
	}

	private void upsertCampaignJobStatus(PhysicianCampaignJobStatusEnums campaignJobStatus, Class<?> entityClass,
			Long sprinttCampaignId, String collectionName) {
		Query campaignJobStatusQuery = new Query(Criteria.where("campaignId").is(sprinttCampaignId));
		Update update = new Update();
		update.set("campaignJobStatus", campaignJobStatus.getValue());
		template.upsert(campaignJobStatusQuery, update, entityClass, collectionName);
	}

}
