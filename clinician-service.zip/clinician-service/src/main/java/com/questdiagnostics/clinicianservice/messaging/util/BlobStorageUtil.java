package com.questdiagnostics.clinicianservice.messaging.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BlobStorageUtil {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.azure.blob.storage.connection.accountname}")
	private String azureAccountName;

	@Value("${sprintt.azure.blob.storage.connection.accountkey}")
	private String azureAccountKey;

	public String getStorageConnectionString() {
		String storageConnectionString = "DefaultEndpointsProtocol=https;" + "AccountName=" + azureAccountName
				+ ";AccountKey=" + azureAccountKey + ";" + "EndpointSuffix=core.windows.net";

		return storageConnectionString;
	}

}
