/**
 * 
 */
package com.questdiagnostics.clinicianservice.messaging.util;


import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.model.CampaignBatchData;
import com.questdiagnostics.clinicianservice.model.NPIAssociationRequest;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignMasterList;
import com.questdiagnostics.clinicianservice.model.PhysicianUpdateCampaignRequest;
import com.questdiagnostics.clinicianservice.model.ViewHistory;
import com.questdiagnostics.clinicianservice.util.RESTUtils;

/**
 * @author Ajay Kumar
 *
 */
@Component
public class PhysicianCommonUtil {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private MongoTemplate template;

	@Autowired
	RESTUtils restUtils;

	@Value("${getEligibleCampaigns.base.url}")
	private String getEligibleCampaignsBaseUrl;

	@Value("${updateCampaign.base.url}")
	private String updateCampaignBaseUrl;

	
	public void updateCampaignJobStatus(String campaignBatchCollectionName, int status, Long campaignId)
			throws Exception {
		Query query = new Query(Criteria.where("campaignId").is(campaignId));
		Update update = new Update();
		update.set("campaignJobStatus", status);
		template.updateFirst(query, update, campaignBatchCollectionName);
	}

	public String buildCollection(NPIAssociationRequest npiAssociationRequest, String type) throws Exception {
		if (type.equals(CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX)) {
			return new StringBuilder(npiAssociationRequest.getCampaignUserName()).append(CommonConstant.UNDER_SCORE)
					.append(npiAssociationRequest.getSprinttCampaignId()).append(CommonConstant.UNDER_SCORE)
					.append(CommonConstant.CAMPAIGN_COL_SUFFIX).append(CommonConstant.UNDER_SCORE)
					.append(CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX).toString();
		} else {
			return new StringBuilder(npiAssociationRequest.getCampaignUserName()).append(CommonConstant.UNDER_SCORE)
					.append(npiAssociationRequest.getSprinttCampaignId()).append(CommonConstant.UNDER_SCORE)
					.append(CommonConstant.CAMPAIGN_COL_SUFFIX).toString();
		}
	}

	public String buildCollection(String userName, Long sprinttCampaignId, String type) throws Exception {
		if (type.equals(CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX)) {
			return new StringBuilder(userName).append(CommonConstant.UNDER_SCORE).append(sprinttCampaignId)
					.append(CommonConstant.UNDER_SCORE).append(CommonConstant.CAMPAIGN_COL_SUFFIX)
					.append(CommonConstant.UNDER_SCORE).append(CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX).toString();
		} else {
			return new StringBuilder(userName).append(CommonConstant.UNDER_SCORE).append(sprinttCampaignId)
					.append(CommonConstant.UNDER_SCORE).append(CommonConstant.CAMPAIGN_COL_SUFFIX).toString();
		}
	}

	public List<CampaignBatchData> getCampaignData(String campaignBatchCollectionName,
			List<String> campaignJobStatusList) {
		Query query = new Query(Criteria.where("campaignJobStatus").in(campaignJobStatusList));
		return template.find(query, CampaignBatchData.class, campaignBatchCollectionName);
	}

	public List<PhysicianCampaignMaster> getEligibleCampaigns() {
		PhysicianCampaignMasterList physicianCampaignMasterList = new PhysicianCampaignMasterList();
		try {
			ResponseEntity<PhysicianCampaignMasterList> entity = restUtils.execute(null, getEligibleCampaignsBaseUrl,
					HttpMethod.GET, PhysicianCampaignMasterList.class);
			if (entity != null && entity.getStatusCode().equals(HttpStatus.OK)) {
				physicianCampaignMasterList = entity.getBody();
			}
		} catch (Exception ex) {
			logger.info("Exception in getEligibleCampaigns : {}", ex.getMessage());
		}
		return physicianCampaignMasterList.getPhysicianCampaignMasterList();
	}

	public PhysicianCampaignMaster updatePhysicianCampaignStatus(
			PhysicianUpdateCampaignRequest physicianUpdateCampaignRequest) {
		logger.info("Processing for updatePhysicianCampaignStatusId");
		PhysicianCampaignMaster physicianCampaignMaster = null;
		try {
			ResponseEntity<PhysicianCampaignMaster> entity = restUtils.execute(physicianUpdateCampaignRequest,
					updateCampaignBaseUrl, HttpMethod.PUT, PhysicianCampaignMaster.class);
			if (entity != null && entity.getStatusCode().equals(HttpStatus.OK)) {
				physicianCampaignMaster = entity.getBody();
			}
		} catch (Exception ex) {
			logger.info("Exception in updatePhysicianCampaignStatusId : {}", ex.getMessage());
		}
		return physicianCampaignMaster;
	}

	public void updateCampaignStatus(Long sprinttCampaignId, int campaignStatusId) {
		PhysicianUpdateCampaignRequest physicianUpdateCampaignRequest = new PhysicianUpdateCampaignRequest();
		physicianUpdateCampaignRequest.setSprinttCampaignId(sprinttCampaignId);
		physicianUpdateCampaignRequest.setCampaignStatusId(campaignStatusId);
		updatePhysicianCampaignStatus(physicianUpdateCampaignRequest);
	}
	
	public PhysicianCampaignData getHistoryDesc(PhysicianCampaignData physicianCampaignData) {
		List<ViewHistory> viewHistories = physicianCampaignData.getViewHistories();
		List<ViewHistory> sortedUsers = viewHistories.stream()
				  .sorted(Comparator.comparing(ViewHistory::getTransactiondate).reversed())
				  .collect(Collectors.toList());
		physicianCampaignData.setViewHistories(sortedUsers);
		return physicianCampaignData;
	}
}
