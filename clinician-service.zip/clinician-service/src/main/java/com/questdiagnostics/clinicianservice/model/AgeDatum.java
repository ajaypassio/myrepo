
package com.questdiagnostics.clinicianservice.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "age",
    "diagnostic_data",
    "lab_results"
})
public class AgeDatum {

    @JsonProperty("age")
    private Integer age;
    @JsonProperty("diagnostic_data")
    private List<DiagnosticDatum> diagnosticData = null;
    @JsonProperty("lab_results")
    private List<LabResult> labResults = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("age")
    public Integer getAge() {
        return age;
    }

    @JsonProperty("age")
    public void setAge(Integer age) {
        this.age = age;
    }

    @JsonProperty("diagnostic_data")
    public List<DiagnosticDatum> getDiagnosticData() {
        return diagnosticData;
    }

    @JsonProperty("diagnostic_data")
    public void setDiagnosticData(List<DiagnosticDatum> diagnosticData) {
        this.diagnosticData = diagnosticData;
    }

    @JsonProperty("lab_results")
    public List<LabResult> getLabResults() {
        return labResults;
    }

    @JsonProperty("lab_results")
    public void setLabResults(List<LabResult> labResults) {
        this.labResults = labResults;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
