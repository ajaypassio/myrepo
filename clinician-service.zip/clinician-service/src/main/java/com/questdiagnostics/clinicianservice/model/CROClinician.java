package com.questdiagnostics.clinicianservice.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "cro_id", "source", "npi", "first_name", "last_name", "address1", "address2", "city",
		"state", "zip", "trail_id", "site_name", "site_id", "investigator_name", "investigator_id", "specialty",
		"project", "phone_number" })
public class CROClinician implements Serializable {

	private static final long serialVersionUID = -1604347862473519664L;

	@JsonProperty("_id")
	private String id;
	@JsonProperty("source")
	private String source;
	@JsonProperty("npi")
	private String npi;
	@Field("first_name")
	@JsonProperty("firstName")
	private String firstName;
	@Field("last_name")
	@JsonProperty("lastName")
	private String lastName;
	@JsonProperty("address1")
	private String address1;
	@JsonProperty("address2")
	private String address2;
	@JsonProperty("city")
	private String city;
	@JsonProperty("state")
	private String state;
	@JsonProperty("zip")
	private String zip;
	@Field("trial_id")
	@JsonProperty("trialId")
	private Long trialId;
	@Field("site_name")
	@JsonProperty("siteName")
	private String siteName;
	@Field("investigator_id")
	@JsonProperty("investigatorId")
	private Long investigatorId;
	@JsonProperty("specialty")
	private String specialty;
	@JsonProperty("project")
	private String project;
	@JsonProperty("email")
	private String email;

	@Field("phone_number")
	@JsonProperty("phoneNumber")
	private List<String> phoneNumber;

	@JsonProperty("_id")
	public String getId() {
		return id;
	}

	@JsonProperty("_id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("source")
	public String getSource() {
		return source;
	}

	@JsonProperty("source")
	public void setSource(String source) {
		this.source = source;
	}

	@JsonProperty("npi")
	public String getNpi() {
		return npi;
	}

	@JsonProperty("npi")
	public void setNpi(String npi) {
		this.npi = npi;
	}

	@JsonProperty("firstName")
	public String getFirstName() {
		return firstName;
	}

	@JsonProperty("firstName")
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@JsonProperty("lastName")
	public String getLastName() {
		return lastName;
	}

	@JsonProperty("lastName")
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@JsonProperty("city")
	public String getCity() {
		return city;
	}

	@JsonProperty("city")
	public void setCity(String city) {
		this.city = city;
	}

	@JsonProperty("state")
	public String getState() {
		return state;
	}

	@JsonProperty("state")
	public void setState(String state) {
		this.state = state;
	}

	@JsonProperty("zip")
	public String getZip() {
		return zip;
	}

	@JsonProperty("zip")
	public void setZip(String zip) {
		this.zip = zip;
	}

	@JsonProperty("specialty")
	public String getSpecialty() {
		return specialty;
	}

	@JsonProperty("specialty")
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	@JsonProperty("project")
	public String getProject() {
		return project;
	}

	@JsonProperty("project")
	public void setProject(String project) {
		this.project = project;
	}

	@JsonProperty("email")
	public String getEmail() {
		return email;
	}

	@JsonProperty("email")
	public void setEmail(String email) {
		this.email = email;
	}

	@JsonProperty("trial_id")
	public Long getTrailId() {
		return trialId;
	}

	@JsonProperty("trial_id")
	public void setTrailId(Long trialId) {
		this.trialId = trialId;
	}

	@JsonProperty("site_name")
	public String getSiteName() {
		return siteName;
	}

	@JsonProperty("site_name")
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	@JsonProperty("investigator_id")
	public Long getInvestigatorId() {
		return investigatorId;
	}

	@JsonProperty("investigator_id")
	public void setInvestigatorId(Long investigatorId) {
		this.investigatorId = investigatorId;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the phoneNumber
	 */
	public List<String> getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(List<String> phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "CROClinician [id=" + id + ", source=" + source + ", npi=" + npi + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", address1=" + address1 + ", address2=" + address2 + ", city=" + city
				+ ", state=" + state + ", zip=" + zip + ", trialId=" + trialId + ", siteName=" + siteName
				+ ", investigatorId=" + investigatorId + ", specialty=" + specialty + ", project=" + project
				+ ", email=" + email + ", phoneNumber=" + phoneNumber + "]";
	}

}
