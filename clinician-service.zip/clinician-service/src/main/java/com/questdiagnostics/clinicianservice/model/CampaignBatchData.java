package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Ajay Kumar
 *
 */
public class CampaignBatchData {

	private int campaignId;
	private int campaignJobStatus;
	private String importURI;
	private String exportURI;
	private String exportSyncURI;
	private String importSyncURI;

	/**
	 * @return the campaignId
	 */
	public int getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	@JsonProperty("campaignId")
	public void setCampaignId(int campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the campaignJobStatus
	 */
	public int getCampaignJobStatus() {
		return campaignJobStatus;
	}

	/**
	 * @param campaignJobStatus the campaignJobStatus to set
	 */
	@JsonProperty("campaignJobStatus")
	public void setCampaignJobStatus(int campaignJobStatus) {
		this.campaignJobStatus = campaignJobStatus;
	}

	/**
	 * @return the importURI
	 */
	@JsonProperty("importURI")
	public String getImportURI() {
		return importURI;
	}

	/**
	 * @param importURI the importURI to set
	 */
	public void setImportURI(String importURI) {
		this.importURI = importURI;
	}

	/**
	 * @return the exportURI
	 */
	@JsonProperty("exportURI")
	public String getExportURI() {
		return exportURI;
	}

	/**
	 * @param exportURI the exportURI to set
	 */
	public void setExportURI(String exportURI) {
		this.exportURI = exportURI;
	}

	/**
	 * @return the exportSyncURI
	 */
	public String getExportSyncURI() {
		return exportSyncURI;
	}

	/**
	 * @param exportSyncURI the exportSyncURI to set
	 */
	@JsonProperty("exportSyncURI")
	public void setExportSyncURI(String exportSyncURI) {
		this.exportSyncURI = exportSyncURI;
	}

	/**
	 * @return the importSyncURI
	 */
	public String getImportSyncURI() {
		return importSyncURI;
	}

	/**
	 * @param importSyncURI the importSyncURI to set
	 */
	@JsonProperty("importSyncURI")
	public void setImportSyncURI(String importSyncURI) {
		this.importSyncURI = importSyncURI;
	}

}