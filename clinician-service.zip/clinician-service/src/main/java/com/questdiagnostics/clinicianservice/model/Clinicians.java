
package com.questdiagnostics.clinicianservice.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	"_id",
    "npi",
    "source",
    "noOfPatients",
    "first_name",
    "last_name",
    "middle_name",
    "address1",
    "address2",
    "address",
    "city",
    "state",
    "zip",
    "email_address",
    "phone_number",
    "specialty",
    "project",
    "data"
})
public class Clinicians {

    @JsonProperty("npi")
   	@JsonAlias("npi_no")
    private String npi = "";
   	
   	@JsonProperty("source")
    private String source =  "";
   	@JsonProperty("noOfPatients")
    private Integer noOfPatients = 0;
	@Field("first_name")
    @JsonProperty("first_name")
    private String firstName = "";
	@Field("last_name")
    @JsonProperty("last_name")
    private String lastName = "";
	@Field("middle_name")
    @JsonProperty("middle_name")
    private String middleName = "";
    @JsonProperty("address1")
    private String address1 = "";
    @JsonProperty("address2")
    private String address2 = "";
    @JsonProperty("address")
    private String address = "";
   
	@JsonProperty("city")
    private String city = "";
    @JsonProperty("state")
    private String state = "";
    @JsonProperty("zip")
    private String zip = "";
    @Field("email_address")
    @JsonProperty("email_address")
    private List<String> emailAddress = null;
    @Field("phone_number")
    @JsonProperty("phone_number")
    private List<String> phoneNumber = null;
    @JsonProperty("specialty")
    @JsonAlias("primary_taxonomy")
    private String specialty = "";
    @JsonProperty("project")
    private String project = "";
    
    @JsonProperty("fastingCount")
    private Integer fastingCount;
    @JsonProperty("patient_ids")
    private List<String> patient_ids = null;
  
	@JsonProperty("data")
    private List<Datum> data = null;
    
    public Clinicians() {
	 
	}
    
    public Clinicians(String npi, String firstName) {
		super();
		this.npi = npi;
		this.firstName = firstName;
	}	

    public String getNpi() {
        return npi;
    }
    public void setNpi(String npi) {
        this.npi = npi;
    }
    @JsonProperty("source")
    public String getSource() {
		return source;
	}
    @JsonProperty("source")
	public void setSource(String source) {
		this.source = source;
	}
    
    @JsonProperty("noOfPatients")
    public Integer getNoOfPatients() {
		return noOfPatients;
	}

    @JsonProperty("noOfPatients")
	public void setNoOfPatients(Integer noOfPatients) {
		this.noOfPatients = noOfPatients;
	}
    @JsonProperty("patient_ids")
  	public List<String> getPatient_ids() {
  		return patient_ids;
  	}
      @JsonProperty("patient_ids")
  	public void setPatient_ids(List<String> patient_ids) {
  		this.patient_ids = patient_ids;
  	}

	@JsonProperty("first_name")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("first_name")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("last_name")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("last_name")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("middle_name")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("middle_name")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("address1")
    public String getAddress1() {
        return address1;
    }

    @JsonProperty("address1")
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    @JsonProperty("address2")
    public String getAddress2() {
        return address2;
    }

    @JsonProperty("address2")
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    @JsonProperty("address")
    public String getAddress() {
		return address;
	}
    @JsonProperty("address")
	public void setAddress(String address) {
		this.address = address;
	}

    @JsonProperty("city")
    public String getCity() {
        return city;
    }

    @JsonProperty("city")
    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("state")
    public String getState() {
        return state;
    }

    @JsonProperty("state")
    public void setState(String state) {
        this.state = state;
    }

    @JsonProperty("zip")
    public String getZip() {
        return zip;
    }

    @JsonProperty("zip")
    public void setZip(String zip) {
        this.zip = zip;
    }

    @JsonProperty("email_address")
    public List<String> getEmailAddress() {
        return emailAddress;
    }

    @JsonProperty("email_address")
    public void setEmailAddress(List<String> emailAddress) {
        this.emailAddress = emailAddress;
    }

    @JsonProperty("phone_number")
    public List<String> getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phone_number")
    public void setPhoneNumber(List<String> phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
 
    public String getSpecialty() {
        return specialty;
    }
 
    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
    public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

    @JsonProperty("data")
    public List<Datum> getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(List<Datum> data) {
        this.data = data;
    }
   
    
    public Integer getFastingCount() {
		return fastingCount;
	}

	public void setFastingCount(Integer fastingCount) {
		this.fastingCount = fastingCount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((npi == null) ? 0 : npi.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Clinicians other = (Clinicians) obj;
		if (npi == null) {
			if (other.npi != null)
				return false;
		} else if (!npi.equals(other.npi)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Clinicians [npi=" + npi + ", source=" + source + ", noOfPatients=" + noOfPatients
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", middleName=" + middleName + ", address1="
				+ address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state + ", zip=" + zip
				+ ", emailAddress=" + emailAddress + ", phoneNumber=" + phoneNumber + ", specialty=" + specialty
				+ ", project=" + project + ", fastingCount=" + fastingCount + ", data=" + data + "]";
	}
    
    

}
