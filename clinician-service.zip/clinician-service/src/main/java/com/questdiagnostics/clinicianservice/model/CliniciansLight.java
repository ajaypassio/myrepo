
package com.questdiagnostics.clinicianservice.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class CliniciansLight {

    
    @JsonAlias("_id")
    private String id = "";
   	
   	@JsonProperty("noOfPatients")
    private Integer noOfPatients = 0;
	
    @JsonProperty("patient_ids")
    private List<String> patient_ids = null;
    
    @JsonIgnore
    private Set<String> patient_ids_set = new HashSet<>();
    
    public CliniciansLight() {
	 
	}
    
    @JsonProperty("noOfPatients")
    public Integer getNoOfPatients() {
		return noOfPatients;
	}

    @JsonProperty("noOfPatients")
	public void setNoOfPatients(Integer noOfPatients) {
		this.noOfPatients = noOfPatients;
	}

    @JsonProperty("patient_ids")
  	public List<String> getPatient_ids() {
  		return patient_ids;
  	}
   
    @JsonProperty("patient_ids")
  	public void setPatient_ids(List<String> patient_ids) {
  		this.patient_ids = patient_ids;
  		if(!CollectionUtils.isEmpty(patient_ids)) {
  			patient_ids_set.addAll(patient_ids);
  		}
  	}

    public Set<String> getPatient_ids_set() {
    	return patient_ids_set;
    }

	public String getId() {
		return id;
	}

	@JsonProperty("_id")
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CliniciansLight other = (CliniciansLight) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Clinicians [id=" + id + ", noOfPatients=" + noOfPatients + "]";
	}

}
