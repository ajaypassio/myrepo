package com.questdiagnostics.clinicianservice.model;

/**
 * @author Ajay Kumar
 *
 */

public class CurrentStatus {

	private int dm;
	private int pc;
	private int em;

	public int getDm() {
		return dm;
	}
	public void setDm(int dm) {
		this.dm = dm;
	}
	public int getPc() {
		return pc;
	}
	public void setPc(int pc) {
		this.pc = pc;
	}
	public int getEm() {
		return em;
	}
	public void setEm(int em) {
		this.em = em;
	}
	
}
