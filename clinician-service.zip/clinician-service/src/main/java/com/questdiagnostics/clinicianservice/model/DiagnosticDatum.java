
package com.questdiagnostics.clinicianservice.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "standard",
    "version",
    "disease_info"
})
public class DiagnosticDatum {

    @JsonProperty("standard")
    private String standard;
    @JsonProperty("version")
    private String version;
    @JsonProperty("disease_info")
    private List<DiseaseInfo> diseaseInfo = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("standard")
    public String getStandard() {
        return standard;
    }

    @JsonProperty("standard")
    public void setStandard(String standard) {
        this.standard = standard;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    @JsonProperty("disease_info")
    public List<DiseaseInfo> getDiseaseInfo() {
        return diseaseInfo;
    }

    @JsonProperty("disease_info")
    public void setDiseaseInfo(List<DiseaseInfo> diseaseInfo) {
        this.diseaseInfo = diseaseInfo;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
