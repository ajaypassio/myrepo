
package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "comparision",
    "icdCode",
    "icdCodeSet"
})
public class DignosticsFilter {

	@JsonProperty("comparision")
    private String comparision;
    @JsonProperty("icdCode")
    private String icdCode;
    @JsonProperty("icdCodeSet")
    private String icdCodeSet;
     
    @JsonProperty("comparision")
    public String getComparision() {
        return comparision;
    }

    @JsonProperty("comparision")
    public void setComparision(String comparision) {
        this.comparision = comparision;
    }

    @JsonProperty("icdCode")
    public String getIcdCode() {
        return icdCode;
    }

    @JsonProperty("icdCode")
    public void setIcdCode(String icdCode) {
        this.icdCode = icdCode;
    }

    @JsonProperty("icdCodeSet")
    public String getIcdCodeSet() {
        return icdCodeSet;
    }

    @JsonProperty("icdCodeSet")
    public void setIcdCodeSet(String icdCodeSet) {
        this.icdCodeSet = icdCodeSet;
    }

  
}

