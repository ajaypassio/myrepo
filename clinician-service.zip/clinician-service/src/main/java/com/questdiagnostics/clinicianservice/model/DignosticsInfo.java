
package com.questdiagnostics.clinicianservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "init",
    "or"
})
public class DignosticsInfo {

    @JsonProperty("init")
    private List<DignosticsFilter> init = null;
    @JsonProperty("or")
    private List<DignosticsOrFilter> or = null;
    
    @JsonProperty("init")
    public List<DignosticsFilter> getInit() {
        return init;
    }

    @JsonProperty("init")
    public void setInit(List<DignosticsFilter> init) {
        this.init = init;
    }

    @JsonProperty("or")
    public List<DignosticsOrFilter> getOr() {
        return or;
    }

    @JsonProperty("or")
    public void setOr(List<DignosticsOrFilter> or) {
        this.or = or;
    }

    
}
