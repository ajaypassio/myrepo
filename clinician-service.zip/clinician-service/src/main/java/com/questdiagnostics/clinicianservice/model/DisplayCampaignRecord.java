package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Ajay Kumar
 *
 */
public class DisplayCampaignRecord {
	@JsonProperty("npi")
	private long npi;
	@JsonProperty("first_name")
	private String first_name;
	@JsonProperty("last_name")
	private String last_name;
	private int isSelected;
	@JsonProperty("currentStatus")
	private CurrentStatus currentStatus;
	public long getNpi() {
		return npi;
	}
	public void setNpi(long npi) {
		this.npi = npi;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	/**
	 * @return the isSelected
	 */
	@JsonProperty("isSelected")
	public int getIsSelected() {
		return isSelected;
	}

	/**
	 * @param isSelected the isSelected to set
	 */
	public void setIsSelected(int isSelected) {
		this.isSelected = isSelected;
	}

	public CurrentStatus getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(CurrentStatus currentStatus) {
		this.currentStatus = currentStatus;
	}
}
