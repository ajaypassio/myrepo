package com.questdiagnostics.clinicianservice.model;

import org.springframework.data.annotation.Transient;

/**
 * @author Ajay Kumar
 *
 */
public class DisplayRecord {

	public long npi;
	public String first_name;
	public String middle_name;
	public String last_name;
	public String address1;
	public String address2;
	public String city;
	public String state;
	public String state_abv;
	public String zip;
	public String email_address;
	public String phone_number;
	public String specialty;
	public int number_of_patients;
	public String fax_number;
	
	@Transient
	public String source;
	
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getSpecialty() {
		return specialty;
	}
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	public int getNumber_of_patients() {
		return number_of_patients;
	}
	public void setNumber_of_patients(int number_of_patients) {
		this.number_of_patients = number_of_patients;
	}
	public long getNpi() {
		return npi;
	}
	public void setNpi(long npi) {
		this.npi = npi;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getFax_number() {
		return fax_number;
	}
	public void setFax_number(String fax_number) {
		this.fax_number = fax_number;
	}
	/**
	 * @return the state_abv
	 */
	public String getState_abv() {
		return state_abv;
	}
	/**
	 * @param state_abv the state_abv to set
	 */
	public void setState_abv(String state_abv) {
		this.state_abv = state_abv;
	}
	
	
}