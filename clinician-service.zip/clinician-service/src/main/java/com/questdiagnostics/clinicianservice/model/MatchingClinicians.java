
package com.questdiagnostics.clinicianservice.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MatchingClinicians {
  
	@JsonProperty("totalCount")
    private List<Object> totalCount;
	
	@JsonProperty("data")
    private List<Clinicians> data = null;
	
	@JsonProperty("total_record_in_db")
	private Integer total_record_in_db;
    
	@JsonProperty("matched_as_per_criteria_Count")
	private Integer matched_as_per_criteria_Count; 
		 

	public MatchingClinicians() {
	 
	}


     
	
	/**
	 * @return the totalCount
	 */
	public List<Object> getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(List<Object> totalCount) {
		this.totalCount = totalCount;
	}
 
 
	public Integer getTotal_record_in_db() {
		return total_record_in_db;
	}




	public void setTotal_record_in_db(Integer total_record_in_db) {
		this.total_record_in_db = total_record_in_db;
	}




	public Integer getMatched_as_per_criteria_Count() {
		return matched_as_per_criteria_Count;
	}




	public void setMatched_as_per_criteria_Count(Integer matched_as_per_criteria_Count) {
		this.matched_as_per_criteria_Count = matched_as_per_criteria_Count;
	}




	/**
	 * @return the data
	 */
	public List<Clinicians> getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(List<Clinicians> data) {
		this.data = data;
	}
    
}