
package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ageMin",
    "ageMax",
    "male",
    "female"
})
public class PatientFilter {

	@JsonProperty("ageMin")
    private Integer ageMin;
    @JsonProperty("ageMax")
    private Integer ageMax;
    @JsonProperty("male")
    private Boolean male;
    @JsonProperty("female")
    private Boolean female;
    
    @JsonProperty("ageMin")
    public Integer getAgeMin() {
        return ageMin;
    }

    @JsonProperty("ageMin")
    public void setAgeMin(Integer ageMin) {
        this.ageMin = ageMin;
    }

    @JsonProperty("ageMax")
    public Integer getAgeMax() {
        return ageMax;
    }

    @JsonProperty("ageMax")
    public void setAgeMax(Integer ageMax) {
        this.ageMax = ageMax;
    }

    @JsonProperty("male")
    public Boolean getMale() {
        return male;
    }

    @JsonProperty("male")
    public void setMale(Boolean male) {
        this.male = male;
    }

    @JsonProperty("female")
    public Boolean getFemale() {
        return female;
    }

    @JsonProperty("female")
    public void setFemale(Boolean female) {
        this.female = female;
    }
 
}
