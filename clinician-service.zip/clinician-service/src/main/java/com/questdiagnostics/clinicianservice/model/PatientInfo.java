
package com.questdiagnostics.clinicianservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "init"
})
public class PatientInfo {

    @JsonProperty("init")
    private List<PatientFilter> init = null;
     
    @JsonProperty("init")
    public List<PatientFilter> getInit() {
        return init;
    }

    @JsonProperty("init")
    public void setInit(List<PatientFilter> init) {
        this.init = init;
    }

    
}
