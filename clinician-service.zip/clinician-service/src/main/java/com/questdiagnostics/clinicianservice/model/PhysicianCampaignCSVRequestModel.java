package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianCampaignCSVRequestModel {
	
	@JsonProperty("userName")
	private String userName;
	
	@JsonProperty("campaignId")
	private int campaignId ;
	
	@JsonProperty("npi")
	private Long [] npi;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(int campaignId) {
		this.campaignId = campaignId;
	}

	public Long[] getNpi() {
		return npi;
	}

	public void setNpi(Long[] npi) {
		this.npi = npi;
	}
	
	

}
