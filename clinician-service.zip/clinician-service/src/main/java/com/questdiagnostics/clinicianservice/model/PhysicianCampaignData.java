package com.questdiagnostics.clinicianservice.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Ajay Kumar
 *
 */
public class PhysicianCampaignData implements Serializable {

	private static final long serialVersionUID = -1014627835580010031L;

	private long npi;
	private DisplayCampaignRecord displayCampaignRecord;
	private DisplayRecord exportRecord;
	private List<ViewHistory> viewHistories;

	@JsonProperty("npi")
	public long getNpi() {
		return this.npi;
	}

	public void setNpi(long npi) {
		this.npi = npi;
	}

	/**
	 * @return the displayCampaignRecord
	 */
	@JsonProperty("displayCampaignRecord")
	public DisplayCampaignRecord getDisplayCampaignRecord() {
		return displayCampaignRecord;
	}

	/**
	 * @param displayCampaignRecord the displayCampaignRecord to set
	 */
	public void setDisplayCampaignRecord(DisplayCampaignRecord displayCampaignRecord) {
		this.displayCampaignRecord = displayCampaignRecord;
	}

	@JsonProperty("exportRecord")
	public DisplayRecord getExportRecord() {
		return this.exportRecord;
	}

	public void setExportRecord(DisplayRecord exportRecord) {
		this.exportRecord = exportRecord;
	}

	@JsonProperty("viewHistories")
	public List<ViewHistory> getViewHistories() {
		return this.viewHistories;
	}

	public void setViewHistories(List<ViewHistory> viewHistories) {
		this.viewHistories = viewHistories;
	}
}
