package com.questdiagnostics.clinicianservice.model;

import java.io.Serializable;
import java.util.Date;

public class PhysicianCampaignMaster implements Serializable{

	private static final long serialVersionUID = -4509022779590403602L;
	
	private Long sprinttCampaignId;

	private String campaignName;

	private String userName;
	
	private String specs;
	
	private int campaignStatusId;
	
	private String remarks;
	
	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public String getCampaignName() {
		return campaignName;
	}

	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getSpecs() {
		return specs;
	}

	public void setSpecs(String specs) {
		this.specs = specs;
	}

	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(int campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}

	@Override
	public String toString() {
		return "PhysicianCampaignMaster [sprinttCampaignId=" + sprinttCampaignId + ", campaignName=" + campaignName
				+ ", userName=" + userName + ", specs=" + specs + ", campaignStatusId=" + campaignStatusId
				+ ", remarks=" + remarks + "]";
	}
	
}

