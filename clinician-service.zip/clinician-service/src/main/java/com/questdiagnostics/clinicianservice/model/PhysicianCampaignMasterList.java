package com.questdiagnostics.clinicianservice.model;

import java.util.List;

public class PhysicianCampaignMasterList {
	
	List<PhysicianCampaignMaster> physicianCampaignMasterList;

	public List<PhysicianCampaignMaster> getPhysicianCampaignMasterList() {
		return physicianCampaignMasterList;
	}

	public void setPhysicianCampaignMasterList(List<PhysicianCampaignMaster> physicianCampaignMasterList) {
		this.physicianCampaignMasterList = physicianCampaignMasterList;
	}

}
