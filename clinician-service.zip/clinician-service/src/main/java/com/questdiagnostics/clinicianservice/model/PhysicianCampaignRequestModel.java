package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianCampaignRequestModel {

	private String userName;

	private long campaignId;

	private long npi;

	private String firstName;

	private String lastName;


	@JsonProperty("isViewHistory")
	private boolean isViewHistory = false;
	
	private int directMail;
	
	private int phoneCall;
	
	private int email;


	private MongoPageRequest mongoPageRequest;


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public long getCampaignId() {
		return campaignId;
	}


	public void setCampaignId(long campaignId) {
		this.campaignId = campaignId;
	}


	public long getNpi() {
		return npi;
	}


	public void setNpi(long npi) {
		this.npi = npi;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public boolean isViewHistory() {
		return isViewHistory;
	}


	public void setViewHistory(boolean isViewHistory) {
		this.isViewHistory = isViewHistory;
	}


	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}


	public void setMongoPageRequest(MongoPageRequest mongoPageRequest) {
		this.mongoPageRequest = mongoPageRequest;
	}


	public int getDirectMail() {
		return directMail;
	}


	public void setDirectMail(int directMail) {
		this.directMail = directMail;
	}


	public int getPhoneCall() {
		return phoneCall;
	}


	public void setPhoneCall(int phoneCall) {
		this.phoneCall = phoneCall;
	}

	public int getEmail() {
		return email;
	}


	public void setEmail(int email) {
		this.email = email;
	}

	
}
