package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
/**
 * @author Ajay Kumar
 *
 */
public class PhysicianData {

	public long npi;
	
	@JsonProperty("data")
	public DisplayRecord displayRecord;
	@JsonProperty("exportRecord")
	public DisplayRecord exportRecord;
	public String isBmis;
	public String hasEmail;
	public String hasPhoneNo;
	public String hasAddress;

	@JsonProperty("npi")
	public long getNpi() {
		return this.npi;
	}

	public void setNpi(long npi) {
		this.npi = npi;
	}

	@JsonProperty("displayRecord")
	public DisplayRecord getDisplayRecord() {
		return this.displayRecord;
	}

	public void setDisplayRecord(DisplayRecord displayRecord) {
		this.displayRecord = displayRecord;
	}
	/**
	 * @return the exportRecord
	 */
	@JsonProperty("exportRecord")
	public DisplayRecord getExportRecord() {
		return exportRecord;
	}

	/**
	 * @param exportRecord the exportRecord to set
	 */
	public void setExportRecord(DisplayRecord exportRecord) {
		this.exportRecord = exportRecord;
	}

	@JsonProperty("isBmis")
	public String getIsBmis() {
		return this.isBmis;
	}

	public void setIsBmis(String isBmis) {
		this.isBmis = isBmis;
	}

	@JsonProperty("hasEmail")
	public String getHasEmail() {
		return this.hasEmail;
	}

	public void setHasEmail(String hasEmail) {
		this.hasEmail = hasEmail;
	}

	@JsonProperty("hasPhoneNo")
	public String getHasPhoneNo() {
		return this.hasPhoneNo;
	}

	public void setHasPhoneNo(String hasPhoneNo) {
		this.hasPhoneNo = hasPhoneNo;
	}

	@JsonProperty("hasAddress")
	public String getHasAddress() {
		return this.hasAddress;
	}

	public void setHasAddress(String hasAddress) {
		this.hasAddress = hasAddress;
	}

}