package com.questdiagnostics.clinicianservice.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianDatas {

	@JsonProperty("physicianData")
    private List<PhysicianData> physicianData = null;
	
	@JsonProperty("total_record_in_db")
	private Integer total_record_in_db;

	public List<PhysicianData> getPhysicianData() {
		return physicianData;
	}

	public void setPhysicianData(List<PhysicianData> physicianData) {
		this.physicianData = physicianData;
	}

	public Integer getTotal_record_in_db() {
		return total_record_in_db;
	}

	public void setTotal_record_in_db(Integer total_record_in_db) {
		this.total_record_in_db = total_record_in_db;
	}
	
	
}
