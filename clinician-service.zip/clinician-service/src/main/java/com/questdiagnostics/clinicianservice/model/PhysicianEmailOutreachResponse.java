package com.questdiagnostics.clinicianservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "emailOutreachId",
    "sprinttCampaignId",
    "eloquaCampaignId",
    "segmentId"
})
public class PhysicianEmailOutreachResponse implements Serializable{

	private static final long serialVersionUID = -4509022779590403602L;

	@JsonProperty("emailOutreachId")
	private Long emailOutreachId;

	@JsonProperty("sprinttCampaignId")
	private Long sprinttCampaignId;

	@JsonProperty("eloquaCampaignId")
	private String eloquaCampaignId;
	
	@JsonProperty("segmentId")
	private Long segmentId;

	@JsonProperty("emailOutreachId")
	public Long getEmailOutreachId() {
		return emailOutreachId;
	}

	@JsonProperty("emailOutreachId")
	public void setEmailOutreachId(Long emailOutreachId) {
		this.emailOutreachId = emailOutreachId;
	}

	
	@JsonProperty("sprinttCampaignId")
	public Long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	@JsonProperty("sprinttCampaignId")
	public void setSprinttCampaignId(Long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	@JsonProperty("eloquaCampaignId")
	public String getEloquaCampaignId() {
		return eloquaCampaignId;
	}

	@JsonProperty("eloquaCampaignId")
	public void setEloquaCampaignId(String eloquaCampaignId) {
		this.eloquaCampaignId = eloquaCampaignId;
	}

	@JsonProperty("segmentId")
	public Long getSegmentId() {
		return segmentId;
	}
	@JsonProperty("segmentId")
	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}
	

	
}


