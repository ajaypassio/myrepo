package com.questdiagnostics.clinicianservice.model;

public class PhysicianRequestModel {

	private String userName;

	private String source;

	private String speciality;

	private String state;

	private MongoPageRequest mongoPageRequest;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}

	public void setMongoPageRequest(MongoPageRequest mongoPageRequest) {
		this.mongoPageRequest = mongoPageRequest;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
