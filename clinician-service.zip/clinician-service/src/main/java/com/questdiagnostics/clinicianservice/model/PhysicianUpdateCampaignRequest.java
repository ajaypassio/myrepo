package com.questdiagnostics.clinicianservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianUpdateCampaignRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("sprinttCampaignId")
	private long sprinttCampaignId;
	
	@JsonProperty("campaignStatusId")
	private int campaignStatusId;

	public long getSprinttCampaignId() {
		return sprinttCampaignId;
	}

	public void setSprinttCampaignId(long sprinttCampaignId) {
		this.sprinttCampaignId = sprinttCampaignId;
	}

	public int getCampaignStatusId() {
		return campaignStatusId;
	}

	public void setCampaignStatusId(int campaignStatusId) {
		this.campaignStatusId = campaignStatusId;
	}
	
}