package com.questdiagnostics.clinicianservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.questdiagnostics.clinicianservice.util.DignosticsInfo;
import com.questdiagnostics.clinicianservice.util.LabTest;
import com.questdiagnostics.clinicianservice.util.PatientInfo;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "patientInfo", "labTest", "dignosticsInfo", "mongoPageRequest", "hasExport", "source", "project" })
public class QueryModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("patientInfo")
	private PatientInfo patientInfo;
	@JsonProperty("labTest")
	private LabTest labTest;
	@JsonProperty("dignosticsInfo")
	private DignosticsInfo dignosticsInfo;
	
	@JsonProperty("mongoPageRequest")
	private MongoPageRequest mongoPageRequest;
	@JsonProperty("hasExport")
	private boolean hasExport = false;
	@JsonProperty("source")
	private String source;
	@JsonProperty("project")
	private String project;
 
	 @JsonProperty("patientInfo")
	    public PatientInfo getPatientInfo() {
	        return patientInfo;
	    }

	    @JsonProperty("patientInfo")
	    public void setPatientInfo(PatientInfo patientInfo) {
	        this.patientInfo = patientInfo;
	    }

	    @JsonProperty("labTest")
	    public LabTest getLabTest() {
	        return labTest;
	    }

	    @JsonProperty("labTest")
	    public void setLabTest(LabTest labTest) {
	        this.labTest = labTest;
	    }

	    @JsonProperty("dignosticsInfo")
	    public DignosticsInfo getDignosticsInfo() {
	        return dignosticsInfo;
	    }

	    @JsonProperty("dignosticsInfo")
	    public void setDignosticsInfo(DignosticsInfo dignosticsInfo) {
	        this.dignosticsInfo = dignosticsInfo;
	    }
	    
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}

	public QueryModel withMongoPageRequest(MongoPageRequest pageable) {
		this.mongoPageRequest = pageable;
		return this;
	}

	public boolean getHasExport() {
		return hasExport;
	}

	public void setHasExport(boolean hasExport) {
		this.hasExport = hasExport;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (hasExport ? 1231 : 1237);
		result = prime * result + ((mongoPageRequest == null) ? 0 : mongoPageRequest.hashCode());
		result = prime * result + ((project == null) ? 0 : project.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QueryModel other = (QueryModel) obj;
		if (hasExport != other.hasExport)
			return false;
		if (mongoPageRequest == null) {
			if (other.mongoPageRequest != null)
				return false;
		} else if (!mongoPageRequest.equals(other.mongoPageRequest))
			return false;
		if (project == null) {
			if (other.project != null)
				return false;
		} else if (!project.equals(other.project))
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		return true;
	}

}
