package com.questdiagnostics.clinicianservice.model;

public class SearchModel {

	private String criteriaJSON;

	private MongoPageRequest mongoPageRequest;

	private boolean hasAggregation = false;
	
	private String source;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public MongoPageRequest getMongoPageRequest() {
		return mongoPageRequest;
	}

	public SearchModel withMongoPageRequest(MongoPageRequest pageable) {
		this.mongoPageRequest = pageable;
		return this;
	}  

	public String getCriteriaJSON() {
		return criteriaJSON;
	}

	public void setCriteriaJSON(String criteriaJSON) {
		this.criteriaJSON = criteriaJSON;
	}

	public boolean getHasAggregation() {
		return hasAggregation;
	}

	public SearchModel withHasAggregation(boolean hasAggregation) {
		this.hasAggregation = hasAggregation;
		return this;
	}
}
