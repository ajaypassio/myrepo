
package com.questdiagnostics.clinicianservice.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "test_name",
    "unit",
    "test_value"
})
public class TestDatum {

    @JsonProperty("test_name")
    private String testName;
    @JsonProperty("unit")
    private String unit;
    @JsonProperty("test_value")
    private List<TestValue> testValue = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("test_name")
    public String getTestName() {
        return testName;
    }

    @JsonProperty("test_name")
    public void setTestName(String testName) {
        this.testName = testName;
    }
    @JsonProperty("unit")
    public String getUnit() {
		return unit;
	}
    @JsonProperty("unit")
	public void setUnit(String unit) {
		this.unit = unit;
	}
    @JsonProperty("test_value")
    public List<TestValue> getTestValue() {
        return testValue;
    }

    @JsonProperty("test_value")
    public void setTestValue(List<TestValue> testValue) {
        this.testValue = testValue;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
