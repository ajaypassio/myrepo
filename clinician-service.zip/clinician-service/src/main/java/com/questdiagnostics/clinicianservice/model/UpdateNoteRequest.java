package com.questdiagnostics.clinicianservice.model;

/**
 * @author Ajay Kumar
 *
 */
public class UpdateNoteRequest extends ViewHistory {

	private String campaignUserName;

	private long campaignId;

	private long npi;

	/**
	 * @return the campaignUserName
	 */
	public String getCampaignUserName() {
		return campaignUserName;
	}

	/**
	 * @param campaignUserName the campaignUserName to set
	 */
	public void setCampaignUserName(String campaignUserName) {
		this.campaignUserName = campaignUserName;
	}

	/**
	 * @return the campaignId
	 */
	public long getCampaignId() {
		return campaignId;
	}

	/**
	 * @param campaignId the campaignId to set
	 */
	public void setCampaignId(long campaignId) {
		this.campaignId = campaignId;
	}

	/**
	 * @return the npi
	 */
	public long getNpi() {
		return npi;
	}

	/**
	 * @param npi the npi to set
	 */
	public void setNpi(long npi) {
		this.npi = npi;
	}
}
