package com.questdiagnostics.clinicianservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author Ajay Kumar
 *
 */
public class ViewHistory {

	private String transactiondate;
	private int dm;
	private int pc;
	private int em;
	private String userName;
	private String note;

	@JsonProperty("transactiondate")
	public String getTransactiondate() {
		return this.transactiondate;
	}

	public void setTransaciondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}

	@JsonProperty("dm")
	public int getDm() {
		return this.dm;
	}

	public void setDm(int dm) {
		this.dm = dm;
	}

	@JsonProperty("pc")
	public int getPc() {
		return this.pc;
	}

	public void setPc(int pc) {
		this.pc = pc;
	}

	@JsonProperty("em")
	public int getEm() {
		return this.em;
	}

	public void setEm(int em) {
		this.em = em;
	}

	@JsonProperty("userName")
	public String getUserName() {
		return this.userName;
	}

	public void setUsername(String userName) {
		this.userName = userName;
	}

	@JsonProperty("note")
	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

}