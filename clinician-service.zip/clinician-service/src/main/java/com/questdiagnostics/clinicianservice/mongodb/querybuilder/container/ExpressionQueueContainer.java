package com.questdiagnostics.clinicianservice.mongodb.querybuilder.container;

import java.util.LinkedList;
import java.util.Queue;

import org.springframework.data.mongodb.core.query.Criteria;

import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Expression;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.LogicalOperator;

public class ExpressionQueueContainer {

	private Criteria containerCriteria;

	protected LogicalOperator operatorKey;

	private Queue<Expression> expressionQueue = new LinkedList<>();

	public ExpressionQueueContainer(LogicalOperator operatorKey) {
		this.operatorKey = operatorKey;
	}

	public Criteria getContainerCriteria() {
		return containerCriteria;
	}

	public void setContainerCriteria(Criteria containerCriteria) {
		this.containerCriteria = containerCriteria;
	}

	public void setOperatorKey(LogicalOperator operatorKey) {
		this.operatorKey = operatorKey;
	}

	public LogicalOperator getOperatorKey() {
		return operatorKey;
	}

	public boolean offer(Expression expression) {
		return expressionQueue.offer(expression);
	}

	public Expression poll() {
		return expressionQueue.poll();
	}

	public Expression peek() {
		return expressionQueue.peek();
	}

	public boolean isEmpty() {
		return expressionQueue.isEmpty();
	}
	
	public int size() {
		return expressionQueue.size();
	}

	@Override
	public String toString() {
		return "ExpressionQueueContainer [containerCriteria=" + containerCriteria + ", operatorKey=" + operatorKey
				+ ", expressionQueue=" + expressionQueue + "]";
	}

}
