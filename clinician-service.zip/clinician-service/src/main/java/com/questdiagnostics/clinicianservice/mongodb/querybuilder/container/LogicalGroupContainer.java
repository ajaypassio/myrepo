package com.questdiagnostics.clinicianservice.mongodb.querybuilder.container;

import java.util.LinkedList;
import java.util.Queue;

import org.springframework.data.mongodb.core.query.Criteria;

import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.LogicalOperator;

public class LogicalGroupContainer {

	private Criteria containerCriteria;

	protected LogicalOperator operatorKey;

	private Queue<ExpressionQueueContainer> expressionQueueContainerQueue = new LinkedList<>();

	public LogicalGroupContainer(LogicalOperator operatorKey) {
		this.operatorKey = operatorKey;
	}

	public Criteria getContainerCriteria() {
		return containerCriteria;
	}

	public void setContainerCriteria(Criteria containerCriteria) {
		this.containerCriteria = containerCriteria;
	}

	public LogicalOperator getOperatorKey() {
		return operatorKey;
	}

	public void setOperatorKey(LogicalOperator operatorKey) {
		this.operatorKey = operatorKey;
	}

	public boolean offer(ExpressionQueueContainer container) {
		return expressionQueueContainerQueue.offer(container);
	}

	public ExpressionQueueContainer poll() {
		return expressionQueueContainerQueue.poll();
	}

	public ExpressionQueueContainer peek() {
		return expressionQueueContainerQueue.peek();
	}

	public boolean isEmpty() {
		return expressionQueueContainerQueue.isEmpty();
	}
	
	public int size() {
		return expressionQueueContainerQueue.size();
	}

	@Override
	public String toString() {
		return "LogicalGroupContainer [containerCriteria=" + containerCriteria + ", operatorKey=" + operatorKey
				+ ", expressionQueueContainerQueue=" + expressionQueueContainerQueue + "]";
	}

}
