package com.questdiagnostics.clinicianservice.mongodb.querybuilder.container;

import java.util.LinkedList;
import java.util.Queue;

import org.springframework.data.mongodb.core.query.Criteria;

import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria;

public class SearchCriteriaContainer {

	private Criteria containerCriteria;
	
	private SearchCriteria searchCriteria;

	private LogicalOperator operatorKey;

	private Queue<LogicalGroupContainer> logicalGroupContainerQueue = new LinkedList<>();

	public SearchCriteriaContainer(SearchCriteria searchCriteria) {
		this.searchCriteria = searchCriteria;
	}

	public void setOperatorKey(LogicalOperator operatorKey) {
		this.operatorKey = operatorKey;
	}

	public SearchCriteria getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(SearchCriteria searchCriteria) {
		this.searchCriteria = searchCriteria;
	}
	
	public Criteria getContainerCriteria() {
		return containerCriteria;
	}

	public void setContainerCriteria(Criteria containerCriteria) {
		this.containerCriteria = containerCriteria;
	}

	public LogicalOperator getOperatorKey() {
		return operatorKey;
	}

	public boolean offer(LogicalGroupContainer container) {
		return logicalGroupContainerQueue.offer(container);
	}

	public LogicalGroupContainer poll() {
		return logicalGroupContainerQueue.poll();
	}

	public LogicalGroupContainer peek() {
		return logicalGroupContainerQueue.peek();
	}

	public boolean isEmpty() {
		return logicalGroupContainerQueue.isEmpty();
	}
	
	public int size() {
		return logicalGroupContainerQueue.size();
	}

	@Override
	public String toString() {
		return "SearchCriteriaContainer [containerCriteria=" + containerCriteria + ", searchCriteria=" + searchCriteria
				+ ", operatorKey=" + operatorKey + ", logicalGroupContainerQueue=" + logicalGroupContainerQueue + "]";
	}

}
