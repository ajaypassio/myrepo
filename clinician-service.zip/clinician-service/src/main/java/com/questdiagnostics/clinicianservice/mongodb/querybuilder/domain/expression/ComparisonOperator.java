package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression;

public enum ComparisonOperator implements Operator {

	GT("$gt", "gt", Object.class), LT("$lt", "lt", Object.class), GTE("$gte", "gte", Object.class),
	LTE("$lte", "lte", Object.class), IS("$eq", "is", Object.class), NE("$ne", "ne", Object.class), 
	IN("$in", "in", Object[].class), NIN("$nin", "nin", Object[].class);
	
	private String methodName;
	private String opString;
	private Class<?> argClass;
	
	private ComparisonOperator(String opString, String methodName, Class<?> argClass) {
		this.opString = opString;
		this.methodName = methodName;
		this.argClass = argClass;
	}
	
	public String getOpString() {
		return opString;
	}
	
	public String getMethodName() {
		return methodName;
	}
	
	public OperatorType getType() {
		return OperatorType.COMPARISON;
	}
	
	public Class<?> getArgClass() {
		return argClass;
	}

}
