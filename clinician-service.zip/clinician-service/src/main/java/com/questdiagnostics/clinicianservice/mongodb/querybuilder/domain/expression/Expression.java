package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression;

public class Expression {

	private Operand<?> leftOperand;
	private Operator operator;
	private Operand<?> rightOperand;

	public <T, E> Expression(Operand<T> leftOperand, Operator operator, Operand<E> rightOperand) {
		this.leftOperand = leftOperand;
		this.operator = operator;
		this.rightOperand = rightOperand;
	}

	public Operand<?> getLeftOperand() {
		return leftOperand;
	}

	public Operator getOperator() {
		return operator;
	}

	public Operand<?> getRightOperand() {
		return rightOperand;
	}

	@Override
	public String toString() {
		return "Expression [leftOperand=" + leftOperand + ", operator=" + operator.getOpString() + ", rightOperand="
				+ rightOperand + "]";
	}

}
