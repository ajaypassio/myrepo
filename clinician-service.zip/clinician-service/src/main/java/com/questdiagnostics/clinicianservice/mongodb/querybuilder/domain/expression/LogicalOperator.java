package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression;

import org.springframework.data.mongodb.core.query.Criteria;

public enum LogicalOperator implements Operator {
	
	AND("$and", "andOperator", Criteria[].class), OR("$or", "orOperator", Criteria[].class); 
	// not presently not supported, NOT("$not", "not");
	
	private String methodName;
	private String opString;
	private Class<?> argClass;
	
	private LogicalOperator(String opString, String methodName, Class<?> argClass) {
		this.opString = opString;
		this.methodName = methodName;
		this.argClass = argClass;
	}
	
	@Override
	public String getOpString() {
		return opString;
	}

	@Override
	public String getMethodName() {
		return methodName;
	}

	@Override
	public OperatorType getType() {
		return OperatorType.LOGICAL;
	}

	public Class<?> getArgClass() {
		return argClass;
	}
}
