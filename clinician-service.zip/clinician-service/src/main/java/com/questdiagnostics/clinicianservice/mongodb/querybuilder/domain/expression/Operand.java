package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression;

public class Operand<T> {

	private T value;
	
	public Operand(T value) {
		this.value = value;
	}

	public T getValue() {
		return value;
	}
	
	public Class<?> getType() {
		return value.getClass();
	}

	@Override
	public String toString() {
		return "Operand [value=" + value + "]";
	}
	
}
