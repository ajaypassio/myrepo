package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression;

public interface Operator {

	String getMethodName();
	
	String getOpString();
	
	OperatorType getType();
	
	Class<?> getArgClass();
}
