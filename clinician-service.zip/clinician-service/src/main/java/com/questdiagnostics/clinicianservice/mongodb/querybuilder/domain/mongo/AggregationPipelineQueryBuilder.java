package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.mongo;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.SkipOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import com.questdiagnostics.clinicianservice.model.MongoPageRequest;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.ExpressionQueueContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.LogicalGroupContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.SearchCriteriaContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Expression;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Operand;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Operator;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.processor.Processor;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.util.RuntimeHelper;

public abstract class AggregationPipelineQueryBuilder<R> implements PipelineQueryBuilder<R> {

	protected static final ThreadLocal<Queue<AggregationOperation>> aggregationPipelineTL = ThreadLocal.withInitial(LinkedList :: new);
	
	@Autowired
	@Qualifier("fieldProcessor")
	private Processor<String, DocumentField> processor;
	
	@Override
	public List<R> build(Queue<SearchCriteriaContainer> searchCriteriaContainerQ, MongoPageRequest pageRequestData) {
		
		int sCCQSize = searchCriteriaContainerQ.size();
		SearchCriteriaContainer[] arrayCopy = new SearchCriteriaContainer[sCCQSize];
		int i = 0;
		Map<String, AggregationOperation> unwindOperationMap = new TreeMap<>((s1, s2) -> s1.length() - s2.length());		
		while(searchCriteriaContainerQ.peek() != null) {
			arrayCopy[i] = searchCriteriaContainerQ.poll();
			processSearchCriteriaContainer(arrayCopy[i], unwindOperationMap, sCCQSize);
			i++;
		}		
		createGroupsAndProjections(arrayCopy);
		
		return getResult(buildAggregation(pageRequestData));
	}
	
	protected abstract List<R> getResult(Aggregation agg);
	
	private Aggregation buildAggregation(MongoPageRequest pageRequestData) {
		Queue<AggregationOperation> pipeline = addPagination(pageRequestData);
		AggregationOperation[] pipelineArr = pipeline.toArray(new AggregationOperation[pipeline.size()]);
		
		return Aggregation.newAggregation(pipelineArr).
				withOptions((Aggregation.newAggregationOptions().allowDiskUse(true).build()));
	}
	
	private Queue<AggregationOperation> addPagination(MongoPageRequest pagination) {
		Queue<AggregationOperation> pipeline = aggregationPipelineTL.get();
		if(pagination != null) {
			pipeline.add(new SkipOperation((long)(pagination.getPageNumber() * pagination.getPageSize())));
			pipeline.add(new LimitOperation((long)pagination.getPageSize()));
		}
		return pipeline;
	}
	
	protected void cleanUpThreadLocal() {
		aggregationPipelineTL.remove();
	} 
	
	private void processSearchCriteriaContainer(SearchCriteriaContainer searchCriteriaContainer,
			Map<String, AggregationOperation> unwindOperationMap, int searchCriteriaContainerQSize) {
		
		int sCCSize = searchCriteriaContainer.size();
		Queue<Criteria> criteriaQSCC = new LinkedList<>();
		
		boolean processSpecific = processSearchCriteriaContainerSpecific(searchCriteriaContainer, searchCriteriaContainerQSize);
		
		while(searchCriteriaContainer.peek() != null) {
			LogicalGroupContainer groupContainer = searchCriteriaContainer.poll();			
			processLogicalGroupContainer(groupContainer, unwindOperationMap, criteriaQSCC, processSpecific);
		}
		// if only INIT is present no need to add any new criteria
		if(sCCSize == 1) {
			searchCriteriaContainer.setContainerCriteria(criteriaQSCC.poll());
		} else {
			searchCriteriaContainer.setContainerCriteria(createCriteriaForLogicalOp(searchCriteriaContainer.getOperatorKey(), criteriaQSCC));
		}
		// create match operation for each stage
		createMatchOperationForSearchCriteria(searchCriteriaContainer);	
	}
	
	protected abstract boolean processSearchCriteriaContainerSpecific(SearchCriteriaContainer sCC, int sCCQSize);
	
	private void processLogicalGroupContainer(LogicalGroupContainer groupContainer, Map<String, 
			AggregationOperation> unwindOperatioMap, Queue<Criteria> criteriaQSCC, boolean processSpecific) {
		
		Queue<Criteria> criteriaQLGC = new LinkedList<>();
		int gCSize = groupContainer.size();
		
		while(groupContainer.peek() != null) {
			ExpressionQueueContainer expressionQueueContainer = groupContainer.poll();
			processExpressionQueueContainer(expressionQueueContainer, unwindOperatioMap, criteriaQLGC, processSpecific);
		}
		// Only INIT present with only one LGC 
		if(gCSize == 1) {
			groupContainer.setContainerCriteria(criteriaQLGC.poll());
		} else {
			groupContainer.setContainerCriteria(createCriteriaForLogicalOp(groupContainer.getOperatorKey(), criteriaQLGC));
		}
		
		criteriaQSCC.offer(groupContainer.getContainerCriteria());
	}
	
	private void processExpressionQueueContainer(ExpressionQueueContainer expressionQueueContainer,
			Map<String, AggregationOperation> unwindOperationMap, Queue<Criteria> criteriaQLGC, boolean processSpecific) {
		int eQCSize = expressionQueueContainer.size();
		Queue<Criteria> criteriaQEQC = new LinkedList<>();
		
		while(expressionQueueContainer.peek() != null) {
			Expression expression = expressionQueueContainer.poll();
			Operand<?> lOperand = expression.getLeftOperand();
			// 2. find mapped field for each left operand; cache it if not already cached
			// 3. Generate field path for each field
			DocumentField field = processor.process((String)lOperand.getValue(), getDocumentClassName());
			// 4. create unwind operation for each stage (cache path in current thread; avoid duplicate unwinding)
			createUnwindStages(field, unwindOperationMap, processSpecific);
			// 5. build criteria based on queue structure
			createCriteriaForExpression(field, expression, criteriaQEQC);			
		}
		// if only one expression exists, logical Operation is null
		if(eQCSize == 1) {
			expressionQueueContainer.setContainerCriteria(criteriaQEQC.poll());
		} else {
			expressionQueueContainer.setContainerCriteria(createCriteriaForLogicalOp(expressionQueueContainer.getOperatorKey(), criteriaQEQC));
		}
		criteriaQLGC.offer(expressionQueueContainer.getContainerCriteria());
	}
	
	/**
	 * Creates unwind stage(s) and cache it for field path
	 * @param field
	 * @param unwindOperationMap
	 */
	private void createUnwindStages(DocumentField field, Map<String, AggregationOperation> unwindOperationMap, boolean processSpecific) {
		Queue<AggregationOperation> currentPipeline = aggregationPipelineTL.get();
		if(unwindOperationMap.get(field.getPath()) == null) {
			// unwind recursively to the field and add unwind operation to the pipeline only if it doesn't exist in the map
			// check for each parent map in the map - if it exists don't add unwind
			List<String> pathElements = field.getPathElements("\\.");
			String currentPath = pathElements.get(0);
			int size = pathElements.size();
			for(int i = 1; i < size; i++) {
				if(unwindOperationMap.get(currentPath) == null) {
					AggregationOperation unwindOp = Aggregation.unwind(currentPath);
					unwindOperationMap.put(currentPath, unwindOp);
					// add to pipeline					
					currentPipeline.offer(unwindOp);
				}
				currentPath = currentPath + "." + pathElements.get(i);
			}
			AggregationOperation unwindOp = Aggregation.unwind(field.getPath());
			currentPipeline.offer(unwindOp);
			unwindOperationMap.put(field.getPath(), unwindOp);
		} // else do nothing; unwind operation for the path already added.	
		// To be done in subclass
		if(processSpecific)
			unwindSpecific(field, unwindOperationMap, currentPipeline);
				
	}
	
	private void createCriteriaForExpression(DocumentField field, Expression expression, Queue<Criteria> localCriteriaQ) {
		Criteria criteria = new Criteria((String)field.getFullPath());
		try {
			criteria = RuntimeHelper.invokeMethodOnInstance(criteria, expression.getOperator().getMethodName(),
							expression.getRightOperand().getValue(), expression.getOperator().getArgClass());
			//expression.getRightOperand().getValue().getClass()); introduces more tight coupling
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			e.printStackTrace();// change this to use logger and exception handling
		}
		localCriteriaQ.offer(criteria);
	}
	
	private Criteria createCriteriaForLogicalOp(Operator logicalOp, Queue<Criteria> criteriaQ) {
		if(logicalOp == null || criteriaQ == null)
			return null;

		Criteria criteria = new Criteria();
		try {
			criteria = RuntimeHelper.invokeMethodOnInstance(criteria, logicalOp.getMethodName(), 
					criteriaQ.toArray(new Criteria[criteriaQ.size()]), Criteria[].class);
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			e.printStackTrace();
		}
		return criteria;
	}
	
	protected abstract void unwindSpecific(DocumentField field, Map<String, AggregationOperation> unwindOperationMap,
			Queue<AggregationOperation> pipeline);
	
	private void createMatchOperationForSearchCriteria(SearchCriteriaContainer searchCriteriaContainer) {
		// Add to current pipeline
		(aggregationPipelineTL.get()).offer(Aggregation.match(searchCriteriaContainer.getContainerCriteria()));
	}
	
	private void createGroupsAndProjections(SearchCriteriaContainer[] searchCriteriaContainerArr) {
		Queue<AggregationOperation> projectionQ = createSpecific(searchCriteriaContainerArr);
		if(projectionQ != null) {
			while(projectionQ.peek() != null) {
				(aggregationPipelineTL.get()).offer(projectionQ.poll());
			}
		}
	}
	
	protected abstract Queue<AggregationOperation> createSpecific(SearchCriteriaContainer[] searchCriteriaContainerQ);
	
}