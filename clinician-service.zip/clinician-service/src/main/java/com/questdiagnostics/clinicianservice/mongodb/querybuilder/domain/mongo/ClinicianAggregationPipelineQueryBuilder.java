package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.mongo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.ConditionalOperators;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SetOperators.SetIntersection;
import org.springframework.data.mongodb.core.aggregation.SetOperators.SetUnion;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.model.Clinicians;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.SearchCriteriaContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria;

@Component
public class ClinicianAggregationPipelineQueryBuilder extends AggregationPipelineQueryBuilder<Clinicians> {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${mongoQuestCollectionName}")
	private String mongoQuestCollectionName;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	private static final String PATIENTS_PER_RECORD = "patients_per_record";
	private static final String NPI_FIRST_NAME = "first_name";
	private static final String LAST_NAME = "last_name";
	private static final String SOURCE = "source";
	private static final String STATE = "state";
	private static final String ZIP = "zip";
	private static final String PHONE_NUMBER = "phone_number";
	private static final String SPECIALTY = "specialty";
	private static final String EMAIL = "email_address";
	private static final String ADDRESS_1 = "address1";
	private static final String CITY = "city";
	
	private static final String AGE_DATA = "data.age_data";
	private static final String LAB_RESULTS = "data.age_data.lab_results";
	private static final String LAB_TEST_DATA = "data.age_data.lab_results.test_data";
	private static final String LAB_TEST_VALUE = "data.age_data.lab_results.test_data.test_value";
	private static final String DIAG_DATA = "data.age_data.diagnostic_data";
	private static final String DIAG_DISEASE_INFO = "data.age_data.diagnostic_data.disease_info";
	private static final String PATIENTS_DIAG = "data.age_data.diagnostic_data.disease_info.patient_ids";
	private static final String PATIENT_LAB = "data.age_data.lab_results.test_data.test_value.patient_ids";
	private static final String PATIENTS_PER_NPI = "patients_per_npi";
	private static final String DOCUMENT_CLASS_NAME = Clinicians.class.getCanonicalName();
	
	@Override
	protected List<Clinicians> getResult(Aggregation agg) {
		/*
		 * AggregationResults<Clinicians> aggResult = mongoTemplate.aggregate(agg,
		 * mongoQuestCollectionName, Clinicians.class); List<Clinicians> mappRes =
		 * aggResult.getMappedResults(); return mappRes;
		 */
		super.cleanUpThreadLocal();
		logger.info(" builded aggregation : " + agg);
		return (mongoTemplate.aggregate(agg, mongoQuestCollectionName,
				Clinicians.class)).getMappedResults();
	}
	
	@Override
	public String getDocumentClassName() {
		return DOCUMENT_CLASS_NAME;
	}
	
	@Override
	protected void unwindSpecific(DocumentField field, Map<String, AggregationOperation> map,
			Queue<AggregationOperation> pipeline) {	
		String fieldName = field.getName();
		if(fieldName.equalsIgnoreCase("gender") || fieldName.equalsIgnoreCase("age")) {
			if(fieldName.equalsIgnoreCase("gender")) {
				// unwind age data
				map.computeIfAbsent(AGE_DATA, k -> putOpAndAddToPipeline(k, pipeline, false));
			}
			// unwind lab data
			map.computeIfAbsent(LAB_RESULTS, k -> putOpAndAddToPipeline(k, pipeline, true));
			map.computeIfAbsent(LAB_TEST_DATA, k -> putOpAndAddToPipeline(k, pipeline, true));
			map.computeIfAbsent(LAB_TEST_VALUE, k -> putOpAndAddToPipeline(k, pipeline, true));
			// unwind diagnostics data
			map.computeIfAbsent(DIAG_DATA, k -> putOpAndAddToPipeline(k, pipeline, true));
			map.computeIfAbsent(DIAG_DISEASE_INFO, k -> putOpAndAddToPipeline(k, pipeline, true));		
		}
	}
	
	private AggregationOperation putOpAndAddToPipeline(String key, Queue<AggregationOperation> pipeline, boolean preserveNullAndEmptyArray) {
		AggregationOperation aggOp = Aggregation.unwind(key, preserveNullAndEmptyArray);
		pipeline.offer(aggOp);
		return aggOp;
	}
	/**
	 * Unwinding for other search criteria would happen automatically through logic flow but IFF
	 * patient info is present, the unwind path to patient Ids, belonging to both lab data as well as diagnostics data
	 * needs to be done
	 */
	@Override
	protected boolean processSearchCriteriaContainerSpecific(SearchCriteriaContainer sCC, int sCCQSize) {	  
		return ((sCCQSize == 1) && (sCC.getSearchCriteria() == SearchCriteria.PATIENT_INFO));
	}
	
	@Override
	protected Queue<AggregationOperation> createSpecific(SearchCriteriaContainer[] searchCriteriaContainerArr) {
		boolean isLabDataPresent = false;
		boolean isDiagDataPresent = false;
		for(SearchCriteriaContainer container : searchCriteriaContainerArr) {
			SearchCriteria searchCriteria = container.getSearchCriteria();
			switch (searchCriteria) {
			case LAB_DATA: 
				isLabDataPresent = true;
				continue;
			case DIAGNOSTIC_DATA: 
				isDiagDataPresent = true;
				continue;
			default:
				break;
			}
		}
		
		Queue<AggregationOperation> projections = new LinkedList<>();
		createProjectionsForPatientsPerNPI(projections, isLabDataPresent, isDiagDataPresent);
		createGroupOperation(projections);
		createFinalProjection(projections);
		
		return projections;	
	}
	
	private void createProjectionsForPatientsPerNPI(Queue<AggregationOperation> projections, boolean isLabDataPresent, boolean isDiagDataPresent) {
		ProjectionOperation projectPatientsPerNPI = Aggregation
			.project("npi", NPI_FIRST_NAME, LAST_NAME, SOURCE, STATE, ZIP, CITY, ADDRESS_1, EMAIL, PHONE_NUMBER, SPECIALTY);
		 List<String> emptyList = new ArrayList<String>();
		if(isLabDataPresent && isDiagDataPresent) {
			projectPatientsPerNPI = 
					projectPatientsPerNPI.and(SetIntersection.arrayAsSet(ConditionalOperators .ifNull(PATIENT_LAB).then(emptyList)).intersects(ConditionalOperators .ifNull(PATIENTS_DIAG).then(emptyList))).as(PATIENTS_PER_RECORD);
		} else if(isLabDataPresent) {
			projectPatientsPerNPI = projectPatientsPerNPI.and(ConditionalOperators .ifNull(PATIENT_LAB).then(emptyList)).as(PATIENTS_PER_RECORD);
		} else if (isDiagDataPresent) {
			projectPatientsPerNPI = projectPatientsPerNPI.and(ConditionalOperators .ifNull(PATIENTS_DIAG).then(emptyList)).as(PATIENTS_PER_RECORD);
		} else {
			projectPatientsPerNPI = 
					projectPatientsPerNPI.and(SetUnion.arrayAsSet(ConditionalOperators .ifNull(PATIENT_LAB).then(emptyList)).union(ConditionalOperators .ifNull(PATIENTS_DIAG).then(emptyList))).as(PATIENTS_PER_RECORD);
		}
		AggregationOperation unwindPatientsPerNPI = Aggregation.unwind(PATIENTS_PER_RECORD);
		projections.offer(projectPatientsPerNPI);
		projections.offer(unwindPatientsPerNPI);
	}
	
	private void createGroupOperation(Queue<AggregationOperation> projections) {
		GroupOperation groupOperationOne = Aggregation
				.group("npi", NPI_FIRST_NAME, LAST_NAME, SOURCE, STATE, ZIP, CITY, ADDRESS_1, EMAIL, PHONE_NUMBER, SPECIALTY).addToSet(PATIENTS_PER_RECORD).as(PATIENTS_PER_NPI);
		projections.offer(groupOperationOne);
	}
	
	private void createFinalProjection(Queue<AggregationOperation> projections) {
		ProjectionOperation projection = Aggregation
				.project("npi", NPI_FIRST_NAME, LAST_NAME, SOURCE, STATE, ZIP, CITY, ADDRESS_1, EMAIL, PHONE_NUMBER, SPECIALTY)
				.andExclude("_id").and(PATIENTS_PER_NPI).size().as("noOfPatients");
		projections.offer(projection);
	}
	
	public List<Clinicians> getFilteredCliniciansForQuest() {
		UnwindOperation unwindOp1 = Aggregation.unwind("data");
		UnwindOperation unwindOp2 = Aggregation.unwind("data.age_data");
		
		/*
		 * {$unwind: "$data.age_data.diagnostic_data"}, 
		 * {$unwind: "$data.age_data.diagnostic_data.disease_info"}, 
		 * {$match: {$and:[{"data.age_data.diagnostic_data.standard": "ICD"},
		 * {"data.age_data.diagnostic_data.version":"9"},
		 * {"data.age_data.diagnostic_data.disease_info.code":"I10"}]}},
		 */
		UnwindOperation unwindOp2_2 = Aggregation.unwind("data.age_data.diagnostic_data");
		UnwindOperation unwindOp2_3 = Aggregation.unwind("data.age_data.diagnostic_data.disease_info");
		Criteria andOp = new Criteria().andOperator(new Criteria("data.age_data.diagnostic_data.standard").is("ICD"),
				new Criteria("data.age_data.diagnostic_data.version").is("9"), 
				new Criteria("data.age_data.diagnostic_data.disease_info.code").is("I10"));
		MatchOperation matchOp0 = Aggregation.match(andOp);
		
		UnwindOperation unwindOp3 = Aggregation.unwind("data.age_data.lab_results");
		
		MatchOperation matchOp1 = Aggregation.match(new Criteria("data.age_data.lab_results.fasting").is("Y"));
		
		UnwindOperation unwindOp4 = Aggregation.unwind("data.age_data.lab_results.test_data");
		UnwindOperation unwindOp5 = Aggregation.unwind("data.age_data.lab_results.test_data.test_value");//criteriaChain.add(new)
		Criteria orOperation = new Criteria(); 
		//orOperation.orOperator(new Criteria().andOperator(criteria))
		Criteria andOp1 = new Criteria().andOperator(new Criteria("data.age_data.lab_results.test_data.test_name").is("ldl"),
				new Criteria("data.age_data.lab_results.test_data.test_value.value").lt(Integer.valueOf(140)));		
		Criteria andOp2 = new Criteria().andOperator(new Criteria("data.age_data.lab_results.test_data.test_name").is("hdl"),
				new Criteria("data.age_data.lab_results.test_data.test_value.value").gt(Integer.valueOf(40)));
		orOperation.orOperator(andOp1, andOp2);		
		MatchOperation matchOp2 = Aggregation.match(orOperation);
		
		ProjectionOperation projectStageOne = Aggregation
				.project("npi", "first_name", "last_name", "source", "zip", "state", "specialty", "phone_number")
				.and(SetIntersection.arrayAsSet(PATIENT_LAB).intersects(PATIENTS_DIAG)).as(PATIENTS_PER_RECORD);

		UnwindOperation unwindStageFive = Aggregation.unwind(PATIENTS_PER_RECORD);
		GroupOperation groupOperationOne = Aggregation
				.group("npi", "first_name", "last_name", "source", "zip", "state", "specialty", "phone_number")
				.addToSet(PATIENTS_PER_RECORD).as(PATIENTS_PER_NPI);

		ProjectionOperation projectStageTwo = Aggregation
				.project("npi", "first_name", "last_name", "source", "zip", "state", "specialty", "phone_number")
				.andExclude("_id").and(PATIENTS_PER_NPI).size().as("noOfPatients");

		/*SortOperation sortByNpiFirstname = Aggregation.sort(Direction.ASC, "first_name", "last_name", "npi", "source",
				"specialty", "state");*/
		
		Aggregation aggregation = Aggregation
				.newAggregation(unwindOp1, unwindOp2, unwindOp3, matchOp1, unwindOp4, unwindOp5, matchOp2, unwindOp2_2, unwindOp2_3,
						matchOp0, projectStageOne, unwindStageFive, groupOperationOne, projectStageTwo)
				.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());

		AggregationResults<Clinicians> output = mongoTemplate.aggregate(aggregation, mongoQuestCollectionName,
				Clinicians.class);

		List<Clinicians> clinicianList = output.getMappedResults();

		return clinicianList;
		
	}

}
