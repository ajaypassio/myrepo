package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.mongo;

import java.util.Arrays;
import java.util.List;

public class DocumentField {
	
	private String name;
	private String path;
	private List<String> pathElements;
	private String fullPath;

	public DocumentField(String name, String path) {
		this.name = name;
		this.path = path;
		this.fullPath = path + "." + name;
	}

	public String getPath() {
		return path;
	}
	
	public String getName() {
		return name;
	}

	public String getFullPath() {
		return fullPath;
	}

	public List<String> getPathElements(String splitter) {
		return Arrays.asList(path.split(splitter));
	}
	
	public int getPathElementsSize() {
		return pathElements == null ? 0 : pathElements.size();
	}

	@Override
	public String toString() {
		return "DocumentField [name=" + name + ", path=" + path + ", pathElements=" + pathElements + ", fullPath="
				+ fullPath + "]";
	}
}
