package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.mongo;

import java.util.List;
import java.util.Queue;

import com.questdiagnostics.clinicianservice.model.MongoPageRequest;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.SearchCriteriaContainer;

public interface PipelineQueryBuilder<R> {

	List<R> build(Queue<SearchCriteriaContainer> searchCriteriaContainerQ, MongoPageRequest pageRequestData);
	
	String getDocumentClassName();
}