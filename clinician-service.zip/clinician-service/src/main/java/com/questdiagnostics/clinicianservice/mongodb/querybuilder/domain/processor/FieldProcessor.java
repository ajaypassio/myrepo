package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.processor;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.mongo.DocumentField;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.util.RuntimeHelper;

@Service("fieldProcessor")
public class FieldProcessor implements Processor<String, DocumentField> {

	private final Map<String, DocumentField> documentFieldCache = new ConcurrentHashMap<>();
	
	@Override
	public DocumentField process(String arg, String className) {
		String field = SearchCriteria.getFieldName(arg);
		DocumentField docField = documentFieldCache.get(field);
		if(docField == null) {
			docField = new DocumentField(field , getFieldPath(field, className));
			documentFieldCache.put(arg, docField);
		}
		return docField;
	}
	
	private String getFieldPath(String field, String className) {		
		try {
			return RuntimeHelper.getFieldPath(field, className);
		} catch (IllegalAccessException | InvocationTargetException | ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}		
	}
	
	public DocumentField getDocumentField(String key) {
		return documentFieldCache.get(key);
	}

}
