package com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.processor;

public interface Processor<T, R> {
	
	R process(T arg, String className);
}
