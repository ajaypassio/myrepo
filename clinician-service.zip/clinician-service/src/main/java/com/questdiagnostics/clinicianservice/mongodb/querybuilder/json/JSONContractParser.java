package com.questdiagnostics.clinicianservice.mongodb.querybuilder.json;

import static com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria.LAB_DATA;
import static com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.JSONContractParserHelper.getSearchCriteriaContainer;
import static com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria.DIAGNOSTIC_DATA;
import static com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria.PATIENT_INFO;

import java.util.LinkedList;
import java.util.Queue;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.SearchCriteriaContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.exception.InputValidationException;

@Component
public class JSONContractParser {


	public Queue<SearchCriteriaContainer> transformJSONInput(JsonNode rootNode) throws InputValidationException {
		// get a queue based on different search criteria
		Queue<SearchCriteriaContainer> searchCriteriaContainerQ = new LinkedList<>();
		
		JsonNode patientInfoNode = rootNode.get(PATIENT_INFO.getElementName());
		
		// Implicit AND operator exists among the search criteria; none for the last criterion
		// AND/OR combinations to be performed in future releases
		if(patientInfoNode != null && !patientInfoNode.isNull() && !patientInfoNode.toString().equals("{}")) {
			searchCriteriaContainerQ.offer(getSearchCriteriaContainer(PATIENT_INFO, patientInfoNode, true));
		}

		JsonNode labTestNode = rootNode.get(LAB_DATA.getElementName());
		if(labTestNode != null && !labTestNode.isNull() && !labTestNode.toString().equals("{}")) {
			searchCriteriaContainerQ.offer(getSearchCriteriaContainer(LAB_DATA, labTestNode, false));
		}
		
		JsonNode diagInfoNode = rootNode.get(DIAGNOSTIC_DATA.getElementName());
		if(diagInfoNode != null && !diagInfoNode.isNull() && !diagInfoNode.toString().equals("{}")) {
			searchCriteriaContainerQ.offer(getSearchCriteriaContainer(DIAGNOSTIC_DATA, diagInfoNode, false));
		}

		return searchCriteriaContainerQ;
	}

}
