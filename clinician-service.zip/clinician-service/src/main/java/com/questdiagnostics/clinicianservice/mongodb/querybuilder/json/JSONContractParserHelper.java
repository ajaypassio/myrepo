package com.questdiagnostics.clinicianservice.mongodb.querybuilder.json;

import static com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria.INIT;
import static com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.SearchCriteria.OR;

import java.util.Iterator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.DoubleNode;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.node.LongNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.ExpressionQueueContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.LogicalGroupContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.container.SearchCriteriaContainer;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.ComparisonOperator;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Expression;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.LogicalOperator;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Operand;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.domain.expression.Operator;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.json.exception.InputValidationException;
import com.questdiagnostics.clinicianservice.mongodb.querybuilder.validator.InputValidator;

public class JSONContractParserHelper {

	private JSONContractParserHelper() {
		throw new UnsupportedOperationException("instantiation not allowed.");
	}

	public static SearchCriteriaContainer getSearchCriteriaContainer(SearchCriteria searchCriteria, JsonNode node, boolean initGroupOnly) 
			throws InputValidationException {
		SearchCriteriaContainer searchCriteriaContainer = new SearchCriteriaContainer(searchCriteria);
		if(node != null && node.fieldNames().hasNext()) {
			Iterator<String> itr = node.fieldNames();
			while(itr.hasNext()) {
				String currentField = itr.next();
				// Get LogicalGroupContainers having ExpressionQueueContainers
				if(currentField.equalsIgnoreCase(INIT.getElementName())) {
					JsonNode andGroup = node.get(currentField);
					if(andGroup != null && andGroup.isArray() && andGroup.size() > 0) {
						searchCriteriaContainer.offer(getLogicalContainer(andGroup, LogicalOperator.AND));
					}
				}
				if(!initGroupOnly && currentField.toUpperCase().contains(OR.getElementName().toUpperCase())) {
					JsonNode orGroup = node.get(currentField);
					if(orGroup != null && orGroup.isArray() && orGroup.size() > 0) {
						searchCriteriaContainer.offer(getLogicalContainer(orGroup, LogicalOperator.AND));
					}
				}
			}
		}
		// check for base cases
		if(searchCriteriaContainer.size() == 1) {
			// if only INIT is present
			searchCriteriaContainer.setOperatorKey(null);
			// if INIT has only one LGC
			if(searchCriteriaContainer.peek().size() == 1) {
				LogicalGroupContainer lGC = searchCriteriaContainer.poll();
				// if EQC has only one expression
				if(lGC.peek().size() == 1) {
					ExpressionQueueContainer eQC = lGC.poll();
					eQC.setOperatorKey(null);
					lGC.offer(eQC);
				}
				lGC.setOperatorKey(null);
				searchCriteriaContainer.offer(lGC);
			}
		} else {
			searchCriteriaContainer.setOperatorKey(LogicalOperator.OR);
		}
		return searchCriteriaContainer;
	}
	
	private static LogicalGroupContainer getLogicalContainer(JsonNode node,
			LogicalOperator logicalContainerOp) throws InputValidationException {
		// First AND/OR container with nested ANDed containers
		LogicalGroupContainer outerContainer = new LogicalGroupContainer(logicalContainerOp);
		for (int i = 0; i < node.size(); i++) {						
			outerContainer.offer(getExpressionQueueContainer(node, i));
		}
		return outerContainer;
	}
	
	private static ExpressionQueueContainer getExpressionQueueContainer(JsonNode node, int index) throws InputValidationException {
		ExpressionQueueContainer expressionQueueContainer = null;
		JsonNode currentNode = node.get(index);
		if (currentNode != null) {
			// Each expression element of the queue is linked to neighboring element using AND operator
			expressionQueueContainer = new ExpressionQueueContainer(LogicalOperator.AND);
			Iterator<String> fieldNames = currentNode.fieldNames();
			// 1. get key value pair
			// 2. split key using splitter and create expression matching the operator
			while (fieldNames.hasNext()) {
				String field = fieldNames.next();
				InputValidator.validateField(field);
				String[] lhStrings = field.split("_");
				if(SearchCriteria.isField(lhStrings[0])) {
					Operator operator = getOperator(lhStrings);
					boolean isRHOArr = isRHOperandAnArray(operator);
					Expression exp = new Expression(getLHOperand(lhStrings[0]), operator,
							getRHOperand(currentNode.get(field), isRHOArr, isNumericOperation(operator)));
					expressionQueueContainer.offer(exp);
				}
			}
		}
		return expressionQueueContainer;
	}
	
	private static boolean isRHOperandAnArray(Operator op) {
		if(op instanceof ComparisonOperator) {
			return op == ComparisonOperator.IN ;						
		}
		return false;
	}
	
	private static boolean isNumericOperation(Operator op) {
		if(op instanceof ComparisonOperator) {
			return (op == ComparisonOperator.GT || op == ComparisonOperator.GTE
					|| op == ComparisonOperator.LT || op == ComparisonOperator.LTE);
		}
		return false;
	}
	
	private static Operand<String> getLHOperand(String value) {
		return new Operand<>(value);
	}

	private static Operator getOperator(String[] fields) {
		// default operation
		if (fields.length == 1) {
			return ComparisonOperator.IS;
		}
		return ComparisonOperator.valueOf(fields[1].toUpperCase());
	}

	private static Operand<?> getRHOperand(JsonNode value, boolean isArray, boolean isValueNumeric) throws InputValidationException {
		Class<?> valueClass = value.getClass();
		Operand<?> operand = null;
		Object val = null;
		Object[] valArr = null;
		// validate value for allowed characters
		if (valueClass == IntNode.class) {
			InputValidator.validateValue(Integer.valueOf(value.asInt()));
			val = Integer.valueOf(value.asInt());
		}
		if (valueClass == LongNode.class) {
			InputValidator.validateValue(Long.valueOf(value.asLong()));
			val = Long.valueOf(value.asLong());
		}
		if (valueClass == DoubleNode.class) {
			InputValidator.validateValue(Double.valueOf(value.asDouble()));
			val = Double.valueOf(value.asDouble());
		}
		if (valueClass == TextNode.class) {
			String str = value.asText();
			InputValidator.validateValue(str);
			if(str.contains(",")) {
				valArr = value.asText().split(",");
			} else if (isArray) {
				valArr = new Object[] {value.asText()};
			} else {
				val = value.asText();
				if(isValueNumeric && InputValidator.isNumber(value.asText())) {
					try {
						val = Double.valueOf(Double.parseDouble(value.asText()));
					} catch(NumberFormatException e) {
						// do-nothing
					}
				}
			}
		}
		
		operand = valArr == null ? new Operand<>(val) : new Operand<>(valArr);
		return operand;
	}
}
