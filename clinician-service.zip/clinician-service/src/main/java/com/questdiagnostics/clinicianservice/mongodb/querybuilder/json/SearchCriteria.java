package com.questdiagnostics.clinicianservice.mongodb.querybuilder.json;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public enum SearchCriteria {

	PATIENT_INFO("patientInfo"), INIT("init"), AND("And"), OR("Or"), LAB_DATA("labTest"), DIAGNOSTIC_DATA("dignosticsInfo");
	
	private String elementName;
	
	private static final Map<String, String> fieldMap = new ConcurrentHashMap<>();
	
	private SearchCriteria(String elementName) {
		this.elementName = elementName;
	}

	public String getElementName() {
		return elementName;
	}
	
	public static String getFieldName(String key) {
		if(fieldMap.isEmpty()) {
			initializeFieldMap();
		}
		return fieldMap.get(key);
	}
	
	/**
	 * Maps ui field name to mongodb document field name
	 */
	private static void initializeFieldMap() {
		fieldMap.put("age", "age");
		fieldMap.put("gender", "gender");
		fieldMap.put("name", "test_name");
		fieldMap.put("value", "value");
		fieldMap.put("fasting", "fasting");
		fieldMap.put("icdCode", "code");
		fieldMap.put("icdCodeSet", "version");
		fieldMap.put("unit", "unit");
	}

	public static boolean isField(String str) {
		if(fieldMap.isEmpty()) {
			initializeFieldMap();
		}
		return fieldMap.containsKey(str);
	}
}
