package com.questdiagnostics.clinicianservice.mongodb.querybuilder.util;

public class Node<T> {

	private Node<T> parent;
	
	private T data;
	
	private boolean isDeadEnd; // leaf-node not on path
	
	private boolean isOnPath; // leaf/intermediate node on path
	
	public Node(Node<T> parent, T data) {
		this.parent = parent;
		this.data = data;
	}

	public Node<T> getParent() {
		return parent;
	}

	public T getData() {
		return data;
	}
	
	public boolean isDeadEnd() {
		return isDeadEnd;
	}

	public void setDeadEnd(boolean isDeadEnd) {
		this.isDeadEnd = isDeadEnd;
	}

	public boolean isOnPath() {
		return isOnPath;
	}

	public void setOnPath(boolean isOnPath) {
		this.isOnPath = isOnPath;
		if(parent != null) {
			parent.setOnPath(isOnPath);
		}
	}	
}
