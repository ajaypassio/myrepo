package com.questdiagnostics.clinicianservice.outreach.campaign;

import static com.questdiagnostics.clinicianservice.enums.PhysicianCampaignStatusEnums.Creation_Failed;
import static com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums.CampaignCreationCompleted;
import static com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums.CampaignCreationFailed;
import static com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums.CampaignCreationInitiated;
import static com.questdiagnostics.clinicianservice.enums.PhysicianOutreachStatus.NotEligible;
import static com.questdiagnostics.clinicianservice.enums.PhysicianOutreachStatus.OutreachPending;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignStatusEnums;
import com.questdiagnostics.clinicianservice.messaging.util.PhysicianCommonUtil;
import com.questdiagnostics.clinicianservice.model.CampaignBatchData;
import com.questdiagnostics.clinicianservice.model.CurrentStatus;
import com.questdiagnostics.clinicianservice.model.DisplayCampaignRecord;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;
import com.questdiagnostics.clinicianservice.model.PhysicianData;
import com.questdiagnostics.clinicianservice.model.PhysicianUpdateCampaignRequest;
import com.questdiagnostics.clinicianservice.model.ViewHistory;

@Component
public class PhysicianCampaignProcessor {

	private static final Logger logger = LoggerFactory.getLogger(PhysicianCampaignProcessor.class);

	@Autowired
	private MongoTemplate template;

	@Autowired
	private PhysicianCommonUtil physicianCommonUtil;

	public boolean createCampaign(String userName, Long sprinttCampaignId, boolean source, String speciality,
			String state) throws Exception {
		String searchCollectionName = userName + "_physician";
		logger.info(
				"Received create campaign msg for sprinttCampaignId: {} for collection: {} with source: {}, speciality: {}, and state: {}",
				sprinttCampaignId, searchCollectionName, source, speciality, state);
		boolean created = false;
		String campaignCollection = physicianCommonUtil.buildCollection(userName, sprinttCampaignId,
				CommonConstant.CAMPAIGN_COL_SUFFIX);
		String campaignBatchJobCollection = physicianCommonUtil.buildCollection(userName, sprinttCampaignId,
				CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX);
		Query campaignJobStatusQuery = new Query(Criteria.where("campaignId").is(sprinttCampaignId));
		try {
			if (!StringUtils.isEmpty(searchCollectionName)) {
				Criteria criteria = getCriteria(source, speciality, state);
				Query query = new Query(criteria);
				List<PhysicianData> physicianDataList = template.find(query, PhysicianData.class, searchCollectionName);
				logger.info("The returned List value :"+ physicianDataList.size());
				
				// construct campaign POJOs
				if (!physicianDataList.isEmpty()) {
					// insert campaign job status as initiated
					if (template.collectionExists(campaignBatchJobCollection)) {
						upsertCampaignJobStatus(CampaignCreationInitiated, CampaignBatchData.class,
								campaignJobStatusQuery, campaignBatchJobCollection);
					} else {
						insertCampaignJobStatus(CampaignCreationInitiated, sprinttCampaignId,
								campaignBatchJobCollection);
					}

					List<PhysicianCampaignData> physicianCampaignList = physicianDataList.stream()
							.map(physicianData -> {
								PhysicianCampaignData campaignData = new PhysicianCampaignData();
								campaignData.setNpi(physicianData.getNpi());
								campaignData.setExportRecord(physicianData.getExportRecord());
								DisplayCampaignRecord displayCampaignRecord = new DisplayCampaignRecord();
								displayCampaignRecord.setNpi(physicianData.getNpi());
								displayCampaignRecord.setFirst_name(physicianData.getDisplayRecord().getFirst_name());
								displayCampaignRecord.setLast_name(physicianData.getDisplayRecord().getLast_name());
								displayCampaignRecord.setIsSelected(0);
								CurrentStatus currentStatus = new CurrentStatus();
								currentStatus.setDm(physicianData.getHasAddress().equalsIgnoreCase("yes")
										? OutreachPending.getValue()
										: NotEligible.getValue());
								currentStatus.setEm(
										physicianData.getHasEmail().equalsIgnoreCase("yes") ? OutreachPending.getValue()
												: NotEligible.getValue());
								currentStatus.setPc(physicianData.getHasPhoneNo().equalsIgnoreCase("yes")
										? OutreachPending.getValue()
										: NotEligible.getValue());
								displayCampaignRecord.setCurrentStatus(currentStatus);
								campaignData.setDisplayCampaignRecord(displayCampaignRecord);
								campaignData.setViewHistories(new ArrayList<ViewHistory>());
								return campaignData;
							}).collect(Collectors.toList());
					if (template.collectionExists(campaignCollection)) {
						template.dropCollection(campaignCollection);
					}
					template.createCollection(campaignCollection);
					template.insert(physicianCampaignList, campaignCollection);
					logger.info("Created campaign collection {}", campaignCollection);

					// update campaign job status as completed
					upsertCampaignJobStatus(CampaignCreationCompleted, CampaignBatchData.class, campaignJobStatusQuery,
							campaignBatchJobCollection);
					logger.info("Update campaign batch collection {} with status {}", campaignBatchJobCollection,
							CampaignCreationCompleted.getValue());
					created = true;
				} else {
					logger.info(
							"Campaign not created as physician list for collection: {} with source: {}, speciality: {}, and state: {} is empty",
							searchCollectionName, source, speciality, state);
					created = false;
				}
			}
		} catch (Exception e) {
			logger.error(
					"Caught exception {} while creating campaign for sprinttCampaignId: {} and collection: {} with source: {}, speciality: {}, and state: {}",
					sprinttCampaignId, searchCollectionName, source, speciality, state);
			if (template.collectionExists(campaignBatchJobCollection)) {
				// update campaign job status as failed
				upsertCampaignJobStatus(CampaignCreationFailed, CampaignBatchData.class, campaignJobStatusQuery,
						campaignBatchJobCollection);
				logger.info("Update campaign batch collection {} with status {}", campaignBatchJobCollection,
						CampaignCreationFailed.getValue());
				updateCampaignStatus(sprinttCampaignId, Creation_Failed);
			}
			created = false;
		}
		return created;
	}

	private boolean updateCampaignStatus(long sprinttCampaignId, PhysicianCampaignStatusEnums status) throws Exception {
		PhysicianUpdateCampaignRequest physicianUpdateCampaignRequest = new PhysicianUpdateCampaignRequest();
		physicianUpdateCampaignRequest.setSprinttCampaignId(sprinttCampaignId);
		physicianUpdateCampaignRequest.setCampaignStatusId(status.getValue());
		physicianCommonUtil.updatePhysicianCampaignStatus(physicianUpdateCampaignRequest);
		return true;
	}

	/**
	 * Preparing the criteria for the data grid query
	 */
	private Criteria getCriteria(boolean source, String speciality, String state) {
		Criteria criteria = null;
		Criteria criteriaSpecialtyAndState = new Criteria();

		if (source) {
			criteria = Criteria.where("isBmis").is(CommonConstant.TRUE);
		} else {
			criteria = Criteria.where("isBmis").is(CommonConstant.FALSE);
		}

		if (!StringUtils.isEmpty(speciality)) {
			criteriaSpecialtyAndState = Criteria.where("displayRecord.specialty").in(speciality.split("_"));
		}
		
		if (!StringUtils.isEmpty(state)) {
			criteriaSpecialtyAndState.andOperator(Criteria.where("displayRecord.state").in(state.split(",")));
		}

		if (!StringUtils.isEmpty(criteria))
			criteria = criteria.andOperator(criteriaSpecialtyAndState);
		else
			criteria = criteriaSpecialtyAndState;
		return criteria;
		/*Criteria criteria = null;
		Criteria criteria1 = new Criteria();
		if (source) {
			criteria = Criteria.where("isBmis").is(CommonConstant.TRUE);
		} else {
			criteria = Criteria.where("isBmis").is(CommonConstant.FALSE);
		}

		if (!StringUtils.isEmpty(speciality)) {
			criteria1 = Criteria.where("displayRecord.specialty").in(speciality.split(","));
		}

		if (!StringUtils.isEmpty(state)) {
			criteria1.andOperator(Criteria.where("displayRecord.state").in(state.split(",")));
		}
		criteria = criteria.andOperator(criteria1);
		return criteria;*/
	}

	public PhysicianCampaignProcessor(MongoTemplate template) {
		this.template = template;
	}

	private void insertCampaignJobStatus(PhysicianCampaignJobStatusEnums campaignJobStatus, Long sprinttCampaignId,
			String collectionName) {
		CampaignBatchData batchData = new CampaignBatchData();
		batchData.setCampaignId((int) ((long) sprinttCampaignId));
		batchData.setCampaignJobStatus(campaignJobStatus.getValue());
		batchData.setImportURI(CommonConstant.EMPTY_STRING);
		batchData.setExportURI(CommonConstant.EMPTY_STRING);
		batchData.setExportSyncURI(CommonConstant.EMPTY_STRING);
		batchData.setImportSyncURI(CommonConstant.EMPTY_STRING);
		template.insert(batchData, collectionName);
	}

	private void upsertCampaignJobStatus(PhysicianCampaignJobStatusEnums campaignJobStatus, Class<?> entityClass,
			Query query, String collectionName) {
		Update update = new Update();
		update.set("campaignJobStatus", campaignJobStatus.getValue());
		template.upsert(query, update, entityClass, collectionName);
	}

	private static class CampaignJobStatus implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		private String campaignJobStatus;

		private String createdOn;

		public CampaignJobStatus(String status) {
			this.campaignJobStatus = status;
			setCreatedOn();
		}

		public String getStatus() {
			return campaignJobStatus;
		}

		@JsonProperty("campaignJobStatus")
		public void setCampaignJobStatus(String status) {
			this.campaignJobStatus = status;
		}

		public String getCreatedOn() {
			return createdOn;
		}

		@JsonProperty("createdOn")
		public void setCreatedOn() {
			this.createdOn = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		}

	}
}
