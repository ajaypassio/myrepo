package com.questdiagnostics.clinicianservice.outreach.messaging;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.questdiagnostics.clinicianservice.model.NotificationPayload;

@Component
public class NotificationPublisher {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${notification.sprintt.azure.storage.queuename}")
	String notificationQueueName;
	
	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureAccountName;

	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureAccountKey;
	
	
	private String getStorageConnectionString() {
		return "DefaultEndpointsProtocol=https;" + "AccountName=" + azureAccountName + ";AccountKey=" + azureAccountKey
				+ ";" + "EndpointSuffix=core.windows.net";

	}

	public void publishNotification(NotificationPayload notificationPayload) {
		logger.info("Notification started for the Physician Campaign name:{} and user: {} ", notificationPayload.getName(),
				notificationPayload.getUserid());
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		try {
			storageAccount = CloudStorageAccount.parse(getStorageConnectionString());
			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(notificationQueueName);
			queue.createIfNotExists();
			ObjectMapper mapper = new ObjectMapper();
			queue.addMessage(new CloudQueueMessage(mapper.writeValueAsString(notificationPayload)));
			logger.info("Notification completed for the Physician Campaign name:{} and user: {} ", notificationPayload.getName(),
					notificationPayload.getUserid());
		} catch (URISyntaxException | StorageException | InvalidKeyException | JsonProcessingException exception) {
			logger.error("Notification processing failed : {} ", exception);
		}
	}
}
