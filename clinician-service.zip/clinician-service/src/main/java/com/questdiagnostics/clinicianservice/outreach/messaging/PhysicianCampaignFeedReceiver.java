package com.questdiagnostics.clinicianservice.outreach.messaging;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignStatusEnums;
import com.questdiagnostics.clinicianservice.messaging.util.PhysicianCommonUtil;
import com.questdiagnostics.clinicianservice.model.NotificationPayload;
import com.questdiagnostics.clinicianservice.outreach.campaign.PhysicianCampaignProcessor;

@Component
public class PhysicianCampaignFeedReceiver {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	static final Gson GSON = new Gson();

	private Boolean isProcessing = Boolean.FALSE;

	@Value("${sprintt.azure.storage.queueName}")
	private String queueName;

	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureAccountNameCampaignFeed;

	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureAccountKeyCampaignFeed;

	private PhysicianCampaignProcessor physicianCampaignProcessor;

	@Autowired
	public PhysicianCampaignFeedReceiver(PhysicianCampaignProcessor physicianCampaignProcessor) {
		this.physicianCampaignProcessor = physicianCampaignProcessor;
	}

	@Autowired
	PhysicianCommonUtil physicianCommonUtil;
    
	@Autowired
	NotificationPublisher notificationPublisher;

	public String getStorageConnectionStringcsvFeedReciever() {
		String storageConnectionString = "DefaultEndpointsProtocol=https;" + "AccountName="
				+ azureAccountNameCampaignFeed + ";AccountKey=" + azureAccountKeyCampaignFeed + ";"
				+ "EndpointSuffix=core.windows.net";

		return storageConnectionString;
	}

	@Scheduled(fixedDelayString = "${scheduler.physician.campaign.creation}")
	public void processCampaignMsg() {
		logger.info("Receive campaign message started----");
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		if (Boolean.FALSE.equals(isProcessing)) {
			PhysicianCampaignMsg msg = null;
			try {
				storageAccount = CloudStorageAccount.parse(getStorageConnectionStringcsvFeedReciever());
				queueClient = storageAccount.createCloudQueueClient();
				queue = queueClient.getQueueReference(queueName);
				queue.createIfNotExists();
				Iterable<CloudQueueMessage> listOfMessages = queue.retrieveMessages(1);
				for (CloudQueueMessage peekedMessage : listOfMessages) {
					byte[] body = peekedMessage.getMessageContentAsByte();
					msg = GSON.fromJson(new String(body, StandardCharsets.UTF_8), PhysicianCampaignMsg.class);
					logger.info("Consumed physician campaign msg with username: {} and SprinttCampaignId: {}",
							msg.getUserName(), msg.getSprinttCampaignId());

					isProcessing = Boolean.TRUE;
					// create campaign collection from search collection
					physicianCommonUtil.updateCampaignStatus(msg.getSprinttCampaignId(),
							PhysicianCampaignStatusEnums.Creation_Initiated.getValue());
					physicianCampaignProcessor.createCampaign(msg.getUserName(), msg.getSprinttCampaignId(),
							msg.getSource(), msg.getSpeciality(), msg.getState());
					// update the campaign status campaign creation completed
					physicianCommonUtil.updateCampaignStatus(msg.getSprinttCampaignId(),
							PhysicianCampaignStatusEnums.Creation_Completed.getValue());
					queue.deleteMessage(peekedMessage);
					//Notification producer : message for Physician List-Success
					publishNotification(msg, "Physician List-Success");
				}
			} catch (Exception e) {
				logger.error(
						"Processing failed while reading and processing physician campaign message from queue: {} ", e);
				if (!ObjectUtils.isEmpty(msg) && msg.getSprinttCampaignId() > 0) {
					physicianCommonUtil.updateCampaignStatus(msg.getSprinttCampaignId(),
							PhysicianCampaignStatusEnums.Creation_Failed.getValue());
					//Notification producer : message for Patient List-Failure
					publishNotification(msg, "Physician List-Failure");
				}
			} finally {
				isProcessing = Boolean.FALSE;
			}
		}
	}
	
	private void publishNotification(PhysicianCampaignMsg physicianCampaignMsg, String eventName){
		NotificationPayload notificationPayload = new NotificationPayload();
		notificationPayload.setId(physicianCampaignMsg.getSprinttCampaignId());
		notificationPayload.setName(physicianCampaignMsg.getCampaignName());
		notificationPayload.setEventName(eventName);
		notificationPayload.setUserid(physicianCampaignMsg.getUserName());
		notificationPublisher.publishNotification(notificationPayload);
	}

	private static class PhysicianCampaignMsg implements Serializable {

		private static final long serialVersionUID = -1L;

		private String userName;

		private Long sprinttCampaignId;

		private boolean source;

		private String speciality;

		private String state;
		
		private String campaignName;

		public String getUserName() {
			return userName;
		}

		@JsonProperty("userName")
		public void setUserName(String userName) {
			this.userName = userName;
		}

		public Long getSprinttCampaignId() {
			return sprinttCampaignId;
		}

		@JsonProperty("sprinttCampaignId")
		public void setSprinttCampaignId(Long sprinttCampaignId) {
			this.sprinttCampaignId = sprinttCampaignId;
		}

		public boolean getSource() {
			return source;
		}

		//@JsonProperty("isBmis")
		public void setSource(boolean source) {
			this.source = source;
		}

		public String getSpeciality() {
			return speciality;
		}

		@JsonProperty("speciality")
		public void setSpeciality(String speciality) {
			this.speciality = speciality;
		}

		public String getState() {
			return state;
		}

		@JsonProperty("state")
		public void setState(String state) {
			this.state = state;
		}
		
		public String getCampaignName() {
			return campaignName;
		}
		
		@JsonProperty("campaignName")
		public void setCampaignName(String campaignName) {
			this.campaignName = campaignName;
		}
	}
}