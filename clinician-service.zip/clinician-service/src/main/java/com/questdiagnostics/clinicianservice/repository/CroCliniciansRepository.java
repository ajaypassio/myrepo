package com.questdiagnostics.clinicianservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.questdiagnostics.clinicianservice.model.CROClinician;

 
public interface CroCliniciansRepository extends MongoRepository<CROClinician, String> {

	
}
