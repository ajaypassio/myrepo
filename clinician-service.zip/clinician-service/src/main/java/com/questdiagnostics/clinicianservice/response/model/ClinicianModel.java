package com.questdiagnostics.clinicianservice.response.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.ALWAYS)
@JsonPropertyOrder({ "first_name", "last_name", "middle_name", "npi", "source", "noOfPatients", "address",
		"city", "state", "zip", "email_address", "phone_number", "specialty"})
public class ClinicianModel implements Serializable {

	@JsonProperty("first_name")
	private String firstName;
	@JsonProperty("middle_name")
	private String middleName;
	@JsonProperty("last_name")
	private String lastName;
	@JsonProperty("npi")
	private String npi;
	@JsonProperty("source")
	private String source;
	@JsonProperty("specialty")
	private String specialty;

	@JsonProperty("noOfPatients")
	private Integer noOfPatients;
	@JsonProperty("address")
	private String address;
	 
	@JsonProperty("city")
	private String city;
	@JsonProperty("state")
	private String state;
	@JsonProperty("zip")
	private String zip;
	@JsonProperty("phone_number")
	private String phoneNumber = "";
	@JsonProperty("email_address")
	private String emailAddress = "";
	
	@JsonProperty("npi")
	public String getNpi() {
		return npi;
	}

	@JsonProperty("npi")
	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@JsonProperty("noOfPatients")
	public Integer getNoOfPatients() {
		return noOfPatients;
	}

	 @JsonProperty("noOfPatients")
		public void setNoOfPatients(Integer noOfPatients) {
			this.noOfPatients = noOfPatients;
		}

	@JsonProperty("first_name")
	public String getFirstName() {
		return firstName;
	}

	@JsonProperty("first_name")
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@JsonProperty("last_name")
	public String getLastName() {
		return lastName;
	}

	@JsonProperty("last_name")
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@JsonProperty("middle_name")
	public String getMiddleName() {
		return middleName;
	}

	@JsonProperty("middle_name")
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	@JsonProperty("address")
	public String getAddress() {
		return address;
	}

	@JsonProperty("address")
	public void setAddress(String address) {
		this.address = address;
	}

	@JsonProperty("city")
	public String getCity() {
		return city;
	}

	@JsonProperty("city")
	public void setCity(String city) {
		this.city = city;
	}

	@JsonProperty("state")
	public String getState() {
		return state;
	}

	@JsonProperty("state")
	public void setState(String state) {
		this.state = state;
	}

	@JsonProperty("zip")
	public String getZip() {
		return zip;
	}

	@JsonProperty("zip")
	public void setZip(String zip) {
		this.zip = zip;
	}

	@JsonProperty("email_address")
	public String getEmailAddress() {
		return emailAddress;
	}

	@JsonProperty("email_address")
	public void setEmailAddress(List<String> emailAddress) {
		if (emailAddress != null && !emailAddress.isEmpty())
			this.emailAddress = String.join(" | ", emailAddress);
	}

	@JsonProperty("phone_number")
	public String getPhoneNumber() {
		return phoneNumber;
	}

	@JsonProperty("phone_number")
	public void setPhoneNumber(List<String> phoneNumber) {
		if (phoneNumber != null && !phoneNumber.isEmpty())
			this.phoneNumber = String.join(" | ", phoneNumber);
	}

	@JsonProperty("specialty")
	public String getSpecialty() {
		return specialty;
	}

	@JsonProperty("specialty")
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

}
