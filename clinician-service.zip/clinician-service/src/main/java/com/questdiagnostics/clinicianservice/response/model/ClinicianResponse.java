package com.questdiagnostics.clinicianservice.response.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Component
public class ClinicianResponse implements Serializable {

	private int status;
	private String message;
	private String createdDate;

	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private Object data;

	private long totalPages;

	private DataCount dataCount;

	private List<String> croProject;

	/**
	 * @return the croProject
	 */
	public List<String> getCroProject() {
		return croProject;
	}

	/**
	 * @param croProject
	 *            the croProject to set
	 */
	public void setCroProject(List<String> croProject) {
		this.croProject = croProject;
	}

	public DataCount getDataCount() {
		return dataCount;
	}

	public void setDataCount(DataCount dataCount) {
		this.dataCount = dataCount;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public long getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(long totalPages) {
		this.totalPages = totalPages;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
}
