package com.questdiagnostics.clinicianservice.response.model;

import java.io.Serializable;

public class DataCount implements Serializable {

	private static final long serialVersionUID = -6717992666243073261L;

	private int totalCount;
	private int questCount;
	private int croCount;
	private int count1572;
	private int questAnd1572Count;
	private int questAndCroCount;
	private int croAnd1572Count;
	private int questAndCroAnd1572Count;

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getQuestCount() {
		return questCount;
	}

	public void setQuestCount(int questCount) {
		this.questCount = questCount;
	}

	public int getCroCount() {
		return croCount;
	}

	public void setCroCount(int croCount) {
		this.croCount = croCount;
	}

	public int getCount1572() {
		return count1572;
	}

	public void setCount1572(int count1572) {
		this.count1572 = count1572;
	}

	public int getQuestAnd1572Count() {
		return questAnd1572Count;
	}

	public void setQuestAnd1572Count(int questAnd1572Count) {
		this.questAnd1572Count = questAnd1572Count;
	}

	public int getQuestAndCroCount() {
		return questAndCroCount;
	}

	public void setQuestAndCroCount(int questAndCroCount) {
		this.questAndCroCount = questAndCroCount;
	}

	public int getCroAnd1572Count() {
		return croAnd1572Count;
	}

	public void setCroAnd1572Count(int croAnd1572Count) {
		this.croAnd1572Count = croAnd1572Count;
	}

	public int getQuestAndCroAnd1572Count() {
		return questAndCroAnd1572Count;
	}

	public void setQuestAndCroAnd1572Count(int questAndCroAnd1572Count) {
		this.questAndCroAnd1572Count = questAndCroAnd1572Count;
	}

	@Override
	public String toString() {
		return "DataCount [totalCount=" + totalCount + ", questCount=" + questCount + ", croCount=" + croCount
				+ ", count1572=" + count1572 + ", questAnd1572Count=" + questAnd1572Count + ", questAndCroCount="
				+ questAndCroCount + ", croAnd1572Count=" + croAnd1572Count + ", questAndCroAnd1572Count="
				+ questAndCroAnd1572Count + "]";
	}

}
