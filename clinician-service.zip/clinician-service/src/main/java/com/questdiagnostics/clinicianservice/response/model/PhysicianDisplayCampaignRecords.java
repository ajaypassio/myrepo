package com.questdiagnostics.clinicianservice.response.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;

public class PhysicianDisplayCampaignRecords {
	@JsonProperty("physicianCampaignData")
    private List<PhysicianCampaignData> physicianCampaignData = null;
	
	@JsonProperty("total_record_in_db")
	private Integer total_record_in_db;

	

	public List<PhysicianCampaignData> getPhysicianCampaignData() {
		return physicianCampaignData;
	}

	public void setPhysicianCampaignData(List<PhysicianCampaignData> physicianCampaignData) {
		this.physicianCampaignData = physicianCampaignData;
	}

	public Integer getTotal_record_in_db() {
		return total_record_in_db;
	}

	public void setTotal_record_in_db(Integer total_record_in_db) {
		this.total_record_in_db = total_record_in_db;
	}
	
	
}
