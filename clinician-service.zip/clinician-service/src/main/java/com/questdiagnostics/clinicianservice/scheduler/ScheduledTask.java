package com.questdiagnostics.clinicianservice.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.service.CROClinicianService;

/**
 *
 * This class is used to start scheduled task after define frequency to process
 * data from event hub
 *
 */

@Component
public class ScheduledTask {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CROClinicianService croService;

	// @Scheduled(cron = "${scheduler.cron.job}")
	public void startCroDataProcessor() {
		try {
			croService.getDataFromQueue();

		} catch (Exception e) {
			logger.error("Got Exception while processing data from event hub {}", e);
		}
	}

}