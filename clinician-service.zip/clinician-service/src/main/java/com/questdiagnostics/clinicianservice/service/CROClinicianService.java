package com.questdiagnostics.clinicianservice.service;

import java.util.List;

import com.questdiagnostics.clinicianservice.model.CROClinician;

public interface CROClinicianService {
	
	public void saveCROData(List<CROClinician> clinician);
	
	public void getDataFromQueue();
	
	public List<String> getDistinctCroProject();

}
