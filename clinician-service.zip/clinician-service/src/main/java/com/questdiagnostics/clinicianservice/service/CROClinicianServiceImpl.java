package com.questdiagnostics.clinicianservice.service;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.mongodb.client.DistinctIterable;
import com.questdiagnostics.clinicianservice.messaging.util.BlobStorageUtil;
import com.questdiagnostics.clinicianservice.model.CROClinician;
import com.questdiagnostics.clinicianservice.util.SpringBeanUtil;

@Service
public class CROClinicianServiceImpl implements CROClinicianService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private final String PROJECT_KEY = "project";

	@Autowired
	private MongoTemplate template;

	@Value("${mongoCROCollectionName}")
	private String mongoCROCollectionName;

	@Value("${sprintt.azure.blob.storage.cro.container.name}")
	String containerName;

	@Value("${sprintt.azure.blob.storage.cro.queue.name}")
	String queueName;

	@Value("${sprintt.max.message.count}")
	String maxMessages;

	@Override
	public List<String> getDistinctCroProject() {
		logger.debug("Process started to fetch distinct project from CRO collection");
		DistinctIterable<String> mongoCollection = template.getCollection(mongoCROCollectionName).distinct(PROJECT_KEY,
				String.class);
		List<String> croProlist = new ArrayList<>();
		for (String str : mongoCollection) {
			croProlist.add(str);
		}
		logger.info("Returning distinct project from CRO collection: {} ", croProlist.size());
		return croProlist;
	}

	@Override
	public void saveCROData(List<CROClinician> clinician) {
		clinician.forEach(x -> {
			logger.info("Docuemnt inserted into collection {} ", x.getId());
			template.save(x, mongoCROCollectionName);
		});
	}

	@Override
	public void getDataFromQueue() {
		BlobStorageUtil util = SpringBeanUtil.getBean(BlobStorageUtil.class);

		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		CloudQueueClient queueClient = null;
		CloudBlockBlob blob = null;

		try {
			storageAccount = CloudStorageAccount.parse(util.getStorageConnectionString());
			logger.info("CRO getStorageConnectionString : {} ", util.getStorageConnectionString());
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);
			container.createIfNotExists();

			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(queueName);
			queue.createIfNotExists();
			logger.info("CRO queue name : {} ", queueName);
			// Peek at the next message.
			Iterable<CloudQueueMessage> listOfMessages = queue.retrieveMessages(Integer.parseInt(maxMessages));
			for (CloudQueueMessage peekedMessage : listOfMessages) {
				String peekedMessageAsString = peekedMessage.getMessageContentAsString();
				blob = container.getBlockBlobReference(peekedMessageAsString);
				String dataValue = blob.downloadText();
				List<CROClinician> croList = convertMessageStringJsonToCROModel(dataValue);
				saveCROData(croList);
				queue.deleteMessage(peekedMessage);
			}

		} catch (URISyntaxException | StorageException | IOException | InvalidKeyException e) {
			logger.error("Processing failed while reading message from queue: " + e.getMessage());
			e.printStackTrace();
		}

		logger.info("CRO data ingetion has been completed from queue ");
	}

	private List<CROClinician> convertMessageStringJsonToCROModel(String queueString) {
		try {
			ObjectMapper mapper = new ObjectMapper();

			List<CROClinician> details = mapper.readValue(queueString, new TypeReference<List<CROClinician>>() {
			});
			details.forEach(croClinician -> croClinician.setId(createKeyFromStrings(croClinician)));

			return details;
		} catch (Exception e) {
			logger.error("exception occured : {}", e.getMessage());
			return null;
		}

	}

	private String createKeyFromStrings(CROClinician croClinician) {
		StringBuilder generatedId = new StringBuilder().append(croClinician.getTrailId())
				.append(croClinician.getSiteName()).append(croClinician.getInvestigatorId())
				.append(croClinician.getFirstName()).append(croClinician.getLastName()).append(croClinician.getNpi())
				.append(croClinician.getZip());

		if (generatedId != null && generatedId.length() > 0) {
			return generatedId.toString().replaceAll(" ", "_").replaceAll("null", "");
		}
		return null;
	}
}