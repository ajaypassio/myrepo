package com.questdiagnostics.clinicianservice.service;

import static com.questdiagnostics.clinicianservice.service.ClinicianServiceImpl.QUEST_CLINICIANS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.clinicianservice.model.CliniciansLight;
import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.util.LabTestUnwindOperationsNew;
import com.questdiagnostics.clinicianservice.util.PatientFilter;
import com.questdiagnostics.clinicianservice.util.UnwindOperationsInterfaceNew;
/**
 * @author samarth.srivastava
 *
 */
public class ClincianServiceHelper {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ClincianServiceHelper.class);

	private static final int MIN_AGE = 1;
	private static final int MAX_AGE = 90;
	private static final int SLAB_RANGE = 5;
	private static String[] ageSlabs = null;
	static {
		ageSlabs = new String[(MAX_AGE - MIN_AGE + 1) / SLAB_RANGE];
		int counter = 0;
		for (int i = MIN_AGE; i < MAX_AGE; i = i + SLAB_RANGE - 1) {
			if (ageSlabs[counter] == null) {
				ageSlabs[counter] = i + "-"
						+ (((i + SLAB_RANGE - 1)> MAX_AGE) ? MAX_AGE : i + SLAB_RANGE - 1);
				i++;
				counter++;
			}
		}
	}

	static List<CliniciansLight> getCliniciansBasedOnQuestCriteriaNew(QueryModel queryModel,
			UnwindOperationsInterfaceNew func, String collectionName, MongoTemplate template) {
		long jobStartTS = System.currentTimeMillis();
		List matchOperation = func.createDBObjectsFromCriteria(queryModel, collectionName);

		Aggregation aggregation = Aggregation.newAggregation(matchOperation)
				.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());

		LOGGER.info("Query created for collection {} :{}", collectionName, aggregation);

		AggregationResults<CliniciansLight> output = template.aggregate(aggregation, collectionName,
				CliniciansLight.class);
		List<CliniciansLight> clinicians = output.getMappedResults();
		clinicians.forEach(x -> x.setNoOfPatients(x.getPatient_ids() != null ? x.getPatient_ids().size() : 0));

		LOGGER.info("Returing list of clinicians for {}  {} ", collectionName,
				!CollectionUtils.isEmpty(clinicians) ? clinicians.size() : 0);

		long jobEndTS = System.currentTimeMillis();
		LOGGER.info("Time taken for {} job and collection {} is {} sec", QUEST_CLINICIANS, collectionName,
				(long) ((jobEndTS - jobStartTS) / 1000));

		return clinicians;
	}

	private static Set<String> resolveCollections(PatientFilter patientFilter, String type) {
		String[] genderArr = null;
		if (patientFilter.getGender().contains(",")) {
			genderArr = patientFilter.getGender().split(",");
		} else {
			genderArr = new String[] { patientFilter.getGender() };
		}
		Set<String> genderAgeArr = new HashSet<>();
		for (String gender : genderArr) {
			boolean minSlabFound = false;
			boolean maxSlabFound = false;
			for(int i = 0; i < ageSlabs.length; i++) {
				Integer[] slabBounds = getAgeBounds(ageSlabs[i]);
				if (!minSlabFound) {					
					if(slabBounds[0] <= patientFilter.getAgeMin() && patientFilter.getAgeMin() <= slabBounds[1]) {
						genderAgeArr.add(gender.trim().toUpperCase() + "_" + ageSlabs[i] + "_" + type);
						minSlabFound = true;
					}
				}
				if (minSlabFound && !maxSlabFound) {
					if(slabBounds[0] <= patientFilter.getAgeMax() && patientFilter.getAgeMax() <= slabBounds[1]) {						
						maxSlabFound = true;
					} 
					genderAgeArr.add(gender.trim().toUpperCase() + "_" + ageSlabs[i] + "_" + type);
				}
			}
		}
		return genderAgeArr;
	}
	
	public static Integer[] getAgeBounds(String ageSlab) {
		String[] slabBounds = ageSlab.split("-");
		int lowerBound = Integer.parseInt(slabBounds[0]);
		int upperBound = Integer.parseInt(slabBounds[1]);
		return new Integer[] { lowerBound, upperBound };
	}
	
	private static Integer[] getAgeBoundsFromCollection(String collName) {
		String[] slabBounds = collName.split("_");
		Integer[] bounds = getAgeBounds(slabBounds[1]);
		return new Integer[] { bounds[0], bounds[1] };
	}

	public static Integer[] determineAgeValues(Integer minAge, Integer maxAge, String collectionName) {
		List<Integer> ageList = new ArrayList<>();
		int counter = 0;
		// Get age bounds of the collection		
		Integer[] ageBounds = getAgeBoundsFromCollection(collectionName);
		if(minAge >= ageBounds[0] && maxAge <= ageBounds[1]) { // both minAge and maxAge lie within the bounds
			counter = minAge;
			while(counter <= maxAge) {
				ageList.add(counter);
				counter++;
			}
		} else if (minAge >= ageBounds[0] && maxAge > ageBounds[1]) { // only min age lies within the bounds
			counter = minAge;
			while(counter <= ageBounds[1]) {
				ageList.add(counter);
				counter++;
			}
		} else if (minAge < ageBounds[0] && maxAge <= ageBounds[1]) { // only max age lies within the bounds
			counter = ageBounds[0];
			while(counter <= maxAge) {
				ageList.add(counter);
				counter++;
			}
		} else { // both bounds lies between the min age and the max age but both ages not in the current slab
			counter = ageBounds[0];
			while(counter <= ageBounds[1]) {
				ageList.add(counter);
				counter++;
			}
		}		
		
		return ageList.toArray(new Integer[ageList.size()]);
	}

	static List<CliniciansLight> performAsyncOperationForACriteria(QueryModel queryModel,
			UnwindOperationsInterfaceNew operation, MongoTemplate template) throws InterruptedException, ExecutionException {
		// get all collections based on patient info and diagnostics/lab data from query model
		// break diagnostics/lab operations for age/gender slabs
		PatientFilter patientFilter = queryModel.getPatientInfo().getInit().get(0);
		String type = (operation instanceof LabTestUnwindOperationsNew) ? "LAB" : "DIAG";

		Set<String> collections = resolveCollections(patientFilter, type);

		// each query to run in its own thread
		// merge data from all parallel queries
		
		List<List<CliniciansLight>> combinedList = 
				collections.parallelStream()
				.map(name -> {return getCliniciansBasedOnQuestCriteriaNew(queryModel, operation, name,template);})
				.collect(Collectors.toList());
				
		if(!CollectionUtils.isEmpty(combinedList)) {
			Map<String, CliniciansLight> cliniciansMap = new HashMap<>();
			for(List<CliniciansLight> cliniciansLightList : combinedList) {
				for(CliniciansLight cliniciansLight : cliniciansLightList) {
					if(cliniciansMap.containsKey(cliniciansLight.getId())) {
						CliniciansLight existingClinician = cliniciansMap.get(cliniciansLight.getId());
						existingClinician.getPatient_ids_set().addAll(existingClinician.getPatient_ids());
						existingClinician.getPatient_ids_set().addAll(cliniciansLight.getPatient_ids());						
					} else {
						cliniciansMap.put(cliniciansLight.getId(), cliniciansLight);
					}
				}
			}
			return new ArrayList<>(cliniciansMap.values());
		}
		return null;
	}
}
