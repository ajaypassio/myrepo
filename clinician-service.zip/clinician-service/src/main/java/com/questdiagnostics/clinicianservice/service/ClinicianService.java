package com.questdiagnostics.clinicianservice.service;

import java.util.List;

import com.questdiagnostics.clinicianservice.model.Clinicians;
import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;

public interface ClinicianService {

	public ClinicianResponse getFilteredCliniciansForQuest(QueryModel searchModel);

	public ClinicianResponse getFilteredClinicians(QueryModel searchModel);

	public ClinicianResponse getFilteredCliniciansFor1572(QueryModel searchModel);
	public ClinicianResponse getFilteredCliniciansForCRO(QueryModel searchModel);
	
	public ClinicianResponse getCliniciansForQuestAndCRO(QueryModel searchModel);

	public ClinicianResponse getCliniciansFor1572AndCRO(QueryModel searchModel);
	public ClinicianResponse getCliniciansForQuest1572AndCRO(QueryModel searchModel);

}
