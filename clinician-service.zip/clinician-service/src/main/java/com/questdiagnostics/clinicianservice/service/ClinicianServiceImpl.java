package com.questdiagnostics.clinicianservice.service;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.FacetOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.model.Clinicians;
import com.questdiagnostics.clinicianservice.model.CliniciansLight;
import com.questdiagnostics.clinicianservice.model.MatchingClinicians;
import com.questdiagnostics.clinicianservice.model.MongoPageRequest;
import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;
import com.questdiagnostics.clinicianservice.response.model.DataCount;
import com.questdiagnostics.clinicianservice.util.LabTestUnwindOperations;
import com.questdiagnostics.clinicianservice.util.UnwindOperationsInterface;
import com.questdiagnostics.clinicianservice.util.UnwindOperationsInterfaceNew;

@Service
public class ClinicianServiceImpl implements ClinicianService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	static final String QUEST_CLINICIANS = "QUEST_CLINICIANS";
	private final String CRO_CLINICIANS = "CRO_CLINICIANS";
	private final String NPI1572_CLINICIANS = "NPI1572_CLINICIANS";
	private final String SET_OPERATIONS = "SET_OPERATIONS";

	private static final Map<String, Clinicians> cliniciansCache = new ConcurrentHashMap<>();
	
	@Autowired
	private MongoTemplate template;

	@Autowired
	private UnwindOperationsInterface labTestUnwindOperations;

	@Autowired
	private UnwindOperationsInterface diagnosticsUnwindOperations;
	
	@Autowired
	private UnwindOperationsInterfaceNew labTestUnwindOperationsNew;

	@Autowired
	private UnwindOperationsInterfaceNew diagnosticsUnwindOperationsNew;

	@Value("${mongoQuestCollectionName}")
	private String mongoQuestCollectionName;

	@Value("${mongoNPI1572CollectionName}")
	private String mongoNPI1572CollectionName;

	@Value("${mongoCROCollectionName}")
	private String mongoCROCollectionName;

	@Override
	public ClinicianResponse getFilteredCliniciansForQuest(QueryModel queryModel) {
		logger.debug("Process started getFilteredCliniciansForQuest for QUEST data");
		ClinicianResponse response = new ClinicianResponse();
		DataCount dc = new DataCount();
		List<Clinicians> clinicianList = getCliniciansFromCache(getFilteredCliniciansForAllNew(queryModel));
		if (!CollectionUtils.isEmpty(clinicianList)) {
			dc.setQuestCount(clinicianList.size());
			dc.setTotalCount(clinicianList.size());
			response = mapToResponseObject(getPaginatedList(clinicianList, queryModel), queryModel);
		}
		response.setDataCount(dc);
		logger.info("Returning clinicians from QUEST data {}: "+dc.toString());
		return response;
	}
	
	@PostConstruct
	private void initializeCliniciansCache() {
		List<Clinicians> list = template.findAll(Clinicians.class, "Quest_Clinicians_Master");
		for(Clinicians clinician : list) {
			cliniciansCache.putIfAbsent(clinician.getNpi(), clinician);
		}
		logger.info("loaded {} clinicians into cache", list.size());
	}

	private List<Clinicians> getCliniciansFromCache(List<CliniciansLight> cliniciansLight) {
		List<Clinicians> finalList = new ArrayList<>();
		logger.info("Received {} cliniciansLight", cliniciansLight.size());
		if (!CollectionUtils.isEmpty(cliniciansLight)) {
			for (CliniciansLight clinicianLight : cliniciansLight) {
				Clinicians clinicianMaster = cliniciansCache.get(clinicianLight.getId());
				if(clinicianMaster != null && !CollectionUtils.isEmpty(clinicianLight.getPatient_ids())) {
					Clinicians clinician = new Clinicians(clinicianMaster.getNpi(), clinicianMaster.getFirstName());
					clinician.setAddress(clinicianMaster.getAddress());
					clinician.setAddress1(clinicianMaster.getAddress1());
					clinician.setAddress2(clinicianMaster.getAddress2());
					clinician.setCity(clinicianMaster.getCity());
					clinician.setEmailAddress(clinicianMaster.getEmailAddress());
					clinician.setLastName(clinicianMaster.getLastName());
					clinician.setMiddleName(clinicianMaster.getMiddleName());
					clinician.setPhoneNumber(clinicianMaster.getPhoneNumber());
					clinician.setProject(clinicianMaster.getProject());
					clinician.setSource(clinicianMaster.getSource());
					clinician.setSpecialty(clinicianMaster.getSpecialty());
					clinician.setState(clinicianMaster.getState());
					clinician.setZip(clinicianMaster.getZip());
					clinician.setNoOfPatients(!CollectionUtils.isEmpty(clinicianLight.getPatient_ids_set())
							? clinicianLight.getPatient_ids_set().size()
							: clinicianLight.getPatient_ids().size());
					finalList.add(clinician);
				}
			}
		}
		logger.info("Returning {} quest clinicians", finalList.size());
		return finalList;
	}
	
	private List<CliniciansLight> getFilteredCliniciansForAllNew(QueryModel queryModel) {
		List<CliniciansLight> questClinicians = new ArrayList<>();
		try {
			long jobStartTS = System.currentTimeMillis();			
			boolean isPatientInfoPresent = queryModel.getPatientInfo().getInit() != null
					&& !queryModel.getPatientInfo().getInit().isEmpty();
			boolean isDiagnosticInfoPresent = queryModel.getDignosticsInfo().getInit() != null
					&& !queryModel.getDignosticsInfo().getInit().isEmpty();
			boolean isLabDataPresent = queryModel.getLabTest().getInit() != null
					&& !queryModel.getLabTest().getInit().isEmpty();

			if (isPatientInfoPresent && isDiagnosticInfoPresent && !isLabDataPresent) { // only diagnostics present
				questClinicians = ClincianServiceHelper.performAsyncOperationForACriteria(queryModel,
						diagnosticsUnwindOperationsNew, template);
			} else if (isPatientInfoPresent && !isDiagnosticInfoPresent && isLabDataPresent) { // only lab data present
				questClinicians = ClincianServiceHelper.performAsyncOperationForACriteria(queryModel,
						labTestUnwindOperationsNew, template);
			} else { // both lab data and diagnostics present
				return performAsyncOperationNew(queryModel, diagnosticsUnwindOperationsNew, labTestUnwindOperationsNew);
			}
			long jobEndTS = System.currentTimeMillis();
			logger.info("Time taken for {} job is {} sec", QUEST_CLINICIANS, (long) ((jobEndTS - jobStartTS) / 1000));
			return questClinicians;
		} catch (InterruptedException | ExecutionException e) {
			logger.error("caught exception during getFilteredCliniciansForAllNew: " + e);
			return questClinicians;
		}
	}
	
	private List<Clinicians> getFilteredCliniciansForAll(QueryModel queryModel) {
		long jobStartTS = System.currentTimeMillis();
		List<Clinicians> questClinicians = new ArrayList<>();
		boolean isPatientInfoPresent = queryModel.getPatientInfo().getInit() != null
				&& !queryModel.getPatientInfo().getInit().isEmpty();
		boolean isDiagnosticInfoPresent = queryModel.getDignosticsInfo().getInit() != null
				&& !queryModel.getDignosticsInfo().getInit().isEmpty();
		boolean isLabDataPresent = queryModel.getLabTest().getInit() != null
				&& !queryModel.getLabTest().getInit().isEmpty();

		if (isPatientInfoPresent && !isDiagnosticInfoPresent && !isLabDataPresent) { // only patient info present			
			questClinicians = performSetOperationNew(
					getCliniciansBasedOnQuestCriteria(queryModel, diagnosticsUnwindOperations),
					getCliniciansBasedOnQuestCriteria(queryModel, labTestUnwindOperations), "OR");
			
		} else if (isDiagnosticInfoPresent && !isLabDataPresent) { // only diagnostics + patient-info* present
			questClinicians = getCliniciansBasedOnQuestCriteria(queryModel, diagnosticsUnwindOperations);
		} else if (!isDiagnosticInfoPresent && isLabDataPresent) { // only lab data + patient-info* present
			questClinicians = getCliniciansBasedOnQuestCriteria(queryModel, labTestUnwindOperations);
		} else {			
			return performAsyncOperation(queryModel, diagnosticsUnwindOperations, labTestUnwindOperations);
		}
		
		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job is {} sec", QUEST_CLINICIANS, (long) ((jobEndTS - jobStartTS) / 1000));
		return questClinicians;
	}
	/**
	 * This method is doing parallel operation to fetch lab and diagnostic data and then combine both data into set operation
	 * @param queryModel
	 * @param diagnosticsUnwindOperations
	 * @param labTestUnwindOperations
	 * @return list of clinicians
	 */
	private List<Clinicians> performAsyncOperation(QueryModel queryModel,
			UnwindOperationsInterface diagnosticsUnwindOperations, UnwindOperationsInterface labTestUnwindOperations) {
		
		CompletableFuture<List<Clinicians>> getDiagnosticsUnwindOperations = CompletableFuture.supplyAsync(() -> {
			return getCliniciansBasedOnQuestCriteria(queryModel, diagnosticsUnwindOperations);
		});

		CompletableFuture<List<Clinicians>> getLabTestUnwindOperations = CompletableFuture.supplyAsync(() -> {
			return getCliniciansBasedOnQuestCriteria(queryModel, labTestUnwindOperations);
		});

		CompletableFuture<List<Clinicians>> questCliniciansParallel = getDiagnosticsUnwindOperations.thenCombine(
				getLabTestUnwindOperations, (localdiagnosticsUnwindOperations, locallabTestUnwindOperations) -> {
					return performSetOperationNew(localdiagnosticsUnwindOperations, locallabTestUnwindOperations,
							queryModel.getLabTest().getOperator());

				});
		try {
			return questCliniciansParallel.get();
		} catch (InterruptedException | ExecutionException e) {
			logger.error("Problem occurred during process async operation of lab and dignostic : {} ",e.getMessage());
		}
		return null;
	}
	
	private List<CliniciansLight> performAsyncOperationNew(QueryModel queryModel,
			UnwindOperationsInterfaceNew diagnosticsUnwindOperations, UnwindOperationsInterfaceNew labTestUnwindOperations) {		
		CompletableFuture<List<CliniciansLight>> getDiagnosticsUnwindOperationsNew = CompletableFuture.supplyAsync(() -> {
			try {
				return  ClincianServiceHelper.performAsyncOperationForACriteria(queryModel,
						diagnosticsUnwindOperationsNew, template);
			} catch (InterruptedException | ExecutionException e) {
				logger.error("Caught exception while performAsyncOperationNew: " + e);
				return null;
			}						
		});

		CompletableFuture<List<CliniciansLight>> getLabTestUnwindOperationsNew = CompletableFuture.supplyAsync(() -> {
			try {
				return ClincianServiceHelper.performAsyncOperationForACriteria(queryModel,
						labTestUnwindOperationsNew, template);
			} catch (InterruptedException | ExecutionException e) {
				logger.error("Caught exception while performAsyncOperationNew: " + e);
				return null;
			}
		});

		CompletableFuture<List<CliniciansLight>> questCliniciansParallel = getDiagnosticsUnwindOperationsNew
				.thenCombine(getLabTestUnwindOperationsNew,
						(localdiagnosticsUnwindOperations, locallabTestUnwindOperations) -> {
							return performSetOperationNew2(localdiagnosticsUnwindOperations,
									locallabTestUnwindOperations, queryModel.getLabTest().getOperator());
						});
		try {
			return questCliniciansParallel.get();
		} catch (InterruptedException | ExecutionException e) {
			logger.error("Problem occurred during process async operation of lab and dignostic : {} ",e.getMessage());
		}
		return null;
	}

	private List<Clinicians> performSetOperation(List<Clinicians> list1, List<Clinicians> list2, String operationType) {
		Set<Clinicians> clinicianSet = new HashSet<>();
		if (operationType.equalsIgnoreCase("AND")) {
			for (Clinicians list1Clinician : list1) {
				int indexOfC1InC2 = list2.indexOf(list1Clinician);
				if (indexOfC1InC2 != -1) {
					// merge patient Ids
					Clinicians list2Clinician = list2.get(indexOfC1InC2);
					List<String> patientIdList = new ArrayList<>();
					if (list1Clinician.getPatient_ids() != null && list2Clinician.getPatient_ids() != null) {
						for (String patientId1 : list1Clinician.getPatient_ids()) {
							int indexOfP1InP2 = list2Clinician.getPatient_ids().indexOf(patientId1);
							if (indexOfP1InP2 != -1) {
								patientIdList.add(patientId1);
							}
						}
					}
					list1Clinician.setPatient_ids(patientIdList);
					list1Clinician.setNoOfPatients(patientIdList.size());
					clinicianSet.add(list1Clinician);
				}

			}
		} else if (operationType.equalsIgnoreCase("OR")) {
			for (Clinicians list1Clinician : list1) {
				int indexOfC1InC2 = list2.indexOf(list1Clinician);
				if (indexOfC1InC2 != -1) {
					// merge patient Ids
					Clinicians list2Clinician = list2.get(indexOfC1InC2);
					Set<String> patientIdList = new HashSet<>();
					if (list1Clinician.getPatient_ids() != null) {
						patientIdList.addAll(list1Clinician.getPatient_ids());
					}
					if (list2Clinician.getPatient_ids() != null) {
						patientIdList.addAll(list2Clinician.getPatient_ids());
					}

					list1Clinician.setPatient_ids(new ArrayList<>(patientIdList));
					list1Clinician.setNoOfPatients(patientIdList.size());
				}
				clinicianSet.add(list1Clinician);
			}
			clinicianSet.addAll(list2);
		}
		return new ArrayList<>(clinicianSet);
	}
	
	private List<Clinicians> performSetOperationNew(List<Clinicians> list1, List<Clinicians> list2,
			String operationType) {
		Set<Clinicians> clinicianSet = new HashSet<>();
		long jobStartTS = System.currentTimeMillis();

		for (Clinicians list1Clinician : list1) {
			int indexOfC1InC2 = list2.indexOf(list1Clinician);
			if (indexOfC1InC2 != -1) {
				// merge patient Ids
				Clinicians list2Clinician = list2.get(indexOfC1InC2);
				Set<String> patientIdList = new HashSet<>();
				if (list1Clinician.getPatient_ids() != null) {
					patientIdList.addAll(list1Clinician.getPatient_ids());
				}
				if (list2Clinician.getPatient_ids() != null) {
					patientIdList.addAll(list2Clinician.getPatient_ids());
				}
				list1Clinician.setPatient_ids(new ArrayList<>(patientIdList));
				list1Clinician.setNoOfPatients(patientIdList.size());
				if (operationType.equalsIgnoreCase("AND")) {
					clinicianSet.add(list1Clinician);
				}
			}
			if (operationType.equalsIgnoreCase("OR")) {
				clinicianSet.add(list1Clinician);
			}
		}
		if (operationType.equalsIgnoreCase("OR")) {
			clinicianSet.addAll(list2);
		}

		long jobEndTS = System.currentTimeMillis();

		logger.info("Time taken for {} job is {} sec", SET_OPERATIONS, (long) ((jobEndTS - jobStartTS) / 1000));

		return new ArrayList<>(clinicianSet);
	}
	
	private List<CliniciansLight> performSetOperationNew2(List<CliniciansLight> list1, List<CliniciansLight> list2,
			String operationType) {
		Set<CliniciansLight> clinicianSet = new HashSet<>();
		long jobStartTS = System.currentTimeMillis();

		for (CliniciansLight list1Clinician : list1) {
			int indexOfC1InC2 = list2.indexOf(list1Clinician);
			if (indexOfC1InC2 != -1) {
				// merge patient Ids
				CliniciansLight list2Clinician = list2.get(indexOfC1InC2);
				Set<String> patientIdList = new HashSet<>();
				if (list1Clinician.getPatient_ids() != null) {
					patientIdList.addAll(list1Clinician.getPatient_ids());
				}
				if (list2Clinician.getPatient_ids() != null) {
					patientIdList.addAll(list2Clinician.getPatient_ids());
				}
				list1Clinician.setPatient_ids(new ArrayList<>(patientIdList));
				list1Clinician.setNoOfPatients(patientIdList.size());
				if (operationType.equalsIgnoreCase("AND")) {
					clinicianSet.add(list1Clinician);
				}
			}
			if (operationType.equalsIgnoreCase("OR")) {
				clinicianSet.add(list1Clinician);
			}
		}
		if (operationType.equalsIgnoreCase("OR")) {
			clinicianSet.addAll(list2);
		}

		long jobEndTS = System.currentTimeMillis();

		logger.info("Time taken for {} job is {} sec", SET_OPERATIONS, (long) ((jobEndTS - jobStartTS) / 1000));

		return new ArrayList<>(clinicianSet);
	}

	private List<Clinicians> getCliniciansBasedOnQuestCriteria(QueryModel queryModel, UnwindOperationsInterface func) {
		long jobStartTS = System.currentTimeMillis();
		String type = (func instanceof LabTestUnwindOperations) ? "lab" : "diag";
		List matchOperation = func.createDBObjectsFromCriteria(queryModel);

		Aggregation aggregation = Aggregation.newAggregation(matchOperation)
				.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());

		logger.info("Query created for {} type :{}", type,aggregation);

		AggregationResults<Clinicians> output = template.aggregate(aggregation, mongoQuestCollectionName,
				Clinicians.class);
		List<Clinicians> clinicians = output.getMappedResults();
		clinicians.forEach(x -> x.setNoOfPatients(x.getPatient_ids() != null ? x.getPatient_ids().size() : 0));

		logger.info("Returing list of clinicians for {}  {} ", type,clinicians != null ? clinicians.size() : 0);

		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job and type {} is {} sec", QUEST_CLINICIANS, type, (long) ((jobEndTS - jobStartTS) / 1000));
		
		return clinicians;
	}

	@Override
	public ClinicianResponse getFilteredClinicians(QueryModel queryModel) {
		long jobStartTS = System.currentTimeMillis();
		logger.debug("Process started getFilteredClinicians for Quest and 1572 ");
		ClinicianResponse response = new ClinicianResponse();
		DataCount dataCount = new DataCount();
		List<Clinicians> questClinicianList =// getFilteredCliniciansForAll(queryModel);
				getCliniciansFromCache(getFilteredCliniciansForAllNew(queryModel));

		List<String> npiList = getNPIsFromList(questClinicianList);
		List<MatchingClinicians> clinician1572 = getMatchingClinicians(queryModel, CommonConstant.NPI_1572, npiList,
				!queryModel.getHasExport());
		List<Clinicians> questAnd1572NpiList = (clinician1572 != null && clinician1572.get(0) != null)
				? clinician1572.get(0).getData()
				: null;
		List<Clinicians> questAnd1572List = getQuestClinicianMatchedWithOthers(questClinicianList, questAnd1572NpiList);
		int total1572Count = clinician1572.get(0).getTotal_record_in_db();
		int intersectionCount = clinician1572.get(0).getMatched_as_per_criteria_Count();

		dataCount.setCount1572(total1572Count);
		dataCount.setQuestAnd1572Count(intersectionCount);

		dataCount.setQuestCount(questClinicianList != null ? questClinicianList.size() : 0);
		dataCount.setTotalCount(intersectionCount);
		response = mapToResponseObject(questAnd1572List, queryModel);

		response.setDataCount(dataCount);

		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job is {} sec", CommonConstant.QUEST_NPI_1572_SOURCE,
				(long) ((jobEndTS - jobStartTS) / 1000));
		
		logger.info("Returning clinicians for Quest and 1572 : {} ", intersectionCount);
		return response;

	}

	@Override
	public ClinicianResponse getCliniciansForQuest1572AndCRO(QueryModel queryModel) {
		long jobStartTS = System.currentTimeMillis();
		logger.debug("Process started getCliniciansForQuest1572AndCRO for Quest, 1572 and CRO");
		List<Clinicians> questClinicianList = //getFilteredCliniciansForAll(queryModel);
				getCliniciansFromCache(getFilteredCliniciansForAllNew(queryModel));
		ClinicianResponse response = new ClinicianResponse();
		DataCount dc = new DataCount();
		if (questClinicianList == null || questClinicianList.size() < 1) {
			response.setDataCount(dc);
			return response;
		}
		List<String> npiList = getNPIsFromList(questClinicianList);
		List<MatchingClinicians> clinician1572 = getMatchingClinicians(queryModel, CommonConstant.NPI_1572, npiList,
				false);
		if (!clinician1572.isEmpty() && clinician1572.get(0).getData() != null
				&& clinician1572.get(0).getData().size() > 0) {
			List<String> npi1572AndQuest = getNPIsFromList(clinician1572.get(0).getData());

			List<MatchingClinicians> clinician1572Cro = getMatchingClinicians(queryModel, CommonConstant.CRO,
					npi1572AndQuest, !queryModel.getHasExport());
			List<Clinicians> intersectionOfQDAndCroAnd1572NpiList = clinician1572Cro.get(0) != null
					? clinician1572Cro.get(0).getData()
					: null;
			int intersectionOfQDAndCroAnd1572Count = clinician1572Cro.get(0) != null
					? clinician1572Cro.get(0).getMatched_as_per_criteria_Count()
					: 0;
			List<Clinicians> intersectionOfQDAndCroAnd1572 = getQuestClinicianMatchedWithOthers(questClinicianList,
					intersectionOfQDAndCroAnd1572NpiList);
			logger.info("Returning clinicians from Quest, 1572 and CRO : {} ", intersectionOfQDAndCroAnd1572Count);

			dc.setQuestAndCroAnd1572Count(intersectionOfQDAndCroAnd1572Count);
			dc.setTotalCount(intersectionOfQDAndCroAnd1572Count);
			response = mapToResponseObject(intersectionOfQDAndCroAnd1572, queryModel);

		}
		response.setDataCount(dc);
		
		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job is {} sec", CommonConstant.QUEST_NPI_1572_CRO_SOURCE,
				(long) ((jobEndTS - jobStartTS) / 1000));
		
		return response;
	}

	private List<String> getNPIsFromList(List<Clinicians> cliniList) {
		if (cliniList != null && cliniList.size() > 0) {
			return cliniList.stream().map(e -> e.getNpi()).distinct().collect(Collectors.toList());
		}
		return new ArrayList<String>();
	}

	private List<Clinicians> getQuestClinicianMatchedWithOthers(List<Clinicians> questList,
			List<Clinicians> othersList) {
		List<Clinicians> filteredList = new ArrayList<>();
		if (questList != null && !questList.isEmpty() && othersList != null && !othersList.isEmpty()) {
			filteredList = questList.stream()
					.filter(empl -> othersList.stream().anyMatch(dept -> dept.getNpi().equals(empl.getNpi())))
					.collect(Collectors.toList());

		}
		return filteredList;
	}

	/*
	 * This method we can use to get data from CRO or 1572 as passing source
	 * 
	 * @param , Source it can be the name of collection from where we have to get
	 * data.
	 * 
	 * @see com.questdiagnostics.clinicianservice.service.ClinicianService#
	 * getCliniciansFor1572OrCRO(searchModel)
	 */
	@Override
	public ClinicianResponse getFilteredCliniciansFor1572(QueryModel searchModel) {
		logger.debug("Process started getFilteredCliniciansFor1572 for 1572");
		long jobStartTS = System.currentTimeMillis();
		String collectionName = getCollectionName(searchModel.getSource());
		if (!StringUtils.isEmpty(collectionName)) {
			Aggregation aggregation = null;
			SortOperation sortByNpiFirstname = Aggregation.sort(Direction.ASC, "first_name", "last_name", "npi",
					"source", "specialty", "state");
			// Query query = new Query();
			MongoPageRequest pageRequest = searchModel.getMongoPageRequest();
			// Pageable page = PageRequest.of(pageRequest.getPageNumber(),
			// pageRequest.getPageSize());
			if (!searchModel.getHasExport()) {
				// query.with(page);
				aggregation = Aggregation
						.newAggregation(sortByNpiFirstname,
								Aggregation.skip(pageRequest.getPageNumber() * pageRequest.getPageSize()),
								Aggregation.limit(pageRequest.getPageSize()))
						.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());
			} else {
				aggregation = Aggregation.newAggregation(sortByNpiFirstname)
						.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());
			}
			AggregationResults<Clinicians> output = template.aggregate(aggregation, collectionName, Clinicians.class);

			List<Clinicians> clinicianList = output.getMappedResults();
			int count = template.findAll(Clinicians.class, collectionName).size();
			DataCount dc = new DataCount();
			dc.setCount1572(count);
			dc.setTotalCount(count);
			logger.info("Returning clinicians from {}  and total count is : {} ", collectionName, count);
			ClinicianResponse response = mapToResponseObject(clinicianList, searchModel);
			response.setDataCount(dc);
			
			long jobEndTS = System.currentTimeMillis();
			logger.info("Time taken for {} job is {} sec", NPI1572_CLINICIANS, (long) ((jobEndTS - jobStartTS) / 1000));
			
			return response;
		}

		return null;
	}

	@Override
	public ClinicianResponse getFilteredCliniciansForCRO(QueryModel searchModel) {
		logger.debug("Process started getFilteredCliniciansForCRO for CRO");
		long jobStartTS = System.currentTimeMillis();
		List<Clinicians> croClinicianList = getCliniciansForCro(searchModel);

		ClinicianResponse response = new ClinicianResponse();
		List<MatchingClinicians> clinician1572 = new ArrayList<MatchingClinicians>();
		List<Clinicians> questClinicianList = //getFilteredCliniciansForAll(searchModel);
				getCliniciansFromCache(getFilteredCliniciansForAllNew(searchModel));
		if (!questClinicianList.isEmpty()) {
			List<String> npiList = getNPIsFromList(questClinicianList);
			clinician1572 = getMatchingClinicians(searchModel, CommonConstant.NPI_1572, npiList, false);

		}

		List<Clinicians> intersectionOfQDAnd1572 = (clinician1572 != null && !clinician1572.isEmpty())
				? clinician1572.get(0).getData()
				: null;
		List<String> npi1572AndQuest = getNPIsFromList(intersectionOfQDAnd1572);
		List<MatchingClinicians> clinician1572Cro = new ArrayList<>();
		clinician1572Cro = getMatchingClinicians(searchModel, CommonConstant.CRO, npi1572AndQuest,
				!searchModel.getHasExport());
		// List<Clinicians> intersectionOfQDAndCroAnd1572 = clinician1572Cro.get(0) !=
		// null ? clinician1572Cro.get(0).getData() : null;

		List<Clinicians> npi1572ClinicianList = getCliniciansFor1572(searchModel);
		List<String> npi1572List = getNPIsFromList(npi1572ClinicianList);
		List<MatchingClinicians> clinician1572AndCro = new ArrayList<>();
		clinician1572AndCro = getMatchingClinicians(searchModel, CommonConstant.CRO, npi1572List,
				!searchModel.getHasExport());

		Set<Clinicians> croAndQuestresult = questClinicianList.stream().distinct().filter(croClinicianList::contains)
				.collect(Collectors.toSet());
		List<Clinicians> intersectionOfQDAndCro = croAndQuestresult.stream().collect(Collectors.toList());
		int croCount = croClinicianList != null ? croClinicianList.size() : 0;
		DataCount dc = new DataCount();
		dc.setCount1572(npi1572ClinicianList != null ? npi1572ClinicianList.size() : 0);
		dc.setQuestAnd1572Count((clinician1572 != null && !clinician1572.isEmpty())
				? clinician1572.get(0).getMatched_as_per_criteria_Count()
				: 0);
		dc.setQuestCount(questClinicianList != null ? questClinicianList.size() : 0);
		dc.setCroAnd1572Count((clinician1572AndCro != null && !clinician1572AndCro.isEmpty())
				? clinician1572AndCro.get(0).getMatched_as_per_criteria_Count()
				: 0);
		dc.setCroCount(croCount);
		dc.setQuestAndCroCount(intersectionOfQDAndCro != null ? intersectionOfQDAndCro.size() : 0);
		dc.setQuestAndCroAnd1572Count((clinician1572Cro != null && clinician1572Cro.get(0) != null)
				? clinician1572Cro.get(0).getMatched_as_per_criteria_Count()
				: 0);
		dc.setTotalCount(croCount);
		response = mapToResponseObject(getPaginatedList(croClinicianList, searchModel), searchModel);
		response.setDataCount(dc);
		logger.info("Returning clinicians based on project '{}' and total count is :{}", searchModel.getProject(),
				croCount);
		
		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job is {} sec", CRO_CLINICIANS, (long) ((jobEndTS - jobStartTS) / 1000));
		
		return response;

	}

	/*
	 * This method will be used to fetch matching clinician data of CRO and 1572 as
	 * passing source
	 * 
	 * @param , Source it can be the name of collection from where we have to get
	 * data.
	 * 
	 * @see com.questdiagnostics.clinicianservice.service.ClinicianService#
	 * getCliniciansForSource(java.lang.String)
	 */
	@Override
	public ClinicianResponse getCliniciansFor1572AndCRO(QueryModel search) {
		logger.debug("Process started getCliniciansFor1572AndCRO for 1572 and CRO");

		long jobStartTS = System.currentTimeMillis();
		/* Fetch data from 1572 */
		List<Clinicians> npi1572ClinicianList = getCliniciansFor1572(search);
		/* Fetch data from CRO */
		List<String> npi1572 = getNPIsFromList(npi1572ClinicianList);
		List<MatchingClinicians> clinician1572Cro = getMatchingClinicians(search, CommonConstant.CRO, npi1572,
				!search.getHasExport());
		List<Clinicians> intersectionOf1572AndCro = clinician1572Cro.get(0) != null ? clinician1572Cro.get(0).getData()
				: null;
		int intersectionOf1572AndCroSize = clinician1572Cro.get(0) != null
				? clinician1572Cro.get(0).getMatched_as_per_criteria_Count()
				: 0;
		ClinicianResponse response = new ClinicianResponse();
		DataCount dc = new DataCount();
		if (intersectionOf1572AndCroSize > 0) {
			response = mapToResponseObject(intersectionOf1572AndCro, search);
		}
		dc.setCroAnd1572Count(intersectionOf1572AndCroSize);
		dc.setTotalCount(intersectionOf1572AndCroSize);
		response.setDataCount(dc);
		logger.info("Returning clinicians from 1572 and CRO and count is : {} ", intersectionOf1572AndCroSize);

		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job is {} sec", CommonConstant.NPI_1572_CRO_SOURCE, (long) ((jobEndTS - jobStartTS) / 1000));
		
		return response;
	}

	private List<Clinicians> getCliniciansFor1572(QueryModel searchModel) {
		/* Fetch data from 1572 */
		List<Clinicians> npi1572ClinicianList = template.findAll(Clinicians.class, mongoNPI1572CollectionName);
		return npi1572ClinicianList;
	}

	private List<MatchingClinicians> getMatchingClinicians(QueryModel searchModel, String source, List<String> npiList,
			boolean pagination) {
		logger.debug("Process started getMatchingClinicians matching clinicians ");
		long jobStartTS = System.currentTimeMillis();
		List<MatchingClinicians> matchingClinicians = new ArrayList<>();
		String collectionName = getCollectionName(source);
		if (!StringUtils.isEmpty(collectionName) && npiList != null) {
			Criteria cr;
			if (collectionName.equalsIgnoreCase(mongoCROCollectionName) && searchModel.getProject() != null) {
				cr = new Criteria("npi").in(npiList)
						.andOperator(Criteria.where("project").is(searchModel.getProject()));
			} else {
				cr = new Criteria("npi").in(npiList);
			}
			FacetOperation facetOpr;
			if (pagination) {
				MongoPageRequest pageRequest = searchModel.getMongoPageRequest();

				facetOpr = Aggregation
						.facet(Aggregation.match(cr),
								Aggregation.skip(pageRequest.getPageNumber() * pageRequest.getPageSize()),
								Aggregation.limit(pageRequest.getPageSize()))
						.as("data").and(Aggregation.match(cr), Aggregation.group("npi").count().as("total"))
						.as("reqCount").and(Aggregation.group("_id").count().as("count")).as("totalCount");
			} else {
				facetOpr = Aggregation.facet(Aggregation.match(cr)).as("data")
						.and(Aggregation.match(cr), Aggregation.group("npi").count().as("total")).as("reqCount")
						.and(Aggregation.group("_id").count().as("count")).as("totalCount");
			}

			ProjectionOperation projectToMatchModel = Aggregation.project().and("totalCount").size()
					.as("total_record_in_db").and("reqCount").size().as("matched_as_per_criteria_Count");
			ProjectionOperation projectStage = projectToMatchModel.andInclude("data");
			Aggregation aggregation = Aggregation.newAggregation(facetOpr, projectStage)
					.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());

			AggregationResults<MatchingClinicians> output = template.aggregate(aggregation, collectionName,
					MatchingClinicians.class);

			matchingClinicians = output.getMappedResults();
			long jobEndTS = System.currentTimeMillis();
			logger.info("Time taken for {} job is {} sec",
					collectionName.equalsIgnoreCase(mongoCROCollectionName) ? "MACHING_CLINICIAN-CRO"
							: "MACHING_CLINICIAN-1572",	(long) ((jobEndTS - jobStartTS) / 1000));
			return matchingClinicians;
		}
		return matchingClinicians;
	}

	// @Cacheable(value="clinicianFind", key="#project")
	private List<Clinicians> getCliniciansForCro(QueryModel searchModel) {
		/* Fetch data from cro */

		Query query = new Query();
		query.addCriteria(
				Criteria.where("project").is(searchModel.getProject() != null ? searchModel.getProject().trim() : ""));

		List<Clinicians> croClinicianList = template.find(query, Clinicians.class, mongoCROCollectionName);

		return croClinicianList;
	}

	private ClinicianResponse mapToResponseObject(List<Clinicians> list, QueryModel model) {
		logger.info("Preparing response mapToResponseObject for UI ");

		if (model.getSource().equals(CommonConstant.QUEST_NPI_1572)) {
			list.forEach(f -> f.setSource(CommonConstant.QUEST_NPI_1572_SOURCE));
		} else if (model.getSource().equals(CommonConstant.NPI_1572_CRO)) {
			list.forEach(f -> f.setSource(CommonConstant.NPI_1572_CRO_SOURCE));

		} else if (model.getSource().equals(CommonConstant.QUEST_CRO)) {
			list.forEach(f -> f.setSource(CommonConstant.QUEST_CRO_SOURCE));

		} else if (model.getSource().equals(CommonConstant.QUEST_NPI_1572_CRO)) {
			list.forEach(f -> f.setSource(CommonConstant.QUEST_NPI_1572_CRO_SOURCE));
		}
		list.forEach(clinician -> clinician.setAddress(clinician.getAddress1() + " " + clinician.getAddress2()));

		Type listType = new TypeToken<List<ClinicianModel>>() {
		}.getType();
		List<ClinicianModel> returnValue = new ModelMapper().map(list, listType);

		ClinicianResponse response = new ClinicianResponse();
		if (returnValue != null && returnValue.size() > 0) {
			response.setData(returnValue);
			response.setStatus(HttpStatus.OK.value());
			response.setMessage("Got Data");
		} else {
			response.setMessage("No Data found");
		}
		return response;
	}

	private String getCollectionName(String source) {
		if (source.equalsIgnoreCase(CommonConstant.QUEST))
			return mongoQuestCollectionName;
		else if (source.equalsIgnoreCase(CommonConstant.NPI_1572))
			return mongoNPI1572CollectionName;
		else if (source.equalsIgnoreCase(CommonConstant.CRO))
			return mongoCROCollectionName;
		return mongoQuestCollectionName;
	}

	@Override
	public ClinicianResponse getCliniciansForQuestAndCRO(QueryModel queryModel) {
		logger.debug("Process started getCliniciansForQuestAndCRO for Quest and CRO ");
		long jobStartTS = System.currentTimeMillis();
		ClinicianResponse response = new ClinicianResponse();
		DataCount dc = new DataCount();
		List<Clinicians> clinicianList = //getFilteredCliniciansForAll(queryModel);
				getCliniciansFromCache(getFilteredCliniciansForAllNew(queryModel));
		if (clinicianList == null || clinicianList.size() < 1) {
			response.setDataCount(dc);
			return response;
		}
		List<String> questNpi = getNPIsFromList(clinicianList);
		List<MatchingClinicians> croClinicianList = getMatchingClinicians(queryModel, CommonConstant.CRO, questNpi,
				!queryModel.getHasExport());
		List<Clinicians> intersectionOfQDAndCroNpiList = croClinicianList.get(0) != null
				? croClinicianList.get(0).getData()
				: null;
		List<Clinicians> intersectionOfQDAndCro = getQuestClinicianMatchedWithOthers(clinicianList,
				intersectionOfQDAndCroNpiList);
		if (intersectionOfQDAndCro != null && intersectionOfQDAndCro.size() > 0) {
			dc.setQuestAndCroCount(croClinicianList.get(0).getMatched_as_per_criteria_Count());
			dc.setTotalCount(croClinicianList.get(0).getMatched_as_per_criteria_Count());
			response = mapToResponseObject(intersectionOfQDAndCro, queryModel);
			logger.info("Returning clinicians from Quest and CRO and count is : {} ", intersectionOfQDAndCro.size());
		}
		response.setDataCount(dc);
		long jobEndTS = System.currentTimeMillis();
		logger.info("Time taken for {} job is {} sec", CommonConstant.QUEST_CRO_SOURCE, (long) ((jobEndTS - jobStartTS) / 1000));
		
		return response;

	}

	private List<Clinicians> getPaginatedList(List<Clinicians> list, QueryModel model) {
		if (model.getHasExport()) {
			return list;
		}
		MongoPageRequest pageRequest = model.getMongoPageRequest();
		int pageNum = pageRequest.getPageNumber();
		int pageSize = pageRequest.getPageSize();
		int from = pageNum * pageSize;
		int to = from + pageSize;

		List<Clinicians> slice = getSlice(list.stream(), from, to).collect(Collectors.toList());

		return slice;
	}

	// Generic function to get Slice of a Stream from fromIndex to toIndex
	private Stream<Clinicians> getSlice(Stream<Clinicians> stream, int fromIndex, int toIndex) {
		return stream
				// specify the number of elements to skip
				.skip(fromIndex)
				// specify the no. of elements the stream should be limited to
				.limit(toIndex - fromIndex);
	}
}