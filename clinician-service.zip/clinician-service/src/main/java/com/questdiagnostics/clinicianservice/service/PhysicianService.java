package com.questdiagnostics.clinicianservice.service;

import java.util.List;

import com.questdiagnostics.clinicianservice.model.PhysicianCampaignCSVRequestModel;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignRequestModel;
import com.questdiagnostics.clinicianservice.model.PhysicianRequestModel;
import com.questdiagnostics.clinicianservice.model.ResponseObjectModel;
import com.questdiagnostics.clinicianservice.model.UpdateNoteRequest;

public interface PhysicianService {

	public ResponseObjectModel getPhysicianData(PhysicianRequestModel physicianModel);

	public ResponseObjectModel getPhysicianCampaignData(PhysicianCampaignRequestModel physicianCampaignRequestModel);

	public ResponseObjectModel getPhysicianCampaignFetchHistory(
			PhysicianCampaignRequestModel physicianCampaignRequestModel);

	public ResponseObjectModel updatePhysicianNote(UpdateNoteRequest updateNote);

	public ResponseObjectModel getPhysicianCSVData(PhysicianRequestModel physicianRequestModel) throws Exception;

	public ResponseObjectModel getPhysicianCampaignDataForCSV(
			PhysicianCampaignRequestModel physicianCampaignRequestModel) throws Exception;

	public ResponseObjectModel getCsvSASUrl(PhysicianRequestModel physicianRequestModel);

	public ResponseObjectModel getPhysicianCampaignDataForCSV(
			PhysicianCampaignCSVRequestModel physicianCampaignCSVRequestModel) throws Exception;

	public ResponseObjectModel getPhysicianCampaignBatchStatus(List<PhysicianCampaignMaster> physicianCampaignMaster);


}
