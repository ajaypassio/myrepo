package com.questdiagnostics.clinicianservice.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.FacetOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.microsoft.azure.storage.StorageException;
import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums;
import com.questdiagnostics.clinicianservice.messaging.util.PhysicianCommonUtil;
import com.questdiagnostics.clinicianservice.model.CampaignBatchData;
import com.questdiagnostics.clinicianservice.model.CurrentStatus;
import com.questdiagnostics.clinicianservice.model.DisplayCampaignRecord;
import com.questdiagnostics.clinicianservice.model.DisplayRecord;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignCSVRequestModel;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignMaster;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignRequestModel;
import com.questdiagnostics.clinicianservice.model.PhysicianData;
import com.questdiagnostics.clinicianservice.model.PhysicianDatas;
import com.questdiagnostics.clinicianservice.model.PhysicianRequestModel;
import com.questdiagnostics.clinicianservice.model.ResponseObjectModel;
import com.questdiagnostics.clinicianservice.model.UpdateNoteRequest;
import com.questdiagnostics.clinicianservice.model.ViewHistory;
import com.questdiagnostics.clinicianservice.response.model.PhysicianDisplayCampaignRecords;
import com.questdiagnostics.clinicianservice.util.CSVHelper;
import com.questdiagnostics.clinicianservice.util.SASGenerationUtil;

@Service
public class PhysicianServiceImpl implements PhysicianService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private MongoTemplate template;

	@Autowired
	private SASGenerationUtil sasGenerationUtil;
	
	@Autowired
	PhysicianCommonUtil physicianCommonUtil;
	
	/**
	 * This Method will be used to fetch the Data grid value for the Last search
	 * screen based on the multiple data filters like Specialty, state, source
	 */	
	@Override
	public ResponseObjectModel getPhysicianData(PhysicianRequestModel physicianModel) {

		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		 String collectionName = physicianModel.getUserName() + "_physician";
		 //String collectionName = CommonConstant.COLLECTION;
		if (!StringUtils.isEmpty(collectionName)) {
			Criteria criteria = getCriteria(physicianModel);
			FacetOperation facetOpr;
			ProjectionOperation projectToMatchModel;
			ProjectionOperation projectStage;
				facetOpr = Aggregation
						.facet(Aggregation.match(criteria),
								Aggregation.skip(physicianModel.getMongoPageRequest().getPageNumber() * physicianModel.getMongoPageRequest().getPageSize()),
								Aggregation.limit(physicianModel.getMongoPageRequest().getPageSize()),
								Aggregation.sort(Sort.Direction.ASC, "npi"))
						.as("physicianData")
						.and(Aggregation.match(criteria),
								Aggregation.group("npi").count().as("total"))
						.as("reqCount");
				projectToMatchModel = Aggregation.project().and("reqCount").size().as("total_record_in_db");
				projectStage = projectToMatchModel.andInclude("physicianData");
				
				Aggregation aggregation = Aggregation.newAggregation(facetOpr, projectStage)
						.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());
				AggregationResults<PhysicianDatas> output = template.aggregate(aggregation, collectionName,
						PhysicianDatas.class);
				List<PhysicianDatas> matchingPatientList = output.getMappedResults();
				
				if(!ObjectUtils.isEmpty(matchingPatientList.get(0).getPhysicianData())){
					List<DisplayRecord> listOfDisplayRecord = new ArrayList<>();
					for (PhysicianData physicianCampaignData : matchingPatientList.get(0).getPhysicianData()) {
						physicianCampaignData.getDisplayRecord().setSource(physicianModel.getSource());
						listOfDisplayRecord.add(physicianCampaignData.getDisplayRecord());
					}
						responseObjectModel.setTotal(matchingPatientList.get(0).getTotal_record_in_db());
						responseObjectModel.setData(listOfDisplayRecord);
						responseObjectModel.setHttpStatus(HttpStatus.OK);
						responseObjectModel.setMessage(CommonConstant.SUCCESS);
					}else{
						responseObjectModel.setTotal(0);
						responseObjectModel.setData(null);
						responseObjectModel.setHttpStatus(HttpStatus.OK);
						responseObjectModel.setMessage(CommonConstant.NO_DATA_AVAILABLE);
					}
			return responseObjectModel;

		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USER_COLLECTION_NOT_FOUND);
			return responseObjectModel;
		}
	}

	/**
	 * Preparing the criteria for the data grid query on search screen
	 */
	public Criteria getCriteria(PhysicianRequestModel physicianModel) {
		Criteria criteria = null;
		Criteria criteriaSpecialtyAndState = new Criteria();

		if (!physicianModel.getSource().equalsIgnoreCase(CommonConstant.SOURCE_QUEST)) {
			criteria = Criteria.where("isBmis").is(CommonConstant.TRUE);
		}

		// If specialty filter is applied another criteria will be added to the query.
		if (!StringUtils.isEmpty(physicianModel.getSpeciality())) {
			criteriaSpecialtyAndState = Criteria.where("displayRecord.specialty")
					.in(physicianModel.getSpeciality().split("_"));
		}
		// If state filter is applied another criteria will be added to the query for
		// state.
		if (!StringUtils.isEmpty(physicianModel.getState())) {
			criteriaSpecialtyAndState
					.andOperator(Criteria.where("displayRecord.state").in(physicianModel.getState().split(",")));
		}

		if (!StringUtils.isEmpty(criteria))
			criteria = criteria.andOperator(criteriaSpecialtyAndState);
		else
			criteria = criteriaSpecialtyAndState;
		return criteria;
	}

	@Override
	public ResponseObjectModel getPhysicianCampaignData(PhysicianCampaignRequestModel physicianCampaignRequestModel) {
		logger.info("process started to fetching campaign data for user : {}",
				physicianCampaignRequestModel.getUserName());
		Query query = new Query();
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (!StringUtils.isEmpty(physicianCampaignRequestModel.getUserName())
				&& physicianCampaignRequestModel.getCampaignId() != 0) {

			Criteria criteria = getFilteredData(physicianCampaignRequestModel);
			FacetOperation facetOpr;
			ProjectionOperation projectToMatchModel;
			ProjectionOperation projectStage;
				facetOpr = Aggregation
						.facet(Aggregation.match(criteria),
								Aggregation.skip(physicianCampaignRequestModel.getMongoPageRequest().getPageNumber() * physicianCampaignRequestModel.getMongoPageRequest().getPageSize()),
								Aggregation.limit(physicianCampaignRequestModel.getMongoPageRequest().getPageSize()),
								Aggregation.sort(Sort.Direction.ASC, "npi"))
						.as("physicianCampaignData")
						.and(Aggregation.match(criteria),
								Aggregation.group("npi").count().as("total"))
						.as("reqCount");
				projectToMatchModel = Aggregation.project().and("reqCount").size().as("total_record_in_db");
				projectStage = projectToMatchModel.andInclude("physicianCampaignData");
								
				Aggregation aggregation = Aggregation.newAggregation(facetOpr, projectStage)
						.withOptions(Aggregation.newAggregationOptions().allowDiskUse(true).build());
				AggregationResults<PhysicianDisplayCampaignRecords> output = template.aggregate(aggregation,buildCollection(physicianCampaignRequestModel.getUserName(),
						physicianCampaignRequestModel.getCampaignId()),PhysicianDisplayCampaignRecords.class);
				List<PhysicianDisplayCampaignRecords> matchingPatientList = output.getMappedResults();
			
			if(!ObjectUtils.isEmpty(matchingPatientList.get(0).getPhysicianCampaignData())){
			List<DisplayCampaignRecord> listOfDisplayCampaignRecord = new ArrayList<>();
			for (PhysicianCampaignData physicianCampaignData : matchingPatientList.get(0).getPhysicianCampaignData()) {
				listOfDisplayCampaignRecord.add(physicianCampaignData.getDisplayCampaignRecord());
			}
			
				responseObjectModel.setTotal(matchingPatientList.get(0).getTotal_record_in_db());
				responseObjectModel.setData(listOfDisplayCampaignRecord);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(CommonConstant.SUCCESS);
			}else{
				responseObjectModel.setTotal(0);
				responseObjectModel.setData(null);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(CommonConstant.NO_DATA_AVAILABLE);
			}
			
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USERNAME_NPI_VALIDATION);
		}

		logger.info("process completed to fetching campaign data");
		return responseObjectModel;
	}

	// Build Collection
	private String buildCollection(String userName, long campaignId) {
		return new StringBuilder(userName).append(CommonConstant.UNDER_SCORE).append(campaignId)
				.append(CommonConstant.UNDER_SCORE).append(CommonConstant.CAMPAIGN_COL_SUFFIX).toString();
	}

	/**
	 * get the filtered criteria for the Campaign Get Screen using filters
	 */
	public Criteria getFilteredData(PhysicianCampaignRequestModel physicianCampaignRequestModel) {
		Criteria criteriaNPI = null;
		Criteria criteriaFirstName = null;
		Criteria criteriaLastName = null;
		Criteria criteriaDirectMail = null;
		Criteria criteriaPhoneCall = null;
		Criteria criteriaEmail = null;
		Criteria criteria = new Criteria();

		if (physicianCampaignRequestModel.getNpi() != 0)
			criteriaNPI = Criteria.where("displayCampaignRecord.npi").is(physicianCampaignRequestModel.getNpi());
		if (!StringUtils.isEmpty(physicianCampaignRequestModel.getFirstName()))
			criteriaFirstName = Criteria.where("displayCampaignRecord.first_name")
					.regex(physicianCampaignRequestModel.getFirstName(), "i");
		if (!StringUtils.isEmpty(physicianCampaignRequestModel.getLastName()))
			criteriaLastName = Criteria.where("displayCampaignRecord.last_name")
					.regex(physicianCampaignRequestModel.getLastName(), "i");
		if (physicianCampaignRequestModel.getDirectMail() != 0)
			criteriaDirectMail = Criteria.where("displayCampaignRecord.currentStatus.dm")
					.is(physicianCampaignRequestModel.getDirectMail());
		if (physicianCampaignRequestModel.getPhoneCall() != 0)
			criteriaPhoneCall = Criteria.where("displayCampaignRecord.currentStatus.pc")
					.is(physicianCampaignRequestModel.getPhoneCall());
		if (physicianCampaignRequestModel.getEmail() != 0)
			criteriaEmail = Criteria.where("displayCampaignRecord.currentStatus.em")
					.is(physicianCampaignRequestModel.getEmail());

		// If NPI filter is applied it will go to this section
		if (!StringUtils.isEmpty(criteriaNPI)) {
			if (!StringUtils.isEmpty(criteriaFirstName)) {
				if (!StringUtils.isEmpty(criteriaLastName)) {
					if (!StringUtils.isEmpty(criteriaDirectMail)) {
						if (!StringUtils.isEmpty(criteriaPhoneCall)) {
							if (!StringUtils.isEmpty(criteriaEmail)) {
								logger.info("All filter are applied by User including channel filter");
								criteria = criteriaNPI.andOperator(
										criteriaFirstName.andOperator(criteriaLastName.andOperator(new Criteria()
												.orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail))));
							} else {
								logger.info("All filter are applied by User except email channel filter");
								criteria = criteriaNPI
										.andOperator(criteriaFirstName.andOperator(criteriaLastName.andOperator(
												new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall))));
							}

						} else if (!StringUtils.isEmpty(criteriaEmail)) {
							logger.info("All filter are applied by User except phone Call channel filter");
							criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(criteriaLastName
									.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail))));
						} else {
							logger.info("All filter are applied by User except phone Call and Email channel filter");
							criteria = criteriaNPI.andOperator(
									criteriaFirstName.andOperator(criteriaLastName.andOperator(criteriaDirectMail)));
						}
					} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
						if (!StringUtils.isEmpty(criteriaEmail)) {
							logger.info("All filter are applied by User except Direct Mail channel filter");
							criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(criteriaLastName
									.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail))));
						} else {
							logger.info("All filter are applied by User except Direct Mail and email channel filter");
							criteria = criteriaNPI.andOperator(
									criteriaFirstName.andOperator(criteriaLastName.andOperator(criteriaPhoneCall)));
						}

					} else if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("All filter are applied by User except Direct Mail and phone channel filter");
						criteria = criteriaNPI.andOperator(
								criteriaFirstName.andOperator(criteriaLastName.andOperator(criteriaEmail)));
					} else {
						logger.info("All filter are applied by User except any channel filter");
						criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(criteriaLastName));
					}
				}
				// LOOPS for 3rd iteration
				else if (!StringUtils.isEmpty(criteriaDirectMail)) {
					if (!StringUtils.isEmpty(criteriaPhoneCall)) {
						if (!StringUtils.isEmpty(criteriaEmail)) {
							logger.info("All filter are applied by User except LastName filter");
							criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(
									new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail)));
						} else {
							logger.info("All filter are applied by User except Lastname and email channel filter");
							criteria = criteriaNPI.andOperator(criteriaFirstName
									.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall)));
						}
					} else if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("All filter are applied by User except Lastname and phone Call channel filter");
						criteria = criteriaNPI.andOperator(criteriaFirstName
								.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail)));
					} else {
						logger.info(
								"All filter are applied by User except Lastname , phone Call and email channel filter");
						criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(criteriaDirectMail));
					}

				} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
					if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("All filter are applied by User except Lastname and Direct Mail filter");
						criteria = criteriaNPI.andOperator(criteriaFirstName
								.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail)));
					} else {
						logger.info("All filter are applied by User except Lastname Direct Mail, email channel filter");
						criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(criteriaPhoneCall));
					}

				} else if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info(
							"All filter are applied by User except Lastname, Direct Mail and phone Call channel filter");
					criteria = criteriaNPI.andOperator(criteriaFirstName.andOperator(criteriaEmail));
				} else {
					logger.info(
							"All filter are applied by User except Lastname, Direct Mail, phone Call and Email channel filter");
					criteria = criteriaNPI.andOperator(criteriaFirstName);
				}

				// TODO ELSE if from 4
			} else if (!StringUtils.isEmpty(criteriaLastName)) {
				if (!StringUtils.isEmpty(criteriaDirectMail)) {
					if (!StringUtils.isEmpty(criteriaPhoneCall)) {

						if (!StringUtils.isEmpty(criteriaEmail)) {
							logger.info("All filter are applied by User except First Name filter");
							criteria = criteriaNPI.andOperator(criteriaLastName.andOperator(
									new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail)));
						} else {
							logger.info("All filter are applied by User except first Name and email channel filter");
							criteria = criteriaNPI.andOperator(criteriaLastName
									.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall)));
						}

					} else if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("All filter are applied by User except first Name and phone Call channel filter");
						criteria = criteriaNPI.andOperator(criteriaLastName
								.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail)));
					} else {
						logger.info(
								"All filter are applied by User except First Name, phone Call and Email channel filter");
						criteria = criteriaNPI.andOperator(criteriaLastName.andOperator(criteriaDirectMail));
					}
				} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
					if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("All filter are applied by User except First Name and Direct channel filter");
						criteria = criteriaNPI.andOperator(criteriaLastName
								.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail)));
					} else {
						logger.info(
								"All filter are applied by User except First Name, Direct Mail and email channel filter");
						criteria = criteriaNPI.andOperator(criteriaLastName.andOperator(criteriaPhoneCall));
					}

				} else if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info(
							"All filter are applied by User except First Name, Direct Mail and phone Call channel filter");
					criteria = criteriaNPI.andOperator(criteriaLastName.andOperator(criteriaEmail));
				} else {
					logger.info("All filter are applied by User except First Name and any channel filter");
					criteria = criteriaNPI.andOperator(criteriaLastName);
				}

			} else if (!StringUtils.isEmpty(criteriaDirectMail)) {
				if (!StringUtils.isEmpty(criteriaPhoneCall)) {

					if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("All filter are applied by User except Lastname and First Name filter");
						criteria = criteriaNPI.andOperator(
								new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail));
					} else {
						logger.info(
								"All filter are applied by User except First Name, Lastname and email channel filter");
						criteria = criteriaNPI
								.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall));
					}

				} else if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only NPI filter, direct mail and email channel filter is applied");
					criteria = criteriaNPI.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail));
				} else {
					logger.info("Only NPI filter and direct mail channel filter is applied");
					criteria = criteriaNPI.andOperator(criteriaDirectMail);
				}

			} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
				if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only NPI filter, phone call and email channel filter is applied");
					criteria = criteriaNPI.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail));
				} else {
					logger.info("Only NPI filter and phone call channel filter is applied");
					criteria = criteriaNPI.andOperator(criteriaPhoneCall);
				}

			} else if (!StringUtils.isEmpty(criteriaEmail)) {
				logger.info("Only NPI filter and email channel filter is applied");
				criteria = criteriaNPI.andOperator(criteriaEmail);
			} else {
				logger.info("Only NPI filter is applied");
				criteria = criteriaNPI;
			}

		}
		// If NPI filter is not applied but FirstName filter is available it will go to
		// this section
		else if (!StringUtils.isEmpty(criteriaFirstName)) {
			// Loop for Filter 2
			if (!StringUtils.isEmpty(criteriaLastName)) {
				if (!StringUtils.isEmpty(criteriaDirectMail)) {
					if (!StringUtils.isEmpty(criteriaPhoneCall)) {

						if (!StringUtils.isEmpty(criteriaEmail)) {
							logger.info(
									"Only First Name, Last Name, Direct Mail, Phone call and email channel filter is applied");
							criteria = criteriaFirstName.andOperator(criteriaLastName.andOperator(
									new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail)));
						} else {
							logger.info(
									"Only First Name, Last Name, Direct Mail and Phone call channel filter is applied");
							criteria = criteriaFirstName.andOperator(criteriaLastName
									.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall)));
						}

					} else if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("Only First Name, Last Name , Direct Mail and email channel filter is applied");
						criteria = criteriaFirstName.andOperator(criteriaLastName
								.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail)));
					} else {
						logger.info("Only First Name, Last Name and Direct Mail channel filter is applied");
						criteria = criteriaFirstName.andOperator(criteriaLastName.andOperator(criteriaDirectMail));
					}
				} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
					if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("Only First Name, Last Name Phone call and email channel filter is applied");
						criteria = criteriaFirstName.andOperator(criteriaLastName
								.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail)));
					} else {
						logger.info("Only First Name, Last Name and Phone call channel filter is applied");
						criteria = criteriaFirstName.andOperator(criteriaLastName.andOperator(criteriaPhoneCall));
					}

				} else if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only First Name,Last Name and email channel filter is applied");
					criteria = criteriaFirstName.andOperator(criteriaLastName.andOperator(criteriaEmail));
				} else {
					logger.info("Only First Name and Last Name filter is applied");
					criteria = criteriaFirstName.andOperator(criteriaLastName);
				}
			} else if (!StringUtils.isEmpty(criteriaDirectMail)) {
				if (!StringUtils.isEmpty(criteriaPhoneCall)) {
					if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("Only First Name Direct Mail, Phone call and email channel filter is applied");
						criteria = criteriaFirstName.andOperator(
								new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail));
					} else {
						logger.info("Only First Name, Direct Mail and Phone call channel filter is applied");
						criteria = criteriaFirstName
								.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall));
					}

				} else if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only First Name , Direct Mail and email channel filter is applied");
					criteria = criteriaFirstName
							.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail));
				} else {
					logger.info("Only First Name and Direct Mail channel filter is applied");
					criteria = criteriaFirstName.andOperator(criteriaDirectMail);
				}

			} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
				if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only First Name, Phone call and email channel filter is applied");
					criteria = criteriaFirstName
							.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail));
				} else {
					logger.info("Only First Name and Phone Call channel filter is applied");
					criteria = criteriaFirstName.andOperator(criteriaPhoneCall);
				}

			} else if (!StringUtils.isEmpty(criteriaEmail)) {
				logger.info("Only First Name and email channel filter is applied");
				criteria = criteriaFirstName.andOperator(criteriaEmail);
			} else {
				logger.info("Only First filter is applied");
				criteria = criteriaFirstName;
			}

		}
		// If NPI and firstName filter is not applied but LastName filter is available
		// it will go to this section
		else if (!StringUtils.isEmpty(criteriaLastName)) {
			// Loop for Filter 3
			if (!StringUtils.isEmpty(criteriaDirectMail)) {
				if (!StringUtils.isEmpty(criteriaPhoneCall)) {
					if (!StringUtils.isEmpty(criteriaEmail)) {
						logger.info("Only Last Name Direct Mail , Phone call and email channel filter is applied");
						criteria = criteriaLastName.andOperator(
								new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail));
					} else {
						logger.info("Only Last Name , Direct Mail and Phone call channel filter is applied");
						criteria = criteriaLastName
								.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall));
					}

				} else if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only Last Name , Direct mail and email channel filter is applied");
					criteria = criteriaLastName
							.andOperator(new Criteria().orOperator(criteriaDirectMail, criteriaEmail));
				} else {
					logger.info("Only Last Name and Direct Mail channel filter is applied");
					criteria = criteriaLastName.andOperator(criteriaDirectMail);
				}

			} else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
				if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only Last Name, Phone call and email channel filter is applied");
					criteria = criteriaLastName
							.andOperator(new Criteria().orOperator(criteriaPhoneCall, criteriaEmail));
				} else {
					logger.info("Only Last Name and Phone call channel filter is applied");
					criteria = criteriaLastName.andOperator(criteriaPhoneCall);
				}
			} else if (!StringUtils.isEmpty(criteriaEmail)) {
				logger.info("Only Last Name and email channel filter is applied");
				criteria = criteriaLastName.andOperator(criteriaEmail);
			} else {
				logger.info("Only Last Name filter is applied");
				criteria = criteriaLastName;
			}
			// TODO loop 3 completion

		}
		// If NPI,firstName, LastName filter is not applied but Direct Mail channel
		// filter is available it will go to this section
		else if (!StringUtils.isEmpty(criteriaDirectMail)) {
			// Loop for Filter 4
			if (!StringUtils.isEmpty(criteriaPhoneCall)) {
				if (!StringUtils.isEmpty(criteriaEmail)) {
					logger.info("Only Direct Mail, phone call and email channel filter is applied");
					criteria = new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall, criteriaEmail);
				} else {
					logger.info("Only Direct Mail and Phone call channel filter is applied");
					criteria = new Criteria().orOperator(criteriaDirectMail, criteriaPhoneCall);
				}

			} else if (!StringUtils.isEmpty(criteriaEmail)) {
				logger.info("Only Direct Mail and email channel filter is applied");
				criteria = new Criteria().orOperator(criteriaDirectMail, criteriaEmail);
			} else {
				logger.info("Only Direct Mail channel filter is applied");
				criteria = criteriaDirectMail;
			}
		}
		// If NPI,firstName, LastName, Direct Mail Channel filter is not applied but
		// Phone Call channel filter is available it will go to this section
		else if (!StringUtils.isEmpty(criteriaPhoneCall)) {
			// Loop for Filter 5
			if (!StringUtils.isEmpty(criteriaEmail)) {
				logger.info("Only phone call and email channel filter is applied");
				criteria = new Criteria().orOperator(criteriaPhoneCall, criteriaEmail);
			} else {
				logger.info("Only phone call channel filter is applied");
				criteria = criteriaPhoneCall;
			}

		}
		// If NPI,firstName, LastName, Direct Mail, Phone Call Channel filter is not
		// applied but email channel filter is available it will go to this section
		else if (!StringUtils.isEmpty(criteriaEmail)) {
			// Loop for Filter 6
			logger.info("Only email channal filter is applied");
			criteria = criteriaEmail;
		}
		return criteria;
	}

	@Override
	public ResponseObjectModel getPhysicianCampaignFetchHistory(
			PhysicianCampaignRequestModel physicianCampaignRequestModel) {
		long npi = physicianCampaignRequestModel.getNpi();
		logger.info("process started to fetching view history for NPI : {}", npi);
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (npi != 0 && !StringUtils.isEmpty(physicianCampaignRequestModel.getUserName())
				&& physicianCampaignRequestModel.getCampaignId() != 0) {
			Query query = new Query(Criteria.where("npi").is(npi));
			List<PhysicianCampaignData> physicianCampaignDataList = template.find(query, PhysicianCampaignData.class,
					buildCollection(physicianCampaignRequestModel.getUserName(),
							physicianCampaignRequestModel.getCampaignId()));
			physicianCampaignDataList.set(0, physicianCommonUtil.getHistoryDesc(physicianCampaignDataList.get(0)));
	
			if (!physicianCampaignDataList.isEmpty()) {
				responseObjectModel.setData(physicianCampaignDataList.get(0).getViewHistories());
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(CommonConstant.SUCCESS);
			}
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USERNAME_NPI_VALIDATION);
		}
		logger.info("process completed to fetching view history");
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel updatePhysicianNote(UpdateNoteRequest updateNote) {

		long npi = updateNote.getNpi();
		logger.info("process started to updating note for NPI : {}", npi);
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (npi != 0 && !StringUtils.isEmpty(updateNote.getCampaignUserName()) && updateNote.getCampaignId() != 0) {
			Query query = new Query(Criteria.where("npi").is(npi));
			List<PhysicianCampaignData> physicianCampaignDataList = template.find(query, PhysicianCampaignData.class,
					buildCollection(updateNote.getCampaignUserName(), updateNote.getCampaignId()));

			if (!physicianCampaignDataList.isEmpty()) {
				DisplayCampaignRecord displayCampaignRecord = physicianCampaignDataList.get(0)
						.getDisplayCampaignRecord();
				CurrentStatus currentStatus = displayCampaignRecord.getCurrentStatus();
				currentStatus.setDm(updateNote.getDm());
				currentStatus.setPc(updateNote.getPc());
				currentStatus.setEm(updateNote.getEm());
				displayCampaignRecord.setCurrentStatus(currentStatus);
				Update updateCurrentStatus = new Update();
				updateCurrentStatus.set("displayCampaignRecord", displayCampaignRecord);
				template.upsert(query, updateCurrentStatus,
						buildCollection(updateNote.getCampaignUserName(), updateNote.getCampaignId()));
				logger.info("updating current status completed for NPI : {}", npi);
				List<ViewHistory> listOfViewHistory = physicianCampaignDataList.get(0).getViewHistories();
				ViewHistory viewHistory = new ViewHistory();
				viewHistory.setDm(updateNote.getDm());
				viewHistory.setEm(updateNote.getEm());
				viewHistory.setNote(updateNote.getNote());
				viewHistory.setPc(updateNote.getPc());
				viewHistory.setUsername(updateNote.getUserName());
				viewHistory.setTransaciondate(estCurrentTime());
				listOfViewHistory.add(viewHistory);

				Update update = new Update();
				update.set("viewHistories", listOfViewHistory);
				template.upsert(query, update,
						buildCollection(updateNote.getCampaignUserName(), updateNote.getCampaignId()));
				logger.info("updating note completed for NPI : {}", npi);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(CommonConstant.SUCCESS);
			}
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USERNAME_NPI_VALIDATION);
		}
		logger.info("process completed to updating note");
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getPhysicianCSVData(PhysicianRequestModel physicianModel) throws Exception {
		logger.info("process started to getPhysicianCSVData for user : {}", physicianModel.getUserName());
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		List<PhysicianData> physicianDataList = new ArrayList<>();
		String collectionName = physicianModel.getUserName() + "_physician";
		// String collectionName = CommonConstant.COLLECTION;
		if (!StringUtils.isEmpty(collectionName)) {
			Criteria criteria = getCriteria(physicianModel);
			Query query = new Query(criteria);
			physicianDataList = template.find(query, PhysicianData.class, collectionName);

			ByteArrayInputStream byteArrayInputStream = CSVHelper.physicianUserCriteriaToCSV(physicianDataList);
			byte[] data = new byte[byteArrayInputStream.available()];
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			int nRead;
			while ((nRead = byteArrayInputStream.read(data, 0, data.length)) != -1) {
				buffer.write(data, 0, nRead);
			}
			String fileData = new String(buffer.toByteArray());
			String encodedString = new String(Base64.getEncoder().encode(fileData.getBytes()));
			buffer.flush();
			responseObjectModel.setData(encodedString);
			responseObjectModel.setMessage(CommonConstant.SUCCESS);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USERNAME_NPI_VALIDATION);
		}
		logger.info("process end to getPhysicianCSVData for user : {}", physicianModel.getUserName());
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getPhysicianCampaignDataForCSV(
			PhysicianCampaignRequestModel physicianCampaignRequestModel) throws Exception {
		logger.info("process started to getPhysicianCampaignDataForCSV for user : {}",
				physicianCampaignRequestModel.getUserName());
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		Query query = new Query();

		if (!StringUtils.isEmpty(physicianCampaignRequestModel.getUserName())
				&& physicianCampaignRequestModel.getCampaignId() != 0) {

			query.addCriteria(getFilteredData(physicianCampaignRequestModel));
			List<PhysicianCampaignData> physicianCampaignDataList = template.find(query, PhysicianCampaignData.class,
					buildCollection(physicianCampaignRequestModel.getUserName(),
							physicianCampaignRequestModel.getCampaignId()));

			ByteArrayInputStream byteArrayInputStream = CSVHelper.physicianCampaignDataToCSV(physicianCampaignDataList);
			byte[] data = new byte[byteArrayInputStream.available()];
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			int nRead;
			while ((nRead = byteArrayInputStream.read(data, 0, data.length)) != -1) {
				buffer.write(data, 0, nRead);
			}
			String fileData = new String(buffer.toByteArray());
			String encodedString = new String(Base64.getEncoder().encode(fileData.getBytes()));
			buffer.flush();
			responseObjectModel.setData(encodedString);
			responseObjectModel.setMessage(CommonConstant.SUCCESS);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USERNAME_CAMPAIGNID_VALIDATION);
		}
		logger.info("process completed to fetching campaign data for csv");
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getCsvSASUrl(PhysicianRequestModel physicianRequestModel) {
		logger.info("getCsvSASUrl method started---");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			String sasUrl = sasGenerationUtil.getBlobSASString(physicianRequestModel.getUserName());
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setData(sasUrl);
			responseObjectModel.setMessage("Success");
			logger.info("getCsvSASUrl method completed ---");
		} catch (InvalidKeyException | MalformedURLException | URISyntaxException | StorageException e) {
			logger.error("Error in generating SAS Url {}", e);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage("Error in generating SAS Url");
		}
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getPhysicianCampaignDataForCSV(
			PhysicianCampaignCSVRequestModel physicianCampaignCSVRequestModel) throws Exception {
		logger.info("process started to getPhysicianCampaignDataForCSV for user : {}",
				physicianCampaignCSVRequestModel.getUserName());
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		Query query = new Query();
		if (!StringUtils.isEmpty(physicianCampaignCSVRequestModel.getUserName())
				&& physicianCampaignCSVRequestModel.getCampaignId() != 0) {
			Criteria criteria = null;
			Long[] npiArray = physicianCampaignCSVRequestModel.getNpi();
			List<Long> physicianCampaignNpiList = Arrays.asList(npiArray);
			if (physicianCampaignNpiList != null && physicianCampaignNpiList.size() != 0) {
				criteria = Criteria.where("npi").in(physicianCampaignNpiList);
			}
			if (null != criteria) {
				query.addCriteria(criteria);
			}
			List<PhysicianCampaignData> physicianCampaignDataList = template.find(query, PhysicianCampaignData.class,
					buildCollection(physicianCampaignCSVRequestModel.getUserName(),
							physicianCampaignCSVRequestModel.getCampaignId()));

			ByteArrayInputStream byteArrayInputStream = CSVHelper.physicianCampaignDataToCSV(physicianCampaignDataList);
			byte[] data = new byte[byteArrayInputStream.available()];
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			int nRead;
			while ((nRead = byteArrayInputStream.read(data, 0, data.length)) != -1) {
				buffer.write(data, 0, nRead);
			}
			String fileData = new String(buffer.toByteArray());
			String encodedString = new String(Base64.getEncoder().encode(fileData.getBytes()));
			buffer.flush();
			responseObjectModel.setData(encodedString);
			responseObjectModel.setMessage(CommonConstant.SUCCESS);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
		} else {
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(CommonConstant.USERNAME_CAMPAIGNID_VALIDATION);
		}
		logger.info("process completed to fetching campaign data for csv");
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getPhysicianCampaignBatchStatus(List<PhysicianCampaignMaster> physicianCampaignMasters) {
		logger.info("process started of fetching PhysicianCampaignBatchStatus");
		Boolean isCampaignProcessing = false;
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		responseObjectModel.setData(isCampaignProcessing);
		responseObjectModel.setMessage("Success");
		for (PhysicianCampaignMaster physicianCampaignMaster : physicianCampaignMasters) {
			String campaignBatchCollectionName = buildCollection(physicianCampaignMaster);
			Query query = new Query(Criteria.where("campaignId").is(physicianCampaignMaster.getSprinttCampaignId()));
			CampaignBatchData campaignBatchData = template.findOne(query, CampaignBatchData.class,
					campaignBatchCollectionName);
			if (!ObjectUtils.isEmpty(campaignBatchData)
					&& !checkPhysicianCampaignJobStatus(campaignBatchData.getCampaignJobStatus())) {
				isCampaignProcessing = true;
				responseObjectModel.setData(isCampaignProcessing);
				break;
			}
		}
		logger.info("process completed of fetching PhysicianCampaignBatchStatus");
		return responseObjectModel;
	}

	public String buildCollection(PhysicianCampaignMaster physicianCampaignMaster) {
		return new StringBuilder(physicianCampaignMaster.getUserName()).append(CommonConstant.UNDER_SCORE)
				.append(physicianCampaignMaster.getSprinttCampaignId()).append(CommonConstant.UNDER_SCORE)
				.append(CommonConstant.CAMPAIGN_COL_SUFFIX).append(CommonConstant.UNDER_SCORE)
				.append(CommonConstant.CAMPAIGN_COL_BATCH_SUFFIX).toString();
	}

	public Boolean checkPhysicianCampaignJobStatus(Integer campaignJobStatusId) {
		if (campaignJobStatusId == PhysicianCampaignJobStatusEnums.CampaignCreationInitiated.getValue())
			return false;
		else
			return true;
	}

	private String estCurrentTime() {
		SimpleDateFormat destFormat = new SimpleDateFormat("MM-dd-yyyy hh:mm a");
		destFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		String date = destFormat.format(new Date());
		date = date + " " + "EST";
		return date;
	}

}
