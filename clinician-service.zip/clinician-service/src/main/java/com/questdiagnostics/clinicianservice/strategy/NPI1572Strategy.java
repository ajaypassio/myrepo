/**
 * 
 */
package com.questdiagnostics.clinicianservice.strategy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;
import com.questdiagnostics.clinicianservice.service.ClinicianService;

/**
 * @author ajaykuma
 *
 */
@Component("NPI1572Strategy")
public class NPI1572Strategy implements QueryStartegy {

	@Autowired
	private ClinicianService clinicianService;
	
	@Override
	public ClinicianResponse performQuery(QueryModel searchModel) {
		ClinicianResponse clinician = clinicianService.getFilteredCliniciansFor1572(searchModel);
		return clinician;

	}

}
