/**
 * 
 */
package com.questdiagnostics.clinicianservice.strategy;

import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;

/**
 * @author ajaykuma
 *
 */

public interface QueryStartegy {
	
	public ClinicianResponse performQuery(QueryModel queryModel);

}
