/**
 * 
 */
package com.questdiagnostics.clinicianservice.strategy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;
import com.questdiagnostics.clinicianservice.service.ClinicianService;

/**
 * @author ajaykuma
 *
 */
@Component("Quest1572AndCROStrategy")
public class Quest1572AndCROStrategy implements QueryStartegy {

	@Autowired
	private ClinicianService clinicianService;
	
	@Override
	public ClinicianResponse performQuery(QueryModel searchModel) {		
		ClinicianResponse clinician = clinicianService.getCliniciansForQuest1572AndCRO(searchModel);
		return clinician;

	}

}
