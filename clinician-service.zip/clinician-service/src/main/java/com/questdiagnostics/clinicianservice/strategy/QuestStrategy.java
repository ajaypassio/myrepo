/**
 * 
 */
package com.questdiagnostics.clinicianservice.strategy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;
import com.questdiagnostics.clinicianservice.service.ClinicianService;

/**
 * @author ajaykuma
 *
 */
@Component("QuestStrategy")
public class QuestStrategy implements QueryStartegy {
	
	private ClinicianService clinicianService;
	
	@Autowired
    public void setClinicianService(ClinicianService clinicianService) {
            this.clinicianService = clinicianService;
    }
	
	@Override
	public ClinicianResponse performQuery(QueryModel queryModel) {
		return clinicianService.getFilteredCliniciansForQuest(queryModel);	
	}

}
