/**
 * 
 */
package com.questdiagnostics.clinicianservice.strategy;

import org.springframework.stereotype.Component;

import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.response.model.ClinicianResponse;

/**
 * @author ajaykuma
 *
 */
@Component
public class StrategyContext {
	
	private QueryStartegy queryStartegy;
	
	/**
	 * @param queryStartegy the queryStartegy to set
	 */
	public void setQueryStartegy(QueryStartegy queryStartegy) {
		this.queryStartegy = queryStartegy;
	}
	
	public ClinicianResponse processQueryFilter(QueryModel queryModel) {
		return queryStartegy.performQuery(queryModel);
	}

}
