package com.questdiagnostics.clinicianservice.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.LinkedList;
import java.util.List;

import com.questdiagnostics.clinicianservice.constant.CommonConstant;
import com.questdiagnostics.clinicianservice.model.DisplayRecord;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;
import com.questdiagnostics.clinicianservice.model.PhysicianData;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

/**
 * CSVHelper class for download csv file
 * @author JaiveerS
 *
 */
public class CSVHelper {
	
	public static ByteArrayInputStream physicianUserCriteriaToCSV(List<PhysicianData> physicianDataList){
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		CsvWriter writer = new CsvWriter(out, new CsvWriterSettings()); 
		writer.writeHeaders( "NPI", "Physician First Name", "Physician Middle Name","Physician Last Name", "Source", "Specialty", "No. of Patients", 
				"Physician Address Line 1", "Physician Address Line 2", "City", "State", "Zip Code", "Phone Number","Email Address","Fax Number");
		for (PhysicianData physicianData : physicianDataList) {
			DisplayRecord displayRecord = physicianData.getDisplayRecord();
			writer.writeRow(
					displayRecord.getNpi(),
					displayRecord.getFirst_name(),
					displayRecord.getMiddle_name(),
					displayRecord.getLast_name(),
					physicianData.getIsBmis().equalsIgnoreCase("false") ? CommonConstant.SOURCE_QUEST: CommonConstant.SOURCE_QUEST1572,
					displayRecord.getSpecialty(),
					displayRecord.getNumber_of_patients(),
					displayRecord.getAddress1(),
					displayRecord.getAddress2(),
					displayRecord.getCity(),
					displayRecord.getState(),
					displayRecord.getZip(),
					displayRecord.getPhone_number(),
					displayRecord.getEmail_address(),
					displayRecord.getFax_number()
					);
		}
		writer.close();
		return new ByteArrayInputStream(out.toByteArray());
	}
	
	public static ByteArrayInputStream physicianCampaignDataToCSV(List<PhysicianCampaignData> physicianCampaignDataList){
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		CsvWriter writer = new CsvWriter(out, new CsvWriterSettings()); 
		writer.writeHeaders( "First Name", "Last Name", "Address Line 1", "Address Line 2", "City", "State", "Zip Code",
				"Physician's name", "Phone Number", "Fax Number", "Email Address");
		for (PhysicianCampaignData physicianCampaignData : physicianCampaignDataList) {
			DisplayRecord displayRecord = physicianCampaignData.getExportRecord();
			writer.writeRow(
					displayRecord.getFirst_name(),
					displayRecord.getLast_name(),
					displayRecord.getAddress1(),
					displayRecord.getAddress2(),
					displayRecord.getCity(),
					displayRecord.getState_abv(),
					displayRecord.getZip(),
					displayRecord.getFirst_name() + " " + displayRecord.getLast_name(), 
					displayRecord.getPhone_number(),
					displayRecord.getFax_number(),
					displayRecord.getEmail_address()
					);
		}
		writer.close();
		return new ByteArrayInputStream(out.toByteArray());
	}
	
}
