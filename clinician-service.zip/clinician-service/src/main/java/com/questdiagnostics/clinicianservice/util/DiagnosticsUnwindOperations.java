package com.questdiagnostics.clinicianservice.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationExpression;
import org.springframework.data.mongodb.core.aggregation.AggregationOperationContext;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.questdiagnostics.clinicianservice.model.QueryModel;

@Service
@Qualifier("diagnosticsUnwindOperations")
public class DiagnosticsUnwindOperations implements UnwindOperationsInterface {

	private static final String DIAG_DATA = "data.age_data.diagnostic_data";
	private static final String STANDARD = "standard";
	private static final String VERSION = "version";
	private static final String DISEASE_INFO_CODE = "disease_info.code";
	private static final String DIAG_DATA_VERSION = "data.age_data.diagnostic_data.version";
	private static final String DATA_DIGNOSTICS_ICDCODE = "data.age_data.diagnostic_data.disease_info.code";
	private static final String DIAG_DISEASE_INFO = "data.age_data.diagnostic_data.disease_info";
	
	private List unwindAndMatchDiagnosticsCriteria(QueryModel model) {
		List dignoList = new ArrayList();
		dignoList.add(putOpAndAddToPipeline(DIAG_DATA, true));
		dignoList.add(putOpAndAddToPipeline(DIAG_DISEASE_INFO, true));
		if (model != null && model.getDignosticsInfo() != null) {
			
			List<DignosticsFilter> dignoFilter = model.getDignosticsInfo().getInit();
			if (dignoFilter != null && !dignoFilter.isEmpty()) {
				
				MatchOperation match = null;
				List<Criteria> innerCriteriaList = new ArrayList<>();
				Criteria outerCriteria = new Criteria();
				for (DignosticsFilter pf : dignoFilter) {
					Criteria innerCriteria = new Criteria().andOperator(
							getCriteriaBasedOnString("is", DIAG_DATA_VERSION, pf.getVersion(), false),
							(getCriteriaBasedOnString(pf.getComparison(), DATA_DIGNOSTICS_ICDCODE, pf.getCode(), true)));
					innerCriteriaList.add(innerCriteria);
				}
				if(innerCriteriaList.size() == 1) {
					match = Aggregation.match(innerCriteriaList.get(0));
				} else {
					match = Aggregation.match(
							outerCriteria.orOperator(innerCriteriaList.toArray(new Criteria[innerCriteriaList.size()])));
				}
				
				dignoList.add(match);
			}			
		}
		return dignoList;
	}

	private Criteria getCriteriaBasedOnString(String operator, String operand, String dataSet, boolean useRegex) {
		Criteria matchOperation = null;
		switch (operator != null ? operator : "is") {
		case "is":
			if (dataSet.contains(".")) {
				//matchOperation = new Criteria(operand).regex(getExactMatchingRegex(dataSet), "i");
				matchOperation = new Criteria(operand).is(dataSet);
			} else {
				matchOperation = useRegex ? new Criteria(operand).regex(getLikeMatchingRegex(dataSet), "i")
						: new Criteria(operand).is(dataSet);
			}
			break;
		case "ne":
			matchOperation = new Criteria(operand).ne(dataSet);
			break;
		}
		return matchOperation;
	}

	private Criteria getCriteriaBasedOnString(Criteria currentCriteria, String operator, String operand,
			String dataSet, boolean useRegex) {
		switch (operator != null ? operator : "is") {
		case "is":
			if (dataSet.contains(".")) {
				//currentCriteria = currentCriteria.and(operand).regex(getExactMatchingRegex(dataSet), "i");
				currentCriteria = currentCriteria.and(operand).is(dataSet);
			} else {
				currentCriteria = useRegex ? currentCriteria.and(operand).regex(getLikeMatchingRegex(dataSet), "i")
						: currentCriteria.and(operand).is(dataSet);
			}
			break;
		case "ne":
			currentCriteria = currentCriteria.and(operand).ne(dataSet);
			break;
		}
		return currentCriteria;
	}

	private Criteria getElementMatchCriteria(DignosticsFilter pf) {
		return new Criteria(DIAG_DATA).elemMatch(getCriteriaBasedOnString(
				getCriteriaBasedOnString(Criteria.where(STANDARD).is("ICD"), "is", VERSION, pf.getVersion(), false),
				pf.getComparison(), DISEASE_INFO_CODE, pf.getCode(), true));

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private MatchOperation matchOperationForDiagnostics(QueryModel model) {
		Criteria patientCriteria = matchPatientCriteria(model);
		MatchOperation matchOp = null;
		if (model.getDignosticsInfo() != null && model.getDignosticsInfo().getInit() != null) {
			Criteria diagnosticsCriteria = null;
			// base case
			if (model.getDignosticsInfo().getInit().size() == 1) {
				DignosticsFilter pf = model.getDignosticsInfo().getInit().get(0);
				// d1
				diagnosticsCriteria = getElementMatchCriteria(pf);
			}

			// for all AND operations
			String previousOperator = null;
			List listOfDiagANDs = new ArrayList<>();
			List<DignosticsFilter> currentANDList = null;
			for (DignosticsFilter pf : model.getDignosticsInfo().getInit()) {
				// d1 or d2 or d3 and d4 or d5 and d6 and d7
				String currentOperator = pf.getOperator();
				if (currentOperator == null || currentOperator.equals("")) {
					// last element reached
					if (previousOperator != null) {
						if (currentANDList != null && previousOperator.equalsIgnoreCase("AND")) {
							currentANDList.add(pf.setProcessed(true));
							listOfDiagANDs.add(currentANDList);
						} else {
							listOfDiagANDs.add(pf);
						}
					}
				} else if (currentOperator.equalsIgnoreCase("AND")) {
					// if previous operator was OR, then a new AND list is instantiated
					if (currentANDList == null) {
						currentANDList = new ArrayList<>();
					}
					currentANDList.add(pf.setProcessed(true));
				} else if (previousOperator != null && !previousOperator.equalsIgnoreCase(currentOperator)) {
					// terminate current AND list
					if (currentANDList != null) {
						currentANDList.add(pf.setProcessed(true));
					}
					listOfDiagANDs.add(currentANDList);
					currentANDList = new ArrayList<>();
				} else if (previousOperator != null && previousOperator.equalsIgnoreCase(currentOperator)) {
					// add individual ORs
					listOfDiagANDs.add(pf);
				} else if(previousOperator == null) {
					listOfDiagANDs.add(pf);
				}
				previousOperator = pf.getOperator();
			}
			// prepare AND criterias
			List<Criteria> orWithGroupedANDCriterias = new ArrayList();
			boolean orPresent = false;
			if (!listOfDiagANDs.isEmpty()) {
				orWithGroupedANDCriterias = new ArrayList<>();
				orPresent = listOfDiagANDs.size() > 1 ? true : false;

				for (int i = 0; i < listOfDiagANDs.size(); i++) {
					// current AND criteria list
					if (listOfDiagANDs.get(i) instanceof DignosticsFilter) {
						Criteria individualOrCriteria = getElementMatchCriteria(
								(DignosticsFilter) listOfDiagANDs.get(i));
						orWithGroupedANDCriterias.add(individualOrCriteria);
					} else {
						// list of diagnostics filter
						List dignosticsFilterList = (List) listOfDiagANDs.get(i);
						List<Criteria> andCriteriaList = new ArrayList<>();
						for (int k = 0; k < dignosticsFilterList.size(); k++) {
							Criteria c = getElementMatchCriteria((DignosticsFilter) dignosticsFilterList.get(k));
							andCriteriaList.add(c);
						}
						Criteria groupANDCriteria = new Criteria()
								.andOperator(andCriteriaList.toArray(new Criteria[andCriteriaList.size()]));
						orWithGroupedANDCriterias.add(groupANDCriteria);
					}
				}
				if (orPresent) {
					diagnosticsCriteria = new Criteria().orOperator(
							orWithGroupedANDCriterias.toArray(new Criteria[orWithGroupedANDCriterias.size()]));
				} else {
					diagnosticsCriteria = orWithGroupedANDCriterias.get(0);
				}
			}

			if(patientCriteria == null) {
				matchOp = Aggregation.match(diagnosticsCriteria);
			} else if (model.getPatientInfo().getOperator().equalsIgnoreCase("AND")) {
				matchOp = Aggregation.match(new Criteria().andOperator(patientCriteria, diagnosticsCriteria));
			} else {
				matchOp = Aggregation.match(new Criteria().orOperator(patientCriteria, diagnosticsCriteria));
			}
		} else {
			matchOp = Aggregation.match(patientCriteria);
		}

		return matchOp;
	}

	private UnwindOperation putOpAndAddToPipeline(String key, boolean preserveNullAndEmptyArray) {
		UnwindOperation aggOp = Aggregation.unwind(key, preserveNullAndEmptyArray);
		return aggOp;
	}

	public List createDBObjectsFromCriteria(QueryModel model) {
		List list = new ArrayList();
		list.add(matchOperationForDiagnostics(model));
		list.addAll(getPatientOperationsList(model));
		list.addAll(unwindAndMatchDiagnosticsCriteria(model));

		AggregationExpression groupAgg = new AggregationExpression() {
			@Override
			public Document toDocument(AggregationOperationContext arg0) {
				Document reduce = new Document("diagnostic_patient_ids",
						"$data.age_data.diagnostic_data.disease_info.patient_ids");
				return reduce;
			}
		};
		GroupOperation groupOperationOne = Aggregation
				.group("npi", "first_name", "last_name", "source", "address1", "address2", "city", "zip", "state",
						"specialty", "phone_number", "email_address", "project")
				.push(new BasicDBObject("diagnostic_patient_ids",
						"$data.age_data.diagnostic_data.disease_info.patient_ids"))
				.as("npis").first(groupAgg).as("firstNpi");
		list.add(groupOperationOne);

		AggregationExpression reduceOperation = new AggregationExpression() {
			@Override
			public Document toDocument(AggregationOperationContext arg0) {
				DBObject reduce = new BasicDBObject("input", "$npis.diagnostic_patient_ids")
						.append("initialValue", "$firstNpi.diagnostic_patient_ids")
						.append("in", new BasicDBObject("$setUnion", Arrays.asList("$$value", "$$this")));
				return new Document("$reduce", reduce);
			}
		};

		Aggregation aggregation = Aggregation.newAggregation(
				Aggregation.project().andExclude("_id").andInclude("content").and(reduceOperation).as("patient_ids"));
		ProjectionOperation projectStageTwo = Aggregation
				.project("npi", "first_name", "last_name", "source", "address1", "address2", "city", "zip", "state",
						"specialty", "phone_number", "email_address", "project")
				.andExclude("_id").and(reduceOperation).as("patient_ids");
		list.add(projectStageTwo);
		return list;
	}

}
