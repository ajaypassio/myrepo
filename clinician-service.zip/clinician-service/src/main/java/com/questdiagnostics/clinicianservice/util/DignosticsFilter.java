
package com.questdiagnostics.clinicianservice.util;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "comparison",
    "standard",
    "version",
    "code",
    "operator"
})
public class DignosticsFilter {

    @JsonProperty("comparison")
    private String comparison;
    @JsonProperty("standard")
    private String standard;
    @JsonProperty("version")
    private String version;
    @JsonProperty("code")
    private String code;
    @JsonProperty("operator")
    private String operator;
    @JsonIgnore
    private boolean processed = false;
   
    @JsonProperty("comparison")
    public String getComparison() {
        return comparison;
    }

    @JsonProperty("comparison")
    public void setComparison(String comparison) {
        this.comparison = comparison;
    }

    @JsonProperty("standard")
    public String getStandard() {
        return standard;
    }

    @JsonProperty("standard")
    public void setStandard(String standard) {
        this.standard = standard;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("code")
    public void setCode(String code) {
        this.code = code;
    }

    @JsonProperty("operator")
    public String getOperator() {
        return operator;
    }

    @JsonProperty("operator")
    public void setOperator(String operator) {
        this.operator = operator;
    }
 
    public boolean isProcessed() {
		return processed;
	}

	public DignosticsFilter setProcessed(boolean processed) {
		this.processed = processed;
		return this;
	}
}
