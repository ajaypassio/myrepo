package com.questdiagnostics.clinicianservice.util;

import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.questdiagnostics.clinicianservice.response.model.ClinicianModel;

public class DownloadCSVHelper {
	
	public static void writeObjectToCSV(PrintWriter writer,List<ClinicianModel> clinicians) {
	    try (
	        CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT
	                      .withHeader("first_name","middle_name","last_name","npi","source","noOfPatients","specialty","address","city","state","zip","project","phone_number","email_address" ));
	    ) {
	      for (ClinicianModel clinician : clinicians) {
	        List<? extends Object> data = Arrays.asList(
	        		clinician.getFirstName(),
	        		clinician.getMiddleName(),
	        		clinician.getLastName(),
	        		clinician.getNpi(),
	        		clinician.getSource(),
	        		clinician.getNoOfPatients(),
	        		clinician.getSpecialty(),
	        		clinician.getAddress(),
	        		clinician.getCity(),
	        		clinician.getState(),
	        		clinician.getZip(),
	        		clinician.getPhoneNumber() != null ? clinician.getPhoneNumber().toString() : "",
	        		clinician.getEmailAddress() != null ? clinician.getEmailAddress().toString() : ""
	          );
	        
	        csvPrinter.printRecord(data);
	      }
	      csvPrinter.flush();
	    } catch (Exception e) {
	      System.out.println("Writing CSV error!");
	      e.printStackTrace();
	    }
	  }
}
