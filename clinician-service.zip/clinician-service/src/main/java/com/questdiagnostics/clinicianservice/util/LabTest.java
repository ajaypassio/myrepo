
package com.questdiagnostics.clinicianservice.util;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "init",
    "operator"
})
public class LabTest {

    @JsonProperty("init")
    private List<LabTestFilter> init = null;
    @JsonProperty("operator")
    private String operator;
   
    @JsonProperty("init")
    public List<LabTestFilter> getInit() {
        return init;
    }

    @JsonProperty("init")
    public void setInit(List<LabTestFilter> init) {
        this.init = init;
    }

    @JsonProperty("operator")
    public String getOperator() {
        return operator;
    }

    @JsonProperty("operator")
    public void setOperator(String operator) {
        this.operator = operator;
    }
 

}
