
package com.questdiagnostics.clinicianservice.util;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "comparison",
    "test_name",
    "test_value",
    "unit",
    "fasting",
    "operator"
})
public class LabTestFilter {

    @JsonProperty("comparison")
    private String comparison;
    @JsonProperty("name")
    private String testName;
    @JsonProperty("value_min")
    private String valueMin;
    @JsonProperty("value_max")
    private String valueMax;
   
    @JsonProperty("unit")
    private String unit;
    @JsonProperty("fasting")
    private String fasting;
    @JsonProperty("operator")
    private String operator;
    @JsonIgnore
    private boolean processed = false;
    
    @JsonProperty("value_min")
    public String getValueMin() {
		return valueMin;
	}
    @JsonProperty("value_min")
	public void setValueMin(String valueMin) {
		this.valueMin = valueMin;
	}
    @JsonProperty("value_max")
	public String getValueMax() {
		return valueMax;
	}
    @JsonProperty("value_max")
	public void setValueMax(String valueMax) {
		this.valueMax = valueMax;
	}

	
	@JsonProperty("comparison")
    public String getComparison() {
        return comparison;
    }

    @JsonProperty("comparison")
    public void setComparison(String comparison) {
        this.comparison = comparison;
    }

    @JsonProperty("name")
    public String getTestName() {
        return testName;
    }

    @JsonProperty("name")
    public void setTestName(String testName) {
        this.testName = testName;
    }   

    @JsonProperty("unit")
    public String getUnit() {
        return unit;
    }

    @JsonProperty("unit")
    public void setUnit(String unit) {
        this.unit = unit;
    }

    @JsonProperty("fasting")
    public String getFasting() {
        return fasting;
    }

    @JsonProperty("fasting")
    public void setFasting(String fasting) {
        this.fasting = fasting;
    }

    @JsonProperty("operator")
    public String getOperator() {
        return operator;
    }

    @JsonProperty("operator")
    public void setOperator(String operator) {
        this.operator = operator;
    }
    public boolean isProcessed() {
		return processed;
	}

	public LabTestFilter setProcessed(boolean processed) {
		this.processed = processed;
		return this;
	}

}
