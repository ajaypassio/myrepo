package com.questdiagnostics.clinicianservice.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationExpression;
import org.springframework.data.mongodb.core.aggregation.AggregationOperationContext;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.questdiagnostics.clinicianservice.model.QueryModel;

@Service
@Qualifier("labTestUnwindOperationsNew")
public class LabTestUnwindOperationsNew implements UnwindOperationsInterfaceNew {
	private static final String LAB_RESULTS = "data.age_data.lab_results";
	private static final String LAB_TEST_DATA = "data.age_data.lab_results.test_data";
	private static final String LAB_TEST_NAME = "data.age_data.lab_results.test_data.test_name";
	private static final String LAB_TEST_FASTING = "data.age_data.lab_results.fasting";
	private static final String LAB_TEST_VALUE = "data.age_data.lab_results.test_data.test_value";
	private static final String LAB_VALUE = "data.age_data.lab_results.test_data.test_value.value";
	private static final String LAB_DECIMAL_VALUE = "data.age_data.lab_results.test_data.test_value.decimal_value";
	private static final String FASTING = "fasting";
	private static final String TEST_NAME = "test_data.test_name";
	private static final String TEST_VALUE = "test_data.test_value.value";
	private static final String TEST_DECIMAL_VALUE = "test_data.test_value.decimal_value";
	
	@Override
	public List createDBObjectsFromCriteria(QueryModel model, String collectionName) {
		List list = new ArrayList();
		list.add(matchOperationForLabTests(model, collectionName));
		list.addAll(getPatientOperationsList(model, collectionName));
		list.addAll(unwindAndMatchLabTestCriteria(model));

		AggregationExpression groupAgg = new AggregationExpression() {
			@Override
			public Document toDocument(AggregationOperationContext arg0) {
				Document reduce = new Document("labtest_patient_ids",
						"$data.age_data.lab_results.test_data.test_value.patient_ids");
				return reduce;
			}
		};
		GroupOperation groupOperationOne = Aggregation
				.group("npi")
				.push(new BasicDBObject("labtest_patient_ids",
						"$data.age_data.lab_results.test_data.test_value.patient_ids"))
				.as("npis").first(groupAgg).as("firstNpi");
		list.add(groupOperationOne);

		AggregationExpression reduceOperation = new AggregationExpression() {
			@Override
			public Document toDocument(AggregationOperationContext arg0) {
				DBObject reduce = new BasicDBObject("input", "$npis.labtest_patient_ids")
						.append("initialValue", "$firstNpi.labtest_patient_ids")
						.append("in", new BasicDBObject("$setUnion", Arrays.asList("$$value", "$$this")));
				return new Document("$reduce", reduce);
			}
		};

		ProjectionOperation projectStageTwo = Aggregation
				.project("_id")
				.and(reduceOperation).as("patient_ids");
		list.add(projectStageTwo);
		return list;
	}

	private List unwindAndMatchLabTestCriteria(QueryModel model) {
		List labUnwindList = new ArrayList();
		labUnwindList.add(putOpAndAddToPipeline(LAB_RESULTS, true));
		labUnwindList.add(putOpAndAddToPipeline(LAB_TEST_DATA, true));
		labUnwindList.add(putOpAndAddToPipeline(LAB_TEST_VALUE, true));
		if (model != null && model.getLabTest() != null) {

			List<LabTestFilter> labTestFilter = model.getLabTest().getInit();
			if (labTestFilter != null && labTestFilter.size() > 0) {

				MatchOperation match = null;
				List<Criteria> innerCriteriaList = new ArrayList<>();
				Criteria outerCriteria = new Criteria();
				for (LabTestFilter filter : labTestFilter) {
					Criteria innerCriteria = new Criteria().andOperator(
							Criteria.where(LAB_TEST_FASTING).is(filter.getFasting()),
							//.Criteria.where(LAB_TEST_NAME).regex(getExactMatchingRegex(filter.getTestName()), "i"),
							Criteria.where(LAB_TEST_NAME).is(filter.getTestName()),
							getOperationBasedOnOperatorForMatchOp(filter.getComparison(), filter));
					innerCriteriaList.add(innerCriteria);
				}
				if(innerCriteriaList.size() == 1) {
					match = Aggregation.match(innerCriteriaList.get(0));
				} else {
				match = Aggregation.match(
						outerCriteria.orOperator(innerCriteriaList.toArray(new Criteria[innerCriteriaList.size()])));
				}
				labUnwindList.add(match);
			}
		}
		return labUnwindList;
	}
	
	
	private UnwindOperation putOpAndAddToPipeline(String key, boolean preserveNullAndEmptyArray) {
		UnwindOperation aggOp = Aggregation.unwind(key, preserveNullAndEmptyArray);
		return aggOp;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private MatchOperation matchOperationForLabTests(QueryModel model, String collectionName) {
		Criteria patientCriteria = matchPatientCriteria(model, collectionName);
		MatchOperation matchOp = null;
		if (model.getLabTest() != null && model.getLabTest().getInit() != null) {
			Criteria labCriteria = null;
			// base case
			if (model.getLabTest().getInit().size() == 1) {
				LabTestFilter pf = model.getLabTest().getInit().get(0);
				// d1
				labCriteria = getElementMatchCriteria(pf);
			}

			// for all AND operations
			String previousOperator = null;
			List listOfLabANDs = new ArrayList<>();
			List<LabTestFilter> currentANDList = null;
			for (LabTestFilter pf : model.getLabTest().getInit()) {
				// d1 or d2 or d3 and d4 or d5 and d6 and d7
				String currentOperator = pf.getOperator();
				if (currentOperator == null || currentOperator.equals("")) {
					// last element reached
					if (previousOperator != null) {
						if (currentANDList != null && previousOperator.equalsIgnoreCase("AND")) {
							currentANDList.add(pf.setProcessed(true));
							listOfLabANDs.add(currentANDList);
						} else {
							listOfLabANDs.add(pf);
						}
					}
				} else if (currentOperator.equalsIgnoreCase("AND")) {
					// if previous operator was OR, then a new AND list is instantiated
					if (currentANDList == null) {
						currentANDList = new ArrayList<>();
					}
					currentANDList.add(pf.setProcessed(true));
				} else if (previousOperator != null && !previousOperator.equalsIgnoreCase(currentOperator)) {
					// terminate current AND list
					if (currentANDList != null) {
						currentANDList.add(pf.setProcessed(true));
					}
					listOfLabANDs.add(currentANDList);
					currentANDList = new ArrayList<>();
				} else if (previousOperator != null && previousOperator.equalsIgnoreCase(currentOperator)) {
					// add individual ORs
					listOfLabANDs.add(pf);
				} else if (previousOperator == null) {
					listOfLabANDs.add(pf);
				}
				previousOperator = pf.getOperator();
			}
			// prepare AND criterias
			List<Criteria> orWithGroupedANDCriterias = new ArrayList();
			boolean orPresent = false;
			if (!listOfLabANDs.isEmpty()) {
				orWithGroupedANDCriterias = new ArrayList<>();
				orPresent = listOfLabANDs.size() > 1 ? true : false;

				for (int i = 0; i < listOfLabANDs.size(); i++) {
					// current AND criteria list
					if (listOfLabANDs.get(i) instanceof LabTestFilter) {
						Criteria individualOrCriteria = getElementMatchCriteria((LabTestFilter) listOfLabANDs.get(i));
						orWithGroupedANDCriterias.add(individualOrCriteria);
					} else {
						// list of diagnostics filter
						List labTestFilterList = (List) listOfLabANDs.get(i);
						List<Criteria> andCriteriaList = new ArrayList<>();
						for (int k = 0; k < labTestFilterList.size(); k++) {
							Criteria c = getElementMatchCriteria((LabTestFilter) labTestFilterList.get(k));
							andCriteriaList.add(c);
						}
						Criteria groupANDCriteria = new Criteria()
								.andOperator(andCriteriaList.toArray(new Criteria[andCriteriaList.size()]));
						orWithGroupedANDCriterias.add(groupANDCriteria);
					}
				}
				if (orPresent) {
					labCriteria = new Criteria().orOperator(
							orWithGroupedANDCriterias.toArray(new Criteria[orWithGroupedANDCriterias.size()]));
				} else {
					labCriteria = orWithGroupedANDCriterias.get(0);
				}
			}

			if (patientCriteria == null) {
				matchOp = Aggregation.match(labCriteria);
			} else if (model.getPatientInfo().getOperator().equalsIgnoreCase("AND")) {
				matchOp = Aggregation.match(new Criteria().andOperator(patientCriteria, labCriteria));
			} else {
				matchOp = Aggregation.match(new Criteria().orOperator(patientCriteria, labCriteria));
			}
		} else {
			matchOp = Aggregation.match(patientCriteria);
		}

		return matchOp;
	}

	private Criteria getElementMatchCriteria(LabTestFilter lbFilter) {
		return new Criteria(LAB_RESULTS)
				.elemMatch(
						getOperationBasedOnOperator(
								Criteria.where(FASTING).is(lbFilter.getFasting()).and(TEST_NAME)
										//.regex(getExactMatchingRegex(lbFilter.getTestName()), "i"),
								.is(lbFilter.getTestName()),
								lbFilter.getComparison(), lbFilter));

	}
	
	
	private Criteria getOperationBasedOnOperator(Criteria currentCriteria, String operator, LabTestFilter filter) {
		switch (operator != null ? operator : "is") {
		case "is":
			currentCriteria = isNumber(filter.getValueMin())
					? currentCriteria.and(TEST_DECIMAL_VALUE).is(convertToDouble(filter.getValueMin()))
					//: currentCriteria.and(TEST_VALUE).regex(getExactMatchingRegex(filter.getValueMin()), "i");
					: currentCriteria.and(TEST_VALUE).is(filter.getValueMin());
			break;
		case "ne":
			currentCriteria = isNumber(filter.getValueMin())
					? currentCriteria.and(TEST_DECIMAL_VALUE).ne(convertToDouble(filter.getValueMin()))
					: currentCriteria.and(TEST_VALUE).ne(filter.getValueMin());
			break;
		case "lt":
			currentCriteria = currentCriteria.and(TEST_DECIMAL_VALUE).lt(convertToDouble(filter.getValueMin()));
			break;
		case "gt":
			currentCriteria = currentCriteria.and(TEST_DECIMAL_VALUE).gt(convertToDouble(filter.getValueMin()));
			break;
		case "gte":
			currentCriteria = currentCriteria.and(TEST_DECIMAL_VALUE).gte(convertToDouble(filter.getValueMin()));
			break;
		case "lte":
			currentCriteria = currentCriteria.and(TEST_DECIMAL_VALUE).lte(convertToDouble(filter.getValueMin()));
			break;
		case "range":
			currentCriteria = currentCriteria.and(TEST_DECIMAL_VALUE).gte(convertToDouble(filter.getValueMin()))
					.lte(convertToDouble(filter.getValueMax()));
			break;
		}
		return currentCriteria;
	}
	
	
	private Criteria getOperationBasedOnOperatorForMatchOp(String operator, LabTestFilter filter) {
		Criteria currentCriteria = new Criteria();
		switch (operator != null ? operator : "is") {
		case "is":
			currentCriteria = isNumber(filter.getValueMin())
					? currentCriteria.and(LAB_DECIMAL_VALUE).is(convertToDouble(filter.getValueMin()))
					//: : currentCriteria.and(LAB_VALUE).regex(getExactMatchingRegex(filter.getValueMin()), "i");
					: currentCriteria.and(LAB_VALUE).is(filter.getValueMin());
			break;
		case "ne":
			currentCriteria = isNumber(filter.getValueMin())
					? currentCriteria.and(LAB_DECIMAL_VALUE).ne(convertToDouble(filter.getValueMin()))
					: currentCriteria.and(LAB_VALUE).ne(filter.getValueMin());
			break;
		case "lt":
			currentCriteria = currentCriteria.and(LAB_DECIMAL_VALUE).lt(convertToDouble(filter.getValueMin()));
			break;
		case "gt":
			currentCriteria = currentCriteria.and(LAB_DECIMAL_VALUE).gt(convertToDouble(filter.getValueMin()));
			break;
		case "gte":
			currentCriteria = currentCriteria.and(LAB_DECIMAL_VALUE).gte(convertToDouble(filter.getValueMin()));
			break;
		case "lte":
			currentCriteria = currentCriteria.and(LAB_DECIMAL_VALUE).lte(convertToDouble(filter.getValueMin()));
			break;
		case "range":
			currentCriteria = currentCriteria.and(LAB_DECIMAL_VALUE).gte(convertToDouble(filter.getValueMin()))
					.lte(convertToDouble(filter.getValueMax()));
			break;
		}
		return currentCriteria;
	}
	
	

}
