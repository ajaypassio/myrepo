package com.questdiagnostics.clinicianservice.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;
import com.questdiagnostics.clinicianservice.model.QueryModel;

@Component
public class MongoDBQueryBuilder {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final String DATA_AGE_DATA = "data.age_data";
	private static final String DATA_AGE = "data.age_data.age";
	private static final String DATA_GENDER = "data.gender";
	private static final String DATA_AGE_DATA_DIAGNOSTIC_DATA = "data.age_data.diagnostic_data";
	private static final String DATA_AGE_DATA_DIAGNOSTIC_DATA_DISEASE_INFO = "data.age_data.diagnostic_data.disease_info";
	private static final String DATA_DIGNOSTICS_ICDCODE = "data.age_data.diagnostic_data.disease_info.code";
	private static final String DATA_DIGNOSTICS_ICDCODESET = "data.age_data.diagnostic_data.version";
	private static final String DATA_LAB_RESULTS = "data.age_data.lab_results";
	private static final String DATA_LAB_RESULTS_TEST_DATA = "data.age_data.lab_results.test_data";
	private static final String DATA_LAB_RESULTS_TEST_VALUE = "data.age_data.lab_results.test_data.test_value.value";
	private static final String DATA_LAB_RESULTS_TEST_NAME = "data.age_data.lab_results.test_data.test_name";
    private static final String DATA_LAB_RESULTS_FASTING = "data.age_data.lab_results.fasting";
    
	public List createAggregationFromQuery(QueryModel query) {
		logger.info(" Inside createAggregationFromQuery");
		List listOfAllOperations = new ArrayList();

		if (query.getPatientInfo() != null && query.getPatientInfo().getInit() != null) {
			listOfAllOperations.addAll(getPatientOperationsList(query.getPatientInfo().getInit()));
		}
		UnwindOperation unwindStageOne = Aggregation.unwind(DATA_AGE_DATA_DIAGNOSTIC_DATA);
		
		listOfAllOperations.add(unwindStageOne);
//		listOfAllOperations.add(unwindStageTwo);
		if (query.getDignosticsInfo() != null && query.getDignosticsInfo().getInit() != null) {
		//	listOfAllOperations.addAll(getDignosticsOperationsList(query.getDignosticsInfo().getInit()));
		}
		if (query.getLabTest() != null && query.getLabTest().getInit() != null) {
			listOfAllOperations.addAll(getLabTestOperationsList(query.getLabTest().getInit()));
		}
		logger.info("returing all operations list" + listOfAllOperations.size());
		return listOfAllOperations;
	}

	@SuppressWarnings("unchecked")
	private List getPatientOperationsList(List<PatientFilter> patientFilter) {
		logger.info(" Inside getPatientOperationsList");
		List listOfPatientOperations = new ArrayList();

		MatchOperation matchStageOne = null;
		MatchOperation matchStageThree = null;
		UnwindOperation unwindStageOne = Aggregation.unwind("data");
		
		
		listOfPatientOperations.add(unwindStageOne);
		 if (patientFilter.size() > 0) {

			for (PatientFilter pf : patientFilter) {

				if (pf.getGender() != null) {
					Criteria criteria = new Criteria().where("data.gender").in(pf.getGender());
					matchStageOne = Aggregation.match(criteria);
					listOfPatientOperations.add(matchStageOne);
					 
				}
				UnwindOperation unwindStageTwo = Aggregation.unwind(DATA_AGE_DATA);
				listOfPatientOperations.add(unwindStageTwo);
				if (pf.getAgeMin() > 0 && pf.getAgeMax() > 0) {
					matchStageThree = Aggregation.match(new Criteria(DATA_AGE).gte(pf.getAgeMin()).andOperator(new Criteria(DATA_AGE).lte(pf.getAgeMax())));
					listOfPatientOperations.add(matchStageThree);
				}else if (pf.getAgeMin() > 0) {
					matchStageThree = Aggregation.match(new Criteria(DATA_AGE).gte(pf.getAgeMin()));
					listOfPatientOperations.add(matchStageThree);
				}else if (pf.getAgeMax() > 0) {
					matchStageThree = Aggregation.match(new Criteria(DATA_AGE).lte(pf.getAgeMax()));
					listOfPatientOperations.add(matchStageThree);

				}
			}
		}
		logger.info("  returing list of patient " + listOfPatientOperations.size());
		return listOfPatientOperations;

	}

	 
	private List getLabTestOperationsList(List<LabTestFilter> labTestFilter) {
		logger.info(" Inside getLabTestOperationsList");
		List listOfLabTestOperations = new ArrayList();
		MatchOperation matchStageOne = null;
		MatchOperation matchStageTwo = null;
		MatchOperation matchStageThree = null;
		UnwindOperation unwindStageOne = Aggregation.unwind(DATA_LAB_RESULTS);
		UnwindOperation unwindStageTwo = Aggregation.unwind(DATA_LAB_RESULTS_TEST_DATA);
		listOfLabTestOperations.add(unwindStageOne);
		listOfLabTestOperations.add(unwindStageTwo);

		if (labTestFilter.size() > 0) {
			for (LabTestFilter filter : labTestFilter) {
//				if (filter.getFasting() != null) {
//					matchStageOne = Aggregation.match(new Criteria(DATA_LAB_RESULTS_FASTING).is(filter.getFasting()));
//					listOfLabTestOperations.add(matchStageOne);
//				}
//				if (filter.getValue() != null) {
//					matchStageOne = Aggregation.match(new Criteria(DATA_LAB_RESULTS_TEST_NAME).is(filter.getValue()));
//					listOfLabTestOperations.add(matchStageOne);
//				}
//				if (filter.getMin() != null) {
//					matchStageThree = getOperationBasedOnOperatorMax(filter.getComparision(), DATA_LAB_RESULTS_TEST_VALUE,
//							filter.getMin(),filter.getMax());
//					listOfLabTestOperations.add(matchStageThree);
//				}
			}
		}
		logger.info(" return getLabTestOperationsList");
		return listOfLabTestOperations;
	}

	private MatchOperation getOperationBasedOnOperator(String operator, String operand, Integer dataSet) {
		MatchOperation matchOperation = null;
		switch (operator != null ? operator : "eq") {
		case "eq":
			matchOperation = Aggregation.match(new Criteria(operand).is(dataSet));
			break;
		case "ne":
			matchOperation = Aggregation.match(new Criteria(operand).ne(dataSet));
			break;
		case "lt":
			matchOperation = Aggregation.match(new Criteria(operand).lt(dataSet));
			break;
		case "gt":
			matchOperation = Aggregation.match(new Criteria(operand).gt(dataSet));
			break;
		case "gte":
			matchOperation = Aggregation.match(new Criteria(operand).gte(dataSet));
			break;
		case "lte":
			matchOperation = Aggregation.match(new Criteria(operand).lte(dataSet));
			break;
		}
		return matchOperation;
	}

	private MatchOperation getOperationBasedOnOperatorMax(String operator, String operand, Integer dataSet, Integer dataSetMax) {
		MatchOperation matchOperation = null;
		if (operator != null && operator.equalsIgnoreCase("range")) {
			matchOperation = Aggregation.match(new Criteria(operand).gte(dataSet).andOperator(new Criteria(operand).lte(dataSetMax)));
			return matchOperation;
		}
		return getOperationBasedOnOperator(operator, operand, dataSet);
	}
	
	private MatchOperation getOperationBasedOnOperatorForICD(String operator, String operand, String dataSet) {
		MatchOperation matchOperation = null;
		switch (operator != null ? operator : "eq") {
		case "eq":
			matchOperation = Aggregation.match(new Criteria(operand).is(dataSet));
			break;
		case "ne":
			matchOperation = Aggregation.match(new Criteria(operand).ne(dataSet));
			break;
		}
		return matchOperation;
	  
	}
}
