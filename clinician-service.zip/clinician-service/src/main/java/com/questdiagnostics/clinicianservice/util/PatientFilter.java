
package com.questdiagnostics.clinicianservice.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "age_min",
    "age_max",
    "gender"
})
public class PatientFilter {

    @JsonProperty("age_min")
    private Integer ageMin;
    @JsonProperty("age_max")
    private Integer ageMax;
    @JsonProperty("gender")
    private String gender;
    
    @JsonProperty("age_min")
    public Integer getAgeMin() {
        return ageMin;
    }

    @JsonProperty("age_min")
    public void setAgeMin(Integer ageMin) {
        this.ageMin = ageMin;
    }

    @JsonProperty("age_max")
    public Integer getAgeMax() {
        return ageMax;
    }

    @JsonProperty("age_max")
    public void setAgeMax(Integer ageMax) {
        this.ageMax = ageMax;
    }

    @JsonProperty("gender")
    public String getGender() {
        return gender;
    }

    @JsonProperty("gender")
    public void setGender(String gender) {
        this.gender = gender;
    }
 
}
