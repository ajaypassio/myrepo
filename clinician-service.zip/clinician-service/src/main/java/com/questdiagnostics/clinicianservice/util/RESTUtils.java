package com.questdiagnostics.clinicianservice.util;

import java.net.URI;
import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RESTUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(RESTUtils.class);

	@Autowired
	RestTemplate restTemplate;

	@Value("${sprintt.physician.campaign.detail")
	private String physicianCampagignDetail;

	public <T, U> ResponseEntity<U> execute(T entityBody, String uriContextPath, HttpMethod httpMethod,
			Class<U> responseType) throws URISyntaxException, JsonProcessingException {
		URI url = new URI(uriContextPath);
		String bodyString = null; // bodyString will be null for GET method
		if (entityBody != null) {
			ObjectMapper mapper = new ObjectMapper();
			bodyString = mapper.writeValueAsString(entityBody);
			LOGGER.debug("bodyString = {}", bodyString);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = new HttpEntity<>(bodyString, headers);
		return restTemplate.exchange(url, httpMethod, request, responseType);
	}

}
