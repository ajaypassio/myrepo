package com.questdiagnostics.clinicianservice.util;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.EnumSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageCredentials;
import com.microsoft.azure.storage.StorageCredentialsAccountAndKey;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.CloudPageBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;
import com.microsoft.azure.storage.blob.SharedAccessBlobPermissions;
import com.microsoft.azure.storage.blob.SharedAccessBlobPolicy;

@Component
public class SASGenerationUtil {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Value("${sprintt.azure.export.storage.accountname}")
	private String accountName;
	
	@Value("${sprintt.azure.export.storage.accountkey}")
	private String accountKey;
	
	@Value("${sprintt.azure.export.storage.SASToekenGenerationTime}")
	private long sasToekenGenerationTime;

	@Value("${sprintt.azure.export.storage.ContainerName}")
	private String containerName;
	
	public String getBlobSASString(String userName)
			throws URISyntaxException, InvalidKeyException, StorageException, MalformedURLException {
		String directoryToDownloadString = "physician_criteria_csv"+"/"+userName;
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		CloudBlobDirectory directory = null;
		String fileNameForSAString = "";
		String sasString = "";
		try {
			String connectStr ="DefaultEndpointsProtocol=https;AccountName="+accountName+";AccountKey="+accountKey+";EndpointSuffix=core.windows.net";
			storageAccount = CloudStorageAccount.parse(connectStr);
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);
			directory = container.getDirectoryReference(directoryToDownloadString);
			
			Iterable<ListBlobItem> itr = directory.listBlobs();
			for(ListBlobItem listBlobItem:itr ) {
				String tempFileName = listBlobItem.getUri().toString();
				if(tempFileName!=null && tempFileName.length()>0) {
					if(tempFileName.contains(".csv")){
						fileNameForSAString = tempFileName.substring(tempFileName.lastIndexOf("/")+1);
						break;
					}
				}
			}
			
			if(fileNameForSAString.length()>0) {
				URI uri = new URI("https://"+accountName+".blob.core.windows.net/"+containerName+"/"+directoryToDownloadString+"/"+fileNameForSAString);
				sasString = uri.toString() + "?" + generateSasToken(uri);
				logger.info(sasString);
			}else {
				sasString ="FIle genearion is not yet done, please try again";
			}
		}catch(Exception e) {
			sasString ="FIle genearion is not yet done, please try again";
		}
        return sasString;
	}
	public String generateSasToken(URI fileUri) throws StorageException, URISyntaxException, InvalidKeyException {
		StorageCredentials credentials = new StorageCredentialsAccountAndKey(accountName, accountKey);
        CloudBlob file = new CloudPageBlob(fileUri, credentials);
        SharedAccessBlobPolicy policy = new SharedAccessBlobPolicy ();
        policy.setPermissions(EnumSet.of(SharedAccessBlobPermissions.READ));
        policy.setSharedAccessStartTime(null);
        policy.setSharedAccessExpiryTime(getExpirationTime());
        return file.generateSharedAccessSignature(policy, null);
    }

    private Date getExpirationTime() {
    	logger.info("Current Date is:"+LocalDateTime.now());
    	LocalDateTime expLDT = LocalDateTime.now().plusMinutes(sasToekenGenerationTime);
        logger.info("Date after added time is:"+expLDT);
        logger.info("Zone is:"+ZoneId.systemDefault());
        Instant expInstant = expLDT.atZone(ZoneId.systemDefault()).toInstant();
        logger.info("Instant is:"+expInstant);
        return Date.from(expInstant);
    }
}
