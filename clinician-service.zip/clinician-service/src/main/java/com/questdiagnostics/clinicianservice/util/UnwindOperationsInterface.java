package com.questdiagnostics.clinicianservice.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.Document;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import com.questdiagnostics.clinicianservice.model.QueryModel;

@FunctionalInterface
public interface UnwindOperationsInterface {
	static final String UNWIND = "$unwind";
	static final String ELEM_MATCH = "$elemMatch";
	static final String PROJECT = "$project";
	static final String GROUP = "$group";
	static final String MATCH = "$match";
	static final String AND = "$and";
	static final String OR = "$or";
	static final String DATA_AGE = "data.age_data.age";
	static final String DATA_GENDER = "data.gender";
	static final String DATA_AGE_DATA = "data.age_data";

	static final Pattern SIGNED_NUMBER_PATTERN = Pattern.compile("[-+]?[0-9]*\\.?[0-9]+");
	static final Pattern UNSIGNED_NUMBER_PATTERN = Pattern.compile("[0-9]*\\.?[0-9]+");

	/**
	 * This method is used to create unwind and match operations for diagnostics or
	 * lab criteria
	 * 
	 * @param model
	 * @return List of Unwind and Match operation
	 */
	public abstract List<Document> createDBObjectsFromCriteria(QueryModel model);

	/**
	 * This method is used to create match operations for query
	 * 
	 * @param model
	 * @return List of Match operation
	 */
	public default Criteria matchPatientCriteria(QueryModel model) {
		PatientInfo info = model.getPatientInfo();
		List<PatientFilter> pFilter = info.getInit();
		Object[] valArr = null;
		// MatchOperation matchStageOne = null;
		// MatchOperation matchStageTwo = null;
		// List listOfPatientOperations = new ArrayList();
		if (pFilter != null && pFilter.size() > 0) {
			for (PatientFilter pf : pFilter) {
				if (pf.getGender().contains(",")) {
					valArr = pf.getGender().split(",");
				} else {
					valArr = new Object[] { pf.getGender() };
				}
				Criteria criteria = Criteria.where(DATA_GENDER).in(valArr);
				if (pf.getAgeMin() > 0 && pf.getAgeMax() > 0) {
					// return new Criteria().andOperator(criteria,new
					// Criteria(DATA_AGE).gte(pf.getAgeMin()),new
					// Criteria(DATA_AGE).lte(pf.getAgeMax()));
					return criteria.and(DATA_AGE).gte(pf.getAgeMin()).lte(pf.getAgeMax());
					// listOfPatientOperations.add(matchStageOne);
				} else if (pf.getAgeMin() > 0) {
					return new Criteria().andOperator(criteria, new Criteria(DATA_AGE).gte(pf.getAgeMin()));
					// listOfPatientOperations.add(matchStageOne);
				} else if (pf.getAgeMax() > 0) {
					return new Criteria().andOperator(criteria, new Criteria(DATA_AGE).lte(pf.getAgeMax()));
					// listOfPatientOperations.add(matchStageOne);

				}

			}
		}
		return null;
	}

	default String getExactMatchingRegex(String value) {
		replaceSpecialCharsFromInput(value);
		return (new StringBuilder("^").append(value.trim()).append("$")).toString();
	}

	default String getLikeMatchingRegex(String value) {
		replaceSpecialCharsFromInput(value);		
		return (new StringBuilder("^").append(value.trim())).toString();
	}

	default String replaceSpecialCharsFromInput(String value) {
		if (value.contains("(")) {
			value = replaceParenthesisForMongoQuery(value, "(");
		}
		if (value.contains(")")) {
			value = replaceParenthesisForMongoQuery(value, ")");
		}
		if (value.contains("[")) {
			value = replaceParenthesisForMongoQuery(value, "[");
		}
		if (value.contains("]")) {
			value = replaceParenthesisForMongoQuery(value, "]");
		}
		return value.trim();
	}

	default String replaceParenthesisForMongoQuery(String value, CharSequence bracket) {
		return value.replace(bracket, "\\" + bracket);
	}

	default Double convertToDouble(String value) {
		try {
			return Double.valueOf(Double.parseDouble(value));
		} catch (NumberFormatException e) {
			return null;
		}
	}

	default boolean isNumber(String str) {
		return UNSIGNED_NUMBER_PATTERN.matcher(str).matches();
	}

	/**
	 * This method is used to create unwind and match operations for query
	 * 
	 * @param model
	 * @return List of Unwind and Match operation
	 */
	public default List getPatientOperationsList(QueryModel model) {
		PatientInfo info = model.getPatientInfo();
		List<PatientFilter> patientFilter = info.getInit();
		List listOfPatientOperations = new ArrayList();

		MatchOperation matchStageOne = null;
		MatchOperation matchStageThree = null;
		UnwindOperation unwindStageOne = Aggregation.unwind("data");

		listOfPatientOperations.add(unwindStageOne);
		if (patientFilter != null && !patientFilter.isEmpty()) {
			Object[] valArr = null;
			for (PatientFilter pf : patientFilter) {

				if (pf.getGender() != null) {
					if (pf.getGender().contains(",")) {
						valArr = pf.getGender().split(",");
					} else {
						valArr = new Object[] { pf.getGender() };
					}

					Criteria criteria = new Criteria().where(DATA_GENDER).in(valArr);
					matchStageOne = Aggregation.match(criteria);
					listOfPatientOperations.add(matchStageOne);

				}
				UnwindOperation unwindStageTwo = Aggregation.unwind(DATA_AGE_DATA);
				listOfPatientOperations.add(unwindStageTwo);
				if (pf.getAgeMin() > 0 && pf.getAgeMax() > 0) {
					matchStageThree = Aggregation.match(new Criteria().andOperator(
							new Criteria(DATA_AGE).gte(pf.getAgeMin()), new Criteria(DATA_AGE).lte(pf.getAgeMax())));
					listOfPatientOperations.add(matchStageThree);
				} else if (pf.getAgeMin() > 0) {
					matchStageThree = Aggregation.match(new Criteria(DATA_AGE).gte(pf.getAgeMin()));
					listOfPatientOperations.add(matchStageThree);
				} else if (pf.getAgeMax() > 0) {
					matchStageThree = Aggregation.match(new Criteria(DATA_AGE).lte(pf.getAgeMax()));
					listOfPatientOperations.add(matchStageThree);

				}
			}
		} else {
			UnwindOperation unwindStageTwo = Aggregation.unwind(DATA_AGE_DATA);
			listOfPatientOperations.add(unwindStageTwo);
		}
		// logger.info(" returing list of patient " + listOfPatientOperations.size());
		return listOfPatientOperations;

	}

}
