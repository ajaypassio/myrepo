package com.questdiagnostics.clinicianservice.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.Document;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.UnwindOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.util.CollectionUtils;

import com.questdiagnostics.clinicianservice.model.QueryModel;
import com.questdiagnostics.clinicianservice.service.ClincianServiceHelper;

@FunctionalInterface
public interface UnwindOperationsInterfaceNew {
	static final String UNWIND = "$unwind";
	static final String ELEM_MATCH = "$elemMatch";
	static final String PROJECT = "$project";
	static final String GROUP = "$group";
	static final String MATCH = "$match";
	static final String AND = "$and";
	static final String OR = "$or";
	static final String DATA_AGE = "data.age_data.age";
	static final String DATA_GENDER = "data.gender";
	static final String DATA_AGE_DATA = "data.age_data";

	static final Pattern SIGNED_NUMBER_PATTERN = Pattern.compile("[-+]?[0-9]*\\.?[0-9]+");
	static final Pattern UNSIGNED_NUMBER_PATTERN = Pattern.compile("[0-9]*\\.?[0-9]+");

	/**
	 * This method is used to create unwind and match operations for diagnostics or
	 * lab criteria
	 * 
	 * @param model
	 * @return List of Unwind and Match operation
	 */
	public abstract List<Document> createDBObjectsFromCriteria(QueryModel model, String collectionName);

	/**
	 * This method is used to create match operations for query
	 * 
	 * @param model
	 * @return List of Match operation
	 */
	public default Criteria matchPatientCriteria(QueryModel model, String collectionName) {
		PatientInfo info = model.getPatientInfo();
		List<PatientFilter> pFilter = info.getInit();
		Object[] valArr = null;		
		if (!CollectionUtils.isEmpty(pFilter)) {
			PatientFilter pf = pFilter.get(0);
			valArr = ClincianServiceHelper.determineAgeValues(pf.getAgeMin(), pf.getAgeMax(), collectionName);
			return Criteria.where(DATA_AGE).in(valArr);
		}
		return null;
	}

	default String getExactMatchingRegex(String value) {
		replaceSpecialCharsFromInput(value);
		return (new StringBuilder("^").append(value.trim()).append("$")).toString();
	}

	default String getLikeMatchingRegex(String value) {
		replaceSpecialCharsFromInput(value);		
		return (new StringBuilder("^").append(value.trim())).toString();
	}

	default String replaceSpecialCharsFromInput(String value) {
		if (value.contains("(")) {
			value = replaceParenthesisForMongoQuery(value, "(");
		}
		if (value.contains(")")) {
			value = replaceParenthesisForMongoQuery(value, ")");
		}
		if (value.contains("[")) {
			value = replaceParenthesisForMongoQuery(value, "[");
		}
		if (value.contains("]")) {
			value = replaceParenthesisForMongoQuery(value, "]");
		}
		return value.trim();
	}

	default String replaceParenthesisForMongoQuery(String value, CharSequence bracket) {
		return value.replace(bracket, "\\" + bracket);
	}

	default Double convertToDouble(String value) {
		try {
			return Double.valueOf(Double.parseDouble(value));
		} catch (NumberFormatException e) {
			return null;
		}
	}

	default boolean isNumber(String str) {
		return UNSIGNED_NUMBER_PATTERN.matcher(str).matches();
	}

	/**
	 * This method is used to create unwind and match operations for query
	 * 
	 * @param model
	 * @return List of Unwind and Match operation
	 */
	public default List getPatientOperationsList(QueryModel model, String collectionName) {
		PatientInfo info = model.getPatientInfo();
		List<PatientFilter> patientFilter = info.getInit();
		List listOfPatientOperations = new ArrayList();

		MatchOperation matchStageOne = null;
		MatchOperation matchStageThree = null;
		UnwindOperation unwindStageOne = Aggregation.unwind("data");

		listOfPatientOperations.add(unwindStageOne);
		if (patientFilter != null && !patientFilter.isEmpty()) {
			Object[] valArr = null;
			if (!CollectionUtils.isEmpty(patientFilter)) {
				PatientFilter pf = patientFilter.get(0);
				valArr = ClincianServiceHelper.determineAgeValues(pf.getAgeMin(), pf.getAgeMax(), collectionName);
				UnwindOperation unwindStageTwo = Aggregation.unwind(DATA_AGE_DATA);
				listOfPatientOperations.add(unwindStageTwo);
				matchStageThree = Aggregation.match(Criteria.where(DATA_AGE).in(valArr));
				listOfPatientOperations.add(matchStageThree);
			}
		} 
		// logger.info(" returing list of patient " + listOfPatientOperations.size());
		return listOfPatientOperations;

	}

}
