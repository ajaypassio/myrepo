/*
 * Sample only, not integrated with flyway
 * Need to run this script on required db.
 */

db.createCollection("Quest_Clinicians");

db.clinicianSearch.createIndex(
   { npi: 1} );
