package com.questdiagnostics.clinicianservice;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@Ignore
@SpringBootTest
@RunWith(SpringRunner.class)
public abstract class BaseIntegrationTest {
	
	@Autowired
	private ApplicationContext applicationContext;
	
	@Autowired
	protected MongoTemplate mongoTemplate;
	
	@Before
	public void contextLoads() throws Throwable {
		Assert.assertNotNull("application context loaded", this.applicationContext);
	}
	
	protected void cleanUpCollection(String collectionName) {
		mongoTemplate.dropCollection(collectionName);
	}
	
	protected void cleanUpCollections(String... collectionNames) {
		for(String collectionName : collectionNames)
			cleanUpCollection(collectionName);
	}
}
