package com.questdiagnostics.clinicianservice.outreach.campaign;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.Serializable;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;
import com.questdiagnostics.clinicianservice.BaseIntegrationTest;
import com.questdiagnostics.clinicianservice.enums.PhysicianCampaignJobStatusEnums;
import com.questdiagnostics.clinicianservice.outreach.messaging.PhysicianCampaignFeedReceiver;

@Ignore
public class PhysicianCampaignFeedReceiverITest extends BaseIntegrationTest {

	@Autowired
	private PhysicianCampaignFeedReceiver physicianCampaignFeedReceiver;

	static final Gson GSON = new Gson();

	@Value("${physician.campaign.queue.name}")
	private String queueName;

	@Autowired
	private MongoTemplate mongoTemplate;

	private String userName;
	private long sprinttCampaignId;
	private String targetCollection;
	private String targetBatchCollection;

	@Before
	public void setUp() throws Exception {
		userName = "samarth.x.srivastava";
		sprinttCampaignId = 1L;
		targetCollection = userName + "_" + sprinttCampaignId + "_campaign";
		targetBatchCollection = userName + "_" + sprinttCampaignId + "_campaign_batch";
	}
	
	// send message to Azure storage queue (to be consumed by test)
	private void sendMsg(CloudQueueMessage msg) {
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		try {
			storageAccount = CloudStorageAccount
					.parse(physicianCampaignFeedReceiver.getStorageConnectionStringcsvFeedReciever());
			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(queueName);
			queue.createIfNotExists();
			queue.addMessage(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@After
	public void tearDown() throws Exception {
		super.cleanUpCollection(targetCollection);
		super.cleanUpCollection(targetBatchCollection);
	}

	@Test
	public void consumeMsgAndCreateCampaignTest() {
		sendMsg(getCampaignMsgForPass());
		physicianCampaignFeedReceiver.processCampaignMsg();
		// assert campaign collection
		assertTrue(mongoTemplate.collectionExists(targetCollection));
		// assert campaign success status
		assertTrue(mongoTemplate.exists(new Query(Criteria.where("campaignJobStatus").is(PhysicianCampaignJobStatusEnums.CampaignCreationCompleted.getValue())),
				targetBatchCollection));
	}
	
	@Test
	public void consumeMsgAndCampaignNotCreatedTest() {
		sendMsg(getCampaignMsgForFail());
		physicianCampaignFeedReceiver.processCampaignMsg();
		// assert campaign collection
		assertFalse(mongoTemplate.collectionExists(targetCollection));
		assertFalse(mongoTemplate.collectionExists(targetBatchCollection));
	}

	private CloudQueueMessage getCampaignMsgForPass() {
		PhysicianCampaignMsg campaignMsg = new PhysicianCampaignMsg();
		campaignMsg.setSource("quest");
		campaignMsg.setUserName(userName);
		campaignMsg.setSprinttCampaignId(sprinttCampaignId);
		campaignMsg.setState("FL");
		byte[] msgAsByteArr = GSON.toJson(campaignMsg).getBytes();
		return new CloudQueueMessage(msgAsByteArr);
	}
	
	private CloudQueueMessage getCampaignMsgForFail() {
		PhysicianCampaignMsg campaignMsg = new PhysicianCampaignMsg();
		campaignMsg.setSource("quest");
		campaignMsg.setUserName(userName);
		campaignMsg.setSprinttCampaignId(sprinttCampaignId);
		campaignMsg.setState("PA");
		byte[] msgAsByteArr = GSON.toJson(campaignMsg).getBytes();
		return new CloudQueueMessage(msgAsByteArr);
	}

	private static class PhysicianCampaignMsg implements Serializable {

		private static final long serialVersionUID = -1L;

		private String userName;

		private Long sprinttCampaignId;

		private String source;

		private String speciality;

		private String state;

		public String getUserName() {
			return userName;
		}

		@JsonProperty("userName")
		public void setUserName(String userName) {
			this.userName = userName;
		}

		public Long getSprinttCampaignId() {
			return sprinttCampaignId;
		}

		@JsonProperty("sprinttCampaignId")
		public void setSprinttCampaignId(Long sprinttCampaignId) {
			this.sprinttCampaignId = sprinttCampaignId;
		}

		public String getSource() {
			return source;
		}

		@JsonProperty("source")
		public void setSource(String source) {
			this.source = source;
		}

		public String getSpeciality() {
			return speciality;
		}

		@JsonProperty("speciality")
		public void setSpeciality(String speciality) {
			this.speciality = speciality;
		}

		public String getState() {
			return state;
		}

		@JsonProperty("state")
		public void setState(String state) {
			this.state = state;
		}
	}
}