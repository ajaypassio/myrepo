package com.questdiagnostics.clinicianservice.outreach.campaign;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.questdiagnostics.clinicianservice.BaseIntegrationTest;

@Ignore
public class PhysicianCampaignProcessorITest extends BaseIntegrationTest {
	
	@Autowired
	private PhysicianCampaignProcessor processor;
	
	private String testCollectionName;
	private long campaignId;

	@Test
	public void testCreateCampaign() throws Exception {
		// source cannot be null
		Assert.assertFalse(processor.createCampaign(testCollectionName, campaignId,true, null, null));
		
		// query data doesn't match
		Assert.assertFalse(processor.createCampaign(testCollectionName, campaignId, false, null, "PA"));
		
		// query data matches
		Assert.assertTrue(processor.createCampaign(testCollectionName, campaignId, false, null, "FL"));
	}
	
	@Before
	public void cleanUpBefore() {
		testCollectionName = "samarth.x.srivastava";
		campaignId = 1l;
	}
	
	@After
	public void cleanUpAfter() {
		super.cleanUpCollection(testCollectionName + "_" + campaignId + "_campaign");
		super.cleanUpCollection(testCollectionName + "_" + campaignId + "_campaign_batch");
	}

}
