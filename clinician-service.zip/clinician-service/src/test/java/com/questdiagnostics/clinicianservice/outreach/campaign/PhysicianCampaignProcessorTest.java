package com.questdiagnostics.clinicianservice.outreach.campaign;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.questdiagnostics.clinicianservice.model.DisplayRecord;
import com.questdiagnostics.clinicianservice.model.PhysicianCampaignData;
import com.questdiagnostics.clinicianservice.model.PhysicianData;

@Ignore
@RunWith(MockitoJUnitRunner.class)
public class PhysicianCampaignProcessorTest {

	@Mock
	private MongoTemplate mongoTemplate;

	private PhysicianCampaignProcessor processor;
	private List<PhysicianData> physicianData;
	private String sourceCollection;
	private String targetCollection;
	
	@Captor
	private ArgumentCaptor<List<PhysicianCampaignData>> physicianCampaignDataArg;

	@Before
	public void setUp() throws Exception {
		processor = new PhysicianCampaignProcessor(mongoTemplate);
		physicianData = getPhysicianData();
		sourceCollection = "samarth.x.srivastava_physician";
		targetCollection = "samarth.x.srivastava_1";
	}

	@Test
	public void searchResultIsEmptyTest() throws Exception {
		when(mongoTemplate.find(any(Query.class), eq(PhysicianData.class), eq(sourceCollection))).thenReturn(null);
		Assert.assertFalse(processor.createCampaign("samarth.x.srivastava", 1L, false, null, "PA"));
	}

	@Test
	public void sourceNullThrowsExceptionTest() throws Exception {
		Assert.assertFalse(processor.createCampaign("samarth.x.srivastava", 1L, true, null, null));
	}

	@Test
	public void campaignCreatedForNonEmptySearchResultTest() throws Exception {
		when(mongoTemplate.find(any(Query.class), eq(PhysicianData.class), eq(sourceCollection))).thenReturn(physicianData);
		Assert.assertTrue(processor.createCampaign("samarth.x.srivastava", 1L, false, null, "FL"));
		ArgumentCaptor<String> collectionCreationArg = ArgumentCaptor.forClass(String.class);
		verify(mongoTemplate).createCollection(collectionCreationArg.capture());
		assertEquals(targetCollection, collectionCreationArg.getValue());
		verify(mongoTemplate).insert(physicianCampaignDataArg.capture(), collectionCreationArg.capture());
		PhysicianCampaignData physicianCampaignData = physicianCampaignDataArg.getValue().get(0);
		assertEquals(physicianData.get(0).getNpi(), physicianCampaignData.getNpi());
		assertEquals(0, physicianCampaignData.getViewHistories().size());
		assertEquals(1, physicianCampaignData.getDisplayCampaignRecord().getCurrentStatus().getDm());
		assertEquals(1, physicianCampaignData.getDisplayCampaignRecord().getCurrentStatus().getEm());
		assertEquals(1, physicianCampaignData.getDisplayCampaignRecord().getCurrentStatus().getPc());
		
	}

	private List<PhysicianData> getPhysicianData() {
		PhysicianData physician = new PhysicianData();
		physician.setNpi(1003807645);
		physician.setHasAddress("yes");
		physician.setHasEmail("yes");
		physician.setHasPhoneNo("yes");
		physician.setIsBmis("false");
		DisplayRecord displayRecord = new DisplayRecord();
		displayRecord.setNpi(1003807645);
		displayRecord.setAddress1("4371 VERONICA S SHOEMAKER BLVD");
		displayRecord.setAddress2("NULL");
		displayRecord.setCity("FORT MYERS");
		displayRecord.setState("FL");
		displayRecord.setEmail_address("scott@gmail,com");
		displayRecord.setZip("33916");
		displayRecord.setNumber_of_patients(14);
		displayRecord.setSpecialty("HEMATOLOGY ONCOLOGIST");
		displayRecord.setPhone_number("941-957-1000");
		physician.setDisplayRecord(displayRecord);
		physicianData = new ArrayList<>();
		physicianData.add(physician);
		return physicianData;
	}
}