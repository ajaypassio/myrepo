# Criteria Service 

Criteria serivce source code for microservice
CI using Jenkins and Azure Conatainer service via Kubernetes

# Database
Mysql Azure

# per avigo, we need to do a dummy commit to force a new image.