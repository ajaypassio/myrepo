package com.avigosolutions.criteriaservice;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableWebMvc
@EnableSwagger2
@ComponentScan(basePackages = "com.avigosolutions.criteriaservice.controllers")
public class CriteriaserviceConfiguration extends WebMvcConfigurerAdapter {
	/*@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")		
			.allowedMethods("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS")
			.allowedOrigins("*");		

	}*/
	
	/*
	@Bean(name = "dataSource")
	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
		driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/userbase");
		driverManagerDataSource.setUsername("root");
		driverManagerDataSource.setPassword("																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				Sep#1234");
		return driverManagerDataSource;
	}*/
	
	
	@Bean
    public CommonsRequestLoggingFilter logFilter() {
        CommonsRequestLoggingFilter filter
          = new CommonsRequestLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludePayload(true);
        filter.setMaxPayloadLength(10000);
        filter.setIncludeHeaders(true);
        filter.setBeanName("Date: "+new Date());
        filter.setAfterMessagePrefix("<<<<<<< REQUEST DATA : ");
        filter.setBeforeMessagePrefix(">>>>> REQUEST DATA : ");
        return filter;
    }
	
	@Bean
	public Docket docConfig() {
		return new Docket(DocumentationType.SWAGGER_2)
					.select()
					// .apis(Predicates.not(RequestHandlerSelectors.basePackage("org.springframework.boot")))
					.apis(RequestHandlerSelectors.basePackage("com.avigosolutions")) // interested only in avigo controllers
					.paths(PathSelectors.any())
					.build()
					.apiInfo(restApiInfo())
					// .pathMapping("/api") // TODO Fix with right version of Swagger and/or change path
					.directModelSubstitute(LocalDate.class, String.class) // replace local date with String
					.genericModelSubstitutes(ResponseEntity.class)        // we don't want ResponseEntity (spring specific), we want the data that's wrapped inside
					;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    registry.addResourceHandler("swagger-ui.html")
	      .addResourceLocations("classpath:/META-INF/resources/");
	 
	    registry.addResourceHandler("/webjars/**")
	      .addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
	
	private ApiInfo restApiInfo() {
		
		return new ApiInfo("Criteria Service API", "Helps Trial designer to specify inclusion/exclusion criteria for selection of patients", 
				"API TOS", "Terms of service", 
				new Contact("Avigo Solutions LLC", "http://www.avigosolutions.com", "contact@avigosolutions.com"), "", "",
				Collections.emptyList());
	}
	
}