package com.avigosolutions.criteriaservice.constant;

public class CSVConstant {
	/*public static String Header = "Active Study Flag,Region,Standard Country Name,"
			+ "Phase,Primary Therapeutic Area,Primary Indication,Investigational Product Type,TDU,"
			+ "Ultimate Parent Name,Account Name,Address Line 1,Address Line 2,"
			+ "Zip Code,Current Study Site Status,Study Site Number,Project Site IRB Type,City,State,"
			+ "Investigator Name,Phone Number 1";*/
	public static String Header="Active Study Flag,Region,Standard Country Name,Phase,Primary Therapeutic Area,"
			+"Primary Indication,Ultimate Parent Name,Account Name,Address Line 1,Address Line 2,Zip Code,"
			+"Current Study Site Status,Project Site IRB Type,city,State,Investigator Name,Phone Number 1,"
			+"Radius Value,Radius Exempt";
	public static final String UPLOAD_FOLDER = "csv/";
	public static final String ERROR_FOLDER = "csv/error/";
}
