package com.avigosolutions.criteriaservice.constant;

public class Constants {
	
	public static String ASCENDING_ORDER = "asc";
	public static String DESCENDING_ORDER = "desc";
	
	public static String IMPORT_STATUS_NEW="New";
	public static String IMPORT_STATUS_INPROGRESS="InProgress";
	public static String IMPORT_STATUS_SUBMITTED="Submitted";
    public static String IMPORT_STATUS_SUCCESS="Success";
    public static String INEX_STATUS_COMPLETE="Complete";
    public static String IMPORT_STATUS_FAILED="Failed";
    public static String IMPORT_STATUS_ERROR="Error";
    public static String VALIDATION_FAILED_FOR_COLLECTION="Validation Failed For Collection";
	public static String IMPORT_STATUS_PARTIAL_SUCCESS="Partially Success";
	public static String SET_RADIUS="Set Radius";
	public static String TITLE="title";
	public static String VALUE="value";
	public static String STUDY_SITES="studySites";
	public static String UPLOAD_STUDY_SITE_BEFORE_SAVING_CRITERIA ="Upload StudySite List before proceeding with criteria processing";
	public static String TRIALID="trialId";
	public static String SUBMITTED_CRITERIA_MSG="Patients migration process is in progress. Once this is complete try again";
	public static String IE_INCOMING_FOLDER="inclusion-exclusion";
	public static String SUCCESS_STATUS="Success";
	public static String USER_NEED_TO_INSERT="User Need to go for Inserting a new criteria";
	public static String USER_NEED_TO_UPDATE="User Need to go for Updating the existing criteria";
	//public static String USER_NOT_FOUND="User criteria not found";
	public static String USER_NOT_FOUND="***No Data is Available***";
	public static String ADMIN ="ADMIN";
	public static String SEARCH_IN_PROGRESS="***Search is in progress.***";
	public static String USER_NAME_BLANK_OR_NULL ="UserName cannot be blank or null";
	public static String DRAFT_STATE ="DRAFT";
	public static String COUNT_REQUEST_SUBMITTED="Count request submitted successfully";
	public static String ENABLED="enabled";
	public static String DISABLED="disabled";
	public static String NOT_FOUND="Not Found";
	public static String IE_PHYSICIAN_CRITERIA_FOLDER="physician_criteria_input";
	public static String SEARCH_COUNT_STATICS_AVAIBLE_DO_YOU_WANT_TO_REPLACE="Search count statics is available. Do you want to replace the last search ?";
	public static String SEARCH_AVAIBLE_DO_YOU_WANT_TO_REPLACE="Search is available. Do you want to replace the last search ?";
	public static String STATUS_UPDATED="Status Updated Successfully.";
	public static final String REQUESTED_OPERATION_FAILED = "Requested operation failed";
	public static final String MONGO_PERSISTENCE_INITIATED="Mongo Persistence Request Successfully submitted.";
	public static String NEWSEARCH = "newSearch";
	public static String LASTSEARCH = "lastSearch";
	public static String CURRENT_SEARCH_CRITERIA_HAS_NO_PHYSICIANS = "Current search criteria has no physicians. Please update the search criteria and try again";
	public static final String USERID ="userId";
	public static final String TRIAL_NAME ="trialName";
	public static final String PHYSICIAN_SEARCH_COUNTS_START ="Physician Search Counts-Start";
	public static final String PHYSICIAN_SEARCH_RESULTS_START ="Physician Search Results-Start";
	public static final String PHYSICIAN_SEARCH_RESULTS_SUCCESS ="Physician Search Results-Success";
	public static final String PHYSICIAN_SEARCH_RESULTS_FAILURE ="Physician Search Results-Failure";
}
