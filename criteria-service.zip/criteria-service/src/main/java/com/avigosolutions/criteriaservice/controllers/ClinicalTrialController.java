package com.avigosolutions.criteriaservice.controllers;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.dto.ClinicalTrialLightWeightDTO;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteTrialRequest;
import com.avigosolutions.criteriaservice.request.model.TrialDetails;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.ClinicalTrialService;

@Controller
@RequestMapping(path = "/trials")
public class ClinicalTrialController {

	@Autowired
	private ClinicalTrialService clinicalTrialService;
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ClinicalTrial>> getAllTrials(@RequestHeader HttpHeaders headers) {
		List<ClinicalTrial> clinicalTrials = this.clinicalTrialService.findAll();
		if (clinicalTrials == null)
			return new ResponseEntity<List<ClinicalTrial>>(clinicalTrials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ClinicalTrial>>(clinicalTrials, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/all/criteria", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTrialsWithCriteria(@RequestHeader HttpHeaders headers,
			@RequestParam int start, @RequestParam int pageSize, @RequestParam String trialName) {
		ResponseObjectModel clinicalTrials = this.clinicalTrialService.findAllWithCriteriaOnly(start, pageSize,
				trialName);
		if (clinicalTrials == null)
			return new ResponseEntity<ResponseObjectModel>(clinicalTrials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(clinicalTrials, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/all_trials/{programId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ClinicalTrial>> getAllTrials(@RequestHeader HttpHeaders headers,
			@PathVariable Long programId) {
		List<ClinicalTrial> clinicalTrials = this.clinicalTrialService.getClinicalTrialsByProgramId(programId);
		if (clinicalTrials == null)
			return new ResponseEntity<List<ClinicalTrial>>(clinicalTrials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ClinicalTrial>>(clinicalTrials, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/page/criteriaonly", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getTrialsByPageCriteria(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrialFilterRequestModel filterModel) {
		ResponseObjectModel clinicalTrials = this.clinicalTrialService.getTrialsByPageCriteria(filterModel);
		if (clinicalTrials == null)
			return new ResponseEntity<ResponseObjectModel>(clinicalTrials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(clinicalTrials, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/exclude/program/search", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTrialsWithoutProgramByFilter(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrialFilterRequestModel filterModel) {
		ResponseObjectModel reponseObject = this.clinicalTrialService.findAllUnAssociatedProgram(filterModel);
		return new ResponseEntity<ResponseObjectModel>(reponseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/search", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTrialsByFilter(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrialFilterRequestModel filterModel) {
		ResponseObjectModel reponseObject = this.clinicalTrialService.findAll(filterModel);
		return new ResponseEntity<ResponseObjectModel>(reponseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/{trialId}", method = RequestMethod.GET)
	public ResponseEntity<ClinicalTrial> getTrial(@RequestHeader HttpHeaders headers, @PathVariable Long trialId) {
		ClinicalTrial trial = this.clinicalTrialService.findOne(trialId);
		if (trial == null)
			return new ResponseEntity<ClinicalTrial>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<ClinicalTrial>(trial, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/all/{trialIds}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ClinicalTrial>> getTrialByTrialId(@RequestHeader HttpHeaders headers,
			@PathVariable String trialIds) {
		String[] strList = trialIds.split(",");
		List<Long> intList = new ArrayList<Long>();
		for (String s : strList)
			intList.add(Long.valueOf(s));
		List<ClinicalTrial> trialList = this.clinicalTrialService.findByTrialIdIn(intList);
		if (trialList == null)
			return new ResponseEntity<List<ClinicalTrial>>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ClinicalTrial>>(trialList, HttpStatus.OK);

	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> createTrial(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrial clinicalTrial) {
		logger.info(clinicalTrial.toString());
		ResponseObjectModel trial = this.clinicalTrialService.save(clinicalTrial);
		if (trial == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ResponseObjectModel>(trial, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/add/{trialId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ResponseObjectModel> updateTrial(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId, @RequestBody ClinicalTrial trial) {
		logger.info("----UPDATE AND PATIENT LIST GENERATION: " + trial.toString() + "---");
		ResponseObjectModel responseObject = new ResponseObjectModel();
		ClinicalTrial ct = trial.withTrialId(trialId);
		
		responseObject = this.clinicalTrialService.update(ct);

		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(responseObject,
				HttpStatus.OK);
		// if(responseObject.getStatus()!=HTTPResponse.SC_OK)
		// rect= new
		// ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		;
		return rect;
	}

	@RequestMapping(value = "/delete/{trialId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','DELETE')")
	public ResponseEntity<ClinicalTrial> deleteTrial(@RequestHeader HttpHeaders headers, @PathVariable Long trialId) {
		clinicalTrialService.delete(trialId);
		return new ResponseEntity<ClinicalTrial>(HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/update/radiusOverride/{trialId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ResponseObjectModel> updateRadiusOverrideFOrTrial(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId, @RequestBody ClinicalTrialLightWeightDTO trial) {
		logger.info("----Inside updateRadiusOverrideFOrTrial method-----");
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject = this.clinicalTrialService.updateTrialRadiusOverride(trial.getTrialId(),
				trial.isRadiusOverride());
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(responseObject,
				HttpStatus.OK);
		return rect;
	}

	@ResponseBody
	@RequestMapping(value = "/update/sites/ignore/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> updateStudySitesIgnoreClicked(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId) {

		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject = this.clinicalTrialService.updateTrialStudySiteIgnore(trialId);
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(responseObject,
				HttpStatus.OK);
		return rect;
	}
	

	/** This method will give the latest TrailJob creation time */
	@ResponseBody
	@RequestMapping(path = "/latestTrailJob/{trailId}", method = RequestMethod.GET)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','GET')")
	public Long getLatestTrailJob(@RequestHeader HttpHeaders headers, @PathVariable Long trailId) {
		logger.info("--------------Inside getAllProgTrialsAssociated method------------------------------");
		
		long latestTym =clinicalTrialService.getLatestTrailJob(trailId);
		logger.info("tym>>"+latestTym);
		return latestTym;
	}
	
	
	@ResponseBody
	@RequestMapping(path = "/studySite/trialDetails", method = RequestMethod.POST)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> getSiteCoordinatorTrials(@RequestHeader HttpHeaders headers,
			@RequestBody StudySiteTrialRequest studySiteTrialRequest) {
		ResponseObjectModel clinicalTrials = this.clinicalTrialService.getStudySiteTrialDetails(studySiteTrialRequest);
		if (clinicalTrials == null)
			return new ResponseEntity<ResponseObjectModel>(clinicalTrials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(clinicalTrials, HttpStatus.OK);

	}
	
	@PostMapping(value = "/addTherapeuticArea")
	public ResponseEntity<ResponseObjectModel> addTherapeuticArea (@RequestHeader HttpHeaders headers,
			@RequestBody TrialDetails trialDetails) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.clinicalTrialService.addTherapeuticArea(trialDetails);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(value = "/addTrialCondition")
	public ResponseEntity<ResponseObjectModel> addTrialCondition (@RequestHeader HttpHeaders headers,
			@RequestBody TrialDetails trialDetails) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.clinicalTrialService.addTrialCondition(trialDetails);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}
}
