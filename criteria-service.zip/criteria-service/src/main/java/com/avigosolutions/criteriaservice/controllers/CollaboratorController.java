package com.avigosolutions.criteriaservice.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.model.Collaborator;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.CollaboratorService;

@Controller
@RequestMapping(path = "/collaborators")
public class CollaboratorController {
	@Autowired
	CollaboratorService collaboratorService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Collaborator>> getAllCollaborators(@RequestHeader HttpHeaders headers) {
		List<Collaborator> collaborators = this.collaboratorService.findAll();	
		if (collaborators == null)
			return new ResponseEntity<List<Collaborator>>(collaborators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Collaborator>>(collaborators, HttpStatus.OK);
	}
	
	@RequestMapping(path = "/{collaboratorId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Collaborator> getCollaborator(@RequestHeader HttpHeaders headers, @PathVariable Long collaboratorId) {
		Collaborator collaborator = this.collaboratorService.findOne(collaboratorId);		
		if (collaborator == null)
			return new ResponseEntity<Collaborator>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Collaborator>(collaborator, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<Collaborator> createCollaborator(@RequestHeader HttpHeaders headers, @RequestBody Collaborator collaborator) {
		logger.debug(collaborator.toString());
		collaborator = this.collaboratorService.save(collaborator);
		if (collaborator == null)
			return new ResponseEntity<Collaborator>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Collaborator>(collaborator, HttpStatus.CREATED);
	}
	
	@ResponseBody
	@RequestMapping(value = "/add/{collaboratorId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<Collaborator> updateCollaborator(@RequestHeader HttpHeaders headers, @PathVariable Long collaboratorId, @RequestBody Collaborator collaborator) {
		logger.debug("----UPDATE: "+ collaborator.toString()+"---");
		Collaborator ct = collaborator.withCollaboratorId(collaboratorId);

		ct = this.collaboratorService.update(ct);
		ResponseEntity<Collaborator> rect =  new ResponseEntity<Collaborator> (ct, HttpStatus.OK);
		return rect;
	}

	@ResponseBody
	@RequestMapping(path = "/all/by_page", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllCollaborators(@RequestHeader HttpHeaders headers,
			@RequestParam("page") int page, @RequestParam("page_size") int pageSize) {
		ResponseObjectModel responseObject = this.collaboratorService.getAll(page, pageSize);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);
	}
}
