package com.avigosolutions.criteriaservice.controllers;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteFilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
import com.avigosolutions.criteriaservice.service.CoordinatorService;
import com.avigosolutions.criteriaservice.service.ProgramService;
import com.avigosolutions.criteriaservice.service.StudySiteService;

@Controller
@RequestMapping(path = "/coordinators")
public class CoordinatorController {
	@Autowired
	CoordinatorService coordinatorService;
	
	@Autowired
	private StudySiteService studySiteService;
	
	@Autowired
	private ClinicalTrialService clinicalTrialService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ProgramService programService;

	@ResponseBody
	@RequestMapping(path = "/studysites/{coordinatorId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Long>> getStudySitesByCoordinatorId(@RequestHeader HttpHeaders headers,
			@PathVariable("coordinatorId") Long coordinatorId) {
		List<Long> studySiteCoordinators = this.coordinatorService.getStudySitesByCoordintorId(coordinatorId);
		if (studySiteCoordinators == null)
			return new ResponseEntity<List<Long>>(studySiteCoordinators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Long>>(studySiteCoordinators, HttpStatus.OK);
	}
	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Coordinator>> getAllCoordinators(@RequestHeader HttpHeaders headers) {
		List<Coordinator> coordinators = this.coordinatorService.findAll();
		if (coordinators == null)
			return new ResponseEntity<List<Coordinator>>(coordinators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Coordinator>>(coordinators, HttpStatus.OK);

	}
	
	@ResponseBody
	@RequestMapping(path = "/all/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Coordinator>> getAllCoordinatorsByStudySiteId(@RequestHeader HttpHeaders headers,Long studySiteId ) {
		List<Coordinator> coordinators = this.coordinatorService.findByStudySiteId(studySiteId);
		if (coordinators == null)
			return new ResponseEntity<List<Coordinator>>(coordinators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Coordinator>>(coordinators, HttpStatus.OK);

	}
	
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<Coordinator> createCoordinator(@RequestHeader HttpHeaders headers, @RequestBody Coordinator coordinator) {
		logger.info("----CREATE" + coordinator.toString() + "---");
		Coordinator coordinatorObj = this.coordinatorService.save(coordinator);
		if (coordinatorObj == null) 
			return new ResponseEntity<Coordinator>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Coordinator>(coordinatorObj, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/add/{coordinatorId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<Coordinator> updateCoordinator(@RequestHeader HttpHeaders headers, @PathVariable Long coordinatorId, @RequestBody Coordinator coordinator) {
		logger.info("----UPDATE: "+coordinator.toString()+"---");
		Coordinator c = coordinator.withCoordinatorId(coordinatorId);
		Coordinator coordinatorObj = this.coordinatorService.update(c);
		if (coordinatorObj == null) 
			return new ResponseEntity<Coordinator>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Coordinator>(coordinatorObj, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/delete/{coordinatorId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','DELETE')")
	public ResponseEntity<Coordinator> deleteCoordinator(@RequestHeader HttpHeaders headers, @PathVariable Long coordinatorId) {
		coordinatorService.delete(coordinatorId);
		return new ResponseEntity<Coordinator>(HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/studysites/{trialId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllStudySitesByTrailId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @RequestBody StudySiteFilterRequestModel studySiteFilterRequest) {
		ResponseObjectModel response = studySiteService.getAllStudySitesByTrailId(trialId, studySiteFilterRequest);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/trial/add/{coordinatorId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> createTrialForCoordinator(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrial clinicalTrial, @PathVariable Long coordinatorId) {
		logger.info(clinicalTrial.toString());
		ResponseObjectModel trial = this.clinicalTrialService.save(clinicalTrial);
		if (trial == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ResponseObjectModel>(trial, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/trial/add/{coordinatorId}/{trialId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ResponseObjectModel> updateTrialForCoordinator(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId, @RequestBody ClinicalTrial trial,  @PathVariable Long coordinatorId) {
		logger.info("----UPDATE: " + trial.toString() + "---");
		ResponseObjectModel responseObject = new ResponseObjectModel();
		ClinicalTrial ct = trial.withTrialId(trialId);
		List<Criteria> criterias = ct.getCriterias();
		for (Criteria criteria : criterias) {
			criteria.withTrialId(trialId);
		}
		responseObject = this.clinicalTrialService.update(ct);

		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(responseObject,
				HttpStatus.OK);
		
		return rect;
	}

	@RequestMapping(value = "/trial/delete/{coordinatorId}/{trialId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','DELETE')")
	public ResponseEntity<ClinicalTrial> deleteTrialForCoordinator(@RequestHeader HttpHeaders headers, @PathVariable Long trialId,  @PathVariable Long coordinatorId) {
		clinicalTrialService.delete(trialId,coordinatorId);
		return new ResponseEntity<ClinicalTrial>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/trial/{coordinatorId}/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ClinicalTrial>> getAllTrials(@RequestHeader HttpHeaders headers, @PathVariable Long coordinatorId) {
		List<ClinicalTrial> clinicalTrials = this.clinicalTrialService.findAll(coordinatorId);
		if (clinicalTrials == null)
			return new ResponseEntity<List<ClinicalTrial>>(clinicalTrials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ClinicalTrial>>(clinicalTrials, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/trial/{coordinatorId}/all", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTrialsByFilter(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrialFilterRequestModel filterModel,@PathVariable Long coordinatorId) {
		ResponseObjectModel reponseObject = this.clinicalTrialService.findAll(filterModel,coordinatorId);
		return new ResponseEntity<ResponseObjectModel>(reponseObject, HttpStatus.OK);

	}
	
	@ResponseBody
	@RequestMapping(path = "/trial/independent/{coordinatorId}/all", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllIndependentTrialsByFilter(@RequestHeader HttpHeaders headers,
			@RequestBody ClinicalTrialFilterRequestModel filterModel,@PathVariable Long coordinatorId) {
		ResponseObjectModel reponseObject = this.clinicalTrialService.findAllUnAssociatedProgram(filterModel.withCoordinatorId(coordinatorId));
		return new ResponseEntity<ResponseObjectModel>(reponseObject, HttpStatus.OK);

	}
	
	@ResponseBody
	@RequestMapping(path = "/program/{coordinatorId}/all", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllProgramsByFilter(@RequestHeader HttpHeaders headers,
			@RequestBody FilterRequestModel filterModel,@PathVariable Long coordinatorId) {
		ResponseObjectModel reponseObject = this.programService.findAll(filterModel.withCoordinatorId(coordinatorId));
		return new ResponseEntity<ResponseObjectModel>(reponseObject, HttpStatus.OK);

	}
}
