package com.avigosolutions.criteriaservice.controllers;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.CriteriaService;
import com.avigosolutions.criteriaservice.util.SasGenerationUtil;
import com.microsoft.azure.storage.StorageException;

@Controller
@RequestMapping(path="/criteria")
public class CriteriaController {

	@Autowired
	private CriteriaService criteriaService;
	
	@Autowired
	private SasGenerationUtil sasGenerationUtil;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	//NO need for transactions at the REST level
	/**
	 * @param headers
	 * @param Ids
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path = "/ids", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<List<Criteria>> getCriteriaByIds(@RequestHeader HttpHeaders headers, @RequestBody List<Long> Ids) {
		List<Criteria> criteria = this.criteriaService.findByIdIn(Ids);
		if (criteria == null)
			return new ResponseEntity<List<Criteria>>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Criteria>>(criteria, HttpStatus.OK);
	}
	
	/**
	 * @param headers
	 * @return
	 */
	@ResponseBody
	@RequestMapping(path = "/", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Criteria>> getAllCriteria(@RequestHeader HttpHeaders headers) {
		List<Criteria> criteria = this.criteriaService.findAll();
		if (criteria == null)
			return new ResponseEntity<List<Criteria>>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Criteria>>(criteria, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/{criteriaId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Criteria> getCriteria(@RequestHeader HttpHeaders headers, @PathVariable Long criteriaId) {
		Criteria criteria = this.criteriaService.findOne(criteriaId);		
		if (criteria == null)
			return new ResponseEntity<Criteria>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Criteria>(criteria, HttpStatus.OK);
		
	}
	
	@ResponseBody
	@RequestMapping(path = "/id", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Criteria>> getCriteriaByTrialId(@RequestHeader HttpHeaders headers, @RequestParam(value = "trialId") long trialId) {
		List<Criteria> criteriaList = this.criteriaService.findByTrialId(trialId);
		if (criteriaList == null)
			return new ResponseEntity<List<Criteria>>(HttpStatus.NOT_FOUND);
		ResponseEntity<List<Criteria>> response = new ResponseEntity<List<Criteria>>(criteriaList, HttpStatus.OK);
		return response;
	}
	
	@RequestMapping(value = "/add/", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<Criteria> createCriteria(@RequestHeader HttpHeaders headers, @RequestBody Criteria criteria) {
		logger.info("----CREATE" + criteria.toString() + "---");
		Criteria criteriaObj = this.criteriaService.save(criteria);
		if (criteriaObj == null) 
			return new ResponseEntity<Criteria>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Criteria>(criteriaObj, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/add/{criteriaId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<Criteria> updateCriteria(@RequestHeader HttpHeaders headers, @PathVariable Long criteriaId, @RequestBody Criteria criteria) {
		logger.info("----UPDATE: "+criteria.toString()+"---");
		Criteria c = criteria.withCriteriaId(criteriaId);
		Criteria criteriaObj = this.criteriaService.update(c);
		if (criteriaObj == null) 
			return new ResponseEntity<Criteria>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Criteria>(criteriaObj, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/delete/{criteriaId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','DELETE')")
	public ResponseEntity<Criteria> deleteCriteria(@RequestHeader HttpHeaders headers, @PathVariable Long criteriaId) {
		criteriaService.delete(criteriaId);
		return new ResponseEntity<Criteria>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getDownloadableSASString", method = RequestMethod.GET)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity getSpecificMessagePayload(@RequestHeader HttpHeaders headers, @RequestParam(value = "trialId") long trialId) throws InvalidKeyException, MalformedURLException, URISyntaxException, StorageException{
		ResponseObjectModel responseObjectModel = sasGenerationUtil.getBlobSASString(trialId);
		logger.info("Return String is:"+responseObjectModel.getMessage());
		return new ResponseEntity<ResponseObjectModel>(responseObjectModel, HttpStatus.OK);
	}
}
