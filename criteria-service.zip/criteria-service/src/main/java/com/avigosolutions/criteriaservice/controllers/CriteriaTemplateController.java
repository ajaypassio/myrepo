package com.avigosolutions.criteriaservice.controllers;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.model.CriteriaTemplate;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.CriteriaService;
import com.avigosolutions.criteriaservice.service.CriteriaTemplateService;

@Controller
@RequestMapping(path = "/templates")
public class CriteriaTemplateController {

	@Autowired
	private CriteriaTemplateService criteriaTemplateService;

	@Autowired
	private CriteriaService criteriaService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','GET')")
	public ResponseEntity<List<CriteriaTemplate>> getAllTemplate(@RequestHeader HttpHeaders headers) {
		List<CriteriaTemplate> criteriaTemplate = this.criteriaTemplateService.findAll();
		if (criteriaTemplate == null)
			return new ResponseEntity<List<CriteriaTemplate>>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<CriteriaTemplate>>(criteriaTemplate, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/all/page", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTemplateByPage(@RequestHeader HttpHeaders headers,
			@RequestParam int start, @RequestParam int pageSize) {
		ResponseObjectModel responseObject = this.criteriaTemplateService.getAllByPage(start, pageSize);
		if (responseObject == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/{templateId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','GET')")
	public ResponseEntity<CriteriaTemplate> getTemplateById(@RequestHeader HttpHeaders headers,
			@PathVariable Long templateId) {
		CriteriaTemplate criteriaTemplate = this.criteriaTemplateService.findOne(templateId);
		if (criteriaTemplate == null)
			return new ResponseEntity<CriteriaTemplate>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<CriteriaTemplate>(criteriaTemplate, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/criteriabytemplateId", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','GET')")
	public ResponseEntity<List<Criteria>> getCriteriaByTemplateId(@RequestHeader HttpHeaders headers,
			@RequestParam(value = "templateId") long templateId) {
		List<Criteria> criteriaList = this.criteriaService.findByTemplateId(templateId);
		if (criteriaList == null)
			return new ResponseEntity<List<Criteria>>(HttpStatus.NOT_FOUND);
		ResponseEntity<List<Criteria>> response = new ResponseEntity<List<Criteria>>(criteriaList, HttpStatus.OK);
		return response;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','POST')")
	public ResponseEntity<ResponseObjectModel> createTemplate(@RequestHeader HttpHeaders headers,
			@RequestBody CriteriaTemplate criteriaTemplate) {
		logger.info("----CREATE" + criteriaTemplate.toString() + "---");
		ResponseObjectModel templateObj = this.criteriaTemplateService.save(criteriaTemplate);
		if (templateObj == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ResponseObjectModel>(templateObj, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/add/{templateId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','PUT')")
	public ResponseEntity<ResponseObjectModel> updateCriteriaTemplate(@RequestHeader HttpHeaders headers,
			@PathVariable Long templateId, @RequestBody CriteriaTemplate criteriaTemplate) {
		logger.info("----UPDATE: " + criteriaTemplate.toString() + "---");
		CriteriaTemplate ct = criteriaTemplate.withTemplateId(templateId);
		ResponseObjectModel optTemplate = this.criteriaTemplateService.update(ct);
		/*
		 * ResponseEntity<CriteriaTemplate> rect = optTemplate.map(CriteriaTemplate ->
		 * new ResponseEntity<CriteriaTemplate> (criteriaTemplate, HttpStatus.OK))
		 * .orElse(new
		 * ResponseEntity<CriteriaTemplate>(HttpStatus.INTERNAL_SERVER_ERROR));
		 */
		if (optTemplate == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ResponseObjectModel>(optTemplate, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/delete/{templateId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TEMPLATE','DELETE')")
	public ResponseEntity<Boolean> deleteCriteriaTemplate(@RequestHeader HttpHeaders headers,
			@PathVariable Long templateId) {
		try {
			criteriaTemplateService.delete(templateId);
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
		}
	}

}
