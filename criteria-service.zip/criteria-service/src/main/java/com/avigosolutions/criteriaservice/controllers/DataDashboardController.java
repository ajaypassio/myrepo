package com.avigosolutions.criteriaservice.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.avigosolutions.criteriaservice.response.model.ReportResponse;

import com.avigosolutions.criteriaservice.service.ReportService;

@Controller
@RequestMapping(path = "/dashboard")
public class DataDashboardController {
	@Autowired
	ReportService  reportService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(path = "/report", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ReportResponse> getData(@RequestHeader HttpHeaders headers) {
		ReportResponse reportResponse = this.reportService.getReport();
		if (reportResponse == null)
			return new ResponseEntity<ReportResponse>(reportResponse, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ReportResponse>(reportResponse, HttpStatus.OK);
	}
}
