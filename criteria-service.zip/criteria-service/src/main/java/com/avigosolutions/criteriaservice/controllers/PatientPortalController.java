package com.avigosolutions.criteriaservice.controllers;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Questionnaire;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.StudySiteResponse;
import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
import com.avigosolutions.criteriaservice.service.QuestionnaireService;
import com.avigosolutions.criteriaservice.service.StudySiteService;
import com.avigosolutions.criteriaservice.util.EncryptionUtils;

@Controller
@RequestMapping(path = "/criteria/patient")
public class PatientPortalController {

	@Autowired
	private StudySiteService studySiteService;

	@Autowired
	QuestionnaireService questionnaireService;

	@Autowired
	private ClinicalTrialService clinicalTrialService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	/*@ResponseBody
	@RequestMapping(path = "/questionnaires/{questionnaireId}", method = RequestMethod.GET)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<Questionnaire> getQuestionnaire(@RequestHeader HttpHeaders headers,
			@PathVariable("questionnaireId") String questionnaireIdStr) {
		logger.info(">>>> getQuestionnaire");
			Long questionnaireId;
		try {
			questionnaireId=(long) Integer.parseInt(questionnaireIdStr);
		}catch(Exception e) {
			questionnaireId=(long) Integer.parseInt(EncryptionUtils.getInstance().decryptFromBase64(questionnaireIdStr));
		}
		Questionnaire questionnaire = this.questionnaireService.findOne(questionnaireId);

		if (questionnaire == null) {
			return new ResponseEntity<>(questionnaire, HttpStatus.NOT_FOUND);
		}
		logger.info(questionnaire.toString());
		logger.info("<<<< getQuestionnaire");
		return new ResponseEntity<Questionnaire>(questionnaire, HttpStatus.OK);
	}*/
	
	@ResponseBody
	@RequestMapping(path = "/questionnaires/{surveyId}/{trialId}", method = RequestMethod.GET)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<ResponseObjectModel> getTrialDetailforSurvey(@RequestHeader HttpHeaders headers,
			@PathVariable("surveyId") String surveyId, @PathVariable("trialId") String trialIdStr) {
		logger.info("Inside getTrialDetailforSurvey method");
		ResponseObjectModel responseObjectModel = null;
		Long trialId ;
		try {
			try{
				trialId = (long) Integer.parseInt(EncryptionUtils.getInstance().decryptFromBase64(trialIdStr));
			}
			catch(Exception e){
				logger.error("Exception: in PROCESSING : method : {} \n {} ",
						Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
				responseObjectModel = new ResponseObjectModel();
				responseObjectModel.setMessage("Exception to decrypt trialId:" + trialIdStr);
				return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
			}
			responseObjectModel = this.questionnaireService.retrieveTrialProgramIdAndName(surveyId, trialId);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}	
	}

	@ResponseBody
	@RequestMapping(path = "/trials/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<ClinicalTrial> getTrial(@RequestHeader HttpHeaders headers, @PathVariable Long trialId) {
		logger.info(">>>> getTrial");
		ClinicalTrial trial = this.clinicalTrialService.findOne(trialId);
		if (trial == null)
			return new ResponseEntity<ClinicalTrial>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<ClinicalTrial>(trial, HttpStatus.OK);
	}

	// It is only used in campaign getting studysites module.
	@ResponseBody
	@RequestMapping(path = "/studysites/search/zip/miles", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<StudySiteResponse> getStudySitesByZip(@RequestHeader HttpHeaders headers,
			@RequestParam("trialId") Long trialId, @RequestParam("zip") Long zip, @RequestParam("miles") Float miles) {
		StudySiteResponse studySites = this.studySiteService.getStudySitesByTrialZipMiles(trialId, zip, miles);
		if (studySites == null)
			return new ResponseEntity<StudySiteResponse>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<StudySiteResponse>(studySites, HttpStatus.OK);

	}

	// get studysites by ids
	@ResponseBody
	@RequestMapping(path = "/studysites/all/{studySiteIds}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<List<StudySiteDto>> getStudySitesByIds(@RequestHeader HttpHeaders headers,
			@PathVariable String studySiteIds, @RequestParam(value = "start") int start,
			@RequestParam(value = "pageSize") int pageSize) {
		String[] strList = studySiteIds.split(",");
		List<Long> idsList = new ArrayList<Long>();
		for (String s : strList)
			idsList.add(Long.valueOf(s));
		List<StudySiteDto> studySites = this.studySiteService.getStudySitesByIds(idsList, start, pageSize);
		if (studySites == null)
			return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.OK);
	}
}
