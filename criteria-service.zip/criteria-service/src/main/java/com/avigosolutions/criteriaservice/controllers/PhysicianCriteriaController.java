package com.avigosolutions.criteriaservice.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import com.avigosolutions.criteriaservice.constant.Constants;
import com.avigosolutions.criteriaservice.enums.PhysicianCriteriaEnums;
import com.avigosolutions.criteriaservice.request.model.PhysicianCriteria;
import com.avigosolutions.criteriaservice.request.model.PhysicianCriteriaRequest;
import com.avigosolutions.criteriaservice.request.model.UserNameRequest;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.PhysicianCriteriaService;

@Controller
@RequestMapping(path = "/physician")
public class PhysicianCriteriaController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	PhysicianCriteriaService physicianCriteriaService;

	@PostMapping(value = "/criteria/persist")
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> createCriteria(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianCriteriaRequest physicianCriteriaRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCriteriaService.createCriteria(physicianCriteriaRequest);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			PhysicianCriteria criteria = new PhysicianCriteria();
			if (!physicianCriteriaRequest.isCountClicked()) {
				this.physicianCriteriaService.saveCountPhysicianResultsButtonEnableDisable(
						(Long.valueOf(PhysicianCriteriaEnums.Draft.getValue())), criteria, Constants.NEWSEARCH);
			} else {
				this.physicianCriteriaService.saveCountPhysicianResultsButtonEnableDisable(
						Long.valueOf(PhysicianCriteriaEnums.Submitted.getValue()), criteria, Constants.NEWSEARCH);
			}
			responseObjectModel.setData(criteria);
			responseObjectModel.setMessage(Constants.REQUESTED_OPERATION_FAILED);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}

	}

	@PutMapping(value = "/criteria/modify")
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> updateCriteria(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianCriteriaRequest physicianCriteriaRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCriteriaService.updateCriteria(physicianCriteriaRequest);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			PhysicianCriteria criteria = new PhysicianCriteria();
			this.physicianCriteriaService
					.saveCountPhysicianResultsButtonEnableDisable(physicianCriteriaRequest.getStatusId(), criteria, Constants.NEWSEARCH);
			responseObjectModel.setData(criteria);
			responseObjectModel.setMessage(Constants.REQUESTED_OPERATION_FAILED);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/criteria/getDetails")
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> getCriteria(@RequestHeader HttpHeaders headers,
			@RequestBody UserNameRequest userNameRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCriteriaService.getCriteria(userNameRequest);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			PhysicianCriteria criteria = new PhysicianCriteria();
			this.physicianCriteriaService.saveCountPhysicianResultsButtonEnableDisable(
					Long.valueOf(PhysicianCriteriaEnums.Draft.getValue()), criteria, userNameRequest.getSource());
			responseObjectModel.setData(criteria);
			responseObjectModel.setMessage(Constants.REQUESTED_OPERATION_FAILED);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/criteria/generatePhysicianResults")
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> generatePhysicianResults(@RequestHeader HttpHeaders headers,
			@RequestBody UserNameRequest userNameRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		try {
			responseObjectModel = this.physicianCriteriaService.generatePhysicianResults(userNameRequest);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception: in PROCESSING : method : {} \n {} ",
					Thread.currentThread().getStackTrace()[1].getMethodName(), e.getStackTrace());
			PhysicianCriteria criteria = new PhysicianCriteria();
			this.physicianCriteriaService.saveCountPhysicianResultsButtonEnableDisable(
					Long.valueOf(PhysicianCriteriaEnums.Draft.getValue()), criteria, Constants.LASTSEARCH);
			responseObjectModel.setData(criteria);
			responseObjectModel.setMessage(Constants.REQUESTED_OPERATION_FAILED);
			return new ResponseEntity<>(responseObjectModel, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/criteria/getPhysicianWithGeneratedStatus")
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<PhysicianCriteria> getPhysicianByStatus() {
		PhysicianCriteria criteriaDetails = this.physicianCriteriaService.getPhysicianWithGeneratedStatus();
		if (criteriaDetails == null)
			return new ResponseEntity<PhysicianCriteria>(criteriaDetails, HttpStatus.NOT_FOUND);
		return new ResponseEntity<PhysicianCriteria>(criteriaDetails, HttpStatus.OK);
	}

	@PutMapping(value = "/criteria/updatePhysicianStatus")
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<PhysicianCriteria> updatePhysicianStatus(@RequestHeader HttpHeaders headers,
			@RequestBody PhysicianCriteriaRequest physicianCriteriaRequest) {
		PhysicianCriteria criteriaDetails = this.physicianCriteriaService
				.updatePhysicianStatus(physicianCriteriaRequest);
		if (criteriaDetails == null)
			return new ResponseEntity<PhysicianCriteria>(criteriaDetails, HttpStatus.NOT_FOUND);
		return new ResponseEntity<PhysicianCriteria>(criteriaDetails, HttpStatus.OK);
	}

}
