package com.avigosolutions.criteriaservice.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.ProgramService;

@Controller
@RequestMapping(path = "/programs")
public class ProgramController {
	@Autowired
	ProgramService programService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','GET')")
	public ResponseEntity<List<Program>> getAllPrograms(@RequestHeader HttpHeaders headers) {
		List<Program> programs = this.programService.findAll();	
		if (programs == null)
			return new ResponseEntity<List<Program>>(programs, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Program>>(programs, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/search", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','GET')")
	public ResponseEntity<ResponseObjectModel> getAllProgramsByFilter(@RequestHeader HttpHeaders headers,
			@RequestBody FilterRequestModel filterModel) {
		ResponseObjectModel reponseObject = this.programService.findAll(filterModel);
		return new ResponseEntity<ResponseObjectModel>(reponseObject, HttpStatus.OK);

	}
	
	@RequestMapping(path = "/{programId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','GET')")
	public ResponseEntity<Program> getProgram(@RequestHeader HttpHeaders headers, @PathVariable Long programId) {
		Program program = this.programService.findOne(programId);		
		if (program == null)
			return new ResponseEntity<Program>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Program>(program, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','POST')")
	public ResponseEntity<ResponseObjectModel> createProgram(@RequestHeader HttpHeaders headers, @RequestBody Program program) {
		logger.debug(program.toString());
		ResponseObjectModel response = this.programService.save(program);
		if (response == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.CREATED);
	}
	
	@ResponseBody
	@RequestMapping(value = "/add/{programId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','PUT')")
	public ResponseEntity<ResponseObjectModel> updateProgram(@RequestHeader HttpHeaders headers, @PathVariable Long programId, @RequestBody Program program) {
		logger.debug("----UPDATE: "+ program.toString()+"---");
		Program ct = program.withProgramId(programId);

		ResponseObjectModel response = this.programService.update(ct);
		ResponseEntity<ResponseObjectModel> rect =  new ResponseEntity<ResponseObjectModel> (response, HttpStatus.OK);
		return rect;
	}

	@ResponseBody
	@RequestMapping(path = "/all/by_page", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','GET')")
	public ResponseEntity<ResponseObjectModel> getAllPrograms(@RequestHeader HttpHeaders headers,
			@RequestBody FilterRequestModel filter) {
		ResponseObjectModel responseObject = this.programService.getAll(filter.getPage(), filter.getPageSize());
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(value = "/update/deleted/{programId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','PUT')")
	public ResponseEntity<ResponseObjectModel> updateDeleted(@RequestHeader HttpHeaders headers, @PathVariable Long programId) {		
		ResponseObjectModel response = this.programService.updateDeleted(programId);
		ResponseEntity<ResponseObjectModel> rect =  new ResponseEntity<ResponseObjectModel> (response, HttpStatus.OK);
		return rect;
	}
	
	@ResponseBody
	@RequestMapping(value = "/export/csv", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'PROGRAM','PUT')")
	public ResponseEntity<ResponseObjectModel> exportCSV(@RequestHeader HttpHeaders headers,@RequestBody FilterRequestModel filter) {		
		ResponseObjectModel response = this.programService.exportCSV(filter);
		ResponseEntity<ResponseObjectModel> rect =  new ResponseEntity<ResponseObjectModel> (response, HttpStatus.OK);
		return rect;
	}
			
}
