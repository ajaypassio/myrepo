package com.avigosolutions.criteriaservice.controllers;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.model.Question;
import com.avigosolutions.criteriaservice.service.QuestionService;



@Controller
@RequestMapping(path = "/questions")
public class QuestionController {
	
	@Autowired
	QuestionService questionService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<List<Question>> getAllQuestions(@RequestHeader HttpHeaders headers) {
		List<Question> questions = this.questionService.findAll();
		if (questions == null)
			return new ResponseEntity<List<Question>>(questions, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Question>>(questions, HttpStatus.OK);

	}
	@ResponseBody
	@RequestMapping(path = "/{questionId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<Question> getQuestionById(@RequestHeader HttpHeaders headers, @PathVariable Long questionId) {
		Question question = this.questionService.findOne(questionId);		
		if (question == null)
			return new ResponseEntity<Question>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Question>(question, HttpStatus.OK);
		
	}
	
	@ResponseBody
	@RequestMapping(path = "/questionByQuestionnaireId", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<List<Question>> getQuestionByQuestionnaireId(@RequestHeader HttpHeaders headers, @RequestParam(value = "questionnaireId") long questionnaireId) {
		List<Question> questionList = this.questionService.findByQuestionnaireId(questionnaireId);
		if (questionList == null)
			return new ResponseEntity<List<Question>>(HttpStatus.NOT_FOUND);
		ResponseEntity<List<Question>> response = new ResponseEntity<List<Question>>(questionList, HttpStatus.OK);
		return response;
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','POST')")
	public ResponseEntity<Question> createQuestion(@RequestHeader HttpHeaders headers, @RequestBody Question question) {
		logger.info("----CREATE" + question.toString() + "---");
		Question questionObj = this.questionService.save(question);
		if (questionObj == null) 
			return new ResponseEntity<Question>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Question>(questionObj, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/add/{questionId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','PUT')")
	public ResponseEntity<Question> updateQuestion(@RequestHeader HttpHeaders headers, @PathVariable Long questionId, @RequestBody Question question) {
		logger.info("----UPDATE: "+question.toString()+"---");
		Question c = question.withQuestionId(questionId);
		Question questionObj = this.questionService.update(c);
		if (questionObj == null) 
			return new ResponseEntity<Question>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<Question>(questionObj, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/delete/{questionId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','DELETE')")
	public ResponseEntity<Question> deleteQuestion(@RequestHeader HttpHeaders headers, @PathVariable Long questionId) {
		questionService.delete(questionId);
		return new ResponseEntity<Question>(HttpStatus.OK);
	}
}
