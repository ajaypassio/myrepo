package com.avigosolutions.criteriaservice.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.dto.QuestionnaireDto;
import com.avigosolutions.criteriaservice.model.Question;
import com.avigosolutions.criteriaservice.model.Questionnaire;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.QuestionnaireFilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.QuestionnaireService;

@Controller
@RequestMapping(path = "/questionnaires")
public class QuestionnaireController {
	@Autowired
	QuestionnaireService questionnaireService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<List<QuestionnaireDto>> getAllQuestionnaires(@RequestHeader HttpHeaders headers) {
		List<QuestionnaireDto> questionnaires = this.questionnaireService.findAll();
		if (questionnaires == null)
			return new ResponseEntity<List<QuestionnaireDto>>(questionnaires, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<QuestionnaireDto>>(questionnaires, HttpStatus.OK);
	}
	@ResponseBody
	@RequestMapping(path = "/all/filter/program", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<ResponseObjectModel> getProgramRelatedQuestionnairesByFilter(@RequestHeader HttpHeaders headers,@RequestBody QuestionnaireFilterRequestModel filterModel) {
		ResponseObjectModel response = this.questionnaireService.retrieveQuestionnaires(filterModel, "program");
		//findByFilter(filterModel);
		if (response == null)
			return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);

	}
	
	@ResponseBody
	@RequestMapping(path = "/all/filter/independent", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<ResponseObjectModel> getIndependentQuestionnairesByFilter(@RequestHeader HttpHeaders headers,@RequestBody QuestionnaireFilterRequestModel filterModel) {
		ResponseObjectModel response = this.questionnaireService.retrieveQuestionnaires(filterModel, "independent");
		//findByFilter(filterModel);
		if (response == null)
			return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);

	}
	
	@ResponseBody
	@RequestMapping(path = "/{questionnaireId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<Questionnaire> getQuestionnaire(@RequestHeader HttpHeaders headers,
			@PathVariable Long questionnaireId) {
		Questionnaire questionnaire = this.questionnaireService.findOne(questionnaireId);
		// questionnaire.getQuestions().stream().sorted((e1,e2)->e1.getQuestionName().compareTo(e2.getQuestionName())).collect(Collectors.toList());
		if (questionnaire == null)
			return new ResponseEntity<Questionnaire>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Questionnaire>(questionnaire, HttpStatus.OK);
	}

	/*
	 * @ResponseBody
	 * 
	 * @RequestMapping(path =
	 * "/questionnaireAndQuestionByQuestionnaireId/{questionnaireId}", method =
	 * RequestMethod.GET)
	 * 
	 * @PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')") public
	 * ResponseEntity<List<Questionnaire>>
	 * getQuestionnairesandQuestionsByQuestionnaireId(
	 * 
	 * @RequestHeader HttpHeaders headers, @PathVariable List<Long> questionnaireId)
	 * { List<Questionnaire> questList = new ArrayList<Questionnaire>(); for (Long
	 * questId : questionnaireId) { Questionnaire question =
	 * this.questionnaireService.findAllQuestionnaireId(questId); if (question !=
	 * null) questList.add(question); } if (questList.size() > 0) { return new
	 * ResponseEntity<List<Questionnaire>>(questList, HttpStatus.OK); } return new
	 * ResponseEntity<List<Questionnaire>>(HttpStatus.NOT_FOUND); }
	 */

	@ResponseBody
	@RequestMapping(path = "/all/{questionnaireIds}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','GET')")
	public ResponseEntity<List<Questionnaire>> getQuestionnairesandQuestionsByQuestionnaireIds(
			@RequestHeader HttpHeaders headers, @PathVariable String questionnaireIds) {
		List<Questionnaire> questList = new ArrayList<Questionnaire>();
		String[] strList = questionnaireIds.replace("'", "").split(",");
		List<Long> idsList = new ArrayList<Long>();
		for (String s : strList)
			idsList.add(Long.valueOf(s));
		questList = this.questionnaireService.findAllQuestionnaireIds(idsList);
		return new ResponseEntity<List<Questionnaire>>(questList, HttpStatus.OK);
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','POST')")
	public ResponseEntity<Questionnaire> createQuestionnaire(@RequestHeader HttpHeaders headers,
			@RequestBody Questionnaire quest) {
		logger.debug(quest.toString());
		Optional<Questionnaire> questionnaire = this.questionnaireService.save(quest);
		if(null == questionnaire) {
			return new ResponseEntity<Questionnaire>(HttpStatus.EXPECTATION_FAILED);
		}
		if (!questionnaire.isPresent())
			return new ResponseEntity<Questionnaire>(HttpStatus.INTERNAL_SERVER_ERROR);
		
		return new ResponseEntity<Questionnaire>(questionnaire.get(), HttpStatus.CREATED);
	}

	@RequestMapping(value = "/add/{questionnaireId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','PUT')")
	public ResponseEntity<Questionnaire> updateQuestionnaire(@RequestHeader HttpHeaders headers,
			@PathVariable Long questionnaireId, @RequestBody Questionnaire questionnaire) {
		logger.debug("----UPDATE: " + questionnaire.toString() + "---");
		Questionnaire ct = questionnaire.withQuestionnaireId(questionnaireId);
		List<Question> questions = ct.getQuestions();
		for (Question criteria : questions) {
			criteria.withQuestionnaireId(questionnaireId);
		}

		Optional<Questionnaire> optClinical = this.questionnaireService.update(ct);
		
		if(null == optClinical) {
			return new ResponseEntity<Questionnaire>(HttpStatus.EXPECTATION_FAILED);
		}
		ResponseEntity<Questionnaire> rect = optClinical
				.map(clinicalTrial -> new ResponseEntity<Questionnaire>(clinicalTrial, HttpStatus.OK))
				.orElse(new ResponseEntity<Questionnaire>(HttpStatus.INTERNAL_SERVER_ERROR));
		return rect;
	}

	@RequestMapping(value = "/delete/{questionnaireId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTIONNAIRE','DELETE')")
	public ResponseEntity<Boolean> deleteQuestionnaire(@RequestHeader HttpHeaders headers,
			@PathVariable Long questionnaireId) {
		try {
			questionnaireService.delete(questionnaireId);
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<Boolean>(false, HttpStatus.BAD_REQUEST);
		}
	}
}
