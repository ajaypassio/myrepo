package com.avigosolutions.criteriaservice.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.quickgeo.Place;
import org.quickgeo.PostalDbFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.avigosolutions.criteriaservice.dto.ClinicalStudySiteSiteStatistics;
import com.avigosolutions.criteriaservice.dto.CoordinatorDto;
import com.avigosolutions.criteriaservice.dto.PrincipalInvestigatorDto;
import com.avigosolutions.criteriaservice.dto.Properties;
import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.dto.StudySiteLightWeightDTO;
import com.avigosolutions.criteriaservice.dto.StudySiteMapBean;
import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.State;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.request.model.LatLngModel;
import com.avigosolutions.criteriaservice.request.model.LocationSearch;
import com.avigosolutions.criteriaservice.request.model.StudySiteFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteRadiusRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteRequestModel;
import com.avigosolutions.criteriaservice.response.model.FileResponseModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.StudySiteAuditResponse;
import com.avigosolutions.criteriaservice.response.model.StudySiteReportResponse;
import com.avigosolutions.criteriaservice.response.model.StudySiteResponse;
import com.avigosolutions.criteriaservice.service.StudySiteService;
import com.avigosolutions.criteriaservice.service.async.StudySiteAsyncService;

@Controller
@RequestMapping(path = "/studysites")

public class StudysiteController {

	@Autowired
	private StudySiteService studySiteService;
	
	@Autowired
	private StudySiteAsyncService studySiteAsyncService;

	@ResponseBody
	@RequestMapping(path = "/all/{studySiteIds}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteDto>> getStudySitesByIds(@RequestHeader HttpHeaders headers,
			@PathVariable String studySiteIds, @RequestParam(value = "start") int start,
			@RequestParam(value = "pageSize") int pageSize) {
		String[] strList = studySiteIds.split(",");
		List<Long> idsList = new ArrayList<Long>();
		for (String s : strList)
			idsList.add(Long.valueOf(s));
		List<StudySiteDto> studySites = this.studySiteService.getStudySitesByIds(idsList, start, pageSize);
		if (studySites == null)
			return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.OK);

	}

	// It is only used in campaign getting studysites module.
	@ResponseBody
	@RequestMapping(path = "/search/zip/miles", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<StudySiteResponse> getStudySitesByZip(@RequestHeader HttpHeaders headers,
			@RequestParam("trialId") Long trialId, @RequestParam("zip") Long zip, @RequestParam("miles") Float miles) {
		StudySiteResponse studySites = this.studySiteService.getStudySitesByTrialZipMiles(trialId, zip, miles);
		if (studySites == null)
			return new ResponseEntity<StudySiteResponse>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<StudySiteResponse>(studySites, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/search/latlng", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySite>> getStudySitesByLatLng(@RequestHeader HttpHeaders headers,
			@RequestBody LatLngModel latLngModel) {
		List<StudySite> studySites = this.studySiteService.findByLatLngByMiles(latLngModel.getLatList(),
				latLngModel.getLngList());
		if (studySites == null)
			return new ResponseEntity<List<StudySite>>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<StudySite>>(studySites, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/all/latlng_miles", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteDto>> getStudySitesByLatLngMiles(@RequestHeader HttpHeaders headers,
			@RequestParam("latitude") Float latitude, @RequestParam("longitude") Float longitude,
			@RequestParam("distance") Float distance, @RequestParam("trialId") Long trialId) {
		List<StudySiteDto> studySites = this.studySiteService.findByMiles(latitude, longitude, distance, trialId);
		if (studySites == null)
			return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/all/latlng/miles/suggestion", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<StudySiteResponse> getStudySitesByLatLngMilesSuggestion(@RequestHeader HttpHeaders headers,
			@RequestParam("latitude") Float latitude, @RequestParam("longitude") Float longitude,
			@RequestParam("distance") Float distance, @RequestParam("trialId") Long trialId) {
		StudySiteResponse response = new StudySiteResponse();
		List<StudySiteDto> studySites = this.studySiteService.findByMiles(latitude, longitude, distance, trialId);
		response.setMatchedStudySites(studySites);
		if (null != studySites && studySites.size() <= 0) {
			studySites = this.studySiteService.findByMiles(latitude, longitude, distance * 2, trialId);
			response.setSuggestedStudySites(studySites);
		}
		return new ResponseEntity<StudySiteResponse>(response, HttpStatus.OK);

	}

	// Get Studysites based on trialid
	@ResponseBody
	@RequestMapping(path = "/all_studysites/{trialId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllStudySitesByTrailId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @RequestBody StudySiteFilterRequestModel studySiteFilterRequest) {
		ResponseObjectModel response = studySiteService.getAllStudySitesByTrailId(trialId, studySiteFilterRequest);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/trialRadius", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getStudySitesByTrailIdRadiusSearch(@RequestHeader HttpHeaders headers,
			@RequestBody StudySiteRadiusRequestModel studySiteFilterRequest) {
		ResponseObjectModel response = studySiteService.getClinicalTrialStudySitesRadius(studySiteFilterRequest);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(value = "/update/trial/{trialId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ResponseObjectModel> updateStudySiteFromTrialPage(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @RequestBody StudySiteLightWeightDTO studysite) {

		ResponseObjectModel response = this.studySiteService.updateStudySiteFromTrialPage(studysite.getStudySiteId(), 
														trialId, studysite.getRadiusValue() ,studysite.isRadiusExempt());
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
		return rect;
	}

	// listed out all the sties active for trial
	@ResponseBody
	@RequestMapping(path = "/trial/active", method = RequestMethod.GET, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteMapBean>> GetAllActiveStudySitesByTrialId(@RequestHeader HttpHeaders headers,
			@RequestParam("trial_id") Long trialId) throws IOException {
		List<StudySiteMapBean> response = studySiteService.getAllActiveSitesById(trialId);
		return new ResponseEntity<List<StudySiteMapBean>>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/all_studysitesByTrialIds/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllStudySitesByTrialIds(@RequestHeader HttpHeaders headers,
			@PathVariable List<Long> trialId, @RequestParam(value = "start") int start,
			@RequestParam(value = "pageSize") int pageSize) {
		ResponseObjectModel studySites = new ResponseObjectModel();
		StudySiteFilterRequestModel studySiteFilterRequestModel = new StudySiteFilterRequestModel();
		studySiteFilterRequestModel.setPage(start);
		studySiteFilterRequestModel.setPageSize(pageSize);
		for (Long id : trialId) {
			List<StudySiteDto> lstStudySites = (List<StudySiteDto>) this.studySiteService
					.getAllStudySitesByTrailId(id, studySiteFilterRequestModel).getData();
			if ((null != lstStudySites && lstStudySites.size() > 0) && null != studySites.getData())
				lstStudySites.addAll((List<StudySiteDto>) studySites.getData());
			studySites.setData(lstStudySites);
		}
		return new ResponseEntity<ResponseObjectModel>(studySites, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/notin/trial/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySite>> getAllStudySitesByNotInTrailId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId) {
		List<StudySite> studySites = this.studySiteService.findByNotTrailIdIn(trialId);
		if (studySites == null)
			return new ResponseEntity<List<StudySite>>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<StudySite>>(studySites, HttpStatus.OK);
	}

	@RequestMapping(value = "/add/trial", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<List<ClinicalTrialStudySite>> addClinicalTrialStudySites(@RequestHeader HttpHeaders headers,
			@RequestBody StudySiteRequestModel request) {
		System.out.println("----CREATE" + request.toString() + "---");
		Optional<List<ClinicalTrialStudySite>> opStudySites = Optional.empty();
		if (request != null) {
			opStudySites = this.studySiteService.saveClinicalTrialStudySiteByTrailIdStudySiteIds(request.getTrialId(),
					request.getStudySiteId());
		}
		if (opStudySites.isPresent())
			return new ResponseEntity<List<ClinicalTrialStudySite>>(opStudySites.get(), HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ClinicalTrialStudySite>>(new ArrayList<ClinicalTrialStudySite>(), HttpStatus.OK);
	}

	/*
	 * Get method to get StudySite info by given StudySiteId
	 * 
	 */
	// Single Edit in studysite module
	@ResponseBody
	@RequestMapping(path = "studySite/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<StudySiteDto> getStudySitesByStudySiteId(@RequestHeader HttpHeaders headers,
			@PathVariable Long studySiteId) {
		StudySiteDto studySite = this.studySiteService.getStudySitesByStudySiteId(studySiteId);
		if (studySite == null)
			return new ResponseEntity<StudySiteDto>(studySite, HttpStatus.NOT_FOUND);
		return new ResponseEntity<StudySiteDto>(studySite, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/studysite/{trialId}/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<StudySiteDto> getStudySitesByStudySiteIdAndTrialId(@RequestHeader HttpHeaders headers,
			@PathVariable Long trialId, @PathVariable Long studySiteId) {
		StudySiteDto studySite = this.studySiteService.getStudySitesByStudySiteIdAndTrialId(studySiteId, trialId);

		if (studySite == null)
			return new ResponseEntity<StudySiteDto>(studySite, HttpStatus.NOT_FOUND);
		return new ResponseEntity<StudySiteDto>(studySite, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/allStudySites", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteDto>> getAllStudySites(@RequestHeader HttpHeaders headers) {
		List<StudySiteDto> studySites = this.studySiteService.findAll();
		System.out.println(studySites.size());
		if (studySites == null)
			return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<StudySiteDto>>(studySites, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "all_trialsByStudySiteId/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ClinicalTrial>> getAllTrialsByStudySiteId(@RequestHeader HttpHeaders headers,
			@PathVariable Long studySiteId) {
		List<ClinicalTrial> trials = this.studySiteService.getTrialsByStudySiteId(studySiteId);
		if (trials == null)
			return new ResponseEntity<List<ClinicalTrial>>(trials, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ClinicalTrial>>(trials, HttpStatus.OK);

	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ResponseObjectModel> createStudySite(@RequestHeader HttpHeaders headers,
			@RequestBody StudySite studySite) {
		System.out.println(studySite.toString());
		ResponseObjectModel trial = this.studySiteService.save(studySite);
		if (trial == null)
			return new ResponseEntity<ResponseObjectModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ResponseObjectModel>(trial, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/delete/{studySiteId}", method = RequestMethod.DELETE)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','DELETE')")
	public ResponseEntity<StudySite> deleteStudySite(@RequestHeader HttpHeaders headers,
			@PathVariable Long studySiteId) {
		studySiteService.delete(studySiteId);
		return new ResponseEntity<StudySite>(HttpStatus.OK);
	}

	@RequestMapping(value = "/add/{studySiteId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<StudySite> updateStudySite(@RequestHeader HttpHeaders headers, @PathVariable Long studySiteId,
			@RequestBody StudySite studySite) {
		System.out.println("----UPDATE: " + studySite.toString() + "---");
		StudySite site = studySite.withId(studySiteId);
		Optional<StudySite> optStudySite = this.studySiteService.update(site);
		ResponseEntity<StudySite> rect = optStudySite
				.map(StudySite -> new ResponseEntity<StudySite>(studySite, HttpStatus.OK))
				.orElse(new ResponseEntity<StudySite>(HttpStatus.INTERNAL_SERVER_ERROR));
		return rect;
	}

	// This is only used in front-end ui
	@RequestMapping(value = "/update/{studySiteId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ResponseObjectModel> updateStudySiteByProperties(@RequestHeader HttpHeaders headers,
			@PathVariable Long studySiteId, @RequestBody Properties property) {
		System.out.println("----UPDATE: " + property.toString() + "---");

		ResponseObjectModel response = this.studySiteService.updateStudySite(property, null);
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
		return rect;
	}

	// This is only used in front-end ui
	@RequestMapping(value = "/update/{trialId}/{studySiteId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ResponseObjectModel> updateStudySiteByPropertiesWithTrialId(
			@RequestHeader HttpHeaders headers, @PathVariable Long studySiteId, @PathVariable Long trialId,
			@RequestBody Properties property) {
		System.out.println("----UPDATE: " + property.toString() + "---");

		ResponseObjectModel response = this.studySiteService.updateStudySite(property, trialId);
		ResponseEntity<ResponseObjectModel> rect = new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
		return rect;
	}

	// This is the test method
	@ResponseBody
	@RequestMapping(path = "/get/csv", method = RequestMethod.GET)
	public ResponseEntity<List<Place>> getAddress(@RequestParam String address) {
		List<StudySite> lstStudySites = new ArrayList<StudySite>();

		// studySiteService.importFromCSV();
		List<Place> nicePlaces = PostalDbFactory.getPostalDb().byName(".*" + address + ".*").subList(0, 10);
		if (lstStudySites == null)
			return new ResponseEntity<List<Place>>(nicePlaces, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Place>>(nicePlaces, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/import/csv/{trialId}", method = RequestMethod.POST, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<FileResponseModel> ImportStudySitesFromCSV(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId,
			@RequestParam(value = "csvFile", required = true) MultipartFile csvFile) throws IOException {
		FileResponseModel response = studySiteService.importStudySiteFromCSV(csvFile, trialId);
		return new ResponseEntity<FileResponseModel>(response, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/import/csv/noTrialId", method = RequestMethod.POST, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<FileResponseModel> uploadStudySitesWithoutTrialId(@RequestHeader HttpHeaders headers,
			@RequestParam(value = "csvFile", required = true) MultipartFile csvFile) throws IOException {
		FileResponseModel response = studySiteService.uploadStudySitesWithoutTrialId(csvFile);
		return new ResponseEntity<FileResponseModel>(response, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/import/status/{trialId}", method = RequestMethod.GET, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> ImportStudySitesFromCSV(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId,@RequestParam(required=false) Integer start , @RequestParam(required=false) Integer pageSize) throws IOException {
		if(start==null) {
			start=0;
		}
		if(pageSize==null) {
			pageSize=0;
		}
		ResponseObjectModel response = studySiteAsyncService.getImportStatusByTrial(trialId,start,pageSize);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/csv/download/template", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Resource> download(@RequestHeader HttpHeaders headers) throws IOException {
		File file = new File("csv/template/studysitetemplate.csv");
		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=StudySite_Template.csv");
		return ResponseEntity.ok().headers(header).contentLength(file.length())
				.contentType(MediaType.parseMediaType("application/octet-stream")).body(resource);
	}

	@ResponseBody
	@RequestMapping(path = "/csv/download/error/{trialId}", method = RequestMethod.GET)

	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Resource> downloadCSVError(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId) throws IOException {

		File file = new File("csv/error/error_" + String.valueOf(trialId) + ".csv");
		InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
		HttpHeaders header = new HttpHeaders();
		header.set(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, "Content-Disposition");
		header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=error_" + String.valueOf(trialId) + ".csv");
		return ResponseEntity.ok().headers(header).contentLength(file.length())
				.contentType(MediaType.parseMediaType("application/octet-stream")).body(resource);
	}

	// It is used in studysite module grid view
	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.POST, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> GetAll(@RequestHeader HttpHeaders headers,
			@RequestBody StudySiteFilterRequestModel requestModel) throws IOException {
		ResponseObjectModel response = studySiteService.getAll(requestModel);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/principalinvestigators", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<PrincipalInvestigatorDto>> getAllPrincipalInvestigators(
			@RequestHeader HttpHeaders headers,
			@RequestParam(value = "principal_investigator_name") String principalInvestigatorName,
			@RequestParam(value = "start") int start, @RequestParam(value = "page_size") int pageSize) {
		List<PrincipalInvestigatorDto> principalInvestigators = this.studySiteService
				.getPrincipalInvestigatorsList(principalInvestigatorName, start, pageSize);
		if (principalInvestigators == null)
			return new ResponseEntity<List<PrincipalInvestigatorDto>>(principalInvestigators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<PrincipalInvestigatorDto>>(principalInvestigators, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/coordinators/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<CoordinatorDto>> getCoordinators(@RequestHeader HttpHeaders headers,
			@PathVariable("studySiteId") Long studySiteId,
			@RequestParam(value = "coordinator_name") String coordinatorName, @RequestParam(value = "start") int start,
			@RequestParam(value = "page_size") int pageSize) {
		List<CoordinatorDto> coordinators = this.studySiteService.getCoordinatorsList(coordinatorName, studySiteId,
				start, pageSize);
		if (coordinators == null)
			return new ResponseEntity<List<CoordinatorDto>>(coordinators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<CoordinatorDto>>(coordinators, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/coordinators/existing", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<CoordinatorDto>> getExistingCoordinators(@RequestHeader HttpHeaders headers) {
		List<CoordinatorDto> coordinators = this.studySiteService.getMappedCoordinators();
		if (coordinators == null)
			return new ResponseEntity<List<CoordinatorDto>>(coordinators, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<CoordinatorDto>>(coordinators, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/trial/name", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> GetStudySitesByTrialIdAndNameContaining(@RequestHeader HttpHeaders headers,
			@RequestParam(value = "start") int start, @RequestParam(value = "pageSize") int pageSize,
			@RequestParam(value = "trialId") Long trialId, @RequestParam(value = "name") String name) {
		ResponseObjectModel model = this.studySiteService.getStudySitesByTrialIdAndNameContaining(start, pageSize,
				trialId, name);
		if (model == null)
			return new ResponseEntity<ResponseObjectModel>(model, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(model, HttpStatus.OK);
	}
	
	//ChangeSite
	@ResponseBody
	@RequestMapping(path = "/trial/name/exclude/current", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> GetStudySitesNotInCurrentSite(@RequestHeader HttpHeaders headers,
			@RequestParam(value = "start") int start, @RequestParam(value = "pageSize") int pageSize,
			@RequestParam(value = "trialId") Long trialId, @RequestParam(value = "name") String name,@RequestParam(value = "currentStudySiteId") Long currentStudySiteId) {
		ResponseObjectModel model = this.studySiteService.getStudySitesByTrialIdAndNameContainingNotInCurrentSiteId(start, pageSize,
				trialId, name,currentStudySiteId);
		if (model == null)
			return new ResponseEntity<ResponseObjectModel>(model, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(model, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/count/{studySiteState}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getActiveStudySites(@RequestHeader HttpHeaders headers,
			@PathVariable("studySiteState") boolean studySiteState) {
		Long count = this.studySiteService.getCount(studySiteState);
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setData(count);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);
	}

	// As per ketan request created.
	@ResponseBody
	@RequestMapping(path = "/all", method = RequestMethod.GET, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> GetAll(@RequestHeader HttpHeaders headers, @RequestParam int page,
			@RequestParam int pageSize) throws IOException {
		ResponseObjectModel response = studySiteService.getAll(page, pageSize);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}

	// As per ketan request created.
	@ResponseBody
	@RequestMapping(path = "/all/detail", method = RequestMethod.GET, produces = "application/json")
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteMapBean>> GetAllStudySites(@RequestHeader HttpHeaders headers)
			throws IOException {
		List<StudySiteMapBean> response = studySiteService.getAll();
		return new ResponseEntity<List<StudySiteMapBean>>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/report/{trialId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteReportResponse>> collectDataForReport(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @RequestBody StudySiteFilterRequestModel requestModel) {
		List<StudySiteReportResponse> list = this.studySiteService.getStudySiteReportByTrialId(trialId, requestModel);
		return new ResponseEntity<List<StudySiteReportResponse>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/count/trial/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ClinicalStudySiteSiteStatistics>> countByClinicalStudySiteIdIdIn(
			@RequestHeader HttpHeaders headers, @PathVariable("trialId") String trialId) {
		List<Long> trialIds = Arrays.asList(trialId.split(",")).stream().map(s -> Long.parseLong(s.trim()))
				.collect(Collectors.toList());
		List<ClinicalStudySiteSiteStatistics> list = this.studySiteService.countByClinicalStudySiteIdIdIn(trialIds);
		return new ResponseEntity<List<ClinicalStudySiteSiteStatistics>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/report/all", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteReportResponse>> collectDataForReport(@RequestHeader HttpHeaders headers,
			@RequestBody StudySiteFilterRequestModel requestModel) {
		List<StudySiteReportResponse> list = this.studySiteService.getStudySiteReport(requestModel);
		return new ResponseEntity<List<StudySiteReportResponse>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/report/studysiteaudit/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<StudySiteAuditResponse>> studySiteAuditReport(@RequestHeader HttpHeaders headers,
			@PathVariable Long studySiteId) {
		List<StudySiteAuditResponse> list = this.studySiteService.getStudySiteAuditReport(studySiteId);
		return new ResponseEntity<List<StudySiteAuditResponse>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/states/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<State>> getStudySiteStates(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId) {
		List<State> list = this.studySiteService.getStudySiteStatesByTrialId(trialId);
		return new ResponseEntity<List<State>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/cities/{trialId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<City>> getStudySiteCities(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId,@RequestBody LocationSearch locationSearch) {
		List<City> list = this.studySiteService.getStudySiteCitiesByTrialId(trialId,locationSearch);
		return new ResponseEntity<List<City>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/citiesForStates/{trialId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<City>> getCitiesForStates(@RequestHeader HttpHeaders headers,
			@RequestBody Map<String, List<Long>> statesList, @RequestParam(value = "cityName") String cityName,
			@RequestParam(value = "start") int start, @RequestParam(value = "pageSize") int pageSize,
			@PathVariable("trialId") Long trialId) {
		List<City> cities = this.studySiteService.getCitiesListForStates(statesList.get("stateIdList"), cityName,
				trialId, start, pageSize);
		if (cities == null)
			return new ResponseEntity<List<City>>(cities, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<City>>(cities, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/states/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<State>> getAllStudySiteStates(@RequestHeader HttpHeaders headers) {
		List<State> list = this.studySiteService.getStudySiteStates();
		return new ResponseEntity<List<State>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/cities/all", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<City>> getAllStudySiteCities(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId) {
		List<City> list = this.studySiteService.getStudySiteCities();
		return new ResponseEntity<List<City>>(list, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/citiesForStates/all", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<City>> getAllCitiesForStates(@RequestHeader HttpHeaders headers,
			@RequestBody List<Long> statesList, @RequestParam(value = "cityName") String cityName,
			@RequestParam(value = "start") int start, @RequestParam(value = "pageSize") int pageSize) {
		List<City> cities = this.studySiteService.getCitiesListForStates(statesList, cityName, null, start, pageSize);
		if (cities == null)
			return new ResponseEntity<List<City>>(cities, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<City>>(cities, HttpStatus.OK);
	}

}