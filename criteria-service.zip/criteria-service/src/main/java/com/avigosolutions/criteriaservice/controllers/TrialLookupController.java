package com.avigosolutions.criteriaservice.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.Phase;
import com.avigosolutions.criteriaservice.model.ProgramStatus;
import com.avigosolutions.criteriaservice.model.Sponsor;
import com.avigosolutions.criteriaservice.model.State;
import com.avigosolutions.criteriaservice.model.Status;
import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.model.TrialCondition;
import com.avigosolutions.criteriaservice.model.TrialStatus;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.service.ArmService;
import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
import com.avigosolutions.criteriaservice.service.LocationLoookupService;
import com.avigosolutions.criteriaservice.service.ProgramService;
import com.avigosolutions.criteriaservice.service.StageService;
import com.avigosolutions.criteriaservice.service.TherapeuticAreaService;

@Controller
@RequestMapping(path = "/trials/lookup")
public class TrialLookupController {

	@Autowired
	private ClinicalTrialService clinicalTrialService;

	@Autowired
	private ProgramService programService;

	@Autowired
	private TherapeuticAreaService therapeuticAreaService;

	@Autowired
	private StageService stageService;

	@Autowired
	private ArmService armService;

	@Autowired
	private LocationLoookupService locationLoookupService;

	@ResponseBody
	@RequestMapping(path = "/sponsors", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Sponsor>> getAllSponsors(@RequestHeader HttpHeaders headers) {
		List<Sponsor> sponsors = this.programService.getAllSponsors();
		if (sponsors == null)
			return new ResponseEntity<List<Sponsor>>(sponsors, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Sponsor>>(sponsors, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/sponsors/search", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Sponsor>> getAllSponsorsBySearch(@RequestHeader HttpHeaders headers,
			@RequestParam("keyword") String keyword, @RequestParam("page") int page,
			@RequestParam("page_size") int pageSize) {
		List<Sponsor> sponsors = this.programService.getSponsorsBySearch(keyword, page, pageSize);
		if (sponsors == null)
			return new ResponseEntity<List<Sponsor>>(sponsors, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Sponsor>>(sponsors, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/therapeutic_area", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<TherapeuticArea>> getAllTherapeuticArea(@RequestHeader HttpHeaders headers) {
		List<TherapeuticArea> therapeuticAreas = this.clinicalTrialService.getAllTherapeuticAreas();
		if (therapeuticAreas == null)
			return new ResponseEntity<List<TherapeuticArea>>(therapeuticAreas, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<TherapeuticArea>>(therapeuticAreas, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/therapeutic/search", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getTherapeuticAreaSearch(@RequestHeader HttpHeaders headers , @RequestParam(value = "keyword") String keyword) {
		ResponseObjectModel therapeuticmodels =  clinicalTrialService.getAllTherapeuticAreasByKeyword(keyword);
		if (therapeuticmodels == null)
			return new ResponseEntity<ResponseObjectModel>(therapeuticmodels, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(therapeuticmodels, HttpStatus.OK);
	}

	//public List<LoincCode> findByDisplayNameContainingIgnoreCase(String standardName);
	/*
	@Override
	public ResponseObjectModel findAll(String keyword,int page, int pageSize) {
		ResponseObjectModel response = new ResponseObjectModel();
		List<LoincCode> pageList = loincCodeRepository.findByDisplayNameContainingIgnoreCase(keyword);
		response.setData(pageList);
		response.setTotal(pageList.size());
		response.setStatus(200);
		return response;
	}
	 */
	@ResponseBody
	@RequestMapping(path = "/phases", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Phase>> getAllPhases(@RequestHeader HttpHeaders headers) {
		List<Phase> phases = this.programService.getAllPhases();
		if (phases == null)
			return new ResponseEntity<List<Phase>>(phases, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Phase>>(phases, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/trialstatuses", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<TrialStatus>> getAllStatuses(@RequestHeader HttpHeaders headers) {
		List<TrialStatus> trialStatuses = this.clinicalTrialService.getAllTrialStatuses();
		List <TrialStatus>updateTrailStatus=new ArrayList();
		if(trialStatuses !=null && trialStatuses.size()>0)
		{
			for(int i=0;i<trialStatuses.size();i++)
			{
				TrialStatus tstaus= new TrialStatus();
				if(trialStatuses.get(i).getTrialStatusId()==6)
				{
					
					tstaus.withName("");
				}
				else
				{
					tstaus.withName(trialStatuses.get(i).getName());
				}
					
				tstaus.withTrialStatusId(trialStatuses.get(i).getTrialStatusId());
				tstaus.withCreatedBy(trialStatuses.get(i).getCreatedBy());
				tstaus.withCreatedOn(trialStatuses.get(i).getCreatedOn());
				tstaus.withUpdatedBy(trialStatuses.get(i).getUpdatedBy());
				tstaus.withUpdatedOn(trialStatuses.get(i).getUpdatedOn());
				
				
				updateTrailStatus.add(tstaus);
				}
			}
		if (trialStatuses == null) {
			return new ResponseEntity<List<TrialStatus>>(trialStatuses, HttpStatus.NOT_FOUND);
		}
	//	return new ResponseEntity<List<TrialStatus>>(trialStatuses, HttpStatus.OK);
		return new ResponseEntity<List<TrialStatus>>(updateTrailStatus, HttpStatus.OK);
		
	}

	@ResponseBody
	@RequestMapping(path = "/programstatuses", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ProgramStatus>> getAllProgramStatuses(@RequestHeader HttpHeaders headers) {
		List<ProgramStatus> pgmStatusList = this.programService.getAllProgramStatus();
		if (pgmStatusList == null)
			return new ResponseEntity<List<ProgramStatus>>(pgmStatusList, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ProgramStatus>>(pgmStatusList, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/statuses", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Status>> getAllPhase(@RequestHeader HttpHeaders headers) {
		List<Status> statuses = this.clinicalTrialService.getAllStatus();
		if (statuses == null)
			return new ResponseEntity<List<Status>>(statuses, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Status>>(statuses, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/cities", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<City>> getAllCities(@RequestHeader HttpHeaders headers,
			@RequestParam(value = "cityName") String cityName, @RequestParam(value = "start") int start,
			@RequestParam(value = "pageSize") int pageSize) {
		List<City> cities = this.locationLoookupService.getCitiesList(cityName, start, pageSize);
		if (cities == null)
			return new ResponseEntity<List<City>>(cities, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<City>>(cities, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/citiesForStates", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<City>> getAllCitiesForStates(@RequestHeader HttpHeaders headers,
			@RequestBody List<Long> statesList, @RequestParam(value = "cityName") String cityName,
			@RequestParam(value = "start") int start, @RequestParam(value = "pageSize") int pageSize) {
		List<City> cities = this.locationLoookupService.getCitiesListForStates(statesList, cityName, start, pageSize);
		if (cities == null)
			return new ResponseEntity<List<City>>(cities, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<City>>(cities, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/states", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<State>> getAllStates(@RequestHeader HttpHeaders headers,
			@RequestParam(value = "stateName") String stateName, @RequestParam(value = "start") int start,
			@RequestParam(value = "pageSize") int pageSize) {
		List<State> states = this.locationLoookupService.getStatesList(stateName, start, pageSize);
		if (states == null)
			return new ResponseEntity<List<State>>(states, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<State>>(states, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/therapeutic_area/all/by_page", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTherapeuticArea(@RequestHeader HttpHeaders headers,
			@RequestParam("page") int page, @RequestParam("page_size") int pageSize) {
		ResponseObjectModel therapeuticAreas = this.therapeuticAreaService.getAll(page, pageSize);
		if (therapeuticAreas == null)
			return new ResponseEntity<ResponseObjectModel>(therapeuticAreas, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(therapeuticAreas, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/arm/all/by_page", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllArms(@RequestHeader HttpHeaders headers,
			@RequestParam("page") int page, @RequestParam("page_size") int pageSize) {
		ResponseObjectModel therapeuticAreas = this.armService.getAll(page, pageSize);
		if (therapeuticAreas == null)
			return new ResponseEntity<ResponseObjectModel>(therapeuticAreas, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(therapeuticAreas, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/stage/all/by_page", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllStages(@RequestHeader HttpHeaders headers,
			@RequestParam("page") int page, @RequestParam("page_size") int pageSize) {
		ResponseObjectModel therapeuticAreas = this.stageService.getAll(page, pageSize);
		if (therapeuticAreas == null)
			return new ResponseEntity<ResponseObjectModel>(therapeuticAreas, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(therapeuticAreas, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/conditions", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<TrialCondition>> getAllTrialConditions(@RequestHeader HttpHeaders headers) {
		List<TrialCondition> conditionList = this.clinicalTrialService.getAllTrialConditions();
		if (conditionList == null)
			return new ResponseEntity<List<TrialCondition>>(conditionList, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<TrialCondition>>(conditionList, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/conditions/all/by_page", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getAllTrialConditions(@RequestHeader HttpHeaders headers,
			@RequestParam("page") int page, @RequestParam("page_size") int pageSize) {
		ResponseObjectModel trialConditions = this.clinicalTrialService.getAllTrialConditions(page, pageSize);
		if (trialConditions == null)
			return new ResponseEntity<ResponseObjectModel>(trialConditions, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(trialConditions, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/condition/search", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getTrialConditionAreaSearch(@RequestHeader HttpHeaders headers, @RequestParam(value = "keyword") String keyword) {
		ResponseObjectModel trialConditionModels = this.clinicalTrialService.getAllTrialConditionsByKeyword(keyword);
		if (trialConditionModels == null)
			return new ResponseEntity<ResponseObjectModel>(trialConditionModels, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ResponseObjectModel>(trialConditionModels, HttpStatus.OK);
	}
}
