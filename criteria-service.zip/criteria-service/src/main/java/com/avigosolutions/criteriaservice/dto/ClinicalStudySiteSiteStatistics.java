package com.avigosolutions.criteriaservice.dto;

public class ClinicalStudySiteSiteStatistics {
	private Long trialId;
	private Long count;

	public ClinicalStudySiteSiteStatistics(Long trialId, Long count) {
		this.trialId = trialId;
		this.count = count;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}
}
