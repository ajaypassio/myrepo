package com.avigosolutions.criteriaservice.dto;

public class ClinicalTrialLightWeightDTO {
	
	private Long trialId;
	private boolean radiusOverride;
	
	public Long getTrialId() {
		return trialId;
	}
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	public boolean isRadiusOverride() {
		return radiusOverride;
	}
	public void setRadiusOverride(boolean radiusOverride) {
		this.radiusOverride = radiusOverride;
	}
	
	

}
