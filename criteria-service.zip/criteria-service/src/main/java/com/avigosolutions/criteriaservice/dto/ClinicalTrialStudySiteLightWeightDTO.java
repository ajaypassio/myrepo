package com.avigosolutions.criteriaservice.dto;

public class ClinicalTrialStudySiteLightWeightDTO {
	
	private Integer radiusValue;
	
	private Long studySiteId;
	
	private String zipCode;
	
	private String radiusOverride;

	public Integer getRadiusValue() {
		return radiusValue;
	}

	public void setRadiusValue(Integer radiusValue) {
		this.radiusValue = radiusValue;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}


	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getRadiusOverride() {
		return radiusOverride;
	}

	public void setRadiusOverride(String radiusOverride) {
		this.radiusOverride = radiusOverride;
	}
	
}
