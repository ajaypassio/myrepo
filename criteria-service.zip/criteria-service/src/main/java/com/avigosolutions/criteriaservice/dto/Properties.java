package com.avigosolutions.criteriaservice.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;

import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.response.model.StudySiteAuditResponse;

public class Properties implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String postalCode;

	private String state;

	private String country;

	private String city;

	private String emailAddress;

	private String phoneNumber;

	private Long createdBy;

	private Long updatedBy;

	private String zip;

	private String address1;

	private String address2;

	private String ultimateParentName;

	private String studySiteNumber;

	private String studySiteName;

	private List<CoordinatorDto> coordinators;

	private List<PrincipalInvestigatorDto> principalInvestigators;

	private String region;

	private String subRegion;

	private String protocolNumber;

	private String projectCode;

	private String primaryTherapeuticArea;

	private String primaryIndication;

	private String investigationalProductType;

	private String tDU;

	private String cTMSResearchFacilityIdentifier;

	private String siteCluster;

	private Boolean active;

	private Long studySitePhaseId;

	private Long studySiteIRBId;

	private Long studySiteStatusId;

	private int referred;

	private int enrolled;

	private Date createdOn;

	private Long studySiteId;
	
	private Long trialId;
	
	private List<StudySiteAuditResponse> auditResponse;
	
	private Integer radiusValue;
	
	private Boolean radiusExempt;

	public String getRegion() {
		return region;
	}

	public Properties withRegion(String region) {
		this.region = region;
		return this;
	}

	public String getSubRegion() {
		return subRegion;
	}

	public Properties withSubRegion(String subRegion) {
		this.subRegion = subRegion;
		return this;
	}

	public String getProtocolNumber() {
		return protocolNumber;
	}

	public Properties withProtocolNumber(String protocolNumber) {
		this.protocolNumber = protocolNumber;
		return this;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public Properties withProjectCode(String projectCode) {
		this.projectCode = projectCode;
		return this;
	}

	public String getPrimaryTherapeuticArea() {
		return primaryTherapeuticArea;
	}

	public Properties withPrimaryTherapeuticArea(String primaryTherapeuticArea) {
		this.primaryTherapeuticArea = primaryTherapeuticArea;
		return this;
	}

	public String getPrimaryIndication() {
		return primaryIndication;
	}

	public Properties withPrimaryIndication(String primaryIndication) {
		this.primaryIndication = primaryIndication;
		return this;
	}

	public String getInvestigationalProductType() {
		return investigationalProductType;
	}

	public Properties withInvestigationalProductType(String investigationalProductType) {
		this.investigationalProductType = investigationalProductType;
		return this;
	}

	public String gettDU() {
		return tDU;
	}

	public Properties withtDU(String tDU) {
		this.tDU = tDU;
		return this;
	}

	public String getcTMSResearchFacilityIdentifier() {
		return cTMSResearchFacilityIdentifier;
	}

	public Properties withcTMSResearchFacilityIdentifier(String cTMSResearchFacilityIdentifier) {
		this.cTMSResearchFacilityIdentifier = cTMSResearchFacilityIdentifier;
		return this;
	}

	public String getSiteCluster() {
		return siteCluster;
	}

	public Properties withSiteCluster(String siteCluster) {
		this.siteCluster = siteCluster;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public Properties withActive(Boolean active) {
		this.active = active;
		return this;
	}

	public Long getStudySitePhaseId() {
		return studySitePhaseId;
	}

	public Properties withStudySitePhaseId(Long studySitePhaseId) {
		this.studySitePhaseId = studySitePhaseId;
		return this;
	}

	public Long getStudySiteIRBId() {
		return studySiteIRBId;
	}

	public Properties withStudySiteIRBId(Long studySiteIRBId) {
		this.studySiteIRBId = studySiteIRBId;
		return this;
	}

	public Long getStudySiteStatusId() {
		return studySiteStatusId;
	}

	public Properties withStudySiteStatusId(Long studySiteStatusId) {
		this.studySiteStatusId = studySiteStatusId;
		return this;
	}

	public String getAddress1() {
		return address1;
	}

	public Properties withAddress1(String address1) {
		this.address1 = address1;
		return this;
	}

	public String getAddress2() {
		return address2;
	}

	public Properties withAddress2(String address2) {
		this.address2 = address2;
		return this;		
	}

	public String getZip() {
		return zip;
	}

	public Properties withZip(String zip) {
		this.zip = zip;
		return this;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public Properties withEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
		return this;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public Properties withPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public Properties withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public Properties withUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public Properties withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public Properties withPostalCode(String postalCode) {
		this.postalCode = postalCode;
		return this;
	}

	public String getState() {
		return state;
	}

	public Properties withState(String state) {
		this.state = state;
		return this;
	}

	public String getCountry() {
		return country;
	}

	public Properties withCountry(String country) {
		this.country = country;
		return this;
	}

	public String getCity() {
		return city;
	}

	public Properties withCity(String city) {
		this.city = city;
		return this;
	}

	@Override
	public String toString() {
		return "Properties [postalCode=" + postalCode + ", state=" + state + ", country=" + country + ", city=" + city
				+ ", emailAddress=" + emailAddress + ", phoneNumber=" + phoneNumber + ", createdBy=" + createdBy
				+ ", updatedBy=" + updatedBy + ", zip=" + zip + ", address1=" + address1 + ", address2=" + address2
				+ ", ultimateParentName=" + ultimateParentName + ", studySiteNumber=" + studySiteNumber
				+ ", studySiteName=" + studySiteName + ", coordinators=" + coordinators + ", principalInvestigators="
				+ principalInvestigators + ", region=" + region + ", subRegion=" + subRegion + ", protocolNumber="
				+ protocolNumber + ", projectCode=" + projectCode + ", primaryTherapeuticArea=" + primaryTherapeuticArea
				+ ", primaryIndication=" + primaryIndication + ", investigationalProductType="
				+ investigationalProductType + ", tDU=" + tDU + ", cTMSResearchFacilityIdentifier="
				+ cTMSResearchFacilityIdentifier + ", siteCluster=" + siteCluster + ", active=" + active
				+ ", studySitePhaseId=" + studySitePhaseId + ", studySiteIRBId=" + studySiteIRBId
				+ ", studySiteStatusId=" + studySiteStatusId + ", referred=" + referred + ", enrolled=" + enrolled
				+ ", createdOn=" + createdOn + ", studySiteId=" + studySiteId + ", trialId=" + trialId
				+ ", auditResponse=" + auditResponse + ", radiusValue=" + radiusValue + ", radiusExempt=" + radiusExempt
				+ "]";
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public Properties withStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

	public String getUltimateParentName() {
		return ultimateParentName;
	}

	public Properties withUltimateParentName(String ultimateParentName) {
		this.ultimateParentName = ultimateParentName;
		return this;
	}

	public String getStudySiteNumber() {
		return studySiteNumber;
	}

	public Properties withStudySiteNumber(String studySiteNumber) {
		this.studySiteNumber = studySiteNumber;
		return this;
	}

	public List<CoordinatorDto> getCoordinators() {
		return coordinators;
	}

	public Properties withCoordinators(List<CoordinatorDto> coordinators) {
		this.coordinators = coordinators;
		return this;
	}

	public List<PrincipalInvestigatorDto> getPrincipalInvestigators() {
		return principalInvestigators;
	}

	public Properties withPrincipalInvestigators(List<PrincipalInvestigatorDto> principalInvestigators) {
		this.principalInvestigators = principalInvestigators;
		return this;
	}

	public String getStudySiteName() {
		return studySiteName;
	}

	public Properties withStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
		return this;
	}

	public int getReferred() {
		return referred;
	}

	public Properties withReferred(int referred) {
		this.referred = referred;
		return this;
	}

	public int getEnrolled() {
		return enrolled;
	}

	public Properties withEnrolled(int enrolled) {
		this.enrolled = enrolled;
		return this;
		
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public List<StudySiteAuditResponse> getAuditResponse() {
		return auditResponse;
	}

	public void setAuditResponse(List<StudySiteAuditResponse> auditResponse) {
		this.auditResponse = auditResponse;
	}
	
	public Integer getRadiusValue() {
		return radiusValue;
	}

	public void setRadiusValue(Integer radiusValue) {
		this.radiusValue = radiusValue;
		
	}
	
	public Boolean getRadiusExempt() {
		return radiusExempt;
	}

	public void setRadiusExempt(Boolean radiusExempt) {
		this.radiusExempt = radiusExempt;
		
	}

}