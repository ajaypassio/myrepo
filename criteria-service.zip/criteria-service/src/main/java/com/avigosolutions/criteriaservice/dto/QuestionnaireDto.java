package com.avigosolutions.criteriaservice.dto;

import java.util.Date;
import java.util.List;
import com.avigosolutions.criteriaservice.util.EncryptionUtils;

public class QuestionnaireDto {
	
	private Long questionnaireId;
	private Long trialId;
	private Long programId;
	private String questionnaireName;
	private String questionnaireDescription;
	private String sponsorName;
	private List<String> collaboratorNames;
	private String trialName;
	private String programName;
	private Date createdOn;
	private Date updatedOn;
	private String trialLandingPage;
	private String encryptedQuestionnaireId;
	
	public QuestionnaireDto() {		
		this.questionnaireId = 0L;
		this.trialId = 0L;
		this.programId = 0L;
		this.questionnaireName = "";
		this.questionnaireDescription="";
		this.sponsorName = "";
		this.collaboratorNames = null;
		this.trialName = "";
		this.programName = "";
		this.createdOn = new Date();
		this.updatedOn = new Date();
		this.trialLandingPage="";
		this.encryptedQuestionnaireId="";
	}
	
	public QuestionnaireDto(Long questionnaireId, Long trialId, Long programId, String questionnaireName,
			String questionnaireDescription, String sponsorName, List<String> collaboratorNames, String trialName, String programName, String trialLandingPage, Date createdOn, Date updatedOn) {
		this.questionnaireId = questionnaireId;
		this.trialId = trialId;
		this.programId = programId;
		this.questionnaireName = questionnaireName;
		this.questionnaireDescription = questionnaireDescription;
		this.sponsorName = sponsorName;
		this.collaboratorNames = collaboratorNames;
		this.trialName = trialName;
		this.programName = programName;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
		this.trialLandingPage= trialLandingPage;
		this.encryptedQuestionnaireId=EncryptionUtils.getInstance().encryptToBase64(String.valueOf(questionnaireId));
	}

	/**
	 * @return the questionnaireId
	 */
	public Long getQuestionnaireId() {
		return questionnaireId;
	}

	/**
	 * @param questionnaireId the questionnaireId to set
	 */
	public QuestionnaireDto withQuestionnaireId(Long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public QuestionnaireDto withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}
	
	/**
	 * @return the trialId
	 */
	public String getTrialLandingPage() {
		return trialLandingPage;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public QuestionnaireDto withTrialId(String trialLandingPage) {
		this.trialLandingPage = trialLandingPage;
		return this;
	}

	/**
	 * @return the programId
	 */
	public Long getProgramId() {
		return programId;
	}

	/**
	 * @param programId the programId to set
	 */
	public QuestionnaireDto withProgramId(Long programId) {
		this.programId = programId;
		return this;
	}

	/**
	 * @return the questionnaireName
	 */
	public String getQuestionnaireName() {
		return questionnaireName;
	}

	/**
	 * @param questionnaireName the questionnaireName to set
	 */
	public QuestionnaireDto withQuestionnaireName(String questionnaireName) {
		this.questionnaireName = questionnaireName;
		return this;
	}
	
	/**
	 * @return the questionnaireDescription
	 */
	public String getQuestionnaireDescription() {
		return questionnaireDescription;
	}

	/**
	 * @param questionnaireName the questionnaireName to set
	 */
	public QuestionnaireDto withQuestionnaireDescription(String questionnaireDescription) {
		this.questionnaireDescription = questionnaireDescription;
		return this;
	}

	/**
	 * @return the sponsorName
	 */
	public String getSponsorName() {
		return sponsorName;
	}

	/**
	 * @param sponsorName the sponsorName to set
	 */
	public QuestionnaireDto withSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
		return this;
	}

	/**
	 * @return the collaboratorName
	 */
	public List<String> getCollaboratorNames() {
		return collaboratorNames;
	}

	/**
	 * @param collaboratorName the collaboratorName to set
	 */
	public QuestionnaireDto withCollaboratorName(List<String> collaboratorNames) {
		this.collaboratorNames = collaboratorNames;
		return this;
	}

	/**
	 * @return the trialName
	 */
	public String getTrialName() {
		return trialName;
	}

	/**
	 * @param trialName the trialName to set
	 */
	public QuestionnaireDto withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}

	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}

	/**
	 * @param programName the programName to set
	 */
	public QuestionnaireDto withProgramName(String programName) {
		this.programName = programName;
		return this;
	}

	/**
	 * @return the createdOn
	 */
	public Date getcreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public QuestionnaireDto withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}
	

	/**
	 * @return the updatedOn
	 */
	public Date getUpdatedOn() {
		return updatedOn;
	}

	/**
	 * @param updatedOn the updatedOn to set
	 */
	public QuestionnaireDto withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
	
	public String getEncryptedQuestionnaireId() {
		return encryptedQuestionnaireId;
	}

    public QuestionnaireDto withEncryptedQuestionnaireId(String encryptedQuestionnaireId) {
		this.encryptedQuestionnaireId = encryptedQuestionnaireId;
		return this;
	}
	

}
