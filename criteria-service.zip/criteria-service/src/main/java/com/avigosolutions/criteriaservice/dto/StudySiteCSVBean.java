package com.avigosolutions.criteriaservice.dto;

import com.univocity.parsers.annotations.Parsed;
import com.univocity.parsers.annotations.Trim;

public class StudySiteCSVBean {

	@Parsed(field = "Active Study Flag")
	private String activeStudyFlag;
	
	@Parsed
	private String region;

	/*@Parsed
	private String subregion;*/
	
	@Trim	
	@Parsed(field = "Standard Country Name")
	private String country;
	
	/*@Parsed(field = "Protocol Number")
	private String protocolNumber;

	@Parsed(field = "Project Code")
	private String projectCode;*/
	
	@Parsed
	private String phase;
	
	@Parsed(field = "Primary Therapeutic Area")
	private String primaryTherapeuticArea;

	@Parsed(field = "Primary Indication")
	private String primaryIndication;

	/*@Parsed(field = "Investigational Product Type")
	private String investigationalProductType;*/

	/*@Parsed
	private String tdu;*/
	
	@Parsed(field = "Ultimate Parent Name")
	private String ultimateParentName;
	
	@Parsed(field = "Account Name")
	private String studySiteName;
	
	/*@Parsed(field = "CTMS Research Facility Identifier")
	private String ctmsResearchFacilityIdentifier;	*/

	@Parsed(field = "Address Line 1")
	private String addressLine1;

	@Parsed(field = "Address Line 2")
	private String addressLine2;
	
	@Parsed(field = "Zip Code")
	private String zip;
	
	@Parsed(field = "Current Study Site Status")
	private String studySiteStatus;
	
	/*@Parsed(field = "Study Site Number")
	private String studySiteNumber;*/

	@Parsed(field = "Project Site IRB Type")
	private String projectSiteIrbType;	
	
	@Parsed
	private String city;

	@Parsed
	private String state;

/*	@Parsed(field = "Site Cluster")
	private String siteCluster;*/
	
	@Parsed(field = "Investigator Name")
	private String investigatorName;

	@Parsed(field = "Phone Number 1")
	private String phoneNumber;
	
	private String emailAddress;


	private String latitude;
	
	private String longitude;
	
	@Parsed(field="Notes")
	private String notes;
	
	private boolean isInValid;
	
	@Parsed(field="Radius Value")
	private String radiusValue;
	
	@Parsed(field="Radius Exempt")
	private String radiusExempt;
	
	@Parsed
	private String npi;
	
	@Parsed
	private String specialty;
	
	@Parsed
	private String project;
	
	
	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	private Long studySiteId;
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}	

	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getStudySiteName() {
		return studySiteName;
	}

	public void setStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getUltimateParentName() {
		return ultimateParentName;
	}

	public void setUltimateParentName(String ultimateParentName) {
		this.ultimateParentName = ultimateParentName;
	}

	/*public String getStudySiteNumber() {
		return studySiteNumber;
	}

	public void setStudySiteNumber(String studySiteNumber) {
		this.studySiteNumber = studySiteNumber;
	}
*/
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	/*public String getSubregion() {
		return subregion;
	}

	public void setSubregion(String subregion) {
		this.subregion = subregion;
	}

	public String getProtocolNumber() {
		return protocolNumber;
	}

	public void setProtocolNumber(String protocolNumber) {
		this.protocolNumber = protocolNumber;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
*/
	public String getPrimaryTherapeuticArea() {
		return primaryTherapeuticArea;
	}

	public void setPrimaryTherapeuticArea(String primaryTherapeuticArea) {
		this.primaryTherapeuticArea = primaryTherapeuticArea;
	}

	public String getPrimaryIndication() {
		return primaryIndication;
	}

	public void setPrimaryIndication(String primaryIndication) {
		this.primaryIndication = primaryIndication;
	}

/*	public String getInvestigationalProductType() {
		return investigationalProductType;
	}

	public void setInvestigationalProductType(String investigationalProductType) {
		this.investigationalProductType = investigationalProductType;
	}

	public String getTdu() {
		return tdu;
	}

	public void setTdu(String tdu) {
		this.tdu = tdu;
	}

	public String getCtmsResearchFacilityIdentifier() {
		return ctmsResearchFacilityIdentifier;
	}

	public void setCtmsResearchFacilityIdentifier(String ctmsResearchFacilityIdentifier) {
		this.ctmsResearchFacilityIdentifier = ctmsResearchFacilityIdentifier;
	}

	public String getSiteCluster() {
		return siteCluster;
	}

	public void setSiteCluster(String siteCluster) {
		this.siteCluster = siteCluster;
	}*/

	public String getActiveStudyFlag() {
		return activeStudyFlag;
	}

	public void setActiveStudyFlag(String activeStudyFlag) {
		this.activeStudyFlag = activeStudyFlag;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public String getProjectSiteIrbType() {
		return projectSiteIrbType;
	}

	public void setProjectSiteIrbType(String projectSiteIrbType) {
		this.projectSiteIrbType = projectSiteIrbType;
	}

	public String getStudySiteStatus() {
		return studySiteStatus;
	}

	public void setStudySiteStatus(String studySiteStatus) {
		this.studySiteStatus = studySiteStatus;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getInvestigatorName() {
		return investigatorName;
	}

	public void setInvestigatorName(String investigatorName) {
		this.investigatorName = investigatorName;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}

	public boolean isInValid() {
		return isInValid;
	}

	public void setInValid(boolean isInValid) {
		this.isInValid = isInValid;
	}

	public String getRadiusValue() {
		return radiusValue;
	}

	public void setRadiusValue(String radiusValue) {
		this.radiusValue = radiusValue;
	}

	public String getRadiusExempt() {
		return String.valueOf(isRadiusExempt());
	}

	public void setRadiusExempt(String radiusExempt) {
		this.radiusExempt = radiusExempt;
	}
	public boolean isRadiusExempt() {
		if(null == radiusExempt) {
			return Boolean.FALSE;
		} else if(radiusExempt.equals("1")) {
			return Boolean.TRUE;
		} else if(radiusExempt.equals("0")){
			return Boolean.FALSE;
		}
		return Boolean.FALSE;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}
	
}
