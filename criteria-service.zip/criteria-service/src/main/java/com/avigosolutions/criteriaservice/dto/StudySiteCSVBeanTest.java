package com.avigosolutions.criteriaservice.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;
import com.avigosolutions.criteriaservice.model.StudySitePrincipalInvestigator;
import com.opencsv.bean.CsvBindByPosition;

public class StudySiteCSVBeanTest {
	@CsvBindByPosition(position = 20)
	private String city;

	@CsvBindByPosition(position = 21)
	private String state;

	@CsvBindByPosition(position = 3)
	private String country;

	@CsvBindByPosition(position = 16)
	private String zip;

	@CsvBindByPosition(position = 12)
	private String studySiteName;

	@CsvBindByPosition(position = 14)
	private String address1;

	@CsvBindByPosition(position = 15)
	private String address2;

	private String emailAddress;

	@CsvBindByPosition(position = 24)
	private String phoneNumber;

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public String getZip() {
		return zip;
	}

	private String latitude;

	public String getLatitude() {
		return latitude;
	}

	public StudySiteCSVBeanTest withLatitude(String latitude) {
		this.latitude = latitude;
		return this;
	}

	private String longitude;

	public String getLongitude() {
		return longitude;
	}

	public StudySiteCSVBeanTest withLongitude(String longitude) {
		this.longitude = longitude;
		return this;
	}

	public String getStudySiteName() {
		return studySiteName;
	}

	public void setStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@CsvBindByPosition(position = 11)
	private String ultimateParentName;

	@CsvBindByPosition(position = 18)
	private String studySiteNumber;

	public StudySiteCSVBeanTest withStudySiteNumber(String studySiteNumber) {
		this.studySiteNumber = studySiteNumber;
		return this;
	}

	public StudySiteCSVBeanTest withUltimateParentName(String ultimateParentName) {
		this.ultimateParentName = ultimateParentName;
		return this;
	}

	public StudySiteCSVBeanTest() {

	}

	public StudySiteCSVBeanTest(String name) {
		this.studySiteName = name;
	}

	public String getUltimateParentName() {
		return ultimateParentName;
	}

	public String getStudySiteNumber() {
		return studySiteNumber;
	}

	@CsvBindByPosition(position = 1)
	private String region;

	@CsvBindByPosition(position = 2)
	private String subRegion;

	@CsvBindByPosition(position = 4)
	private String protocolNumber;

	@CsvBindByPosition(position = 5)
	private String projectCode;

	@CsvBindByPosition(position = 7)
	private String primaryTherapeuticArea;

	@CsvBindByPosition(position = 8)
	private String primaryIndication;

	@CsvBindByPosition(position = 9)
	private String investigationalProductType;

	@CsvBindByPosition(position = 10)
	private String tDU;

	@CsvBindByPosition(position = 13)
	private String cTMSResearchFacilityIdentifier;

	@CsvBindByPosition(position = 22)
	private String siteCluster;

	@CsvBindByPosition(position = 0)
	private String active;

	@CsvBindByPosition(position = 6)
	private String studySitePhaseId;

	@CsvBindByPosition(position = 19)
	private String studySiteIRBId;

	@CsvBindByPosition(position = 17)
	private String studySiteStatusId;

	public String getRegion() {
		return region;
	}

	public StudySiteCSVBeanTest withRegion(String region) {
		this.region = region;
		return this;
	}

	public String getSubRegion() {
		return subRegion;
	}

	public StudySiteCSVBeanTest withSubRegion(String subRegion) {
		this.subRegion = subRegion;
		return this;
	}

	public String getProtocolNumber() {
		return protocolNumber;
	}

	public StudySiteCSVBeanTest withProtocolNumber(String protocolNumber) {
		this.protocolNumber = protocolNumber;
		return this;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public StudySiteCSVBeanTest withProjectCode(String projectCode) {
		this.projectCode = projectCode;
		return this;
	}

	public String getPrimaryTherapeuticArea() {
		return primaryTherapeuticArea;
	}

	public StudySiteCSVBeanTest withPrimaryTherapeuticArea(String primaryTherapeuticArea) {
		this.primaryTherapeuticArea = primaryTherapeuticArea;
		return this;
	}

	public String getPrimaryIndication() {
		return primaryIndication;
	}

	public StudySiteCSVBeanTest withPrimaryIndication(String primaryIndication) {
		this.primaryIndication = primaryIndication;
		return this;
	}

	public String getInvestigationalProductType() {
		return investigationalProductType;
	}

	public StudySiteCSVBeanTest withInvestigationalProductType(String investigationalProductType) {
		this.investigationalProductType = investigationalProductType;
		return this;
	}

	public String getTDU() {
		return tDU;
	}

	public StudySiteCSVBeanTest withTDU(String tDU) {
		this.tDU = tDU;
		return this;
	}

	public String getCTMSResearchFacilityIdentifier() {
		return cTMSResearchFacilityIdentifier;
	}

	public StudySiteCSVBeanTest withCTMSResearchFacilityIdentifier(String cTMSResearchFacilityIdentifier) {
		this.cTMSResearchFacilityIdentifier = cTMSResearchFacilityIdentifier;
		return this;
	}

	public String getSiteCluster() {
		return siteCluster;
	}

	public StudySiteCSVBeanTest withSiteCluster(String siteCluster) {
		this.siteCluster = siteCluster;
		return this;
	}

	public String getActive() {
		return active;
	}

	public StudySiteCSVBeanTest withActive(String active) {
		this.active = active;
		return this;
	}

	public String getStudySitePhaseId() {
		return studySitePhaseId;
	}

	public StudySiteCSVBeanTest withStudySitePhaseId(String studySitePhaseId) {
		this.studySitePhaseId = studySitePhaseId;
		return this;
	}

	public String getStudySiteIRBId() {
		return studySiteIRBId;
	}

	public StudySiteCSVBeanTest withStudySiteIRBId(String studySiteIRBId) {
		this.studySiteIRBId = studySiteIRBId;
		return this;
	}

	public String getStudySiteStatusId() {
		return studySiteStatusId;
	}

	public StudySiteCSVBeanTest withStudySiteStatusId(String studySiteStatusId) {
		this.studySiteStatusId = studySiteStatusId;
		return this;
	}

}
