package com.avigosolutions.criteriaservice.dto;

public class StudySiteLightWeightDTO {
	
	private String studySite;
	
	private Integer radiusValue;
	
	private boolean radiusExempt;
	
	private Long studySiteId;
	
	private boolean active;

	private String piName;
	
	public String getStudySite() {
		return studySite;
	}

	public void setStudySite(String studySite) {
		this.studySite = studySite;
	}

	public Integer getRadiusValue() {
		return radiusValue;
	}

	public void setRadiusValue(Integer radiusValue) {
		this.radiusValue = radiusValue;
	}

	public boolean isRadiusExempt() {
		return radiusExempt;
	}

	public void setRadiusExempt(boolean radiusExempt) {
		this.radiusExempt = radiusExempt;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getPiName() {
		return piName;
	}

	public void setPiName(String piName) {
		this.piName = piName;
	}
	
}
