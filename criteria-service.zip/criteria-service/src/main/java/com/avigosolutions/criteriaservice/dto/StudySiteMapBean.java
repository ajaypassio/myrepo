package com.avigosolutions.criteriaservice.dto;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class StudySiteMapBean {

	private static final long serialVersionUID = 2312121232L;

	private Long studySiteId;
	private double latitude;
	private double longitude;
	private String studySiteName;

	public StudySiteMapBean() {

	}

	public StudySiteMapBean(Long id, String name, double lat, double lng) {
		this.studySiteName = name;
		this.studySiteId = id;
		this.latitude = lat;
		this.longitude = lng;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public StudySiteMapBean withStudySiteId(Long id) {
		this.studySiteId = id;
		return this;
	}

	public double getLatitude() {
		return latitude;
	}

	public StudySiteMapBean withLatitude(double latitude) {
		this.latitude = latitude;
		return this;
	}

	public double getLongitude() {
		return longitude;
	}

	public StudySiteMapBean withLongitude(double longitude) {
		this.longitude = longitude;
		return this;
	}

	public String getStudySiteName() {
		return studySiteName;
	}

	public void setStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
	}

}
