package com.avigosolutions.criteriaservice.enums;

import com.fasterxml.jackson.annotation.JsonValue;

public enum PhysicianCriteriaEnums {

	Draft("Draft", 1),
	Submitted("Submitted", 2),
	CountsGenerated("Counts_Generated", 3),
	PhysicianGenerated("Physician_Generated", 4),
	PhysicianPopulationInitiated("Physician_Population_Initiated", 5),
	PhysicianPopulated("Physician_Populated", 6),
	PhysicianGenerationFailed("Physician_Generation_Failed", 7),	
	PhysicianPopulationFailed("Physician_Population_Failed", 8);

	/** The value. */
	private final String type;
	private final Integer value;

	PhysicianCriteriaEnums(String type, Integer value) {
		this.type = type;
		this.value = value;
	}

	/**
	 * @return the type
	 */
	@JsonValue
	public String getType() {
		return type;
	}

	/**
	 * @return the value
	 */
	@JsonValue
	public Integer getValue() {
		return value;
	}

	public static PhysicianCriteriaEnums getStatusOf(int value) {
		for (PhysicianCriteriaEnums status : PhysicianCriteriaEnums.values()) {
			if (status.value == value)
				return status;
		}
		return null;
	}

	public static PhysicianCriteriaEnums getStatusOf(String type) {
		for (PhysicianCriteriaEnums status : PhysicianCriteriaEnums.values()) {
			if (status.type.equalsIgnoreCase(type))
				return status;
		}
		return null;
	}

	@Override
	public String toString() {
		return this.type;
	}
}
