package com.avigosolutions.criteriaservice.json.parser;

import static com.avigosolutions.criteriaservice.json.parser.container.ContainerType.getContainerType;
import static com.avigosolutions.criteriaservice.json.parser.container.ContainerType.ModuleName.INCLUSION_EXCLUSION;

import java.util.Iterator;
import org.springframework.util.StringUtils;

import com.avigosolutions.criteriaservice.json.parser.container.AbstractContainer;
import com.avigosolutions.criteriaservice.json.parser.container.BaseContainer;
import com.avigosolutions.criteriaservice.json.parser.container.Container;
import com.avigosolutions.criteriaservice.json.parser.container.ContainerType;
import com.avigosolutions.criteriaservice.json.parser.container.EQCLogicalGroupContainerIE;
import com.avigosolutions.criteriaservice.json.parser.container.ExpressionQueueContainerIE;
import com.avigosolutions.criteriaservice.json.parser.container.SCCLogicalGroupContainerIE;
import com.avigosolutions.criteriaservice.json.parser.container.SearchCriteriaContainerIE;
import com.avigosolutions.criteriaservice.json.parser.exception.InputValidationException;
import com.avigosolutions.criteriaservice.json.parser.expression.ComparisonOperator;
import com.avigosolutions.criteriaservice.json.parser.expression.Expression;
import com.avigosolutions.criteriaservice.json.parser.expression.Operand;
import com.avigosolutions.criteriaservice.json.parser.expression.Operator;
import com.avigosolutions.criteriaservice.json.parser.validator.InputValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.DoubleNode;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.node.LongNode;
import com.fasterxml.jackson.databind.node.TextNode;

public class JSONContractParserHelperIE {

	private static final String VALUE = "value";
	private static final String VALUESTR = "valuestr";
	private static final String TYPE_IE = "type";
	private static final String DEMOGRAPHICS_IE = "Demographics";
	private static final String FIELD_LABEL = "fieldLabel";
	private static final String FIELD_VALUE = "fieldValue";
	private static final String TRUE = "true";
	private static final String RANGE = "range";

	// Use below when data type is governed by UI. private static final String
	// VALUE_TYPE = "valueType";

	private JSONContractParserHelperIE() {
		throw new UnsupportedOperationException("instantiation not allowed.");
	}

	private static <T extends AbstractContainer> BaseContainer<T> processContainerForSingleQueueEntry(
			BaseContainer<T> container) {
		if (!container.isEmpty() && container.size() == 1) {
			container.setLogicalOperator(null);
		}
		return container;
	}

	static Container getSCCLogicalGroupContainers(BaseContainer<SCCLogicalGroupContainerIE> criteriaGroupContainer,
			JsonNode node) throws InputValidationException {
		if (node != null && node.fieldNames().hasNext()) {
			Iterator<String> itr = node.fieldNames();
			while (itr.hasNext()) {
				String currentField = itr.next();
				JsonNode currentNode = node.get(currentField);
				BaseContainer<SearchCriteriaContainerIE> sccLogicalGroupContainer = new SCCLogicalGroupContainerIE(
						getContainerType(currentField, SCCLogicalGroupContainerIE.class, INCLUSION_EXCLUSION));
				if (currentNode != null && currentNode.isArray() && currentNode.size() > 0) {
					criteriaGroupContainer.offer(getSearchCriteriaContainers(sccLogicalGroupContainer, currentNode));
				}
			}
		}
		return processContainerForSingleQueueEntry(criteriaGroupContainer);
	}

	private static SCCLogicalGroupContainerIE getSearchCriteriaContainers(
			BaseContainer<SearchCriteriaContainerIE> sccLogicalGroupContainer, JsonNode jsonNode)
			throws InputValidationException {
		for (int i = 0; i < jsonNode.size(); i++) {
			JsonNode currentNode = jsonNode.get(i);
			if (currentNode != null && currentNode.fieldNames().hasNext()) {
				Iterator<String> itr = currentNode.fieldNames();
				while (itr.hasNext()) {
					String currentField = itr.next();
					ContainerType cType = getContainerType(currentField, SearchCriteriaContainerIE.class,
							INCLUSION_EXCLUSION);

					sccLogicalGroupContainer.offer(getEQCLogicalGroupContainers(new SearchCriteriaContainerIE(cType),
							currentNode.get(currentField)));
				}
			}
		}
		return (SCCLogicalGroupContainerIE) processContainerForSingleQueueEntry(sccLogicalGroupContainer);
	}

	private static SearchCriteriaContainerIE getEQCLogicalGroupContainers(
			BaseContainer<EQCLogicalGroupContainerIE> searchCriteriaContainer, JsonNode node)
			throws InputValidationException {
		if (node != null && node.fieldNames().hasNext()) {
			Iterator<String> itr = node.fieldNames();
			while (itr.hasNext()) {
				String currentField = itr.next();
				JsonNode currentNode = node.get(currentField);
				BaseContainer<ExpressionQueueContainerIE> eqcLogicalGroupContainer = new EQCLogicalGroupContainerIE(
						getContainerType(currentField, EQCLogicalGroupContainerIE.class, INCLUSION_EXCLUSION));
				if (currentNode != null && currentNode.isArray() && currentNode.size() > 0) {
					searchCriteriaContainer.offer(getExpressionQueueContainers(eqcLogicalGroupContainer, currentNode));
				}
			}
		}
		return (SearchCriteriaContainerIE) processContainerForSingleQueueEntry(searchCriteriaContainer);
	}

	private static EQCLogicalGroupContainerIE getExpressionQueueContainers(
			BaseContainer<ExpressionQueueContainerIE> eqcLogicalGroupContainer, JsonNode jsonNode)
			throws InputValidationException {
		for (int i = 0; i < jsonNode.size(); i++) {
			JsonNode currentNode = jsonNode.get(i);
			if (currentNode != null && currentNode.fieldNames().hasNext()) {
				Iterator<String> itr = currentNode.fieldNames();
				while (itr.hasNext()) {
					String currentField = itr.next();
					if (currentField.equals(TYPE_IE)) {
						ContainerType cType = currentNode.get(TYPE_IE).asText().equalsIgnoreCase(DEMOGRAPHICS_IE)
								? ContainerType.DEMOGRAPHICS_IE
								: null;
						String subType = itr.next();
						JsonNode node = currentNode.get(subType);
						if (node != null && node.fieldNames().hasNext()) {
							Iterator<String> itrInner = node.fieldNames();
							String currentFieldInner = itrInner.next();
							if (cType == null) {
								cType = getContainerType(currentFieldInner, ExpressionQueueContainerIE.class,
										INCLUSION_EXCLUSION);
							}
							eqcLogicalGroupContainer.offer(getExpressionQueue(new ExpressionQueueContainerIE(cType),
									currentFieldInner, node.get(currentFieldInner)));
						}
					}
				}
			}
		}

		return (EQCLogicalGroupContainerIE) eqcLogicalGroupContainer;
	}

	private static ExpressionQueueContainerIE getExpressionQueue(ExpressionQueueContainerIE expressionQueueContainer,
			String subType, JsonNode jsonNode) throws InputValidationException {
		ContainerType cType = expressionQueueContainer.getContainerType();
		switch (cType) {
		case DEMOGRAPHICS_IE:
			prepareDemographicsIEExpressions(subType, jsonNode, expressionQueueContainer);
			break;
		case LAB_RESULTS_IE:
			prepareLabResultsIEExpressionsNew(jsonNode, expressionQueueContainer);
			break;
		case DIAGNOSTICS_IE:
			prepareDiagnosticsIEExpressionsNew(jsonNode, expressionQueueContainer);
			break;
		case COMMON_TIME_IE:
			prepareCommonTimeIEExpression(jsonNode, expressionQueueContainer);
			break;
		default:
			break;
		}
		return expressionQueueContainer;
	}

	private static void prepareDiagnosticsIEExpressionsNew(JsonNode jsonNode, ExpressionQueueContainerIE eQContainer)
			throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			int index = 0;
			boolean includeTimeUnit = false;
			// diag node
			JsonNode diagNode = jsonNode.get(index);
			Expression diagIcdCodeExpression = new Expression();
			String diagFieldLabel = diagNode.get(FIELD_LABEL).asText();

			// ICD code diag expression
			diagIcdCodeExpression.setLeftOperand(getLHOperand(diagFieldLabel));
			diagIcdCodeExpression.setRightOperand(getRHOperand(diagNode.get(FIELD_VALUE), false));
			diagIcdCodeExpression.setOperator(ComparisonOperator.EQ);
			eQContainer.offer(diagIcdCodeExpression);
			// ICD code set expression
			Expression diagIcdCodeSetExpression = new Expression();
			JsonNode icdCodeSetNode = jsonNode.get(++index);
			diagIcdCodeSetExpression.setOperator(ComparisonOperator.EQ);
			diagIcdCodeSetExpression.setLeftOperand(getLHOperand(icdCodeSetNode.get(FIELD_LABEL).asText()));
			diagIcdCodeSetExpression.setRightOperand(getRHOperand(icdCodeSetNode.get(FIELD_VALUE), false));
			eQContainer.offer(diagIcdCodeSetExpression);

			processTimeComponentFields(jsonNode, index, eQContainer, includeTimeUnit);
		}
	}

	private static void processTimeComponentFields(JsonNode jsonNode, int index, ExpressionQueueContainerIE eQContainer,
			boolean includeTimeUnit) throws InputValidationException {
		// Time component expression
		JsonNode timeComponentCBNode = jsonNode.get(++index);
		if (timeComponentCBNode.get(FIELD_VALUE).asText().equalsIgnoreCase(TRUE)) {
			JsonNode timeComponentNode = jsonNode.get(++index);
			Expression timeComponentExpression = new Expression();
			timeComponentExpression.setLeftOperand(getLHOperand(timeComponentNode.get(FIELD_VALUE).asText()));
			JsonNode conditionNode = jsonNode.get(++index);
			if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase(RANGE)) {
				JsonNode minNode = jsonNode.get(++index);
				Expression timeComponentExpressionMin = new Expression();
				timeComponentExpressionMin.setLeftOperand(getLHOperand(timeComponentNode.get(FIELD_VALUE).asText()));
				timeComponentExpressionMin.setOperator(ComparisonOperator.GTE);
				timeComponentExpressionMin.setRightOperand(getRHOperand(minNode.get(FIELD_VALUE), false));
				eQContainer.offer(timeComponentExpressionMin);
				JsonNode maxNode = jsonNode.get(++index);
				timeComponentExpression.setOperator(ComparisonOperator.LTE);
				timeComponentExpression.setRightOperand(getRHOperand(maxNode.get(FIELD_VALUE), false));
				if (timeComponentNode.get(FIELD_VALUE).asText().equalsIgnoreCase("patientAgeAtDateOfService"))
					includeTimeUnit = true;
			} else if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("forThePast")) {

				JsonNode valueNode = jsonNode.get(++index);
				Expression timeComponentExpressionMin = new Expression();
				timeComponentExpressionMin.setOperator(ComparisonOperator.GTE);
				timeComponentExpressionMin.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE), false));
				timeComponentExpressionMin.setLeftOperand(getLHOperand(timeComponentNode.get(FIELD_VALUE).asText()));

				timeComponentExpression.setRightOperand(new Operand<>("0"));
				timeComponentExpression.setOperator(ComparisonOperator.LTE);
				eQContainer.offer(timeComponentExpressionMin);
				includeTimeUnit = true;
			} else {
				timeComponentExpression.setOperator(getOperator(conditionNode.get(FIELD_VALUE).asText()));
				JsonNode valueNode = jsonNode.get(++index);
				timeComponentExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE),
						isRHOperandAnArray(timeComponentExpression.getOperator())));
				if (timeComponentNode.get(FIELD_VALUE).asText().equalsIgnoreCase("patientAgeAtDateOfService"))
					includeTimeUnit = true;
			}
			eQContainer.offer(timeComponentExpression);

			// time component unit node
			if (includeTimeUnit) {
				JsonNode timeComponentUnitNode = jsonNode.get(++index);
				Expression timeComponentUnitExpression = new Expression();
				timeComponentUnitExpression
						.setLeftOperand(getLHOperand(timeComponentUnitNode.get(FIELD_LABEL).asText()));
				timeComponentUnitExpression
						.setRightOperand(getRHOperand(timeComponentUnitNode.get(FIELD_VALUE), false));
				timeComponentUnitExpression.setOperator(ComparisonOperator.EQ);
				eQContainer.offer(timeComponentUnitExpression);
			}
		}
	}

	private static void prepareCommonTimeIEExpression(JsonNode jsonNode,
			ExpressionQueueContainerIE expressionQueueContainer) throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			int index = 0;
			JsonNode conditionNode = jsonNode.get(index);
			String conditionNodeValue = conditionNode.get(FIELD_VALUE).asText();
			Expression commonTimeMinExpression = new Expression();
			commonTimeMinExpression.setLeftOperand(
					getLHOperand(ContainerType.getFieldName(conditionNodeValue, "time", INCLUSION_EXCLUSION)));
			commonTimeMinExpression.setOperator(ComparisonOperator.GTE);

			Expression commonTimeMaxExpression = new Expression();
			commonTimeMaxExpression.setLeftOperand(
					getLHOperand(ContainerType.getFieldName(conditionNodeValue, "time", INCLUSION_EXCLUSION)));
			commonTimeMaxExpression.setOperator(ComparisonOperator.LTE);

			if (conditionNodeValue.equalsIgnoreCase("forThePast")) {
				JsonNode valueNode = jsonNode.get(++index);
				commonTimeMinExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE), false));
				commonTimeMaxExpression.setRightOperand(new Operand<>("0"));
				expressionQueueContainer.offer(commonTimeMinExpression);
				expressionQueueContainer.offer(commonTimeMaxExpression);

				JsonNode unitNode = jsonNode.get(++index);
				Expression commonTimeUnitExpression = new Expression();
				commonTimeUnitExpression.setLeftOperand(getLHOperand(unitNode.get(FIELD_LABEL).asText()));
				commonTimeUnitExpression.setOperator(ComparisonOperator.EQ);
				commonTimeUnitExpression.setRightOperand(getRHOperand(unitNode.get(FIELD_VALUE), false));
				expressionQueueContainer.offer(commonTimeUnitExpression);
			} else if (conditionNodeValue.equalsIgnoreCase("dateRangeBetween")) {
				JsonNode minNode = jsonNode.get(++index);
				commonTimeMinExpression.setRightOperand(getRHOperand(minNode.get(FIELD_VALUE), false));
				JsonNode maxNode = jsonNode.get(++index);
				commonTimeMaxExpression.setRightOperand(getRHOperand(maxNode.get(FIELD_VALUE), false));
				expressionQueueContainer.offer(commonTimeMinExpression);
				expressionQueueContainer.offer(commonTimeMaxExpression);
			}
		}
	}

	private static void prepareLabResultsIEExpressionsNew(JsonNode jsonNode, ExpressionQueueContainerIE eQContainer)
			throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			int index = 0;
			boolean includeTimeUnit = false;
			// lab test name node
			JsonNode labTestNameNode = jsonNode.get(index);
			Expression labTestNameExpression = new Expression();
			labTestNameExpression.setLeftOperand(getLHOperand(labTestNameNode.get(FIELD_LABEL).asText()));
			labTestNameExpression.setRightOperand(getRHOperand(labTestNameNode.get(FIELD_VALUE), false));
			labTestNameExpression.setOperator(ComparisonOperator.EQ);
			eQContainer.offer(labTestNameExpression);

			// lab test condition
			JsonNode labTestConditionNode = jsonNode.get(++index);
			String labTestConditionValue = labTestConditionNode.get(FIELD_VALUE).asText();
			// check if result comment text is there
			if (labTestConditionValue.equalsIgnoreCase("resultCommentText")) {
				Expression resultCommentTextExpression = new Expression();
				resultCommentTextExpression.setLeftOperand(getLHOperand(labTestConditionValue));
				resultCommentTextExpression.setOperator(ComparisonOperator.LIKE);
				JsonNode resultCommentTextValueNode = jsonNode.get(++index);

				resultCommentTextExpression
						.setRightOperand(new Operand<>(resultCommentTextValueNode.get(FIELD_VALUE).asText()));
				eQContainer.offer(resultCommentTextExpression);
			} else {
				JsonNode labTestValueTypeNode = jsonNode.get(++index);
				String labTestValueType = labTestValueTypeNode.get(FIELD_VALUE).asText();
				Expression labTestValueExpression = new Expression();
				labTestValueExpression.setLeftOperand(
						getLHOperand(labTestValueType.equalsIgnoreCase("other") ? VALUE : labTestValueType));

				// lab test value multiplier - is blank for ref-range alpha and other
				JsonNode labTestValueMultiplierNode = null;
				String labTestValueMultiplier = null;
				labTestValueMultiplierNode = jsonNode.get(++index);
				labTestValueMultiplier = labTestValueMultiplierNode.get(FIELD_VALUE).asText();

				if (labTestConditionValue.equalsIgnoreCase(RANGE)) {
					if (labTestValueType.equalsIgnoreCase("refRangeAlpha")) {
						Expression refRangeAlphaExpression = new Expression();
						refRangeAlphaExpression.setLeftOperand(getLHOperand(labTestValueType));
						JsonNode endPointsNode = jsonNode.get(++index);
						refRangeAlphaExpression.setOperator(getOperator(endPointsNode.get(FIELD_VALUE).asText()));
						JsonNode rangesNode = jsonNode.get(++index);
						refRangeAlphaExpression.setRightOperand(new Operand<>(rangesNode.get(FIELD_VALUE).asText()));
						eQContainer.offer(refRangeAlphaExpression);
					} else {
						JsonNode minValueNode = jsonNode.get(++index);
						Expression minValExpression = new Expression();
						minValExpression.setLeftOperand(
								getLHOperand(labTestValueType.equalsIgnoreCase("other") ? VALUE : labTestValueType));
						minValExpression.setOperator(ComparisonOperator.GTE);
						minValExpression.setRightOperand(getRHOperand(minValueNode.get(FIELD_VALUE), false));
						eQContainer.offer(minValExpression);

						JsonNode maxValueNode = jsonNode.get(++index);
						labTestValueExpression.setOperator(ComparisonOperator.LTE);
						labTestValueExpression.setRightOperand(getRHOperand(maxValueNode.get(FIELD_VALUE), false));
						eQContainer.offer(labTestValueExpression);
					}
				} else {
					if (!labTestValueType.equalsIgnoreCase("other")) {
						// ref-ranges low/high
						labTestValueExpression.setOperator(getOperator(labTestConditionValue));
						labTestValueExpression.setRightOperand(new Operand<>(labTestValueMultiplier));
					} else {
						// value type is other/decision point
						// lab test value node
						labTestValueExpression.setOperator(getOperator(labTestConditionValue));
						JsonNode valueNode = jsonNode.get(++index);
						// Result Test Value from numeric change to alphanumeric if decision point is eq
						if (labTestConditionValue.equalsIgnoreCase("eq")) {
							Operand<?> rightOperand = null;
							String customizeNumberRegex = "([+-])?(\\s*)?(\\d*\\.)?(\\d+)";
							if (valueNode.get(FIELD_VALUE).asText().matches(customizeNumberRegex)) {
								String fieldValue = valueNode.get(FIELD_VALUE).asText().replace("+", "").trim();
								rightOperand = new Operand<>(Double.valueOf(fieldValue));
							} else {
								labTestValueExpression.setLeftOperand(getLHOperand(VALUESTR));
								rightOperand = new Operand<>(valueNode.get(FIELD_VALUE).asText().trim());
							}
							labTestValueExpression.setRightOperand(rightOperand);
						} else {
							labTestValueExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE), false));
						}
					}
					eQContainer.offer(labTestValueExpression);

				}

				// lab test unit node
				if (labTestValueType.equalsIgnoreCase("other")) {
					JsonNode labTestUnitNode = jsonNode.get(++index);
					Expression labTestUnitExpression = new Expression();
					labTestUnitExpression.setLeftOperand(getLHOperand(labTestUnitNode.get(FIELD_LABEL).asText()));
					labTestUnitExpression.setRightOperand(getRHOperand(labTestUnitNode.get(FIELD_VALUE), false));
					labTestUnitExpression.setOperator(ComparisonOperator.EQ);
					eQContainer.offer(labTestUnitExpression);
				}
			}

			processTimeComponentFields(jsonNode, index, eQContainer, includeTimeUnit);
		}
	}

	private static void prepareDemographicsIEExpressions(String subType, JsonNode jsonNode,
			ExpressionQueueContainerIE eQContainer) throws InputValidationException {
		if (jsonNode != null && jsonNode.isArray() && jsonNode.size() > 0) {
			Expression demographicsExpression = new Expression();
			demographicsExpression.setLeftOperand(new Operand<>(subType));

			JsonNode conditionNode = jsonNode.get(0);
			// if a condition node is meant only for eid population then use if/else to set
			// the tag
			demographicsExpression.setTag("noneid");
			if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase(RANGE)) {
				JsonNode minNode = jsonNode.get(1);
				Expression demographicsExpression0 = new Expression();
				demographicsExpression0.setTag("noneid");
				demographicsExpression0.setLeftOperand(new Operand<>(subType));
				demographicsExpression0.setOperator(ComparisonOperator.GTE);
				demographicsExpression0.setRightOperand(getRHOperand(minNode.get(FIELD_VALUE), false));
				eQContainer.offer(demographicsExpression0);
				JsonNode maxNode = jsonNode.get(2);
				demographicsExpression.setOperator(ComparisonOperator.LTE);
				demographicsExpression.setRightOperand(getRHOperand(maxNode.get(FIELD_VALUE), false));
				eQContainer.offer(demographicsExpression);
			} else if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("state")
					|| conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("stateCity")
					|| conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("zipCode")) {
				demographicsExpression.setLeftOperand(getLHOperand(conditionNode.get(FIELD_VALUE).asText()));
				demographicsExpression.setOperator(ComparisonOperator.IN);
				JsonNode valueNode = jsonNode.get(1);
				demographicsExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE), true));
				eQContainer.offer(demographicsExpression);
				if (conditionNode.get(FIELD_VALUE).asText().equalsIgnoreCase("zipCode") && jsonNode.get(2) != null) {
					JsonNode radiusNode = jsonNode.get(2);
					if(!StringUtils.isEmpty(radiusNode.get(FIELD_VALUE).asText())){
						Expression radiusExpression = new Expression();
						radiusExpression.setLeftOperand(getLHOperand(radiusNode.get(FIELD_LABEL).asText()));
						radiusExpression.setOperator(ComparisonOperator.EQ);
						radiusExpression.setRightOperand(getRHOperand(radiusNode.get(FIELD_VALUE), false));
						radiusExpression.setTag("noneid");
						eQContainer.offer(radiusExpression);
					}
				}
			} else if (jsonNode.size() == 1) {
				// only value exists with default string comparison.
				demographicsExpression.setOperator(ComparisonOperator.EQ);
				demographicsExpression.setRightOperand(getRHOperand(jsonNode.get(0).get(FIELD_VALUE), false));
				eQContainer.offer(demographicsExpression);
			} else {
				demographicsExpression.setOperator(getOperator(conditionNode.get(FIELD_VALUE).asText()));
				JsonNode valueNode = jsonNode.get(1);
				demographicsExpression.setRightOperand(getRHOperand(valueNode.get(FIELD_VALUE),
						isRHOperandAnArray(demographicsExpression.getOperator())));
				eQContainer.offer(demographicsExpression);
			}
		}
	}

	private static boolean isRHOperandAnArray(Operator op) {
		if (op instanceof ComparisonOperator) {
			return op == ComparisonOperator.IN;
		}
		return false;
	}

	private static Operand<String> getLHOperand(String value) {
		return new Operand<>(value);
	}

	private static Operator getOperator(String field) {
		// default operation
		return ComparisonOperator.valueOf(field.toUpperCase());
	}

	private static Operand<?> getRHOperand(JsonNode value, boolean isArray) throws InputValidationException {
		Class<?> valueClass = value.getClass();
		Operand<?> operand = null;
		Object val = null;
		Object[] valArr = null;
		// validate value for allowed characters
		if (valueClass == IntNode.class) {
			InputValidator.validateValue(Integer.valueOf(value.asInt()));
			val = Integer.valueOf(value.asInt());
		}
		if (valueClass == LongNode.class) {
			InputValidator.validateValue(Long.valueOf(value.asLong()));
			val = Long.valueOf(value.asLong());
		}
		if (valueClass == DoubleNode.class) {
			InputValidator.validateValue(Double.valueOf(value.asDouble()));
			val = Double.valueOf(value.asDouble());
		}
		if (valueClass == TextNode.class) {
			String str = value.asText();
			InputValidator.validateValue(str);
			if (isArray) {
				valArr = str.contains(",") ? value.asText().split(",") : new Object[] { value.asText() };
				if (valArr != null && valArr.length > 0) {
					for (int i = 0; i < valArr.length; i++) {
						valArr[i] = ((String) valArr[i]).trim();
					}
				}
			} else {
				val = str;
			}
		}

		operand = valArr == null ? new Operand<>(val) : new Operand<>(valArr);
		return operand;
	}

}