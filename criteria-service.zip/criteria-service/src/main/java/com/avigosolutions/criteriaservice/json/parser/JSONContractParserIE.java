package com.avigosolutions.criteriaservice.json.parser;

import static com.avigosolutions.criteriaservice.json.parser.JSONContractParserHelperIE.getSCCLogicalGroupContainers;

import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.json.parser.container.ContainerType;
import com.avigosolutions.criteriaservice.json.parser.container.SearchCriteriaGroupContainerIE;
import com.avigosolutions.criteriaservice.json.parser.exception.InputValidationException;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class JSONContractParserIE {

	public SearchCriteriaGroupContainerIE parseJSONInput(JsonNode rootNode, ContainerType cType)
			throws InputValidationException {
		return (SearchCriteriaGroupContainerIE) getSCCLogicalGroupContainers(new SearchCriteriaGroupContainerIE(cType),
						rootNode);
	}

}
