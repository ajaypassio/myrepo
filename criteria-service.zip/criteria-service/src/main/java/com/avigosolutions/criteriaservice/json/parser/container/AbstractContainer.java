package com.avigosolutions.criteriaservice.json.parser.container;

import com.avigosolutions.criteriaservice.json.parser.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class AbstractContainer implements Container {
	
	@JsonProperty("containerType")
	private ContainerType containerType;
	
	@JsonProperty("logicalOperator")
	private LogicalOperator logicalOperator;
	
	protected AbstractContainer() {}
	
	protected AbstractContainer(ContainerType containerType) {
		this.containerType = containerType;
	}

	public void setLogicalOperator(LogicalOperator logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	@Override
	public LogicalOperator getLogicalOperator() {
		return logicalOperator;
	}

	@Override
	public ContainerType getContainerType() {
		return containerType;
	}

	public void setContainerType(ContainerType containerType) {
		this.containerType = containerType;
	}

}