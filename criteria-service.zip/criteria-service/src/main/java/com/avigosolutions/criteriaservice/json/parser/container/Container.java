package com.avigosolutions.criteriaservice.json.parser.container;

import com.avigosolutions.criteriaservice.json.parser.expression.LogicalOperator;

public interface Container {

	ContainerType getContainerType();
	
	LogicalOperator getLogicalOperator();
	
	boolean isEmpty();
	
	int size();
}
