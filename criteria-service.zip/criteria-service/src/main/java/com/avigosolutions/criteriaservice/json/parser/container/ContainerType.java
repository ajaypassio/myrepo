package com.avigosolutions.criteriaservice.json.parser.container;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum ContainerType {

	@JsonProperty("LabResults")
	LAB_RESULTS_IE("LabResults", ExpressionQueueContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	@JsonProperty("Diagnostic")
	DIAGNOSTICS_IE("Diagnostic", ExpressionQueueContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	@JsonProperty("Demographics")
	DEMOGRAPHICS_IE("Demographics", ExpressionQueueContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	@JsonProperty("time")
	COMMON_TIME_IE("time", ExpressionQueueContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	INIT_EQCLGC_IE("INIT", EQCLogicalGroupContainerIE.class, ModuleName.INCLUSION_EXCLUSION), 
	OR_EQCLGC_IE("OR", EQCLogicalGroupContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	IC_IE("IC", SearchCriteriaContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	INIT_SCCLGC_IE("INIT", SCCLogicalGroupContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	OR_SCCLGC_IE("OR", SCCLogicalGroupContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	@JsonProperty("inclusionCriteria")
	INCLUSION_CRITERIA("inclusionCriteria", SearchCriteriaGroupContainerIE.class, ModuleName.INCLUSION_EXCLUSION),
	@JsonProperty("exclusionCriteria")
	EXCLUSION_CRITERIA("exclusionCriteria", SearchCriteriaGroupContainerIE.class, ModuleName.INCLUSION_EXCLUSION)
	;
	
	public enum ModuleName {INCLUSION_EXCLUSION, CLINICIAN_SEARCH}

	private String typeName;

	private Class<?> containerClass;
	
	private ModuleName moduleName;
	
	private static final Map<ContainerType, Map<String, String>> containerFieldMap = new ConcurrentHashMap<>();

	private ContainerType(String typeName, Class<?> containerClass, ModuleName moduleName) {
		this.typeName = typeName;
		this.containerClass = containerClass;
		this.moduleName = moduleName;
	}

	public String getTypeName() {
		return typeName;
	}

	public Class<?> getContainerClass() {
		return containerClass;
	}
	
	public ModuleName getModuleName() {
		return moduleName;
	}
	
	@Override
	public String toString() {
		return this.getTypeName();
	}

	public static ContainerType getContainerType(String elementName, Class<?> clazz, ModuleName moduleName) {
		for (ContainerType criteria : ContainerType.values()) {
			if (elementName.toLowerCase().contains(criteria.typeName.toLowerCase()) && (clazz == null || criteria.getContainerClass().equals(clazz))
					&& criteria.moduleName == moduleName) {
				return criteria;
			}
		}
		return null;
	}
	
	private static void initializeFieldMaps() {
		initializeLabResultsIEMap();
		initializeDiagnosticsIEMap();
		initializeDemographicsIEMap();
		initializeCommonTimeIEMap();
	}
	
	
	public static String getFieldName(String key, ModuleName module) {
		if (containerFieldMap.isEmpty()) {
			initializeFieldMaps();
		}
		return containerFieldMap.get(getContainerType(key, null, module)).get(key);
	}
	
	public static String getFieldName(String fieldKey, String typeName, ModuleName module) {
		if (containerFieldMap.isEmpty()) {
			initializeFieldMaps();
		}
		return containerFieldMap.get(getContainerType(typeName, null, module)).get(fieldKey);
	}
	 
	
	private static void initializeLabResultsIEMap() {
		Map<String, String> labResultsIE = new HashMap<>();
		labResultsIE.put("LabResults", "labRecords");
		labResultsIE.put("LabTestLookup", "testName");
		labResultsIE.put("labTestValue", "testValue");
		labResultsIE.put("labTestUnits", "testUnits");
		labResultsIE.put("dateOfService", "dateOfService");
		labResultsIE.put("patientAgeAtDateOfService", "patientAgeAtDateOfService");
		labResultsIE.put("resultCommentText", "resultCommentText");
		labResultsIE.put("refRangeAlpha", "refRangeAlpha");
		labResultsIE.put("refRangeLow", "refRangeLow");
		labResultsIE.put("refRangeHigh", "refRangeHigh");
		containerFieldMap.put(LAB_RESULTS_IE, labResultsIE);
	}
	
	private static void initializeDiagnosticsIEMap() {
		Map<String, String> diagnosticsIE = new HashMap<>();
		diagnosticsIE.put("Diagnostic", "diagnosisRecords");
		diagnosticsIE.put("icdCodeSet", "icdCodeSet");
		diagnosticsIE.put("icdCode", "icdCode");
		diagnosticsIE.put("dateOfService", "dateOfService");
		diagnosticsIE.put("patientAgeAtDateOfService", "patientAgeAtDateOfService");
		containerFieldMap.put(DIAGNOSTICS_IE, diagnosticsIE);
	}
	
	private static void initializeDemographicsIEMap() {
		Map<String, String> demographicsIE = new HashMap<>();
		// start at root directory of the document
		demographicsIE.put("Demographics", null); 
		demographicsIE.put("Age", "age");
		demographicsIE.put("Gender", "gender");
		demographicsIE.put("dateOfBirth", "dateOfBirth");
		// combine the text of these two fields in the document to match the input
		demographicsIE.put("address", "addressLine1, addressLine2"); 
		demographicsIE.put("state", "state");
		demographicsIE.put("city", "city");
		demographicsIE.put("zip", "zip");
		demographicsIE.put("latitude", "lat");
		demographicsIE.put("longitude", "lng");
		containerFieldMap.put(DEMOGRAPHICS_IE, demographicsIE);
	}
	
	private static void initializeCommonTimeIEMap() {
		Map<String, String> commonTimeIE = new HashMap<>();
		commonTimeIE.put("time", "commonTime");
		commonTimeIE.put("forThePast", "commonTime");
		commonTimeIE.put("dateRangeBetween", "commonTime");
		commonTimeIE.put("units", "units");
		containerFieldMap.put(ContainerType.COMMON_TIME_IE, commonTimeIE);
	}
}
