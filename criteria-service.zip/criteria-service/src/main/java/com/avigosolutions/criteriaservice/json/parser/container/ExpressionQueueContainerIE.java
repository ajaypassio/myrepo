package com.avigosolutions.criteriaservice.json.parser.container;

import java.util.LinkedList;
import java.util.Queue;

import com.avigosolutions.criteriaservice.json.parser.expression.Expression;
import com.avigosolutions.criteriaservice.json.parser.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("expressionQueueContainer")
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
public class ExpressionQueueContainerIE extends AbstractContainer {

	@JsonProperty("containerQueue")
	private Queue<Expression> expressionQueue = new LinkedList<>();

	public ExpressionQueueContainerIE(ContainerType cType) {
		super(cType);
		setLogicalOperator(LogicalOperator.AND);
	}

	public boolean offer(Expression expression) {
		return expressionQueue.offer(expression);
	}

	public Expression poll() {
		return expressionQueue.poll();
	}

	public Expression peek() {
		return expressionQueue.peek();
	}
	
	@JsonProperty("containerQueue")
	protected Queue<Expression> getExpressionQueue() {
		return expressionQueue;
	}

	@JsonIgnore
	@Override
	public boolean isEmpty() {
		return expressionQueue.isEmpty();
	}

	@Override
	public int size() {
		return expressionQueue.size();
	}

	@Override
	public String toString() {
		return "ExpressionQueueContainer [logicalOperator=" + getLogicalOperator() + ", containerType="
				+ getContainerType() + ", expressionQueue=" + expressionQueue + "]";
	}

}
