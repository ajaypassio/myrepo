package com.avigosolutions.criteriaservice.json.parser.container;

import java.util.Queue;

import com.avigosolutions.criteriaservice.json.parser.expression.LogicalOperator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("searchCriteriaContainer")
@JsonTypeInfo(include=As.WRAPPER_OBJECT, use=JsonTypeInfo.Id.NAME)
@JsonIgnoreProperties(value = {"containerType"})
public class SearchCriteriaContainerIE extends BaseContainer<EQCLogicalGroupContainerIE> {

	public SearchCriteriaContainerIE(ContainerType cType) {
		super(cType);
		setLogicalOperator(LogicalOperator.OR);
	}
	
	@JsonProperty("sCContainerQueue")
	@Override
	protected Queue<EQCLogicalGroupContainerIE> getContainerQueue() {
		return super.getContainerQueue();
	}
	
	@Override
	public String toString() {
		return "SearchCriteriaContainer [logicalOperator=" + getLogicalOperator() + ", containerType="
				+ getContainerType() + ", containerQueue=" + getContainerQueue() + "]";
	}
}
