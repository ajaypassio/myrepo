package com.avigosolutions.criteriaservice.json.parser.exception;

public class FieldValidationException extends InputValidationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FieldValidationException() {
		// default constructor
	}

	public FieldValidationException(String message) {
		super(message);
	}

	public FieldValidationException(Throwable cause) {
		super(cause);
	}

	public FieldValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
