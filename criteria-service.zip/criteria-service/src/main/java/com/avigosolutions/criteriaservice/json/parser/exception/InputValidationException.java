package com.avigosolutions.criteriaservice.json.parser.exception;

public class InputValidationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputValidationException() {
		// default constructor
	}

	public InputValidationException(String message) {
		super(message);
	}

	public InputValidationException(Throwable cause) {
		super(cause);
	}

	public InputValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
