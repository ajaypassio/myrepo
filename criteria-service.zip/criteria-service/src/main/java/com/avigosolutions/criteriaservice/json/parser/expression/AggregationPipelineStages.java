package com.avigosolutions.criteriaservice.json.parser.expression;

import org.springframework.data.domain.Sort;

public enum AggregationPipelineStages implements Operator {

	COUNT("$count", "count", null), GROUP("$group", "group", String[].class), LIMIT("$limit", "limit", Long.class), 
	MATCH("$match", "match", Object.class), PROJECT("$project", "project", String[].class), 
	SORT("$sort", "sort", Sort.class), UNWIND("$unwind", "unwind", String.class);
	
	private String methodName;
	private String opString;
	private Class<?> argClass;
	
	private AggregationPipelineStages(String methodName, String opString, Class<?> argClass) {
		this.methodName = methodName;
		this.opString = opString;
		this.argClass = argClass;
	}

	public Class<?> getArgClass() {
		return argClass;
	}

	@Override
	public String getMethodName() {
		return methodName;
	}
	
	@Override
	public String getOpString() {
		return opString;
	}
	
	@Override
	public OperatorType getType() {
		return OperatorType.AGGREGATION_PIPELINE;
	}	
	
}
