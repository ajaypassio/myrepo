package com.avigosolutions.criteriaservice.json.parser.expression;

public enum ArrayOperator implements Operator {

	SIZE("$size", "size", Integer.class), EM("$elemMatch", "elemMatch", Object.class);
	
	private String methodName;
	private String opString;
	private Class<?> argClass;
	
	private ArrayOperator(String methodName, String opString, Class<?> argClass) {
		this.methodName = methodName;
		this.opString = opString;
		this.argClass = argClass;
	}
	
	public Class<?> getArgClass() {
		return argClass;
	}

	public String getOpString() {
		return opString;
	}
	
	public String getMethodName() {
		return methodName;
	}
	
	public OperatorType getType() {
		return OperatorType.ARRAY;
	}
}
