package com.avigosolutions.criteriaservice.json.parser.expression;

public enum ComparisonOperator implements Operator {

	GT("$gt", "gt", Object.class), LT("$lt", "lt", Object.class), GTE("$gte", "gte", Object.class),
	LTE("$lte", "lte", Object.class), EQ("$eq", "is", Object.class), NE("$ne", "ne", Object.class), 
	IN("$in", "in", Object[].class), NIN("$nin", "nin", Object[].class), LIKE("$like", "like", Object.class)
	, INC_EP("$inc_ep", "inc_ep", Object.class), EXC_EP("$exc_ep", "exc_ep", Object.class),
	OUTSIDE("$outside", "outside", Object.class), INSIDE("$inside", "inside", Object.class);
	
	private String methodName;
	private String opString;
	private Class<?> argClass;
	
	private ComparisonOperator(String opString, String methodName, Class<?> argClass) {
		this.opString = opString;
		this.methodName = methodName;
		this.argClass = argClass;
	}
	
	public String getOpString() {
		return opString;
	}
	
	public String getMethodName() {
		return methodName;
	}
	
	public OperatorType getType() {
		return OperatorType.COMPARISON;
	}
	
	public Class<?> getArgClass() {
		return argClass;
	}

}
