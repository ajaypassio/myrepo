package com.avigosolutions.criteriaservice.json.parser.expression;

public class NotExpression<T> {

	private Operand<T> operand;
	private LogicalOperator operator = LogicalOperator.NOT;
	
	public NotExpression(Operand<T> operand) {
		this.operand = operand;
	}

	public Operand<T> getOperand() {
		return operand;
	}

	public Operator getOperator() {
		return operator;
	}

	@Override
	public String toString() {
		return "NotExpression [operand=" + operand + ", operator=" + operator + "]";
	}
}
