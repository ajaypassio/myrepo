package com.avigosolutions.criteriaservice.json.parser.expression;

public enum OperatorType {

	COMPARISON, LOGICAL, ARRAY, ELEMENT, AGGREGATION_PIPELINE;
}
