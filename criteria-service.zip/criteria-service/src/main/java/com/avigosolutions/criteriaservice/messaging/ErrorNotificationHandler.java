package com.avigosolutions.criteriaservice.messaging;

import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microsoft.azure.eventprocessorhost.ExceptionReceivedEventArgs;

public class ErrorNotificationHandler implements Consumer<ExceptionReceivedEventArgs>
{
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public void accept(ExceptionReceivedEventArgs t)
	{
		logger.info("EventHub Receiver EPH : Host " + t.getHostname() + " received general error notification during " + t.getAction() + ": " + t.getException().toString());
	}
}
