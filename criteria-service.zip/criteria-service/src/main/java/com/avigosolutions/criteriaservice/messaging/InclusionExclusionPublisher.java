
package com.avigosolutions.criteriaservice.messaging;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.constant.Constants;
import com.avigosolutions.criteriaservice.messaging.models.NotificationPayload;
import com.avigosolutions.criteriaservice.messaging.util.EventHubUtil;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

@Component
public class InclusionExclusionPublisher {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.azure.storage.containername}")
	String containerName;	
	
	@Value("${notification.sprintt.azure.storage.queuename}")
	String notificationQueueName;	

	@Autowired
	EventHubUtil util;

	/**
	 * This method is responsible to publish study site data
	 * 
	 * @param payload
	 * @throws URISyntaxException
	 * @throws InvalidKeyException
	 * @throws StorageException
	 * @throws IOException
	 */

	public boolean publishInclusionExclusionCriteria(String listCriteria, Long trailId) {
		logger.info("Publish Inclusion Exclusion started ");

		try {
			byte[] payloadBytes = listCriteria.getBytes("UTF-8");
			CloudBlobContainer container = getContainer();
			String fileNeme = "T_" + trailId + ".json";
			String pathWithoutContainerPS = new StringBuilder(Constants.IE_INCOMING_FOLDER).append("/").append(fileNeme)
					.toString();
			logger.info("Inclusion Exclusion File Path : {} " + pathWithoutContainerPS);
			CloudBlockBlob blob = container.getBlockBlobReference(pathWithoutContainerPS);
			HashMap<String, String> metaData = new HashMap<String, String>();
			metaData.put("Serializer", "JSON");
			blob.setMetadata(metaData);			
			blob.uploadFromByteArray(payloadBytes, 0, payloadBytes.length);
			return true;
		} catch (URISyntaxException | StorageException | IOException e) {
			logger.error("Error:" + e.getMessage());
			logger.info("Error occurred while adding file in Inclusion Exclusion Conatiner" + e.getMessage());
			return false;
		}
	}

	public boolean fileExistsInBoldContainer(Long trialId) {
		logger.info("in fileExistsInBoldContainer method ");
		try {

			CloudBlobContainer container = getContainer();
			String fileNeme = "T_" + trialId + ".json";
			String pathWithoutContainerPS = new StringBuilder(Constants.IE_INCOMING_FOLDER).append("/").append(fileNeme)
					.toString();
			CloudBlockBlob blob = container.getBlockBlobReference(pathWithoutContainerPS);
			return blob.exists();
		} catch (StorageException | URISyntaxException e) {
			logger.error("Error:" + e.getMessage());
			logger.info("Error occurred while adding file in Inclusion Exclusion Conatiner" + e.getMessage());
			return false;
		}
	}

	public CloudBlobContainer getContainer() {
		logger.info("Inclusion Exclusion get container ");
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		try {
			storageAccount = CloudStorageAccount.parse(util.getDataProcessingStorageConnectionString());
			logger.info("Inclusion Exclusion Criteria Incoming getStorageConnectionString : {} ",
					util.getDataProcessingStorageConnectionString());
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);
			container.createIfNotExists();
			return container;
		} catch (InvalidKeyException | URISyntaxException | StorageException e) {
			logger.error("Error:" + e.getMessage());
			logger.info("Error occurred while setting Inclusion Exclusion Conatiner" + e.getMessage());
			return null;
		}

	}
	
	public boolean publishInclusionCriteriaForPhysicianSearch(String listCriteria, String userName) {
		logger.info("Publish Inclusion started ");
		try {
			byte[] payloadBytes = listCriteria.getBytes("UTF-8");
			CloudBlobContainer container = getContainer();
			String fileNeme =  new StringBuilder(userName.replace('.', '_')).append("_criteria").append(".json").toString();
			String pathWithoutContainerPS = new StringBuilder(Constants.IE_PHYSICIAN_CRITERIA_FOLDER).append("/").append(fileNeme).toString();
			logger.info("Inclusion File Path : {} " + pathWithoutContainerPS);
			CloudBlockBlob blob = container.getBlockBlobReference(pathWithoutContainerPS);
			HashMap<String, String> metaData = new HashMap<String, String>();
			metaData.put("Serializer", "JSON");
			blob.setMetadata(metaData);			
			blob.uploadFromByteArray(payloadBytes, 0, payloadBytes.length);
			return true;
		} catch (URISyntaxException | StorageException | IOException e) {
			logger.error("Error:" + e.getMessage());
			logger.info("Error occurred while adding file in Inclusion Conatiner" + e.getMessage());
			return false;
		}
	}
	
	public void publishNotification(ClinicalTrial clinicalTrial) {
		logger.info("Notification started for the trial name:{} and user: {} ", clinicalTrial.getTrialName(),
				clinicalTrial.getCreatedBy());
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudQueueClient queueClient = null;
		try {
			storageAccount = CloudStorageAccount.parse(util.getNotificationStorageConnectionString());
			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(notificationQueueName);
			queue.createIfNotExists();
			ObjectMapper mapper = new ObjectMapper();
			NotificationPayload notificationPayload = new NotificationPayload();
			notificationPayload.setEventName("Patient List-Start");
			notificationPayload.setId(clinicalTrial.getTrialId());
			notificationPayload.setName(clinicalTrial.getTrialName());
			notificationPayload.setUserid(clinicalTrial.getInitiatedBy());
			queue.addMessage(new CloudQueueMessage(mapper.writeValueAsString(notificationPayload)));
			logger.info("Notification completed for the trial name:{} and user: {} ", clinicalTrial.getTrialName(),
					clinicalTrial.getCreatedBy());
		} catch (URISyntaxException | StorageException | InvalidKeyException | JsonProcessingException exception) {
			logger.error("Notification processing failed : {} ", exception);
		}
	}

}