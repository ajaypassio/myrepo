package com.avigosolutions.criteriaservice.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.avigosolutions.criteriaservice.messaging.models.TrialJobStatusModel;
import com.avigosolutions.criteriaservice.messaging.util.EventHubUtil;
import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
import com.avigosolutions.criteriaservice.util.SpringBeanUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.eventhubs.EventData;
import com.microsoft.azure.eventprocessorhost.CloseReason;
import com.microsoft.azure.eventprocessorhost.IEventProcessor;
import com.microsoft.azure.eventprocessorhost.PartitionContext;

public class JobStatusEventProcessor implements IEventProcessor
{
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	private int checkpointBatchingCount = 0;

	// OnOpen is called when a new event processor instance is created by the host. In a real implementation, this
	// is the place to do initialization so that events can be processed when they arrive, such as opening a database
	// connection.
	@Override
    public void onOpen(PartitionContext context) throws Exception
    {
		logger.info("EventProcessor: Partition " + context.getPartitionId() + " is opening");
    }

    // OnClose is called when an event processor instance is being shut down. The reason argument indicates whether the shut down
    // is because another host has stolen the lease for this partition or due to error or host shutdown. In a real implementation,
    // this is the place to do cleanup for resources that were opened in onOpen.
	@Override
    public void onClose(PartitionContext context, CloseReason reason) throws Exception
    {
		logger.info("EventProcessor: Partition " + context.getPartitionId() + " is closing for reason " + reason.toString());
    }
	
	// onError is called when an error occurs in EventProcessorHost code that is tied to this partition, such as a receiver failure.
	// It is NOT called for exceptions thrown out of onOpen/onClose/onEvents. EventProcessorHost is responsible for recovering from
	// the error, if possible, or shutting the event processor down if not, in which case there will be a call to onClose. The
	// notification provided to onError is primarily informational.
	@Override
	public void onError(PartitionContext context, Throwable error)
	{
		logger.info("EventProcessor: Partition " + context.getPartitionId() + " onError: " + error.toString());
	}

	// onEvents is called when events are received on this partition of the Event Hub. The maximum number of events in a batch
	// can be controlled via EventProcessorOptions. Also, if the "invoke processor after receive timeout" option is set to true,
	// this method will be called with null when a receive timeout occurs.
	@Override	
    public void onEvents(PartitionContext context, Iterable<EventData> events) throws Exception
    {
		EventHubUtil util  = SpringBeanUtil.getBean(EventHubUtil.class);
		logger.info("EventProcessor: Partition " + context.getPartitionId() + " got event batch");
        int eventCount = 0;
        for (EventData data : events)
        {
        	// It is important to have a try-catch around the processing of each event. Throwing out of onEvents deprives
        	// you of the chance to process any remaining events in the batch. 
        	try
        	{
        		String strData = new String(data.getBytes(), "UTF8");
        		logger.info("EventProcessor (" + context.getPartitionId() + "," + data.getSystemProperties().getOffset() + "," +
                		data.getSystemProperties().getSequenceNumber() + "): " + strData);
        		ObjectMapper mapper = new ObjectMapper();
        		TrialJobStatusModel statusObject = mapper.readValue(strData,TrialJobStatusModel.class);
        		util.updateTrial(statusObject);        		
                eventCount++;
                
                this.checkpointBatchingCount++;
                if ((checkpointBatchingCount % util.getCheckpointInterval()) == 0)
                {
                	logger.info("EventProcessor: Partition " + context.getPartitionId() + " checkpointing at " +
               			data.getSystemProperties().getOffset() + "," + data.getSystemProperties().getSequenceNumber());        
                	context.checkpoint(data).whenComplete((result,e)->{
                		if (e != null) {
    						logger.info("Failure while checkpointing: " + e.toString());
    						if (e.getCause() != null) {
    							logger.error("Inner exception: " + e.getCause().toString());
    						}
    					}
                	}).get();
                	}                
        	}
        	catch (Exception e)
        	{
        		logger.info("Processing failed for an event: " + e.toString());
        		e.printStackTrace();
        	}
        }
        logger.info("EventProcessor: Partition " + context.getPartitionId() + " batch size was " + eventCount + " for host " + context.getOwner());
    }
}
