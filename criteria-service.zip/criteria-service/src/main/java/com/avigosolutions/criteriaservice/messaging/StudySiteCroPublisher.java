package com.avigosolutions.criteriaservice.messaging;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.avigosolutions.criteriaservice.messaging.models.CROClinician;
import com.avigosolutions.criteriaservice.messaging.util.EventHubUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueClient;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

@Component
public class StudySiteCroPublisher {

	private Logger logger = LoggerFactory.getLogger(this.getClass());	

	@Value("${sprintt.azure.blob.storage.cro.container.name}")
	String containerName;
	
	@Value("${sprintt.azure.blob.storage.cro.queue.name}")
	String queueName;
		
	@Autowired
	EventHubUtil util;
	/**
	 * This method is responsible to publish study site data
	 * 
	 * @param payload
	 * @throws URISyntaxException
	 * @throws InvalidKeyException
	 * @throws StorageException
	 * @throws IOException
	 */
	public void publishStudySiteClinicianDetails(List<CROClinician> listCro) {
		logger.info("Publish CRO study site started ");
		CloudQueue queue = null;
		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;
		CloudQueueClient queueClient = null;

		try {

			String generatedUuid = UUID.randomUUID().toString();
			storageAccount = CloudStorageAccount.parse(util.getStorageConnectionString());
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerName);
			container.createIfNotExists();

			queueClient = storageAccount.createCloudQueueClient();
			queue = queueClient.getQueueReference(queueName);
			queue.createIfNotExists();

			ObjectMapper obj = new ObjectMapper();
			String payload = obj.writeValueAsString(listCro);
			logger.info("----- Data being send:" + payload);
			byte[] payloadBytes = payload.getBytes("UTF-8");

			String pathWithoutContainerPS = queueName + "/" + generatedUuid + ".json";
			CloudBlockBlob blob = container.getBlockBlobReference(pathWithoutContainerPS);
			logger.info("Queue Path without containers for  : {} " + pathWithoutContainerPS);

			HashMap<String, String> metaData = new HashMap<String, String>();
			metaData.put("TargetName", queueName);
			metaData.put("Serializer", "JSON");
			blob.setMetadata(metaData);
			logger.info("Queue MetaData  " + queueName + "     " + metaData.toString());
			blob.uploadFromByteArray(payloadBytes, 0, payloadBytes.length);
			queue.addMessage(new CloudQueueMessage(pathWithoutContainerPS));
			
		} catch ( InvalidKeyException | URISyntaxException | StorageException | IOException e) {
			logger.error("Error:" + e.getStackTrace());
			logger.info("Error occurred while adding file and message in queue" + e.getMessage());
		} 		
	}
}
