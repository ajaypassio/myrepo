package com.avigosolutions.criteriaservice.messaging;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.microsoft.azure.eventhubs.EventHubException;
import com.microsoft.azure.eventprocessorhost.EventProcessorHost;
import com.microsoft.azure.eventprocessorhost.EventProcessorOptions;

import com.avigosolutions.criteriaservice.messaging.util.EventHubUtil;

@Component
public class TrialCollectionStatusBean {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EventHubUtil util;
	

	@Value("${sprintt.azure.eventhub.consumer-groups}")
	private String consumerGroup;

	@Value("${sprintt.azure.eventhub.storage.containername}")
	private String storageContainerName;

	@Value("${sprintt.azure.eventhub.host.prefix}")
	private String hostNamePrefix;
	
	//sprintt.azure.eventhub.name
	@Value("${sprintt.azure.eventhub.jobstatus.queue.name}")
	private String eventHubName;

	@PostConstruct
	public void init() {
		getJobStatus();
	}

	public EventProcessorHost getEPHInstance() throws EventHubException, IOException {
		EventProcessorHost host = new EventProcessorHost(EventProcessorHost.createHostName(hostNamePrefix),
				eventHubName, consumerGroup, util.getConnectionStringForJobStatus(), util.getStorageConnectionString(), storageContainerName);
		return host;
	}

	public void getJobStatus() {

		EventProcessorHost eph = null;
		try {
			eph = getEPHInstance();
			EventProcessorOptions options = new EventProcessorOptions();
			options.setExceptionNotification(new ErrorNotificationHandler());

			logger.info("Starting Event processor ==>");
			
			eph.registerEventProcessor(JobStatusEventProcessor.class, options).get();

		} catch (EventHubException | IOException | InterruptedException | ExecutionException e) {
			logger.error("Error:" + e.getStackTrace());
			logger.info("Error occurred while connecting to eventhub" + e.getLocalizedMessage());
			eph.unregisterEventProcessor();
		}finally {
			
		}
	}
}
