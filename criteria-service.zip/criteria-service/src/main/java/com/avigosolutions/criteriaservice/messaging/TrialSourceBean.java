package com.avigosolutions.criteriaservice.messaging;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.messaging.models.TrialChangeModel;
import com.avigosolutions.criteriaservice.messaging.util.EventHubUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.eventhubs.EventData;
import com.microsoft.azure.eventhubs.EventHubClient;
import com.microsoft.azure.eventhubs.EventHubException;

@Component
public class TrialSourceBean {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EventHubUtil util;


	public void sendTrialChange(String action, Long trialId, String trialJson, String correlationId) {

		logger.info("----- Sending  {} Event for TrialID: {}", action, trialId);
		
		final ExecutorService executorService = Executors.newSingleThreadExecutor();
		EventHubClient ehClient = null;

		trialJson = trialJson.replaceAll("\\\\", "");
		TrialChangeModel trialChangeModel = new TrialChangeModel(TrialChangeModel.class.getTypeName(), action, trialId,
				trialJson, correlationId);

		try {
			ehClient = EventHubClient.createSync(util.getConnectionStringForJobQueue(), executorService);//getConnectionString
			ObjectMapper obj = new ObjectMapper();
			//JSONObject json = new JSONObject(trialChangeModel);
			String payload = obj.writeValueAsString(trialChangeModel);
			logger.info("----- Data being send:"+payload);
			byte[] payloadBytes = payload.getBytes("UTF-8");
			EventData sendEvent = EventData.create(payloadBytes);
			//ehClient.createPartitionSenderSync(partitionId)
				//.send(sendEvent).whenComplete((unused, e) -> {			
				ehClient.send(sendEvent).whenComplete((unused, e) -> {
					if (e != null) {
						logger.info("Failure while sending event: " + e.toString());
						if (e.getCause() != null) {
							logger.info("Inner exception: " + e.getCause().toString());
						}
					}
				 }).get();
			
		} catch (EventHubException | IOException | InterruptedException | ExecutionException e) {
			logger.error("Error:" + e.getStackTrace());
			logger.info("Error occurred while connecting to eventhub" + e.getLocalizedMessage());
		} finally {
			try {
				if (null != ehClient) {
					ehClient.closeSync();
				}
			} catch (Exception e) {
				logger.error("Error:" + e.getStackTrace());
				logger.info("Error occurred while closing the eventhub connection" + e.getLocalizedMessage());
			}
			if (null != executorService)
				executorService.shutdown();
		}
	}	
}
