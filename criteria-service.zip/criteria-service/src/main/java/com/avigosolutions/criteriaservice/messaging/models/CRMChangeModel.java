package com.avigosolutions.criteriaservice.messaging.models;

import java.io.Serializable;
import java.util.UUID;

import com.avigosolutions.criteriaservice.dto.CRMCategory;

public class CRMChangeModel implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private CRMCategory crmCategory;
	private String correlationId;
	private String substituteName;
	private String substituteValue;
	
	public CRMChangeModel() {
		super();
	}
	
	public CRMChangeModel(CRMCategory crmCat) {
		super();
		this.crmCategory = crmCat;
	}
	
	public CRMChangeModel(String name, String value) {
		super();
		this.substituteName = name;
		this.substituteValue = value;
	}
	
	public String getCorrelationId() {
		return correlationId;
	}
	
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	
	public CRMCategory getCrmCategory() {
		return crmCategory;
	}

	public void setCrmCategory(CRMCategory crmCategory) {
		this.crmCategory = crmCategory;
	}
	
	public String getSubstituteName() {
		return substituteName;
	}

	public void setSubstituteName(String substituteName) {
		this.substituteName = substituteName;
	}

	public String getSubstituteValue() {
		return substituteValue;
	}

	public void setSubstituteValue(String substituteValue) {
		this.substituteValue = substituteValue;
	}

}
