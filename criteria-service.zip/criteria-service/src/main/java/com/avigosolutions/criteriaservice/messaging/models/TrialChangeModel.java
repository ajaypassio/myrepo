package com.avigosolutions.criteriaservice.messaging.models;

public class TrialChangeModel {
	private String type;
	private String action;
	private Long trialId;
	private String trialJson;
	private String correlationId;
	
	
	public TrialChangeModel(String type, String action, Long trialId, String trialJson, String correlationId) {
		super();
		this.type = type;
		this.action = action;
		this.trialId = trialId;
		this.trialJson = trialJson;
		this.correlationId = correlationId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public Long getTrialId() {
		return trialId;
	}
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	public String getTrialJson() {
		return trialJson;
	}
	public void setTrialJson(String trialJson) {
		this.trialJson = trialJson;
	}
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	

}
