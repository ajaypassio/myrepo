package com.avigosolutions.criteriaservice.messaging.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TrialJobStatusModel {

	private String type;
	private String status;
	private String correlationId;
	private Object info;
	private String attempt;
	private String trialId;
	
	
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}
	/**
	 * @param correlationId the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	/**
	 * @return the info
	 */
	public Object getInfo() {
		return info;
	}
	/**
	 * @param info the info to set
	 */
	public void setInfo(Object info) {
		this.info = info;
	}
	
	public String getAttempt() {
		return attempt;
	}
	public void setAttempt(String attempt) {
		this.attempt = attempt;
	}
	
	public String getTrialId() {
		return trialId;
	}
	public void setTrialId(String trialId) {
		this.trialId = trialId;
	}
	
	
	
}
