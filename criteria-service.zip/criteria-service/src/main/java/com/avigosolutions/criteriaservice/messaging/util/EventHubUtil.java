package com.avigosolutions.criteriaservice.messaging.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.messaging.models.TrialJobStatusModel;
import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
import com.microsoft.azure.eventhubs.ConnectionStringBuilder;

@Component
public class EventHubUtil {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	ClinicalTrialService clinicalTrialService;
	
	
	@Value("${sprintt.azure.eventhub.namespace}")
	private String namespaceName;
	
	@Value("${sprintt.azure.eventhub.jobstatus.queue.name}")
	private String eventHubNameForStatus;
		
	@Value("${sprintt.azure.eventhub.jobstatus.sharedaccess.keyname}")
	private String statusKeyName;
	
	@Value("${sprintt.azure.eventhub.jobstatus.sharedaccess.keyvalue}")
	private String statusKeyValue;
	
	@Value("${sprintt.azure.eventhub.jobqueue.queue.name}")
	private String eventHubNameForJob;
		
	@Value("${sprintt.azure.eventhub.jobqueue.sharedaccess.keyname}")
	private String jobKeyName;
	
	@Value("${sprintt.azure.eventhub.jobqueue.sharedaccess.keyvalue}")
	private String jobKeyValue;
	
	@Value("${sprintt.azure.eventhub.storage.connection.accountname}")
	private String azureAccountName;
	
	@Value("${sprintt.azure.eventhub.storage.connection.accountkey}")
	private String azureAccountKey;
	
	@Value("${sprintt.azure.eventhub.checkpoint.interval}")
	private Integer checkpointInterval;
	
	@Value("${sprintt.azure.storage.connection.accountname}")
	private String azureDataProcessingAccountName;
		
	@Value("${sprintt.azure.storage.connection.accountkey}")
	private String azureDataProcessingAccountKey; 
	 
	@Value("${notification.sprintt.azure.storage.connection.accountname}")
	private String notificationAccountName;
	
	@Value("${notification.sprintt.azure.storage.connection.accountkey}")
	private String notificationAccountKey;
	
	public Integer getCheckpointInterval() {
		return this.checkpointInterval;
	}
	
	
	public String   getDataProcessingStorageConnectionString() {
		String storageConnectionString = "DefaultEndpointsProtocol=https;"
				+ "AccountName="+azureDataProcessingAccountName
				+ ";AccountKey="+azureDataProcessingAccountKey+";"
				+ "EndpointSuffix=core.windows.net";
		
		return storageConnectionString;
	} 
		
	public String getConnectionStringForJobStatus() {
		ConnectionStringBuilder eventHubConnectionString = new ConnectionStringBuilder()
    			.setNamespaceName(namespaceName)
    			.setEventHubName(eventHubNameForStatus)
    			.setSasKeyName(statusKeyName)
    			.setSasKey(statusKeyValue);
		
		return eventHubConnectionString.toString();
	}
	
	public String getConnectionStringForJobQueue() {
		ConnectionStringBuilder eventHubConnectionString = new ConnectionStringBuilder()
    			.setNamespaceName(namespaceName)
    			.setEventHubName(eventHubNameForJob)
    			.setSasKeyName(jobKeyName)
    			.setSasKey(jobKeyValue);
		
		return eventHubConnectionString.toString();
	}
	
	public String getStorageConnectionString() {
		String storageConnectionString = "DefaultEndpointsProtocol=https;"
				+ "AccountName="+azureAccountName
				+ ";AccountKey="+azureAccountKey+";"
				+ "EndpointSuffix=core.windows.net";
		
		return storageConnectionString;
	}
	public String getNotificationStorageConnectionString() {
		return "DefaultEndpointsProtocol=https;"
				+ "AccountName="+notificationAccountName
				+ ";AccountKey="+notificationAccountKey+";"
				+ "EndpointSuffix=core.windows.net";
		
	}
	
	public void updateTrial(TrialJobStatusModel statusObject) {
		/*
		 * try { clinicalTrialService =
		 * SpringBeanUtil.getBean(ClinicalTrialServiceImpl.class);
		 * clinicalTrialService.updateTrialCollectionStatus(statusObject);
		 * }catch(Exception e) {
		 * logger.info("Unable to update the job status details in criteria-service ");
		 * e.printStackTrace(); }
		 */
		
	}

}
