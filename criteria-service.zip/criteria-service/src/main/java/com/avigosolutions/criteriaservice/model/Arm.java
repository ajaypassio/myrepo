package com.avigosolutions.criteriaservice.model;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name="Arm")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Arm  extends Auditable<Long>  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4108589404555827724L;
	
	
	@Id
	@GeneratedValue
	@Column(name = "ArmId", nullable = false)
	private Long id;

	public Long getArmId() {
		return this.id;
	}

	public Arm withArmId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "ArmName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public Arm withName(String name) {
		this.name = name;
		return this;
	}

	@Override
	public String toString() {
		return "Arm [id=" + id + ", name=" + name + "]";
	}
	
	
}
