package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name = "City")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class City extends Auditable<Long> implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 970607895211696042L;

	@Id
	@GeneratedValue
	@Column(name = "CityId", nullable = false)
	private Long id;

	@Column(name = "CityName")
	private String cityName;

	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "StateId", insertable = false, updatable = false)
	private State state;

	public Long getId() {
		return id;
	}

	public City withId(Long id) {
		this.id = id;
		return this;
	}

	public String getCityName() {
		return cityName;
		
	}

	public City withCityName(String cityName) {
		this.cityName = cityName;
		return this;
	}

	public State getState() {
		return state;
	}

	public City withState(State state) {
		this.state = state;
		return this;
	}

}
