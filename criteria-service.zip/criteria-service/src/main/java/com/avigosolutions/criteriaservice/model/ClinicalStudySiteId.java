package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Embeddable
public class ClinicalStudySiteId implements Serializable {

	@Column(name = "TrialId")
	private Long id;

	@Column(name = "StudySiteId")
	private Long studySiteId;

	@Transient
	@ManyToOne
	@JoinColumn(name = "ClinicalTrialId")
	private ClinicalTrial clinicalTrial;

	@Transient
	@ManyToOne
	@JoinColumn(name = "StudySiteId")
	private StudySite studySite;

	public ClinicalTrial getClinicalTrial() {
		return clinicalTrial;
	}

	public void setClinicalTrial(ClinicalTrial clinicalTrial) {
		this.clinicalTrial = clinicalTrial;
	}

	public StudySite getStudySite() {
		return studySite;
	}

	public void setStudySite(StudySite studySite) {
		this.studySite = studySite;
	}

	public ClinicalStudySiteId() {
	}

	public ClinicalStudySiteId(Long id, Long studySiteId) {
		this.id = id;
		this.studySiteId = studySiteId;
	}

	public Long getId() {
		return id;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof ClinicalStudySiteId))
			return false;
		ClinicalStudySiteId that = (ClinicalStudySiteId) o;
		return Objects.equals(getId(), that.getId()) && Objects.equals(getStudySiteId(), that.getStudySiteId());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getId(), getStudySiteId());
	}

	public ClinicalStudySiteId withId(Long id) {
		this.id = id;
		return this;
	}

	public ClinicalStudySiteId withStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

}
