package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.avigosolutions.criteriaservice.dto.StudySiteLightWeightDTO;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

@Entity
@Table(name = "ClinicalTrial")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class ClinicalTrial extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 8237095501517057348L;

	
	public ClinicalTrial() {
		//cinicalTrialStudySites = new HashSet<>();
	}

	
	@Id
	@GeneratedValue
	@Column(name = "TrialId", nullable = false)
	private Long id;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.MERGE, mappedBy = "clinicalTrial", orphanRemoval = true)
	private List<Criteria> criterias;

	@Column(name = "TrialName",columnDefinition="nvarchar")
	private String trialName;
	


	@Column(name = "TrialStartDate")
	private Date trialStartDate;

	@Column(name = "TrialEndDate")
	private Date trialEndDate;

	@Column(name = "TrialConditionId", nullable = true)
	private Long trialConditionId;

	@Column(name = "NctNumber", nullable = true)
	private String nctNumber;
	
	@Column(name = "Interventions", nullable = true)
	private String interventions;


	@Column(name = "TrialStatusId", nullable = true)
	private Integer trialStatusId;
	
	@Column(name = "TrialJson", nullable = true,columnDefinition="text")
	private String trialJson;
	
	@Column(name = "trialLandingURL", nullable = true)
	private String trialLandingURL;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "TrialStatusId", insertable = false, updatable = false)
	//@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private TrialStatus trialStatus;

	@Column(name = "ProgramId", nullable=true)
	private Long programId;
	
	@Transient
    @OneToOne
    @JoinColumn(name = "ProgramId", insertable = false, updatable = false)    
    private Program program;
        
    @Column(name = "ArmId", nullable = true)
    private Long armId;
    
    @Column(name = "StageId", nullable = true)
    private Long stageId;
    
    @Transient
    @OneToOne
    @JoinColumn(name = "TrialConditionId", insertable = false, updatable = false)    
    private TrialCondition trialCondition;
    
    @Transient
    @OneToOne
    @JoinColumn(name = "ArmId", insertable = false, updatable = false)    
    //@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
    private Arm arm;
    
    
    
    @Transient
    @OneToOne
    @JoinColumn(name = "TherapeuticAreaId", insertable = false, updatable = false)    
   // @JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
    private TherapeuticArea therapeuticArea;
    
    @Transient
    @OneToOne
    @JoinColumn(name = "StageId", insertable = false, updatable = false)    
    //@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
    private Stage stage;
    
    @Column(name = "StudySite")
	private String studySite;   
    
    @Transient
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "SponsorId", insertable = false, updatable = false) 
	private Sponsor sponsor;
	
	@Column(name = "SponsorId", nullable = true)
	private Long sponsorId;
	
	//@Transient
    @ManyToMany(fetch = FetchType.EAGER,cascade = {
            CascadeType.MERGE
        })
    @JoinTable(
            name = "ClinicalTrial_Collaborator", 
            joinColumns = { @JoinColumn(name = "TrialId") }, 
            inverseJoinColumns = { @JoinColumn(name = "CollaboratorId") }
        )
    private Set<Collaborator> collaborators;
    
    @Column(name="TrialCollectionReady" , nullable = true)
    private Integer collectionReady=0;
    
    @Column(name = "RadiusOverride")
	private boolean radiusOverride=false;
    
    @Transient
    private boolean studySiteChanged =false;
    
    @Transient
    private Long sitesChangedNumber;
    
    @Transient
    private List<StudySiteLightWeightDTO> studySitesList;

	@Transient
    private Set<String> projectList ;
	
	@Column(name = "ProtocolStudyName",columnDefinition="nvarchar",nullable = true)
	private String protocolStudyName;
	
	@Transient
	@JsonProperty("isPatientListGeneration")
    private boolean isPatientListGeneration=false;
	
	@Transient
	private boolean isPatientListInProgress;
	
	@Column(name="PatientHeadline" , nullable = true)
	private String patientHeadline;
    
	@Column(name="MessageToPatient" , nullable = true)
	private String msgToPatient;
	
	@Column(name="InitiatedBy" , nullable = true)
	private String initiatedBy ;
	
    public ClinicalTrial withProtocolStudyName(String protocolStudyName) {
    	this.protocolStudyName=protocolStudyName;
    	return this;
    }
	
    public String getProtocolStudyName() {
		return protocolStudyName;
	}

	public void setProtocolStudyName(String protocolStudyName) {
		this.protocolStudyName = protocolStudyName;
	}

	public Set<String> getProjectList() {  
		return projectList;
	}

	public void setProjectList(Set<String> projectList) {
		this.projectList = projectList;
	}
    
    public int getCollectionReady() {
    	return collectionReady;
    }
    
    public ClinicalTrial withCollectionReady(int collectionReady) {
    	this.collectionReady = collectionReady;
    	return this;
    }
    
    public String getStudySite() {
		return studySite;
	}

	public ClinicalTrial withStudySite(String studySite) {
		this.studySite = studySite;
		return this;
	}

	public TherapeuticArea getTherapeuticArea() {
    	return this.therapeuticArea;
    }
    
    public ClinicalTrial withTherapeuticArea(TherapeuticArea therapeuticArea) {
    	this.therapeuticArea=therapeuticArea;
    	return this;
    }
        
    public Stage getStage() {
    	return this.stage;
    }
    
    public ClinicalTrial withStage(Stage stage) {
    	this.stage=stage;
    	return this;
    }
    
    public Arm getArm() {
    	return this.arm;
    }
    
    public ClinicalTrial withArm(Arm arm) {
    	this.arm=arm;
    	return this;
    }
    	
	@Column(name = "TherapeuticAreaId", nullable = true)
	private Long therapeuticAreaId;
	
	public Long getTherapeuticAreaId()
	{
		return this.therapeuticAreaId;
	}
	
	public ClinicalTrial withTherapeuticAreaId(Long therapeuticAreaId) {
		this.therapeuticAreaId=therapeuticAreaId;
		return this;
	}

	public Integer getTrialStatusId() {
		return this.trialStatusId;
	}

	public Long getTrialConditionId() {
		return this.trialConditionId;
	}

	public ClinicalTrial withTrialConditionId(Long conditionId) {
		this.trialConditionId = conditionId;
		return this;
	}
	
	public TrialCondition getTrialCondition() {
		return this.trialCondition;
	}
	
	public ClinicalTrial withTrialCondition(TrialCondition condition) {
		this.trialCondition = condition;
		return this;
	}

	public String getNctNumber() {
		return this.nctNumber;
	}

	public ClinicalTrial withNctNumber(String nctNumber) {
		this.nctNumber = nctNumber;
		return this;
	}

	public String getInterventions() {
		return this.interventions;
	}

	public ClinicalTrial withInterventions(String interventions) {
		this.interventions = interventions;
		return this;
	}

	public TrialStatus getTrialStatus() {
		return this.trialStatus;
	}

	public ClinicalTrial withTrialStatus(TrialStatus trialStatus) {
		this.trialStatus = trialStatus;
		return this;
	}

	

	public ClinicalTrial withTrialStatusId(Integer trialStatusId) {
		this.trialStatusId = trialStatusId;
		return this;
	}

	// See: https://avaldes.com/json-tutorial-jackson-annotations-part-2/
	// We need to have @JsonGetter and @JsonListter below otherwise we have to
	// follow
	// Java conventions
	// property name = id, Getter = getId() and Listter = ListId()
	// Since we have property name = id (not trialId), getTrialId() and
	// ListTrialId()
	// we need annotation for both get and List
	// Alternative is to hack with getId() in addition to getTrialId()
	@JsonGetter("id")
	public Long getTrialId() {
		return id;
	}

	// public Long getId() {
	// return id;
	// }

	public String getTrialName() {
		return trialName;
	}
	


	public List<Criteria> getCriterias() {
		return criterias;
	}

	public Date getTrialStartDate() {
		return this.trialStartDate;
	}

	public Date getTrialEndDate() {
		return this.trialEndDate;
	}

	@JsonSetter("id")
	public ClinicalTrial withTrialId(Long id) {
		this.id = id;
		return this;
	}

	public ClinicalTrial withTrialName(String name) {
		this.trialName = name;
		return this;
	}


	
	public ClinicalTrial withTrialStartDate(Date startDate) {
		this.trialStartDate = startDate;
		return this;
	}

	public ClinicalTrial withTrialEndDate(Date endDate) {
		this.trialEndDate = endDate;
		return this;
	}

	public ClinicalTrial withCriterias(List<Criteria> criterias) {
		this.criterias = criterias;
		return this;
	}

	@Override
	public String toString() {
		return "ClinicalTrial [id=" + id + ", criterias=" + criterias + ", trialName=" + trialName + ", trialStartDate="
				+ trialStartDate + ", trialEndDate=" + trialEndDate + ", nctNumber=" + nctNumber 
				+ ", interventions=" + interventions  + ", trialStatus="
				+ trialStatus +  ", createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", updatedBy=" + updatedBy + ", updatedAt=" + updatedOn + ", trialJson=" + trialJson + "]";
	}

	public String getTrialJson() {
		return trialJson;
	}

	public ClinicalTrial withTrialJson(String trialJson) {
		this.trialJson = trialJson;
		return this;
	}

	public Long getArmId() {
		return armId;
	}

	public ClinicalTrial withArmId(Long armId) {
		this.armId = armId;
		return this;
	}

	public Long getStageId() {
		return stageId;
	}

	public ClinicalTrial withStageId(Long stageId) {
		this.stageId = stageId;
		return this;
	}
	
	public Long getProgramId() {
		return programId;
	}

	public ClinicalTrial withProgramId(Long programId) {
		this.programId = programId;
		return this;
	}

	public Program getProgram() {
		return program;
	}

	public ClinicalTrial withProgram(Program program) {
		this.program = program;
		return this;
	}
	
	public String getTrialLandingURL() {
		return trialLandingURL;
	}

	public ClinicalTrial withTrialLandingURL(String trialLandingURL) {
		this.trialLandingURL = trialLandingURL;
		return this;
	}
	
	public Set<Collaborator> getCollaborators() {
		return collaborators;
	}

	public ClinicalTrial withCollaborators(Set<Collaborator> collaborators) {
		this.collaborators = collaborators;
		return this;
	}
	
	public Long getSponsorId() {
		return this.sponsorId;
	}
	
	public ClinicalTrial withSponsorId(Long sponsorId) {
		this.sponsorId = sponsorId;
		return this;
	}
	
	public Sponsor getSponsor() {
		return this.sponsor;
	}

	public ClinicalTrial withSponsor(Sponsor sponsor) {
		this.sponsor = sponsor;
		this.sponsorId = this.sponsor.getSponsorId();
		return this;
	}
    
    public boolean getRadiusOverride() {
		return radiusOverride;
	}

	public ClinicalTrial withRadiusOverride(boolean radiusOverride) {
		this.radiusOverride = radiusOverride;
		return this;
	}
	
	public boolean getStudySiteChanged() {
		return studySiteChanged;
	}

	public ClinicalTrial withStudySiteChanged(boolean studySiteChanged) {
		this.studySiteChanged = studySiteChanged;
		return this;
	}
	
	public Long getSitesChangedNumber() {
		return this.sitesChangedNumber;
	}
	
	public ClinicalTrial withSitesChangedNumber(Long sitesChangedNumber) {
		this.sitesChangedNumber = sitesChangedNumber;
		return this;
	}
	
	public ClinicalTrial withStudySitesList(List<StudySiteLightWeightDTO> studySitesList) {
		this.studySitesList = studySitesList;
		return this;
	}
	
	public List<StudySiteLightWeightDTO> getStudySitesList() {
		return studySitesList;
	}

	public boolean isPatientListGeneration() {
		return isPatientListGeneration;
	}

	public void setPatientListGeneration(boolean isPatientListGeneration) {
		this.isPatientListGeneration = isPatientListGeneration;
	}

	public boolean isPatientListInProgress() {
		return isPatientListInProgress;
	}

	public void setPatientListInProgress(boolean isPatientListInProgress) {
		this.isPatientListInProgress = isPatientListInProgress;
	}

	public String getPatientHeadline() {
		return patientHeadline;
	}

	public void setPatientHeadline(String patientHeadline) {
		this.patientHeadline = patientHeadline;
	}

	public String getMsgToPatient() {
		return msgToPatient;
	}

	public void setMsgToPatient(String msgToPatient) {
		this.msgToPatient = msgToPatient;
	}	

	public ClinicalTrial withInitiatedBy(String initiatedBy) {
		this.initiatedBy = initiatedBy;
		return this;
	}

	public String getInitiatedBy() {
		return initiatedBy;
	}
}
