package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name = "ClinicalTrialStudySite")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class ClinicalTrialStudySite extends Auditable<Long> implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ClinicalStudySiteId clinicalStudySiteId; 

	public ClinicalStudySiteId getId() {
		return  clinicalStudySiteId;
	}
	
	public ClinicalTrialStudySite() {
		
	}
	
	public ClinicalTrialStudySite(ClinicalStudySiteId clinicalStudySiteId) {
		this.clinicalStudySiteId = clinicalStudySiteId;
	}
	
	public ClinicalTrialStudySite(Long TrialId,Long studySiteId) {
		this.clinicalStudySiteId=new ClinicalStudySiteId(TrialId,studySiteId);
		
	}
	
	public ClinicalTrialStudySite(Long TrialId,Long studySiteId,boolean isActive,Integer radiusValue,boolean radiusExempt,boolean radiusChanged) {
		this.clinicalStudySiteId=new ClinicalStudySiteId(TrialId,studySiteId);
		this.isActive=isActive;
		this.radiusValue=radiusValue;
		this.radiusExempt=radiusExempt;
		this.radiusChanged=radiusChanged;
	}
	@Column(name = "IsActive", nullable = true)
	private Boolean isActive;
	
	@Column(name = "RadiusValue", nullable = true)
	private Integer radiusValue;
	
	@Column(name = "RadiusExempt")
	private Boolean radiusExempt=false;
	
	@Column(name = "RadiusChanged")
	private Boolean radiusChanged = false;
	
	public Boolean getIsActive() {
		return isActive;
	}

	public ClinicalTrialStudySite setIsActive(Boolean isActive) {
		this.isActive = isActive;
		return this;
	}
	
	public Integer getRadiusValue() {
		return radiusValue;
	}

	public ClinicalTrialStudySite withRadiusValue(Integer radiusValue) {
		this.radiusValue = radiusValue;
		return this;
	}

	public Boolean getRadiusExempt() {
		return radiusExempt;
	}

	public ClinicalTrialStudySite withRadiusExempt(Boolean radiusExempt) {
		this.radiusExempt = radiusExempt;
		return this;
	}
	
	public Boolean getRadiusChanged() {
		return radiusChanged;
	}

	public ClinicalTrialStudySite withRadiusChanged(Boolean radiusChanged) {
		this.radiusChanged = radiusChanged;
		return this;
	}
	
}


