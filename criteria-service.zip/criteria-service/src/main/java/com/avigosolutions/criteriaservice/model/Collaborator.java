package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "Collaborator")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Collaborator extends Auditable<Long> implements Serializable {
	private static final long serialVersionUID = 7237095501517057347L;

	@Id
	@GeneratedValue
	@Column(name = "CollaboratorId", nullable = false)
	private Long id;

	@JsonProperty("collaboratorId")
	public Collaborator withCollaboratorId(Long id) {
		this.id = id;
		return this;
	}

	@JsonProperty("id")
	public Long getId() {
		return id;
	}

	@Column(name = "collaboratorName", nullable = false)
	private String name;

	@Column(name = "CollaboratorType", nullable = true)
	private Long collaboratorTypeId;

	@ManyToOne(fetch = FetchType.EAGER,cascade = {
            CascadeType.ALL
        })
	@JoinColumn(name = "CollaboratorType", insertable = false, updatable = false)
	/*@JsonIgnore*/
	private CollaboratorType collaboratorType;

	
	public CollaboratorType getCollaboratorType() {
		return collaboratorType;
	}

	public String getName() {
		return name;
	}
	
	public long getCollaboratorTypeId() {
		return collaboratorTypeId;
	}

	public Collaborator withName(String collaboratorName) {
		this.name = collaboratorName;
		return this;
	}
	
	public Collaborator withCollaboratorType(CollaboratorType collaboratorType) {
		this.collaboratorType = collaboratorType;
		this.collaboratorTypeId = this.collaboratorType.getCollaboratorTypeId();
		return this;
	}
	
	public Collaborator withCollaboratorTypeId(long collaboratorTypeId) {
		this.collaboratorTypeId = collaboratorTypeId;
		return this;
	}

	@Override
	public String toString() {
		return "Collaborator [id=" + id + ", collaboratorName=" + name + ", collaboratorTypeId="
				+ collaboratorTypeId + "]";
	}
}
