package com.avigosolutions.criteriaservice.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.avigosolutions.criteriaservice.audit.Auditable;

@Entity
@Table(name="CollaboratorType")
public class CollaboratorType extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "CollaboratorTypeId", nullable = false)
	private long id;

	public long getCollaboratorTypeId() {
		return this.id;
	}

	public CollaboratorType withCollaboratorTypeId(int id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "CollaboratorTypeName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public CollaboratorType withName(String name) {
		this.name = name;
		return this;
	}

	@Override
	public String toString() {
		return "CollaboratorType [id=" + id + ", name=" + name + "]";
	}

}
