package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name = "Coordinator")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Coordinator extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "CoordinatorId", nullable = false)
	private long id;

	public long getCoordinatorId() {
		return this.id;
	}

	public Coordinator withCoordinatorId(long id) {
		this.id = id;
		return this;
	}

	public Coordinator() {

	}

	public Coordinator(String name) {
		this.name = name;
	}
	

	@Column(name = "CoordinatorName", nullable = false)
	private String name;

	public String getName() {
		return this.name;
	}

	public Coordinator withName(String name) {
		this.name = name;
		return this;
	}

	@Column(name = "Address1", nullable = false)
	private String address1;

	public String getAddress1() {
		return this.address1;
	}

	public Coordinator withAddress1(String address1) {
		this.address1 = address1;
		return this;
	}

	@Column(name = "Address2", nullable = false)
	private String address2;

	public String getAddress2() {
		return this.address2;
	}

	public Coordinator withAddress2(String address2) {
		this.address2 = address2;
		return this;
	}

	@Column(name = "EmailAddress", nullable = false)
	private String emailAddress;

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public Coordinator withEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
		return this;
	}

	@Column(name = "PhoneNumber", nullable = false)
	private String phoneNumber;

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public Coordinator withPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "coordinator", orphanRemoval = true)
	private Set<StudySiteCoordinator> studySiteCoordinators;

	
	public Set<StudySiteCoordinator> getStudySiteCoordinators() {
		return studySiteCoordinators;
	}

	public void setStudySiteCoordinators(Set<StudySiteCoordinator> studySiteCoordinator) {
		this.studySiteCoordinators = studySiteCoordinator;
	}

	@Override
	public String toString() {
		return "Coordinator [id=" + id + ", name=" + name + ", address1=" + address1 + ", address2=" + address2
				+ ", emailAddress=" + emailAddress + ", phoneNumber=" + phoneNumber + ", studySiteCoordinators="
				//+ studySiteCoordinators 
				+ "]";
	}
	
}
