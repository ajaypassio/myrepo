package com.avigosolutions.criteriaservice.model;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name="Country")
@EntityListeners({AuditingEntityListener.class , EntityListener.class})
public class Country extends Auditable<Long> implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "CountryId", nullable = false)
    private Long countryId;

	@Column(name = "CountryName")
	private String countryName;

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	@Override
	public String toString() {	  
	   return "State [countryId=" + countryId + ", countryName =" + countryName + "]";
	 }

}