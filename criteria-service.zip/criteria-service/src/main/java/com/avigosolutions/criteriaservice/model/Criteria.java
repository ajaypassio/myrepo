package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import javax.persistence.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRawValue;

@Entity
@Table(name = "Criteria")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Criteria extends Auditable<Long> implements Serializable {
	private static final long serialVersionUID = 7237095501517057347L;

	@Id
	@GeneratedValue
	@Column(name = "CriteriaId", nullable = false)
	private Long id;

	@JsonProperty("criteriaId")
	public void setCriteriaId(Long id) {
		this.id = id;
	}

	@JsonProperty("id")
	public Long getId() {
		return id;
	}	

	@Override
	public String toString() {
		return "Criteria [id=" + id + ", trialId=" + trialId + ", templateId=" + templateId +  ", criteriaTemplate=" + criteriaTemplate + ", criteriaName=" + criteriaName
				+ ", criteriaDescription=" + criteriaDescription + ", overAllOperator=" + overAllOperator
				+ ", qualifier=" + qualifier + ", isDeleted=" + isDeleted + ", isInclude=" + isInclude
				+ ", inclusionCriteria=" + inclusionCriteria + ", exclusionCriteria=" + exclusionCriteria + "]";
	}

	@Column(name = "TrialId", nullable = true)
	private Long trialId;

	@Column(name = "TemplateId", nullable = true)
	private Long templateId;

	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "TrialId", insertable = false, updatable = false)
	@JsonIgnore
	private ClinicalTrial clinicalTrial;

	@ManyToOne(fetch = FetchType.EAGER, optional = true)
	@JoinColumn(name = "TemplateId", insertable = false, updatable = false, nullable = true)
	@JsonIgnore
	private CriteriaTemplate criteriaTemplate;

	@Column(name = "CriteriaName", nullable = false, columnDefinition = "nvarchar")
	private String criteriaName;

	@Column(name = "CriteriaDescription", nullable = false, columnDefinition = "nvarchar")
	private String criteriaDescription;

	@Column(name = "OverAllOperator", nullable = false)
	private String overAllOperator;

	@Column(name = "Qualifiers", nullable = false, columnDefinition = "text")
	@JsonRawValue
	private String qualifier;

	@Column(name = "IsDeleted", nullable = true)
	private boolean isDeleted;

	@Column(name = "IsInclude", nullable = true)
	private boolean isInclude;

	@Column(name = "InclusionCriteria", nullable = false, columnDefinition = "text")
	//@JsonRawValue
	private String inclusionCriteria;
	
	@Column(name = "ExclusionCriteria", nullable = false, columnDefinition = "text")
	//@JsonRawValue
	private String exclusionCriteria;

	public Long getCriteriaId() {
		return id;
	}

	public Long getTrialId() {
		return this.trialId;
	}

	public Long getTemplateId() {
		return this.templateId;
	}

	public String getCriteriaName() {
		return this.criteriaName;
	}

	public String getOverAllOperator() {
		if(this.overAllOperator!=null && "ALL".equals(this.overAllOperator))
			return "AND";
		if(this.overAllOperator!=null && "ANY".equals(this.overAllOperator))
			return "OR";
		return this.overAllOperator;
	}

	public String getCriteriaDescription() {
		return this.criteriaDescription;
	}

	public String getQualifier() {
		return this.qualifier;
	}

	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	public boolean getIsInclude() {
		return this.isInclude;
	}

	public ClinicalTrial getClinicalTrial() {
		return this.clinicalTrial;
	}

	public CriteriaTemplate getCriteriaTemplate() {
		return this.criteriaTemplate;
	}

	public String getInclusionCriteria() {
		return this.inclusionCriteria;
	}

	public String getExclusionCriteria() {
		return this.exclusionCriteria;
	}

	public Criteria withCriteriaId(Long id) {
		this.id = id;
		return this;
	}

	public Criteria withOverallOperator(String overAllOperator) {
		this.overAllOperator = overAllOperator;
		return this;
	}

	public Criteria withCriteriaName(String name) {
		this.criteriaName = name;
		return this;
	}

	public Criteria withCriteriaDescription(String desc) {
		this.criteriaDescription = desc;
		return this;
	}

	public Criteria withCriteriaQualifier(String q) {
		this.qualifier = q;
		return this;
	}

	public Criteria withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	public Criteria withTemplateId(Long templateId) {
		this.templateId = templateId;
		return this;
	}

	public Criteria withIsInclude(boolean isInclude) {
		this.isInclude = isInclude;
		return this;
	}

	public Criteria withIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
		return this;
	}

	public Criteria withClinicalTrial(ClinicalTrial clinicalTrial) {
		this.clinicalTrial = clinicalTrial;
		return this;
	}

	public Criteria withCriteriaTemplate(CriteriaTemplate criteriaTemplate) {
		this.criteriaTemplate = criteriaTemplate;
		return this;
	}
    public Criteria withCriteriaInclusionCriteria(String i) {
		this.inclusionCriteria = i;
		return this;
	}
	public Criteria withExclusionCriteria(String e) {
		this.exclusionCriteria = e;
		return this;
	}
}
