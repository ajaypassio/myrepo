package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import org.springframework.util.Assert;

public class CriteriaSearch implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;

	public CriteriaSearch() {
	}

	public CriteriaSearch(String name) {
		Assert.notNull(name, "Name must not be null");
		this.name = name;
	}
	

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
