package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;


@Entity
@Table(name = "CriteriaTemplate")
@EntityListeners({AuditingEntityListener.class , EntityListener.class})
public class CriteriaTemplate extends Auditable<Long> implements Serializable  {
	private static final long serialVersionUID = 7237095501517053217L;
	
	@Id
	@GeneratedValue
	@Column(name = "TemplateId", nullable = false)
	private Long id;
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL, mappedBy="criteriaTemplate", orphanRemoval=true)
	private List<Criteria> criterias;
	
	@Column(name = "TemplateName")		
	private String templateName;
	
	@Column(name = "TemplateDescription")
	private String templateDescription;
	
	@Column(name = "TemplateSource")
	private String templateSource;

	
	public Long getTemplateId() {
		return this.id;
	}	

	public String getTemplateName() {
		return this.templateName;
	}

	public String getTemplateDescription() {
		return this.templateDescription;
	}
	
	public String getTemplateSource(){
		return this.templateSource;
	}
	
	public List<Criteria> getCriterias(){
		return this.criterias;
	}


	public CriteriaTemplate withTemplateId(Long id) {
		this.id = id;
		return this;
	}
	
	public CriteriaTemplate withTemplateName(String name) {
		this.templateName = name;
		return this;
	}
	
	public CriteriaTemplate withTemplateDescription(String desc) {
		this.templateDescription = desc;
		return this;
	}
	
	public CriteriaTemplate withCriterias(List<Criteria> criterias) {
		this.criterias = criterias;
		return this;
	}
  	
	@Override
	public String toString() {
		return "CriteriaTemplate [id=" + id + ", name=" + templateName
				+ ", description=" + templateDescription + "]";
	}
}
