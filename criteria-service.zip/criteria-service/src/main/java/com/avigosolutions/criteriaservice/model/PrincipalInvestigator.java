package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name = "PrincipalInvestigator")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class PrincipalInvestigator extends Auditable<Long> implements Serializable {
	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "PrincipalInvestigatorId", nullable = false)
	private long id;
	
	@Column(name = "PrincipalInvestigatorName", nullable = false)
	private String name;
	

	@Column(name = "EmailAddress", nullable = false)
	private String emailAddress;
	
	@Column(name = "PhoneNumber", nullable = false)
	private String phoneNumber;
	
	@Column(name = "NPI")
	private String npi;
	
	@Column(name = "Specialty")
	private String specialty;
	
	@Column(name = "Project")
	private String project;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "principalInvestigator")
	private Set<StudySitePrincipalInvestigator> studySitePrincipalInvestigators;
	
	public long getPrincipalInvestigatorId() {
		return this.id;
	}

	public PrincipalInvestigator withPrincipalInvestigatorId(long id) {
		this.id = id;
		return this;
	}

	public String getName() {
		return this.name;
	}

	public PrincipalInvestigator withName(String name) {
		this.name = name;
		return this;
	}
	
	public String getEmailAddress() {
		return this.emailAddress;
	}

	public PrincipalInvestigator withEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
		return this;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public PrincipalInvestigator withPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}
	
	public String getNpi() {
		return this.npi;
	}

	public PrincipalInvestigator withNpi(String npi) {
		this.npi = npi;
		return this;
	}

	public String getSpecialty() {
		return this.specialty;
	}

	public PrincipalInvestigator withSpecialty(String specialty) {
		this.specialty = specialty;
		return this;
	}
	
	public String getProject() {
		return this.project;
	}

	public PrincipalInvestigator withProject(String project) {
		this.project = project;
		return this;
	}

	public Set<StudySitePrincipalInvestigator> getStudySitePrincipalInvestigators() {
		return studySitePrincipalInvestigators;
	}

	public void setStudySitePrincipalInvestigators(Set<StudySitePrincipalInvestigator> studySitePrincipalInvestigators) {
		this.studySitePrincipalInvestigators = studySitePrincipalInvestigators;
	}
	
}
