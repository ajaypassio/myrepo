package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonProperty;



@Entity
@Table(name = "Program")
@EntityListeners({AuditingEntityListener.class , EntityListener.class})
public class Program extends Auditable<Long> implements Serializable  {
	private static final long serialVersionUID = 7237095501517057347L;
	
	@Id
	@GeneratedValue
	@Column(name = "ProgramId", nullable = false)
	private Long programId;

	@JsonProperty("programId")
	public Program withProgramId(Long programId) {
		this.programId = programId;
		return this;
	}

	@JsonProperty("id")
	public Long getId() {
		return programId;
	}
	
	//@JsonProperty("programName")
	@Column(name = "ProgramName", nullable = false)		
	private String name;
	
	
	@Column(name = "ProgramDesc", nullable = true)		
	private String description;
	
	@Column(name = "StartDate", nullable = true)		
	private Date startDate;
	
	@Column(name = "EstimatedEndDate", nullable = true)		
	private Date endDate;
	
	@Column(name = "StatusId", nullable = true)		
	private Integer programStatusId;
	
	@Column(name = "SponsorId", nullable = true)
	private Long sponsorId;

	@Column(name = "PhaseId", nullable = true)
	private Integer phaseId;
	
	/*@Column(name = "CollaboratorId", nullable=true)
	private Long collaboratorId;*/
	
	@Column(name = "TherapeuticAreaId", nullable=true)
	private Long therapeuticAreaId;
	
	@Transient
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PhaseId", insertable = false, updatable = false) 
	private Phase phase;
	
	//@Transient
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "SponsorId", insertable = false, updatable = false) 
	private Sponsor sponsor;
	
	//@Transient
    @ManyToMany(fetch = FetchType.EAGER,cascade = {
            CascadeType.MERGE
        })
    @JoinTable(
            name = "Program_Collaborator", 
            joinColumns = { @JoinColumn(name = "ProgramId") }, 
            inverseJoinColumns = { @JoinColumn(name = "CollaboratorId") }
        )
    private Set<Collaborator> collaborators;
	
	//@Transient
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "TherapeuticAreaId", insertable = false, updatable = false)    
    private TherapeuticArea therapeuticArea;
	
	@Transient
    @OneToOne
    @JoinColumn(name = "StatusId", insertable = false, updatable = false)    
    private ProgramStatus programStatus;
    
    @Column(name = "IsDeleted")
	private boolean deleted;
	
	public boolean getDeleted() {
		return deleted;
	}

	public Program withDeleted(boolean deleted) {
		this.deleted = deleted;
		return this;
	}

	public Integer getPhaseId() {
		return this.phaseId;
	}
	public Program withPhaseId(Integer phaseId) {
		this.phaseId = phaseId;
		return this;
	}
	
	public Phase getPhase() {
		return this.phase;
	}

	public Program withPhase(Phase phase) {
		this.phase = phase;
		this.phaseId = this.phase.getPhaseId();
		return this;
	}
	
	public Long getSponsorId() {
		return this.sponsorId;
	}
	
	public Program withSponsorId(Long sponsorId) {
		this.sponsorId = sponsorId;
		return this;
	}
	
	public Sponsor getSponsor() {
		return this.sponsor;
	}

	public Program withSponsor(Sponsor sponsor) {
		this.sponsor = sponsor;
		this.sponsorId = this.sponsor.getSponsorId();
		return this;
	}
	
	/*public Long getCollaboratorId() {
		return collaboratorId;
	}*/

	/*public Program withCollaboratorId(Long collaboratorId) {
		this.collaboratorId = collaboratorId;
		return this;
	}*/

	public Set<Collaborator> getCollaborators() {
		return collaborators;
	}

	public Program withCollaborators(Set<Collaborator> collaborators) {
		this.collaborators = collaborators;
		return this;
	}
	
	public Long getTherapeuticAreaId() {
		return this.therapeuticAreaId;
	}
	
	public Program withTherapeuticAreaId(Long therapeuticAreaId) {
		this.therapeuticAreaId = therapeuticAreaId;
		return this;
	}
	
	public TherapeuticArea getTherapeuticArea() {
		return therapeuticArea;
	}

	public Program withTherapeuticArea(TherapeuticArea therapeuticArea) {
		this.therapeuticArea = therapeuticArea;
		this.therapeuticAreaId = this.therapeuticArea.getTherapeuticAreaId();
		return this;
	}
	
	public Integer getProgramStatusId() {
		return programStatusId;
	}

	public Program withProgramStatusId(Integer programStatusId) {
		this.programStatusId = programStatusId;
		return this;
	}
	
	public ProgramStatus getProgramStatus() {
		return programStatus;
	}

	public Program withProgramStatus(ProgramStatus programStatus) {
		this.programStatus = programStatus;
		this.programStatusId = this.programStatus.getStatusId();
		return this;
	}
	
	/*@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "program")
	private List<ClinicalTrial> trials;

	public List<ClinicalTrial> getTrials() {
		return trials;
	}

	public void setTrials(List<ClinicalTrial> trials) {
		this.trials = trials;
	}*/
	
	public String getName() {
		return name;
	}

	public Program withName(String programName) {
		this.name = programName;
		return this;
	}
	
	public String getDescription() {
		return description;
	}

	public Program withDescription(String description) {
		this.description = description;
		return this;
	}
	
	public Date getStartDate() {
		return startDate;
	}

	public Program withStartDate(Date startDate) {
		this.startDate = startDate;
		return this;
	}
	
	public Date getEndDate() {
		return endDate;
	}

	public Program withEndDate(Date endDate) {
		this.endDate = endDate;
		return this;
	}

	@Override
	public String toString() {
		return "Program [programId=" + programId + ", name=" + name + ", description=" + description + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", programStatusId=" + programStatusId + ", sponsorId=" + sponsorId
				+ ", phaseId=" + phaseId +  ", therapeuticAreaId="
				+ therapeuticAreaId + "]";
	}
}
