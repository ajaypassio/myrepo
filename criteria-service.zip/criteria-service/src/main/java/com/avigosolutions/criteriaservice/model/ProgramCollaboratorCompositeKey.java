package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

public class ProgramCollaboratorCompositeKey implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5162942010110272528L;
	
	private Long programId;
	private Long collaboratorId;
}
