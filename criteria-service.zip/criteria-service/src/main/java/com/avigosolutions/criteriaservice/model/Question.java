package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;

@Entity
@Table(name = "Question")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Question extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 2312121232L;

	@Id
	@GeneratedValue
	@Column(name = "QuestionId", nullable = false)
	private long id;

	@Column(name = "Status", nullable = true)
	private boolean status;

	@Column(name = "Description", nullable = true)
	private String description;

	@Column(name = "QuestionName", nullable = true)
	private String questionName;

	@Column(name = "CriteriaId")
	private Long criteriaId;

	@Column(name = "QualifierId", nullable = true)	
	private String qualifierId;

	@OneToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "CriteriaId", insertable = false, updatable = false)	
	@JsonIgnore
	private Criteria criteria;
	
	@Transient
	private boolean isIncludeCriteria;
	
	@Column(name = "IsInclude", nullable = true)
	private boolean isInclude;	
	
	public boolean getIsInclude() {
		return isInclude;
	}

	public Question withIsInclude(boolean isInclude) {
		this.isInclude = isInclude;
		return this;
	}

	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "QuestionnaireId", insertable = false, updatable = false)
	@JsonIgnore
	private Questionnaire questionnaire;

	@Column(name = "QuestionnaireId", nullable = true)
	private Long questionnaireId;
	
	@Column(name = "CorrectAnswer", nullable = true)
	private String correctAnswer;	


	public String getCorrectAnswer() {
		return correctAnswer;
	}

	public Question withCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
		return this;
	}

	public Long getQuestionnaireId() {
		return this.questionnaireId;
	}

	public Question withQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	public Questionnaire getQuestionnaire() {
		return this.questionnaire;
	}

	public Question withQuestionnaire(Questionnaire questionnaire) {
		this.questionnaire = questionnaire;
		return this;
	}
	
	@JsonGetter("id")
	public long getQuestionId() {
		return this.id;
	}

	@JsonSetter("id")
	public Question withQuestionId(long id) {
		this.id = id;
		return this;
	}

	public boolean getStatus() {
		return this.status;
	}

	public Question withStatus(boolean status) {
		this.status = status;
		return this;
	}

	@Override
	public String toString() {
		return "Question:";
	}

	public String getDescription() {
		return this.description;
	}

	public Question withDescription(String description) {
		this.description = description;
		return this;
	}

	public String getQuestionName() {
		return this.questionName;
	}

	public Question withQuestionName(String questionName) {
		this.questionName = questionName;
		return this;
	}

	public Question withCriteriaId(Long criteriaId) {
		this.criteriaId = criteriaId;
		return this;
	}

	public Long getCriteriaId() {
		return this.criteriaId;
	}

	public Question withQualifierId(String qualifierId) {
		this.qualifierId = qualifierId;
		return this;
	}

	public String getQualifierId() {
		return this.qualifierId;
	}

	public Criteria getCriteria() {
		return this.criteria;
	}

	public Question withCriteria(Criteria criteria) {
		this.criteria = criteria;
		return this;
	}
	
	public boolean getIsIncludeCriteria() {
		return this.isIncludeCriteria;
	}

	public Question withIsIncludeCriteria(boolean isIncludeCriteria) {
		this.isIncludeCriteria = isIncludeCriteria;
		return this;
	}

}
