package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.avigosolutions.criteriaservice.util.EncryptionUtils;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;

@Entity
@Table(name = "Questionnaire")
@EntityListeners({AuditingEntityListener.class , EntityListener.class})
public class Questionnaire extends Auditable<Long>  implements Serializable {

	private static final long serialVersionUID = 2312121232L;

	@Id
	@GeneratedValue
	@Column(name = "QuestionnaireId", nullable = false)
	private long id;
	
	@Column(name = "Status", nullable = true)
	private boolean status;
	
	@Column(name = "Description", nullable = true)
	private String description;

    @Transient
	private String encruptedId;

     @PostLoad
	 private void postLoadFunction(){
	   setEncruptedId(EncryptionUtils.getInstance().encryptToBase64(String.valueOf(id)));
	}

	@JsonSetter("id")
	public long getQuestionnaireId() {
		return this.id;
	}

	@JsonSetter("id")
	public Questionnaire withQuestionnaireId(long id) {
		this.id = id;
		return this;
	}	

	public boolean getStatus() {
		return this.status;
	}

	public Questionnaire withStatus(boolean status) {
		this.status = status;
		return this;
	}

	@Override
	public String toString() {
		return "Questionnaire:";
	}


	public String getDescription() {
		return this.description;
	}

	public Questionnaire withDescription(String description) {
		this.description = description;
		return this;
	}

	@Column(name = "TrialId", nullable = true)
	private Long trialId;
	
	@Column(name = "ProgramId", nullable = true)
	private Long programId;

	/**
	 * @return the programId
	 */
	public Long getProgramId() {
		return programId;
	}

	/**
	 * @param programId the programId to set
	 */
	public Questionnaire withProgramId(Long programId) {
		this.programId = programId;
		return this;
	}

	public Questionnaire withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}
	
	public long getTrialId() {
		return this.trialId;
	}
	
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "TrialId", insertable = false, updatable = false)
	@JsonIgnore
	private ClinicalTrial clinicalTrial;	

	public ClinicalTrial getClinicalTrial() {
		return this.clinicalTrial;
	}

	public Questionnaire withClinicalTrial(ClinicalTrial clinicalTrial) {
		this.clinicalTrial = clinicalTrial;
		return this;
	}

	@Column(name = "QuestionnaireName", nullable = false)
	private String name;

	public String getName() {
		return this.name;
	}

	public Questionnaire withName(String name) {
		this.name = name;
		return this;
	}	
	public Questionnaire withQuestions(List<Question> questions) {
		this.questions = questions;
		return this;
	}
	public List<Question> getQuestions() {
		return questions;
	}
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL, mappedBy="questionnaire", orphanRemoval=true)
	private List<Question> questions;

	@Transient
	private String trialName;

	@Transient
	private TherapeuticArea therapeuticArea;
	
	@Transient
	private Long therapeuticAreaId;

	
	
	public Long getTherapeuticAreaId() {
		return therapeuticAreaId;
	}

	public void setTherapeuticAreaId(Long therapeuticAreaId) {
		this.therapeuticAreaId = therapeuticAreaId;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}
    
	public String getEncruptedId() {
		return encruptedId;
	}

	public void setEncruptedId(String encruptedId) {
		this.encruptedId = encruptedId;
	}

	public TherapeuticArea getTherapeuticArea() {
		return therapeuticArea;
	}

	public void setTherapeuticArea(TherapeuticArea therapeuticArea) {
		this.therapeuticArea = therapeuticArea;
	}
	
	
	
}
