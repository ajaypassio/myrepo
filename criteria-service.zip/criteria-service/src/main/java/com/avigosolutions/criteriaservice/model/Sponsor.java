package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name="Sponsor")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Sponsor  extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "SponsorId", nullable = false)
	private Long id;

	public Long getSponsorId() {
		return this.id;
	}

	public Sponsor withSponsorId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "SponsorName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public Sponsor withName(String name) {
		this.name = name;
		return this;
	}
	
	
}
