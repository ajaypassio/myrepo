package com.avigosolutions.criteriaservice.model;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="Stage")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Stage  extends Auditable<Long>  implements Serializable {

	private static final long serialVersionUID = 4808491656221849433L;
	@Id
	@GeneratedValue
	@Column(name = "StageId", nullable = false)
	private Long id;

	
	public Long getStageId() {
		return this.id;
	}
	

	public Stage withStageId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "StageName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public Stage withName(String name) {
		this.name = name;
		return this;
	}

	@Override
	public String toString() {
		return "Stage [id=" + id + ", name=" + name + "]";
	}
	
	
}
