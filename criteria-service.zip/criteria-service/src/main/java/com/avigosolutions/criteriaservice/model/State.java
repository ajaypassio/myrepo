package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name = "State")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class State extends Auditable<Long> implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -52854989633260025L;
	@Id
	@GeneratedValue
	@Column(name = "StateId", nullable = false)	
	private Long id;
	
	@Column(name = "StateName")
	private String stateName;

	@Column(name = "Abbrev")
	private String abbrev;


	@Column(name = "CountryId")
	private Long countryId;

	public Long getId() {
		return id;
	}

	public State withId(Long id) {
		this.id = id;
		return this;
	}

	public String getStateName() {
		return stateName;
	}

	public State withStateName(String stateName) {
		this.stateName = stateName;
		return this;
	}

	public String getAbbrev() {
		return abbrev;
	}

	public State withAbbrev(String abbrev) {
		this.abbrev = abbrev;
		return this;
	}


	public Long getCountryId() {
		return countryId;
	}

	public State withCountryId(Long countryId) {
		this.countryId = countryId;
		return this;
	}

}
