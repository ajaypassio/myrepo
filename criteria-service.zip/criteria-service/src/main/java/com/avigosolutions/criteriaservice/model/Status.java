package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Status")
public class Status implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "StatusId", nullable = false)
	private int id;

	public int getStatusId() {
		return this.id;
	}

	public Status withStatusId(int id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "StatusName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public Status withName(String name) {
		this.name = name;
		return this;
	}
	
	@Column(name = "CreatedBy")	
	private Long createdBy;

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public Status withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}
	
	@Column(name = "CreatedOn")	
	private Date createdOn;

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public Status withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}
	
	@Column(name = "UpdatedBy")	
	private Long updatedBy;

	public Long getUpdatedBy() {
		return this.updatedBy;
	}

	public Status withUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}
	
	@Column(name = "UpdatedOn")	
	private Date updatedOn;

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public Status withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
}
