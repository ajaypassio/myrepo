package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name = "StudySite")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class StudySite extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 2312121232L;

	@Id
	@GeneratedValue
	@Column(name = "StudySiteId", nullable = false)
	private Long id;
	
	@Column(name = "Latitude", nullable = true)
	private double latitude;
	
	@Column(name = "Longitude", nullable = true)
	private double longitude;
	
	@Column(name = "City", nullable = true)
	private String city;

	@Column(name = "State", nullable = true)
	private String state;

	@Column(name = "Country", nullable = true)
	private String country;

	@Column(name = "Zip", nullable = true)
	private String zip;

	//@CsvBindByName
	@Column(name = "studySiteName", nullable = true)
	private String studySiteName;

	@Column(name = "Address1", nullable = true)
	private String address1;

	@Column(name = "Address2", nullable = true)
	private String address2;

	@Column(name = "EmailAddress", nullable = true)
	private String emailAddress;

	@Column(name = "PhoneNumber", nullable = true)
	private String phoneNumber;
	
	@Column(name = "UltimateParentName", nullable = true)
	private String ultimateParentName;

	/*@Column(name = "StudySiteNumber", nullable = true)
	private String studySiteNumber;*/

	@Column(name = "Region", nullable = true)
	private String region;

/*	@Column(name = "SubRegion", nullable = true)
	private String subRegion;*/

	/*@Column(name = "ProtocolNumber", nullable = true)
	private String protocolNumber;

	@Column(name = "ProjectCode", nullable = true)
	private String projectCode;*/

	@Column(name = "PrimaryTherapeuticArea", nullable = true)
	private String primaryTherapeuticArea;

	@Column(name = "PrimaryIndication", nullable = true)
	private String primaryIndication;

	/*@Column(name = "InvestigationalProductType", nullable = true)
	private String investigationalProductType;
*/
	/*@Column(name = "TDU", nullable = true)
	private String tDU;*/

	/*@Column(name = "CTMSResearchFacilityIdentifier", nullable = true)
	private String cTMSResearchFacilityIdentifier;*/

/*	@Column(name = "SiteCluster", nullable = true)
	private String siteCluster;*/

	@Column(name = "Active", nullable = true)
	private Boolean active;

	@Column(name = "StudySitePhaseId", nullable = true)
	private Long studySitePhaseId;

	@Column(name = "StudySiteIRBId", nullable = true)
	private Long studySiteIRBId;

	@Column(name = "StudySiteStatusId", nullable = true)
	private Long studySiteStatusId;
	
	@Transient
	private Integer radiusValue;
	
	@Transient
	private Boolean radiusExempt=false;
	
	@Transient
	private Boolean radiusChanged=false;
	
	@Transient
	private String principalInvestigatorName;
	
	//@Transient
	@OneToMany
	@JoinColumn(name = "StudySiteId", insertable = false, updatable = false)
	private Set<StudySiteCoordinator> studySiteCoordinators;

	//@Transient
	@OneToMany
	@JoinColumn(name = "StudySiteId", insertable = false, updatable = false) 
	private Set<StudySitePrincipalInvestigator> studySitePrincipalInvestigators;
 
	//@Transient
	@OneToMany
	@JoinColumn(name = "StudySiteId", insertable = false, updatable = false) 
	private Set<ClinicalTrialStudySite> cinicalTrialStudySites;
 

	//constructors
	public StudySite() {

	}

	public StudySite(String name) {
		this.studySiteName = name;
		studySiteCoordinators = new HashSet<>();
		studySitePrincipalInvestigators = new HashSet<>();
	} 

	public Long getId() {
		return id;
	}

	public StudySite withId(Long id) {
		this.id = id;
		return this;
	}

	public String getCity() {
		return city;
	}

	public StudySite withCity(String city) {
		this.city = city;
		return this;
	}

	public String getState() {
		return state;
	}

	public StudySite withState(String state) {
		this.state = state;
		return this;
	}

	public StudySite withCountry(String country) {
		this.country = country;
		return this;
	}

	public String getCountry() {
		return country;
	}

	public String getZip() {
		return zip;
	}

	public StudySite withZip(String zip) {
		this.zip = zip;
		return this;
	}

	public double getLatitude() {
		return latitude;
	}

	public StudySite withLatitude(double latitude) {
		this.latitude = latitude;
		return this;
	}

	public double getLongitude() {
		return longitude;
	}

	public StudySite withLongitude(double longitude) {
		this.longitude = longitude;
		return this;
	}

	public String getStudySiteName() {
		return studySiteName;
	}

	public void setStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
	}

	public String getAddress1() {
		return address1;
	}

	public StudySite withAddress1(String address1) {
		this.address1 = address1;
		return this;
	}

	public String getAddress2() {
		return address2;
	}

	public StudySite withAddress2(String address2) {
		this.address2 = address2;
		return this;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public StudySite withEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
		return this;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public StudySite withPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	/*public StudySite withStudySiteNumber(String studySiteNumber) {
		this.studySiteNumber = studySiteNumber;
		return this;
	}*/

	public StudySite withUltimateParentName(String ultimateParentName) {
		this.ultimateParentName = ultimateParentName;
		return this;
	}

	
	public Set<StudySiteCoordinator> getStudySiteCoordinators() {
		return studySiteCoordinators;
	}
	
	public StudySite withStudySiteCoordinators(Set<StudySiteCoordinator> studySiteCoordinator) {
		this.studySiteCoordinators = studySiteCoordinator;
		return this;
	}

	public StudySite withStudySitePrincipalInvestigators(
			Set<StudySitePrincipalInvestigator> studySitePrincipalInvestigators) {
		this.studySitePrincipalInvestigators = studySitePrincipalInvestigators;
		return this;
	}
	
	public Set<StudySitePrincipalInvestigator> getStudySitePrincipalInvestigators() {
		return studySitePrincipalInvestigators;
	}

	public String getUltimateParentName() {
		return ultimateParentName;
	}

	/*public String getStudySiteNumber() {
		return studySiteNumber;
	}*/

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getRegion() {
		return region;
	}

	public StudySite withRegion(String region) {
		this.region = region;
		return this;
	}

	/*public String getSubRegion() {
		return subRegion;
	}

	public StudySite withSubRegion(String subRegion) {
		this.subRegion = subRegion;
		return this;
	}

	public String getProtocolNumber() {
		return protocolNumber;
	}

	public StudySite withProtocolNumber(String protocolNumber) {
		this.protocolNumber = protocolNumber;
		return this;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public StudySite withProjectCode(String projectCode) {
		this.projectCode = projectCode;
		return this;
	}*/

	public String getPrimaryTherapeuticArea() {
		return primaryTherapeuticArea;
	}

	public StudySite withPrimaryTherapeuticArea(String primaryTherapeuticArea) {
		this.primaryTherapeuticArea = primaryTherapeuticArea;
		return this;
	}

	public String getPrimaryIndication() {
		return primaryIndication;
	}

	public StudySite withPrimaryIndication(String primaryIndication) {
		this.primaryIndication = primaryIndication;
		return this;
	}
	/*
	public String getInvestigationalProductType() {
		return investigationalProductType;
	}

	public StudySite withInvestigationalProductType(String investigationalProductType) {
		this.investigationalProductType = investigationalProductType;
		return this;
	}

	public String getTDU() {
		return tDU;
	}

	public StudySite withTDU(String tDU) {
		this.tDU = tDU;
		return this;
	}

	public String getCTMSResearchFacilityIdentifier() {
		return cTMSResearchFacilityIdentifier;
	}

	public StudySite withCTMSResearchFacilityIdentifier(String cTMSResearchFacilityIdentifier) {
		this.cTMSResearchFacilityIdentifier = cTMSResearchFacilityIdentifier;
		return this;
	}

	public String getSiteCluster() {
		return siteCluster;
	}

	public StudySite withSiteCluster(String siteCluster) {
		this.siteCluster = siteCluster;
		return this;
	}
*/
	public Boolean getActive() {
		return active;
	}

	public StudySite withActive(Boolean active) {
		this.active = active;
		return this;
	}

	public Long getStudySitePhaseId() {
		return studySitePhaseId;
	}

	public StudySite withStudySitePhaseId(Long studySitePhaseId) {
		this.studySitePhaseId = studySitePhaseId;
		return this;
	}

	public Long getStudySiteIRBId() {
		return studySiteIRBId;
	}

	public StudySite withStudySiteIRBId(Long studySiteIRBId) {
		this.studySiteIRBId = studySiteIRBId;
		return this;
	}

	public Long getStudySiteStatusId() {
		return studySiteStatusId;
	}

	public StudySite withStudySiteStatusId(Long studySiteStatusId) {
		this.studySiteStatusId = studySiteStatusId;
		return this;
	}

	@Override
	public String toString() {
		return "StudySite [id=" + id + ", latitude=" + latitude + ", longitude=" + longitude + ", city=" + city
				/*+ ", state=" + state + ", country=" + country + ", zip=" + zip + ", studySiteName=" + studySiteName
				+ ", address1=" + address1 + ", address2=" + address2 + ", emailAddress=" + emailAddress
				+ ", phoneNumber=" + phoneNumber + ", ultimateParentName=" + ultimateParentName + ", region=" + region
				+ ", primaryTherapeuticArea=" + primaryTherapeuticArea + ", primaryIndication=" + primaryIndication
				+ ", active=" + active + ", studySitePhaseId=" + studySitePhaseId + ", studySiteIRBId=" + studySiteIRBId
				+ ", studySiteStatusId=" + studySiteStatusId + ", radiusValue=" + radiusValue + ", radiusExempt="
				+ radiusExempt + ", radiusChanged=" + radiusChanged + ", principalInvestigatorName="
				+ principalInvestigatorName + ", studySiteCoordinators=" + studySiteCoordinators
				+ ", studySitePrincipalInvestigators=" + studySitePrincipalInvestigators + ", cinicalTrialStudySites="
				+ cinicalTrialStudySites */+ "]";
	}

	public Integer getRadiusValue() {
		return radiusValue;
	}

	public void setRadiusValue(Integer radiusValue) {
		this.radiusValue = radiusValue;
	}

	public Boolean isRadiusExempt() {
		return radiusExempt;
	}

	public void setRadiusExempt(Boolean radiusExempt) {
		this.radiusExempt = radiusExempt;
	}
	
	public Boolean isRadiusChanged() {
		return radiusChanged;
	}

	public void setRadiusChanged(Boolean radiusChanged) {
		this.radiusChanged = radiusChanged;
	}

	public String getPrincipalInvestigatorName() {
		return principalInvestigatorName;
	}

	public void setPrincipalInvestigatorName(String principalInvestigatorName) {
		this.principalInvestigatorName = principalInvestigatorName;
	}
	
}
