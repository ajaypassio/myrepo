package com.avigosolutions.criteriaservice.model;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
@Entity
@Table(name = "StudySiteAudit")
public class StudySiteAudit extends Auditable<Long> implements Serializable{

	private static final long serialVersionUID = 1841738157374264504L;
	
	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;
	
	@Column(name = "StudySiteId", nullable = false)
	private Long studySiteId;
	
	@Column(name = "PreviousStatus", nullable = true)
	private Boolean previousStatus;
	
	@Column(name = "ChangedStatus", nullable = true)
	private Boolean changedStatus;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}

	public Boolean getPreviousStatus() {
		return previousStatus;
	}

	public void setPreviousStatus(Boolean previousStatus) {
		this.previousStatus = previousStatus;
	}

	public Boolean getChangedStatus() {
		return changedStatus;
	}

	public void setChangedStatus(Boolean changedStatus) {
		this.changedStatus = changedStatus;
	}

	
    
}
