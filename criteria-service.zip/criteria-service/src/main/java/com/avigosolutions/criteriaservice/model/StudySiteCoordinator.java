package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "StudySiteCoordinator")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class StudySiteCoordinator extends Auditable<Long> implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 5706189621858620056L;

	@Id
	@GeneratedValue
	@Column(name = "StudySiteCoordinatorId", nullable = false)
	private Long id;

	@Column(name = "CoordinatorId")
	private Long coordinatorId;

	@Column(name = "StudySiteId")
	private Long studySiteId;
	
	@Column(name = "TrialId")
	private Long trialId;

	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public StudySiteCoordinator withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "StudySiteId", insertable = false, updatable = false)
	@JsonIgnore
	private StudySite studySite;

	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "CoordinatorId", insertable = false, updatable = false)
	@JsonIgnore
	private Coordinator coordinator;

	public StudySite getStudySite() {
		return studySite;
	}

	public void setStudySite(StudySite studySite) {
		this.studySite = studySite;
	}

	public Coordinator getCoordinator() {
		return coordinator;
	}

	public void setCoordinator(Coordinator coordinator) {
		this.coordinator = coordinator;
	}

	public Long getStudySiteCoordinatorId() {
		return this.id;
	}

	public StudySiteCoordinator withStudySiteCoordinatorId(Long id) {
		this.id = id;
		return this;
	}

	public StudySiteCoordinator() {

	}
	public StudySiteCoordinator(Long coordintorId,Long studySiteId) {
		this.coordinatorId=coordintorId;
		this.studySiteId=studySiteId;
		
	}

	public Long getCoordinatorId() {
		return coordinatorId;
	}

	public StudySiteCoordinator withCoordinatorId(Long coordinatorId) {
		this.coordinatorId = coordinatorId;
		return this;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public StudySiteCoordinator withStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

	@Override
	public String toString() {
		return "StudySiteCoordinator [id=" + id + ", coordinatorId=" + coordinatorId + ", studySiteId=" + studySiteId
				+ ", studySite=" + studySite + ", coordinator=" + coordinator + "]";
	}

}
