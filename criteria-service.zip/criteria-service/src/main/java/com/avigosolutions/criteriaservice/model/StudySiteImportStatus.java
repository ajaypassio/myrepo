package com.avigosolutions.criteriaservice.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "StudySiteImportStatus")
public class StudySiteImportStatus {

	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;

	@Column(name = "FileName", nullable = false)
	private String fileName;

	@Column(name = "TrialId", nullable = false)
	private Long trialId;

	@Column(name = "ImportStatus", nullable = true)
	private String importStatus;

	@Column(name = "ImportStatusData", nullable = true)
	private String importStatusDataJson;

	@Column(name = "CreatedBy", nullable = true)
	private Long createdBy;

	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;
	
	@Column(name = "OriginalFileName", nullable = true)
	private String originalFileName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public StudySiteImportStatus withId(Long id) {
		this.id = id;
		return this;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public StudySiteImportStatus withFileName(String fileName) {
		this.fileName = fileName;
		return this;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public StudySiteImportStatus withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	public String getImportStatus() {
		return importStatus;
	}

	public void setImportStatus(String importStatus) {
		this.importStatus = importStatus;
	}

	public StudySiteImportStatus withImportStatus(String importStatus) {
		this.importStatus = importStatus;
		return this;
	}

	public String getImportStatusDataJson() {
		return importStatusDataJson;
	}

	public void setImportStatusDataJson(String importStatusDataJson) {
		this.importStatusDataJson = importStatusDataJson;
	}

	public StudySiteImportStatus withImportStatusDataJson(String importStatusDataJson) {
		this.importStatusDataJson = importStatusDataJson;
		return this;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public StudySiteImportStatus withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public StudySiteImportStatus withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public StudySiteImportStatus withOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
		return this;
	}

	@Override
	public String toString() {
		return "StudySiteImportStatus [id=" + id + ", fileName=" + fileName + ", trialId=" + trialId + ", importStatus="
				+ importStatus + ", importStatusDataJson=" + importStatusDataJson + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", originalFileName=" + originalFileName + "]";
	}

}
