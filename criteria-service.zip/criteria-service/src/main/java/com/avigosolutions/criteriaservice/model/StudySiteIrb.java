package com.avigosolutions.criteriaservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "StudySiteIRB")
public class StudySiteIrb {

	@Id
	@Column(name = "StudySiteIRBId")
	private Long studySiteIrbId;

	@Column(name = "StudySiteIRBName")
	private String studySiteIrbName;

	public Long getStudySiteIRBId() {
		return studySiteIrbId;
	}

	public StudySiteIrb withStudySiteIrbId(Long studySiteIrbId) {
		this.studySiteIrbId = studySiteIrbId;
		return this;
	}

	public String getStudySiteIrbName() {
		return studySiteIrbName;
	}

	public StudySiteIrb withStudySiteIrbName(String studySiteIrbName) {
		this.studySiteIrbName = studySiteIrbName;
		return this;
	}

	@Column(name = "IRBDisplayName")
	private String irbDisplayName;

	public String getirbDisplayName() {
		return irbDisplayName;
	}

	public StudySiteIrb withirbDisplayName(String irbDisplayName) {
		this.irbDisplayName = irbDisplayName;
		return this;
	}

}
