package com.avigosolutions.criteriaservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "StudySitePhase")
public class StudySitePhase {

	@Id
	@Column(name = "StudySitePhaseId")
	private Long studySitePhaseId;

	@Column(name = "StudySitePhaseName")
	private String studySitePhaseName;

	public Long getStudySitePhaseId() {
		return studySitePhaseId;
	}

	public StudySitePhase withStudySiteStatusId(Long studySitePhaseId) {
		this.studySitePhaseId = studySitePhaseId;
		return this;
	}

	public String getStudySitePhaseName() {
		return studySitePhaseName;
	}

	public StudySitePhase withStudySitePhaseName(String studySitePhaseName) {
		this.studySitePhaseName = studySitePhaseName;
		return this;
	}

	@Column(name = "StudySitePhaseDisplayName")
	private String phaseDisplayName;

	public String getPhaseDisplayName() {
		return phaseDisplayName;
	}

	public StudySitePhase withstudySiteDisplayName(String phaseDisplayName) {
		this.phaseDisplayName = phaseDisplayName;
		return this;
	}

}
