package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "StudySitePrincipalInvestigator")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class StudySitePrincipalInvestigator extends Auditable<Long> implements Serializable {
	
	public StudySitePrincipalInvestigator() {
		
	}
	public StudySitePrincipalInvestigator(Long principalInvestigatorId,Long studySiteId,Long trialId) {
		this.principalInvestigatorId=principalInvestigatorId;
		this.studySiteId=studySiteId;
		this.trialId=trialId;
	}
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="StudySitePrincipalInvestigatorId")
	private Long studySitePrincipalInvestigatorId;
	
	@Column(name = "PrincipalInvestigatorId")
	private Long principalInvestigatorId;

	@Column(name = "StudySiteId")
	private Long studySiteId;
	
	@Column(name = "TrialId")
	private Long trialId;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "StudySiteId", insertable = false, updatable = false)
	@JsonIgnore
	private StudySite studySite;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "PrincipalInvestigatorId", insertable = false, updatable = false)
	@JsonIgnore
	private PrincipalInvestigator principalInvestigator;
	
	public Long getPrincipalInvestigatorId() {
		return principalInvestigatorId;
	}

	public StudySitePrincipalInvestigator withPrincipalInvestigatorId(Long principalInvestigatorId) {
		this.principalInvestigatorId = principalInvestigatorId;
		return this;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public StudySitePrincipalInvestigator withStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

	public Long getStudySitePrincipalInvestigatorId() {
		return studySitePrincipalInvestigatorId;
	}

	public StudySitePrincipalInvestigator withStudySitePrincipalInvestigatorId(Long studySitePrincipalInvestigatorId) {
		this.studySitePrincipalInvestigatorId = studySitePrincipalInvestigatorId;
		return this;
	}
	
	public StudySite getStudySite() {
		return studySite;
	}

	public void setStudySite(StudySite studySite) {
		this.studySite = studySite;
	}
	
	public PrincipalInvestigator getPrincipalInvestigator() {
		return principalInvestigator;
	}

	public void setPrincipalInvestigator(PrincipalInvestigator principalInvestigator) {
		this.principalInvestigator = principalInvestigator;
	}
	
	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public StudySitePrincipalInvestigator withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}
	
}
