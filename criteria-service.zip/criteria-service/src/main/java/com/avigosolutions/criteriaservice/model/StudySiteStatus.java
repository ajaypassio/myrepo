package com.avigosolutions.criteriaservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name ="StudySiteStatus")
public class StudySiteStatus {
	
	@Id	
	@Column(name="StudySiteStatusId")
	private Long studySiteStatusId;
	
	@Column(name="StudySiteStatusName")
	private String studySiteStatusName;
	
	public Long getStudySiteStatusId() {
		return studySiteStatusId;
	}
	
	public StudySiteStatus withStudySiteStatusId(Long studySiteStatusId) {
		this.studySiteStatusId=studySiteStatusId;
		return this;
	}

	public String getStudySiteStatusName() {
		return studySiteStatusName;
	}
	
	public StudySiteStatus withStudySiteStatusName(String studySiteStatusName) {
		this.studySiteStatusName=studySiteStatusName;
		return this;
	}

	@Column(name="StudySiteStatusDisplayName")
	private String statusDisplayName;
	
	public String getStatusDisplayName() {
		return statusDisplayName;
	}
	
	public StudySiteStatus withstudySiteDisplayName(String statusDisplayName) {
		this.statusDisplayName=statusDisplayName;
		return this;
	}

}
