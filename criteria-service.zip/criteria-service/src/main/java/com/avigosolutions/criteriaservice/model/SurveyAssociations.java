package com.avigosolutions.criteriaservice.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "SurveyAssociations")
public class SurveyAssociations implements Serializable{
	
	private static final long serialVersionUID = -4877151372844124396L;

	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long Id;
	
	@Column(name = "trialId", nullable = false)
	private Long trialId;
	
	@Column(name = "ProgramId", nullable = false)
	private Long programId;
	
	@Column(name = "SprinttSurveyStatus", nullable = false)
	private Byte sprinttSurveyStatus;
	
	@Column(name = "Remarks", nullable = true)
	private String remarks;
	
	@Column(name = "CreatedBy", nullable = false)
	private String createdBy;
	
	@Column(name = "CreatedOn", nullable = false)
	private Date createdOn;
	
	@Column(name = "UpdatedBy", nullable = false)
	private String updatedBy;
	
	@Column(name = "UpdatedOn", nullable = false)
	private Date updatedOn;

	@ManyToOne(fetch = FetchType.EAGER, optional=false,cascade = CascadeType.ALL)
	@JoinColumn(name = "SprinttSurveyId",nullable=false)
	@JsonBackReference
	private SurveyMaster surveyMaster;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Long getProgramId() {
		return programId;
	}

	public void setProgramId(Long programId) {
		this.programId = programId;
	}

	public Byte getSprinttSurveyStatus() {
		return sprinttSurveyStatus;
	}

	public void setSprinttSurveyStatus(Byte sprinttSurveyStatus) {
		this.sprinttSurveyStatus = sprinttSurveyStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public SurveyMaster getSurveyMaster() {
		return surveyMaster;
	}

	public void setSurveyMaster(SurveyMaster surveyMaster) {
		this.surveyMaster = surveyMaster;
	}

	@Override
	public String toString() {
		return "SurveyAssociations [Id=" + Id + ", trialId=" + trialId + ", programId=" + programId
				+ ", sprinttSurveyStatus=" + sprinttSurveyStatus + ", remarks=" + remarks + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn=" + updatedOn
				+ ", surveyMaster=" + surveyMaster + "]";
	}
}
