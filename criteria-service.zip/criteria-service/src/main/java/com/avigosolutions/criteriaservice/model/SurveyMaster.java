package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "SurveyMaster")
public class SurveyMaster implements Serializable {

	private static final long serialVersionUID = -9121765346628166686L;

	@Id
	@GeneratedValue
	@Column(name = "SprinttSurveyId", nullable = true)
	private Long sprinttSurveyId;

	@Column(name = "SurveyId", nullable = false)
	private String surveyId;

	@Column(name = "SurveyTitle", nullable = false)
	private String surveyTitle;

	@Column(name = "SurveyDescription", nullable = false)
	private String surveyDescription;

	@Column(name = "SurveyToolId", nullable = false)
	private Byte surveyToolId;
	
	@Column(name = "SurveyStatus", nullable = false)
	private Byte surveyStatus;
	
	
	@Column(name = "CreatedBy", nullable = false)
	private String createdBy;

	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa")
	@Column(name = "CreatedOn", nullable = false)
	private Date createdOn;

	@Column(name = "UpdatedBy", nullable = false)
	private String updatedBy;

	@JsonFormat(pattern = "M/dd/yyyy, hh:mm:ss aa")
	@Column(name = "UpdatedOn", nullable = false)
	private Date updatedOn;
	
	@Column(name = "SurveyVersion", nullable = true)
	private String surveyVersion;

	@OneToMany(mappedBy = "surveyMaster", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<SurveyAssociations> surveyAssociations;

	public Long getSprinttSurveyId() {
		return sprinttSurveyId;
	}

	public void setSprinttSurveyId(Long sprinttSurveyId) {
		this.sprinttSurveyId = sprinttSurveyId;
	}

	public String getSurveyId() {
		return surveyId;
	}

	public void setSurveyId(String surveyId) {
		this.surveyId = surveyId;
	}

	public String getSurveyTitle() {
		return surveyTitle;
	}

	public void setSurveyTitle(String surveyTitle) {
		this.surveyTitle = surveyTitle;
	}

	public String getSurveyDescription() {
		return surveyDescription;
	}

	public void setSurveyDescription(String surveyDescription) {
		this.surveyDescription = surveyDescription;
	}

	public Byte getSurveyToolId() {
		return surveyToolId;
	}

	public void setSurveyToolId(Byte surveyToolId) {
		this.surveyToolId = surveyToolId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Byte getSurveyStatus() {
		return surveyStatus;
	}

	public void setSurveyStatus(Byte surveyStatus) {
		this.surveyStatus = surveyStatus;
	}

	public String getSurveyVersion() {
		return surveyVersion;
	}

	public void setSurveyVersion(String surveyVersion) {
		this.surveyVersion = surveyVersion;
	}

	public List<SurveyAssociations> getSurveyAssociations() {
		return surveyAssociations;
	}

	public void setSurveyAssociations(List<SurveyAssociations> surveyAssociations) {
		this.surveyAssociations = surveyAssociations;
	}

	@Override
	public String toString() {
		return "SurveyMaster [sprinttSurveyId=" + sprinttSurveyId + ", surveyId=" + surveyId + ", surveyTitle="
				+ surveyTitle + ", surveyDescription=" + surveyDescription + ", surveyToolId=" + surveyToolId
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn="
				+ updatedOn + ", surveyStatus=" + surveyStatus + ", surveyAssociations=" + surveyAssociations + "]";
	}

}
