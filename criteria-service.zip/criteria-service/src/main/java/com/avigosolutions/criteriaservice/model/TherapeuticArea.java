package com.avigosolutions.criteriaservice.model;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;

@Entity
@Table(name="TherapeuticArea")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class TherapeuticArea  extends Auditable<Long>  implements Serializable {

	private static final long serialVersionUID = 4531568070309274763L;
	
	@Id
	@GeneratedValue
	@Column(name = "TherapeuticAreaId", nullable = false)
	private Long id;

	public Long getTherapeuticAreaId() {
		return this.id;
	}

	public TherapeuticArea withTherapeuticAreaId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "TherapeuticAreaName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public TherapeuticArea withName(String name) {
		this.name = name;
		return this;
	}

	@Override
	public String toString() {
		return "TherapeuticArea [id=" + id + ", name=" + name + "]";
	}
	
	
}
