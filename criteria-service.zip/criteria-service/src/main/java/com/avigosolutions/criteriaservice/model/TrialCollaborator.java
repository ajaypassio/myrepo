package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ClinicalTrial_Collaborator")
@IdClass(TrialCollaboratorCompositeKey.class)
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class TrialCollaborator implements Serializable {
	private static final long serialVersionUID = 976960176990267001L;
	
	@Id
	@Column(name = "TrialId")
	private Long trialId;
	
	@Id
	@Column(name = "CollaboratorId")
	private Long collaboratorId;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "TrialId", insertable = false, updatable = false)
	@JsonIgnore
	private ClinicalTrial trial;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "CollaboratorId", insertable = false, updatable = false)
	@JsonIgnore
	private Collaborator collaborator;
	public Long getProgramId() {
		return trialId;
	}
	public void setProgramId(Long programId) {
		this.trialId = programId;
	}
	public Long getCollaboratorId() {
		return collaboratorId;
	}
	public void setCollaboratorId(Long collaboratorId) {
		this.collaboratorId = collaboratorId;
	}
	public ClinicalTrial getProgram() {
		return trial;
	}
	public void setProgram(ClinicalTrial trial) {
		this.trial = trial;
	}
	public Collaborator getCollaborator() {
		return collaborator;
	}
	public void setCollaborator(Collaborator collaborator) {
		this.collaborator = collaborator;
	}

	
}
