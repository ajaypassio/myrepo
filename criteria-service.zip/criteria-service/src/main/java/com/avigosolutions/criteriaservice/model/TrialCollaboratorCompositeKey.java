package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

public class TrialCollaboratorCompositeKey implements Serializable{

	private static final long serialVersionUID = -5506840264542733143L;
	private Long trialId;
	private Long collaboratorId;
}
