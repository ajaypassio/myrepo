package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.criteriaservice.audit.Auditable;
import com.avigosolutions.criteriaservice.audit.EntityListener;

@Entity
@Table(name="TrialJobMap")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class TrialJobMap extends Auditable<Long> implements Serializable{
	

	private static final long serialVersionUID = -6694207148215397017L;
	
	@Id
	@GeneratedValue
	@Column(name="MapId",nullable=false)
	private Long mapId;
	
	@Column(name="CorrelationId",nullable=false)
	private String correlationId;
	
	@Column(name="TrialId",nullable=false)
	private Long trialId;
	
	@Column(name="JobStatus",nullable=false)
	private String jobStatus;
	

	public String getJobStatus() {
		return jobStatus;
	}

	public TrialJobMap withJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
		return this;
	}

	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * @param correlationId the correlationId to set
	 */
	public TrialJobMap withCorrelationId(String correlationId) {
		this.correlationId = correlationId;
		return this;
	}

	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public TrialJobMap withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	/**
	 * @return the mapId
	 */
	public Long getMapId() {
		return mapId;
	}

	/**
	 * @param mapId the mapId to set
	 */
	public TrialJobMap withMapId(Long mapId) {
		this.mapId = mapId;
		return this;
	}
	
	

}
