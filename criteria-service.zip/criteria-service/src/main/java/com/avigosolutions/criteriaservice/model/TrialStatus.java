package com.avigosolutions.criteriaservice.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TrialStatus")
public class TrialStatus implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "TrialStatusId", nullable = false)
	private int id;

	
	public TrialStatus() {
		super();
	}

	public TrialStatus(String string) {
		
	} 
	
	
	public int getTrialStatusId() {
		return this.id;
	}

	public TrialStatus withTrialStatusId(int id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "TrialStatusName", nullable = false)	
	private String name;

	public String getName() {
		return this.name;
	}

	public TrialStatus withName(String name) {
		this.name = name;
		return this;
	}
	
	@Column(name = "CreatedBy")	
	private Long createdBy;

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public TrialStatus withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}
	
	@Column(name = "CreatedOn")	
	private Date createdOn;

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public TrialStatus withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}
	
	@Column(name = "UpdatedBy")	
	private Long updatedBy;

	public Long getUpdatedBy() {
		return this.updatedBy;
	}

	public TrialStatus withUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}
	
	@Column(name = "UpdatedOn")	
	private Date updatedOn;

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public TrialStatus withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
}
