package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.State;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {
		
	public List<City> findByCityNameContaining(String cityName, Pageable pageable);
	public List<City> findByCityNameContainingAndStateIdIn(String cityName,List<Long> stateList, Pageable pageable);
	public List<City> findByCityNameIn(List<String> cityNameList);
	public List<City> findByCityNameInAndStateStateNameInOrStateAbbrevIn(List<String> cityNameList,List<String> stateNameList,List<String> stateAbbrevList);
	public List<City> findByCityNameInAndStateStateNameIn(List<String> cityNameList,List<String> stateNameList);
	public List<City> findByCityNameInAndStateAbbrevIn(List<String> cityNameList,List<String> abbrevList);
}