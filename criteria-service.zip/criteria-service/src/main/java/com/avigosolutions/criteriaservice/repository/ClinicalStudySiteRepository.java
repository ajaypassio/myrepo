package com.avigosolutions.criteriaservice.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.dto.ClinicalStudySiteSiteStatistics;
import com.avigosolutions.criteriaservice.model.ClinicalStudySiteId;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.StudySite;

@Repository
public interface ClinicalStudySiteRepository  extends JpaRepository<ClinicalTrialStudySite, ClinicalStudySiteId>,JpaSpecificationExecutor<ClinicalTrialStudySite> {
	
	public List<ClinicalTrialStudySite> findByIsActiveTrueAndClinicalStudySiteIdId(Long id);
	
	public List<ClinicalTrialStudySite> findByClinicalStudySiteIdId(Long id);
	
	public List<ClinicalTrialStudySite> findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteIdNotIn(Long id,List<Long> StudySiteIds);
	
	public List<ClinicalTrialStudySite> findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteId(Long id,Long studySiteId);
	
	public List<ClinicalTrialStudySite> findByClinicalStudySiteIdIdIn(List<Long> ids);
	
	public List<ClinicalTrialStudySite> findByIsActiveTrueAndClinicalStudySiteIdIdIn(List<Long> ids);

	public List<ClinicalTrialStudySite> findByClinicalStudySiteIdStudySiteId(Long studySiteId);
	
	@Query(value="SELECT "
			+ "    new com.avigosolutions.criteriaservice.dto.ClinicalStudySiteSiteStatistics(v.clinicalStudySiteId.id, count(v)) "
			+ "FROM " + "    ClinicalTrialStudySite v WHERE v.clinicalStudySiteId.id in(:trialIds) "
			+ " GROUP BY " + "    v.clinicalStudySiteId.id")
	public List<ClinicalStudySiteSiteStatistics> countByClinicalStudySiteIdIdIn(@Param("trialIds") List<Long> trialIds);

}