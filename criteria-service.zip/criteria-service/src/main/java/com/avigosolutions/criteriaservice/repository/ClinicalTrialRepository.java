package com.avigosolutions.criteriaservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.response.model.StudySiteTrialResponse;

@Repository
public interface ClinicalTrialRepository
		extends JpaRepository<ClinicalTrial, Long>, JpaSpecificationExecutor<ClinicalTrial> {

	public Page<ClinicalTrial> findByProgramIdIsNull(Pageable pageable);

	public Page<ClinicalTrial> findAll(Pageable pageable);

	public Page<ClinicalTrial> findByTrialName(String trialName, Pageable pageable);

	public List<ClinicalTrial> findByTrialName(String trialName);

	public List<ClinicalTrial> findByTrialNameAndIdNot(String trialName, Long trialId);

	public List<ClinicalTrial> findByIdIn(List<Long> trialIds);

	public Page<ClinicalTrial> findByIdInAndTrialNameContaining(List<Long> trialIds, String trialName,
			Pageable pageable);

	public List<ClinicalTrial> findByProgramId(Long programId);

	public Page<ClinicalTrial> findByProgramId(Long programId, Pageable pageable);

	public Page<ClinicalTrial> findByProgramIdAndTrialNameContainingAndTherapeuticAreaIdInAndTrialStatusIdInAndTrialConditionIdIn(
			Long programId, String trialName, List<Long> therapeuticAreaIds, List<Integer> status,
			List<Long> trialConditionIds, Pageable pageable);

	public Page<ClinicalTrial> findByProgramIdInAndTrialNameContainingAndTherapeuticAreaIdInAndTrialStatusIdInAndTrialConditionIdIn(
			List<Long> programId, String trialName, List<Long> therapeuticAreaIds, List<Integer> status,
			List<Long> trialConditionIds, Pageable pageable);

	// trial Ids
	public Page<ClinicalTrial> findByIdIn(List<Long> trialIds, Pageable page);

	public Page<ClinicalTrial> findByTrialNameContaining(String trialName, Pageable page);

	public Page<ClinicalTrial> findByIdNotIn(List<Long> trialId, Pageable page);

	@Query(value = "select t.trialId, t.trialName from ClinicalTrial t left outer join ClinicalTrialStudySite s on t.TrialId=s.TrialId where s.StudySiteId =:studySiteId and t.trialName  like %:trialName%",nativeQuery = true) 
	public List<Object[]> getStudySiteTrialLikeDetails(@Param("studySiteId")Long studySiteId, @Param("trialName")String trialName);
	
	@Query(value = "select t.trialId,t.trialName from ClinicalTrial t left outer join ClinicalTrialStudySite s on t.TrialId=s.TrialId where s.StudySiteId =:studySiteId",nativeQuery = true) 
	public List<Object[]> getStudySiteTrialDetails(@Param("studySiteId")Long studySiteId);
	
	@Query(value = "select t.trialId, t.trialName from ClinicalTrial t where t.trialName  like %:trialName%",nativeQuery = true)
	public List<Object[]> getTrialNames(@Param("trialName")String trialName);
}
