package com.avigosolutions.criteriaservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avigosolutions.criteriaservice.model.Collaborator;

public interface CollaboratorRepository extends JpaRepository<Collaborator, Long> {

	Collaborator findByName(String name);
	
	Collaborator findByNameAndIdNot(String name, long collaboratorId);
}
