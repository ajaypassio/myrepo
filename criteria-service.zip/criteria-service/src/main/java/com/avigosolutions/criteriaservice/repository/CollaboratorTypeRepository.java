package com.avigosolutions.criteriaservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avigosolutions.criteriaservice.model.CollaboratorType;

public interface CollaboratorTypeRepository extends JpaRepository<CollaboratorType, Long> {


}
