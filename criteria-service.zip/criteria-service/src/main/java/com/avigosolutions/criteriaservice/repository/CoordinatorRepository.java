package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.model.State;

public interface CoordinatorRepository extends JpaRepository<Coordinator, Long> {
	public List<Coordinator> findByNameContaining(String name, Pageable pageable);
	public List<Coordinator> findByName(String name);
}
