package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.Criteria;

@Repository
public interface CriteriaRepository extends JpaRepository<Criteria, Long> {
	
	public List<Criteria> findByTrialId(Long trialId);
	
	public List<Criteria> findByTemplateId(Long templateId);
	
	public List<Criteria> findByIdIn(List<Long> Ids);
	public List<Criteria> findByTrialIdNotNull();
	/*;
	public List<Criteria> findAll();
	
	//public Criteria findOne(Long id);
	public Criteria findById(Long id);
	
	
	//public Criteria save(Criteria persisted);
	
	public void delete(Long id);*/
		
}
