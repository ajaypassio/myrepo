package com.avigosolutions.criteriaservice.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.avigosolutions.criteriaservice.model.CriteriaTemplate;
@Repository
public interface CriteriaTemplateRepository extends JpaRepository<CriteriaTemplate, Long> {
	public List<CriteriaTemplate> findAll();
	
	public CriteriaTemplate findById(Long id);
	
	public List<CriteriaTemplate> findByTemplateName(String TemplateName);
	public List<CriteriaTemplate> findByTemplateNameAndIdNot(String TemplateName,Long id);
		
}
