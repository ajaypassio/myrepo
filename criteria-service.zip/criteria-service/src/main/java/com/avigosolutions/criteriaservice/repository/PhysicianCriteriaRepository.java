package com.avigosolutions.criteriaservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.request.model.PhysicianCriteria;


@Repository
public interface PhysicianCriteriaRepository extends JpaRepository<PhysicianCriteria, String>, JpaSpecificationExecutor<String>{
	
	public Optional<PhysicianCriteria> findByUserName(String userName);
	
	@Query(value = "Select max(criteriaId) from PhysicianCriteria",nativeQuery=true)
	public Long getMaxCount();
	
	@Query(value = "select TOP(1) * from PhysicianCriteria where StatusId=4 order By CreatedOn DESC",nativeQuery=true)
	public Optional<PhysicianCriteria> getPhysicianDetailsByStatus();
	
}
