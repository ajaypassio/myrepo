package com.avigosolutions.criteriaservice.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.model.PrincipalInvestigator;

@Repository
public interface PrincipalInvestigatorRepository extends JpaRepository<PrincipalInvestigator, Long> {
	
	public PrincipalInvestigator findById(Long id);

	public List<PrincipalInvestigator> findByName(String investigatorName);
	
	public List<PrincipalInvestigator> findByNameContaining(String investigatorName, Pageable pageable);

	@Query(value = "SELECT pri.Project FROM PrincipalInvestigator pri left join StudySitePrincipalInvestigator sspi on pri.PrincipalInvestigatorId = sspi.PrincipalInvestigatorId where sspi.TrialId=?1 and pri.Project is not null",nativeQuery = true)
	public Set<String> getProjectListFindbyTrialId(Long trialId);

}
