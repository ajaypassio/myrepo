package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avigosolutions.criteriaservice.model.Collaborator;
import com.avigosolutions.criteriaservice.model.ProgramCollaborator;

public interface ProgramCollaboratorRepository extends JpaRepository<ProgramCollaborator, Long> {

	List<ProgramCollaborator>findByProgramId(Long programId);
	public List<ProgramCollaborator> findByCollaboratorIdIn(List<Long> collaboratorIdList);

}
