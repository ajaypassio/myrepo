package com.avigosolutions.criteriaservice.repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.avigosolutions.criteriaservice.model.Program;

@Repository
public interface ProgramRepository extends JpaRepository<Program, Long>, JpaSpecificationExecutor<Program> {

	Page<Program> findAll(Pageable page);

	Page<Program> findByDeletedFalse(Pageable page);

	Program findByName(String programName);

	Program findByNameAndProgramIdNot(String programName, long programId);

	Stream<Program> findByProgramIdIn(List<Long> trialIds);

	Optional<Program> findByProgramId(Long programId);

	List<Program> findByPhaseId(Long phaseId);

	List<Program> findByPhaseIdIn(List<Long> phaseIds);

	List<Program> findByTherapeuticAreaId(Long therapeuticAreaId);

	List<Program> findByTherapeuticAreaIdIn(List<Long> therapeuticAreaIds);

	List<Program> findBySponsorId(Long sponsorId);

	List<Program> findBySponsorIdIn(List<Long> sponsorIds);

	Page<Program> findByProgramId(Long programId, Pageable pageable);

	Page<Program> findBySponsorIdInAndTherapeuticAreaIdInAndDeletedFalse(List<Long> sponsorIds,
			List<Long> therapeuticAreaIds, Pageable pageable);

	Page<Program> findBySponsorIdInAndDeletedFalse(List<Long> sponsorIds, Pageable pageable);

	Page<Program> findByTherapeuticAreaIdInAndDeletedFalse(List<Long> therapeuticAreaIds, Pageable pageable);
	
}