package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.Questionnaire;


@Repository
public interface QuestionnaireRepository extends JpaRepository<Questionnaire,Long>,JpaSpecificationExecutor<Questionnaire> {

	List<Questionnaire> findAllById(Long questionnaireId);
	
	public Questionnaire findById(Long QuestionnaireId);
	
	public List<Questionnaire> findByName(String questionnaireName);
	public List<Questionnaire> findByNameAndIdNot(String questionnaireName,Long questionnaireId);
	
	public List<Questionnaire> findByIdIn(List<Long> questionnaireIds);
	
	public Page<Questionnaire> findAll(Pageable page);
}
