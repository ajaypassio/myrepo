package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.State;

@Repository
public interface StateRepository extends JpaRepository<State, Long> {
		
	public List<State> findByStateNameContaining(String stateName, Pageable pageable);
	
	public List<State> findByAbbrevIn(List<String> abbrev);
}