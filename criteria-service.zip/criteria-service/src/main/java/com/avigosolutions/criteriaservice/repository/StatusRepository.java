package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.Status;

@Repository
public interface StatusRepository extends JpaRepository<Status, Integer> {
	
}