package com.avigosolutions.criteriaservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.StudySiteAudit;
@Repository
public interface StudySiteAuditRepository extends JpaRepository<StudySiteAudit, Long>,JpaSpecificationExecutor<StudySiteAudit>{

}
