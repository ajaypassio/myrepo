package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;

@Repository
public interface StudySiteCoordinatorRepository extends JpaRepository<StudySiteCoordinator,Long>{

	public List<StudySiteCoordinator> findByStudySiteIdIn(List<Long> studySiteId);

	public List<StudySiteCoordinator> findByStudySiteId(Long id);
	
	public List<StudySiteCoordinator> findByCoordinatorId(Long id);
	
	public List<StudySiteCoordinator> findByCoordinatorIdIn(List<Long> coordinatorId);
	
	public List<StudySiteCoordinator> findByStudySiteIdAndTrialId(Long id,Long trialId);
	
	@Modifying
	@Transactional
	@Query(value="delete from  StudySiteCoordinator ss where ss.studySiteId = ?1 and "
			+ "(ss.trialId = ?2)")
	public void deleteByStudySiteIdAndTrialId(Long studySiteId,Long trialId);
	
	@Modifying
	@Transactional
	@Query(value="delete from  StudySiteCoordinator ss where ss.coordinatorId = ?1 ")
	public void deleteByCoordinatorId(Long coordinatorId);
	
	@Modifying
	@Transactional
	@Query(value="delete from  StudySiteCoordinator ss where ss.coordinatorId = ?1 and"
	+"(ss.trialId = ?2)")
	public void deleteByCoordinatorIdAndTrialId(Long coordinatorId,Long trialId);

	public Page<StudySiteCoordinator> findByCoordinatorId(Long id, Pageable page);
	
}
