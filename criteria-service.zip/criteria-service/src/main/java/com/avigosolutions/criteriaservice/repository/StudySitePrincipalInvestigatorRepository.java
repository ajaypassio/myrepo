package com.avigosolutions.criteriaservice.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.criteriaservice.model.StudySitePrincipalInvestigator;

@Repository
public interface StudySitePrincipalInvestigatorRepository extends JpaRepository<StudySitePrincipalInvestigator, Long> {

	public List<StudySitePrincipalInvestigator> findByStudySiteId(Long studySiteId);

	public List<StudySitePrincipalInvestigator> findByStudySiteIdAndTrialId(Long studySiteId, Long trialId);

	public List<StudySitePrincipalInvestigator> findByStudySiteIdAndTrialIdAndPrincipalInvestigatorId(Long studySiteId,
			Long trialId, Long principalInvestigatorId);

	public List<StudySitePrincipalInvestigator> findByStudySiteIdIn(List<Long> studySiteId);

	@Modifying
	@Transactional
	@Query(value = "delete from  StudySitePrincipalInvestigator ss where ss.studySiteId = ?1 and ss.trialId = ?2")
	public void deleteByStudySiteIdIdAndTrialId(Long studySiteId, Long trialId);

	@Query(value = "select principalInvestigatorId  from StudySitePrincipalInvestigator where studysiteId = :studySiteId", nativeQuery = true)
	public List<BigInteger> findprincipalInvestigatorIdByStudySiteId(@Param("studySiteId") Long studySiteId);

}
