
package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.StudySite;

@Repository
public interface StudySiteRepository extends JpaRepository<StudySite, Long>,JpaSpecificationExecutor<StudySite> {

	public List<StudySite> findByIdIn(List<Long> ids);

	public Page<StudySite> findByIdIn(List<Long> ids, Pageable page);

	public StudySite findById(Long id);

	public List<StudySite> findByStudySiteName(String studySiteName);

	public List<StudySite> findByStudySiteNameAndIdNot(String studySiteName, Long id);

	public List<StudySite> findByStudySiteNameAndZip(String studySiteName, String zip);

	List<StudySite> findByZip(String zip);

	List<StudySite> findByLatitudeInAndLongitudeIn( List<String> latList,  List<String> LngList);

	//Get study sites based on trail id, zipcode and miles (GeoRect object lat lang values passed as params)
	public List<StudySite> findByCinicalTrialStudySitesClinicalStudySiteIdIdAndLatitudeLessThanAndLatitudeGreaterThanAndLongitudeGreaterThanAndLongitudeLessThanAndActiveTrue(long trailId, double topLeftLat, double bottomRightLat, double topLeftLon, double bottomRightLon );

	//Get study sites based on trail id and zipcode
	public List<StudySite> findByCinicalTrialStudySitesClinicalStudySiteIdIdAndZip(long trailId, String zip);
	
	public List<StudySite> findByCinicalTrialStudySitesClinicalStudySiteIdIdAndZipAndActiveTrue(long trailId, String zip);
	
	public List<StudySite> findByCinicalTrialStudySitesClinicalStudySiteIdIdAndCinicalTrialStudySitesIsActiveTrueAndZipAndActiveTrue(long trailId, String zip);
	// Depricated native query
	@Query(value = "" + "SELECT" + "  s.*, (" + "    3959 * acos (" + "      cos ( radians(:latitude1) )"
			+ "      * cos( radians( Latitude ) )" + "      * cos( radians( Longitude) - radians(:longitude) )"
			+ "      + sin ( radians(:latitude2) )" + "      * sin( radians( latitude ) )" + "    )" + "  ) AS distance"
			+ " FROM studysite s " + " inner join clinicaltrialstudysite c on s.studysiteid=c.studysiteid "
			+ "where c.trialid=:trialId" + " HAVING distance <(:miles)" + " ORDER BY distance", nativeQuery = true)
	List<StudySite> findByMiles(@Param("latitude1") Float latitude1, @Param("latitude2") Float latitude2,
			@Param("longitude") Float Longitude, @Param("miles") Float miles, @Param("trialId") Long trialId);

	@Query(value = "" + "SELECT" + "  s.*, (" + "    3959 * acos (" + "      cos ( radians(:latitude1) )"
			+ "      * cos( radians( Latitude ) )" + "      * cos( radians( Longitude) - radians(:longitude) )"
			+ "      + sin ( radians(:latitude2) )" + "      * sin( radians( latitude ) )" + "    )" + "  ) AS distance"
			+ " FROM studysite s " + " inner join clinicaltrialstudysite c on s.studysiteid=c.studysiteid "
			+ "where c.trialid=:trialId" + " HAVING distance <(:miles)" + " ORDER BY distance", nativeQuery = true)
	List<StudySite> findByLatLngMiles(@Param("latitude1") String latitude1, @Param("latitude2") String latitude2,
			@Param("longitude") String Longitude, @Param("miles") Float miles, @Param("trialId") Long trialId);

	@Query(value = "select * FROM studysite s  where s.studysiteid not in(select c.studysiteid from clinicaltrialstudysite c where c.TrialId !=:trialId)", nativeQuery = true)
	public List<StudySite> findByNotTrailIdIn(@Param("trialId") Long trialId);

	public Page<StudySite> findByIdInAndStudySiteNameContaining(List<Long> Id, String studySiteName, Pageable pageable);
	
	public Page<StudySite> findByIdInAndStudySiteName(List<Long> Id, String studySiteName, Pageable pageable);

	public Page<StudySite> findByIdInAndStateInOrCityIn(List<Long> Id, List<String> stateName, List<String> City,
			Pageable pageable);

	public Page<StudySite> findByIdInAndStudySiteNameContainingAndActiveTrueAndStateInOrCityIn(List<Long> Id,
			String studySiteName, List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByIdInAndActiveTrueAndStateInOrCityIn(List<Long> Id, List<String> stateName,
			List<String> City, Pageable pageable);

	public Page<StudySite> findByIdInAndStudySiteNameContainingAndActiveFalse(List<Long> Id, String studySiteName,
			Pageable pageable);

	public Page<StudySite> findByIdInAndStudySiteNameContainingAndActiveTrue(List<Long> Id, String studySiteName,
			Pageable pageable);

	public Page<StudySite> findByIdInAndStateInOrCityInAndActiveFalse(List<Long> Id, List<String> stateName,
			List<String> City, Pageable pageable);

	public Page<StudySite> findByIdInAndStudySiteNameContainingAndStateInOrCityInAndActiveTrue(List<Long> Id,
			String studySiteName, List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByIdInAndStudySiteNameContainingAndStateInOrCityInAndActiveFalse(List<Long> Id,
			String studySiteName, List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByIdInAndStudySiteNameContainingAndStateInOrCityIn(List<Long> Id, String studySiteName,
			List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByIdInAndActiveTrue(List<Long> Id, Pageable pageable);

	public Page<StudySite> findByIdInAndActiveFalse(List<Long> Id, Pageable pageable);

	// Filter for StudySitepage:

	public Page<StudySite> findByStudySiteNameContaining(String studySiteName, Pageable pageable);

	public Page<StudySite> findByStateInOrCityIn(List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByStudySiteNameContainingAndActiveTrueAndStateInOrCityIn(String studySiteName,
			List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByActiveTrueAndStateInOrCityIn(List<String> stateName, List<String> City,
			Pageable pageable);

	public Page<StudySite> findByStudySiteNameContainingAndActiveFalse(String studySiteName, Pageable pageable);

	public Page<StudySite> findByStudySiteNameContainingAndActiveTrue(String studySiteName, Pageable pageable);

	public Page<StudySite> findByStateInOrCityInAndActiveFalse(List<String> stateName, List<String> City,
			Pageable pageable);

	public Page<StudySite> findByStudySiteNameContainingAndStateInOrCityInAndActiveTrue(String studySiteName,
			List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByStudySiteNameContainingAndStateInOrCityInAndActiveFalse(String studySiteName,
			List<String> stateName, List<String> City, Pageable pageable);

	public Page<StudySite> findByStudySiteNameContainingAndStateInOrCityIn(String studySiteName, List<String> stateName,
			List<String> City, Pageable pageable);

	public Page<StudySite> findByActiveTrue(Pageable pageable);

	public Page<StudySite> findByActiveFalse(Pageable pageable);

	// PiName filter & id
	public Page<StudySite> findByIdInAndStudySitePrincipalInvestigatorsPrincipalInvestigatorNameContaining(
			List<Long> id, String piName, Pageable pageable);

	// PiName filter Active False
	public Page<StudySite> findByIdInAndActiveFalseAndStudySitePrincipalInvestigatorsPrincipalInvestigatorNameContaining(
			List<Long> id, String piName, Pageable pageable);

	// PiName filter Active True
	public Page<StudySite> findByIdInAndActiveTrueAndStudySitePrincipalInvestigatorsPrincipalInvestigatorNameContaining(
			List<Long> id, String piName, Pageable pageable);
	
	@Query(value = "SELECT SOURCE='CRO', pri.[Npi] as NPI, pri.[PrincipalInvestigatorId], pri.[PrincipalInvestigatorName] as name, "  
			+ "	ss.[StudySiteName], ss.[Address1], ss.[Address2], ss.[City], ss.[State], ss.[Zip], pri.[Specialty], " 
			+ "	pri.[Project], pri.[PhoneNumber] as PHONE, pri.[EmailAddress] as EMAIL"
			+ " FROM [dbo].[PrincipalInvestigator] pri"
			+ " INNER JOIN [dbo].[StudySitePrincipalInvestigator] sspri ON pri.PrincipalInvestigatorId = sspri.PrincipalInvestigatorId"
			+ " INNER JOIN [dbo].[StudySite] ss ON sspri.StudySiteId = ss.StudySiteId"
			+ " INNER JOIN [dbo].[ClinicalTrialStudySite] css ON ss.StudySiteId = css.StudySiteId and sspri.TrialId = css.TrialId and sspri.StudySiteId = css.StudySiteId"
			+ " INNER JOIN [dbo].[ClinicalTrial] t ON css.TrialId = t.TrialId and sspri.TrialId = t.TrialId"
			+ " LEFT OUTER JOIN [dbo].[Program] p ON t.ProgramId = p.ProgramID"
			+ " WHERE SS.STUDYSITEID IN (:ids) AND t.TrialId=:trialId", nativeQuery = true)
	List<Object[]> findByStudySitesIn(@Param("ids") List<Long> ids, @Param("trialId") Long trialId);

}
