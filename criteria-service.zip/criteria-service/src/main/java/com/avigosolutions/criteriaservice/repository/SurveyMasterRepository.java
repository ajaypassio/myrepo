package com.avigosolutions.criteriaservice.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.SurveyMaster;


@Repository
public interface SurveyMasterRepository extends JpaRepository<SurveyMaster,Long>, Serializable{

	public Optional<List<SurveyMaster>>  findBySurveyTitle(String surveyTitle);	
	public SurveyMaster findBySprinttSurveyId(Long sprinttSurveyId); 
	public SurveyMaster findBySurveyId(String surveyId);
	public Optional<List<SurveyMaster>>  findBySurveyStatus(Byte surveyStatus);	
}
