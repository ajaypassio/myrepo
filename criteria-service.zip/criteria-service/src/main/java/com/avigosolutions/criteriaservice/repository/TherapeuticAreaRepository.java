package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.TherapeuticArea;

@Repository
public interface TherapeuticAreaRepository extends JpaRepository<TherapeuticArea, Long> {

	List<TherapeuticArea> findByNameContainingIgnoreCase(String keyword);

}
