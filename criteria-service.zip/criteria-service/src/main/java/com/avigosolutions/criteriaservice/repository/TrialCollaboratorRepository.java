package com.avigosolutions.criteriaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.TrialCollaborator;

@Repository
public interface TrialCollaboratorRepository extends JpaRepository<TrialCollaborator, Long> {

	public List<TrialCollaborator> findByCollaboratorIdIn(List<Long> collaboratorIdList);
	
	
}