package com.avigosolutions.criteriaservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.TrialJobMap;

@Repository
public interface TrialJobMapRepository extends JpaRepository<TrialJobMap, Long> {

	TrialJobMap findByCorrelationId(String correlationId);
	
	@Modifying
	@Query(value="UPDATE TrialJobMap SET JobStatus = ?2 WHERE MapId = (select top(1) t.MapId from TrialJobMap t where t.TrialId=?1 order by t.CreatedOn desc)",nativeQuery = true)
	public void updateTrailJobStatus(Long trialId , String jobStatus) ; 

	@Query(value = "select top(1) * from TrialJobMap t where t.TrialId=?1",nativeQuery = true)
    public TrialJobMap getLatestTrailJob(Long trailId); 
}

