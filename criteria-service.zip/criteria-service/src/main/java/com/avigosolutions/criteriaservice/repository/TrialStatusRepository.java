package com.avigosolutions.criteriaservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.criteriaservice.model.TrialStatus;

@Repository
public interface TrialStatusRepository extends JpaRepository<TrialStatus, Integer> {

	public TrialStatus findByid(Integer trialStatusId);
	
	
}