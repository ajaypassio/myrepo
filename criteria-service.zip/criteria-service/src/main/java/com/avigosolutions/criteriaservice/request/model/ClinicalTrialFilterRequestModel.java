package com.avigosolutions.criteriaservice.request.model;

import java.util.ArrayList;
import java.util.List;

public class ClinicalTrialFilterRequestModel {
	
	private int page;
	private int pageSize;
	private String sortDirection;
	private String sortBy;
	private List<Long> programIdList;
	private String trialName;
	private List<Integer> statusList;
	private List<Long> trialConditionList;
	private List<Long> collaboratorList;
	private List<Long> sponsorList;
	private List<Long> therapeuticAreaList;
	private List<Long> stageList;
	private List<Long> armList;
	private List<Integer> activeList;
	private Long coordinatorId;
	private List<Long> trialIdList;
	public List<Long> getTrialConditionList() {
		return trialConditionList;
	}
	
	public ClinicalTrialFilterRequestModel withTrialConditionList(List<Long> conditionList) {
		this.trialConditionList = conditionList;
		return this;
	}
	
	public List<Integer> getStatusList() {
		return statusList;
	}

	public ClinicalTrialFilterRequestModel withStatusList(List<Integer> statusList) {
		this.statusList = statusList;
		return this;
	}

	public List<Long> getCollaboratorList() {
		return collaboratorList;
	}

	public ClinicalTrialFilterRequestModel withCollaboratorList(List<Long> collaboratorList) {
		this.collaboratorList = collaboratorList;
		return this;
	}

	public List<Long> getSponsorList() {
		return sponsorList;
	}

	public ClinicalTrialFilterRequestModel withSponsorList(List<Long> sponsorList) {
		this.sponsorList = sponsorList;
		return this;
	}

	public List<Long> getTherapeuticAreaList() {
		return therapeuticAreaList;
	}

	public ClinicalTrialFilterRequestModel withTherapeuticAreaList(List<Long> therapeuticAreaList) {
		this.therapeuticAreaList = therapeuticAreaList;
		return this;
	}

	public List<Long> getStageList() {
		return stageList;
	}

	public ClinicalTrialFilterRequestModel withStageList(List<Long> stageList) {
		this.stageList = stageList;
		return this;
	}
	public List<Integer> getActiveList() {
		if(activeList==null) {
			activeList=new ArrayList<Integer>();
			activeList.add(1);
			activeList.add(0);
		}
		return activeList;
	}

	public ClinicalTrialFilterRequestModel withActiveList(List<Integer> activeList) {
		this.activeList = activeList;
		return this;
	}
	public List<Long> getArmList() {
		return armList;
	}

	public ClinicalTrialFilterRequestModel withArmList(List<Long> armList) {
		this.armList = armList;
		return this;
	}

	public int getPage() {
		return page;
	}

	public ClinicalTrialFilterRequestModel withPage(int page) {
		this.page = page;
		return this;
	}

	public int getPageSize() {
		return pageSize;
	}

	public ClinicalTrialFilterRequestModel withPageSize(int pageSize) {
		this.pageSize = pageSize;
		return this;
	}

	public String getSortDirection() {
		return sortDirection;
	}

	public ClinicalTrialFilterRequestModel withSortDirection(String sortDirection) {
		this.sortDirection = sortDirection;
		return this;
	}

	public String getSortBy() {
		return sortBy;
	}

	public ClinicalTrialFilterRequestModel withSortBy(String sortBy) {
		this.sortBy = sortBy;
		return this;
	}

	public String getTrialName() {
		return trialName;
	}

	public ClinicalTrialFilterRequestModel withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}


	public List<Long> getProgramIdList() {
		return programIdList;
	}

	public ClinicalTrialFilterRequestModel withProgramIdList(List<Long> programIdList) {
		this.programIdList = programIdList;
		return this;
	}
	
	public Long getCoordinatorId() {
		return coordinatorId;
	}

	public ClinicalTrialFilterRequestModel withCoordinatorId(Long coordinatorId) {
		this.coordinatorId = coordinatorId;
		return this;
	}

	public List<Long> getTrialIdList() {
		return trialIdList;
	}

	public void setTrialIdList(List<Long> trialIdList) {
		this.trialIdList = trialIdList;
	}
	

}
