package com.avigosolutions.criteriaservice.request.model;

import java.util.List;

public class FilterRequestModel {

	private int page;
	private int pageSize;
	private String sortDirection;
	private String sortBy;
	private Long programId;
	private String programName;
	private List<Integer> statusList;
	private List<Long> collaboratorList;
	private List<Long> sponsorList;
	private List<Long> therapeuticAreaList;
	private Long coordinatorId;

	private String name;
	private List<Integer> activeList;

	public List<Integer> getActiveList() {
		return activeList;
	}

	public FilterRequestModel withActiveList(List<Integer> activeList) {
		this.activeList = activeList;
		return this;
	}

	public List<Integer> getStatusList() {
		return statusList;
	}

	public FilterRequestModel withStatusList(List<Integer> statusList) {
		this.statusList = statusList;
		return this;
	}

	public List<Long> getCollaboratorList() {
		return collaboratorList;
	}

	public FilterRequestModel withCollaboratorList(List<Long> collaboratorList) {
		this.collaboratorList = collaboratorList;
		return this;
	}

	public List<Long> getSponsorList() {
		return sponsorList;
	}

	public FilterRequestModel withSponsorList(List<Long> sponsorList) {
		this.sponsorList = sponsorList;
		return this;
	}

	public List<Long> getTherapeuticAreaList() {
		return therapeuticAreaList;
	}

	public FilterRequestModel withTherapeuticAreaList(List<Long> therapeuticAreaList) {
		this.therapeuticAreaList = therapeuticAreaList;
		return this;
	}

	public int getPage() {
		return page;
	}

	public FilterRequestModel withPage(int page) {
		this.page = page;
		return this;
	}

	public int getPageSize() {
		return pageSize;
	}

	public FilterRequestModel withPageSize(int pageSize) {
		this.pageSize = pageSize;
		return this;
	}

	public String getSortDirection() {
		return sortDirection;
	}

	public FilterRequestModel withSortDirection(String sortDirection) {
		this.sortDirection = sortDirection;
		return this;
	}

	public String getSortBy() {
		return sortBy;
	}

	public FilterRequestModel withSortBy(String sortBy) {
		this.sortBy = sortBy;
		return this;
	}

	public String getProgramName() {
		return programName;
	}

	public FilterRequestModel withprogramName(String programName) {
		this.programName = programName;
		return this;
	}

	public Long getProgramId() {
		return programId;
	}

	public FilterRequestModel withProgramId(Long programId) {
		this.programId = programId;
		return this;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getCoordinatorId() {
		return coordinatorId;
	}

	public FilterRequestModel withCoordinatorId(Long coordinatorId) {
		this.coordinatorId = coordinatorId;
		return this;
	}

}
