package com.avigosolutions.criteriaservice.request.model;

import java.util.List;

public class LatLngModel {

	private List<Float> latList;
	
	private List<Float> lngList;

	public List<Float> getLngList() {
		return lngList;
	}

	public void setLngList(List<Float> lngList) {
		this.lngList = lngList;
	}

	public List<Float> getLatList() {
		return latList;
	}

	public void setLatList(List<Float> latList) {
		this.latList = latList;
	}
}
