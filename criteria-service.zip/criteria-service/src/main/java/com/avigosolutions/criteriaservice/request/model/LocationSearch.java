package com.avigosolutions.criteriaservice.request.model;

import java.util.List;

public class LocationSearch {
	private Long trialId;
	private Long studySiteId;
	private String cityName;
	private List<String> stateName;
	private int start;
	private int pageSize;
	private List<String> stateAbbrev;
	public Long getTrialId() {
		return trialId;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public String getCityName() {
		return cityName;
	}

	public List<String> getStateName() {
		return stateName;
	}

	public int getStart() {
		return start;
	}

	public int getPageSize() {
		return pageSize;
	}

	public  LocationSearch withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	public  LocationSearch withStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

	public  LocationSearch withCityName(String cityName) {
		this.cityName = cityName;
		return this;
	}

	public  LocationSearch withStateName(List<String> stateName) {
		this.stateName = stateName;
		return this;
	}

	public  LocationSearch withStart(int start) {
		this.start = start;
		return this;
	}

	public  LocationSearch withPageSize(int pageSize) {
		this.pageSize = pageSize;
		return this;
	}

	public List<String> getStateAbbrev() {
		return stateAbbrev;
	}

	public LocationSearch withStateAbbrev(List<String> stateAbbrev) {
		this.stateAbbrev = stateAbbrev;
		return this;
	}

}

