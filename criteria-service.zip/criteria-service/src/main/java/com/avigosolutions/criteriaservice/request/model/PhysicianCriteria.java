package com.avigosolutions.criteriaservice.request.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "PhysicianCriteria")
public class PhysicianCriteria implements Serializable {
	
	private static final long serialVersionUID = -1826223299667377759L;
	
	@Column(name = "CriteriaId", nullable = false)
	private Long criteriaId;
	
	@Column(name = "QueryName", nullable = false, columnDefinition = "nvarchar")
	private String queryName;
	
	@Id
	@Column(name = "UserName", nullable = false)
	private String userName;
	
	@Column(name = "InclusionCriteria", nullable = true, columnDefinition = "text")
	private String inclusionCriteria;
	
	@Column(name = "StatusId", nullable = false)
	private Long statusId;
	
	@Column(name = "TotalPhysicianCount", nullable = true)
	private Integer totalPhysicianCount;
	
	@Column(name = "TotalPatientsCount", nullable = true)
	private Integer totalPatientsCount;
	
	
	@Column(name = "IsCountClicked" ,columnDefinition = "TINYINT(1)")
	private boolean isCountClicked;
	
	@Column(name = "Remarks", nullable = true,  columnDefinition = "nvarchar")
	private String remarks;
	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;
	
	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz",timezone = "America/New_York")
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;
	
	@Transient
	@Column(name = "Save", nullable = true)
	private String save;
	
	@Transient
	@Column(name = "Count", nullable = true)
	private String count;
	
	@Transient
	@Column(name = "generatePhysicianResults", nullable = true)
	private String generatePhysicianResults;
	
	@Transient
	@Column(name = "createCampaign", nullable = true)
	private String createCampaign;
	
	@Transient
	@Column(name = "isPhysicianPopulated", nullable = true)
	private Boolean isPhysicianPopulated;

	@Column(name = "PhysicianLocation", nullable = true, columnDefinition = "text")
	private String physicianLocation;
	
	@Column(name = "Count1572", nullable = true)
	private Integer count1572;
	
	@Column(name = "CountQuest", nullable = true)
	private Integer CountQuest;
	
	@Column(name = "CountQuestAnd1572", nullable = true)
	private Integer CountQuestAnd1572;
	
	public Long getCriteriaId() {
		return criteriaId;
	}

	public void setCriteriaId(Long criteriaId) {
		this.criteriaId = criteriaId;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getInclusionCriteria() {
		return inclusionCriteria;
	}

	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}

	public Long getStatusId() {
		return statusId;
	}

	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	public Integer getTotalPhysicianCount() {
		return totalPhysicianCount;
	}

	public void setTotalPhysicianCount(Integer totalPhysicianCount) {
		this.totalPhysicianCount = totalPhysicianCount;
	}

	public Integer getTotalPatientsCount() {
		return totalPatientsCount;
	}

	public void setTotalPatientsCount(Integer totalPatientsCount) {
		this.totalPatientsCount = totalPatientsCount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public String getSave() {
		return save;
	}

	public void setSave(String save) {
		this.save = save;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhysicianLocation() {
		return physicianLocation;
	}

	public void setPhysicianLocation(String physicianLocation) {
		this.physicianLocation = physicianLocation;
	}

	public boolean isCountClicked() {
		return isCountClicked;
	}

	public void setCountClicked(boolean isCountClicked) {
		this.isCountClicked = isCountClicked;
	}

	public String getGeneratePhysicianResults() {
		return generatePhysicianResults;
	}

	public void setGeneratePhysicianResults(String generatePhysicianResults) {
		this.generatePhysicianResults = generatePhysicianResults;
	}

	public Integer getCount1572() {
		return count1572;
	}

	public void setCount1572(Integer count1572) {
		this.count1572 = count1572;
	}

	/**
	 * @return the countQuest
	 */
	public Integer getCountQuest() {
		return CountQuest;
	}

	/**
	 * @param countQuest the countQuest to set
	 */
	public void setCountQuest(Integer countQuest) {
		CountQuest = countQuest;
	}

	/**
	 * @return the countQuestAnd1572
	 */
	public Integer getCountQuestAnd1572() {
		return CountQuestAnd1572;
	}

	/**
	 * @param countQuestAnd1572 the countQuestAnd1572 to set
	 */
	public void setCountQuestAnd1572(Integer countQuestAnd1572) {
		CountQuestAnd1572 = countQuestAnd1572;
	}

	public String getCreateCampaign() {
		return createCampaign;
	}

	public void setCreateCampaign(String createCampaign) {
		this.createCampaign = createCampaign;
	}

	public Boolean getIsPhysicianPopulated() {
		return isPhysicianPopulated;
	}

	public void setIsPhysicianPopulated(Boolean isPhysicianPopulated) {
		this.isPhysicianPopulated = isPhysicianPopulated;
	}

}
