package com.avigosolutions.criteriaservice.request.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PhysicianCriteriaRequest {

	@JsonProperty(value = "criteriaId")
	private Long criteriaId;

	@JsonProperty(value = "queryName")
	private String queryName;

	@JsonProperty(value = "userName")
	private String userName;

	@JsonProperty(value = "inclusionCriteria")
	private String inclusionCriteria;

	@JsonProperty(value = "physicianLocation")
	private String physicianLocation;

	@JsonProperty(value = "statusId")
	private Long statusId;

	@JsonProperty(value = "countClicked")
	private boolean countClicked;

	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz", timezone = "America/New_York")
	@JsonProperty(value = "createdOn")
	private Date createdOn;

	@JsonFormat(pattern = "MM/dd/yyyy, hh:mm aa zzz", timezone = "America/New_York")
	@JsonProperty(value = "updatedOn")
	private Date updatedOn;

	public Long getCriteriaId() {
		return criteriaId;
	}

	public void setCriteriaId(Long criteriaId) {
		this.criteriaId = criteriaId;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getInclusionCriteria() {
		return inclusionCriteria;
	}

	public void setInclusionCriteria(String inclusionCriteria) {
		this.inclusionCriteria = inclusionCriteria;
	}

	public Long getStatusId() {
		return statusId;
	}

	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getPhysicianLocation() {
		return physicianLocation;
	}

	public void setPhysicianLocation(String physicianLocation) {
		this.physicianLocation = physicianLocation;
	}

	public boolean isCountClicked() {
		return countClicked;
	}

	public void setCountClicked(boolean countClicked) {
		this.countClicked = countClicked;
	}

}
