package com.avigosolutions.criteriaservice.request.model;

import java.util.Date;
import java.util.List;

public class QuestionnaireFilterRequestModel {
	
	private int page;
	private int pageSize;
	private String sortDirection;
	private String sortBy;
	private Long trialId;
	private Long questionnaireId;
	private Date filterStartDate;
	private Date filterEndDate;
	private List<Long> programList;
	private List<Long> collaboratorList;
	private List<Long> sponsorList;
	private List<Long> trialList;
	
	private String name;
	

	public List<Long> getTrialList() {
		return trialList;
	}

	public QuestionnaireFilterRequestModel withTrialList(List<Long> trialList) {
		this.trialList = trialList;
		return this;
	}

	public List<Long> getCollaboratorList() {
		return collaboratorList;
	}

	public QuestionnaireFilterRequestModel withCollaboratorList(List<Long> collaboratorList) {
		this.collaboratorList = collaboratorList;
		return this;
	}

	public List<Long> getSponsorList() {
		return sponsorList;
	}

	public QuestionnaireFilterRequestModel withSponsorList(List<Long> sponsorList) {
		this.sponsorList = sponsorList;
		return this;
	}

	public List<Long> getProgramList() {
		return programList;
	}

	public QuestionnaireFilterRequestModel withProgramNameList(List<Long> programList) {
		this.programList = programList;
		return this;
	}

	public int getPage() {
		return page;
	}

	public QuestionnaireFilterRequestModel withPage(int page) {
		this.page = page;
		return this;
	}

	public int getPageSize() {
		return pageSize;
	}

	public QuestionnaireFilterRequestModel withPageSize(int pageSize) {
		this.pageSize = pageSize;
		return this;
	}

	public String getSortDirection() {
		return sortDirection;
	}

	public QuestionnaireFilterRequestModel withSortDirection(String sortDirection) {
		this.sortDirection = sortDirection;
		return this;
	}

	public String getSortBy() {
		return sortBy;
	}

	public QuestionnaireFilterRequestModel withSortBy(String sortBy) {
		this.sortBy = sortBy;
		return this;
	}

	public Long getQuestionnaireId() {
		return questionnaireId;
	}

	public QuestionnaireFilterRequestModel withQuestionnaireId(Long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	public Long getTrialId() {
		return trialId;
	}

	public QuestionnaireFilterRequestModel withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the filterStartDate
	 */
	public Date getFilterStartDate() {
		return filterStartDate;
	}

	/**
	 * @param filterStartDate the filterStartDate to set
	 * @return QuestionnaireFilterRequestModel
	 */
	public QuestionnaireFilterRequestModel withFilterStartDate(Date filterStartDate) {
		this.filterStartDate = filterStartDate;
		return this;
	}

	/**
	 * @return the filterEndDate
	 */
	public Date getFilterEndDate() {
		return filterEndDate;
	}

	/**
	 * @param filterEndDate the filterEndDate to set
	 * @return QuestionnaireFilterRequestModel
	 */
	public QuestionnaireFilterRequestModel withFilterEndDate(Date filterEndDate) {
		this.filterEndDate = filterEndDate;
		return this;
	}
}
