package com.avigosolutions.criteriaservice.request.model;

import java.util.Date;
import java.util.List;

public class StudySiteFilterRequestModel {

	private int page;
	
	private int pageSize;
	
	private String studySiteName;

	private String piName;

	private List<String> cities;

	private List<String> states;

	private boolean active;

	private boolean disabled;
	
	private String columnToSort;
	
	private String sortType;
	
	private List<Long> sponsorList;
	
	private List<Long> collaboratorList;
	
	private List<Long> studySiteIds;
	
	private List<Long> coordinatorList;
	
	private Date fromDate;
	
	private Date toDate;
	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public String getStudySiteName() {
		return studySiteName;
	}

	public void setStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
	}

	public String getPiName() {
		return piName;
	}

	public void setPiName(String piName) {
		this.piName = piName;
	}

	public List<String> getCities() {
		return cities;
	}

	public void setCities(List<String> cities) {
		this.cities = cities;
	}

	public List<String> getStates() {
		return states;
	}

	public void setStates(List<String> states) {
		this.states = states;
	}

	

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	public String getColumnToSort() {
		return columnToSort;
	}

	public void setColumnToSort(String columnToSort) {
		this.columnToSort = columnToSort;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public List<Long> getStudySiteIds() {
		return studySiteIds;
	}

	public void setStudySiteIds(List<Long> studySiteIds) {
		this.studySiteIds = studySiteIds;
	}

	/**
	 * @return the fromDate
	 */
	public Date getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public Date getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the sponsorList
	 */
	public List<Long> getSponsorList() {
		return sponsorList;
	}

	/**
	 * @param sponsorList the sponsorList to set
	 */
	public void setSponsorList(List<Long> sponsorList) {
		this.sponsorList = sponsorList;
	}

	/**
	 * @return the collaboratorList
	 */
	public List<Long> getCollaboratorList() {
		return collaboratorList;
	}

	/**
	 * @param collaboratorList the collaboratorList to set
	 */
	public void setCollaboratorList(List<Long> collaboratorList) {
		this.collaboratorList = collaboratorList;
	}

	public List<Long> getCoordinatorList() {
		return coordinatorList;
	}

	public void setCoordinatorList(List<Long> coordinatorList) {
		this.coordinatorList = coordinatorList;
	}

}
