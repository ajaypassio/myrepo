package com.avigosolutions.criteriaservice.request.model;

public class StudySiteRadiusRequestModel {
	
	private Long trialId;
	
	private Long studySiteId;
	
	private int page;
	
	private int pageSize;
	
	/*private String columnToSort;
	
	private String sortType;*/
	
	//private boolean active;
	
	private String studySiteName;
	
	private String radiusValue;
	
	private boolean radiusExempt;

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/*public String getColumnToSort() {
		return columnToSort;
	}

	public void setColumnToSort(String columnToSort) {
		this.columnToSort = columnToSort;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
*/
	public String getStudySiteName() {
		return studySiteName;
	}

	public void setStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
	}

	public String getRadiusValue() {
		return radiusValue;
	}

	public void setRadiusValue(String radiusValue) {
		this.radiusValue = radiusValue;
	}

	public boolean isRadiusExempt() {
		return radiusExempt;
	}

	public void setRadiusExempt(boolean radiusExempt) {
		this.radiusExempt = radiusExempt;
	}
	
}
