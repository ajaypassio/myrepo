package com.avigosolutions.criteriaservice.request.model;

import java.util.List;

public class StudySiteRequestModel {
	private Long trialId;
	
	private List<Long> studySiteId;

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public List<Long> getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(List<Long> studySiteId) {
		this.studySiteId = studySiteId;
	}
}
