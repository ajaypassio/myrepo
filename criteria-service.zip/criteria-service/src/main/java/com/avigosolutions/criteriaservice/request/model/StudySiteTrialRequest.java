package com.avigosolutions.criteriaservice.request.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StudySiteTrialRequest {

	@JsonProperty("studySiteId")
	private Long studySiteId;
	
	@JsonProperty("trialName")
	private String trialName;

	public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	@Override
	public String toString() {
		return "StudySiteTrialRequest [studySiteId=" + studySiteId + ", trialName=" + trialName + "]";
	}
}
