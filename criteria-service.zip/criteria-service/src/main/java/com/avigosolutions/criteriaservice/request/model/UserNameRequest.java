package com.avigosolutions.criteriaservice.request.model;

public class UserNameRequest {

	private String userName;
	
	private String source;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "UserNameRequest [userName=" + userName + ", source=" + source + "]";
	}
	
}
