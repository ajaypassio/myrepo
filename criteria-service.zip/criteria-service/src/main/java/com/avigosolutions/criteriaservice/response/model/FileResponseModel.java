package com.avigosolutions.criteriaservice.response.model;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.dto.StudySiteCSVBean;
import com.avigosolutions.criteriaservice.dto.StudySiteLightWeightDTO;

@Component
public class FileResponseModel {
	private HttpStatus status;

	private String message;

	private List<RowDetail> statusRows;

	private int successRows;

	private int invalidRows;

	private int totalRows;

	private int newlyAddedRowCount;

	private int existingRowCount;
	
	private List<StudySiteCSVBean> errorRows;
	
	private List<StudySiteLightWeightDTO> studySiteList;
 
	public int getNewlyAddedRowCount() {
		return newlyAddedRowCount;
	}

	public void setNewlyAddedRowCount(int newlyAddedRowCount) {
		this.newlyAddedRowCount = newlyAddedRowCount;
	}

	public int getExistingRowCount() {
		return existingRowCount;
	}

	public void setExistingRowCount(int existingRowCount) {
		this.existingRowCount = existingRowCount;
	}
	
	public int getStatus() {
		if(null!=status) {
			return status.value();
		}
		return 0;
	}

	public HttpStatus getHttpStatus() {
		return status;
	}

	public void setHttpStatus(HttpStatus status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<RowDetail> getStatusRows() {
		return statusRows;
	}

	public void setStatusRows(List<RowDetail> statusRows) {
		this.statusRows = statusRows;
	}

	public int getSuccessRows() {
		return successRows;
	}

	public void setSuccessRows(int successRows) {
		this.successRows = successRows;
	}

	public int getInvalidRows() {
		return invalidRows;
	}

	public void setInvalidRows(int invalidRows) {
		this.invalidRows = invalidRows;
	}

	public int getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(int totalRows) {
		this.totalRows = totalRows;
	}

	public List<StudySiteCSVBean> getErrorRows() {
		return errorRows;
	}

	public void setErrorRows(List<StudySiteCSVBean> errorRows) {
		this.errorRows = errorRows;
	}

	public List<StudySiteLightWeightDTO> getStudySiteList() {
		return studySiteList;
	}

	public void setStudySiteList(List<StudySiteLightWeightDTO> studySiteList) {
		this.studySiteList = studySiteList;
	}
	
}
