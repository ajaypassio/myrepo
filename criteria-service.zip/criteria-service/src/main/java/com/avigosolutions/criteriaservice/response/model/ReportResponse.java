package com.avigosolutions.criteriaservice.response.model;

public class ReportResponse {
	
	private Long countSites;
	private Long countCollaborators;
	private Long countSponsors;
	private Long countPrograms;
	private Long countTrials;
	private Long countActiveSites;
	private Long countSitesWithTrials;
	/**
	 * @return the countSites
	 */
	public Long getCountSites() {
		return countSites;
	}
	/**
	 * @param countSites the countSites to set
	 */
	public ReportResponse withCountSites(Long countSites) {
		this.countSites = countSites;
		return this;
	}
	/**
	 * @return the countCollaborators
	 */
	public Long getCountCollaborators() {
		return countCollaborators;
	}
	/**
	 * @param countCollaborators the countCollaborators to set
	 */
	public ReportResponse withCountCollaborators(Long countCollaborators) {
		this.countCollaborators = countCollaborators;
		return this;
	}
	/**
	 * @return the countSponsors
	 */
	public Long getCountSponsors() {
		return countSponsors;
	}
	/**
	 * @param countSponsors the countSponsors to set
	 */
	public ReportResponse withCountSponsors(Long countSponsors) {
		this.countSponsors = countSponsors;
		return this;
	}
	/**
	 * @return the countPrograms
	 */
	public Long getCountPrograms() {
		return countPrograms;
	}
	/**
	 * @param countPrograms the countPrograms to set
	 */
	public ReportResponse withCountPrograms(Long countPrograms) {
		this.countPrograms = countPrograms;
		return this;
	}
	/**
	 * @return the countTrials
	 */
	public Long getCountTrials() {
		return countTrials;
	}
	/**
	 * @param countTrials the countTrials to set
	 */
	public ReportResponse withCountTrials(Long countTrials) {
		this.countTrials = countTrials;
		return this;
	}
	/**
	 * @return the countActiveSites
	 */
	public Long getCountActiveSites() {
		return countActiveSites;
	}
	/**
	 * @param countActiveSites the countActiveSites to set
	 */
	public ReportResponse withCountActiveSites(Long countActiveSites) {
		this.countActiveSites = countActiveSites;
		return this;
	}
	
	/**
	 * @return the countSitesWithTrials
	 */
	public Long getCountSitesWithTrials() {
		return countSitesWithTrials;
	}
	/**
	 * @param countSitesWithTrials the countSitesWithTrials to set
	 */
	public ReportResponse withCountSitesWithTrials(Long countSitesWithTrials) {
		this.countSitesWithTrials = countSitesWithTrials;
		return this;
	}
	
	

}
