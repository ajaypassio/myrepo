package com.avigosolutions.criteriaservice.response.model;

public class RowDetail{
	int rowNumber;
	public int getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	public String getRowMessage() {
		return rowMessage;
	}
	public void setRowMessage(String rowMessage) {
		this.rowMessage = rowMessage;
	}
	String rowMessage;
}
