package com.avigosolutions.criteriaservice.response.model;

import java.util.List;

public class StudySiteReportResponse {
	
	private Long studySiteId;
	private Long trialId;
	private String zip;
	private String studySiteName;
	private List<String> trialNameList;
	private String trialName;
	private List<String> programNameList;
	private String programName;
	private List<String> principalInvestigatorNames;
	private String coordinator;
	private String programTherapeuticAreaName;
	private String programCollaboratorName;
	private String programSponsorName;
	private String trialTherapeuticAreaName;
	
	
	public StudySiteReportResponse(){
		this.programName="";
		this.trialName="";
		this.coordinator="";
		this.zip="";
		this.studySiteName="";
		this.programCollaboratorName="";
		this.programSponsorName="";
		this.programTherapeuticAreaName="";
		this.trialTherapeuticAreaName="";
	}
	
	/**
	 * @return the studySiteId
	 */
	public Long getStudySiteId() {
		return studySiteId;
	}
	/**
	 * @param studySiteId the studySiteId to set
	 */
	public StudySiteReportResponse withStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}
	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}
	/**
	 * @param trialId the trialId to set
	 */
	public StudySiteReportResponse withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}
	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}
	/**
	 * @param zip the zip to set
	 */
	public StudySiteReportResponse withZip(String zip) {
		this.zip = zip;
		return this;
	}
	/**
	 * @return the studySiteName
	 */
	public String getStudySiteName() {
		return studySiteName;
	}
	/**
	 * @param studySiteName the studySiteName to set
	 */
	public StudySiteReportResponse withStudySiteName(String studySiteName) {
		this.studySiteName = studySiteName;
		return this;
	}
	/**
	 * @return the trialNameList
	 */
	public List<String> getTrialNameList() {
		return trialNameList;
	}
	
	/**
	 * @return the trialName
	 */
	public String getTrialName() {
		return trialName;
	}
	/**
	 * @param trialNameList the trialNameList to set
	 */
	public StudySiteReportResponse withTrialNameList(List<String> trialNameList) {
		this.trialNameList = trialNameList;
		return this;
	}
	
	/**
	 * @param trialName the trialName to set
	 */
	public StudySiteReportResponse withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}
	
	/**
	 * @return the programNameList
	 */
	public List<String> getProgramNameList() {
		return programNameList;
	}
	
	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}
	
	/**
	 * @param programNameList the programNameList to set
	 */
	public StudySiteReportResponse withProgramNameList(List<String> programNameList) {
		this.programNameList = programNameList;
		return this;
	}
	
	/**
	 * @param programName the programName to set
	 */
	public StudySiteReportResponse withProgramName(String programName) {
		this.programName = programName;
		return this;
	}
	/**
	 * @return the principalInvestigatorNames
	 */
	public List<String> getPrincipalInvestigatorNames() {
		return principalInvestigatorNames;
	}
	/**
	 * @param principalInvestigatorNames the principalInvestigatorNames to set
	 */
	public StudySiteReportResponse withPrincipalInvestigatorNames(List<String> principalInvestigatorNames) {
		this.principalInvestigatorNames = principalInvestigatorNames;
		return this;
	}
	/**
	 * @return the coordinator
	 */
	public String getCoordinator() {
		return coordinator;
	}
	/**
	 * @param coordinator the coordinator to set
	 */
	public StudySiteReportResponse withCoordinator(String coordinator) {
		this.coordinator = coordinator;
		return this;
	}

	/**
	 * @return the programTherapeuticAreaName
	 */
	public String getProgramTherapeuticAreaName() {
		return programTherapeuticAreaName;
	}

	/**
	 * @param programTherapeuticAreaName the programTherapeuticAreaName to set
	 */
	public StudySiteReportResponse withProgramTherapeuticAreaName(String programTherapeuticAreaName) {
		this.programTherapeuticAreaName = programTherapeuticAreaName;
		return this;
	}

	/**
	 * @return the programCollaboratorName
	 */
	public String getProgramCollaboratorName() {
		return programCollaboratorName;
	}

	/**
	 * @param programCollaboratorName the programCollaboratorName to set
	 */
	public StudySiteReportResponse withProgramCollaboratorName(String programCollaboratorName) {
		this.programCollaboratorName = programCollaboratorName;
		return this;
	}

	/**
	 * @return the programSponsorName
	 */
	public String getProgramSponsorName() {
		return programSponsorName;
	}

	/**
	 * @param programSponsorName the programSponsorName to set
	 */
	public StudySiteReportResponse withProgramSponsorName(String programSponsorName) {
		this.programSponsorName = programSponsorName;
		return this;
	}

	/**
	 * @return the trialTherapeuticAreaName
	 */
	public String getTrialTherapeuticAreaName() {
		return trialTherapeuticAreaName;
	}

	/**
	 * @param trialTherapeuticAreaName the trialTherapeuticAreaName to set
	 */
	public StudySiteReportResponse withTrialTherapeuticAreaName(String trialTherapeuticAreaName) {
		this.trialTherapeuticAreaName = trialTherapeuticAreaName;
		return this;
	}


	
	

}
