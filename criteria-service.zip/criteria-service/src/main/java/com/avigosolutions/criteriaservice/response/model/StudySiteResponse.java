package com.avigosolutions.criteriaservice.response.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.model.StudySite;

@Component
public class StudySiteResponse {
	Long id = 0l;

	public StudySiteResponse() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public List<StudySiteDto> getMatchedStudySites() {
		return matchedStudySites;
	}

	public void setMatchedStudySites(List<StudySiteDto> matchedStudySites) {
		this.matchedStudySites = matchedStudySites;
	}
	public List<StudySiteDto> getSuggestedStudySites() {
		return suggestedStudySites;
	}

	public void setSuggestedStudySites(List<StudySiteDto> suggestedStudySites) {
		this.suggestedStudySites = suggestedStudySites;
	}
	private List<StudySiteDto> matchedStudySites;
	private List<StudySiteDto> suggestedStudySites;
}
