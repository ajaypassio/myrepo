package com.avigosolutions.criteriaservice.response.model;

public class StudySiteTrialResponse {

	private Long trialId;
	
	private String trialName;

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	@Override
	public String toString() {
		return "StudySiteTrialResponse [trialId=" + trialId + ", trialName=" + trialName + "]";
	}
		
}
