package com.avigosolutions.criteriaservice.response.model;

public class TrialOrProgramResponse {

	private Long trialId;
	private String trialName;
	
	private Long programId;
	private String programName;
	
	public Long getTrialId() {
		return trialId;
	}
	public String getTrialName() {
		return trialName;
	}
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}
	public Long getProgramId() {
		return programId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramId(Long programId) {
		this.programId = programId;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	
}
