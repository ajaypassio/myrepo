package com.avigosolutions.criteriaservice.service;

import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface ArmService {

	ResponseObjectModel getAll(int page,int pageSize);
}
