package com.avigosolutions.criteriaservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.criteriaservice.model.Arm;
import com.avigosolutions.criteriaservice.repository.ArmRepository;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.util.CommonUtil;
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ArmServiceImp implements ArmService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ArmRepository armRepository;
	
	@Override
	public ResponseObjectModel getAll(int page, int pageSize) {
		ResponseObjectModel responseObject=new ResponseObjectModel();
		PageRequest pageRequest=CommonUtil.getPageRequest(page, pageSize);
		try {
			Page<Arm> pageList=armRepository.findAll(pageRequest);
			responseObject.setData(pageList.getContent());
			responseObject.setTotal(pageList.getTotalElements());
			responseObject.setHttpStatus(HttpStatus.OK);
		} catch(Exception e) {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
		}
		return responseObject;
	}

}
