package com.avigosolutions.criteriaservice.service;

import java.util.List;

import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.messaging.models.TrialJobStatusModel;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.TrialCondition;
import com.avigosolutions.criteriaservice.model.Phase;
import com.avigosolutions.criteriaservice.model.Sponsor;
import com.avigosolutions.criteriaservice.model.Status;
import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.model.TrialStatus;
import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteTrialRequest;
import com.avigosolutions.criteriaservice.request.model.TrialDetails;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;


public interface ClinicalTrialService {
	/**
	 * returns all the Clinical Trials in the system
	 * 
	 * @return
	 */
	public List<ClinicalTrial> findAll();
	
	/*
	 * returns all the clinical trials with criteria * 
	 */
	public ResponseObjectModel findAllWithCriteriaOnly(int start, int pageSize,String trialName);
	/**
	 * Finds a Clinical Trial based on the id
	 * 
	 * @param id
	 * @return a Clinical Trial, or null if not found
	 */
	public ClinicalTrial findOne(Long id);

	/**
	 * Saves the Clinical Trial
	 * 
	 * @param clinicalTrialToBePersisted
	 * @return Clinical Trial that saved or null if there was an error
	 */
	public ResponseObjectModel save(ClinicalTrial clinicalTrialToBePersisted);

	/**
	 * Updates the Clinical Trial
	 * 
	 * @param clinicalTrialToBePersisted
	 * @return a Clinical Trial that was updated
	 */
	public ResponseObjectModel update(ClinicalTrial clinicalTrialToBePersisted);

	/**
	 * deletes the Clinical Trial
	 * 
	 * @param id
	 */
	public void delete(Long id);

	/**
	 * Returns the statuses of Clinical Trials
	 * 
	 * @return
	 */
	public List<TrialStatus> getAllTrialStatuses();

	/**
	 * Returns the conditions of Clinical Trials
	 * 
	 * @return
	 */
	public List<TrialCondition> getAllTrialConditions();

	/*
	 * get number of trial conditions
	 */
	public ResponseObjectModel getAllTrialConditions(int page, int pageSize);

	/*
	 * get all trial status list
	 * 
	 */
	public List<Status> getAllStatus();

	/*
	 * get trial based on trial ids
	 */
	public List<ClinicalTrial> findByTrialIdIn(List<Long> trialIds);

	/*
	 * Filter trials by different fileds
	 * 
	 */

	ResponseObjectModel findAll(ClinicalTrialFilterRequestModel filterModel);

	/*
	 * get all the therapeuticarea list
	 */
	List<TherapeuticArea> getAllTherapeuticAreas();

	/*
	 * get trials based on program
	 */

	List<ClinicalTrial> getClinicalTrialsByProgramId(long programId);
	
	

	/*
	 * get trials unassociated programs
	 */
	ResponseObjectModel findAllUnAssociatedProgram(ClinicalTrialFilterRequestModel filterModel);	
	
	/*method for coordinators*/
	List<ClinicalTrial> findAll(Long coordinatorId);	
	
	public void delete(Long id,Long coordinatorId);
	
	ResponseObjectModel findAll(ClinicalTrialFilterRequestModel filterModel,Long coordinatorId);	
	
	public ResponseObjectModel getTrialsByPageCriteria(ClinicalTrialFilterRequestModel filterModel);
	
	public boolean updateTrialCollectionStatus(TrialJobStatusModel statusmodel);

	public ResponseObjectModel getAllTherapeuticAreasByKeyword(String keyword);

	public ResponseObjectModel getAllTrialConditionsByKeyword(String keyword);

	public ResponseObjectModel updateTrialRadiusOverride(Long trialId, boolean radiusOverride);
	
	public ResponseObjectModel updateTrialStudySiteIgnore(Long trialId);
	
	//Inclusion Exclusion change	
    public String updateInExCriteria(long trialId);
    public long getLatestTrailJob(Long trailId);
    
    public ResponseObjectModel getStudySiteTrialDetails(StudySiteTrialRequest studySiteTrialRequest);
    
    public ResponseObjectModel addTherapeuticArea(TrialDetails trialDetails);
    public ResponseObjectModel addTrialCondition(TrialDetails trialDetails);
}
