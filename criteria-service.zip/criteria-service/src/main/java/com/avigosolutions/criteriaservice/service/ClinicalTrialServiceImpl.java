package com.avigosolutions.criteriaservice.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.criteriaservice.constant.Constants;
import com.avigosolutions.criteriaservice.dto.CRMCategory;
import com.avigosolutions.criteriaservice.dto.ClinicalTrialStudySiteLightWeightDTO;
import com.avigosolutions.criteriaservice.dto.CountModel;
import com.avigosolutions.criteriaservice.dto.StudySiteLightWeightDTO;
import com.avigosolutions.criteriaservice.json.parser.JSONContractParserIE;
import com.avigosolutions.criteriaservice.json.parser.container.ContainerType;
import com.avigosolutions.criteriaservice.messaging.InclusionExclusionPublisher;
import com.avigosolutions.criteriaservice.messaging.StudySiteCroPublisher;
import com.avigosolutions.criteriaservice.messaging.models.CROClinician;
import com.avigosolutions.criteriaservice.messaging.models.TrialJobStatusModel;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.model.PrincipalInvestigator;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.model.ProgramStatus;
import com.avigosolutions.criteriaservice.model.Status;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;
import com.avigosolutions.criteriaservice.model.StudySitePrincipalInvestigator;
import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.model.TrialCollaborator;
import com.avigosolutions.criteriaservice.model.TrialCondition;
import com.avigosolutions.criteriaservice.model.TrialJobMap;
import com.avigosolutions.criteriaservice.model.TrialStatus;
import com.avigosolutions.criteriaservice.repository.ArmRepository;
import com.avigosolutions.criteriaservice.repository.ClinicalStudySiteRepository;
import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
import com.avigosolutions.criteriaservice.repository.ConditionRepository;
import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
import com.avigosolutions.criteriaservice.repository.PhaseRepository;
import com.avigosolutions.criteriaservice.repository.PrincipalInvestigatorRepository;
import com.avigosolutions.criteriaservice.repository.ProgramRepository;
import com.avigosolutions.criteriaservice.repository.ProgramStatusRepository;
import com.avigosolutions.criteriaservice.repository.SponsorRepository;
import com.avigosolutions.criteriaservice.repository.StageRepository;
import com.avigosolutions.criteriaservice.repository.StatusRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteCoordinatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySitePrincipalInvestigatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteRepository;
import com.avigosolutions.criteriaservice.repository.TherapeuticAreaRepository;
import com.avigosolutions.criteriaservice.repository.TrialConditionRepository;
import com.avigosolutions.criteriaservice.repository.TrialJobMapRepository;
import com.avigosolutions.criteriaservice.repository.TrialStatusRepository;
import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteTrialRequest;
import com.avigosolutions.criteriaservice.request.model.TrialDetails;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.StudySiteTrialResponse;
import com.avigosolutions.criteriaservice.util.CommonUtil;
import com.avigosolutions.criteriaservice.util.SpringSpecifications;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ClinicalTrialServiceImpl implements ClinicalTrialService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@PersistenceContext
	private EntityManager manager;
	private final int TRIAL_STATUS_ACTIVE = 1;
	private final String JOB_STATUS_DONE = "done";
	private final String JOB_STATUS_DEAD = "dead";
	private final String JOB_STATUS_SUCCESS = "success";

	@Autowired
	private ClinicalTrialRepository clinicalTrialRepository;
	@Autowired
	private InclusionExclusionPublisher inclusionExclusionPublisher;
	@Autowired
	private CriteriaRepository criteriaRepository;

	@Autowired
	private TrialStatusRepository trialStatusRepository;

	@Autowired
	private StatusRepository statusRepository;

	@Autowired
	private ProgramRepository programRepository;

	@Autowired
	private ProgramStatusRepository programStatusRepository;

	@Autowired
	private PhaseRepository phaseRepository;

	@Autowired
	private ConditionRepository conditionRepository;

	@Autowired
	private TherapeuticAreaRepository therapeuticAreaRepository;

	@Autowired
	private StageRepository stageRepository;

	@Autowired
	private SponsorRepository sponsorRepository;

	@Autowired
	private ArmRepository armRepository;

	@Autowired
	private StudySiteCoordinatorRepository studySiteCoordinatorRepository;

	@Autowired
	private ClinicalStudySiteRepository clinicalStudySiteRepository;

	@Autowired
	private TrialJobMapRepository trialJobMapRepository;

	@Autowired
	private PrincipalInvestigatorRepository principalInvestigatorRepository;

	@Autowired
	private StudySitePrincipalInvestigatorRepository studySitePrincipalInvestigatorRepository;

	@Autowired
	private StudySiteRepository studySiteRepository;

	@Autowired
	private StudySiteCroPublisher studySiteCroPublisher;

	@Autowired
	JSONContractParserIE uiJSONContractParser;

	@Value("${sprintt.participant.status.service.url}")
	private String participantStatusUrl;

	@Value("${sprintt.participant.service.categoryurl}")
	String participantServiceCRMCategoryURL;

	@Value("${sprintt.ranking.service.checkpatientcollectionurl}")
	String checkpatientcollectionurl;
	
	@Autowired
	private TrialConditionRepository trialConditionRepository;

	List<CountModel> getParticipantStudySite(List<Long> trialId, List<Long> statusId) {
		RestTemplate restTemplate = new RestTemplate();
		MultiValueMap<String, List<Long>> map = new LinkedMultiValueMap<String, List<Long>>();
		map.add("trial", trialId);
		map.add("status", statusId);
		ResponseObjectModel responseObject = restTemplate.postForObject(participantStatusUrl, map,
				ResponseObjectModel.class);
		List<Object> lstObjects = (List<Object>) responseObject.getData();
		List<CountModel> lstCount = new ArrayList<CountModel>();
		for (Object obj : lstObjects) {
			logger.info(obj.toString());
			ObjectMapper m = new ObjectMapper();
			CountModel countModel = m.convertValue(obj, CountModel.class);
			logger.info(countModel.toString());
			lstCount.add(countModel);
		}
		return lstCount;
	}

	@Override
	public List<ClinicalTrial> findByTrialIdIn(List<Long> trialIds) {
		List<ClinicalTrial> trialList = clinicalTrialRepository.findByIdIn(trialIds);
		for (ClinicalTrial clinicalTrial : trialList) {
			populateTrialAttributes(clinicalTrial);
		}
		return trialList;
	}

	@Override
	public List<ClinicalTrial> findAll() {
		List<ClinicalTrial> trialList = clinicalTrialRepository.findAll(new Sort(Sort.Direction.DESC, "createdOn"));
		for (ClinicalTrial clinicalTrial : trialList) {
			populateTrialAttributes(clinicalTrial);
		}
		return trialList;
	}

	@Override
	public ResponseObjectModel findAllWithCriteriaOnly(int start, int pageSize, String trialName) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Page<ClinicalTrial> pageTrial = null;
		List<Long> lstTrialIds = criteriaRepository.findByTrialIdNotNull().stream().map(c -> c.getTrialId()).distinct()
				.collect(Collectors.toList());
		if (null != trialName && !trialName.isEmpty()) {
			if (null != lstTrialIds && lstTrialIds.size() > 0)
				pageTrial = clinicalTrialRepository.findByIdInAndTrialNameContaining(lstTrialIds, trialName,
						new PageRequest(start, pageSize, new Sort(Sort.Direction.DESC, "createdOn")));
			else {
				pageTrial = clinicalTrialRepository.findByTrialNameContaining(trialName,
						new PageRequest(start, pageSize, new Sort(Sort.Direction.DESC, "createdOn")));
			}
		} else {
			if (null != lstTrialIds && lstTrialIds.size() > 0)
				pageTrial = clinicalTrialRepository.findByIdIn(lstTrialIds,
						new PageRequest(start, pageSize, new Sort(Sort.Direction.DESC, "createdOn")));
			else {
				pageTrial = clinicalTrialRepository
						.findAll(new PageRequest(start, pageSize, new Sort(Sort.Direction.DESC, "createdOn")));
			}
		}
		List<ClinicalTrial> lstTrials = pageTrial.getContent();
		responseObject.setData(lstTrials);
		responseObject.setTotal(pageTrial.getTotalElements());
		return responseObject;
	}

	@Override
	public ResponseObjectModel findAll(ClinicalTrialFilterRequestModel filterModel) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		// Set default sort order by updated on field
		if (null == filterModel.getSortBy() || filterModel.getSortBy().isEmpty()
				|| null == filterModel.getSortDirection() || filterModel.getSortDirection().isEmpty()) {
			filterModel.withSortBy("UpdatedOn");
			filterModel.withSortDirection("DESC");
		}

		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize(),
				filterModel.getSortBy(), filterModel.getSortDirection());
		Page<ClinicalTrial> pageTrial = null;

		if (null != filterModel.getSortBy() && filterModel.getSortBy().equals("therapeuticAreaName")) {
			pageRequest = CommonUtil.getPageRequest(0, 10000);
		}

		List<Program> programList = programRepository
				.findAll(SpringSpecifications.getProgramSpecification(filterModel), new PageRequest(0, 1)).getContent();
		List<Long> programIdList = (null != programList && !programList.isEmpty())
				? programList.stream().map(p -> p.getId()).collect(Collectors.toList()) : new ArrayList<>();
		if (programIdList.isEmpty()) {
			programIdList.add(0L);
		}

		pageTrial = clinicalTrialRepository.findAll(
				SpringSpecifications.getClinicalTrialSpecification(filterModel, programIdList, true), pageRequest);

		List<ClinicalTrial> trialList = pageTrial.getContent();
		for (ClinicalTrial clinicalTrial : trialList) {
			populateTrialAttributes(clinicalTrial);
		}

		responseObject.setData(trialList);
		responseObject.setTotal(pageTrial.getTotalElements());
		return responseObject;
	}

	@Override
	public ClinicalTrial findOne(Long id) {
		boolean isPatientListInProgrss = false;
		ClinicalTrial clinicalTrial = clinicalTrialRepository.findOne(id);
		populateTrialAttributes(clinicalTrial);
		if (clinicalTrial.getCriterias().size() > 0) {
			boolean fileExists = inclusionExclusionPublisher.fileExistsInBoldContainer(clinicalTrial.getTrialId());
			logger.info("Inclusio exclusion file existance check : {} ", fileExists);
			String ValidationStr = updateInExCriteria(clinicalTrial.getTrialId());
			logger.info("Patient list gereration status : {} ", ValidationStr);
			if (fileExists || ValidationStr.equalsIgnoreCase(Constants.IMPORT_STATUS_INPROGRESS)) {
				isPatientListInProgrss = true;
			}
			clinicalTrial.setPatientListInProgress(isPatientListInProgrss);
		}
		return clinicalTrial;
	}

	private String trialValidation(ClinicalTrial clinicalTrialToBePersisted) {
		String message = "";

		if (null != clinicalTrialToBePersisted.getTrialName()
				&& clinicalTrialToBePersisted.getTrialName().length() > 512) {
			message = (message + (message.isEmpty() ? "" : "\n\r")
					+ "TrialName should be less than or equal to 512 characters.");
		}

		if (!message.isEmpty()) {
			return message;
		}
		return "";
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel save(ClinicalTrial clinicalTrialToBePersisted) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setMessage(trialValidation(clinicalTrialToBePersisted));
		if (!responseObject.getMessage().isEmpty()) {
			return responseObject;
		}
		if (clinicalTrialToBePersisted != null) {
			List<ClinicalTrial> existingTrials = clinicalTrialRepository
					.findByTrialName(clinicalTrialToBePersisted.getTrialName());
			if (null != existingTrials && existingTrials.size() > 0) {

				responseObject.setHttpStatus(HttpStatus.FOUND);
				responseObject.setMessage("Trial name already exists.");
				return responseObject;
			}

			ClinicalTrial savedTrial = clinicalTrialRepository.save(clinicalTrialToBePersisted);
			if (null != savedTrial.getProgramId() && null != savedTrial.getTrialStatusId()) {
				checkAndMarkProgramOff(savedTrial.getProgramId(), savedTrial.getTrialStatusId());
			}
			List<StudySiteLightWeightDTO> studySitesList = clinicalTrialToBePersisted.getStudySitesList();
			if (null != clinicalTrialToBePersisted && null != studySitesList && studySitesList.size() > 0) {
				List<ClinicalTrialStudySite> lstClinicalTrialStudySite = studySitesList.stream()
						.map(s -> new ClinicalTrialStudySite(savedTrial.getTrialId(), s.getStudySiteId(), true,
								s.getRadiusValue(), s.isRadiusExempt(), false))
						.collect(Collectors.toList());

				if (lstClinicalTrialStudySite.size() > 0) {
					clinicalStudySiteRepository.save(lstClinicalTrialStudySite);
				}
			}

			List<String> lstIvestigators = studySitesList.stream().map(s -> s.getPiName()).collect(Collectors.toList());
			Set<String> lstUniqueInvestigators = new HashSet<String>(lstIvestigators);

			if (null != lstUniqueInvestigators && lstUniqueInvestigators.size() > 0) {
				for (String investigatorName : lstUniqueInvestigators) {
					if (null == investigatorName || investigatorName.equals(""))
						continue;
					List<PrincipalInvestigator> lstPrincipalInvestigators = principalInvestigatorRepository
							.findByName(investigatorName);
					PrincipalInvestigator principalInvestigator = new PrincipalInvestigator();
					if (lstPrincipalInvestigators.size() > 0) {
						principalInvestigator = lstPrincipalInvestigators.get(0);

						Long piId = principalInvestigator.getPrincipalInvestigatorId();
						List<StudySiteLightWeightDTO> listStudySitesWithInvestigatorName = studySitesList.stream()
								.filter(f -> investigatorName.equals(f.getPiName())).collect(Collectors.toList());

						List<StudySitePrincipalInvestigator> lstStudySitePIs = new ArrayList<StudySitePrincipalInvestigator>();
						if (null != listStudySitesWithInvestigatorName
								&& listStudySitesWithInvestigatorName.size() > 0) {

							listStudySitesWithInvestigatorName
									.forEach(f -> lstStudySitePIs.add(new StudySitePrincipalInvestigator(piId,
											f.getStudySiteId(), savedTrial.getTrialId())));
							if (lstStudySitePIs.size() > 0) {
								studySitePrincipalInvestigatorRepository.save(lstStudySitePIs);
							}
						}
					}
				}
			}

			doProcessingCROClinicianData(studySitesList, savedTrial.getTrialId());

			List<Criteria> criterias = savedTrial.getCriterias();
			if (criterias != null && criterias.size() > 0) {
				logger.info("criteria present in payload");
				for (Criteria criteria : criterias) {
					criteria.withTrialId(savedTrial.getTrialId());
					criteriaRepository.save(criteria);
				}

			} else {
				logger.info("criteria is not present in the payload");
				responseObject.setHttpStatus(HttpStatus.OK);
				responseObject.setData(savedTrial);
				return responseObject;
			}
			responseObject.setHttpStatus(HttpStatus.OK);
			responseObject.setData(savedTrial);

			try {

				List<ClinicalTrialStudySiteLightWeightDTO> response = getClinicalTrialStudySites(
						savedTrial.getTrialId(), savedTrial);

				Gson gson = new Gson();

				JsonObject trialWithStudysites = new JsonObject();

				trialWithStudysites.add(Constants.STUDY_SITES, gson.toJsonTree(response));

				logger.info("trialWithStudysites create toString :::  " + trialWithStudysites.toString());

			} catch (Exception e) {

				logger.error("Error occured while creating trialWithStudysites " + e);
			}
		}
		return responseObject;
	}

	private void doProcessingCROClinicianData(List<StudySiteLightWeightDTO> studySiteCSVBeans, Long trialId) {
		List<Long> listStudySiteIds = studySiteCSVBeans.stream().map(s -> s.getStudySiteId())
				.collect(Collectors.toList());
		if (null != listStudySiteIds && listStudySiteIds.size() > 0) {
			List<CROClinician> listCROClinicians = generateCROClinicianList(
					studySiteRepository.findByStudySitesIn(listStudySiteIds, trialId), trialId);
			studySiteCroPublisher.publishStudySiteClinicianDetails(listCROClinicians);
		}
	}

	private List<CROClinician> generateCROClinicianList(List<Object[]> objClinicianList, Long trialId) {
		List<CROClinician> croClinicianList = new ArrayList<CROClinician>();

		objClinicianList.stream().forEach((clinician) -> {
			CROClinician croClinician = new CROClinician();
			croClinician.setSource((String) clinician[0]);
			croClinician.setNpi((String) clinician[1]);
			croClinician.setInvestigatorId((BigInteger) clinician[2]);
			String name = (String) clinician[3];
			if (null != name) {
				String[] splitName = name.split(" ");
				if (splitName.length > 0)
					croClinician.setFirstName(splitName[0]);
				if (splitName.length > 1)
					croClinician.setLastName(splitName[1]);
			}
			croClinician.setSiteName((String) clinician[4]);
			croClinician.setAddress1((String) clinician[5]);
			croClinician.setAddress2((String) clinician[6]);
			croClinician.setCity((String) clinician[7]);
			croClinician.setState((String) clinician[8]);
			croClinician.setZip((String) clinician[9]);
			croClinician.setSpecialty((String) clinician[10]);
			croClinician.setProject((String) clinician[11]);
			if (!StringUtils.isEmpty((String) clinician[12]))
				croClinician.setPhoneNumber(Arrays.asList((String) clinician[12]));
			croClinician.setEmail((String) clinician[13]);
			croClinician.setTrialId(trialId);

			croClinicianList.add(croClinician);
		});
		return croClinicianList;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel update(ClinicalTrial clinicalTrialToBePersisted) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setMessage(trialValidation(clinicalTrialToBePersisted));
		if (!responseObject.getMessage().isEmpty()) {
			return responseObject;
		}
		// Re-factored above implementation with less complexity using Optional
		// effectively
		// 1. The first map() below finds a trial by ID - we can only update a
		// Trial
		// which exists in the DB, its NOT a create
		// 2. If such a trial exists in the DB, then the second map() is called
		// otherwise we print an error
		// 3. The second map calls save and returns the ClinicalTrial that's
		// returned by
		// save.
		if (clinicalTrialToBePersisted != null) {
			List<ClinicalTrial> existingTrials = clinicalTrialRepository.findByTrialNameAndIdNot(
					clinicalTrialToBePersisted.getTrialName(), clinicalTrialToBePersisted.getTrialId());
			if (null != existingTrials && existingTrials.size() > 0) {
				responseObject.setHttpStatus(HttpStatus.FOUND);
				responseObject.setMessage("Trial name already exists.");
				return responseObject;
			}

		}

		Criteria existingCriteria = populateCriteria(
				criteriaRepository.findByTrialId(clinicalTrialToBePersisted.getTrialId()));
		List<Criteria> existingCriterias = new ArrayList<Criteria>();
		existingCriterias.add(existingCriteria);
		logger.info("Inclusion exclusion existingCriterias: {} ", existingCriterias.toString());

		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(clinicalTrialToBePersisted.getTrialId());
		if (null != listClinicalTrialStudySite && listClinicalTrialStudySite.size() > 0) {
			listClinicalTrialStudySite.stream().forEach(b -> b.withRadiusChanged(false));
			clinicalStudySiteRepository.save(listClinicalTrialStudySite);
		}

		AtomicReference<String> oldTrailName = new AtomicReference<>();
		AtomicReference<String> oldTrialJson = new AtomicReference<>();
		Optional<ClinicalTrial> ctRet = Optional.ofNullable(clinicalTrialToBePersisted).map(ct1 -> {
			ClinicalTrial ctrial = clinicalTrialRepository.findOne(ct1.getTrialId());
			if (ctrial == null) {
				logger.error(
						"Update called on an nonextistent clinical trial: " + clinicalTrialToBePersisted.toString());
			}
			return ctrial;
		}).map(ct2 -> {
			ClinicalTrial ct = clinicalTrialRepository.save(clinicalTrialToBePersisted);
			if (null != ct.getProgramId() && null != ct.getTrialStatusId()) {
				checkAndMarkProgramOff(ct.getProgramId(), ct.getTrialStatusId());
			}

			return ct;
		});
		List<Criteria> criterias = clinicalTrialToBePersisted.getCriterias();
		Criteria savedCriteriaDto = new Criteria();
		if (!clinicalTrialToBePersisted.isPatientListGeneration()) {
			savedCriteriaDto = persistCriterias(criterias, clinicalTrialToBePersisted.getTrialId(), savedCriteriaDto);
		}
		if (ctRet.isPresent() && clinicalTrialToBePersisted.isPatientListGeneration()) {
			ClinicalTrial updatedTrail = ctRet.get();
			Set<String> lstProject = new HashSet<>();
			lstProject = principalInvestigatorRepository.getProjectListFindbyTrialId(updatedTrail.getTrialId());
			updatedTrail.setProjectList(lstProject);
			responseObject.setData(updatedTrail);
			if (criterias != null && criterias.size() > 0) {
				boolean fileExists = inclusionExclusionPublisher
						.fileExistsInBoldContainer(clinicalTrialToBePersisted.getTrialId());
				logger.info("Inclusio exclusion file existance check : {} ", fileExists);
				String ValidationStr = updateInExCriteria(clinicalTrialToBePersisted.getTrialId());
				if (!fileExists && (ValidationStr.equalsIgnoreCase(Constants.INEX_STATUS_COMPLETE)
						|| ValidationStr.equalsIgnoreCase(Constants.IMPORT_STATUS_FAILED))) {
					savedCriteriaDto = persistCriterias(criterias, clinicalTrialToBePersisted.getTrialId(),
							savedCriteriaDto);
				} else if (fileExists || ValidationStr.equalsIgnoreCase(Constants.IMPORT_STATUS_INPROGRESS)) {
					savedCriteriaDto = persistCriterias(existingCriterias, clinicalTrialToBePersisted.getTrialId(),
							savedCriteriaDto);
					// responseObject.setMessage(Constants.SUBMITTED_CRITERIA_MSG);
					// return responseObject;
				} else if (ValidationStr.equalsIgnoreCase(Constants.VALIDATION_FAILED_FOR_COLLECTION)) {
					logger.info("Inside Validation Failed For Collection block");
					savedCriteriaDto = persistCriterias(existingCriterias, clinicalTrialToBePersisted.getTrialId(),
							savedCriteriaDto);
					responseObject.setMessage("collection validation error. Please Try Again");
					return responseObject;
				}

			} else {
				responseObject.setHttpStatus(HttpStatus.OK);
				return responseObject;
			}

			String correlationId = UUID.randomUUID().toString();
			try {
				List<ClinicalTrialStudySiteLightWeightDTO> response = getClinicalTrialStudySites(
						updatedTrail.getTrialId(), updatedTrail);

				Gson gson = new Gson();

				JsonObject trialWithStudysites = new JsonObject();
				trialWithStudysites.add(Constants.TRIALID,
						new JsonParser().parse(updatedTrail.getTrialId().toString()));
				trialWithStudysites.add(Constants.TRIAL_NAME,
						new JsonPrimitive(updatedTrail.getTrialName()));
				trialWithStudysites.add(Constants.USERID,
						new JsonParser().parse(updatedTrail.getInitiatedBy()));
				ObjectMapper mapper = new ObjectMapper();

				if (!CommonUtil.isNullOrBlank(savedCriteriaDto.getInclusionCriteria())) {
					trialWithStudysites.add("inclusionCriteria",
							new JsonParser()
									.parse(mapper.writeValueAsString(uiJSONContractParser.parseJSONInput(
											mapper.readTree(savedCriteriaDto.getInclusionCriteria()),
											ContainerType.INCLUSION_CRITERIA)))
									.getAsJsonObject());

				}

				if (!CommonUtil.isNullOrBlank(savedCriteriaDto.getExclusionCriteria())) {
					trialWithStudysites.add("exclusionCriteria",
							new JsonParser()
									.parse(mapper.writeValueAsString(uiJSONContractParser.parseJSONInput(
											mapper.readTree(savedCriteriaDto.getExclusionCriteria()),
											ContainerType.EXCLUSION_CRITERIA)))
									.getAsJsonObject());
				}

				if (!CommonUtil.isNullOrBlank(savedCriteriaDto.getInclusionCriteria())
						|| !CommonUtil.isNullOrBlank(savedCriteriaDto.getExclusionCriteria())) {
					trialWithStudysites.add(Constants.STUDY_SITES, gson.toJsonTree(response));
					boolean filewrite = inclusionExclusionPublisher.publishInclusionExclusionCriteria(
							trialWithStudysites.toString(), savedCriteriaDto.getTrialId());
					/*Notification published for the criteria processing started*/
					inclusionExclusionPublisher.publishNotification(updatedTrail);
					logger.info("container filewrite status :{}" , filewrite);

					// update Job Table for success
					if (filewrite) {
						TrialJobMap jobMap = new TrialJobMap();
						jobMap.withCorrelationId(correlationId).withTrialId(updatedTrail.getTrialId())
								.withJobStatus(Constants.IMPORT_STATUS_SUBMITTED);
						this.trialJobMapRepository.save(jobMap);
					} else {
						TrialJobMap jobMap = new TrialJobMap();
						jobMap.withCorrelationId(correlationId).withTrialId(updatedTrail.getTrialId())
								.withJobStatus(Constants.IMPORT_STATUS_FAILED);
						this.trialJobMapRepository.save(jobMap);
					}

				}
				logger.info("trialWithStudysites update toString ::: {} " , trialWithStudysites.toString());
				String curTrailName = "";

				// If old trail name doesn't match with current trailName then
				// update CRM
				/*if (!curTrailName.equals(oldTrailName.get())) {
					CRMCategory category = new CRMCategory();
					category.withTrialId(updatedTrail.getTrialId()).withTrialName(curTrailName)
							.withOldTrialName(oldTrailName.get());
					sendCRMCategoryToParticipantService(category);
				}*/
				responseObject.setHttpStatus(HttpStatus.OK);
			} catch (Exception e) {
				// update Job Table for Error
				e.printStackTrace();
				TrialJobMap jobMap = new TrialJobMap();
				jobMap.withCorrelationId(correlationId).withTrialId(updatedTrail.getTrialId())
						.withJobStatus(Constants.IMPORT_STATUS_FAILED);
				this.trialJobMapRepository.save(jobMap);
				responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObject.setMessage("Error occured while creating trialWithStudysites.");
				logger.error("Error occured while creating trialWithStudysites " + e);
			}

		} else {
			if (ctRet.isPresent()) {
				logger.info("Response for update call");
				responseObject.setHttpStatus(HttpStatus.OK);
				responseObject.setData(ctRet.get());
			}
		}
		return responseObject;
	}

	private List<ClinicalTrialStudySiteLightWeightDTO> getClinicalTrialStudySites(Long trialId,
			ClinicalTrial updatedTrail) {
		logger.info(" inside getClinicalTrialStudySites method >>");
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(trialId);

		if (listClinicalTrialStudySite.size() <= 0) {
			return null;
		}

		List<Long> ids = new ArrayList<Long>();
		ids = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId()).collect(Collectors.toList());

		List<StudySite> lstStudySite = studySiteRepository.findByIdIn(ids);
		//As Qualifier concept is removed from criteria. 
		//So code to calculate overriddenRadius is no longer use. Thats why code is commented
		/*int overriddenRadius = 0;
		if (null != updatedTrail.getCriterias() && updatedTrail.getRadiusOverride()) {
			overriddenRadius = getOverriddenRadius(updatedTrail.getCriterias());
		}*/
		List<ClinicalTrialStudySiteLightWeightDTO> siteDTOList = new ArrayList<ClinicalTrialStudySiteLightWeightDTO>();

		for (StudySite site : lstStudySite) {
			for (ClinicalTrialStudySite clinicalTrialSite : listClinicalTrialStudySite) {
				if (site.getId().equals(clinicalTrialSite.getId().getStudySiteId())) {
					if (clinicalTrialSite.getIsActive()) {
						ClinicalTrialStudySiteLightWeightDTO dto = new ClinicalTrialStudySiteLightWeightDTO();
						dto.setRadiusValue(clinicalTrialSite.getRadiusValue());
						if (updatedTrail.getRadiusOverride()) {
							dto.setRadiusOverride("Y");	
						} else {
							dto.setRadiusOverride("N");
						}
						//As Qualifier concept is removed from criteria. 
						//So code to calculate overriddenRadius is no longer use. Thats why code is commented
						/*if (!updatedTrail.getRadiusOverride()) {
							if (!CommonUtil.isNullOrBlank(String.valueOf(clinicalTrialSite.getRadiusValue()))) {
								dto.setRadiusValue(clinicalTrialSite.getRadiusValue());
							} else {
								dto.setRadiusValue(null);
							}
						} else {
							dto.setRadiusValue(overriddenRadius);
							dto.setRadiusOverride("Y");
						}*/
						dto.setStudySiteId(site.getId());
						dto.setZipCode(site.getZip());
						siteDTOList.add(dto);
					}
				}
			}
		}
		return siteDTOList;
	}

	//As Qualifier concept is removed from criteria. 
	//So code to calculate overriddenRadius is no longer use. Thats why code is commented
	/*private int getOverriddenRadius(List<Criteria> criterias) {

		for (Criteria criteria : criterias) {
			//if (!CommonUtil.isNullOrBlank(String.valueOf(criteria.getQualifier()))) {
			if (!CommonUtil.isNullOrBlank(criteria.getQualifier())) {
				JSONArray jsonArray;
				try {
					jsonArray = new JSONArray(criteria.getQualifier());
					for (int i = 0; i < jsonArray.length(); i++) {
						JSONObject jsonObj = jsonArray.getJSONObject(i);
						String title = jsonObj.getString(Constants.TITLE);
						if (Constants.SET_RADIUS.equalsIgnoreCase(title)) {
							return jsonObj.getInt(Constants.VALUE);
						}
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		}
		return 0;
	}*/

	@Override
	public void delete(Long id) {
		clinicalTrialRepository.delete(id);

	}

	@Override
	public List<TrialStatus> getAllTrialStatuses() {
		return this.trialStatusRepository.findAll();
	}

	@Override
	public List<Status> getAllStatus() {
		return this.statusRepository.findAll();
	}

	private void populateTrialAttributes(ClinicalTrial trial) {
		Set<String> lstProject = new HashSet<String>();
		if (trial != null) {

			Integer statusId = trial.getTrialStatusId();
			Long programId = trial.getProgramId();
			Long sponsorId = trial.getSponsorId();

			Long stageId = trial.getStageId();
			Long armId = trial.getArmId();
			Long therapeuticAreaId = trial.getTherapeuticAreaId();
			Long trialConditionId = trial.getTrialConditionId();

			if (statusId != null && statusId.intValue() > 0)
				// trial.withTrialStatus(this.trialStatusRepository.findOne(trial.getTrialStatusId()));

				// Check Trail Status Id.If Trail Status Id is 6 then Trail
				// Status name should
				// be blank("") else it should return the Trial details from DB
				if (statusId == 6) {
					TrialStatus tStatus = new TrialStatus();
					tStatus.withName("");
					tStatus.withTrialStatusId(statusId);
					tStatus.withCreatedBy(trial.getCreatedBy());
					tStatus.withCreatedOn(trial.getCreatedOn());
					tStatus.withUpdatedBy(trial.getUpdatedBy());
					tStatus.withUpdatedOn(trial.getUpdatedOn());

					trial.withTrialStatus(tStatus);
				} else {
					trial.withTrialStatus(this.trialStatusRepository.findOne(trial.getTrialStatusId()));
				}

			if (programId != null && programId.longValue() > 0) {
				trial.withProgram(populateProgramAttributes(this.programRepository.findOne(programId)));
			}

			if (therapeuticAreaId != null && therapeuticAreaId.longValue() > 0) {
				trial.withTherapeuticArea(this.therapeuticAreaRepository.findOne(therapeuticAreaId));
			}
			if (trialConditionId != null && trialConditionId.longValue() > 0) {
				trial.withTrialCondition(this.conditionRepository.findOne(trialConditionId));
			}

			if (sponsorId != null && sponsorId.longValue() > 0) {
				trial.withSponsor(this.sponsorRepository.findOne(sponsorId));
			}

			if (stageId != null && stageId.longValue() > 0) {
				trial.withStage(this.stageRepository.findOne(stageId));
			}
			if (armId != null && armId.longValue() > 0) {
				trial.withArm(this.armRepository.findOne(armId));
			}

			List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
					.findByClinicalStudySiteIdId(trial.getTrialId());
			if (null == listClinicalTrialStudySite
					|| (null != listClinicalTrialStudySite && listClinicalTrialStudySite.size() <= 0)) {
				trial.withStudySiteChanged(false);
			} else {
				long size = listClinicalTrialStudySite.stream().filter(s -> (s.getRadiusChanged() == true)).count();
				logger.info("size value" + String.valueOf(size));
				if (size > 0) {
					trial.withSitesChangedNumber(size);
					trial.withStudySiteChanged(true);
				}
			}
			lstProject = principalInvestigatorRepository.getProjectListFindbyTrialId(trial.getTrialId());
			trial.setProjectList(lstProject);
		}
		logger.info("trial object  >>>>>   " + lstProject.size());
	}

	private Program populateProgramAttributes(Program program) {
		if (program != null) {

			Long sponsorId = program.getSponsorId();
			Integer phaseId = program.getPhaseId();
			// Long collaboratorId = program.getCollaboratorId();
			Long therapeuticAreaId = program.getTherapeuticAreaId();
			Integer programStatusId = program.getProgramStatusId();

			if (therapeuticAreaId != null && therapeuticAreaId.longValue() > 0) {
				program.withTherapeuticArea(this.therapeuticAreaRepository.findOne(therapeuticAreaId));
			}

			if (phaseId != null && phaseId.intValue() > 0) {
				program.withPhase(this.phaseRepository.findOne(phaseId));
			}

			if (sponsorId != null && sponsorId.longValue() > 0) {
				program.withSponsor(this.sponsorRepository.findOne(sponsorId));
			}

			if (programStatusId != null && programStatusId.intValue() > 0) {
				program.withProgramStatus(this.programStatusRepository.findOne(programStatusId));
			}
		}
		return program;
	}

	@Override
	public List<TrialCondition> getAllTrialConditions() {
		return this.conditionRepository.findAll();
	}

	@Override
	public List<TherapeuticArea> getAllTherapeuticAreas() {
		return this.therapeuticAreaRepository.findAll();
	}

	@Override
	public ResponseObjectModel getAllTherapeuticAreasByKeyword(String keyword) {
		ResponseObjectModel response = new ResponseObjectModel();
		List<TherapeuticArea> therapeuticAreaList = therapeuticAreaRepository.findByNameContainingIgnoreCase(keyword);
		response.setData(therapeuticAreaList);
		response.setTotal(therapeuticAreaList.size());
		response.setHttpStatus(HttpStatus.OK);
		return response;
	}

	@Override
	public List<ClinicalTrial> getClinicalTrialsByProgramId(long programId) {
		List<ClinicalTrial> listOfTrials = this.clinicalTrialRepository.findByProgramId(programId);
		listOfTrials.forEach(trial -> {
			if (trial.getTherapeuticAreaId() != null) {
				trial.withTherapeuticArea(this.therapeuticAreaRepository.findOne(trial.getTherapeuticAreaId()));
			}
		});
		return listOfTrials;
	}

	@Override
	public ResponseObjectModel getAllTrialConditions(int page, int pageSize) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		try {
			PageRequest pageRequest = CommonUtil.getPageRequest(page, pageSize);
			Page<TrialCondition> pageList = conditionRepository.findAll(pageRequest);
			responseObject.setData(pageList.getContent());
			responseObject.setTotal(pageList.getTotalElements());
			responseObject.setHttpStatus(HttpStatus.OK);
		} catch (Exception e) {
			responseObject.setHttpStatus(HttpStatus.BAD_REQUEST);
		}

		return responseObject;
	}

	@Override
	public ResponseObjectModel getAllTrialConditionsByKeyword(String keyword) {
		ResponseObjectModel response = new ResponseObjectModel();
		List<TrialCondition> therapeuticAreaList = conditionRepository
				.findByTrialConditionNameContainingIgnoreCase(keyword);
		response.setData(therapeuticAreaList);
		response.setTotal(therapeuticAreaList.size());
		response.setHttpStatus(HttpStatus.OK);
		return response;
	}

	@Override
	public ResponseObjectModel findAllUnAssociatedProgram(ClinicalTrialFilterRequestModel filterModel) {
		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize());
		// Default sorting order by updated on field
		if (filterModel.getSortBy().isEmpty() || filterModel.getSortDirection().isEmpty()) {
			filterModel.withSortBy("UpdatedOn");
			filterModel.withSortDirection("DESC");
			pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize(),
					filterModel.getSortBy(), filterModel.getSortDirection());
		}
		ResponseObjectModel model = new ResponseObjectModel();
		Page<ClinicalTrial> pageList = clinicalTrialRepository.findAll((root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			List<Long> therapeuticAreaIdList = filterModel.getTherapeuticAreaList();
			List<Long> collaboratorList = filterModel.getCollaboratorList();
			List<Long> sponsorList = filterModel.getSponsorList();
			String trialName = filterModel.getTrialName();
			List<Integer> statusIdList = filterModel.getStatusList();
			List<Long> conditionIdList = filterModel.getTrialConditionList();
			predicates.add(cb.isNull(root.get("programId")));
			if (null != filterModel.getCoordinatorId() && filterModel.getCoordinatorId().longValue() > 0) {

				Root<StudySiteCoordinator> rootssc = query.from(StudySiteCoordinator.class);
				Root<ClinicalTrialStudySite> rootClinical = query.from(ClinicalTrialStudySite.class);
				predicates.add(cb.equal(rootssc.get("coordinatorId"), filterModel.getCoordinatorId()));
				predicates.add(cb.isTrue(rootClinical.get("isActive").in(filterModel.getActiveList())));
				predicates.add(cb.and(
						cb.equal(rootssc.get("studySiteId"),
								rootClinical.get("clinicalStudySiteId").get("studySiteId")),
						cb.equal(rootClinical.get("clinicalStudySiteId").get("id"), root.get("id"))));
			}

			if (!CommonUtil.IsNullOrEmpty(collaboratorList)) {
				Root<TrialCollaborator> rootTC = query.from(TrialCollaborator.class);
				predicates.add(cb.isTrue(rootTC.get("collaborator").get("id").in(collaboratorList)));
				predicates.add(cb.equal(rootTC.get("trial").get("id"), root.get("id")));
			}

			if (!CommonUtil.IsNullOrEmpty(sponsorList)) {
				predicates.add(cb.isTrue(root.get("sponsorId").in(sponsorList)));
			}

			if (!CommonUtil.IsNullOrEmpty(therapeuticAreaIdList)) {
				predicates.add(cb.isTrue(root.get("therapeuticAreaId").in(therapeuticAreaIdList)));
			}

			if (!CommonUtil.IsNullOrEmpty(statusIdList)) {
				predicates.add(cb.isTrue(root.get("trialStatusId").in(statusIdList)));
			}

			if (!CommonUtil.IsNullOrEmpty(conditionIdList)) {
				predicates.add(cb.isTrue(root.get("trialConditionId").in(conditionIdList)));
			}

			if (!CommonUtil.isNullOrBlank(trialName)) {
				predicates.add(cb.like(root.get("trialName"), "%" + trialName + "%"));
			}

			if (!filterModel.getSortDirection().trim().isEmpty()) {
				Root<TherapeuticArea> therapeuticAreaRoot = null;
				if ("therapeuticAreaName".equals(filterModel.getSortBy())) {
					therapeuticAreaRoot = query.from(TherapeuticArea.class);
					predicates.add(cb.equal(root.get("therapeuticAreaId"), therapeuticAreaRoot.get("id")));
				}
				query.orderBy(SpringSpecifications.getTrialOrder(filterModel.getSortBy(),
						filterModel.getSortDirection(), cb, root, therapeuticAreaRoot));
			}

			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		}, pageRequest);
		List<ClinicalTrial> trialList = pageList.getContent();
		logger.info("Independent trials filtered:" + trialList.size());
		trialList.forEach(trial -> populateTrialAttributes(trial));

		model.setData(trialList);
		model.setTotal(pageList.getTotalElements());
		return model;
	}

	@Override
	public List<ClinicalTrial> findAll(Long coordinatorId) {
		List<Long> studySiteIds = this.studySiteCoordinatorRepository.findByCoordinatorId(coordinatorId).stream()
				.map(ssc -> ssc.getStudySiteId()).collect(Collectors.toList());
		List<Long> trialIds = this.clinicalStudySiteRepository.findByClinicalStudySiteIdStudySiteId(studySiteIds.get(0))
				.stream().map(css -> css.getId().getId()).collect(Collectors.toList());
		List<ClinicalTrial> trialList = clinicalTrialRepository.findByIdIn(trialIds);

		for (ClinicalTrial clinicalTrial : trialList) {
			populateTrialAttributes(clinicalTrial);
		}
		return trialList;
	}

	@Override
	public void delete(Long id, Long coordinatorId) {
		studySiteCoordinatorRepository.deleteByCoordinatorIdAndTrialId(coordinatorId, id);
	}

	@Override
	public ResponseObjectModel findAll(ClinicalTrialFilterRequestModel filterModel, Long coordinatorId) {
		ResponseObjectModel responseObject = findAll(filterModel.withCoordinatorId(coordinatorId));
		return responseObject;
	}

	private boolean sendCRMCategoryToParticipantService(CRMCategory crmCategory) {

		HttpHeaders headers = CommonUtil.getHttpHeaders();
		try {
			HttpEntity<CRMCategory> httpEntity = new HttpEntity<>(crmCategory, headers);

			RestTemplate restTemplate = new RestTemplate();
			restTemplate.postForObject(participantServiceCRMCategoryURL, httpEntity, CRMCategory.class);
		} catch (Exception e) {
			logger.error("Error accessing/sending CRMCategory to participantService", e);
		}
		return false;
	}

	public ResponseObjectModel getTrialsByPageCriteria(ClinicalTrialFilterRequestModel filterModel) {
		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize());
		ResponseObjectModel response = new ResponseObjectModel();
		Page<ClinicalTrial> page = null;
		List<ClinicalTrial> lstTrials = null;
		if (null != filterModel.getTrialName() && !filterModel.getTrialName().isEmpty())
			page = clinicalTrialRepository.findByTrialNameContaining(filterModel.getTrialName(), pageRequest);
		else if (null != filterModel.getTrialIdList() && filterModel.getTrialIdList().size() > 0
				&& filterModel.getPage() <= 0) {
			lstTrials = clinicalTrialRepository.findByIdIn(filterModel.getTrialIdList());
			if (lstTrials != null)
				pageRequest = CommonUtil.getPageRequest(filterModel.getPage(),
						filterModel.getPageSize() - lstTrials.size());
			page = clinicalTrialRepository.findByIdNotIn(filterModel.getTrialIdList(), pageRequest);
			lstTrials.addAll(page.getContent());
		} else {
			page = clinicalTrialRepository.findAll(pageRequest);
		}
		if (null != lstTrials) {
			response.setData(lstTrials);
			response.setTotal(page.getTotalElements() + 1);
		} else {
			response.setData(page.getContent());
			response.setTotal(page.getTotalElements());
		}

		return response;
	}

	public boolean updateTrialCollectionStatus(TrialJobStatusModel statusmodel) {

		logger.info("Starting to update the job status for CorrelationId==>" + statusmodel.getCorrelationId());

		TrialJobMap jobMap = this.trialJobMapRepository.findByCorrelationId(statusmodel.getCorrelationId());

		String status = statusmodel.getStatus();
		int collectionReady = 0;
		logger.info("Status of job[correlationId=" + statusmodel.getCorrelationId() + "] is ===>" + status);

		if (null == jobMap && !status.equalsIgnoreCase(JOB_STATUS_DONE)) {
			logger.info(
					"Not able to find the job entry in database for CorrelationId==>" + statusmodel.getCorrelationId());
			return false;
		} else if (null == jobMap && status.equalsIgnoreCase(JOB_STATUS_DONE) && null != statusmodel.getTrialId()) {
			logger.info(
					"Not able to find the job entry in database for CorrelationId==>" + statusmodel.getCorrelationId());
			logger.info("Checking for trial in database for TrialId==>" + statusmodel.getTrialId());
			ClinicalTrial trial = findOne(Long.valueOf(statusmodel.getTrialId()));
			if (null == trial) {
				logger.info("Not able to find the job entry in database for trialId==>" + statusmodel.getTrialId());
				return false;
			}

			logger.info("MongoDB Collection Availability Status of trial [trialId=" + trial.getTrialId()
					+ "] is updated to ===>1");
			this.clinicalTrialRepository.save(trial.withCollectionReady(1));
			return true;
		} else {
			logger.info("Trial mapped for the job[correlationId=" + statusmodel.getCorrelationId() + "] is ===>"
					+ jobMap.getTrialId());
			ClinicalTrial trial = findOne(jobMap.getTrialId());

			if (null != status) {
				this.trialJobMapRepository.save(jobMap.withJobStatus(status));
				if (status.equalsIgnoreCase(JOB_STATUS_DONE)) {
					collectionReady = 1;
				}
				if (status.equalsIgnoreCase(JOB_STATUS_DEAD)) {
					collectionReady = 2;
				}
			}
			this.clinicalTrialRepository.save(trial.withCollectionReady(collectionReady));
			logger.info("MongoDB Collection Availability Status of trial [trialId=" + jobMap.getTrialId()
					+ "] is updated to ===>" + collectionReady);
			return true;
		}
	}

	private boolean trialsActiveInProgram(Long programId) {

		ClinicalTrialFilterRequestModel trialFilter = new ClinicalTrialFilterRequestModel();
		ArrayList<Long> programList = new ArrayList<>();
		programList.add(programId);
		trialFilter.withProgramIdList(programList);
		List<ClinicalTrial> trialList = this.clinicalTrialRepository.findByProgramId(programId);

		List<ClinicalTrial> activeTrials = trialList.size() > 0 ? trialList.stream()
				.filter(t -> t.getTrialStatusId() == TRIAL_STATUS_ACTIVE).collect(Collectors.toList())
				: new ArrayList<>();

		if (trialList.size() == 0 || (trialList.size() > 0 && activeTrials.size() > 0)) {
			logger.info("Atleast one trial is active in Program[Id=" + programId + "]");
			return true;
		}
		logger.info("No trial is active in Program[Id=" + programId + "]");
		return false;
	}

	private void checkAndMarkProgramOff(Long programId, int currentTrialStatus) {
		if (null != programId) {
			Program pgm = this.programRepository.findOne(programId);
			boolean trialStatus = trialsActiveInProgram(programId);

			if (!trialStatus && currentTrialStatus != TRIAL_STATUS_ACTIVE) {
				pgm.withProgramStatus(new ProgramStatus().withStatusId(2)).withProgramStatusId(2);
			} else if ((!trialStatus && TRIAL_STATUS_ACTIVE == currentTrialStatus)
					|| (trialStatus || TRIAL_STATUS_ACTIVE == currentTrialStatus)) {
				pgm.withProgramStatus(new ProgramStatus().withStatusId(1)).withProgramStatusId(1);
			}

			this.programRepository.save(pgm);
		}
	}

	// @Async
	@Override
	public ResponseObjectModel updateTrialRadiusOverride(Long trialId, boolean radiusOverride) {

		ResponseObjectModel res = new ResponseObjectModel();

		ClinicalTrial clinicalTrial = clinicalTrialRepository.findOne(trialId);
		if (clinicalTrial != null) {
			clinicalTrial.withRadiusOverride(radiusOverride);
			clinicalTrial = clinicalTrialRepository.save(clinicalTrial);
		}
		res.setHttpStatus(HttpStatus.OK);
		res.setData(clinicalTrial);
		return res;
	}

	@Override
	public ResponseObjectModel updateTrialStudySiteIgnore(Long trialId) {

		ResponseObjectModel res = new ResponseObjectModel();
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(trialId);

		if (null != listClinicalTrialStudySite && listClinicalTrialStudySite.size() > 0) {
			listClinicalTrialStudySite.stream().forEach(b -> b.withRadiusChanged(false));
			clinicalStudySiteRepository.save(listClinicalTrialStudySite);
		}
		res.setHttpStatus(HttpStatus.OK);

		return res;
	}

	@Override
	public String updateInExCriteria(long trialId) {
		List<TrialJobMap> trialLst = manager
				.createQuery("select t from TrialJobMap t where t.trialId=" + trialId + " order by t.createdOn desc ",
						TrialJobMap.class)
				.setMaxResults(1).getResultList();
		if (trialLst.size() > 0) {
			if (trialLst.get(0).getJobStatus().equalsIgnoreCase(Constants.IMPORT_STATUS_SUBMITTED)
					|| trialLst.get(0).getJobStatus().equalsIgnoreCase(Constants.IMPORT_STATUS_INPROGRESS)) {
				try {

					long jobCreationTym = trialLst.get(0).getCreatedOn().getTime();
					String reqCheckpatientcollectionurl = checkpatientcollectionurl + trialId + "/" + jobCreationTym;
					logger.info("url for collection check>>" + reqCheckpatientcollectionurl);
					RestTemplate restTemplate = new RestTemplate();
					Boolean fileWriteStatus = restTemplate.getForObject(reqCheckpatientcollectionurl, Boolean.class);

					logger.info("fileWriteStatus...>>>>" + fileWriteStatus);
					if (fileWriteStatus) {
						trialJobMapRepository.updateTrailJobStatus(trialId, Constants.INEX_STATUS_COMPLETE);
						return Constants.INEX_STATUS_COMPLETE;
					} else {

						trialJobMapRepository.updateTrailJobStatus(trialId, Constants.IMPORT_STATUS_INPROGRESS);
						return Constants.IMPORT_STATUS_INPROGRESS;
					}

				} catch (Exception e) {
					logger.error("Error accessing/sending CRMCategory to participantService", e.getMessage());
					return Constants.VALIDATION_FAILED_FOR_COLLECTION;
				}
			} else {
				return Constants.IMPORT_STATUS_FAILED;
			}
		} else {
			return Constants.INEX_STATUS_COMPLETE;
		}
	}

	@Override
	public long getLatestTrailJob(Long trailId) {
		// TODO Auto-generated method stub
		TrialJobMap trialJobMap = trialJobMapRepository.getLatestTrailJob(trailId);
		if (trialJobMap != null) {
			long requiredTym = trialJobMap.getCreatedOn().getTime();
			return requiredTym;
		} else {
			return 0;
		}
	}

	private Criteria persistCriterias(List<Criteria> criterias, long trialId, Criteria savedCriteriaDto) {
		for (Criteria criteria : criterias) {
			criteria.withTrialId(trialId);
			savedCriteriaDto = criteriaRepository.save(criteria);
		}
		return savedCriteriaDto;
	}

	private Criteria populateCriteria(List<Criteria> criterias) {
		Criteria criteria = new Criteria();
		if (criterias.size() > 0) {
			criteria.withCriteriaDescription(criterias.get(0).getCriteriaDescription());
			criteria.withCriteriaName(criterias.get(0).getCriteriaName());
			criteria.withExclusionCriteria(criterias.get(0).getExclusionCriteria());
			criteria.withCriteriaInclusionCriteria(criterias.get(0).getInclusionCriteria());
			criteria.withCriteriaId(criterias.get(0).getCriteriaId());
			criteria.withTrialId(criterias.get(0).getTrialId());
			criteria.withTemplateId(criterias.get(0).getTemplateId());
			criteria.withCriteriaQualifier(criterias.get(0).getQualifier());
			criteria.withIsDeleted(criterias.get(0).getIsDeleted());
			criteria.withIsInclude(criterias.get(0).getIsInclude());
			criteria.withOverallOperator(criterias.get(0).getOverAllOperator());
		}
		return criteria;
	}

	@Override
	public ResponseObjectModel getStudySiteTrialDetails(StudySiteTrialRequest studySiteTrialRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		List<StudySiteTrialResponse> trialDetails = null;

		// If studySiteId is blank we need to get all the trails with the
		// specified trialName sent from the UI.
		if (StringUtils.isEmpty(studySiteTrialRequest.getStudySiteId())) {
			logger.info("Fetch TrialNames based on search without receiving the studysiteId >>");
			trialDetails = clinicalTrialRepository.getTrialNames(studySiteTrialRequest.getTrialName()).stream()
					.map(objects -> {

						StudySiteTrialResponse studySiteTrialResponse = new StudySiteTrialResponse();

						if (objects[0] != null)
							studySiteTrialResponse.setTrialId(((BigInteger) objects[0]).longValue());
						else
							studySiteTrialResponse.setTrialId(null);
						if (objects[1] != null)
							studySiteTrialResponse.setTrialName(objects[1].toString());
						else
							studySiteTrialResponse.setTrialName(null);
						return studySiteTrialResponse;
					}).collect(Collectors.toList());
		}
		// TrialNames based on Auto search
		if (!StringUtils.isEmpty(studySiteTrialRequest.getStudySiteId()) && !StringUtils.isEmpty(studySiteTrialRequest.getTrialName())) {
			logger.info("Fetch TrialNames based on auto-search with studySiteId provided >>");
			trialDetails = clinicalTrialRepository.getStudySiteTrialLikeDetails(studySiteTrialRequest.getStudySiteId(),
					studySiteTrialRequest.getTrialName()).stream().map(objects -> {
						StudySiteTrialResponse studySiteTrialResponse = new StudySiteTrialResponse();

						if (objects[0] != null)
							studySiteTrialResponse.setTrialId(((BigInteger) objects[0]).longValue());
						else
							studySiteTrialResponse.setTrialId(null);
						if (objects[1] != null)
							studySiteTrialResponse.setTrialName(objects[1].toString());
						else
							studySiteTrialResponse.setTrialName(null);
						return studySiteTrialResponse;
					}).collect(Collectors.toList());
		} else if(!StringUtils.isEmpty(studySiteTrialRequest.getStudySiteId()) && StringUtils.isEmpty(studySiteTrialRequest.getTrialName())) {
			logger.info("Fetch TrialNames based on studySiteId with No trialName specified >>");
			// TrialNames based on no TrialName and only StudySiteId is provided
			trialDetails = clinicalTrialRepository.getStudySiteTrialDetails(studySiteTrialRequest.getStudySiteId())
					.stream().map(objects -> {
						StudySiteTrialResponse studySiteTrialResponse = new StudySiteTrialResponse();

						if (objects[0] != null)
							studySiteTrialResponse.setTrialId(((BigInteger) objects[0]).longValue());
						else
							studySiteTrialResponse.setTrialId(null);
						if (objects[1] != null)
							studySiteTrialResponse.setTrialName(objects[1].toString());
						else
							studySiteTrialResponse.setTrialName(null);
						return studySiteTrialResponse;
					}).collect(Collectors.toList());
		}

		if (trialDetails != null) {
			responseObjectModel.setData(trialDetails);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage("Success");
		}
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel addTherapeuticArea(TrialDetails trialDetails) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		
		TherapeuticArea therapeuticArea = new TherapeuticArea();
		therapeuticArea.withName(trialDetails.getName());
		therapeuticArea.setCreatedBy(1L);
		therapeuticArea.setCreatedOn(new Date());
		responseObjectModel.setData(therapeuticAreaRepository.save(therapeuticArea));
		responseObjectModel.setHttpStatus(HttpStatus.OK);
		responseObjectModel.setMessage(Constants.IMPORT_STATUS_SUCCESS);
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel addTrialCondition(TrialDetails trialDetails) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		TrialCondition trialCondition = new TrialCondition();
		trialCondition.withTrialConditionName(trialDetails.getName());
		trialCondition.withCreatedBy(1L);
		trialCondition.withCreatedOn(new Date());
		responseObjectModel.setData(trialConditionRepository.save(trialCondition));
		responseObjectModel.setHttpStatus(HttpStatus.OK);
		responseObjectModel.setMessage(Constants.IMPORT_STATUS_SUCCESS);
		return responseObjectModel;
	}
}