package com.avigosolutions.criteriaservice.service;

import java.util.List;

import com.avigosolutions.criteriaservice.model.Collaborator;
import com.avigosolutions.criteriaservice.model.CollaboratorType;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;;

public interface CollaboratorService {
	public CollaboratorType findCollaboratorType(Long collaboratorTypeId);
	public List<Collaborator> findAll();
	public Collaborator findOne(Long collaboratorId);
	public Collaborator save(Collaborator collaborator);
	public Collaborator update(Collaborator collaborator);
	//public boolean delete(Long collaboratorId);
	
	//Get all programs based on page and pagesize
	public ResponseObjectModel getAll(int page,int pageSize);
	
	public boolean delete(Long collaboratorId);
}
