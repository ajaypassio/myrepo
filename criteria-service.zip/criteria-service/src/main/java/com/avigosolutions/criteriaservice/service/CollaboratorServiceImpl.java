package com.avigosolutions.criteriaservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Collaborator;
import com.avigosolutions.criteriaservice.model.CollaboratorType;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.repository.CollaboratorRepository;
import com.avigosolutions.criteriaservice.repository.CollaboratorTypeRepository;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.util.CommonUtil;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class CollaboratorServiceImpl implements CollaboratorService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CollaboratorRepository collaboratorRepository;

	@Autowired
	CollaboratorTypeRepository collaboratorTypeRepository;
	
	@Autowired
	ClinicalTrialService clinicalTrialService;
	
	@Autowired
	ProgramService programService;

	@Override
	public CollaboratorType findCollaboratorType(Long collaboratorTypeId) {

		return collaboratorTypeRepository.findOne(collaboratorTypeId);
	}

	@Override
	public List<Collaborator> findAll() {

		return collaboratorRepository.findAll();
	}

	@Override
	public Collaborator findOne(Long collaboratorId) {

		return collaboratorRepository.findOne(collaboratorId);
	}

	/*
	 * Before saving collaborator need to verify if we have duplicate collaborator
	 * name
	 */
	@Override
	public Collaborator save(Collaborator collaborator) {
		Collaborator existingColl = collaboratorRepository.findByName(collaborator.getName());
		if (existingColl != null) {
			logger.error("Duplicate program found on insert - {}", collaborator.getName());
			return null;
		}
		CollaboratorType ct = findCollaboratorType(collaborator.getCollaboratorTypeId());
		collaborator.withCollaboratorType(ct);

		return collaboratorRepository.save(collaborator);
	}

	/*
	 * Before saving collaborator need to verify if we have duplicate collaborator
	 * name for any other entry
	 */
	@Override
	public Collaborator update(Collaborator collaborator) {
		Collaborator existingColl = collaboratorRepository
				.findByNameAndIdNot(collaborator.getName(), collaborator.getId());
		if (existingColl != null) {
			logger.error("Duplicate program found on insert - {}", collaborator.getName());
			return null;
		}
		CollaboratorType ct = findCollaboratorType(collaborator.getCollaboratorTypeId());
		collaborator.withCollaboratorType(ct);

		return collaboratorRepository.save(collaborator);
	}
	
	/*
	 * This method will not be exposed to rest end point.
	 */
	
	/*@Override
	public boolean delete(Long collaboratorId) {
		if (collaboratorId != null) {
			List<ClinicalTrial> trials = clinicalTrialService.getClinicalTrialsByCollaboratorId(collaboratorId);
			trials.forEach(trial -> {
				trial.withCollaboratorId(null);
				clinicalTrialService.update(trial);
			});
			collaboratorRepository.delete(collaboratorId);
		}
		return true;
	}*/
	
	@Override
	public boolean delete(Long collaboratorId) {
		/*if (collaboratorId != null) {
			List<Program> programs = programService.getProgramsByCollaboratorId(collaboratorId);
			programs.forEach(program -> {
				//program.withCollaboratorId(null);
				programService.update(program);
			});
			collaboratorRepository.delete(collaboratorId);
		}*/
		return true;
	}

	@Override
	public ResponseObjectModel getAll(int page, int pageSize) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(page, pageSize);
		Page<Collaborator> collaboratorPage = collaboratorRepository.findAll(pageRequest);
		responseObjectModel.setData(collaboratorPage.getContent());
		responseObjectModel.setTotal(collaboratorPage.getTotalElements());
		return responseObjectModel;
	}
}
