package com.avigosolutions.criteriaservice.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;;

public interface CoordinatorService {
	public List<Coordinator> findAll();
	public Coordinator findOne(Long coordinatorId);
	public List<Coordinator> findByStudySiteId(Long studySiteId);
	public Coordinator save(Coordinator coordinator);
	public Coordinator update(Coordinator coordinator);
	public boolean delete(Long coordinatorId);
	public Page<StudySiteCoordinator> getStudySiteByCoordintorId(Long id,int page,int pageSize);
	public  List<Long> getStudySitesByCoordintorId(Long id);
}
