package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;
import com.avigosolutions.criteriaservice.repository.ClinicalStudySiteRepository;
import com.avigosolutions.criteriaservice.repository.CoordinatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteCoordinatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteRepository;
import com.avigosolutions.criteriaservice.util.CommonUtil;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CoordinatorServiceImpl implements CoordinatorService {

	@Autowired
	CoordinatorRepository coordinatorRepositTory;

	@Autowired
	StudySiteRepository studySiteRepository;

	@Autowired
	StudySiteCoordinatorRepository studySiteCoordinatorRepositTory;

	@Autowired
	ClinicalStudySiteRepository clinicalStudySiteRepository;

	@Autowired
	StudySiteService studySiteService;

	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public List<Coordinator> findAll() {

		return coordinatorRepositTory.findAll();
	}

	@Override
	public Coordinator findOne(Long coordinatorId) {

		return coordinatorRepositTory.findOne(coordinatorId);
	}

	@Override
	public List<Coordinator> findByStudySiteId(Long studySiteId) {

		return null;
	}

	@Override
	public Coordinator save(Coordinator coordinator) {

		return coordinatorRepositTory.save(coordinator);
	}

	@Override
	public Coordinator update(Coordinator coordinator) {

		return coordinatorRepositTory.save(coordinator);
	}

	@Override
	public boolean delete(Long coordinatorId) {
		if (coordinatorId != null) {
			coordinatorRepositTory.delete(coordinatorId);
			return true;
		}
		logger.info("Delete Coordinator called with null Coordinator obj");
		return false;
	}

	@Override
	public Page<StudySiteCoordinator> getStudySiteByCoordintorId(Long id, int page, int pageSize) {
		return studySiteCoordinatorRepositTory.findByCoordinatorId(id, CommonUtil.getPageRequest(page, pageSize));
	}

	@Override
	public List<Long> getStudySitesByCoordintorId(Long id) {
		
		List<Long> studySiteIds = this.studySiteCoordinatorRepositTory.findByCoordinatorId(id).stream()
				.filter(ssc -> null != ssc.getStudySiteId()).map(ssc -> ssc.getStudySiteId())
				.collect(Collectors.toList());

		/*studySiteIds = this.clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdIdIn(studySiteIds)
				.stream().filter(ssc -> null != ssc.getId().getStudySiteId()).map(ssc -> ssc.getId().getStudySiteId())
				.collect(Collectors.toList());*/
		
		return studySiteIds;
	}

}
