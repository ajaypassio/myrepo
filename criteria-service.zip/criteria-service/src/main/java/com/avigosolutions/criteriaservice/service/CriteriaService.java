package com.avigosolutions.criteriaservice.service;

import java.util.List;

import com.avigosolutions.criteriaservice.model.Criteria;

public interface CriteriaService {
	public List<Criteria> findByIdIn(List<Long> Ids);
	/**
	 * finds all the Criteria in the system
	 * @return
	 */
	public List<Criteria> findAll();
	
	/**
	 * finds the Criteria that matches the id
	 * @param id
	 * @return a Criteria or null if not found
	 */
	public Criteria findOne(Long id);
	
	/**
	 * find a Criteria based on the clinical trial id
	 * @param trialId
	 * @return a Criteria or null if not found
	 */
	public List<Criteria> findByTrialId(Long trialId);
	
	/**
	 * find a Criteria based on template id
	 * @param templateId
	 * @return a Criteria that matches the template id or null if not found
	 */
	public List<Criteria> findByTemplateId(Long templateId);
	
	/**
	 * Saves the criteria
	 * @param criteriaToBePersisted
	 * @return returns the Criteria that was saved, null otherwise
	 */
	public Criteria save(Criteria criteriaToBePersisted);
	
	/**
	 * Updates the Criteria
	 * @param criteriaToBePersisted
	 * @return returns the Criteria that was updated, null otherwise
	 */
	public Criteria update(Criteria criteriaToBePersisted);
	
	/**
	 * Deletes the Criteria identified by id
	 * @param id
	 */
	public void delete(Long id);

}
