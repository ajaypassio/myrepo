package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;

@Service
@Transactional(propagation=Propagation.SUPPORTS, readOnly = true)
public class CriteriaServiceImpl implements CriteriaService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	private CriteriaRepository criteriaRepository;
	
	@Autowired
	private ClinicalTrialRepository clinicalTrialRepository;
	
	@Override
	public List<Criteria> findAll() {
		return criteriaRepository.findAll();
	}

	@Override
	public Criteria findOne(Long id) {
		return criteriaRepository.findOne(id);
	}

	@Override
	public  List<Criteria> findByTrialId(Long trialId) {
		return criteriaRepository.findByTrialId(trialId);
	}
	
	@Override
	public  List<Criteria> findByTemplateId(Long templateId) {
		return criteriaRepository.findByTemplateId(templateId);
	}
	
	@Override
	public List<Criteria> findByIdIn(List<Long> Ids) {
		// TODO Auto-generated method stub
		return criteriaRepository.findByIdIn(Ids);
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly = false)
	public Criteria save(Criteria criteriaToBePersisted) {
		return persist(criteriaToBePersisted,false);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly = false)
	public Criteria update(Criteria criteriaToBePersisted) {
		//return criteriaRepository.
		return persist(criteriaToBePersisted,true);
	}

	@Override
	public void delete(Long criteriaToBeDeleted) {
		if (criteriaToBeDeleted != null) {
			Query query = manager.createNativeQuery("DELETE FROM CRITERIA WHERE CRITERIAID = " + criteriaToBeDeleted);
			query.executeUpdate();
			//criteriaRepository.delete(criteriaToBeDeleted);
		}
		else {
			logger.info("Delete criteria called with null Criteria object");
		}
		
	}

	
	private Criteria persist(Criteria criteriaToBePersisted, boolean isUpdate)
	{
		/*//check
		if (criteriaToBePersisted != null) {
		
			Long criteriaId = criteriaToBePersisted.getCriteriaId();
			// if update check if it has id or if the Criteria to be updated doesn't exist
			if(isUpdate && (criteriaId == null || (criteriaRepository.findOne(criteriaId) == null)))
			{
				logger.error("Update called with null or invalid criteria: " + criteriaToBePersisted.toString());
				return null;
			}
			
			ClinicalTrial trial = criteriaToBePersisted.getClinicalTrial();
			if( trial != null )
			{		
				//check if trial already exists
				ClinicalTrial existingTrial =  clinicalTrialRepository.findOne(criteriaToBePersisted.getTrialId());
				if(existingTrial == null)
				{		
					//if not save trial before criteria
					ClinicalTrial savedTrial = clinicalTrialRepository.save(trial);	
					
					criteriaToBePersisted.withTrialId(savedTrial.getTrialId());
				}
			}
			
			return criteriaRepository.save(criteriaToBePersisted);
		}
		return null;*/
		
		
		Optional<Criteria> criteriaOptional = Optional.ofNullable(criteriaToBePersisted).map(criteria ->{
			Long criteriaId = criteria.getCriteriaId();
			// if update check if it has id or if the Criteria to be updated doesn't exist
			if(isUpdate && (criteriaId == null || (criteriaRepository.findOne(criteriaId) == null)))
			{
				logger.error("Update called with null or invalid criteria service: " + criteria.toString());
				return null;
			}
			
			Optional<ClinicalTrial> trialOp = Optional.ofNullable(criteria.getClinicalTrial());
			if( trialOp.isPresent() && Optional.ofNullable( clinicalTrialRepository.findOne(criteria.getTrialId())).isPresent()) {				
					ClinicalTrial savedTrial = clinicalTrialRepository.save(trialOp.get());				
					criteriaToBePersisted.withTrialId(savedTrial.getTrialId());				
			}
			return criteriaRepository.save(criteriaToBePersisted);
		});
		
		return criteriaOptional.isPresent()?criteriaOptional.get():null;
	}
}
