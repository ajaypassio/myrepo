package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.Optional;

import com.avigosolutions.criteriaservice.model.CriteriaTemplate;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface CriteriaTemplateService {
	/**
	 * finds all the Criteria Template in the system
	 * @return 
	 */
	public List<CriteriaTemplate> findAll();
	
	/**
	 * finds the Criteria Template that matches the "id" that is passed in
	 * @param id
	 * @return a Criteria Template or null if not found
	 */
	public CriteriaTemplate findOne(Long id);
	
	/**
	 * Persists/Saves the Criteria Template
	 * @param criteriaTemplateToBePersisted
	 * @return a Criteria Template or null
	 */
	public ResponseObjectModel save(CriteriaTemplate criteriaTemplateToBePersisted);
	
	/**
	 * Updates the Criteria Template
	 * @param criteriaTemplateToBePersisted
	 * @return a Criteria Template that was updated or null
	 */
	public ResponseObjectModel update(CriteriaTemplate criteriaTemplateToBePersisted);
	
	/**
	 * Deletes the Criteria Template 
	 * @param id
	 */
	public void delete(Long id);
	
	/**
	 * Get templates by page
	 * @param start
	 * @param pageSize
	 * @return
	 */
	public ResponseObjectModel getAllByPage(int start,int pageSize) ;

}
