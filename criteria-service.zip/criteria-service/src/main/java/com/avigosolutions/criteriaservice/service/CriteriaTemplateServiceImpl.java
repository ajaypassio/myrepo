package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import com.avigosolutions.criteriaservice.model.CriteriaTemplate;
import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
import com.avigosolutions.criteriaservice.repository.CriteriaTemplateRepository;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CriteriaTemplateServiceImpl implements CriteriaTemplateService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@PersistenceContext
	private EntityManager manager;

	@Autowired
	private CriteriaRepository criteriaRepository;

	@Autowired
	private CriteriaTemplateRepository criteriaTemplateRepository;

	@Override
	public List<CriteriaTemplate> findAll() {
		return criteriaTemplateRepository.findAll();
	}

	@Override
	public ResponseObjectModel getAllByPage(int start, int pageSize) {
		ResponseObjectModel response = new ResponseObjectModel();

		Page<CriteriaTemplate> pageTemplates = criteriaTemplateRepository
				.findAll(new PageRequest(start, pageSize, new Sort(Sort.Direction.DESC, "updatedOn")));
		if (pageTemplates != null) {
			response.setData(pageTemplates.getContent());
			response.setTotal(pageTemplates.getTotalElements());
			response.setHttpStatus(HttpStatus.OK);
		} else {
			response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@Override
	public CriteriaTemplate findOne(Long id) {
		return criteriaTemplateRepository.findOne(id);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel save(CriteriaTemplate criteriaTemplateToBePersisted) {
		ResponseObjectModel response = new ResponseObjectModel();
		if (criteriaTemplateToBePersisted != null) {
			List<CriteriaTemplate> lstCriteriaTemplate = criteriaTemplateRepository
					.findByTemplateName(criteriaTemplateToBePersisted.getTemplateName());
			if (null != lstCriteriaTemplate && lstCriteriaTemplate.size() > 0) {
				response.setMessage("Criteria Template already exists");
				return response;
			}
			CriteriaTemplate savedTemplate = criteriaTemplateRepository.save(criteriaTemplateToBePersisted);
			List<Criteria> criterias = savedTemplate.getCriterias();
			if (criterias != null && criterias.size() > 0) {
				for (Criteria criteria : criterias) {
					criteria.withTemplateId(savedTemplate.getTemplateId());
					criteriaRepository.save(criteria);
				}
			}
			response.setData(savedTemplate);

		}
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel update(CriteriaTemplate criteriaTemplateToBePersisted) {
		ResponseObjectModel response = new ResponseObjectModel();
		List<CriteriaTemplate> lstCriteriaTemplate = criteriaTemplateRepository.findByTemplateNameAndIdNot(
				criteriaTemplateToBePersisted.getTemplateName(), criteriaTemplateToBePersisted.getTemplateId());
		if (null != lstCriteriaTemplate && lstCriteriaTemplate.size() > 0) {
			response.setMessage("Criteria Template already exists");
			return response;
		}
		Optional<CriteriaTemplate> ctRet = Optional.ofNullable(criteriaTemplateToBePersisted).map(cTemplate -> {

			CriteriaTemplate criteriaTemplate = criteriaTemplateRepository.findById(cTemplate.getTemplateId());
			if (criteriaTemplate == null)
				logger.error("Update called on an nonextistent criteria template: "
						+ criteriaTemplateToBePersisted.toString());
			return criteriaTemplate;
		}).map(ct -> criteriaTemplateRepository.save(criteriaTemplateToBePersisted));
		response.setData(ctRet);
		return response;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void delete(Long criteriaTemplateIdToBeDeleted) {
		if (criteriaTemplateIdToBeDeleted != null) {
			Query query = manager.createNativeQuery(
					"DELETE FROM CRITERIATEMPLATE WHERE TEMPLATEID = " + criteriaTemplateIdToBeDeleted);
			query.executeUpdate();
		} else {
			logger.info("Delete criteriatemplate called with null CriteriaTemplate obj");
		}

	}

}
