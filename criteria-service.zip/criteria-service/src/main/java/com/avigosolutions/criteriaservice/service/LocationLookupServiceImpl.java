package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.State;
import com.avigosolutions.criteriaservice.repository.CityRepository;
import com.avigosolutions.criteriaservice.repository.StateRepository;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class LocationLookupServiceImpl implements LocationLoookupService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CityRepository cityRepository;

	@Autowired
	private StateRepository stateRepository;

	@Override
	public List<City> getCitiesList(String cityName, int start, int page) {
		List<City> cities = null;

		if (page < 0) {
			cities = this.cityRepository.findAll();
		} else {
			cities = this.cityRepository.findByCityNameContaining(cityName, new PageRequest(start, page));
		}
		return cities;
	}

	@Override
	public List<State> getStatesList(String stateName, int start, int page) {

		List<State> states = null;

		if (page < 0) {
			states = this.stateRepository.findAll();
		} else {
			states = this.stateRepository.findByStateNameContaining(stateName, new PageRequest(start, page));
		}

		return states;
	}
	
	@Override
	public List<City> getCitiesListForStates(List<Long> stateList, String cityName, int start, int page) {
		List<City> cities = null;

		if (page < 0) {
			cities = this.cityRepository.findAll();
		} else {
			cities = this.cityRepository.findByCityNameContainingAndStateIdIn(cityName, stateList,
					new PageRequest(start, page));
		}
		return cities;
	}

}
