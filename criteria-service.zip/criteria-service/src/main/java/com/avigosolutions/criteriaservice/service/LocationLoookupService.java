package com.avigosolutions.criteriaservice.service;

import java.util.List;

import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.State;

public interface LocationLoookupService {

	public List<City> getCitiesList(String cityName, int start, int page);

	public List<State> getStatesList(String stateName, int start, int page);

	public List<City> getCitiesListForStates(List<Long> stateList, String stateName, int start, int page);

}
