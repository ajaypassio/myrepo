package com.avigosolutions.criteriaservice.service;

import java.io.Serializable;

import com.avigosolutions.criteriaservice.request.model.PhysicianCriteria;
import com.avigosolutions.criteriaservice.request.model.PhysicianCriteriaRequest;
import com.avigosolutions.criteriaservice.request.model.UserNameRequest;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface PhysicianCriteriaService extends Serializable {

	public ResponseObjectModel createCriteria(PhysicianCriteriaRequest physicianCriteria) throws Exception;
	
	public ResponseObjectModel updateCriteria(PhysicianCriteriaRequest physicianCriteria) throws Exception;
	
	public ResponseObjectModel getCriteria(UserNameRequest userNameRequest);
	
	public PhysicianCriteria getPhysicianWithGeneratedStatus();
	
	public PhysicianCriteria updatePhysicianStatus(PhysicianCriteriaRequest physicianCriteria);
	
	public String saveCountPhysicianResultsButtonEnableDisable(Long statusId, PhysicianCriteria physicianCriteria, String sourcePage);
	
	public ResponseObjectModel generatePhysicianResults(UserNameRequest userNameRequest);
	
}
