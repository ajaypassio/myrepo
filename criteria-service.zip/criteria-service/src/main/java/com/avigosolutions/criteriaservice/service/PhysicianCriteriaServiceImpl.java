package com.avigosolutions.criteriaservice.service;

import java.util.Date;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.criteriaservice.constant.Constants;
import com.avigosolutions.criteriaservice.enums.PhysicianCriteriaEnums;
import com.avigosolutions.criteriaservice.json.parser.JSONContractParserIE;
import com.avigosolutions.criteriaservice.json.parser.container.ContainerType;
import com.avigosolutions.criteriaservice.messaging.InclusionExclusionPublisher;
import com.avigosolutions.criteriaservice.messaging.NotificationPublisher;
import com.avigosolutions.criteriaservice.messaging.models.NotificationPayload;
import com.avigosolutions.criteriaservice.repository.PhysicianCriteriaRepository;
import com.avigosolutions.criteriaservice.request.model.PhysicianCriteria;
import com.avigosolutions.criteriaservice.request.model.PhysicianCriteriaRequest;
import com.avigosolutions.criteriaservice.request.model.UserNameRequest;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

@Service
public class PhysicianCriteriaServiceImpl implements PhysicianCriteriaService {

	private static final long serialVersionUID = 2096478722754165118L;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private PhysicianCriteriaRepository physicianCriteriaRepository;

	@Autowired
	JSONContractParserIE uiJSONContractParser;

	@Autowired
	private InclusionExclusionPublisher inclusionExclusionPublisher;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${clinician.processor.persistence.url}")
	private String clinicianProcessorPersistenceUrl;
	
	@Autowired
	private NotificationPublisher notificationPublisher;

	@Override
	@Transactional(rollbackFor = {Exception.class})
	public ResponseObjectModel createCriteria(PhysicianCriteriaRequest physicianCriteriaRequest) throws Exception {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		Long maxValue = physicianCriteriaRepository.getMaxCount();
		// UserName Validation
		if (!StringUtils.isEmpty(physicianCriteriaRequest.getUserName())) {
			PhysicianCriteria criteria = getPhysicianCriteria(physicianCriteriaRequest);
			if (!physicianCriteriaRequest.isCountClicked()) {
				criteria.setStatusId(Long.valueOf(PhysicianCriteriaEnums.Draft.getValue()));
			} else {
				criteria.setStatusId(Long.valueOf(PhysicianCriteriaEnums.Submitted.getValue()));
			}
			criteria.setCreatedOn(new Date());
			criteria.setUpdatedOn(new Date());
			criteria.setCriteriaId(Long.valueOf(CommonUtil.getCriteriaId(maxValue)));
			physicianCriteriaRepository.save(criteria);

			// Physician criteria process to BDL contract json and put on azure
			if (criteria.isCountClicked()) {
				physicianInclusionCriteriaProcess(criteria);
				//Notification producer: message for count start
				publishNotification(criteria, Constants.PHYSICIAN_SEARCH_COUNTS_START);
			}
			String message = saveCountPhysicianResultsButtonEnableDisable(criteria.getStatusId(), criteria, Constants.NEWSEARCH);
			responseObjectModel.setData(criteria);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage(message);

		} else {
			PhysicianCriteria criteria = new PhysicianCriteria();
			Long statusId = null;
			if(!physicianCriteriaRequest.isCountClicked()){
				statusId = Long.valueOf(PhysicianCriteriaEnums.Draft.getValue());
			} else {
				statusId = Long.valueOf(PhysicianCriteriaEnums.Submitted.getValue());
			}
			saveCountPhysicianResultsButtonEnableDisable(statusId, criteria, Constants.NEWSEARCH);
			responseObjectModel.setData(criteria);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(Constants.USER_NAME_BLANK_OR_NULL);
		}
		return responseObjectModel;
	}
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObjectModel updateCriteria(PhysicianCriteriaRequest physicianCriteria) throws Exception {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		Optional<PhysicianCriteria> physiciancriteriaFromDB = physicianCriteriaRepository
				.findByUserName(physicianCriteria.getUserName());
		if (physiciancriteriaFromDB.isPresent()) {
			PhysicianCriteria criteria = physiciancriteriaFromDB.get();
			// check if status is PhysicianGenerated or PhysicianPopulated. 
			// then Need to send message to UI
			if (criteria.getStatusId() == PhysicianCriteriaEnums.PhysicianPopulationInitiated.getValue().longValue()) {
				//Both fields disabled , populated flag will be false, message = search is progress
				String message = saveCountPhysicianResultsButtonEnableDisable(criteria.getStatusId(), criteria, Constants.NEWSEARCH);
				responseObjectModel.setData(criteria);
				responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
				responseObjectModel.setMessage(message);
				return responseObjectModel;
			}
			criteria.setQueryName(physicianCriteria.getQueryName());
			criteria.setPhysicianLocation(physicianCriteria.getPhysicianLocation());
			criteria.setCountClicked(physicianCriteria.isCountClicked());
			criteria.setInclusionCriteria(physicianCriteria.getInclusionCriteria());
			criteria.setCount1572(0);
			criteria.setCountQuestAnd1572(0);
			criteria.setTotalPatientsCount(0);
			criteria.setCountQuest(0);
			criteria.setTotalPhysicianCount(0);
			if (!physicianCriteria.isCountClicked()) {
				criteria.setStatusId(Long.valueOf(PhysicianCriteriaEnums.Draft.getValue()));
			} else {
				criteria.setStatusId(Long.valueOf(PhysicianCriteriaEnums.Submitted.getValue()));
			}
			criteria.setUpdatedOn(new Date());
			physicianCriteriaRepository.save(criteria);

			// Physician criteria process to BDL contract json and put on azure
			if (physicianCriteria.isCountClicked()) {
				physicianInclusionCriteriaProcess(criteria);
				//Notification producer: message for count start
				publishNotification(criteria, Constants.PHYSICIAN_SEARCH_COUNTS_START);
			}
			String message = saveCountPhysicianResultsButtonEnableDisable(criteria.getStatusId(), criteria, Constants.NEWSEARCH);
			responseObjectModel.setData(criteria);
			responseObjectModel.setMessage(message);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
		} else {
			PhysicianCriteria criteria = new PhysicianCriteria();
			Long statusId = null;
			if(!physicianCriteria.isCountClicked()){
				statusId = Long.valueOf(PhysicianCriteriaEnums.Draft.getValue());
			} else {
				statusId = Long.valueOf(PhysicianCriteriaEnums.Submitted.getValue());
			}
			saveCountPhysicianResultsButtonEnableDisable(statusId, criteria, Constants.NEWSEARCH);
			responseObjectModel.setData(criteria);
			responseObjectModel.setHttpStatus(HttpStatus.OK);
			responseObjectModel.setMessage(Constants.USER_NOT_FOUND);
		}
		return responseObjectModel;
	}

	@Override
	public ResponseObjectModel getCriteria(UserNameRequest userNameRequest) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (!StringUtils.isEmpty(userNameRequest.getUserName())) {
			Optional<PhysicianCriteria> physicianCriteriaOptional = physicianCriteriaRepository
					.findByUserName(userNameRequest.getUserName());
			if (physicianCriteriaOptional.isPresent()) {
				PhysicianCriteria physicianCriteria = physicianCriteriaOptional.get();
				String message = saveCountPhysicianResultsButtonEnableDisable(physicianCriteria.getStatusId(),physicianCriteria,userNameRequest.getSource() );
				responseObjectModel.setData(physicianCriteria);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(message);
			} else {
				PhysicianCriteria physicianCriteria = new PhysicianCriteria();
				saveCountPhysicianResultsButtonEnableDisable(physicianCriteria.getStatusId(),physicianCriteria,userNameRequest.getSource());
				responseObjectModel.setData(physicianCriteria);
				responseObjectModel.setHttpStatus(HttpStatus.OK);
				responseObjectModel.setMessage(Constants.USER_NOT_FOUND);
			}
		} else {
			PhysicianCriteria criteria = new PhysicianCriteria();
			saveCountPhysicianResultsButtonEnableDisable(Long.valueOf(PhysicianCriteriaEnums.Draft.getValue()), criteria, userNameRequest.getSource());
			responseObjectModel.setData(criteria);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(Constants.USER_NAME_BLANK_OR_NULL);
		}
		return responseObjectModel;
	}

	public PhysicianCriteria getPhysicianCriteria(PhysicianCriteriaRequest physicianCriteriaRequest) {
		PhysicianCriteria physicianCriteria = new PhysicianCriteria();
		physicianCriteria.setCriteriaId(physicianCriteriaRequest.getCriteriaId());
		physicianCriteria.setQueryName(physicianCriteriaRequest.getQueryName());
		physicianCriteria.setUserName(physicianCriteriaRequest.getUserName());
		physicianCriteria.setInclusionCriteria(physicianCriteriaRequest.getInclusionCriteria());
		physicianCriteria.setPhysicianLocation(physicianCriteriaRequest.getPhysicianLocation());
		physicianCriteria.setStatusId(physicianCriteriaRequest.getStatusId());
		physicianCriteria.setCountClicked(physicianCriteriaRequest.isCountClicked());
		return physicianCriteria;
	}

	@Override
	public String saveCountPhysicianResultsButtonEnableDisable(Long statusId, PhysicianCriteria physicianCriteria,
			String sourcePage) {
		String message = "";
		if ("newSearch".equalsIgnoreCase(sourcePage) && null != statusId) {
			if (statusId == PhysicianCriteriaEnums.Draft.getValue().longValue()) {
				physicianCriteria.setSave(Constants.ENABLED);
				physicianCriteria.setCount(Constants.DISABLED);
				if (!StringUtils.isEmpty(physicianCriteria.getInclusionCriteria())
						|| !StringUtils.isEmpty(physicianCriteria.getPhysicianLocation())) {
					physicianCriteria.setCount(Constants.ENABLED);
				}
				message = "";
			} else if (statusId == PhysicianCriteriaEnums.Submitted.getValue().longValue()) {
				physicianCriteria.setSave(Constants.DISABLED);
				physicianCriteria.setCount(Constants.DISABLED);
				message = Constants.SEARCH_IN_PROGRESS;
			} else if (statusId == PhysicianCriteriaEnums.CountsGenerated.getValue().longValue()) {
				physicianCriteria.setSave(Constants.ENABLED);
				physicianCriteria.setCount(Constants.ENABLED);
				message = "";
			} else if (statusId == PhysicianCriteriaEnums.PhysicianGenerated.getValue().longValue()) {
				physicianCriteria.setSave(Constants.ENABLED);
				physicianCriteria.setCount(Constants.ENABLED);
				message = Constants.SEARCH_COUNT_STATICS_AVAIBLE_DO_YOU_WANT_TO_REPLACE;
			} else if (statusId == PhysicianCriteriaEnums.PhysicianPopulationInitiated.getValue().longValue()) {
				physicianCriteria.setSave(Constants.DISABLED);
				physicianCriteria.setCount(Constants.DISABLED);
				physicianCriteria.setIsPhysicianPopulated(false);
				message = Constants.SEARCH_IN_PROGRESS;
			} else if (statusId == PhysicianCriteriaEnums.PhysicianPopulated.getValue().longValue()) {
				physicianCriteria.setSave(Constants.ENABLED);
				physicianCriteria.setCount(Constants.ENABLED);
				physicianCriteria.setIsPhysicianPopulated(true);
				message = Constants.SEARCH_AVAIBLE_DO_YOU_WANT_TO_REPLACE;
			} else {
				physicianCriteria.setSave(Constants.ENABLED);
				physicianCriteria.setCount(Constants.DISABLED);
				message = "";
			}
		} else if ("lastSearch".equalsIgnoreCase(sourcePage) && null != statusId) {
			if (statusId == PhysicianCriteriaEnums.Draft.getValue().longValue()) {
				physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
				physicianCriteria.setCreateCampaign(Constants.DISABLED);
				message = "";
			} else if (statusId == PhysicianCriteriaEnums.Submitted.getValue().longValue()) {
				physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
				physicianCriteria.setCreateCampaign(Constants.DISABLED);
				message = Constants.USER_NOT_FOUND;
			} else if (statusId == PhysicianCriteriaEnums.CountsGenerated.getValue().longValue()) {
				if (physicianCriteria.getTotalPatientsCount() == 0 && physicianCriteria.getTotalPhysicianCount() == 0) {
					physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
					physicianCriteria.setCreateCampaign(Constants.DISABLED);
					message = Constants.CURRENT_SEARCH_CRITERIA_HAS_NO_PHYSICIANS;
				} else {
					physicianCriteria.setGeneratePhysicianResults(Constants.ENABLED);
					physicianCriteria.setCreateCampaign(Constants.DISABLED);
					message = "";
				}
			} else if (statusId == PhysicianCriteriaEnums.PhysicianGenerated.getValue().longValue()) {
				physicianCriteria.setGeneratePhysicianResults(Constants.ENABLED);
				physicianCriteria.setCreateCampaign(Constants.DISABLED);
				message = Constants.SEARCH_AVAIBLE_DO_YOU_WANT_TO_REPLACE;
			} else if (statusId == PhysicianCriteriaEnums.PhysicianPopulationInitiated.getValue().longValue()) {
				physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
				physicianCriteria.setCreateCampaign(Constants.DISABLED);
				message = Constants.SEARCH_IN_PROGRESS;
			} else if (statusId == PhysicianCriteriaEnums.PhysicianPopulated.getValue().longValue()) {
				physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
				physicianCriteria.setCreateCampaign(Constants.ENABLED);
				physicianCriteria.setIsPhysicianPopulated(true);
				message = Constants.SEARCH_AVAIBLE_DO_YOU_WANT_TO_REPLACE;
			} else {
				physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
				physicianCriteria.setCreateCampaign(Constants.DISABLED);
				message = "";
			}
		} else {
			physicianCriteria.setSave(Constants.ENABLED);
			physicianCriteria.setCount(Constants.DISABLED);
			physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);
			physicianCriteria.setCreateCampaign(Constants.DISABLED);
		}
		return message;
	}

	public void physicianInclusionCriteriaProcess(PhysicianCriteria physicianCriteria) throws Exception {
		logger.info("Process start for physicianinclusionCriteria");
		JsonObject physicianCriteriaBDContract = new JsonObject();
		ObjectMapper mapper = new ObjectMapper();
		
		physicianCriteriaBDContract.add("userName", new JsonParser().parse(physicianCriteria.getUserName()));
		physicianCriteriaBDContract.add("queryName", new JsonPrimitive(physicianCriteria.getQueryName()));
		if (!CommonUtil.isNullOrBlank(physicianCriteria.getInclusionCriteria())) {
			physicianCriteriaBDContract.add("inclusionCriteria",
					new JsonParser().parse(mapper.writeValueAsString(uiJSONContractParser.parseJSONInput(
							mapper.readTree(physicianCriteria.getInclusionCriteria()),
							ContainerType.INCLUSION_CRITERIA))).getAsJsonObject());
		}
		physicianCriteriaBDContract.add("PhysicianLocation", new JsonParser().parse(physicianCriteria.getPhysicianLocation()));
		logger.info("physicianCriteriaBDContract : {}", physicianCriteriaBDContract.toString());

		boolean filewrite = inclusionExclusionPublisher.
				publishInclusionCriteriaForPhysicianSearch(physicianCriteriaBDContract.toString(), physicianCriteria.getUserName());
		logger.info("container filewrite status>>", filewrite);
	}

	@Override
	public PhysicianCriteria getPhysicianWithGeneratedStatus() {
		logger.info("Process start for getPhysicianWithGeneratedStatus");
		PhysicianCriteria physicianCriteria = null;
		Optional<PhysicianCriteria> physicianCriteriaOptional = physicianCriteriaRepository
				.getPhysicianDetailsByStatus();
		if (physicianCriteriaOptional.isPresent()) {
			physicianCriteria = physicianCriteriaOptional.get();
		}
		return physicianCriteria;
	}

	@Override
	public PhysicianCriteria updatePhysicianStatus(PhysicianCriteriaRequest physicianCriteriaRequest) {
		logger.info("Process start for updatePhysicianStatus");
		PhysicianCriteria physicianCriteria = null;
		Optional<PhysicianCriteria> physicianCriteriaOptional = physicianCriteriaRepository
				.findByUserName(physicianCriteriaRequest.getUserName());
		if (physicianCriteriaOptional.isPresent()) {
			physicianCriteria = physicianCriteriaOptional.get();
			physicianCriteria.setStatusId(PhysicianCriteriaEnums.PhysicianPopulated.getValue().longValue());
			physicianCriteria = physicianCriteriaRepository.save(physicianCriteria);
		}
		return physicianCriteria;
	}
	
	
	@Override
	public ResponseObjectModel generatePhysicianResults(UserNameRequest userNameRequest) {
		logger.info("Process start for generatePhysicianResults");
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		if (!StringUtils.isEmpty(userNameRequest)) {
			Optional<PhysicianCriteria> physicianCriteriaOptional = physicianCriteriaRepository
					.findByUserName(userNameRequest.getUserName());
			if (physicianCriteriaOptional.isPresent()) {
					PhysicianCriteria physicianCriteria = physicianCriteriaOptional.get();
					if (physicianCriteria.getStatusId() == PhysicianCriteriaEnums.PhysicianGenerated.getValue().longValue()) {
						physicianCriteria.setCountClicked(false);
						physicianCriteria.setStatusId(Long.valueOf(PhysicianCriteriaEnums.PhysicianPopulationInitiated.getValue()));
						physicianCriteriaRepository.save(physicianCriteria);
						//Notification producer: Physician Search Results-Start
						publishNotification(physicianCriteria, Constants.PHYSICIAN_SEARCH_RESULTS_START);
						performMongoPersistence(userNameRequest.getUserName(),physicianCriteria);
					}
					saveCountPhysicianResultsButtonEnableDisable(PhysicianCriteriaEnums.PhysicianPopulationInitiated.getValue().longValue(), physicianCriteria, Constants.LASTSEARCH);
					/*physicianCriteria.setSave(Constants.DISABLED);
					physicianCriteria.setCount(Constants.DISABLED);
					physicianCriteria.setGeneratePhysicianResults(Constants.DISABLED);*/
					responseObjectModel.setData(physicianCriteria);
					responseObjectModel.setHttpStatus(HttpStatus.OK);
					responseObjectModel.setMessage(Constants.SEARCH_IN_PROGRESS);
				} else {
					PhysicianCriteria criteria = new PhysicianCriteria();
					saveCountPhysicianResultsButtonEnableDisable(Long.valueOf(1), criteria, Constants.LASTSEARCH);
					responseObjectModel.setData(criteria);
					responseObjectModel.setHttpStatus(HttpStatus.OK);
					responseObjectModel.setMessage(Constants.USER_NOT_FOUND);
			}
		} else {
			PhysicianCriteria criteria = new PhysicianCriteria();
			saveCountPhysicianResultsButtonEnableDisable(Long.valueOf(PhysicianCriteriaEnums.Draft.getValue()), criteria, userNameRequest.getSource());
			responseObjectModel.setData(criteria);
			responseObjectModel.setHttpStatus(HttpStatus.BAD_REQUEST);
			responseObjectModel.setMessage(Constants.USER_NAME_BLANK_OR_NULL);
		}
		return responseObjectModel;
	}
	
	private void performMongoPersistence(String userName, PhysicianCriteria physicianCriteria) {
		logger.info("Process started for MongoPersistence for user : {}", userName);
		CompletableFuture.supplyAsync(() -> {
			HttpHeaders headers = prepareHeader();
			HttpEntity<PhysicianCriteriaRequest> httpEntity = new HttpEntity<>(
					generateClinicianProcessorObject(userName), headers);
			return restTemplate.postForEntity(clinicianProcessorPersistenceUrl, httpEntity, Boolean.class).getBody();
		}).whenComplete((result, ex) -> {
			if (!ObjectUtils.isEmpty(ex)) {
				updatePhysicianStatus(physicianCriteria,
						PhysicianCriteriaEnums.PhysicianPopulationFailed.getValue().longValue());
			}
		}).thenAcceptAsync(jobStatus -> {
			if (jobStatus.booleanValue()) {
				updatePhysicianStatus(physicianCriteria,
						PhysicianCriteriaEnums.PhysicianPopulated.getValue().longValue());
				logger.info("Process completed for MongoPersistence for user : {}", userName);
				//Notification producer: message for Physician Search Results-Success
				publishNotification(physicianCriteria, Constants.PHYSICIAN_SEARCH_RESULTS_SUCCESS);
			} else {
				updatePhysicianStatus(physicianCriteria,
						PhysicianCriteriaEnums.PhysicianPopulationFailed.getValue().longValue());
				//Notification producer: message for Physician Search Results-Failure
				publishNotification(physicianCriteria, Constants.PHYSICIAN_SEARCH_RESULTS_FAILURE);
			}
		});

	}
	
	public static HttpHeaders prepareHeader() {
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		return header;
	}
	
	public PhysicianCriteriaRequest generateClinicianProcessorObject(String userName) {
		PhysicianCriteriaRequest physicianCriteriaRequest = new PhysicianCriteriaRequest();
		physicianCriteriaRequest.setUserName(userName);
		return physicianCriteriaRequest;
	}
	
	private void updatePhysicianStatus(PhysicianCriteria physicianCriteria, Long status) {
		physicianCriteria.setStatusId(status);
		physicianCriteriaRepository.save(physicianCriteria);
	}
	
	private void publishNotification(PhysicianCriteria criteria, String eventName){
		NotificationPayload notificationPayload = new NotificationPayload();
		notificationPayload.setId(criteria.getCriteriaId());
		notificationPayload.setName(criteria.getQueryName());
		notificationPayload.setEventName(eventName);
		notificationPayload.setUserid(criteria.getUserName());
		notificationPublisher.publishNotification(notificationPayload);
	}


}
