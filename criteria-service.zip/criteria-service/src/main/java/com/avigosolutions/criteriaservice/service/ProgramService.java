package com.avigosolutions.criteriaservice.service;

import java.util.List;

import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Phase;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.model.ProgramStatus;
import com.avigosolutions.criteriaservice.model.Sponsor;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface ProgramService {
	public List<Program> findAll();

	public ResponseObjectModel findAll(FilterRequestModel filterModel);

	public Program findOne(Long programId);

	public ResponseObjectModel save(Program program);

	public ResponseObjectModel update(Program program);

	public boolean delete(Long programId);
	// public List<Program> getProgramsByCollaboratorId(Long collaboratorId);

	// Get all programs based on page and pagesize
	public ResponseObjectModel getAll(int page, int pageSize);

	public List<Sponsor> getAllSponsors();

	public List<Sponsor> getSponsorsBySearch(String name, int page, int pageSize);

	public List<Phase> getAllPhases();

	public List<ProgramStatus> getAllProgramStatus();

	/**
	 * updates isdeleted true
	 * 
	 * @param programId
	 * @return
	 */
	public ResponseObjectModel updateDeleted(Long programId);

	ResponseObjectModel exportCSV(FilterRequestModel filterModel);
}
