package com.avigosolutions.criteriaservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.SetJoin;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.Collaborator;
import com.avigosolutions.criteriaservice.model.Phase;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.model.ProgramStatus;
import com.avigosolutions.criteriaservice.model.Sponsor;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;
import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.model.ProgramCollaborator;
import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
import com.avigosolutions.criteriaservice.repository.CollaboratorRepository;
import com.avigosolutions.criteriaservice.repository.PhaseRepository;
import com.avigosolutions.criteriaservice.repository.ProgramRepository;
import com.avigosolutions.criteriaservice.repository.ProgramStatusRepository;
import com.avigosolutions.criteriaservice.repository.SponsorRepository;
import com.avigosolutions.criteriaservice.repository.TherapeuticAreaRepository;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.util.CommonUtil;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ProgramServiceImpl implements ProgramService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	ModelMapper modelMapper = new ModelMapper();
	
	@Autowired
	ProgramRepository programRepository;

	@Autowired
	private SponsorRepository sponsorRepository;

	@Autowired
	private PhaseRepository phaseRepository;

	@Autowired
	ProgramStatusRepository programStatusRepository;

	@Autowired
	private TherapeuticAreaRepository therapeuticAreaRepository;

	@Autowired
	ClinicalTrialService clinicalTrialService;
	
	@Autowired
	ClinicalTrialRepository clinicaltrialRepository;
	
	
	@Override
	public List<Program> findAll() {

		return programRepository.findAll();
	}

	/*
	 * public ResponseObjectModel findAll(FilterRequestModel filterModel) {
	 * ResponseObjectModel responseObject = new ResponseObjectModel(); List<Long>
	 * collaboratorList = filterModel.getCollaboratorList();// .isEmpty()?null : //
	 * filterModel.getCollaboratorList(); List<Long> sponsorList =
	 * filterModel.getSponsorList();// .isEmpty()?null :
	 * filterModel.getSponsorList(); List<Long> therapeuticAreaList =
	 * filterModel.getTherapeuticAreaList();// .isEmpty()?null : //
	 * filterModel.getTherapeuticAreaList(); PageRequest pageRequest =
	 * CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize());
	 * 
	 * Page<Program> programList = !CommonUtil.IsNullOrEmpty(collaboratorList) &&
	 * !CommonUtil.IsNullOrEmpty(sponsorList) &&
	 * !CommonUtil.IsNullOrEmpty(therapeuticAreaList) ? programRepository.
	 * findByCollaboratorIdInAndSponsorIdInAndTherapeuticAreaIdInAndDeletedFalse(
	 * collaboratorList, sponsorList, therapeuticAreaList, pageRequest) :
	 * !CommonUtil.IsNullOrEmpty(collaboratorList) &&
	 * !CommonUtil.IsNullOrEmpty(sponsorList) ?
	 * programRepository.findByCollaboratorIdInAndSponsorIdInAndDeletedFalse(
	 * collaboratorList, sponsorList, pageRequest) :
	 * !CommonUtil.IsNullOrEmpty(sponsorList) ?
	 * programRepository.findBySponsorIdInAndDeletedFalse(sponsorList, pageRequest)
	 * : !CommonUtil.IsNullOrEmpty(collaboratorList) ?
	 * programRepository.findByCollaboratorIdInAndDeletedFalse(sponsorList,
	 * pageRequest) : !CommonUtil.IsNullOrEmpty(collaboratorList) ?
	 * programRepository.findByCollaboratorIdInAndDeletedFalse( collaboratorList,
	 * pageRequest) : !CommonUtil.IsNullOrEmpty(therapeuticAreaList) ?
	 * programRepository .findByTherapeuticAreaIdInAndDeletedFalse(
	 * therapeuticAreaList, pageRequest) :
	 * programRepository.findByDeletedFalse(pageRequest);
	 * 
	 * responseObject.setData(programList);
	 * responseObject.setTotal(programList.getTotalElements()); return
	 * responseObject; }
	 */

	public ResponseObjectModel findAll(FilterRequestModel filterModel) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize(),"createdOn","desc");
		Page<Program> programList = programRepository.findAll(getProgramSpecification(filterModel), pageRequest);

		responseObject.setData(programList);
		responseObject.setTotal(programList.getTotalElements());
		return responseObject;
	}

	@Override
	public ResponseObjectModel exportCSV(FilterRequestModel filterModel) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize());
		Page<Program> programList = programRepository.findAll(getProgramSpecification(filterModel), pageRequest);

		responseObject.setData(programList);
		responseObject.setTotal(programList.getTotalElements());
		return responseObject;
	}

	private Specification<Program> getProgramSpecification(FilterRequestModel filterModel) {

		return (root, query, cb) -> {
			List<Long> collaboratorList = filterModel.getCollaboratorList();
			List<Long> sponsorList = filterModel.getSponsorList();
			List<Long> therapeuticAreaList = filterModel.getTherapeuticAreaList();
			Root<ProgramCollaborator> rootPC = query.from(ProgramCollaborator.class);

			List<Predicate> predicates = new ArrayList<>();

			predicates.add(cb.isFalse(root.get("deleted")));// to get the record with deleted as false

			if (null != filterModel.getCoordinatorId()) {
				Root<StudySiteCoordinator> rootssc = query.from(StudySiteCoordinator.class);
				Root<ClinicalTrialStudySite> rootClinical = query.from(ClinicalTrialStudySite.class);
				Root<ClinicalTrial> rootTrial = query.from(ClinicalTrial.class);
				predicates.add(cb.isTrue(rootClinical.get("isActive").in(filterModel.getActiveList())));
				predicates.add(cb.equal(rootssc.get("coordinatorId"), filterModel.getCoordinatorId()));
				predicates.add(cb.and(
						cb.equal(rootssc.get("studySiteId"), rootClinical.get("clinicalStudySiteId").get("studySiteId")),
						cb.equal(rootClinical.get("clinicalStudySiteId").get("id"), rootTrial.get("id"))));
				predicates.add(cb.equal(rootTrial.get("programId"), root.get("programId")));

				/*
				 * List<Long> studySiteIds =
				 * this.studySiteCoordinatorRepository.findByCoordinatorId(filterModel.
				 * getCoordinatorId()).stream().map(ssc->ssc.getStudySiteId()).collect(
				 * Collectors.toList()); List<Long> trialIds =
				 * this.clinicalStudySiteRepository.findByClinicalStudySiteIdStudySiteId(
				 * studySiteIds.get(0)).stream().map(css->css.getId().getId()).collect(
				 * Collectors.toList());
				 * 
				 * predicates.add(cb.isTrue(root.get("id").in(trialIds)));
				 */

			}

			if (!CommonUtil.IsNullOrEmpty(collaboratorList)) {
				predicates.add(cb.isTrue(rootPC.get("collaborator").get("id").in(collaboratorList)));
				predicates.add(cb.equal(rootPC.get("program").get("programId"), root.get("programId")));
			}

			if (!CommonUtil.IsNullOrEmpty(sponsorList)) {
				predicates.add(cb.isTrue(root.get("sponsor").get("id").in(sponsorList)));
			}

			if (!CommonUtil.IsNullOrEmpty(therapeuticAreaList)) {
				predicates.add(cb.isTrue(root.get("therapeuticArea").get("id").in(therapeuticAreaList)));
			}

			query.distinct(true);

			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	@Override
	public Program findOne(Long programId) {
		Program pgm = programRepository.findOne(programId);
		populateProgramAttributes(pgm);
		return pgm;
	}

	@Override
	public ResponseObjectModel save(Program program) {
		ResponseObjectModel response = new ResponseObjectModel();
		Program existingProg = programRepository.findByName(program.getName());
		if (existingProg != null) {
			logger.error("Duplicate program found on insert - {}", program.getName());
			response.setMessage("Program already exists");
			return response;
		}

		response.setData(programRepository.save(program));
		return response;
	}

	@Override
	public ResponseObjectModel update(Program program) {
		ResponseObjectModel response = new ResponseObjectModel();
		Program existingProg = programRepository.findByNameAndProgramIdNot(program.getName(), program.getId());
		if (program.getSponsorId() != null) {
			program.withSponsor(sponsorRepository.findOne(program.getSponsorId()));
		}
		if (program.getTherapeuticAreaId() != null) {
			program.withTherapeuticArea(therapeuticAreaRepository.findOne(program.getTherapeuticAreaId()));
		}
		if (program.getPhaseId() != null) {
			program.withPhase(phaseRepository.findOne(program.getPhaseId()));
		}
		if (existingProg != null) {
			logger.error("Duplicate program found on insert - {}", program.getName());
			response.setHttpStatus(HttpStatus.FOUND);
			response.setMessage("Program already exists");
			return response;
		}
		response.setHttpStatus(HttpStatus.OK);
		response.setData(programRepository.save(program));
		return response;
	}

	@Override
	public boolean delete(Long programId) {
		if (programId != null) {
			List<ClinicalTrial> trials = clinicalTrialService.getClinicalTrialsByProgramId(programId);
			trials.forEach(trial -> {
				trial.withProgramId(null);
				clinicalTrialService.update(trial);
			});
			programRepository.delete(programId);
		}
		return true;
	}

	@Override
	public ResponseObjectModel updateDeleted(Long programId) {
		ResponseObjectModel response = new ResponseObjectModel();
		if (programId != null) {
			Optional<Program> program = programRepository.findByProgramId(programId);
			program.ifPresent(prg -> {
				prg.withDeleted(true);
				programRepository.save(prg);
				response.setData(true);
			});
		}
		return response;
	}

	/*
	 * public List<Program> getProgramsByCollaboratorId(Long collaboratorId) {
	 * return this.programRepository.findByCollaboratorId(collaboratorId); }
	 */

	@Override
	public ResponseObjectModel getAll(int page, int pageSize) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(page, pageSize, "createdOn", "desc");
		Page<Program> programPage = programRepository.findByDeletedFalse(pageRequest);
		List<Program> pgmList = programPage.getContent();
		for (Program pgm : pgmList) {
			populateProgramAttributes(pgm);
		}
		responseObjectModel.setData(pgmList);
		responseObjectModel.setTotal(programPage.getTotalElements());
		return responseObjectModel;
	}

	@Override
	public List<Sponsor> getAllSponsors() {
		return this.sponsorRepository.findAll();
	}

	@Override
	public List<Sponsor> getSponsorsBySearch(String name, int page, int pageSize) {
		if (CommonUtil.isNullOrBlank(name))
			return this.sponsorRepository.findAll(CommonUtil.getPageRequest(page, pageSize)).getContent();
		return this.sponsorRepository.findByNameContaining(name, CommonUtil.getPageRequest(page, pageSize))
				.getContent();
	}

	@Override
	public List<Phase> getAllPhases() {
		return this.phaseRepository.findAll();
	}

	public List<ProgramStatus> getAllProgramStatus() {
		return this.programStatusRepository.findAll();
	}

	private Program populateProgramAttributes(Program program) {
		if (program != null) {

			Long sponsorId = program.getSponsorId();
			Integer phaseId = program.getPhaseId();
			// Long collaboratorId = program.getCollaboratorId();
			Long therapeuticAreaId = program.getTherapeuticAreaId();
			Integer programStatusId = program.getProgramStatusId();

			if (therapeuticAreaId != null && therapeuticAreaId.longValue() > 0) {
				program.withTherapeuticArea(this.therapeuticAreaRepository.findOne(therapeuticAreaId));
			}

			if (phaseId != null && phaseId.intValue() > 0) {
				program.withPhase(this.phaseRepository.findOne(phaseId));
			}

			if (sponsorId != null && sponsorId.longValue() > 0) {
				program.withSponsor(this.sponsorRepository.findOne(sponsorId));
			}

			/*
			 * if (collaboratorId != null && collaboratorId.longValue() > 0) {
			 * program.withCollaborator(this.collaboratorRepository.findOne(collaboratorId))
			 * ; }
			 */
			if (programStatusId != null && programStatusId.intValue() > 0) {
				program.withProgramStatus(this.programStatusRepository.findOne(programStatusId));
			}
		}
		return program;
	}	
	
}

