package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.Optional;

import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.model.Question;


public interface QuestionService {
	public List<Question> findByIdIn(List<Long> Ids);

	/**
	 * returns all the Questions in the system
	 * @return
	 */
	public List<Question> findAll();
	
	/**
	 * Finds a Question based on the id
	 * @param id
	 * @return a Question, or null if not found
	 */
	public Question findOne(Long id);
	
	/**
	 * Saves the Question
	 * @param QuestionToBePersisted
	 * @return Question that saved or null if there was an error
	 */
	public Question save(Question questionToBePersisted);
	
	/**
	 * Updates the Question
	 * @param QuestionToBePersisted
	 * @return a Question that was updated
	 */
	public Question update(Question questionToBePersisted);
	
	/**
	 * deletes the Question
	 * @param id
	 */
	public boolean delete(Long id);
	public  List<Question> findByQuestionnaireId(Long questionaireId);
}
