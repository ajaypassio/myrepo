package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.avigosolutions.criteriaservice.model.Question;
import com.avigosolutions.criteriaservice.model.Questionnaire;
import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
import com.avigosolutions.criteriaservice.repository.QuestionRepository;
import com.avigosolutions.criteriaservice.repository.QuestionnaireRepository;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class QuestionServiceImpl implements QuestionService {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	QuestionnaireRepository questionnaireRepository;
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	CriteriaRepository criteriaRepository;
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public List<Question> findAll() {
		// TODO Auto-generated method stub
		return questionRepository.findAll();
	}

	@Override
	public Question findOne(Long id) {
		Question question = questionRepository.findOne(id);
		return question;
	}

	@Override
	public  List<Question> findByQuestionnaireId(Long questionaireId) {
		return questionRepository.findByQuestionnaireId(questionaireId);
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly = false)
	public Question save(Question questionToBePersisted) {
		return persist(questionToBePersisted,false);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly = false)
	public Question update(Question questionToBePersisted) {
		//return criteriaRepository.
		return persist(questionToBePersisted,true);
	}

	@Override
	public boolean delete(Long questionToBeDeleted) {
		try {
			if (questionToBeDeleted != null) {
				questionRepository.delete(questionToBeDeleted);
				return true;
			}
			else {
				logger.info("Delete question called with null Question obj");
				return false;
			}
			
		} catch(Exception e) {
			return false;
		}
		
	}

	
	private Question persist(Question questionToBePersisted, boolean isUpdate)
	{
		//check
		if (questionToBePersisted != null) {
		
			Long questionId = questionToBePersisted.getQuestionId();
			// if update check if it has id or if the Criteria to be updated doesn't exist
			if(isUpdate && (questionId == null || (questionRepository.findOne(questionId) == null)))
			{
				logger.error("Update called with null or invalid Question: " + questionToBePersisted.toString());
				return null;
			}
			
			Questionnaire questionnaire = questionToBePersisted.getQuestionnaire();
			if( questionnaire != null )
			{		
				//check if trial already exists
				Questionnaire existingQuestionnaire =  questionnaireRepository.findOne(questionnaire.getQuestionnaireId());
				if(existingQuestionnaire == null)
				{		
					//if not save trial before criteria
					Questionnaire savedQuestionnaire = questionnaireRepository.save(questionnaire);	
					
					questionToBePersisted.withQuestionnaireId(savedQuestionnaire.getQuestionnaireId());
				}
			}
			
			return questionRepository.save(questionToBePersisted);
		}
		return null;
	}

	@Override
	public List<Question> findByIdIn(List<Long> Ids) {
		// TODO Auto-generated method stub
		return questionRepository.findByIdIn(Ids);
	}

	public void populateQuestionAttributes(Question question) {
		if (question != null) {
			if (question.getCriteriaId() > 0)
				question.withCriteria(criteriaRepository.findOne(question.getCriteriaId()));
		}
	}
}
