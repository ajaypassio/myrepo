package com.avigosolutions.criteriaservice.service;

import java.util.List;
import java.util.Optional;

import com.avigosolutions.criteriaservice.dto.QuestionnaireDto;
import com.avigosolutions.criteriaservice.model.*;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.QuestionnaireFilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface QuestionnaireService {
	/**
	 * returns all the Clinical Trials in the system
	 * @return
	 */
	public List<QuestionnaireDto> findAll();
	
	/**
	 * Finds a Clinical Trial based on the id
	 * @param id
	 * @return a Clinical Trial, or null if not found
	 */
	public Questionnaire findOne(Long id);
	
	/**
	 * Saves the Clinical Trial
	 * @param QuestionnaireToBePersisted
	 * @return Clinical Trial that saved or null if there was an error
	 */
	public Optional<Questionnaire> save(Questionnaire questionnaireToBePersisted);
	
	/**
	 * Updates the Clinical Trial
	 * @param QuestionnaireToBePersisted
	 * @return a Clinical Trial that was updated
	 */
	public Optional<Questionnaire> update(Questionnaire questionnaireToBePersisted);
	
	/**
	 * deletes the Clinical Trial
	 * @param id
	 */
	public void delete(Long id);
	
	public Questionnaire findAllQuestionnaireId(Long questionnaireId);

	public List<Questionnaire> findAllQuestionnaireIds(List<Long> questionnaireIds);
	
	/**
	 * returns all the Clinical Trials in the system
	 * @return
	 */
	public ResponseObjectModel findByFilter(FilterRequestModel filterModel);
	
	/**
	 * Get independent/program related trial questionnaire
	 */
	public ResponseObjectModel retrieveQuestionnaires(QuestionnaireFilterRequestModel filter, String type); 
	public ResponseObjectModel retrieveTrialProgramIdAndName(String surveyId, Long trialId); 
}
