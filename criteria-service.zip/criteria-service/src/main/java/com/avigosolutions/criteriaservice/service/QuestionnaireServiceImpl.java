package com.avigosolutions.criteriaservice.service;

import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.criteriaservice.dto.CRMCategory;
import com.avigosolutions.criteriaservice.dto.QuestionnaireDto;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.Criteria;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.model.ProgramCollaborator;
import com.avigosolutions.criteriaservice.model.Question;
import com.avigosolutions.criteriaservice.model.Questionnaire;
import com.avigosolutions.criteriaservice.model.SurveyAssociations;
import com.avigosolutions.criteriaservice.model.SurveyMaster;
import com.avigosolutions.criteriaservice.model.TrialCollaborator;
import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
import com.avigosolutions.criteriaservice.repository.CollaboratorRepository;
import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
import com.avigosolutions.criteriaservice.repository.ProgramCollaboratorRepository;
import com.avigosolutions.criteriaservice.repository.ProgramRepository;
import com.avigosolutions.criteriaservice.repository.QuestionRepository;
import com.avigosolutions.criteriaservice.repository.QuestionnaireRepository;
import com.avigosolutions.criteriaservice.repository.SponsorRepository;
import com.avigosolutions.criteriaservice.repository.SurveyMasterRepository;
import com.avigosolutions.criteriaservice.repository.TherapeuticAreaRepository;
import com.avigosolutions.criteriaservice.repository.TrialCollaboratorRepository;
import com.avigosolutions.criteriaservice.request.model.FilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.QuestionnaireFilterRequestModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.TrialOrProgramResponse;
import com.avigosolutions.criteriaservice.util.CommonUtil;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class QuestionnaireServiceImpl implements QuestionnaireService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	QuestionnaireRepository questionnaireRepository;

	@Autowired
	ClinicalTrialRepository clinicalTrialRepository;
	
	@Autowired
	TherapeuticAreaRepository therapeuticAreaRepository;

	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	TrialCollaboratorRepository trialCollaboratorRepository;
	
	@Autowired
	ProgramCollaboratorRepository programCollaboratorRepository;

	@Autowired
	ProgramRepository programRepository;

	@Autowired
	private SponsorRepository sponsorRepository;

	@Autowired
	private CollaboratorRepository collaboratorRepository;

	@Autowired
	private CriteriaRepository criteriaRepository;
	
	@Autowired
	SurveyMasterRepository surveyMasterRepository;
	
	@Value("${sprintt.participant.service.substituteurl}")
	String participantServiceSubstituteURL;
	
	@Value("${sprintt.patient.portal.landingpage.url}")
	String patientPortalLandingPageURL;
	

	RestTemplate restTemplate = new RestTemplate();

	@Override
	public List<QuestionnaireDto> findAll() {
		// TODO Auto-generated method stub

		List<Questionnaire> questionnaireList = questionnaireRepository.findAll();
		List<QuestionnaireDto> questionnaireDtoList = new ArrayList<>();
		questionnaireList.forEach(qustr -> {
			questionnaireDtoList.add(toQuestionnaireDto(qustr));
		});

		return questionnaireDtoList;
	}

	private QuestionnaireDto toQuestionnaireDto(Questionnaire questionnaire) {
		ClinicalTrial trial = clinicalTrialRepository.findOne(questionnaire.getTrialId());
		Program program = null;

		if (null != trial && null != trial.getProgramId() && trial.getProgramId() > 0) {
			program = programRepository.findOne(trial.getProgramId());
			trial.withProgram(populateProgramAttributes(program));
		}

		String questionnaireName = (questionnaire.getName() != null) ? questionnaire.getName() : "";
		String questionnaireDescription = (questionnaire.getDescription() != null) ? questionnaire.getDescription()
				: "";
		Long programId = (null != program) ? program.getId() : 0L;
		String programName = (program != null) ? program.getName() : "-";
		String sponsorName = (program != null && program.getSponsor() != null) ? program.getSponsor().getName() : "-";
		List<String> collaboratorName = null;
		if(program != null) {
			collaboratorName = (CollectionUtils.isEmpty(program.getCollaborators())) ? null
					: program.getCollaborators().stream().map(t -> t.getName()).collect(Collectors.toList());
		}else {
		
			Long sponserId =trial.getSponsorId();
			sponsorName = (sponserId != null &&  sponserId != 0) ?this.sponsorRepository.findOne(sponserId).getName():"-";
			collaboratorName = (CollectionUtils.isEmpty(trial.getCollaborators())) ? null
					: trial.getCollaborators().stream().map(t -> t.getName()).collect(Collectors.toList());
		}
		String trialName = (trial != null) ? trial.getTrialName() : "";
		Date createdOn = (trial != null) ? questionnaire.getCreatedOn() : null;
		Date updatedOn = (trial != null) ? questionnaire.getUpdatedOn() : null;
		String trialLandingPage = (trial != null) ? trial.getTrialLandingURL() : "";

		return new QuestionnaireDto(questionnaire.getQuestionnaireId(), questionnaire.getTrialId(), programId,
				questionnaireName, questionnaireDescription, sponsorName, collaboratorName, trialName, programName,
				trialLandingPage, createdOn, updatedOn);
	}

	@Override
	public Questionnaire findOne(Long id) {
		/*Questionnaire questionnaire = questionnaireRepository.findOne(id);
		if (questionnaire != null) {
			populateQuestionnaireAttributes(questionnaire);
			questionnaire.getQuestions().forEach(question -> {
				if (question.getCriteriaId() != null && question.getCriteriaId() > 0) {
					Criteria criteria = criteriaRepository.findOne(question.getCriteriaId());
					if (criteria != null) {
						question.withIsIncludeCriteria(criteria.getIsInclude());
						question.withIsInclude(criteria.getIsInclude());
					}
				} else {

				}
			});
			
			if(null != questionnaire && null != questionnaire.getQuestions()) {
				questionnaire.getQuestions().sort(Comparator.comparing(Question::getQuestionId,Comparator.naturalOrder()));
			}
			
		}*/
		Questionnaire questionnaire = new Questionnaire();
		SurveyMaster surveyMaster = this.surveyMasterRepository.findBySprinttSurveyId(id);
		if(surveyMaster != null){
			List<SurveyAssociations> surveyAssociationsList =  surveyMaster.getSurveyAssociations();
			questionnaire = new Questionnaire().withQuestionnaireId(surveyMaster.getSprinttSurveyId())
					.withName(surveyMaster.getSurveyTitle())
					.withDescription(surveyMaster.getSurveyDescription())
					.withTrialId(surveyAssociationsList.get(0).getTrialId())
					.withStatus(true)
					.withProgramId(surveyAssociationsList.get(0).getProgramId());
		}
		return questionnaire;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Optional<Questionnaire> save(Questionnaire questionnaireToBePersisted) {
		/*
		 * This condition was added because if the input param is null
		 * then we return an empty optional for test cases to pass.
		 * Edit by: Sai Kiran (sdasika@avigosolutions.com)
		 */
		if (questionnaireToBePersisted == null) {
			return Optional.empty();
		}
		
		List<Questionnaire> existingQuestionnaireList = questionnaireRepository.findByName(questionnaireToBePersisted.getName());
		if(null==existingQuestionnaireList || existingQuestionnaireList.size()<=0 ) {
			Optional<Questionnaire> opQte = Optional.ofNullable(questionnaireToBePersisted).map(qtr1 -> {
				ClinicalTrial trial = clinicalTrialRepository.findOne(qtr1.getTrialId());
				Questionnaire savedQuestionnaire = questionnaireRepository.save(qtr1.withProgramId(trial.getProgramId()));
				logger.info(String.valueOf(savedQuestionnaire.getQuestionnaireId()));
				sendCRMSubstitutionToParticipantService(patientPortalLandingPageURL.replace(":QUESTIONNAIRE_ID", savedQuestionnaire.getQuestionnaireId()+""), savedQuestionnaire.getName());
				Optional.ofNullable(savedQuestionnaire.getQuestions()).ifPresent(qq -> qq.forEach(q -> {
					q.withQuestionnaireId(savedQuestionnaire.getQuestionnaireId());
					questionRepository.save(q);
				}));
				return savedQuestionnaire;
			});
			return opQte;
		}else {
			return null;
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Optional<Questionnaire> update(Questionnaire questionnaireToBePersisted) {

		// Re-factored above implementation with less complexity using Optional
		// effectively
		// 1. The first map() below finds a trial by ID - we can only update a Trial
		// which exists in the DB, its NOT a create
		// 2. If such a trial exists in the DB, then the second map() is called
		// otherwise we print an error
		// 3. The second map calls save and returns the ClinicalTrial that's returned by
		// save.
		
		/*
		 * This condition was added because if the input param is null
		 * then we return an empty optional for test cases to pass.
		 * Edit by: Sai Kiran (sdasika@avigosolutions.com)
		 */
		if (questionnaireToBePersisted == null) {
			return Optional.empty();
		}
		List<Questionnaire> existingQuestionnaireList = questionnaireRepository.findByNameAndIdNot(questionnaireToBePersisted.getName(), questionnaireToBePersisted.getQuestionnaireId());
		if(null==existingQuestionnaireList || existingQuestionnaireList.size()<=0 ) {
		Optional<Questionnaire> ctRet = Optional.ofNullable(questionnaireToBePersisted).map(ct1 -> { // NOTE: This
																										// function can
																										// be reduced to
																										// a ONE liner
																										// but we want
																										// to print the
																										// error hence 4
																										// lines
			Questionnaire cQuestionnaire = questionnaireRepository.findOne(ct1.getQuestionnaireId());
			
			if (cQuestionnaire == null)
				logger.error(
						"Update called on an nonextistent clinical trial: " + questionnaireToBePersisted.toString());
			return cQuestionnaire;
		}).map(ct2 -> {
			ClinicalTrial trial = clinicalTrialRepository.findOne(questionnaireToBePersisted.getTrialId());
			Questionnaire ct = questionnaireRepository
					.save(questionnaireToBePersisted.withProgramId(trial.getProgramId()));
			if(ct != null) {
				sendCRMSubstitutionToParticipantService(patientPortalLandingPageURL.replace(":QUESTIONNAIRE_ID", ct.getQuestionnaireId()+""),  ct.getName());
			}
			return ct;
		});
		return ctRet;
		}else {
			return null;
		}
		
	}

	@Override
	public void delete(Long id) {
		questionnaireRepository.delete(id);
		
		sendCRMSubstitutionToParticipantService(patientPortalLandingPageURL.replace(":QUESTIONNAIRE_ID", id+""),  "");
	}

	private void populateQuestionnaireAttributes(Questionnaire questionnaire) {
		if (questionnaire != null) {
			if (questionnaire.getTrialId() > 0)
				questionnaire.withClinicalTrial(clinicalTrialRepository.findOne(questionnaire.getTrialId()));
		        questionnaire.setTrialName(questionnaire.getClinicalTrial().getTrialName());
		        if(null!=questionnaire.getClinicalTrial().getTherapeuticArea())
		        questionnaire.setTherapeuticArea(questionnaire.getClinicalTrial().getTherapeuticArea());
		        if(null!=questionnaire.getClinicalTrial().getTherapeuticAreaId())
			    questionnaire.setTherapeuticAreaId(questionnaire.getClinicalTrial().getTherapeuticAreaId());
		        
		        if(null!=questionnaire.getTherapeuticAreaId())
		        questionnaire.setTherapeuticArea(therapeuticAreaRepository.findOne(questionnaire.getTherapeuticAreaId()));
				logger.info("trial name is " + questionnaire.getTrialName());
		}
	}

	@Override
	public Questionnaire findAllQuestionnaireId(Long questionnaireId) {
		Questionnaire questionnaire = questionnaireRepository.findById(questionnaireId);
		questionnaire.getQuestions().forEach(question -> {
			question.withIsIncludeCriteria(criteriaRepository.findOne(question.getCriteriaId()).getIsInclude());
		});
		if(null != questionnaire && null != questionnaire.getQuestions()) {
			questionnaire.getQuestions().sort(Comparator.comparing(Question::getQuestionId,Comparator.naturalOrder()));
		}
		return questionnaire;
	}

	@Override
	public List<Questionnaire> findAllQuestionnaireIds(List<Long> questionnaireIds) {
		List<Questionnaire> questionnaireList = questionnaireRepository.findByIdIn(questionnaireIds);
		questionnaireList.forEach(questionnaire -> {
			questionnaire.getQuestions().forEach(question -> {
				Criteria criteria = criteriaRepository.findOne(question.getCriteriaId());
				if (criteria != null) {
					question.withIsIncludeCriteria(criteria.getIsInclude());					
				}
			});
			//To sort the questions by updated date
			if(null != questionnaire.getQuestions()) {
				questionnaire.getQuestions().sort(Comparator.comparing(Question::getQuestionId,Comparator.naturalOrder()));
			}
		});
				
		return questionnaireList;
	}

	@Override
	public ResponseObjectModel findByFilter(FilterRequestModel filterModel) {
		ResponseObjectModel response = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getPage(), filterModel.getPageSize());
		Page<Questionnaire> page = questionnaireRepository.findAll(pageRequest);
		response.setData(page.getContent());
		response.setTotal(page.getTotalElements());
		return response;
	} 
	
	@Override
	public ResponseObjectModel retrieveQuestionnaires(QuestionnaireFilterRequestModel filter, String type) {
		ResponseObjectModel response = new ResponseObjectModel(); 

		String columnToSort = filter.getSortBy();
		String sortType = filter.getSortDirection();
		Pageable pageRequest = CommonUtil.getPageRequest(filter.getPage(), filter.getPageSize());
		Page<Questionnaire> questionnairePage = null;
		
		//Get results based on the questionnaire type asked for
		if(type.equalsIgnoreCase("independent")) {
			
			List<Long> trialList = this.trialCollaboratorRepository.findByCollaboratorIdIn(filter.getCollaboratorList()).stream().map(tco->tco.getProgramId()).distinct().collect(Collectors.toList());;
			if( null == filter.getTrialList() || filter.getTrialList().isEmpty()) {				
				if((null == trialList || trialList.isEmpty()) && !CommonUtil.IsNullOrEmpty(filter.getCollaboratorList()) ) {
					trialList = new ArrayList<Long>();trialList.add(0L);
				}
				filter.withTrialList(trialList);
			}else {
				if(filter.getTrialList().addAll(trialList)) {
					filter.withTrialList(filter.getTrialList().stream().distinct().collect(Collectors.toList()));
				}
				
			}
			questionnairePage = questionnaireRepository
					.findAll((getIndependentTrialQuestionnaire(filter, columnToSort, sortType)), pageRequest); 
			

		} else if(type.equalsIgnoreCase("program"))  {
			List<Long> programList = this.programCollaboratorRepository.findByCollaboratorIdIn(filter.getCollaboratorList()).stream().map(tco->tco.getProgramId()).distinct().collect(Collectors.toList());;
			if( null == filter.getProgramList() || filter.getProgramList().isEmpty()) {
				if((null == programList || programList.isEmpty()) && !CommonUtil.IsNullOrEmpty(filter.getCollaboratorList()) ) {
					programList = new ArrayList<Long>();programList.add(0L);
				}
				filter.withProgramNameList(programList);
			}else {
				if(filter.getProgramList().addAll(programList)) {
					filter.withProgramNameList(filter.getProgramList().stream().distinct().collect(Collectors.toList()));
				}
				
			}
			 questionnairePage = questionnaireRepository
					.findAll((getQuestionnaireSpecification(filter, columnToSort, sortType)), pageRequest); 
		}
		
		List<QuestionnaireDto> questionnaireDtoList = questionnairePage.getContent().stream()
				.map(questr -> toQuestionnaireDto(questr)).collect(Collectors.toList()); 
		 
		response.setData(questionnaireDtoList);
		response.setTotal(questionnairePage.getTotalElements());
		return response;
	}

	private Specification<Questionnaire> getQuestionnaireSpecification(QuestionnaireFilterRequestModel filter,
			String columnToSort, String sortType) {
		return new Specification<Questionnaire>() {

			@Override
			public Predicate toPredicate(Root<Questionnaire> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				Root<Program> rootP = query.from(Program.class);
				

				List<Predicate> predicates = new ArrayList<>();
				if (filter.getTrialId() != null && filter.getTrialId().floatValue() > 0L) {
					predicates.add(cb.equal(cb.lower(root.get("trialId")), filter.getTrialId()));
				}

				predicates.add(cb.equal(root.get("programId"), rootP.get("programId"))); // to add to the where clause

				if (!CommonUtil.isNullOrBlank(filter.getName())) {
					predicates.add(cb.like(cb.lower(root.get("name")), "%" + filter.getName().toLowerCase() + "%"));
				}

				if (!CommonUtil.IsNullOrEmpty(filter.getSponsorList())) {
					predicates.add(
							cb.isTrue(rootP.get("sponsor").get("id").in((Object[]) filter.getSponsorList().toArray())));
				}
				if (!CommonUtil.IsNullOrEmpty(filter.getProgramList()) || !CommonUtil.IsNullOrEmpty(filter.getCollaboratorList())) {
					predicates.add(cb.isTrue(root.get("programId").in((Object[]) filter.getProgramList().toArray())));
				}
				if (!CommonUtil.IsNullOrEmpty(filter.getTrialList())) {
					predicates.add(cb.isTrue(root.get("trialId").in((Object[]) filter.getTrialList().toArray())));
				}
				
				//Date Filter
				if (!CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& !CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.between(root.get("updatedOn"), filter.getFilterStartDate(), filter.getFilterEndDate()));
				}
				
				if (!CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.lessThanOrEqualTo(root.get("updatedOn"), filter.getFilterEndDate()));
				}
				if (CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& !CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.greaterThanOrEqualTo(root.get("updatedOn"), filter.getFilterStartDate()));
				}			

				if (sortType != null && !sortType.trim().isEmpty()) {
					query.orderBy(getOrder(columnToSort, sortType, cb, root, rootP));
				} else {
					//default sorting
					query.orderBy(getOrder("updatedOn", "desc", cb, root, null));
				}
				
//				query.distinct(true);
				
				return cb.and(predicates.toArray(new Predicate[predicates.size()]));
			}
		};
	}

	private Specification<Questionnaire> getIndependentTrialQuestionnaire(QuestionnaireFilterRequestModel filter,
			String columnToSort, String sortType) {
		return new Specification<Questionnaire>() {

			@Override
			public Predicate toPredicate(Root<Questionnaire> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				List<Predicate> predicates = new ArrayList<>();
				if (filter.getTrialId() != null && filter.getTrialId().floatValue() > 0L) {
					predicates.add(cb.equal(cb.lower(root.get("trialId")), filter.getTrialId()));
				}

				predicates.add(cb.isNull(root.get("programId"))); // to add to the where clause

				if (!CommonUtil.isNullOrBlank(filter.getName())) {
					predicates.add(cb.like(cb.lower(root.get("name")), "%" + filter.getName().toLowerCase() + "%"));
				}
				
				if (!CommonUtil.IsNullOrEmpty(filter.getSponsorList())) {
					Root<ClinicalTrial> rootTrial = query.from(ClinicalTrial.class);
					predicates.add(cb.isTrue(rootTrial.get("sponsorId").in(filter.getSponsorList())));
					predicates.add(cb.equal(rootTrial.get("id"), root.get("trialId")));
				}
				
				if (!CommonUtil.IsNullOrEmpty(filter.getProgramList())) {
					predicates.add(cb.isTrue(root.get("programId").in((Object[]) filter.getProgramList().toArray())));
				}

				if (!CommonUtil.IsNullOrEmpty(filter.getTrialList()) || !CommonUtil.IsNullOrEmpty(filter.getCollaboratorList())) {
					predicates.add(cb.isTrue(root.get("trialId").in((Object[]) filter.getTrialList().toArray())));
				}
				
				
				if (!CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& !CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.between(root.get("createdOn"), filter.getFilterStartDate(), filter.getFilterEndDate()));
				}
				
				//Date Filter
				if (!CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& !CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.between(root.get("updatedOn"), filter.getFilterStartDate(), filter.getFilterEndDate()));
				}
				
				if (!CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.lessThanOrEqualTo(root.get("updatedOn"), filter.getFilterEndDate()));
				}
				if (CommonUtil.isNullOrEmpty(filter.getFilterEndDate())
						&& !CommonUtil.isNullOrEmpty(filter.getFilterStartDate())) {
					predicates.add(
							cb.greaterThanOrEqualTo(root.get("updatedOn"), filter.getFilterStartDate()));
				}
				
//				query.distinct(true);

				if (sortType != null && !sortType.trim().isEmpty()) {
					query.orderBy(getOrder(columnToSort, sortType, cb, root, null));
				} else {
					//default sorting
					query.orderBy(getOrder("updatedOn", "desc", cb, root, null));
				}
				return cb.and(predicates.toArray(new Predicate[predicates.size()]));
			}
		};
	}

	private Order getOrder(String column, String sortType, CriteriaBuilder cb, Root<Questionnaire> rootQ,
			Root<Program> rootP) {
		if (null != rootP && "sponsorName".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(rootP.get("sponsor").get("name"));
			} else {
				return (cb.desc(rootP.get("sponsor").get("name")));

			}
		} else if (null != rootP && "collaboratorName".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(rootP.get("collaborator").get("name"));
			} else {
				return cb.desc(rootP.get("collaborator").get("name"));
			}

		} else if (null != rootP && "programName".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(rootP.get("name"));
			} else {
				return (cb.desc(rootP.get("name")));
			}

		} else if ("trialName".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(rootQ.get("clinicalTrial").get("trialName"));
			} else {
				return cb.desc(rootQ.get("clinicalTrial").get("trialName"));
			}

		} else if ("name".equals(column)) {
			if (sortType.equals("asc")) {
				return (cb.asc(rootQ.get("name")));
			} else {
				return (cb.desc(rootQ.get("name")));
			}

		} else if ("createdOn".equals(column)) {
			if (sortType.equals("asc")) {
				return (cb.asc(rootQ.get("createdOn")));
			} else {
				return (cb.desc(rootQ.get("createdOn")));
			}

		}  else if ("updatedOn".equals(column)) {
			if (sortType.equals("asc")) {
				return (cb.asc(rootQ.get("updatedOn")));
			} else {
				return (cb.desc(rootQ.get("updatedOn")));
			}

		} else {
			return (cb.desc(rootQ.get("updatedOn")));
		}
	}

	private Comparator<QuestionnaireDto> getSortComparator(Comparator<String> sortOrder, String columnName,
			String sortType) {
		if ("sponsorName".equals(columnName)) {
			return Comparator.comparing(QuestionnaireDto::getSponsorName, sortOrder);
		}  else if ("trialName".equals(columnName)) { 
			return Comparator.comparing(QuestionnaireDto::getTrialName, sortOrder); 
		}else if ("programName".equals(columnName)) {
			return Comparator.comparing(QuestionnaireDto::getProgramName, sortOrder);
		} else if ("name".equals(columnName)) {
			return Comparator.comparing(QuestionnaireDto::getQuestionnaireName, sortOrder);
		} else if ("createdOn".equals(columnName)) {
			Comparator<Date> dateComparator = sortType.equals("asc") ? Comparator.naturalOrder()
					: Comparator.reverseOrder();
			return Comparator.comparing(QuestionnaireDto::getcreatedOn, dateComparator);
		} else if ("updatedOn".equals(columnName)) {
			Comparator<Date> dateComparator = sortType.equals("asc") ? Comparator.naturalOrder()
					: Comparator.reverseOrder();
			return Comparator.comparing(QuestionnaireDto::getUpdatedOn, dateComparator);
		} else {
			return Comparator.comparing(QuestionnaireDto::getUpdatedOn, Comparator.reverseOrder());
		}
	}

	private Program populateProgramAttributes(Program program) {
		if (program != null) {

			Long sponsorId = program.getSponsorId();
			// Long collaboratorId = program.getCollaboratorId();

			if (sponsorId != null && sponsorId.longValue() > 0) {
				program.withSponsor(this.sponsorRepository.findOne(sponsorId));
			}

			/*
			 * if (collaboratorId != null && collaboratorId.longValue() > 0) {
			 * program.withCollaborator(this.collaboratorRepository.findOne(collaboratorId))
			 * ; }
			 */

		}
		return program;
	}
	
	private boolean sendCRMSubstitutionToParticipantService(String key, String value) {
		if(key == null) {
			return false;
		}
		
		HttpHeaders headers = CommonUtil.getHttpHeaders();
		try {
			HttpEntity<CRMCategory> httpEntity = new HttpEntity<>(headers);
			String url = participantServiceSubstituteURL.replace(":SUB_KEY", URLEncoder.encode(key, "UTF-8")+"")
								.replace(":SUB_VALUE", URLEncoder.encode(value, "UTF-8"));
			
			restTemplate.postForObject(url, httpEntity, CRMCategory.class);
		} catch (Exception e) {
			logger.error("Error accessing/sending CRM Substitution to participantService", e);
		}
		return true;
	}

	@Override
	public ResponseObjectModel retrieveTrialProgramIdAndName(String surveyId, Long trialId) {
		ResponseObjectModel responseObjectModel = new ResponseObjectModel();
		TrialOrProgramResponse trialOrProgramResponse = null;
		
		if(trialId != null && trialId !=0 ){
			ClinicalTrial clinicaltrial = this.clinicalTrialRepository.findOne(trialId);
			if(clinicaltrial != null){
				Date clinicalTrialEndDate = clinicaltrial.getTrialEndDate();
				if(null != clinicalTrialEndDate){
					LocalDateTime trialEndDate = clinicalTrialEndDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
					LocalDateTime currentDateTime = LocalDateTime.now();
					
					boolean isAfter = currentDateTime.isAfter(trialEndDate);
					if(isAfter || !clinicaltrial.getTrialStatusId().equals(1)){
						responseObjectModel.setData(null);
						responseObjectModel.setMessage("Trial is not active");
						responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
						return responseObjectModel;
					}
				}
			}
		}

		SurveyMaster surveyMaster = this.surveyMasterRepository.findBySurveyId(surveyId);
		if(surveyMaster != null){
			List<SurveyAssociations> surveyAssociationsList = surveyMaster.getSurveyAssociations();
			for(SurveyAssociations surveyAssociations : surveyAssociationsList){
				
				if(surveyAssociations.getTrialId().equals(trialId)){
					trialOrProgramResponse = new TrialOrProgramResponse();
					trialOrProgramResponse.setTrialId(trialId);
					
					if(trialId != null && trialId !=0 ){
						ClinicalTrial clinicalTrial = this.clinicalTrialRepository.findOne(trialId);
						if(clinicalTrial != null){
							trialOrProgramResponse.setTrialName(clinicalTrial.getTrialName());
						}
					}
					trialOrProgramResponse.setProgramId(surveyAssociations.getProgramId());
					if(surveyAssociations.getProgramId() != 0){
						Optional<Program> program= this.programRepository.findByProgramId(surveyAssociations.getProgramId());
						if(program.isPresent()){
							trialOrProgramResponse.setProgramName(program.get().getName());
						}
					}
				}
			}
			
			if(trialOrProgramResponse == null){
				responseObjectModel.setData(null);
				responseObjectModel.setMessage("Trial id not associated with survey Id");
				responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
			} else {
				responseObjectModel.setData(trialOrProgramResponse);
				responseObjectModel.setMessage("SUCCESS");
				responseObjectModel.setHttpStatus(HttpStatus.OK);
			}
		}
		else {
			responseObjectModel.setData(null);
			responseObjectModel.setMessage("No survey exist for the surveyId :" + surveyId);
			responseObjectModel.setHttpStatus(HttpStatus.NOT_FOUND);
		}
		return responseObjectModel;
	}
}
