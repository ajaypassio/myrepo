package com.avigosolutions.criteriaservice.service;

import com.avigosolutions.criteriaservice.response.model.ReportResponse;

public interface ReportService {
	
	public ReportResponse getReport();

}
