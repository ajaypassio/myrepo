package com.avigosolutions.criteriaservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.avigosolutions.criteriaservice.repository.ClinicalStudySiteRepository;
import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
import com.avigosolutions.criteriaservice.repository.CollaboratorRepository;
import com.avigosolutions.criteriaservice.repository.ProgramRepository;
import com.avigosolutions.criteriaservice.repository.SponsorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteRepository;
import com.avigosolutions.criteriaservice.response.model.ReportResponse;


@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ReportServiceImpl implements ReportService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	CollaboratorRepository collaboratorRepository;

	@Autowired
	ProgramRepository programRepository;
	
	@Autowired
	ClinicalTrialRepository clinicalTrialRepository;
	
	@Autowired
	SponsorRepository sponsorRepository;
	
	@Autowired
	ClinicalTrialService clinicalTrialService;
	
	@Autowired
	StudySiteRepository studySiteRepository;
	
	@Autowired
	ClinicalStudySiteRepository clinicalStudySiteRepository;
	
	@Autowired
	ProgramService programService;
	
	@Autowired
	StudySiteService studySiteService;

	
	@Override
	public ReportResponse getReport() {

		ReportResponse reportRes = new ReportResponse();
		reportRes.withCountCollaborators(collaboratorRepository.count())
				 .withCountSponsors(sponsorRepository.count())
				 .withCountPrograms(programRepository.count())
				 .withCountTrials(clinicalTrialRepository.count())
				 .withCountSites(studySiteRepository.count())
				 .withCountSitesWithTrials(clinicalStudySiteRepository.count())
				 .withCountActiveSites(studySiteService.getCount(true));
		
		return reportRes;
		
	}
}
