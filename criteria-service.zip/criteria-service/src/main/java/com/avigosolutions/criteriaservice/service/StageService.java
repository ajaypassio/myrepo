package com.avigosolutions.criteriaservice.service;

import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface StageService {
	ResponseObjectModel getAll(int page,int pageSize);
}
