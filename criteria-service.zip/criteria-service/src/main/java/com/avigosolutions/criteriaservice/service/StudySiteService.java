package com.avigosolutions.criteriaservice.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.avigosolutions.criteriaservice.dto.ClinicalStudySiteSiteStatistics;
import com.avigosolutions.criteriaservice.dto.CoordinatorDto;
import com.avigosolutions.criteriaservice.dto.PrincipalInvestigatorDto;
import com.avigosolutions.criteriaservice.dto.Properties;
import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.dto.StudySiteMapBean;
import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.State;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.request.model.LocationSearch;
import com.avigosolutions.criteriaservice.request.model.StudySiteFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteRadiusRequestModel;
import com.avigosolutions.criteriaservice.response.model.FileResponseModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.StudySiteAuditResponse;
import com.avigosolutions.criteriaservice.response.model.StudySiteReportResponse;
import com.avigosolutions.criteriaservice.response.model.StudySiteResponse;

public interface StudySiteService {

	public List<StudySiteDto> getStudySitesByIds(List<Long> ids);

	public List<StudySiteDto> getStudySitesByIds(List<Long> ids, int start, int pageSize);

	public StudySiteResponse getStudySitesByTrialZipMiles(Long trialId, Long zip, Float miles);

	List<StudySite> findByLatLngByMiles(List<Float> latList, List<Float> LngList);

	List<StudySiteDto> findByMiles(Float latitude, Float Longitude, Float miles, Long trialId);

	public ResponseObjectModel getAllStudySitesByTrailId(Long trialId,
			StudySiteFilterRequestModel studySiteFilterRequest);

	public ResponseObjectModel getAllStudySitesByTrailId(List<Long> trialId,
			StudySiteFilterRequestModel studySiteFilterRequest, int start, int pageSize);

	public StudySiteDto getStudySitesByStudySiteId(Long studySiteId);

	public StudySiteDto getStudySitesByStudySiteIdAndTrialId(Long studySiteId, Long trialId);

	public List<StudySite> findByNotTrailIdIn(Long trialId);

	public Optional<List<ClinicalTrialStudySite>> saveClinicalTrialStudySiteByTrailIdStudySiteIds(Long trialId,
			List<Long> studySiteIds);

	public ResponseObjectModel save(StudySite studySite);

	/**
	 * deletes the Study Site
	 * 
	 * @param id
	 */
	public void delete(Long id);

	public Optional<StudySite> update(StudySite studySiteToBeUpdated);

	public List<StudySite> importFromCSV();

	void createFolderIfNotExists(String dirName) throws SecurityException;

	void saveToFile(MultipartFile inStream, String target) throws IOException;

	public FileResponseModel importStudySiteFromCSV(MultipartFile csvFile, Long trialId);
	
	public FileResponseModel uploadStudySitesWithoutTrialId(MultipartFile csvFile);

	public List<StudySiteDto> findAll();

	public List<ClinicalTrial> getTrialsByStudySiteId(Long studySiteId);

	public ResponseObjectModel getAll(StudySiteFilterRequestModel studySiteRequestModel);

	public ResponseObjectModel updateStudySite(Properties property, Long trialId);

	public List<PrincipalInvestigatorDto> getPrincipalInvestigatorsList(String principalInvestigatorName, int start,
			int page);

	public List<CoordinatorDto> getCoordinatorsList(String coordinatorrName, Long studySiteId, int start, int page);

	// Change Site search by name and trialId
	ResponseObjectModel getStudySitesByTrialIdAndNameContaining(int start, int pageSize, Long trialId, String name);

	// Change Site search by name and trialId
	ResponseObjectModel getStudySitesByTrialIdAndNameContainingNotInCurrentSiteId(int start, int pageSize, Long trialId, String name,Long studySiteId);

	public Long getCount(boolean siteStatus);

	ResponseObjectModel getAll(int page, int pageSize);

	List<StudySiteMapBean> getAll();

	public List<StudySiteReportResponse> getStudySiteReportByTrialId(Long trialId,
			StudySiteFilterRequestModel filterModel);

	public List<StudySiteReportResponse> getStudySiteReport(StudySiteFilterRequestModel filterModel);

	public List<ClinicalStudySiteSiteStatistics> countByClinicalStudySiteIdIdIn(List<Long> trialIds);

	public List<StudySiteMapBean> getAllActiveSitesById(Long trialId);

	public List<StudySiteAuditResponse> getStudySiteAuditReport(Long studySiteId);

	public List<State> getStudySiteStatesByTrialId(Long trialId);

	public List<State> getStudySiteStates();

	public List<City> getStudySiteCities();

	public List<City> getCitiesListForStates(List<Long> statesList, String cityName, Long trialId, int start,
			int pageSize);

	public List<CoordinatorDto> getMappedCoordinators();

	List<StudySiteDto> buildStudySiteDtoList(List<StudySite> studySites, Long trialId);

	public List<City> getStudySiteCitiesByTrialId(Long trialId, LocationSearch locationSearch);

	public ResponseObjectModel getClinicalTrialStudySitesRadius(StudySiteRadiusRequestModel studySiteFilterRequest);
	
	public ResponseObjectModel updateStudySiteFromTrialPage(Long studySiteId, Long trialId, Integer radiusValue, boolean radiusExempt);
	
}
