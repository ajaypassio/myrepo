package com.avigosolutions.criteriaservice.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.quickgeo.Place;
import org.quickgeo.PostalDb.GeoRect;
import org.quickgeo.PostalDbFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.avigosolutions.criteriaservice.constant.CSVConstant;
import com.avigosolutions.criteriaservice.constant.Constants;
import com.avigosolutions.criteriaservice.dto.ClinicalStudySiteSiteStatistics;
import com.avigosolutions.criteriaservice.dto.CoordinatorDto;
import com.avigosolutions.criteriaservice.dto.CountModel;
import com.avigosolutions.criteriaservice.dto.Features;
import com.avigosolutions.criteriaservice.dto.Geometry;
import com.avigosolutions.criteriaservice.dto.PrincipalInvestigatorDto;
import com.avigosolutions.criteriaservice.dto.Properties;
import com.avigosolutions.criteriaservice.dto.StudySiteCSVBean;
import com.avigosolutions.criteriaservice.dto.StudySiteDto;
import com.avigosolutions.criteriaservice.dto.StudySiteLightWeightDTO;
import com.avigosolutions.criteriaservice.dto.StudySiteMapBean;
import com.avigosolutions.criteriaservice.dto.UserDetails;
import com.avigosolutions.criteriaservice.model.City;
import com.avigosolutions.criteriaservice.model.ClinicalStudySiteId;
import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.Coordinator;
import com.avigosolutions.criteriaservice.model.PrincipalInvestigator;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.model.ProgramCollaborator;
import com.avigosolutions.criteriaservice.model.Sponsor;
import com.avigosolutions.criteriaservice.model.State;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.model.StudySiteAudit;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;
import com.avigosolutions.criteriaservice.model.StudySiteImportStatus;
import com.avigosolutions.criteriaservice.model.StudySitePrincipalInvestigator;
import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.repository.CityRepository;
import com.avigosolutions.criteriaservice.repository.ClinicalStudySiteRepository;
import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
import com.avigosolutions.criteriaservice.repository.CoordinatorRepository;
import com.avigosolutions.criteriaservice.repository.PrincipalInvestigatorRepository;
import com.avigosolutions.criteriaservice.repository.ProgramCollaboratorRepository;
import com.avigosolutions.criteriaservice.repository.ProgramRepository;
import com.avigosolutions.criteriaservice.repository.SponsorRepository;
import com.avigosolutions.criteriaservice.repository.StateRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteAuditRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteCoordinatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySitePrincipalInvestigatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteRepository;
import com.avigosolutions.criteriaservice.repository.TherapeuticAreaRepository;
import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.LocationSearch;
import com.avigosolutions.criteriaservice.request.model.StudySiteFilterRequestModel;
import com.avigosolutions.criteriaservice.request.model.StudySiteRadiusRequestModel;
import com.avigosolutions.criteriaservice.response.model.FileResponseModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.RowDetail;
import com.avigosolutions.criteriaservice.response.model.StudySiteAuditResponse;
import com.avigosolutions.criteriaservice.response.model.StudySiteReportResponse;
import com.avigosolutions.criteriaservice.response.model.StudySiteResponse;
import com.avigosolutions.criteriaservice.service.async.StudySiteAsyncService;
import com.avigosolutions.criteriaservice.util.CommonUtil;
import com.avigosolutions.criteriaservice.util.SpringSpecifications;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.univocity.parsers.common.processor.BeanListProcessor;
import com.univocity.parsers.common.processor.OutputValueSwitch;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

@Service
@Transactional(propagation = Propagation.REQUIRED, readOnly = false, noRollbackFor = Exception.class)
public class StudySiteServiceImpl implements StudySiteService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private StudySiteRepository studySiteRepository;

	@Autowired
	private ClinicalStudySiteRepository clinicalStudySiteRepository;

	@Autowired
	private StudySitePrincipalInvestigatorRepository studySitePrincipalInvestigatorRepository;

	@Autowired
	private PrincipalInvestigatorRepository principalInvestigatorRepository;

	@Autowired
	private StudySiteCoordinatorRepository studySiteCoordinatorRepository;

	@Autowired
	private ClinicalTrialRepository clinicalTrialRepository;

	@Autowired
	private ProgramRepository programRepository;

	@Autowired
	private CoordinatorRepository coordinatorRepository;

	@Autowired
	private TherapeuticAreaRepository therapeuticAreaRepository;

	@Autowired
	private ProgramCollaboratorRepository programCollaboratorRepository;

	@Autowired
	private SponsorRepository sponsorRepository;

	@Autowired
	private StudySiteAuditRepository studySiteAuditRepository;

	@Autowired
	private StateRepository stateRepository;

	@Autowired
	private CityRepository cityRepository;

	@Autowired
	private UserDetailService userDetailService;

	@Autowired
	private StudySiteAsyncService studySiteAsyncService;

	@Value("${sprintt.participant.service.studysite.count.url}")
	private String participantServiceStudySiteCountURL;

	@Override
	public List<StudySiteDto> getStudySitesByIds(List<Long> ids, int start, int pageSize) {
		List<StudySite> lstStudySite = studySiteRepository.findByIdIn(ids, new PageRequest(start, pageSize))
				.getContent();
		// No Transient
		/*
		 * List<StudySitePrincipalInvestigator> lstStudySitePrincipalInvestigators =
		 * studySitePrincipalInvestigatorRepository .findByStudySiteIdIn(ids); for
		 * (StudySitePrincipalInvestigator pi : lstStudySitePrincipalInvestigators) {
		 * Set<StudySitePrincipalInvestigator> setPIs = new
		 * HashSet<StudySitePrincipalInvestigator>(); setPIs.add(pi); for (int i = 0; i
		 * < lstStudySite.size(); i++) { if
		 * (lstStudySite.get(i).getId().equals(pi.getStudySiteId())) {
		 * logger.info(lstStudySite.get(i).getStudySiteName());
		 * logger.info(pi.getPrincipalInvestigator().getName());
		 * lstStudySite.get(i).withStudySitePrincipalInvestigators(setPIs); break; } } }
		 * List<StudySiteCoordinator> lstStudySiteCoordinators =
		 * studySiteCoordinatorRepository.findByStudySiteIdIn(ids); for
		 * (StudySiteCoordinator pi : lstStudySiteCoordinators) {
		 * Set<StudySiteCoordinator> setCoordinators = new
		 * HashSet<StudySiteCoordinator>(); setCoordinators.add(pi); for (int i = 0; i <
		 * lstStudySite.size(); i++) { if
		 * (lstStudySite.get(i).getId().equals(pi.getStudySiteId())) {
		 * logger.info(lstStudySite.get(i).getStudySiteName());
		 * logger.info(pi.getCoordinator().getName());
		 * lstStudySite.get(i).withStudySiteCoordinators(setCoordinators); break; } } }
		 */
		return buildStudySiteDtoList(lstStudySite, 0L);
	}

	@Override
	public List<StudySiteDto> getStudySitesByIds(List<Long> ids) {
		List<StudySite> lstStudySite = studySiteRepository.findByIdIn(ids);
		List<StudySitePrincipalInvestigator> lstStudySitePrincipalInvestigators = studySitePrincipalInvestigatorRepository
				.findByStudySiteIdIn(ids);
		for (StudySitePrincipalInvestigator pi : lstStudySitePrincipalInvestigators) {
			Set<StudySitePrincipalInvestigator> setPIs = new HashSet<StudySitePrincipalInvestigator>();
			setPIs.add(pi);
			for (int i = 0; i < lstStudySite.size(); i++) {
				if (lstStudySite.get(i).getId().equals(pi.getStudySiteId())) {
					logger.info(lstStudySite.get(i).getStudySiteName());
					logger.info(pi.getPrincipalInvestigator().getName());
					lstStudySite.get(i).withStudySitePrincipalInvestigators(setPIs);
					break;
				}
			}
		}
		return buildStudySiteDtoList(lstStudySite, 0L);

	}

	@Override
	public List<StudySiteDto> findAll() {
		return buildStudySiteDtoList(studySiteRepository.findAll(), 0L);
	}

	@Override
	public List<ClinicalTrial> getTrialsByStudySiteId(Long studySiteId) {
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdStudySiteId(studySiteId);
		logger.info("**********" + listClinicalTrialStudySite.size());

		// List<Long> ids = new ArrayList<Long>();
		List<ClinicalTrial> trial = new ArrayList<>();
		for (ClinicalTrialStudySite clinicalTrialStudySite : listClinicalTrialStudySite) {
			Long trialID = clinicalTrialStudySite.getId().getId();
			logger.info("*********" + trialID);

			trial.add(clinicalTrialRepository.findOne(trialID));

			logger.info("*****" + trial.size());
		}
		return trial;
	}

	@Override
	public StudySiteResponse getStudySitesByTrialZipMiles(Long trialId, Long zip, Float miles) {

		List<StudySite> studySiteList = getStudySiteListWithQuickGeo(trialId, zip, miles);
		// Query DB directly if there is no study sites available by lat and lang
		if (null == studySiteList || studySiteList.size() <= 0) {
			studySiteList = studySiteRepository
					.findByCinicalTrialStudySitesClinicalStudySiteIdIdAndCinicalTrialStudySitesIsActiveTrueAndZipAndActiveTrue(
							trialId, String.valueOf(zip));
		}
		// Generate DTO object
		List<StudySiteDto> lstStudySiteDto = new ArrayList<StudySiteDto>();
		lstStudySiteDto = buildStudySiteDtoList(studySiteList, trialId);

		// Add matched sites lists to response
		StudySiteResponse response = new StudySiteResponse();
		response.setMatchedStudySites(lstStudySiteDto);

		// Get suggested sites If related sites not foundby extending miles by 10 times
		// and do a search again
		if (null == response.getMatchedStudySites() || response.getMatchedStudySites().size() <= 0) {
			response.setSuggestedStudySites(
					buildStudySiteDtoList(getStudySiteListWithQuickGeo(trialId, zip, miles * 10), trialId));
		}
		return response;
	}

	@Override
	public List<StudySite> findByLatLngByMiles(List<Float> latList, List<Float> LngList) {

		return null;
	}

	@Override
	public List<StudySiteDto> findByMiles(Float latitude, Float longitude, Float miles, Long trialId) {
		return buildStudySiteDtoList(studySiteRepository.findByMiles(latitude, latitude, longitude, miles, trialId),
				trialId);
	}
	
	
	

	@Override
	public ResponseObjectModel getAllStudySitesByTrailId(Long trialId,
			StudySiteFilterRequestModel studySiteFilterRequest) {

		// PageRequest pageRequest = CommonUtil.getPageRequest(start, pageSize,
		// columnToSort, sortType);
		
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				// .findByIsActiveTrueAndClinicalStudySiteIdId(trialId);
				.findByClinicalStudySiteIdId(trialId);
		if (listClinicalTrialStudySite.size() <= 0) {
			return new ResponseObjectModel();
		}
		List<Long> ids = new ArrayList<Long>();
		List<CountModel> lstCount = new ArrayList<CountModel>();
		if (studySiteFilterRequest.getColumnToSort().equals("referred")
				|| studySiteFilterRequest.getColumnToSort().equals("enrolled")) {
			lstCount = getParticipantStudySite(trialId);
			if (null != lstCount && lstCount.size() > 0) {
				for (CountModel countModel : lstCount)
					// Need to collect studysite id for the search
					ids.add(Long.parseLong(String.valueOf(countModel.getId())));
			}
		}

		if (listClinicalTrialStudySite.size() > 0) {
			ids = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId()).collect(Collectors.toList());

			logger.info("Filtered StudySite Ids:" + ids);
			if (studySiteFilterRequest.getPageSize() <= 0)
				studySiteFilterRequest.setPageSize(100000);
			Page<StudySite> pgStudySite = studySiteRepository.findAll(
					getStudySiteSpecification(studySiteFilterRequest, null, ids),
					new PageRequest(studySiteFilterRequest.getPage(), studySiteFilterRequest.getPageSize()));
			List<StudySite> lstSites = pgStudySite.getContent().stream().collect(Collectors.toList());
			List<StudySite> sites = new ArrayList<StudySite>();
			List<StudySite> sites1 = new ArrayList<StudySite>();
			for(StudySite site: lstSites) {
				for(ClinicalTrialStudySite clinicalTrialSite : listClinicalTrialStudySite) {
					if(site.getId().equals(clinicalTrialSite.getId().getStudySiteId())) {
						site.setRadiusValue(clinicalTrialSite.getRadiusValue());
						site.setRadiusExempt(clinicalTrialSite.getRadiusExempt());
						sites.add(site);
					}
				}
			}
			
			HashSet<StudySite> piSet = new HashSet<>(sites);
			sites.clear();
			// set active status based on trialstudysite entry.
			piSet.forEach(studySite -> {
				Optional<ClinicalTrialStudySite> optTrialStudySite = listClinicalTrialStudySite.stream()
						.filter(lpi -> lpi.getId().getStudySiteId() == studySite.getId()).findFirst();
				if (optTrialStudySite.isPresent()) {
					studySite.withActive(optTrialStudySite.get().getIsActive());
				}
				sites.add(studySite);
			});
			List<StudySiteDto> studySiteDtoList = null;
			if (studySiteFilterRequest.getColumnToSort() != null && studySiteFilterRequest.getColumnToSort()
					.equalsIgnoreCase("studySitePrincipalInvestigatorsPrincipalInvestigatorName")) {
				sites1 = getSortedStudySiteByPIName(sites, studySiteFilterRequest);
				studySiteDtoList = generateStudySiteDtoPICo(sites1, trialId);
			} else
				studySiteDtoList = generateStudySiteDtoPICo(sites, trialId);
			if (lstCount.size() > 0 && null != studySiteDtoList && studySiteDtoList.get(0).getFeatures().size() > 0) {
				for (int j = 0; j < lstCount.size(); j++) {
					List<Features> lstFeatures = studySiteDtoList.get(0).getFeatures();
					for (int i = 0; i < lstFeatures.size(); i++) {

						if (lstFeatures.get(i).getProperties().getStudySiteId()
								.equals(Long.parseLong(String.valueOf(lstCount.get(j).getId())))) {

							if (lstCount.get(j).getStatusId().equals(new BigInteger("12"))) {
								lstFeatures.get(i).getProperties()
										.withReferred(Integer.parseInt(String.valueOf(lstCount.get(j).getCount())));
								break;
							}
							if (lstCount.get(j).getStatusId().equals(new BigInteger("7"))) {
								lstFeatures.get(i).getProperties()
										.withEnrolled(Integer.parseInt(String.valueOf(lstCount.get(j).getCount())));
								break;
							}
						}
					}
				}
			}

			if ((studySiteFilterRequest.getColumnToSort().equals("referred")
					|| studySiteFilterRequest.getColumnToSort().equals("enrolled"))
					&& (null != studySiteDtoList && studySiteDtoList.size() > 0))
				sortStudySiteDto(studySiteDtoList, studySiteFilterRequest.getColumnToSort(),
						studySiteFilterRequest.getSortType());

			ResponseObjectModel response = new ResponseObjectModel();
			response.setData(studySiteDtoList);
			response.setTotal(pgStudySite.getTotalElements());
			response.setTotalPages(pgStudySite.getTotalPages());
			return response;
		} else {
			return new ResponseObjectModel();
		}

	}

	@SuppressWarnings("unchecked")
	private List<StudySiteDto> sortStudySiteDto(List<StudySiteDto> studySiteDtoList, String sortColumn,
			String sortOrder) {
		Collections.sort(studySiteDtoList.get(0).getFeatures(), new Comparator() {
			public int compare(Object o1, Object o2) {

				int x1 = 0;
				int x2 = 0;
				if (sortColumn.equals("enrolled")) {
					x1 = ((Features) o1).getProperties().getEnrolled();
					x2 = ((Features) o2).getProperties().getEnrolled();
				} else {
					x1 = ((Features) o1).getProperties().getReferred();
					x2 = ((Features) o2).getProperties().getReferred();
				}

				if (x1 != x2) {
					if (sortOrder.equals("asc"))
						return x1 - x2;
					else
						return x2 - x1;
				} else {
					int y1 = 0;
					int y2 = 0;
					if (sortColumn.equals("enrolled")) {
						y1 = ((Features) o1).getProperties().getEnrolled();
						y2 = ((Features) o2).getProperties().getEnrolled();
					} else {
						y1 = ((Features) o1).getProperties().getReferred();
						y2 = ((Features) o2).getProperties().getReferred();
					}
					return y2 - y1;
				}
			}
		});
		return studySiteDtoList;
	}

	private StudySiteDto generateStudySiteDtoPICo(StudySite studySite, Long trialId) {

		List<StudySiteCoordinator> lstStudySiteCoordinator = studySiteCoordinatorRepository
				.findByStudySiteIdAndTrialId(studySite.getId(), trialId);
		if (null != lstStudySiteCoordinator && lstStudySiteCoordinator.size() > 0) {
			Set<StudySiteCoordinator> setCoordinator = new HashSet<StudySiteCoordinator>(lstStudySiteCoordinator);

			studySite.withStudySiteCoordinators(setCoordinator);
		}

		List<StudySitePrincipalInvestigator> lstStudySitePrincipalInvestigators = studySitePrincipalInvestigatorRepository
				.findByStudySiteId(studySite.getId());
		if (null != lstStudySitePrincipalInvestigators && lstStudySitePrincipalInvestigators.size() > 0) {
			Set<StudySitePrincipalInvestigator> setPIs = new HashSet<StudySitePrincipalInvestigator>(
					lstStudySitePrincipalInvestigators);

			studySite.withStudySitePrincipalInvestigators(setPIs);
		}
		if (null != trialId && trialId > 0) {
			try {
				List<ClinicalTrialStudySite> lstClinicalTrialStudySite = clinicalStudySiteRepository
						.findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteId(trialId, studySite.getId());
				if (null != lstClinicalTrialStudySite && lstClinicalTrialStudySite.size() > 0) {
					studySite.withActive(lstClinicalTrialStudySite.get(0).getIsActive());
					studySite.setRadiusValue(lstClinicalTrialStudySite.get(0).getRadiusValue());
					studySite.setRadiusExempt(lstClinicalTrialStudySite.get(0).getRadiusExempt());
				}

			} catch (Exception ex) {
				logger.debug(ex.getMessage());
			}

		}
		StudySiteDto studySiteDto = buildStudySiteDto(studySite, trialId);
		logger.info("StudySiteDTO:" + studySiteDto);
		return studySiteDto;
	}

	private List<StudySiteDto> generateStudySiteDtoPICo(List<StudySite> lstStudySite, Long trialId) {
		List<StudySiteDto> studySiteDtoList = buildStudySiteDtoList(lstStudySite, trialId);
		if (studySiteDtoList != null)
			logger.info("******" + studySiteDtoList.size());

		return studySiteDtoList;
	}

	@Override
	public List<StudySiteDto> buildStudySiteDtoList(List<StudySite> studySites, Long trialId) {

		if (studySites != null && studySites.size() > 0) {
			logger.info("****________*******" + studySites.size() + "," + trialId);
			List<StudySiteDto> studySiteDtos = new ArrayList<>();

			StudySiteDto studySiteDto = new StudySiteDto();

			studySiteDto.setType("FeatureCollection");
			studySiteDto.setTrialId(trialId);
			List<Features> featuresList = new ArrayList<>();
			for (StudySite studySite : studySites) {
				featuresList.add(generateFeatures(studySite, trialId));
			}
			studySiteDto.setFeatures(featuresList);
			logger.info(studySiteDto + "Study site");
			studySiteDtos.add(studySiteDto);
			return studySiteDtos;
		}

		return null;

		/*
		 * Optional<List<StudySiteDto>> dtoOp = Optional.ofNullable(studySites).map(
		 * list ->{ if(list.isEmpty()) return new ArrayList<StudySiteDto>();
		 * 
		 * StudySiteDto studySiteDto = new StudySiteDto();
		 * studySiteDto.setType("FeatureCollection"); studySiteDto.setTrialId(trialId);
		 * List<Features> featuresList = new ArrayList<>(); list.forEach(
		 * studySite->featuresList.add(generateFeatures(studySite)) );
		 * studySiteDto.setFeatures(featuresList); logger.info(studySiteDto +
		 * "Study site"); List<StudySiteDto> studySiteDtoList = new ArrayList<>();
		 * studySiteDtoList.add(studySiteDto); return studySiteDtoList; });
		 * 
		 * return dtoOp.isPresent()?dtoOp.get():null;
		 */

	}

	private StudySiteDto buildStudySiteDto(StudySite studySite, Long trialId) {

		StudySiteDto studySiteDto = new StudySiteDto();

		studySiteDto.setType("FeatureCollection");
		studySiteDto.setTrialId(trialId);
		List<Features> featuresList = new ArrayList<>();

		featuresList.add(generateFeatures(studySite, trialId));

		studySiteDto.setFeatures(featuresList);
		logger.info(studySiteDto + "Study site");

		return studySiteDto;

	}

	private Properties generateProperty(StudySite studySite, Long trialId) {
		Properties properties = new Properties();
		properties.withCity(studySite.getCity());
		properties.withCountry(studySite.getCountry());
		properties.withPostalCode(studySite.getZip() + "");
		properties.withState(studySite.getState());
		properties.withEmailAddress(studySite.getEmailAddress());
		properties.withPhoneNumber(studySite.getPhoneNumber());
		properties.withZip(studySite.getZip());
		properties.withAddress1(studySite.getAddress1());
		properties.withAddress2(studySite.getAddress2());
		properties.withStudySiteId(studySite.getId());
		properties.withUltimateParentName(studySite.getUltimateParentName());
		properties.withCreatedOn(studySite.getCreatedOn());
		// properties.withStudySiteNumber(studySite.getStudySiteNumber());
		properties.withStudySiteName(studySite.getStudySiteName());
		List<CoordinatorDto> lstCoordinator = new ArrayList<CoordinatorDto>();
		if (studySite.getStudySiteCoordinators() != null) {
			for (StudySiteCoordinator coordinator : studySite.getStudySiteCoordinators()) {
				if (coordinator.getCoordinator() != null) {
					logger.info(coordinator.getCoordinator().getName());
					lstCoordinator.add(getCoordinatorDtoModel(coordinator.getCoordinator()));
				}
			}
		}
		List<PrincipalInvestigatorDto> lstPrincipalInvestigator = new ArrayList<PrincipalInvestigatorDto>();

		if (studySite.getStudySitePrincipalInvestigators() != null) {

			for (StudySitePrincipalInvestigator principalInvestigator : studySite
					.getStudySitePrincipalInvestigators()) {
				if (principalInvestigator.getPrincipalInvestigator() != null) {
					if ((null != trialId && null != principalInvestigator.getTrialId()
							&& (principalInvestigator.getTrialId().equals(trialId)) || trialId == 0)) {
						lstPrincipalInvestigator.add(
								getPrincipalInvestigatorDtoModel(principalInvestigator.getPrincipalInvestigator()));
					}
				}
			}
		}
		if (lstPrincipalInvestigator.size() > 0) {
			HashSet<PrincipalInvestigatorDto> piSet = new HashSet<>(lstPrincipalInvestigator);
			lstPrincipalInvestigator.clear();

			piSet.forEach(piDto -> {
				if (lstPrincipalInvestigator.stream().filter(lpi -> lpi.getName().equals(piDto.getName()))
						.count() <= 0) {
					lstPrincipalInvestigator.add(piDto);
				}
			});
			logger.info("lstPrincipalInvestigator size 585 list "+lstPrincipalInvestigator);
		}
		properties.withPrincipalInvestigators(lstPrincipalInvestigator);
		logger.info("lstPrincipalInvestigator size 587"+lstPrincipalInvestigator.size());
		properties.withCoordinators(lstCoordinator);
		properties.withRegion(studySite.getRegion());
		properties.withActive(studySite.getActive());
		properties.withPrimaryIndication(studySite.getPrimaryIndication());
		properties.withPrimaryTherapeuticArea(studySite.getPrimaryTherapeuticArea());
		properties.withStudySiteIRBId(studySite.getStudySiteIRBId());
		properties.withStudySitePhaseId(studySite.getStudySitePhaseId());
		properties.withStudySiteStatusId(studySite.getStudySiteStatusId());
		properties.setRadiusValue(studySite.getRadiusValue());
		properties.setRadiusExempt(studySite.isRadiusExempt());
		properties.setAuditResponse(getStudySiteAuditReport(studySite.getId()));
		
		return properties;
	}

	private Features generateFeatures(StudySite studySite, Long trialId) {
		Features features = new Features();
		features.setStudySiteId(studySite.getId());
		features.setType("Feature");
		Geometry geometry = new Geometry();
		geometry.setType("Point");
		String[] coordinates = new String[] { String.valueOf(studySite.getLongitude()),
				String.valueOf(studySite.getLatitude()) };
		geometry.setCoordinates(coordinates);
		features.setGeometry(geometry);
		Properties properties = generateProperty(studySite, trialId);
		properties.setTrialId(trialId);
		features.setProperties(properties);
		return features;
	}

	private PrincipalInvestigatorDto getPrincipalInvestigatorDtoModel(PrincipalInvestigator principalInvestigator) {
		PrincipalInvestigatorDto principalInvestigatorDto = new PrincipalInvestigatorDto();
		principalInvestigatorDto.setName(principalInvestigator.getName());
		principalInvestigatorDto.setId(principalInvestigator.getPrincipalInvestigatorId());

		return principalInvestigatorDto;
	}

	private CoordinatorDto getCoordinatorDtoModel(Coordinator coordinator) {
		CoordinatorDto coordinatorDto = new CoordinatorDto();
		coordinatorDto.setId(coordinator.getCoordinatorId());
		coordinatorDto.setName(coordinator.getName());
		coordinatorDto.setPhoneNumber(coordinator.getPhoneNumber());
		return coordinatorDto;
	}

	@Override
	public StudySiteDto getStudySitesByStudySiteId(Long studySiteId) {

		StudySiteDto studySite = generateStudySiteDtoPICo(studySiteRepository.findById(studySiteId), 0l);

		return studySite;
	}

	@Override
	public StudySiteDto getStudySitesByStudySiteIdAndTrialId(Long studySiteId, Long trialId) {
		StudySiteDto studySite = generateStudySiteDtoPICo(studySiteRepository.findById(studySiteId), trialId);

		logger.info("StudySite:" + studySite);
		return studySite;
	}

	@Override
	public List<StudySite> findByNotTrailIdIn(Long trialId) {
		return studySiteRepository.findByNotTrailIdIn(trialId);
	}

	@Override
	public Optional<List<ClinicalTrialStudySite>> saveClinicalTrialStudySiteByTrailIdStudySiteIds(Long trialId,
			List<Long> studySiteIds) {

		List<ClinicalTrialStudySite> lstClinicalTrialStudySite = new ArrayList<ClinicalTrialStudySite>();
		studySiteIds.forEach(id -> {
			lstClinicalTrialStudySite.add(new ClinicalTrialStudySite(new ClinicalStudySiteId(trialId, id)));
		});

		Optional<List<ClinicalTrialStudySite>> opList = Optional
				.ofNullable(clinicalStudySiteRepository.save(lstClinicalTrialStudySite));
		return opList;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel save(StudySite studySiteToBePersisted) {
		ResponseObjectModel responseObject = new ResponseObjectModel();

		Optional.ofNullable(studySiteToBePersisted).ifPresent(ss -> {
			Optional.ofNullable(studySiteRepository.findByStudySiteName(ss.getStudySiteName())).ifPresent(e -> {
				if (!e.isEmpty()) {
					responseObject.setHttpStatus(HttpStatus.CREATED);
					responseObject.setMessage("StudySite name already exists.");
				}
			});
			StudySite savedSite = ss;
			if (responseObject.getHttpStatus() != HttpStatus.CREATED) {
				savedSite = studySiteRepository.save(ss);
				responseObject.setHttpStatus(HttpStatus.OK);
			}
			logger.info("*************" + savedSite.getId());
			responseObject.setData(savedSite);

		});
		return responseObject;
		/*
		 * if (studySiteToBePersisted != null) { List<StudySite> existingSites =
		 * studySiteRepository
		 * .findByStudySiteName(studySiteToBePersisted.getStudySiteName()); if (null !=
		 * existingSites && existingSites.size() > 0) { responseObject.setStatus(201);
		 * responseObject.setMessage("StudySite name already exists."); return
		 * responseObject; } } logger.info("*************" +
		 * studySiteToBePersisted.getId()); StudySite savedSite =
		 * studySiteRepository.save(studySiteToBePersisted); // code to add principal
		 * investigator and coordinator responseObject.setStatus(200);
		 * responseObject.setData(studySiteToBePersisted); return responseObject;
		 */
	}

	private void deletePICoordinator(StudySite studySiteToBePersisted) {
		List<StudySitePrincipalInvestigator> lstStudySitePrincipalInvestigator = studySitePrincipalInvestigatorRepository
				.findByStudySiteId(studySiteToBePersisted.getId());
		if (null != lstStudySitePrincipalInvestigator && lstStudySitePrincipalInvestigator.size() > 0) {
			for (StudySitePrincipalInvestigator sp : lstStudySitePrincipalInvestigator)
				studySitePrincipalInvestigatorRepository.delete(sp);
		}

		List<StudySiteCoordinator> lstStudySiteCoordinator = studySiteCoordinatorRepository
				.findByStudySiteId(studySiteToBePersisted.getId());
		if (null != lstStudySiteCoordinator && lstStudySiteCoordinator.size() > 0) {
			for (StudySiteCoordinator sc : lstStudySiteCoordinator) {
				studySiteCoordinatorRepository.delete(sc);
			}
			// studySiteCoordinatorRepository.delete(lstStudySiteCoordinator);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel updateStudySite(Properties property, Long trialId) {

		StudySite studySiteToBePersisted = null;
		if (property.getStudySiteId() > 0) {
			studySiteToBePersisted = studySiteRepository.findById(property.getStudySiteId());
			generateStudySiteFromProperty(property, studySiteToBePersisted, true);
		}
		ResponseObjectModel responseObject = new ResponseObjectModel();
		
		if (studySiteToBePersisted != null && studySiteToBePersisted.getId() <= 0) {
			List<StudySite> existingSites = studySiteRepository.findByStudySiteName(studySiteToBePersisted.getStudySiteName());
			if (null != existingSites && existingSites.size() > 0) {
				responseObject.setHttpStatus(HttpStatus.CREATED);
				responseObject.setMessage("StudySite name already exists.");
				return responseObject;
			} else {
				// deletePICoordinator(studySiteToBePersisted);
			}
		}
		if (studySiteToBePersisted != null && studySiteToBePersisted.getId() > 0) {
			List<StudySite> existingSites = studySiteRepository.findByStudySiteName(studySiteToBePersisted.getStudySiteName());
			
			if (null != existingSites && existingSites.size() > 0) {
				for(StudySite site : existingSites) {
					if(studySiteToBePersisted.getId() != site.getId() && site.getZip().equalsIgnoreCase(studySiteToBePersisted.getZip())) {
						responseObject.setHttpStatus(HttpStatus.CREATED);
						responseObject.setMessage("StudySite name already exists for this zipcode  "+site.getZip());
						return responseObject;
					}
				}
			} else {
				// deletePICoordinator(studySiteToBePersisted);
			}
		}
		logger.info("****studySiteToBePersisted.getId()   *********" + studySiteToBePersisted.getId());
		if (null != property.getCoordinators() && property.getCoordinators().size() > 0) {

			studySiteToBePersisted = assignStudySiteCoordinator(property.getCoordinators(), studySiteToBePersisted,
					trialId);
			if (null == studySiteToBePersisted) {
				responseObject.setHttpStatus(HttpStatus.OK);
				return responseObject;
			}
		}
		if (null != property.getPrincipalInvestigators() && property.getPrincipalInvestigators().size() > 0) {

			assignStudySitePrincipalInvestigator(property.getPrincipalInvestigators(), studySiteToBePersisted, trialId);
		}
		studySiteToBePersisted.withActive(true);// Cant change studysite status from trial.
		studySiteRepository.save(studySiteToBePersisted);

		if (null != trialId && trialId > 0) {
			try {
				List<ClinicalTrialStudySite> lstClinicalTrialStudySite = clinicalStudySiteRepository
						.findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteId(trialId,
								studySiteToBePersisted.getId());
				for (int i = 0; i < lstClinicalTrialStudySite.size(); i++) {
					lstClinicalTrialStudySite.get(i).setIsActive(property.getActive());
					if(null != lstClinicalTrialStudySite && null!= lstClinicalTrialStudySite.get(i) &&
							!lstClinicalTrialStudySite.get(i).getRadiusChanged() &&
							((lstClinicalTrialStudySite.get(i).getRadiusValue() != property.getRadiusValue()) ||
							(lstClinicalTrialStudySite.get(i).getRadiusExempt() != property.getRadiusExempt()))) {
						lstClinicalTrialStudySite.get(i).withRadiusChanged(true);
					}
					if(null!=property.getRadiusValue() && String.valueOf(property.getRadiusValue()).matches("^(?:[1-9][0-9]{3}|[1-9][0-9]{2}|[1-9][0-9]|[1-9])$")) {
						lstClinicalTrialStudySite.get(i).withRadiusValue(property.getRadiusValue());
					} else if(property.getRadiusValue()==null || property.getRadiusValue()==0) {
						lstClinicalTrialStudySite.get(i).withRadiusValue(0);
					}
					lstClinicalTrialStudySite.get(i).withRadiusExempt(property.getRadiusExempt());
				}
				clinicalStudySiteRepository.save(lstClinicalTrialStudySite);
			} catch (Exception ex) {
				logger.debug(ex.getMessage());
			}
		}
		// code to add principal investigator and coordinator
		responseObject.setHttpStatus(HttpStatus.OK);
		responseObject.setData(studySiteToBePersisted);
		return responseObject;
	}

	private void assignStudySitePrincipalInvestigator(List<PrincipalInvestigatorDto> lstPrincipalInvestigators,
			StudySite studySiteToBePersisted, Long trialId) {

		List<StudySitePrincipalInvestigator> existingRecordsForStudySite = studySitePrincipalInvestigatorRepository
				.findByStudySiteId(studySiteToBePersisted.getId());

		if (null != trialId) {
			existingRecordsForStudySite = existingRecordsForStudySite.stream()
					.filter(ss -> (ss.getTrialId() == trialId || null == ss.getTrialId())).collect(Collectors.toList());
		}

		if (null != trialId && lstPrincipalInvestigators.size() > 0) {
			studySitePrincipalInvestigatorRepository.deleteByStudySiteIdIdAndTrialId(studySiteToBePersisted.getId(),
					trialId);
		}

		logger.info("Existing StudySitePrincipalInvestigator records:" + existingRecordsForStudySite);
		List<StudySitePrincipalInvestigator> saveStudySitePrincipalInvestigatorList = new ArrayList<>();

		for (int i = 0; i < lstPrincipalInvestigators.size(); i++) {

			Long id = lstPrincipalInvestigators.get(i).getId();

			if (null == id || id == 0) {
				List<PrincipalInvestigator> piList = principalInvestigatorRepository
						.findByName(lstPrincipalInvestigators.get(i).getName());
				if (piList.size() > 0) {
					id = piList.get(0).getPrincipalInvestigatorId();
				} else {
					PrincipalInvestigator pi = principalInvestigatorRepository
							.save(new PrincipalInvestigator().withName(lstPrincipalInvestigators.get(i).getName()));
					id = pi.getPrincipalInvestigatorId();
				}
			}

			saveStudySitePrincipalInvestigatorList.add(new StudySitePrincipalInvestigator()
					// .withStudySitePrincipalInvestigatorId(sspInv.getStudySitePrincipalInvestigatorId())
					.withPrincipalInvestigatorId(id).withStudySiteId(studySiteToBePersisted.getId())
					.withTrialId(trialId));
		}

		logger.info(
				"New StudySitePrincipalInvestigator records to be persisted:" + saveStudySitePrincipalInvestigatorList);
		if (saveStudySitePrincipalInvestigatorList.size() > 0) {
			studySiteToBePersisted.withStudySitePrincipalInvestigators(
					new HashSet<StudySitePrincipalInvestigator>(saveStudySitePrincipalInvestigatorList));
			studySitePrincipalInvestigatorRepository.save(saveStudySitePrincipalInvestigatorList);
		}
	}

	private StudySite assignStudySiteCoordinator(List<CoordinatorDto> lstCoordinators, StudySite studySiteToBePersisted,
			Long trialId) {
		List<StudySiteCoordinator> existingRecordsForStudySite = studySiteCoordinatorRepository
				.findByStudySiteId(studySiteToBePersisted.getId());

		/*
		 * if (null != trialId) { existingRecordsForStudySite =
		 * existingRecordsForStudySite.stream() .filter(ss ->
		 * (ss.getTrialId().equals(trialId))).collect(Collectors.toList()); }
		 * 
		 * logger.error("Existing StudySiteCoordinator records:" +
		 * existingRecordsForStudySite); List<StudySiteCoordinator>
		 * saveStudySiteCordinatorList = new ArrayList<>();
		 * 
		 * for (int i = 0; i < lstCoordinators.size(); i++) { Long id =
		 * lstCoordinators.get(i).getId();
		 * 
		 * if (null == id || id == 0) { List<Coordinator> coList =
		 * coordinatorRepository.findByName(lstCoordinators.get(i).getName()); if
		 * (coList.size() > 0) { id = coList.get(0).getCoordinatorId(); if (null !=
		 * trialId) { studySiteCoordinatorRepository.deleteByStudySiteIdAndTrialId(
		 * studySiteToBePersisted.getId(), trialId); } else {
		 * studySiteCoordinatorRepository.deleteByCoordinatorId(id); }
		 * 
		 * saveStudySiteCordinatorList.add(new StudySiteCoordinator() //
		 * .withStudySitePrincipalInvestigatorId(sspInv.
		 * getStudySitePrincipalInvestigatorId())
		 * .withCoordinatorId(id).withStudySiteId(studySiteToBePersisted.getId()).
		 * withTrialId(trialId)); } else { return null; } }
		 * 
		 * 
		 * }
		 * 
		 * logger.info("New StudySiteCordinator records to be added:" +
		 * saveStudySiteCordinatorList); if (saveStudySiteCordinatorList.size() > 0) {
		 * studySiteToBePersisted .withStudySiteCoordinators(new
		 * HashSet<StudySiteCoordinator>(saveStudySiteCordinatorList));
		 * studySiteCoordinatorRepository.save(saveStudySiteCordinatorList); }
		 */

		List<StudySiteCoordinator> saveStudySiteCordinatorList = new ArrayList<>();
		for (int i = 0; i < lstCoordinators.size(); i++) {
			Long id = lstCoordinators.get(i).getId();
			if (null == id || id == 0) {
				List<Coordinator> coList = coordinatorRepository.findByName(lstCoordinators.get(i).getName());
				if (coList.size() > 0) {
					id = coList.get(0).getCoordinatorId();
					coordinatorRepository.save(coList.get(0).withPhoneNumber(lstCoordinators.get(i).getPhoneNumber())); // update
																														// phone
																														// number
				} else {
					Coordinator co = coordinatorRepository
							.save(new Coordinator().withName(lstCoordinators.get(i).getName())
									.withPhoneNumber(lstCoordinators.get(i).getPhoneNumber()));
					id = co.getCoordinatorId();
				}

				if (null != existingRecordsForStudySite && existingRecordsForStudySite.size() > 0) {
					Long coId = id;
					existingRecordsForStudySite.forEach(ssc -> ssc.withCoordinatorId(coId));
					saveStudySiteCordinatorList.addAll(existingRecordsForStudySite);
				} else {
					saveStudySiteCordinatorList.add(new StudySiteCoordinator().withCoordinatorId(id)
							.withStudySiteId(studySiteToBePersisted.getId()).withTrialId(trialId));
				}

			}
		}

		logger.info("StudySiteCordinator records to be added:" + saveStudySiteCordinatorList);
		if (saveStudySiteCordinatorList.size() > 0) {
			studySiteToBePersisted
					.withStudySiteCoordinators(new HashSet<StudySiteCoordinator>(saveStudySiteCordinatorList));
			studySiteCoordinatorRepository.save(saveStudySiteCordinatorList);
		} else {
			return null;
		}

		return studySiteToBePersisted;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	private StudySite UpdateByNameByZip(StudySite studySite, ExistReponse AlreadyExist) {
		if (studySite != null) {
			List<StudySite> existingSites = studySiteRepository.findByStudySiteNameAndZip(studySite.getStudySiteName(),
					studySite.getZip());
			if (null != existingSites && existingSites.size() > 0) {
				studySite.withId(existingSites.get(0).getId());
				studySite = studySiteRepository.save(studySite);
				AlreadyExist.setAlreadyExist(true);
				return studySite;
			}
		}
		logger.info("*************" + studySite.getId());
		StudySite savedSite = studySiteRepository.save(studySite);
		return savedSite;
	}

	@Override
	public void delete(Long id) {
		if (id != null) {
			studySiteRepository.delete(id);
		} else {
			logger.info("Delete criteria called with null Criteria obj");
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Optional<StudySite> update(StudySite studySiteToBeUpdated) {
		Optional<StudySite> studySiteRet = Optional.ofNullable(studySiteToBeUpdated).map(sSite -> {
			StudySite studySite = studySiteRepository.findById(sSite.getId());
			if (studySite == null)
				logger.error("Update called on an nonextistent studySite: " + studySiteToBeUpdated.toString());
			return studySite;
		}).map(ct -> {
			if (ct.getActive() != studySiteToBeUpdated.getActive()) {
				StudySiteAudit studySiteAudit = new StudySiteAudit();
				studySiteAudit.setStudySiteId(studySiteToBeUpdated.getId());
				studySiteAudit.setPreviousStatus(ct.getActive());
				studySiteAudit.setChangedStatus(studySiteToBeUpdated.getActive());
				studySiteAudit.setUpdatedBy(studySiteToBeUpdated.getUpdatedBy());
				studySiteAudit.setUpdatedOn(studySiteToBeUpdated.getUpdatedOn());
				studySiteAuditRepository.save(studySiteAudit);
			}
			return studySiteRepository.save(studySiteToBeUpdated);
		});
		return studySiteRet;
	}

	@Override
	public void saveToFile(MultipartFile file, String target) throws IOException {

		byte[] byteArr = file.getBytes();
		InputStream inStream = new ByteArrayInputStream(byteArr);
		OutputStream out = null;
		int read = 0;
		byte[] bytes = new byte[1024];
		out = new FileOutputStream(new File(target));
		while ((read = inStream.read(bytes)) != -1) {
			out.write(bytes, 0, read);
		}
		out.flush();
		out.close();
	}

	/**
	 * Creates a folder to desired location if it not already exists
	 * 
	 * @param dirName
	 *            - full path to the folder
	 * @throws SecurityException
	 *             - in case you don't have permission to create the folder
	 */
	@Override
	public void createFolderIfNotExists(String dirName) throws SecurityException {
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
	}

	/**
	 * Creates a reader for a resource in the relative path
	 *
	 * @param relativePath
	 *            relative path of the resource to be read
	 *
	 * @return a reader of the resource
	 */
	public static Reader getReader(String relativePath) {
		try {

			return new InputStreamReader(StudySiteServiceImpl.class.getResourceAsStream(relativePath), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new IllegalStateException("Unable to read input", e);
		}
	}

	@Override
	public FileResponseModel importStudySiteFromCSV(MultipartFile csvFile, Long trialId) {
		FileResponseModel response = new FileResponseModel();
		String extension = csvFile.getOriginalFilename();
		String uploadedFileLocation = CSVConstant.UPLOAD_FOLDER + csvFile.getOriginalFilename();
		if (extension.indexOf(".") > 0) {
			extension = extension.substring(extension.lastIndexOf(".") + 1);
			if (!extension.toLowerCase().equals("csv"))
				response.setMessage("Invalid File");
			else {
				response.setMessage("");
				try {
					createFolderIfNotExists(CSVConstant.UPLOAD_FOLDER);
					saveToFile(csvFile, uploadedFileLocation);
					BeanListProcessor<StudySiteCSVBean> rowProcessor = new BeanListProcessor<StudySiteCSVBean>(
							StudySiteCSVBean.class);
					CsvParserSettings parserSettings = new CsvParserSettings();
					parserSettings.getFormat().setLineSeparator("\n");
					parserSettings.setProcessor(rowProcessor);
					parserSettings.setHeaderExtractionEnabled(true);
					CsvParser parser = new CsvParser(parserSettings);
					Reader reader = Files.newBufferedReader(Paths.get(uploadedFileLocation));
					parser.parse(reader);
					// Let's get our StudySiteCSVBeans
					String[] headers = rowProcessor.getHeaders();
					String headerString = String.join(",", headers).toLowerCase();
					logger.info(headerString);
					System.out
							.println(Arrays.asList(CSVConstant.Header.split(",")).containsAll(Arrays.asList(headers)));

					Collection<String> smallerSet = new ArrayList<String>(
							Arrays.asList(CSVConstant.Header.toLowerCase().split(",")));
					Collection<String> biggerSet = new ArrayList<String>(Arrays.asList(headerString.split(",")));

					biggerSet.retainAll(smallerSet);
					if (biggerSet.size() != smallerSet.size()) {
						smallerSet.removeAll(biggerSet);
						response.setMessage("Missed columns(s):  " + String.join(",", smallerSet));
						return response;
					}

					List<StudySiteCSVBean> studySiteCSVBeans = rowProcessor.getBeans();
					logger.info("List of study sites size  +++++  "+studySiteCSVBeans.size());
					String fileName = csvFile.getOriginalFilename() + CommonUtil.formatDate(new Date());
					String originalFileName = csvFile.getOriginalFilename();
					if (studySiteCSVBeans.size() > 0) {
						StudySiteImportStatus importStatus = studySiteAsyncService.addNewStatusEntry(originalFileName, fileName, trialId);
						try {
							studySiteAsyncService.processCSVBean(fileName, studySiteCSVBeans, trialId);// .get();
						} catch (Exception e) {
							logger.info("Error Calling Async Service");
							logger.error("Error occurred during invocation of Async Service", e);
						}

						response.setMessage("Started processing of imported studysites");
						response.setTotalRows(studySiteCSVBeans.size());
					} else {
						response.setMessage("No records are present to import");
						response.setTotalRows(0);
					}
					return response;

				} catch (SecurityException se) {
					response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
					response.setMessage("Can not create destination folder on server");
				} catch (IOException e) {
					response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
					response.setMessage("Can not save file");
				}
				response.setHttpStatus(HttpStatus.OK);
				response.setMessage("File Uploaded >>>" + uploadedFileLocation);
			}
		}

		return response;
	}
	
	@Override
	public FileResponseModel uploadStudySitesWithoutTrialId(MultipartFile csvFile) {
		
		FileResponseModel response = new FileResponseModel();
		String extension = csvFile.getOriginalFilename();
		String uploadedFileLocation = CSVConstant.UPLOAD_FOLDER + csvFile.getOriginalFilename();
		if (extension.indexOf(".") > 0) {
			extension = extension.substring(extension.lastIndexOf(".") + 1);
			if (!extension.toLowerCase().equals("csv"))
				response.setMessage("Invalid File");
			else {
				response.setMessage("");
				try {
					createFolderIfNotExists(CSVConstant.UPLOAD_FOLDER);
					saveToFile(csvFile, uploadedFileLocation);
					BeanListProcessor<StudySiteCSVBean> rowProcessor = new BeanListProcessor<StudySiteCSVBean>(
							StudySiteCSVBean.class);
					CsvParserSettings parserSettings = new CsvParserSettings();
					parserSettings.getFormat().setLineSeparator("\n");
					parserSettings.setProcessor(rowProcessor);
					parserSettings.setHeaderExtractionEnabled(true);
					CsvParser parser = new CsvParser(parserSettings);
					Reader reader = Files.newBufferedReader(Paths.get(uploadedFileLocation));
					parser.parse(reader);
					// Let's get our StudySiteCSVBeans
					String[] headers = rowProcessor.getHeaders();
					String headerString = String.join(",", headers).toLowerCase();
					logger.info(headerString);
					System.out.println(Arrays.asList(CSVConstant.Header.split(",")).containsAll(Arrays.asList(headers)));

					Collection<String> smallerSet = new ArrayList<String>(
							Arrays.asList(CSVConstant.Header.toLowerCase().split(",")));
					Collection<String> biggerSet = new ArrayList<String>(Arrays.asList(headerString.split(",")));

					biggerSet.retainAll(smallerSet);
					if (biggerSet.size() != smallerSet.size()) {
						smallerSet.removeAll(biggerSet);
						response.setMessage("Missed columns(s):  " + String.join(",", smallerSet));
						return response;
					}

					List<StudySiteCSVBean> studySiteCSVBeans = rowProcessor.getBeans();
					logger.info("List of study sites size  +++++  "+studySiteCSVBeans.size());
					String fileName = csvFile.getOriginalFilename() + CommonUtil.formatDate(new Date());
					if (studySiteCSVBeans.size() > 0) {
						
						try {
							response = processCSVStudySiteNewTrial(fileName, studySiteCSVBeans);
						} catch (Exception e) {
							logger.error("Error occurred during invocation of processCSVBeanTrials Service", e);
						}

					} else {
						response.setMessage("No records are present to import");
						response.setTotalRows(0);
					}
					return response;

				} catch (SecurityException se) {
					response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
					response.setMessage("Can not create destination folder on server");
				} catch (IOException e) {
					response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
					response.setMessage("Can not save file");
				}
				response.setHttpStatus(HttpStatus.OK);
				response.setMessage("File Uploaded >>>" + uploadedFileLocation);
			}
		}

		return response;
	}

	private FileResponseModel processCSVStudySiteNewTrial(String fileName, List<StudySiteCSVBean> studySiteCSVBeans) {
		FileResponseModel fileResponse = new FileResponseModel();
		fileResponse.setTotalRows(studySiteCSVBeans.size());
		fileResponse.setMessage("");
		try {

			List<StudySite> listStudySites = new ArrayList<StudySite>();
			List<RowDetail> lstRowDetail = new ArrayList<RowDetail>();
			List<PrincipalInvestigator> lstPIBeans = new ArrayList<PrincipalInvestigator>();

			List<String> listPI = new ArrayList<String>();
			List<StudySiteCSVBean> lstInvalidRows = new ArrayList<StudySiteCSVBean>();
			int iRowIndex = 0;
			for (int i = 0; i < studySiteCSVBeans.size(); i++) {
				StudySiteCSVBean studySiteCSVBean = studySiteCSVBeans.get(i);
				iRowIndex++;
				// Let's get only those StudySiteCSVBeans that actually have some description
				if (CommonUtil.isNullOrBlank(studySiteCSVBean.getStudySiteName())) {
					RowDetail rowDetail = new RowDetail();
					rowDetail.setRowMessage("StudySiteName is Empty");
					rowDetail.setRowNumber(iRowIndex);
					lstRowDetail.add(rowDetail);
					fileResponse.setInvalidRows(fileResponse.getInvalidRows() + 1);
					studySiteCSVBean.setNotes(rowDetail.getRowMessage());
					lstInvalidRows.add(studySiteCSVBean);
					continue;
				}
				if (CommonUtil.isNullOrBlank(studySiteCSVBean.getZip())) {
					RowDetail rowDetail = new RowDetail();
					rowDetail.setRowMessage("Zipcode is Empty");
					rowDetail.setRowNumber(iRowIndex);
					lstRowDetail.add(rowDetail);
					fileResponse.setInvalidRows(fileResponse.getInvalidRows() + 1);
					studySiteCSVBean.setNotes(rowDetail.getRowMessage());
					studySiteCSVBean.setInValid(true);
					lstInvalidRows.add(studySiteCSVBean);
					continue;
				} else {
					try {
						String zip = studySiteCSVBean.getZip();
						if (studySiteCSVBean.getZip().length() < 5)
							zip = CommonUtil.padLeftZeros(studySiteCSVBean.getZip(), 5);
						else if (studySiteCSVBean.getZip().length() > 5) {
							String[] zipArray = studySiteCSVBean.getZip().split("-");
							if (zipArray.length > 1) {
								zip = zipArray[0];
							} else {
								RowDetail rowDetail = new RowDetail();
								rowDetail.setRowMessage("Zipcode is Empty");
								rowDetail.setRowNumber(iRowIndex);
								lstRowDetail.add(rowDetail);
								fileResponse.setInvalidRows(fileResponse.getInvalidRows() + 1);
								studySiteCSVBean.setNotes(rowDetail.getRowMessage());
								studySiteCSVBean.setInValid(true);
								lstInvalidRows.add(studySiteCSVBean);
								continue;
							}
						}
						List<Place> listPlace = PostalDbFactory.getPostalDb().byPostalCode(zip);// studySiteCSVBean.getZip()
						if (null != listPlace && listPlace.size() > 0) {
							studySiteCSVBean.setLatitude(String.valueOf(listPlace.get(0).getLatitude()));
							studySiteCSVBean.setLongitude(String.valueOf(listPlace.get(0).getLongitude()));
						} else {
							RowDetail rowDetail = new RowDetail();
							rowDetail.setRowMessage("Zipcode is invalid");
							rowDetail.setRowNumber(iRowIndex);
							lstRowDetail.add(rowDetail);
							fileResponse.setInvalidRows(fileResponse.getInvalidRows() + 1);
							studySiteCSVBean.setNotes(rowDetail.getRowMessage());
							studySiteCSVBean.setInValid(true);
							lstInvalidRows.add(studySiteCSVBean);
							continue;
						}
					} catch (Exception ex) {
						logger.error("Exception", ex);
					}
				}
				if (!studySiteCSVBean.getStudySiteName().isEmpty()) {
					logger.info(studySiteCSVBean.getStudySiteName() + " - " + studySiteCSVBean.toString());
				}
				ExistReponse obj = new ExistReponse();
				StudySite studySite = UpdateByNameByZip(generateStudySite(studySiteCSVBean), obj);

				//setting radius values to study site
				if( studySiteCSVBean.getRadiusValue()!=null && studySiteCSVBean.getRadiusValue().matches("^(?:[1-9][0-9]{3}|[1-9][0-9]{2}|[1-9][0-9]|[1-9])$")) {
					studySite.setRadiusValue(Integer.parseInt(studySiteCSVBean.getRadiusValue()));
				}
				studySite.setRadiusExempt(studySiteCSVBean.isRadiusExempt());
				studySite.setPrincipalInvestigatorName(studySiteCSVBean.getInvestigatorName());
				if (studySite != null) {
					studySiteCSVBeans.get(i).setStudySiteId(studySite.getId());
					listStudySites.add(studySite);
					listPI.add(studySiteCSVBean.getInvestigatorName());
				}
				lstPIBeans.add(generatePI(studySiteCSVBean));
			}
			
			if (lstInvalidRows.size() > 0) {
				logger.info("==>Invalid Rows Count:" + lstInvalidRows.size());
				fileResponse.setErrorRows(lstInvalidRows);
			}
			fileResponse.setStatusRows(lstRowDetail);
			fileResponse.setSuccessRows(listStudySites.size());
			//update the PI table only when pi name is not there in the table.
			
			doPrincipalInvestigatorProcessing(listStudySites, studySiteCSVBeans, listPI, lstPIBeans);

			fileResponse.setHttpStatus(HttpStatus.OK);
			fileResponse.setMessage("Completed processing of studysites");
			
			List<StudySiteLightWeightDTO> siteDTOList = new ArrayList<StudySiteLightWeightDTO>();
			
			for(StudySite site: listStudySites) {
				StudySiteLightWeightDTO dto = new StudySiteLightWeightDTO();
				dto.setRadiusValue(site.getRadiusValue());
				dto.setRadiusExempt(site.isRadiusExempt());
				dto.setStudySite(site.getStudySiteName());
				dto.setStudySiteId(site.getId());
				dto.setActive(true);
				dto.setPiName(site.getPrincipalInvestigatorName());
				siteDTOList.add(dto);
			}
			
			fileResponse.setStudySiteList(siteDTOList);
			return fileResponse;

		} catch (Exception e) {
			logger.error("Exception Ocurred", e);
			fileResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			fileResponse.setMessage("Can not create destination folder on server");
		}
		return fileResponse;
	}
	
	private void doPrincipalInvestigatorProcessing(List<StudySite> listStudySites,
			List<StudySiteCSVBean> studySiteCSVBeans, List<String> lstExistingPI, List<PrincipalInvestigator> lstPIBeans) {
		// Associate existing sites with trial
		if (listStudySites.size() > 0) {
			Set<String> lstUniqueInvestigators = new HashSet<String>(lstExistingPI);
			if (null != lstUniqueInvestigators && lstUniqueInvestigators.size() > 0) {
				for (String investigatorName : lstUniqueInvestigators) {
					if (null == investigatorName || investigatorName.equals(""))
						continue;
					PrincipalInvestigator principalInvestigator = lstPIBeans.stream().filter(f -> investigatorName.equals(f.getName())).collect(Collectors.toList()).get(0);
					savePrincipalInvestigator(principalInvestigator);
				}
			}
		}
	}
	

	public void writeInvalidErrors(List<StudySiteCSVBean> lstCSVBeans, Long trialId) throws IOException {
		createFolderIfNotExists(CSVConstant.ERROR_FOLDER);
		Writer outputWriter = new FileWriter(new File("csv/error/error_" + trialId + ".csv"));
		OutputValueSwitch writerSwitch = new OutputValueSwitch("type");
		writerSwitch.addSwitchForType(StudySiteCSVBean.class);
		CsvWriterSettings settings = new CsvWriterSettings();
		settings.setRowWriterProcessor(writerSwitch);
		// Any null values will be written as ?
		settings.setNullValue("");
		settings.getFormat().setLineSeparator("\n");
		settings.setHeaderWritingEnabled(false);

		settings.setHeaders("Active Study Flag", "Region", "Standard Country Name", "Phase", "Primary Therapeutic Area",
				"Primary Indication", "Ultimate Parent Name", "Account Name", "Address Line 1", "Address Line 2",
				"Zip Code", "Current Study Site Status", "Project Site IRB Type", "City", "State", "Investigator Name",
				"Phone Number 1", "Notes");

		CsvWriter writer = new CsvWriter(outputWriter, settings);
		// Writes the headers specified in the settings
		writer.writeHeaders();
		for (StudySiteCSVBean csvBean : lstCSVBeans)
			writer.processRecord(csvBean);
		writer.close();

	}

	private PrincipalInvestigator savePrincipalInvestigator(PrincipalInvestigator principalInvestigator) {
		List<PrincipalInvestigator> lstPrincipalInvestigators = principalInvestigatorRepository
				.findByName(principalInvestigator.getName());
		if (null != lstPrincipalInvestigators && lstPrincipalInvestigators.size() > 0) {
			principalInvestigator = lstPrincipalInvestigators.get(0);
			return principalInvestigator;
		}
		principalInvestigator = principalInvestigatorRepository.save(principalInvestigator);
		return principalInvestigator;
	}

	private StudySite generateStudySite(StudySiteCSVBean studySiteCSVBean) {
		StudySite studySite = new StudySite();
		if (studySiteCSVBean != null) {
			studySite.withLatitude(Double.valueOf(studySiteCSVBean.getLatitude()));
			studySite.withLongitude(Double.valueOf(studySiteCSVBean.getLongitude()));
			studySite.setStudySiteName(studySiteCSVBean.getStudySiteName());
			studySite.withActive(true);
			studySite.withPrimaryIndication(studySiteCSVBean.getPrimaryIndication());
			studySite.withPrimaryTherapeuticArea(studySiteCSVBean.getPrimaryTherapeuticArea());
			// studySite.withProjectCode(studySiteCSVBean.getProjectCode());
			// studySite.withProtocolNumber(studySiteCSVBean.getProtocolNumber());
			studySite.withRegion(studySiteCSVBean.getRegion());
			// studySite.withSubRegion(studySiteCSVBean.getSubregion());
			// studySite.withCTMSResearchFacilityIdentifier(studySiteCSVBean.getCtmsResearchFacilityIdentifier());
			// studySite.withSiteCluster(studySiteCSVBean.getSiteCluster());
			// studySite.withStudySiteIRBId(studySiteCSVBean.getProjectSiteIrbType());
			// studySite.withStudySiteNumber(studySiteCSVBean.getStudySiteNumber());
			// studySite.withTDU(studySiteCSVBean.getTdu());
			studySite.withUltimateParentName(studySiteCSVBean.getUltimateParentName());

			// studySite.withStudySitePhaseId(studySitePhaseId)
			// studySite.withStudySiteStatusId(studySiteStatusId)
			studySite.withAddress1(studySiteCSVBean.getAddressLine1());
			studySite.withAddress2(studySiteCSVBean.getAddressLine2());
			studySite.withCity(studySiteCSVBean.getCity());
			studySite.withState(studySiteCSVBean.getState());
			studySite.withCountry(studySiteCSVBean.getCountry());
			studySite.withZip(studySiteCSVBean.getZip());
			studySite.withPhoneNumber(studySiteCSVBean.getPhoneNumber());

		}
		return studySite;
	}
	
	private PrincipalInvestigator generatePI(StudySiteCSVBean studySiteCSVBean) {
		PrincipalInvestigator principalInvestigator = new PrincipalInvestigator();
		if (studySiteCSVBean != null) {
			principalInvestigator.withName(studySiteCSVBean.getInvestigatorName());
			principalInvestigator.withNpi(studySiteCSVBean.getNpi());
			principalInvestigator.withProject(studySiteCSVBean.getProject());
			principalInvestigator.withSpecialty(studySiteCSVBean.getSpecialty());
		}
		return principalInvestigator;
	}

	@Override
	public List<StudySite> importFromCSV() {
		// TODO Auto-generated method stub
		logger.debug(PostalDbFactory.getPostalDb().byPostalCode("92780").toString());
		return null;
	}

	/*
	 * public ResponseObjectModel getAll_old(StudySiteFilterRequestModel
	 * studySiteFilterRequest) { ResponseObjectModel response = new
	 * ResponseObjectModel(); Page<StudySite> pgStudySite = null; if
	 * (studySiteFilterRequest.isActive() == studySiteFilterRequest.isDisabled()) {
	 * if (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName()) &&
	 * (studySiteFilterRequest.getStates().size() > 0 ||
	 * studySiteFilterRequest.getCities().size() > 0)) {
	 * 
	 * pgStudySite =
	 * studySiteRepository.findByStudySiteNameContainingAndStateInOrCityIn(
	 * studySiteFilterRequest.getStudySiteName(),
	 * studySiteFilterRequest.getStates(), studySiteFilterRequest.getCities(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else if
	 * (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName())) {
	 * 
	 * pgStudySite = studySiteRepository.findByStudySiteNameContaining(
	 * studySiteFilterRequest.getStudySiteName(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else if
	 * (studySiteFilterRequest.getStates().size() > 0 ||
	 * studySiteFilterRequest.getCities().size() > 0) { pgStudySite =
	 * studySiteRepository.findByStateInOrCityIn(studySiteFilterRequest.getStates(),
	 * studySiteFilterRequest.getCities(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else { pgStudySite =
	 * studySiteRepository.findAll( new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } } else if
	 * (studySiteFilterRequest.isActive()) { if
	 * (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName()) &&
	 * (studySiteFilterRequest.getStates().size() > 0 ||
	 * studySiteFilterRequest.getCities().size() > 0)) {
	 * 
	 * pgStudySite = studySiteRepository.
	 * findByStudySiteNameContainingAndActiveTrueAndStateInOrCityIn(
	 * studySiteFilterRequest.getStudySiteName(),
	 * studySiteFilterRequest.getStates(), studySiteFilterRequest.getCities(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else if
	 * (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName())) {
	 * 
	 * pgStudySite = studySiteRepository.findByStudySiteNameContainingAndActiveTrue(
	 * studySiteFilterRequest.getStudySiteName(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else if
	 * (studySiteFilterRequest.getStates().size() > 0 ||
	 * studySiteFilterRequest.getCities().size() > 0) { pgStudySite =
	 * studySiteRepository.findByActiveTrueAndStateInOrCityIn(studySiteFilterRequest
	 * .getStates(), studySiteFilterRequest.getCities(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else { pgStudySite =
	 * studySiteRepository.findByActiveTrue( new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } } else if
	 * (studySiteFilterRequest.isDisabled()) { if
	 * (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName()) &&
	 * (studySiteFilterRequest.getStates().size() > 0 ||
	 * studySiteFilterRequest.getCities().size() > 0)) {
	 * 
	 * pgStudySite = studySiteRepository.
	 * findByStudySiteNameContainingAndStateInOrCityInAndActiveFalse(
	 * studySiteFilterRequest.getStudySiteName(),
	 * studySiteFilterRequest.getStates(), studySiteFilterRequest.getCities(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else if
	 * (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName())) {
	 * 
	 * pgStudySite =
	 * studySiteRepository.findByStudySiteNameContainingAndActiveFalse(
	 * studySiteFilterRequest.getStudySiteName(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else if
	 * (studySiteFilterRequest.getStates().size() > 0 ||
	 * studySiteFilterRequest.getCities().size() > 0) { pgStudySite =
	 * studySiteRepository.findByStateInOrCityInAndActiveFalse(
	 * studySiteFilterRequest.getStates(), studySiteFilterRequest.getCities(), new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } else { pgStudySite =
	 * studySiteRepository.findByActiveFalse( new
	 * PageRequest(studySiteFilterRequest.getPage(),
	 * studySiteFilterRequest.getPageSize())); } }
	 * 
	 * if (pgStudySite.getContent().size() > 0)
	 * response.setData(generateStudySiteDtoPICo(pgStudySite.getContent(), 0L));
	 * response.setTotal(pgStudySite.getTotalElements());
	 * response.setTotalPages(pgStudySite.getTotalPages()); return response; }
	 */

	@Override
	public ResponseObjectModel getAll(StudySiteFilterRequestModel studySiteFilterRequest) {
		ResponseObjectModel response = new ResponseObjectModel();
		Page<StudySite> pgStudySite = null;
		List<Long> trialIdList = null;

		ClinicalTrialFilterRequestModel trialFilterModel = new ClinicalTrialFilterRequestModel();
		trialFilterModel.withCollaboratorList(studySiteFilterRequest.getCollaboratorList());
		trialFilterModel.withSponsorList(studySiteFilterRequest.getSponsorList());
		if (!CommonUtil.IsNullOrEmpty(studySiteFilterRequest.getCollaboratorList())
				|| !CommonUtil.IsNullOrEmpty(studySiteFilterRequest.getSponsorList())) {
			List<Long> programIdList = programRepository
					.findAll(SpringSpecifications.getProgramSpecification(trialFilterModel)).stream()
					.map(p -> p.getId()).collect(Collectors.toList());
			logger.info("Program filtered:" + programIdList);
			if (programIdList.isEmpty()) {
				programIdList.add(0L);
			}
			trialIdList = clinicalTrialRepository
					.findAll(SpringSpecifications.getClinicalTrialSpecification(trialFilterModel, programIdList, false))
					.stream().map(t -> t.getTrialId()).collect(Collectors.toList());
			logger.info("Trial filtered:" + trialIdList);
			if (trialIdList.isEmpty()) {
				trialIdList.add(0L);
			}
		}
		pgStudySite = studySiteRepository.findAll(getStudySiteSpecification(studySiteFilterRequest, trialIdList, null),
				new PageRequest(studySiteFilterRequest.getPage(), studySiteFilterRequest.getPageSize()));

		if (pgStudySite.getContent().size() > 0)
			response.setData(generateStudySiteDtoPICo(pgStudySite.getContent(), 0L));
		response.setTotal(pgStudySite.getTotalElements());
		response.setTotalPages(pgStudySite.getTotalPages());
		return response;
	}

	@Override
	public List<StudySiteMapBean> getAll() {
		List<StudySite> lstStudySite = null;
		lstStudySite = studySiteRepository.findAll();
		return lstStudySite.stream()
				.map(m -> new StudySiteMapBean(m.getId(), m.getStudySiteName(), m.getLatitude(), m.getLongitude()))
				.collect(Collectors.toList());
	}

	@Override
	public List<StudySiteMapBean> getAllActiveSitesById(Long trialId) {
		List<StudySite> lstStudySite = null;
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByIsActiveTrueAndClinicalStudySiteIdId(trialId);
		if (listClinicalTrialStudySite.size() > 0) {
			List<Long> ids = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId())
					.collect(Collectors.toList());
			lstStudySite = studySiteRepository.findByIdIn(ids);
		}
		return lstStudySite.stream()
				.map(m -> new StudySiteMapBean(m.getId(), m.getStudySiteName(), m.getLatitude(), m.getLongitude()))
				.collect(Collectors.toList());
	}

	@Override
	public ResponseObjectModel getAll(int page, int pageSize) {
		ResponseObjectModel response = new ResponseObjectModel();
		Page<StudySite> pgStudySite = null;

		pgStudySite = studySiteRepository.findAll(new PageRequest(page, pageSize));
		if (pgStudySite.getContent().size() > 0)
			response.setData(pgStudySite.getContent());
		response.setTotal(pgStudySite.getTotalElements());
		response.setTotalPages(pgStudySite.getTotalPages());
		return response;
	}

	@Override
	public ResponseObjectModel getAllStudySitesByTrailId(List<Long> trialId,
			StudySiteFilterRequestModel studySiteFilterRequest, int start, int pageSize) {
		// TODO Auto-generated method stub
		return getAllStudySitesByTrailId(trialId.get(0), studySiteFilterRequest);
	}

	private StudySite generateStudySiteFromProperty(Properties property, StudySite studySiteToBePersisted,
			boolean IsChangeStatus) {

		StudySite studySite = new StudySite();
		if (studySiteToBePersisted != null)
			studySite = studySiteToBePersisted;
		studySite.withAddress1(property.getAddress1());
		studySite.withEmailAddress(property.getEmailAddress());
		studySite.withPhoneNumber(property.getPhoneNumber());
		studySite.setStudySiteName(property.getStudySiteName());
		studySite.withStudySiteCoordinators(null);
		studySite.withStudySiteCoordinators(null);
		if (IsChangeStatus) {
			if (studySiteToBePersisted.getActive() != property.getActive()) {
				StudySiteAudit studySiteAudit = new StudySiteAudit();
				studySiteAudit.setStudySiteId(studySiteToBePersisted.getId());
				studySiteAudit.setPreviousStatus(studySiteToBePersisted.getActive());
				studySiteAudit.setChangedStatus(property.getActive());
				studySiteAudit.setUpdatedBy(studySiteToBePersisted.getUpdatedBy());
				studySiteAudit.setUpdatedOn(studySiteToBePersisted.getUpdatedOn());
				studySiteAuditRepository.save(studySiteAudit);
			}
			studySite.withActive(property.getActive());
		}
		studySite.withCity(property.getCity());
		studySite.withCountry(property.getCountry());
		// studySite.withCTMSResearchFacilityIdentifier(property.getcTMSResearchFacilityIdentifier());
		studySite.withId(property.getStudySiteId());
		// studySite.withInvestigationalProductType(property.getInvestigationalProductType());
		studySite.withPrimaryIndication(property.getPrimaryIndication());
		studySite.withPrimaryTherapeuticArea(property.getPrimaryTherapeuticArea());
		// studySite.withProjectCode(property.getProjectCode());
		// studySite.withProtocolNumber(property.getProtocolNumber());
		studySite.withRegion(property.getRegion());
		// studySite.withSiteCluster(property.getSiteCluster());
		studySite.withState(property.getState());
		studySite.withStudySiteIRBId(property.getStudySiteIRBId());
		// studySite.withStudySiteNumber(property.getStudySiteNumber());
		studySite.withStudySitePhaseId(property.getStudySiteStatusId());
		// studySite.withSubRegion(property.getSubRegion());
		studySite.withStudySiteStatusId(property.getStudySiteStatusId());
		// studySite.withTDU(property.gettDU());
		studySite.withUltimateParentName(property.getUltimateParentName());
		studySite.withZip(property.getZip());

		return studySite;
	}

	class ExistReponse {
		boolean isAlreadyExist;

		public boolean isAlreadyExist() {
			return isAlreadyExist;
		}

		public void setAlreadyExist(boolean isAlreadyExist) {
			this.isAlreadyExist = isAlreadyExist;
		}

	}

	@Override
	public List<PrincipalInvestigatorDto> getPrincipalInvestigatorsList(String principalInvestigatorName, int start,
			int page) {

		List<PrincipalInvestigator> principalInvestigators = this.principalInvestigatorRepository
				.findByNameContaining(principalInvestigatorName, new PageRequest(start, page));
		return principalInvestigators.stream()
				.map(m -> new PrincipalInvestigatorDto(m.getPrincipalInvestigatorId(), m.getName()))
				.collect(Collectors.toList());

	}

	@Override
	public List<CoordinatorDto> getCoordinatorsList(String coordinatorName, Long studySiteId, int start, int page) {

		List<Coordinator> coordinators = this.coordinatorRepository.findByNameContaining(coordinatorName,
				new PageRequest(start, page));

		List<Long> mappedCoordinatorIds = this.studySiteCoordinatorRepository
				.findByCoordinatorIdIn(
						coordinators.stream().map(c -> c.getCoordinatorId()).collect(Collectors.toList()))
				.stream().filter(ssc -> !ssc.getStudySiteId().equals(studySiteId)).map(ssc -> ssc.getCoordinatorId())
				.collect(Collectors.toList());
		return coordinators.stream().filter(c -> !mappedCoordinatorIds.contains(c.getCoordinatorId()))
				.map(m -> new CoordinatorDto(m.getCoordinatorId(), m.getName())).collect(Collectors.toList());

	}

	List<CountModel> getParticipantStudySite(Long trialId) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = CommonUtil.getHttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		ResponseEntity<ResponseObjectModel> result = restTemplate.exchange(
				participantServiceStudySiteCountURL + trialId + "", HttpMethod.GET, entity, ResponseObjectModel.class);
		ResponseObjectModel responseObject = (ResponseObjectModel) result.getBody();
		// ResponseObjectModel responseObject = restTemplate.getfor(participantUrl +
		// trialId + "",entity,
		// ResponseObjectModel.class);
		List<Object> lstObjects = (List<Object>) responseObject.getData();
		List<CountModel> lstCount = new ArrayList<CountModel>();
		for (Object obj : lstObjects) {
			logger.info(obj.toString());
			ObjectMapper m = new ObjectMapper();
			CountModel countModel = m.convertValue(obj, CountModel.class);
			logger.info(countModel.toString());
			lstCount.add(countModel);
		}
		return lstCount;
	}

	/*
	 * Get study site list based on lat lang by zipcode and miles
	 */
	private List<StudySite> getStudySiteListWithQuickGeo(Long trailId, Long zip, Float miles) {
		List<StudySite> studySiteList = new ArrayList<StudySite>();
		List<Place> placeList = PostalDbFactory.getPostalDb().byPostalCode(String.valueOf(zip));
		int milesInt = (int) (Math.round(miles));
		GeoRect geoRect = null;
		for (Place place : placeList) {
			geoRect = PostalDbFactory.getPostalDb().boundingBoxInMiles(place.getLatitude(), place.getLongitude(),
					milesInt);
			double topLeftLat = geoRect.getTopLeftLat();
			double topLeftLon = geoRect.getTopLeftLon();
			double bottomRightLat = geoRect.getBottomRightLat();
			double bottomRightLon = geoRect.getBottomRightLon();
			if (geoRect != null) {
				List<StudySite> studySiteListTemp = new ArrayList<StudySite>();
				studySiteListTemp = studySiteRepository
						.findByCinicalTrialStudySitesClinicalStudySiteIdIdAndLatitudeLessThanAndLatitudeGreaterThanAndLongitudeGreaterThanAndLongitudeLessThanAndActiveTrue(
								trailId, topLeftLat, bottomRightLat, topLeftLon, bottomRightLon);
				if (studySiteListTemp != null) {
					studySiteList.addAll(studySiteListTemp);
				}
			}
		}
		return studySiteList;
	}

	@Override
	public ResponseObjectModel getStudySitesByTrialIdAndNameContaining(int start, int pageSize, Long trialId,
			String name) {
		ResponseObjectModel model = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(start, pageSize, "StudySiteName", "asc");

		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(trialId);

		logger.info("**********" + listClinicalTrialStudySite.size());

		List<Long> ids = new ArrayList<Long>();
		for (ClinicalTrialStudySite clinicalTrialStudySite : listClinicalTrialStudySite)
			ids.add(clinicalTrialStudySite.getId().getStudySiteId());

		Page<StudySite> page = null;
		if (name == null || name.equals(""))
			page = studySiteRepository.findByIdIn(ids, pageRequest);
		else
			page = studySiteRepository.findByIdInAndStudySiteNameContaining(ids, name, pageRequest);
		model.setData(page.getContent());
		model.setTotal(page.getTotalElements());
		return model;
	}

	@Override
	public ResponseObjectModel getStudySitesByTrialIdAndNameContainingNotInCurrentSiteId(int start, int pageSize,
			Long trialId, String name, Long studySiteId) {
		ResponseObjectModel model = new ResponseObjectModel();
		PageRequest pageRequest = CommonUtil.getPageRequest(start, pageSize, "StudySiteName", "asc");
		List<Long> studySiteIds = new ArrayList<Long>();
		studySiteIds.add(studySiteId);
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteIdNotIn(trialId, studySiteIds);

		logger.info("**********" + listClinicalTrialStudySite.size());

		List<Long> ids = new ArrayList<Long>();
		for (ClinicalTrialStudySite clinicalTrialStudySite : listClinicalTrialStudySite)
			ids.add(clinicalTrialStudySite.getId().getStudySiteId());

		Page<StudySite> page = null;
		if (name == null || name.equals(""))
			page = studySiteRepository.findByIdIn(ids, pageRequest);
		else
			page = studySiteRepository.findByIdInAndStudySiteNameContaining(ids, name, pageRequest);
		model.setData(page.getContent());
		model.setTotal(page.getTotalElements());
		return model;
	}

	@Override
	public Long getCount(boolean siteStatus) {
		return studySiteRepository.count(getStudySiteSpecification(siteStatus));
	}

	@Override
	public List<StudySiteReportResponse> getStudySiteReportByTrialId(Long trialId,
			StudySiteFilterRequestModel filterModel) {

		logger.debug("Entering StudySiteService.getStudySiteReportByTrialId");
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByIsActiveTrueAndClinicalStudySiteIdId(trialId);
		ClinicalTrial trial = clinicalTrialRepository.findOne(trialId);
		Program program = null;
		if (null != trial && null != trial.getProgramId()) {
			program = programRepository.findOne(trial.getProgramId());
		}

		List<StudySiteReportResponse> responseData = new ArrayList<>();

		List<Long> studySiteIds = new ArrayList<Long>();

		if (listClinicalTrialStudySite.size() > 0) {
			studySiteIds = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId())
					.collect(Collectors.toList());

			logger.info("Filtered StudySite Ids:" + studySiteIds);

			List<StudySite> studySiteList = studySiteRepository
					.findAll(getStudySiteSpecification(filterModel, null, studySiteIds));// findByIdIn(studySiteIds);

			List<StudySiteDto> studySiteDtoList = generateStudySiteDtoPICo(studySiteList, trialId);
			if (null != studySiteDtoList && studySiteDtoList.get(0).getFeatures().size() > 0) {
				List<Features> lstFeatures = studySiteDtoList.get(0).getFeatures();
				for (int i = 0; i < lstFeatures.size(); i++) {

					StudySiteReportResponse response = new StudySiteReportResponse();
					if (null != lstFeatures.get(i).getProperties().getPrincipalInvestigators()
							&& lstFeatures.get(i).getProperties().getPrincipalInvestigators().size() > 0) {
						response.withPrincipalInvestigatorNames(
								lstFeatures.get(i).getProperties().getPrincipalInvestigators().stream()
										.map(pi -> pi.getName()).collect(Collectors.toList()));
					}
					if (null != lstFeatures.get(i).getProperties().getCoordinators()
							&& lstFeatures.get(i).getProperties().getCoordinators().size() > 0) {
						response.withCoordinator(lstFeatures.get(i).getProperties().getCoordinators().get(0).getName());
					}

					if (null != trial) {
						response.withTrialName(trial.getTrialName());
					}

					if (null != program) {
						response.withProgramName(program.getName());
					}
					response.withTrialId(trialId);
					response.withStudySiteName(lstFeatures.get(i).getProperties().getStudySiteName());
					response.withStudySiteId(lstFeatures.get(i).getProperties().getStudySiteId());
					response.withZip(lstFeatures.get(i).getProperties().getZip());
					responseData.add(response);
				}

			}
			logger.debug("Exiting StudySiteService.getStudySiteReportByTrialId with proper data");
			return responseData;
		} else {
			logger.debug("Exiting StudySiteService.getStudySiteReportByTrialId with empty list");
			return new ArrayList<StudySiteReportResponse>();
		}
	}

	@Override
	public List<StudySiteReportResponse> getStudySiteReport(StudySiteFilterRequestModel filterModel) {

		logger.debug("Entering StudySiteService.getStudySiteReport");

		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository.findAll();
		List<StudySite> studySiteList = studySiteRepository.findAll(getStudySiteSpecification(filterModel, null, null));
		List<StudySiteReportResponse> responseData = new ArrayList<>();

		if (studySiteList.size() > 0) {
			List<Long> trialIds = new ArrayList<Long>();

			trialIds = listClinicalTrialStudySite.stream().map(e -> e.getId().getId()).distinct()
					.collect(Collectors.toList());

			List<ClinicalTrial> trialList = clinicalTrialRepository.findByIdIn(trialIds);

			List<Long> programIds = trialList.stream().map(e -> e.getProgramId()).filter(id -> id != null).distinct()
					.collect(Collectors.toList());

			Supplier<Stream<Program>> programList = () -> programRepository.findByProgramIdIn(programIds);

			studySiteList.forEach(studySite -> {

				List<ClinicalTrialStudySite> trialStudySiteList = listClinicalTrialStudySite.stream()
						.filter(tSite -> (studySite.getId().equals(tSite.getId().getStudySiteId())))
						.collect(Collectors.toList());

				if (null != trialStudySiteList && trialStudySiteList.size() > 0) {
					trialStudySiteList.forEach(tss -> {
						Sponsor sponsor = null;
						if (null != filterModel.getSponsorList() && filterModel.getSponsorList().size() >= 1) {
							sponsor = sponsorRepository.findOne(filterModel.getSponsorList().get(0));
						}

						ClinicalTrial trial = trialList.stream().filter(t -> t.getTrialId() == tss.getId().getId())
								.findFirst().get();
						TherapeuticArea tArea = therapeuticAreaRepository.findOne(trial.getTherapeuticAreaId());

						List<ProgramCollaborator> pCollaborator = null;
						Program program = null;
						if (null != trial && null != trial.getProgramId()) {
							program = programList.get().filter(p -> p.getId() == trial.getProgramId()).findFirst()
									.get();
							pCollaborator = programCollaboratorRepository.findByProgramId(trial.getProgramId());
						}
						logger.info("Program:" + program);
						logger.info("pCollaborator:" + pCollaborator);

						StudySiteReportResponse response = new StudySiteReportResponse();
						response.withStudySiteId(studySite.getId()).withStudySiteName(studySite.getStudySiteName())
								.withZip(studySite.getZip());
						if (null != trial) {
							response.withProgramName(null != program ? program.getName() : "-")
									.withProgramCollaboratorName(
											null != pCollaborator
													? pCollaborator.stream().map(fc -> fc.getCollaborator().getName())
															.collect(Collectors.joining(";"))
													: "-")
									.withProgramSponsorName(null != program ? program.getSponsor().getName() : "-")
									// .withProgramSponsorName(null !=
									// sponsor?sponsor.getName():program.getSponsor().getName())
									.withProgramTherapeuticAreaName(
											null != program ? program.getTherapeuticArea().getName() : "-")
									.withTrialName(trial.getTrialName()).withTrialTherapeuticAreaName(tArea.getName());
						}
						responseData.add(response);

					});

				} else {
					StudySiteReportResponse response = new StudySiteReportResponse();
					response.withStudySiteId(studySite.getId()).withStudySiteName(studySite.getStudySiteName())
							.withZip(studySite.getZip());
					responseData.add(response);
				}

			});
			logger.info("Exiting StudySiteService.getStudySiteReport with proper data");
			logger.info("Total records" + responseData.size());
			return responseData;
		} else {
			logger.info("Exiting StudySiteService.getStudySiteReport with empty list");
			return new ArrayList<StudySiteReportResponse>();
		}
	}

	private Specification<StudySite> getStudySiteSpecification(boolean isActive) {
		return (root, query, cb) -> {
			query.distinct(true);
			return cb.and(cb.equal(root.get("active"), isActive));
		};
	}

	private Specification<StudySite> getStudySiteSpecification(StudySiteFilterRequestModel studySiteFilterRequest,
			List<Long> trialIdList, List<Long> studySiteIdList) {
		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			Root<ClinicalTrialStudySite> rootTSS = query.from(ClinicalTrialStudySite.class);

			if (null != trialIdList) {
				predicates.add(cb.isTrue(rootTSS.get("clinicalStudySiteId").get("id").in(trialIdList)));
				// use the below predicate only if we have to join StudySite and
				// ClinicalTrialStudySite
				predicates.add(cb.equal(rootTSS.get("clinicalStudySiteId").get("studySiteId"), root.get("id")));
			}

			if (null != studySiteIdList) {
				predicates.add(cb.isTrue(root.get("id").in(studySiteIdList)));
			}

			if (null != studySiteFilterRequest.getCoordinatorList()
					&& studySiteFilterRequest.getCoordinatorList().size() > 0) {
				predicates.add(cb.isTrue(root.join("studySiteCoordinators").get("coordinator").get("id")
						.in(studySiteFilterRequest.getCoordinatorList())));
			}

			if (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getPiName())) {
				/*
				 * predicates.add(cb.like(
				 * cb.lower(root.join("studySitePrincipalInvestigators").get(
				 * "principalInvestigator").get("name")), "%" +
				 * studySiteFilterRequest.getPiName().toLowerCase() + "%"));
				 */
				Root<StudySitePrincipalInvestigator> rootssPI = query.from(StudySitePrincipalInvestigator.class);
				predicates.add(cb.like(cb.lower(rootssPI.get("principalInvestigator").get("name")),
						"%" + studySiteFilterRequest.getPiName().toLowerCase() + "%"));
				// use the below predicate only if we have to join StudySite and
				// ClinicalTrialStudySite
				predicates.add(cb.equal(rootssPI.get("studySiteId"), root.get("id")));
			}

			if (!CommonUtil.isNullOrBlank(studySiteFilterRequest.getStudySiteName())) {
				predicates.add(cb.like(cb.lower(root.get("studySiteName")),
						"%" + studySiteFilterRequest.getStudySiteName().toLowerCase() + "%"));
			}

			if (!CommonUtil.IsNullOrEmpty(studySiteFilterRequest.getCities())) {
				predicates.add(cb.isTrue(root.get("city").in(studySiteFilterRequest.getCities())));
			}

			if (!CommonUtil.IsNullOrEmpty(studySiteFilterRequest.getStates())) {
				predicates.add(cb.isTrue(root.get("state").in(studySiteFilterRequest.getStates())));
			}

			if (!CommonUtil.IsNullOrEmpty(studySiteFilterRequest.getSponsorList())) {
				List<Program> programList = programRepository
						.findAll(SpringSpecifications.getProgramSpecification(new ClinicalTrialFilterRequestModel()
								.withSponsorList(studySiteFilterRequest.getSponsorList())));
				if (null != programList && programList.size() > 0) {
					List<Long> programsIdList = programList.stream().map(p -> p.getId()).collect(Collectors.toList());
					List<ClinicalTrial> trialList = clinicalTrialRepository.findAll(
							SpringSpecifications.getClinicalTrialSpecification(new ClinicalTrialFilterRequestModel()
									.withSponsorList(studySiteFilterRequest.getSponsorList()), programsIdList, false));
					List<Long> clinicalTrialIdList = trialList.stream().map(ct -> ct.getTrialId())
							.collect(Collectors.toList());
					predicates.add(cb.isTrue(rootTSS.get("clinicalStudySiteId").get("id").in(clinicalTrialIdList)));
					predicates.add(cb.equal(rootTSS.get("clinicalStudySiteId").get("studySiteId"), root.get("id")));
				}
			}

			if (!CommonUtil.IsNullOrEmpty(studySiteFilterRequest.getCollaboratorList())) {
				List<Program> programList = programRepository
						.findAll(SpringSpecifications.getProgramSpecification(new ClinicalTrialFilterRequestModel()
								.withCollaboratorList(studySiteFilterRequest.getCollaboratorList())));
				if (null != programList && programList.size() > 0) {
					List<Long> programsIdList = programList.stream().map(p -> p.getId()).collect(Collectors.toList());
					List<ClinicalTrial> trialList = clinicalTrialRepository
							.findAll(
									SpringSpecifications.getClinicalTrialSpecification(
											new ClinicalTrialFilterRequestModel()
													.withCollaboratorList(studySiteFilterRequest.getCollaboratorList()),
											programsIdList, false));
					List<Long> clinicalTrialIdList = trialList.stream().map(ct -> ct.getTrialId())
							.collect(Collectors.toList());
					predicates.add(cb.isTrue(rootTSS.get("clinicalStudySiteId").get("id").in(clinicalTrialIdList)));
					predicates.add(cb.equal(rootTSS.get("clinicalStudySiteId").get("studySiteId"), root.get("id")));
				}

			}

			// Created on date filter starts here
			if (!CommonUtil.isNullOrEmpty(studySiteFilterRequest.getFromDate())
					&& !CommonUtil.isNullOrEmpty(studySiteFilterRequest.getToDate())) {
				predicates.add(cb.between(root.get("createdOn"), studySiteFilterRequest.getFromDate(),
						studySiteFilterRequest.getToDate()));
				/*
				 * predicates.add(cb.or( cb.between(root.get("createdOn"),
				 * studySiteFilterRequest.getFromDate(), studySiteFilterRequest.getToDate()),
				 * cb.between(root.get("updatedOn"), studySiteFilterRequest.getFromDate(),
				 * studySiteFilterRequest.getToDate())));
				 */
			}
			if (!CommonUtil.isNullOrEmpty(studySiteFilterRequest.getFromDate())) {
				predicates.add(cb.greaterThanOrEqualTo(root.get("createdOn"), studySiteFilterRequest.getFromDate()));
				/*
				 * predicates .add(cb.or(cb.greaterThanOrEqualTo(root.get("createdOn"),
				 * studySiteFilterRequest.getFromDate()),
				 * cb.greaterThanOrEqualTo(root.get("updatedOn"),
				 * studySiteFilterRequest.getFromDate())));
				 */
			}

			if (!CommonUtil.isNullOrEmpty(studySiteFilterRequest.getToDate())) {
				predicates.add(cb.lessThanOrEqualTo(root.get("createdOn"), studySiteFilterRequest.getToDate()));

				/*
				 * predicates.add(cb.or(cb.lessThanOrEqualTo(root.get("createdOn"),
				 * studySiteFilterRequest.getToDate()),
				 * cb.lessThanOrEqualTo(root.get("updatedOn"),
				 * studySiteFilterRequest.getToDate())));
				 */
			}

			if (studySiteFilterRequest.isActive() && studySiteFilterRequest.isDisabled()) {
				//
			} else if (studySiteFilterRequest.isDisabled()) {
				predicates.add(cb.equal(root.get("active"), false));
			} else if (studySiteFilterRequest.isActive()) {
				predicates.add(cb.equal(root.get("active"), true));
			} else {
			}

			if (!studySiteFilterRequest.getSortType().trim().isEmpty()) {
				if(!studySiteFilterRequest.getColumnToSort().equals("studySitePrincipalInvestigatorsPrincipalInvestigatorName")) {
				Order order = getOrder(studySiteFilterRequest.getColumnToSort(), studySiteFilterRequest.getSortType(),
						cb, root);
				query.orderBy(order);
				}
			}
			query.distinct(true);
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};

	}

	private Order getOrder(String column, String sortType, CriteriaBuilder cb, Root<StudySite> studySiteRoot) {
		if ("studySitePrincipalInvestigatorsPrincipalInvestigatorName".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(
						studySiteRoot.join("studySitePrincipalInvestigators").get("principalInvestigator").get("name"));
			} else {
				return cb.desc(
						studySiteRoot.join("studySitePrincipalInvestigators").get("principalInvestigator").get("name"));

			}
		} else if ("StudySiteName".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(studySiteRoot.get("studySiteName"));
			} else {
				return cb.desc(studySiteRoot.get("studySiteName"));

			}
		} else if ("Status".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(studySiteRoot.get("active")).reverse();
			} else {
				return cb.desc(studySiteRoot.get("active")).reverse();

			}
		} else if ("State".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(studySiteRoot.get("state"));
			} else {
				return cb.desc(studySiteRoot.get("state"));

			}
		} else if ("City".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(studySiteRoot.get("city"));
			} else {
				return cb.desc(studySiteRoot.get("city"));

			}
		} else if ("PhoneNumber".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(studySiteRoot.get("phoneNumber"));
			} else {
				return cb.desc(studySiteRoot.get("phoneNumber"));

			}
		} else if ("Address1".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(studySiteRoot.get("address1"));
			} else {
				return cb.desc(studySiteRoot.get("address1"));

			}
		}
		return (cb.asc(studySiteRoot.get("createdOn")));

	}

	public List<ClinicalStudySiteSiteStatistics> countByClinicalStudySiteIdIdIn(List<Long> trialIds) {
		return clinicalStudySiteRepository.countByClinicalStudySiteIdIdIn(trialIds);
	}

	@Override
	public List<StudySiteAuditResponse> getStudySiteAuditReport(Long studySiteId) {
		List<StudySiteAudit> auditList = studySiteAuditRepository.findAll(getStudySiteAuditSpecification(studySiteId));
		List<StudySiteAuditResponse> responseList = auditList.stream().map(t -> {
			StudySiteAuditResponse response = new StudySiteAuditResponse();
			response.setNewStatus(t.getChangedStatus() ? "Active" : "InActive");
			response.setOldStatus(t.getPreviousStatus() ? "Active" : "InActive");
			response.setUpdatedBy(t.getUpdatedBy());
			response.setUpdatedOn(t.getUpdatedOn());
			UserDetails userDetails = userDetailService.getUserDetails(t.getUpdatedBy());
			response.setUpdatedUserName(userDetails != null ? userDetails.getUserName() : null);
			return response;
		}).collect(Collectors.toList());
		return responseList;
	}

	private Specification<StudySiteAudit> getStudySiteAuditSpecification(Long studySiteId) {
		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			if (null != studySiteId) {
				predicates.add(cb.equal(root.get("studySiteId"), studySiteId));
			}
			query.orderBy(cb.desc(root.get("updatedOn")));
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	@Override
	public List<State> getStudySiteStatesByTrialId(Long trialId) {
		logger.info("Entering StudySiteService.getStudySiteStatesByTrialId");
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(trialId);
		List<String> abbrevList = new ArrayList<String>();
		if (listClinicalTrialStudySite.size() > 0) {
			List<Long> idList = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId()).distinct()
					.collect(Collectors.toList());
			List<StudySite> studySiteList = studySiteRepository.findByIdIn(idList);
			if (studySiteList.size() > 0)
				abbrevList = studySiteList.stream().map(e -> e.getState()).distinct().collect(Collectors.toList());
			if (abbrevList.size() > 0)
				return stateRepository.findByAbbrevIn(abbrevList);
		}
		return new ArrayList<State>();
	}

	@Override
	public List<City> getStudySiteCitiesByTrialId(Long trialId, LocationSearch locationSearch) {
		logger.info("Entering StudySiteService.getStudySiteCitiesByTrialId");
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(trialId);
		List<String> cityNameList = new ArrayList<String>();
		if (listClinicalTrialStudySite.size() > 0) {
			List<Long> idList = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId()).distinct()
					.collect(Collectors.toList());
			List<StudySite> studySiteList = studySiteRepository.findByIdIn(idList);
			if (studySiteList.size() > 0) {
				if ((null != locationSearch.getStateAbbrev() && locationSearch.getStateAbbrev().size() > 0)
						&& (null != locationSearch.getStateName() && locationSearch.getStateName().size() > 0))
					cityNameList = studySiteList.stream()
							.filter(s -> locationSearch.getStateName().contains(s.getState())
									|| locationSearch.getStateAbbrev().contains(s.getState()))
							.map(e -> e.getCity()).distinct().collect(Collectors.toList());
				else if ((null != locationSearch.getStateName() && locationSearch.getStateName().size() > 0))
					cityNameList = studySiteList.stream()
							.filter(s -> locationSearch.getStateName().contains(s.getState())).map(e -> e.getCity())
							.distinct().collect(Collectors.toList());
				else if ((null != locationSearch.getStateAbbrev() && locationSearch.getStateAbbrev().size() > 0))
					cityNameList = studySiteList.stream()
							.filter(s -> locationSearch.getStateAbbrev().contains(s.getState())).map(e -> e.getCity())
							.distinct().collect(Collectors.toList());
				else
					cityNameList = studySiteList.stream().map(e -> e.getCity()).distinct().collect(Collectors.toList());
				if ((locationSearch.getStateName() == null
						|| (null != locationSearch.getStateName() && locationSearch.getStateName().size() <= 0))
						&& (locationSearch.getStateAbbrev() == null || (null != locationSearch.getStateAbbrev()
								&& locationSearch.getStateAbbrev().size() <= 0))) {
					locationSearch.withStateAbbrev(
							studySiteList.stream().map(e -> e.getState()).distinct().collect(Collectors.toList()));
				}
			}
			/*
			 * if (cityNameList.size() > 0 && null != locationSearch &&
			 * locationSearch.getStateName().size()>0 && null
			 * !=locationSearch.getStateAbbrev() &&
			 * locationSearch.getStateAbbrev().size()>0) return
			 * cityRepository.findByCityNameInAndStateStateNameInOrStateAbbrevIn(
			 * cityNameList,locationSearch.getStateName(),locationSearch.getStateAbbrev());
			 * else
			 */
			if (cityNameList.size() > 0 && null != locationSearch.getStateAbbrev()
					&& locationSearch.getStateAbbrev().size() > 0)
				return cityRepository.findByCityNameInAndStateAbbrevIn(cityNameList, locationSearch.getStateAbbrev());
			else if (cityNameList.size() > 0 && null != locationSearch.getStateName()
					&& locationSearch.getStateName().size() > 0)
				return cityRepository.findByCityNameInAndStateStateNameIn(cityNameList, locationSearch.getStateName());
			else
				return cityRepository.findByCityNameIn(cityNameList);
		}
		return new ArrayList<City>();
	}

	@Override
	public List<State> getStudySiteStates() {
		logger.info("Entering StudySiteService.getStudySiteStates");

		List<String> abbrevList = new ArrayList<String>();
		List<StudySite> studySiteList = studySiteRepository.findAll();
		if (studySiteList.size() > 0)
			abbrevList = studySiteList.stream().map(e -> e.getState()).distinct().collect(Collectors.toList());
		if (abbrevList.size() > 0)
			return stateRepository.findByAbbrevIn(abbrevList);
		return new ArrayList<State>();
	}

	@Override
	public List<City> getStudySiteCities() {
		logger.info("Entering StudySiteService.getStudySiteCities");

		List<String> cityNameList = new ArrayList<String>();
		List<StudySite> studySiteList = studySiteRepository.findAll();
		if (studySiteList.size() > 0)
			cityNameList = studySiteList.stream().map(e -> e.getCity()).distinct().collect(Collectors.toList());
		if (cityNameList.size() > 0)
			return cityRepository.findByCityNameIn(cityNameList);
		return new ArrayList<City>();
	}

	@Override
	public List<CoordinatorDto> getMappedCoordinators() {
		List<Coordinator> coordinators = this.coordinatorRepository.findAll();
		List<Long> mappedCoordinatorIds = this.studySiteCoordinatorRepository.findAll().stream()
				.filter(ssc -> null != ssc.getStudySiteId()).map(ssc -> ssc.getCoordinatorId())
				.collect(Collectors.toList());
		return coordinators.stream().filter(c -> mappedCoordinatorIds.contains(c.getCoordinatorId()))
				.map(m -> new CoordinatorDto(m.getCoordinatorId(), m.getName())).collect(Collectors.toList());
	}

	@Override
	public List<City> getCitiesListForStates(List<Long> statesList, String cityName, Long trialId, int start,
			int pageSize) {
		logger.info("Entering StudySiteService.getCitiesListForStates");
		logger.info("-----TrialId=>" + trialId);
		List<City> cities = null;

		if (trialId == null || trialId <= 0) {
			if (pageSize < 0 || (null == cityName || cityName.trim().isEmpty())) {
				cities = this.cityRepository.findAll().stream()
						.filter(city -> statesList.contains(city.getState().getId())).collect(Collectors.toList());
			} else {
				cities = this.cityRepository.findByCityNameContainingAndStateIdIn(cityName, statesList,
						new PageRequest(start, pageSize));
			}
			return cities;
		} else {

			List<City> trialCities = getStudySiteCitiesByTrialId(trialId, null).stream()
					.filter(city -> statesList.contains(city.getState().getId())).collect(Collectors.toList());
			return trialCities;
		}

	}

	@Override
	public ResponseObjectModel getClinicalTrialStudySitesRadius(StudySiteRadiusRequestModel studySiteFilterRequest) {
		
		List<ClinicalTrialStudySite> listClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdId(studySiteFilterRequest.getTrialId());
		
		if (listClinicalTrialStudySite.size() <= 0) {
			return new ResponseObjectModel();
		}
		
		List<Long> ids = new ArrayList<Long>();
		
		if(listClinicalTrialStudySite.size() > 0) {
			ids = listClinicalTrialStudySite.stream().map(e -> e.getId().getStudySiteId()).collect(Collectors.toList());
		}
		PageRequest pageRequest =new PageRequest(studySiteFilterRequest.getPage(), studySiteFilterRequest.getPageSize());
		Page<StudySite> pageStudySite = null;
		pageStudySite = studySiteRepository.findByIdIn(ids, pageRequest);
		List<StudySiteLightWeightDTO> siteDTOList = new ArrayList<StudySiteLightWeightDTO>();
		
		for(StudySite site: pageStudySite) {
			for(ClinicalTrialStudySite clinicalTrialSite : listClinicalTrialStudySite) {
				if(site.getId().equals(clinicalTrialSite.getId().getStudySiteId())) {
					StudySiteLightWeightDTO dto = new StudySiteLightWeightDTO();
					dto.setRadiusValue(clinicalTrialSite.getRadiusValue());
					dto.setRadiusExempt(clinicalTrialSite.getRadiusExempt());
					dto.setStudySite(site.getStudySiteName());
					dto.setStudySiteId(site.getId());
					dto.setActive(clinicalTrialSite.getIsActive());
					siteDTOList.add(dto);
				}
			}
		}
		
		ResponseObjectModel res = new ResponseObjectModel();
		res.setData(siteDTOList);
		res.setTotal(pageStudySite.getTotalElements());
		res.setTotalPages(pageStudySite.getTotalPages());
		return res;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ResponseObjectModel updateStudySiteFromTrialPage(Long studySiteId, Long trialId, Integer radiusValue, boolean radiusExempt) {
		ResponseObjectModel res = new ResponseObjectModel();
		
		List<ClinicalTrialStudySite> lstClinicalTrialStudySite = clinicalStudySiteRepository
				.findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteId(trialId,studySiteId);
		
		for (int i = 0; i < lstClinicalTrialStudySite.size(); i++) {
			lstClinicalTrialStudySite.get(i).withRadiusExempt(radiusExempt);
			if(null!= radiusValue && String.valueOf(radiusValue).matches("^(?:[1-9][0-9]{3}|[1-9][0-9]{2}|[1-9][0-9]|[1-9])$")) {
				lstClinicalTrialStudySite.get(i).withRadiusValue(radiusValue);
			} else if(null==radiusValue || radiusValue==0) {
				lstClinicalTrialStudySite.get(i).withRadiusValue(0);
			}
			lstClinicalTrialStudySite.get(i).withRadiusChanged(true);
		}
		
		clinicalStudySiteRepository.save(lstClinicalTrialStudySite);
		res.setHttpStatus(HttpStatus.OK);
		
		return res;
	}

	private List<StudySite> getSortedStudySiteByPIName(List<StudySite> list,
			StudySiteFilterRequestModel studySiteFilterRequest) {
		if (studySiteFilterRequest.getSortType() != null
				&& studySiteFilterRequest.getSortType().equalsIgnoreCase("asc")) {

			list.sort((StudySite s1,
					StudySite s2) -> (s1.getStudySitePrincipalInvestigators().stream().findFirst().get()
							.getPrincipalInvestigator().getName())
									.compareTo((s2.getStudySitePrincipalInvestigators().stream().findFirst().get()
											.getPrincipalInvestigator().getName())));
		} else {
			list.sort((StudySite s1,
					StudySite s2) -> (s2.getStudySitePrincipalInvestigators().stream().findFirst().get()
							.getPrincipalInvestigator().getName())
									.compareTo((s1.getStudySitePrincipalInvestigators().stream().findFirst().get()
											.getPrincipalInvestigator().getName())));
		}
		return list;
	}

}
