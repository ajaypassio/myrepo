package com.avigosolutions.criteriaservice.service;

import java.util.List;

import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

public interface TherapeuticAreaService {
	public ResponseObjectModel getAll(int page, int pageSize);
}
