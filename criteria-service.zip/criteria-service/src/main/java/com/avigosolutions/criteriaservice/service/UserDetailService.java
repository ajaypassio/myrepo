package com.avigosolutions.criteriaservice.service;


import com.avigosolutions.criteriaservice.dto.UserDetails;

public interface UserDetailService {
	UserDetails getUserDetails(Long userId);

}