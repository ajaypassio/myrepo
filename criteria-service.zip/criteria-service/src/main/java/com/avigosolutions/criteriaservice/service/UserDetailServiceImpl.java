package com.avigosolutions.criteriaservice.service;

import java.nio.charset.Charset;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.criteriaservice.dto.UserDetails;

@Service
public class UserDetailServiceImpl implements UserDetailService {
	@Value("${sprintt.auth.user}")
	private String springAuthUser;
	
	@Value("${sprintt.auth.password}")
	private String springAuthPassword;
	
	@Value("${sprintt.app.urlformat}")
	private String springAppUrlFormat;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
	public UserDetails getUserDetails(Long userId) {
		String urlStr = getURL(userId);
		logger.info("***** urlStr: " + urlStr);
		
		HttpHeaders headers = createHeaders(springAuthUser,springAuthPassword);
 		logger.info("HttpHeaders: " + headers.getValuesAsList("Authorization").toString());
 		logger.info("HttpHeaders: " + headers.getValuesAsList("uuid").toString());
 		ResponseEntity<UserDetails> response = null;
 		try {
 			response=restTemplate().exchange(urlStr,HttpMethod.GET , new HttpEntity<String>("parameters",headers), UserDetails.class);
 		}catch(Exception e) {
 			logger.info("Exception ",e);
 			return null;
 		}
  		return response.getBody();
	}
	
	/*private String getUniqueIdValue(Long userId){
		String uniqueId = "";
		if(headers != null && ! headers.isEmpty()){
			List<String> uniqueValue = headers.get("UUID");			
			if(!uniqueValue.isEmpty()){
				uniqueId =  uniqueValue.get(0);
			}
		}
		return uniqueId;
	}*/
	
	private String getURL(final Long uid){
		return String.format(springAppUrlFormat, uid);
	}
	private HttpHeaders createHeaders(final String username, final String password ){
	    HttpHeaders headers =  new HttpHeaders(){
			private static final long serialVersionUID = 1L;

			{
	             String auth = username + ":" + password;
	             byte[] encodedAuth =  Base64.getEncoder().encode(
	                auth.getBytes(Charset.forName("US-ASCII")) );
	             String authHeader = "Basic " + new String( encodedAuth );
	             set( "Authorization", authHeader );
	             set("UUID","11");
	          }
	       };
	       return headers;
	}

}
