package com.avigosolutions.criteriaservice.service.async;

import java.util.List;
import java.util.concurrent.Future;

import com.avigosolutions.criteriaservice.dto.StudySiteCSVBean;
import com.avigosolutions.criteriaservice.model.StudySiteImportStatus;
import com.avigosolutions.criteriaservice.response.model.FileResponseModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface StudySiteAsyncService {

	public Future<FileResponseModel> processCSVBean(String fileName,List<StudySiteCSVBean> studySiteCSVBeans, Long trialId);

	public StudySiteImportStatus getImportStatusByFileName(String fileName, Long trialId);
	
	public StudySiteImportStatus addNewStatusEntry(String orgFileName,String fileName, Long trialId) throws JsonProcessingException;

	public ResponseObjectModel getImportStatusByTrial(Long trialId, Integer start, Integer pageSize);

}
