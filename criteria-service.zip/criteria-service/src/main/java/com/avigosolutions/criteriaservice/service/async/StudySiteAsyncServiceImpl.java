package com.avigosolutions.criteriaservice.service.async;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.quickgeo.Place;
import org.quickgeo.PostalDbFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.avigosolutions.criteriaservice.constant.CSVConstant;
import com.avigosolutions.criteriaservice.constant.Constants;
import com.avigosolutions.criteriaservice.dto.StudySiteCSVBean;
import com.avigosolutions.criteriaservice.messaging.StudySiteCroPublisher;
import com.avigosolutions.criteriaservice.messaging.models.CROClinician;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.PrincipalInvestigator;
import com.avigosolutions.criteriaservice.model.StudySite;
import com.avigosolutions.criteriaservice.model.StudySiteImportStatus;
import com.avigosolutions.criteriaservice.model.StudySitePrincipalInvestigator;
import com.avigosolutions.criteriaservice.repository.ClinicalStudySiteRepository;
import com.avigosolutions.criteriaservice.repository.PrincipalInvestigatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteImportStatusRepository;
import com.avigosolutions.criteriaservice.repository.StudySitePrincipalInvestigatorRepository;
import com.avigosolutions.criteriaservice.repository.StudySiteRepository;
import com.avigosolutions.criteriaservice.response.model.FileResponseModel;
import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
import com.avigosolutions.criteriaservice.response.model.RowDetail;
import com.avigosolutions.criteriaservice.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.univocity.parsers.common.processor.OutputValueSwitch;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

@Service
@Transactional(propagation = Propagation.REQUIRED, readOnly = false, noRollbackFor = Exception.class)
public class StudySiteAsyncServiceImpl implements StudySiteAsyncService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private StudySiteRepository studySiteRepository;

	@Autowired
	private ClinicalStudySiteRepository clinicalStudySiteRepository;

	@Autowired
	private StudySitePrincipalInvestigatorRepository studySitePrincipalInvestigatorRepository;

	@Autowired
	StudySiteImportStatusRepository studySiteImportStatusRepository;

	@Autowired
	private PrincipalInvestigatorRepository principalInvestigatorRepository;
	
	@Autowired
	private StudySiteCroPublisher studySiteCroPublisher;

	/**
	 * Creates a folder to desired location if it not already exists
	 * 
	 * @param dirName
	 *            - full path to the folder
	 * @throws SecurityException
	 *             - in case you don't have permission to create the folder
	 */

	private void createFolderIfNotExists(String dirName) throws SecurityException {
		File theDir = new File(dirName);
		if (!theDir.exists()) {
			theDir.mkdir();
		}
	}

	@Async
	public Future<FileResponseModel> processCSVBean(String fileName, List<StudySiteCSVBean> studySiteCSVBeans,
			Long trialId) {
		FileResponseModel response = new FileResponseModel();
		response.setTotalRows(studySiteCSVBeans.size());
		response.setMessage("");
		try {

			response.setTotalRows(studySiteCSVBeans.size());
			List<StudySite> lstStudySites = new ArrayList<StudySite>();
			List<RowDetail> lstRowDetail = new ArrayList<RowDetail>();
			List<StudySite> lstNewStudySites = new ArrayList<StudySite>();

			List<StudySite> lstExistingStudySites = new ArrayList<StudySite>();
			List<String> lstExistingPI = new ArrayList<String>();
			List<PrincipalInvestigator> lstPIBeans = new ArrayList<PrincipalInvestigator>();
			List<StudySiteCSVBean> lstNewStudySiteCSVBeans = new ArrayList<StudySiteCSVBean>();
			List<StudySiteCSVBean> lstInvalidRows = new ArrayList<StudySiteCSVBean>();
			int iRowIndex = 0;
			int newlyAddedRowCount = 0;
			int existingRowCount = 0;
			for (int i = 0; i < studySiteCSVBeans.size(); i++) {
				StudySiteCSVBean studySiteCSVBean = studySiteCSVBeans.get(i);
				iRowIndex++;
				// Let's get only those StudySiteCSVBeans that actually have some description
				if (CommonUtil.isNullOrBlank(studySiteCSVBean.getStudySiteName())) {
					RowDetail rowDetail = new RowDetail();
					rowDetail.setRowMessage("StudySiteName is Empty");
					rowDetail.setRowNumber(iRowIndex);
					lstRowDetail.add(rowDetail);
					response.setInvalidRows(response.getInvalidRows() + 1);
					studySiteCSVBean.setNotes(rowDetail.getRowMessage());
					lstInvalidRows.add(studySiteCSVBean);
					continue;
				}
				if (CommonUtil.isNullOrBlank(studySiteCSVBean.getZip())) {
					RowDetail rowDetail = new RowDetail();
					rowDetail.setRowMessage("Zipcode is Empty");
					rowDetail.setRowNumber(iRowIndex);
					lstRowDetail.add(rowDetail);
					response.setInvalidRows(response.getInvalidRows() + 1);
					studySiteCSVBean.setNotes(rowDetail.getRowMessage());
					studySiteCSVBean.setInValid(true);
					lstInvalidRows.add(studySiteCSVBean);
					continue;
				} else {
					try {
						String zip = studySiteCSVBean.getZip();
						if (studySiteCSVBean.getZip().length() < 5)
							zip = CommonUtil.padLeftZeros(studySiteCSVBean.getZip(), 5);
						else if (studySiteCSVBean.getZip().length() > 5) {
							String[] zipArray = studySiteCSVBean.getZip().split("-");
							if (zipArray.length > 1) {
								zip = zipArray[0];
							} else {
								RowDetail rowDetail = new RowDetail();
								rowDetail.setRowMessage("Zipcode is Empty");
								rowDetail.setRowNumber(iRowIndex);
								lstRowDetail.add(rowDetail);
								response.setInvalidRows(response.getInvalidRows() + 1);
								studySiteCSVBean.setNotes(rowDetail.getRowMessage());
								studySiteCSVBean.setInValid(true);
								lstInvalidRows.add(studySiteCSVBean);
								continue;
							}
						}
						List<Place> listPlace = PostalDbFactory.getPostalDb().byPostalCode(zip);// studySiteCSVBean.getZip()
						if (null != listPlace && listPlace.size() > 0) {
							studySiteCSVBean.setLatitude(String.valueOf(listPlace.get(0).getLatitude()));
							studySiteCSVBean.setLongitude(String.valueOf(listPlace.get(0).getLongitude()));
						} else {
							RowDetail rowDetail = new RowDetail();
							rowDetail.setRowMessage("Zipcode is invalid");
							rowDetail.setRowNumber(iRowIndex);
							lstRowDetail.add(rowDetail);
							response.setInvalidRows(response.getInvalidRows() + 1);
							studySiteCSVBean.setNotes(rowDetail.getRowMessage());
							studySiteCSVBean.setInValid(true);
							lstInvalidRows.add(studySiteCSVBean);
							continue;
						}
					} catch (Exception ex) {
						logger.error("Exception", ex);
					}
				}
				if (!studySiteCSVBean.getStudySiteName().isEmpty()) {
					logger.info(studySiteCSVBean.getStudySiteName() + " - " + studySiteCSVBean.toString());
				}
				ExistReponse obj = new ExistReponse();
				StudySite studySite = UpdateByNameByZip(generateStudySite(studySiteCSVBean), obj);
				List<ClinicalTrialStudySite> lstClinicalTrialStudySite = clinicalStudySiteRepository
						.findByClinicalStudySiteIdIdAndClinicalStudySiteIdStudySiteId(trialId, studySite.getId());
				
				if(obj.isAlreadyExist() && studySiteCSVBean.getRadiusValue()!=null &&
						studySiteCSVBean.getRadiusValue().matches("^(?:[1-9][0-9]{3}|[1-9][0-9]{2}|[1-9][0-9]|[1-9])$") && 
					 null != lstClinicalTrialStudySite && lstClinicalTrialStudySite.size() > 0 &&
						(!(studySiteCSVBean.getRadiusValue().equalsIgnoreCase(String.valueOf(lstClinicalTrialStudySite.get(0).getRadiusValue()))) ||
								(studySiteCSVBean.isRadiusExempt() != lstClinicalTrialStudySite.get(0).getRadiusExempt()))) {
					studySite.setRadiusChanged(true);
				}
				if( null != lstClinicalTrialStudySite && lstClinicalTrialStudySite.size() > 0 && lstClinicalTrialStudySite.get(0).getRadiusChanged()) {
					studySite.setRadiusChanged(lstClinicalTrialStudySite.get(0).getRadiusChanged());
				}
				if(!obj.isAlreadyExist()) {
					studySite.setRadiusChanged(true);
				}
				if( studySiteCSVBean.getRadiusValue()!=null && studySiteCSVBean.getRadiusValue().matches("^(?:[1-9][0-9]{3}|[1-9][0-9]{2}|[1-9][0-9]|[1-9])$")) {
					studySite.setRadiusValue(Integer.parseInt(studySiteCSVBean.getRadiusValue()));
				}
				studySite.setRadiusExempt(studySiteCSVBean.isRadiusExempt());
				
				if (studySite != null) {
					studySiteCSVBeans.get(i).setStudySiteId(studySite.getId());
					lstStudySites.add(studySite);
					if (!obj.isAlreadyExist()) {
						lstNewStudySites.add(studySite);
						newlyAddedRowCount++;
						lstNewStudySiteCSVBeans.add(studySiteCSVBean);
					} else {
						lstExistingPI.add(studySiteCSVBean.getInvestigatorName());
						lstExistingStudySites.add(studySite);
						existingRowCount++;
					}
				}
				lstPIBeans.add(generatePI(studySiteCSVBean));
			}
			updateStatusEntryWithStatus(fileName, trialId, Constants.IMPORT_STATUS_INPROGRESS);
			if (lstInvalidRows.size() > 0) {
				logger.info("==>Invalid Rows Count:" + lstInvalidRows.size());
				response.setErrorRows(lstInvalidRows);
			}
			response.setStatusRows(lstRowDetail);
			// studySiteRepository.save(lstStudySites);
			response.setSuccessRows(lstStudySites.size());
			response.setExistingRowCount(existingRowCount);
			response.setNewlyAddedRowCount(newlyAddedRowCount);

			if (null != lstNewStudySites && lstNewStudySites.size() > 0) {
				List<ClinicalTrialStudySite> lstClinicalTrialStudySiteDb = new ArrayList<ClinicalTrialStudySite>();
				List<ClinicalTrialStudySite> lstClinicalTrialStudySite = lstNewStudySites.stream()
						.map(s -> new ClinicalTrialStudySite(trialId, s.getId(), true,s.getRadiusValue(),s.isRadiusExempt(),s.isRadiusChanged())).collect(Collectors.toList());
				if (lstClinicalTrialStudySite.size() > 0) {
					for (int i = 0; i < lstClinicalTrialStudySite.size(); i++) {
						ClinicalTrialStudySite clinicalTrialStudySite = lstClinicalTrialStudySite.get(i);
						lstClinicalTrialStudySiteDb.add(new ClinicalTrialStudySite(trialId,clinicalTrialStudySite.getId().getStudySiteId(),true,
								clinicalTrialStudySite.getRadiusValue(),clinicalTrialStudySite.getRadiusExempt(), clinicalTrialStudySite.getRadiusChanged()));
					}
					clinicalStudySiteRepository.save(lstClinicalTrialStudySiteDb);
				}
			}
			doPrincipalInvestigatorProcessing(lstExistingStudySites, studySiteCSVBeans, lstExistingPI,
					lstNewStudySiteCSVBeans, lstPIBeans, trialId);

			updateStatusEntry(fileName, trialId, response);
			return new AsyncResult<FileResponseModel>(response);

		} catch (Exception e) {
			updateStatusEntry(fileName, trialId, null);
			logger.error("Exception Ocurred", e);
			response.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			response.setMessage("Can not create destination folder on server");
		}
		response.setHttpStatus(HttpStatus.OK);

		return new AsyncResult<FileResponseModel>(response);
	}

	public StudySiteImportStatus getImportStatusByFileName(String fileName, Long trialId) {

		return studySiteImportStatusRepository.findByFileNameEqualsAndTrialId(fileName, trialId);

	}

	@Override
	public ResponseObjectModel getImportStatusByTrial(Long trialId, Integer start, Integer pageSize) {
		ResponseObjectModel responseObject = new ResponseObjectModel();
		Page<StudySiteImportStatus> importStatus = studySiteImportStatusRepository.findByTrialId(trialId,
				new PageRequest(start, pageSize));

		if (null == importStatus.getContent() || importStatus.getContent().size() <= 0) {
			responseObject.setData(new ArrayList<>());
		}
		responseObject.setData(importStatus.getContent());
		responseObject.setTotal(importStatus.getTotalElements());
		responseObject.setTotalPages(importStatus.getTotalPages());
		return responseObject;
	}

	private void doPrincipalInvestigatorProcessing(List<StudySite> lstExistingStudySites,
			List<StudySiteCSVBean> studySiteCSVBeans, List<String> lstExistingPI,
			List<StudySiteCSVBean> lstNewStudySiteCSVBeans, List<PrincipalInvestigator> lstPIBeans, Long trialId) {
		// Associate existing sites with trial
		if (lstExistingStudySites.size() > 0) {
			List<ClinicalTrialStudySite> lstClinicalTrialStudySite = null;
			List<ClinicalTrialStudySite> lstClinicalTrialStudySiteDb = new ArrayList<ClinicalTrialStudySite>();
			try {
				lstClinicalTrialStudySite = lstExistingStudySites.stream()
						.map(s -> new ClinicalTrialStudySite(trialId, s.getId(), true,s.getRadiusValue(),s.isRadiusExempt(),s.isRadiusChanged())).collect(Collectors.toList());
				if (lstClinicalTrialStudySite.size() > 0) {
					for (int i = 0; i < lstClinicalTrialStudySite.size(); i++) {
						ClinicalTrialStudySite clinicalTrialStudySite = lstClinicalTrialStudySite.get(i);
						lstClinicalTrialStudySiteDb.add(new ClinicalTrialStudySite(trialId,
								clinicalTrialStudySite.getId().getStudySiteId(), true,
								clinicalTrialStudySite.getRadiusValue(),clinicalTrialStudySite.getRadiusExempt(),clinicalTrialStudySite.getRadiusChanged()));
					}
					clinicalStudySiteRepository.save(lstClinicalTrialStudySiteDb);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				logger.debug(ex.getMessage());
			}
			Set<String> lstUniqueInvestigators = new HashSet<String>(lstExistingPI);
			if (null != lstUniqueInvestigators && lstUniqueInvestigators.size() > 0) {
				List<PrincipalInvestigator> lstPIs = new ArrayList<PrincipalInvestigator>();
				for (String investigatorName : lstUniqueInvestigators) {
					if (null == investigatorName || investigatorName.equals(""))
						continue;
					PrincipalInvestigator principalInvestigator = lstPIBeans.stream().filter(f -> investigatorName.equals(f.getName())).collect(Collectors.toList()).get(0);
					principalInvestigator = savePrincipalInvestigator(principalInvestigator);
					Long id = principalInvestigator.getPrincipalInvestigatorId();
					List<StudySitePrincipalInvestigator> lstStudySitePIs = new ArrayList<StudySitePrincipalInvestigator>();
					List<StudySiteCSVBean> lststudySiteCSVBeans = studySiteCSVBeans.stream()
							.filter(f -> investigatorName.equals(f.getInvestigatorName())).collect(Collectors.toList());

					if (null != lststudySiteCSVBeans && lststudySiteCSVBeans.size() > 0) {

						lststudySiteCSVBeans.forEach(f -> lstStudySitePIs
								.add(new StudySitePrincipalInvestigator(id, f.getStudySiteId(), trialId)));
						if (lstStudySitePIs.size() > 0) {
							for (StudySitePrincipalInvestigator studyPI : lstStudySitePIs) {
								if(studyPI.getStudySiteId()!=null) {
									List<StudySitePrincipalInvestigator> lstStudyPIs = studySitePrincipalInvestigatorRepository
											.findByStudySiteIdAndTrialIdAndPrincipalInvestigatorId(studyPI.getStudySiteId(),
													studyPI.getTrialId(), studyPI.getPrincipalInvestigatorId());
									if (null == lstStudyPIs || (null != lstStudyPIs && lstStudyPIs.size() <= 0)) {
										studySitePrincipalInvestigatorRepository.save(studyPI);
									}
								}
							}
						}
					}
					lstPIs.add(principalInvestigator);
				}

			}
		}
		// Get list of investigators
		List<String> lstIvestigators = lstNewStudySiteCSVBeans.stream().map(s -> s.getInvestigatorName())
				.collect(Collectors.toList());
		Set<String> lstUniqueInvestigators = new HashSet<String>(lstIvestigators);
		if (null != lstUniqueInvestigators && lstUniqueInvestigators.size() > 0) {
			List<PrincipalInvestigator> lstPIs = new ArrayList<PrincipalInvestigator>();
			for (String investigatorName : lstUniqueInvestigators) {
				if (null == investigatorName || investigatorName.equals(""))
					continue;
				PrincipalInvestigator principalInvestigator = lstPIBeans.stream().filter(f -> investigatorName.equals(f.getName())).collect(Collectors.toList()).get(0);
				principalInvestigator = savePrincipalInvestigator(principalInvestigator);
				Long id = principalInvestigator.getPrincipalInvestigatorId();
				List<StudySitePrincipalInvestigator> lstStudySitePIs = new ArrayList<StudySitePrincipalInvestigator>();
				List<StudySiteCSVBean> lststudySiteCSVBeans = studySiteCSVBeans.stream()
						.filter(f -> investigatorName.equals(f.getInvestigatorName())).collect(Collectors.toList());

				if (null != lststudySiteCSVBeans && lststudySiteCSVBeans.size() > 0) {

					lststudySiteCSVBeans.forEach(f -> lstStudySitePIs
							.add(new StudySitePrincipalInvestigator(id, f.getStudySiteId(), trialId)));
					if (lstStudySitePIs.size() > 0) {
                        for (StudySitePrincipalInvestigator studyPI : lstStudySitePIs) {
                               if(studyPI.getStudySiteId()!=null) {
                                      List<StudySitePrincipalInvestigator> lstStudyPIs = studySitePrincipalInvestigatorRepository
                                                    .findByStudySiteIdAndTrialIdAndPrincipalInvestigatorId(studyPI.getStudySiteId(),
                                                                 studyPI.getTrialId(), studyPI.getPrincipalInvestigatorId());
                                      if (null == lstStudyPIs || (null != lstStudyPIs && lstStudyPIs.size() <= 0)) {
                                             studySitePrincipalInvestigatorRepository.save(studyPI);
                                      }
                               }
                        }
					}
				}
				lstPIs.add(principalInvestigator);
			}

		}
		doProcessingCROClinicianData(studySiteCSVBeans, trialId);
	}
	
	private void doProcessingCROClinicianData(List<StudySiteCSVBean> studySiteCSVBeans, Long trialId) {
		List<Long> listStudySiteIds = studySiteCSVBeans.stream().map(s -> s.getStudySiteId())
				.collect(Collectors.toList());
		if(null != listStudySiteIds && listStudySiteIds.size() > 0) {
			List<CROClinician> listCROClinicians = generateCROClinicianList(studySiteRepository.findByStudySitesIn(listStudySiteIds, trialId), trialId);
			studySiteCroPublisher.publishStudySiteClinicianDetails(listCROClinicians);	
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	private StudySite UpdateByNameByZip(StudySite studySite, ExistReponse AlreadyExist) {
		if (studySite != null) {
			List<StudySite> existingSites = studySiteRepository.findByStudySiteNameAndZip(studySite.getStudySiteName(),
					studySite.getZip());
			if (null != existingSites && existingSites.size() > 0) {
				studySite.withId(existingSites.get(0).getId());
				studySite = studySiteRepository.save(studySite);
				AlreadyExist.setAlreadyExist(true);
				return studySite;
			}
		}
		logger.info("*************" + studySite.getId());
		StudySite savedSite = studySiteRepository.save(studySite);
		return savedSite;
	}

	public void writeInvalidErrors(List<StudySiteCSVBean> lstCSVBeans, Long trialId) throws IOException {
		createFolderIfNotExists(CSVConstant.ERROR_FOLDER);
		Writer outputWriter = new FileWriter(new File("csv/error/error_" + trialId + ".csv"));
		OutputValueSwitch writerSwitch = new OutputValueSwitch("type");
		writerSwitch.addSwitchForType(StudySiteCSVBean.class);
		CsvWriterSettings settings = new CsvWriterSettings();
		settings.setRowWriterProcessor(writerSwitch);
		// Any null values will be written as ?
		settings.setNullValue("");
		settings.getFormat().setLineSeparator("\n");
		settings.setHeaderWritingEnabled(false);

		settings.setHeaders("Active Study Flag", "Region", "Standard Country Name", "Phase", "Primary Therapeutic Area",
				"Primary Indication", "Ultimate Parent Name", "Account Name", "Address Line 1", "Address Line 2",
				"Zip Code", "Current Study Site Status", "Project Site IRB Type", "City", "State", "Investigator Name",
				"Phone Number 1", "Notes");

		CsvWriter writer = new CsvWriter(outputWriter, settings);
		// Writes the headers specified in the settings
		writer.writeHeaders();
		for (StudySiteCSVBean csvBean : lstCSVBeans)
			writer.processRecord(csvBean);
		writer.close();

	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	private PrincipalInvestigator savePrincipalInvestigator(PrincipalInvestigator principalInvestigator) {
		List<PrincipalInvestigator> lstPrincipalInvestigators = principalInvestigatorRepository
				.findByName(principalInvestigator.getName());
		
		if (null != lstPrincipalInvestigators && lstPrincipalInvestigators.size() > 0) {
			principalInvestigator.withPrincipalInvestigatorId(lstPrincipalInvestigators.get(0).getPrincipalInvestigatorId());
			principalInvestigator = principalInvestigatorRepository.save(principalInvestigator);
			return principalInvestigator;
		}
		
		principalInvestigator = principalInvestigatorRepository.save(principalInvestigator);
		return principalInvestigator;
	}

	private StudySite generateStudySite(StudySiteCSVBean studySiteCSVBean) {
		StudySite studySite = new StudySite();
		if (studySiteCSVBean != null) {
			studySite.withLatitude(Double.valueOf(studySiteCSVBean.getLatitude()));
			studySite.withLongitude(Double.valueOf(studySiteCSVBean.getLongitude()));
			studySite.setStudySiteName(studySiteCSVBean.getStudySiteName());
			studySite.withActive(true);
			studySite.withPrimaryIndication(studySiteCSVBean.getPrimaryIndication());
			studySite.withPrimaryTherapeuticArea(studySiteCSVBean.getPrimaryTherapeuticArea());
			// studySite.withProjectCode(studySiteCSVBean.getProjectCode());
			// studySite.withProtocolNumber(studySiteCSVBean.getProtocolNumber());
			studySite.withRegion(studySiteCSVBean.getRegion());
			// studySite.withSubRegion(studySiteCSVBean.getSubregion());
			// studySite.withCTMSResearchFacilityIdentifier(studySiteCSVBean.getCtmsResearchFacilityIdentifier());
			// studySite.withSiteCluster(studySiteCSVBean.getSiteCluster());
			// studySite.withStudySiteIRBId(studySiteCSVBean.getProjectSiteIrbType());
			// studySite.withStudySiteNumber(studySiteCSVBean.getStudySiteNumber());
			// studySite.withTDU(studySiteCSVBean.getTdu());
			studySite.withUltimateParentName(studySiteCSVBean.getUltimateParentName());

			// studySite.withStudySitePhaseId(studySitePhaseId)
			// studySite.withStudySiteStatusId(studySiteStatusId)
			studySite.withAddress1(studySiteCSVBean.getAddressLine1());
			studySite.withAddress2(studySiteCSVBean.getAddressLine2());
			studySite.withCity(studySiteCSVBean.getCity());
			studySite.withState(studySiteCSVBean.getState());
			studySite.withCountry(studySiteCSVBean.getCountry());
			studySite.withZip(studySiteCSVBean.getZip());
			studySite.withPhoneNumber(studySiteCSVBean.getPhoneNumber());
		}
		return studySite;
	}
	
	private PrincipalInvestigator generatePI(StudySiteCSVBean studySiteCSVBean) {
		PrincipalInvestigator principalInvestigator = new PrincipalInvestigator();
		if (studySiteCSVBean != null) {
			principalInvestigator.withName(studySiteCSVBean.getInvestigatorName());
			principalInvestigator.withNpi(studySiteCSVBean.getNpi());
			principalInvestigator.withProject(studySiteCSVBean.getProject());
			principalInvestigator.withSpecialty(studySiteCSVBean.getSpecialty());
		}
		return principalInvestigator;
	}
	
	private List<CROClinician> generateCROClinicianList(List<Object[]> objClinicianList, Long trialId) {
		List<CROClinician> croClinicianList = new ArrayList<CROClinician>();
		
		objClinicianList.stream().forEach((clinician) -> {
			CROClinician croClinician = new CROClinician();
			croClinician.setSource((String) clinician[0]);
			croClinician.setNpi((String) clinician[1]);
			croClinician.setInvestigatorId((BigInteger) clinician[2]);
			String name = (String) clinician[3];
			if(null != name) {
				String[] splitName = name.split(" ");
				if(splitName.length > 0)
					croClinician.setFirstName(splitName[0]);
				if(splitName.length > 1)
					croClinician.setLastName(splitName[1]);
			}
			croClinician.setSiteName((String) clinician[4]);
			croClinician.setAddress1((String) clinician[5]);
			croClinician.setAddress2((String) clinician[6]);
			croClinician.setCity((String) clinician[7]);
			croClinician.setState((String) clinician[8]);
			croClinician.setZip((String) clinician[9]);
			croClinician.setSpecialty((String) clinician[10]);
			croClinician.setProject((String) clinician[11]);
			if(!StringUtils.isEmpty((String)clinician[12]))
			croClinician.setPhoneNumber(Arrays.asList((String) clinician[12]));
			croClinician.setEmail((String) clinician[13]);
			croClinician.setTrialId(trialId);
			
			croClinicianList.add(croClinician);
		});
		return croClinicianList;
	}

	public List<StudySite> importFromCSV() {
		// TODO Auto-generated method stub
		logger.debug(PostalDbFactory.getPostalDb().byPostalCode("92780").toString());
		return null;
	}

	public StudySiteImportStatus addNewStatusEntry(String orgFileName,String fileName, Long trialId) {
		logger.info("addNewStatusEntry==>");
		StudySiteImportStatus statusModel = studySiteImportStatusRepository.findByFileNameEqualsAndTrialId(fileName,
				trialId);

		if (null == statusModel) {
			statusModel = new StudySiteImportStatus().withCreatedBy(1L).withFileName(fileName).withOriginalFileName(orgFileName)
					.withImportStatus(Constants.IMPORT_STATUS_NEW).withCreatedOn(new Date()).withTrialId(trialId);
		} else {
			statusModel.withImportStatus(Constants.IMPORT_STATUS_NEW).withImportStatusDataJson(null).withOriginalFileName(orgFileName)
					.withCreatedOn(new Date());
		}

		return studySiteImportStatusRepository.save(statusModel);
	}

	private void updateStatusEntryWithStatus(String fileName, Long trialId, String importStatus) {

		logger.info("updateStatusEntryWithStatus==>");
		StudySiteImportStatus statusModel = studySiteImportStatusRepository.findByFileNameEqualsAndTrialId(fileName,
				trialId);

		if (null == statusModel) {
			statusModel = new StudySiteImportStatus().withCreatedBy(1L).withFileName(fileName)
					.withImportStatus(Constants.IMPORT_STATUS_NEW).withCreatedOn(new Date()).withTrialId(trialId);
		} else {
			statusModel.withImportStatus(importStatus);
		}

		studySiteImportStatusRepository.save(statusModel);
	}

	private void updateStatusEntry(String fileName, Long trialId, FileResponseModel fileResponseModel) {

		StudySiteImportStatus statusModel = studySiteImportStatusRepository.findByFileNameEqualsAndTrialId(fileName,
				trialId);

		if (null != statusModel) {

			ObjectMapper mapper = new ObjectMapper();
			String importStatusDataJson = null;
			String importStatus = statusModel.getImportStatus();
			if (null != fileResponseModel) {
				try {
					importStatusDataJson = mapper.writeValueAsString(fileResponseModel);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.info("JSON Conversion failed");
					logger.error("JSON Conversion failed due to exception", e);
				}

				if ((fileResponseModel.getInvalidRows() > 0
						|| (null != fileResponseModel.getErrorRows() && !fileResponseModel.getErrorRows().isEmpty()))
						&& fileResponseModel.getSuccessRows() > 0) {
					importStatus = Constants.IMPORT_STATUS_PARTIAL_SUCCESS;
				} else if ((fileResponseModel.getInvalidRows() > 0
						|| (null != fileResponseModel.getErrorRows() && !fileResponseModel.getErrorRows().isEmpty()))
						&& fileResponseModel.getSuccessRows() <= 0) {
					importStatus = Constants.IMPORT_STATUS_FAILED;
				} else if ((fileResponseModel.getInvalidRows() <= 0
						|| (null == fileResponseModel.getErrorRows() || fileResponseModel.getErrorRows().isEmpty()))
						&& fileResponseModel.getSuccessRows() > 0) {
					importStatus = Constants.IMPORT_STATUS_SUCCESS;
				}

			} else {
				importStatus = Constants.IMPORT_STATUS_FAILED;
			}

			statusModel.withImportStatus(importStatus).withImportStatusDataJson(importStatusDataJson);
			logger.info("Adding status===>" + statusModel);
			studySiteImportStatusRepository.save(statusModel);
		}

	}

	class ExistReponse {
		boolean isAlreadyExist;

		public boolean isAlreadyExist() {
			return isAlreadyExist;
		}

		public void setAlreadyExist(boolean isAlreadyExist) {
			this.isAlreadyExist = isAlreadyExist;
		}
	}

}