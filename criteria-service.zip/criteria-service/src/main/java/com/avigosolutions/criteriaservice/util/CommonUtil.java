package com.avigosolutions.criteriaservice.util;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.avigosolutions.criteriaservice.constant.Constants;


@Component
public class CommonUtil {
	
	static String sprinttUuid;
	
	static String sprinttUuidPassword;
	
	@Value("${sprintt.uuid}")
	public void setSprintUuid(String sprintUuid) {
		this.sprinttUuid = sprintUuid;
	}
	
	@Value("${sprintt.uuid.password}")
	public void setSprintUuidPassword(String sprinttUuidPassword) {
		this.sprinttUuidPassword = sprinttUuidPassword;
	}
	
	
	

	public static String formatDate(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String strDate = formatter.format(date);
		return strDate;
	}

	public static boolean isNull(String str) {
		return str == null ? true : false;
	}

	public static <T> boolean IsNullOrEmpty(Collection<T> list) {
		return list == null || list.isEmpty();
	}

	public static boolean isNullOrBlank(String param) {
		if (isNull(param) || param.trim().length() == 0) {
			return true;
		}
		return false;
	}

	public static boolean isNullOrSizeZero(List param) {
		if (param == null || param.size() == 0) {
			return true;
		}
		return false;
	}

	public static boolean isNullOrEmpty(Date date) {
		if (null == date || date.toString().trim().isEmpty()) {
			return true;
		}
		return false;
	}

	public static String padLeftZeros(String str, int n) {
		return String.format("%1$" + n + "s", str).replace(' ', '0');
	}

	/*
	 * Function to generate PageRequest object based on the filter params
	 */
	public static PageRequest getPageRequest(int page, int size, String columnToSort, String sortType) {
		PageRequest pageRequest = new PageRequest(page, size);
		// Sorting will work only if the user passes the column name to sort with a
		// sorting order
		if (null != sortType && !sortType.equals("") && null != columnToSort && !columnToSort.equals("")) {
			if (sortType.equalsIgnoreCase(Constants.ASCENDING_ORDER)) {
				pageRequest = new PageRequest(page, size, Sort.Direction.ASC, columnToSort);
			} else if (sortType.equalsIgnoreCase(Constants.DESCENDING_ORDER)) {
				pageRequest = new PageRequest(page, size, Sort.Direction.DESC, columnToSort);
			}
		}
		return pageRequest;
	}

	public static PageRequest getPageRequest(int page, int size) {
		PageRequest pageRequest = new PageRequest(page, size);
		return pageRequest;
	}

	/**
	 * Adding sprinttUuid and sprinttUuidPassword to app.properties file
	 * @return HttpHeaders
	 */
	public static  HttpHeaders getHttpHeaders() {
		HttpHeaders headers = new HttpHeaders() {
			private static final long serialVersionUID = 1L;
			{
				String authHeader = "Basic " + sprinttUuidPassword;
				set("Authorization", authHeader);
				set("UUID",sprinttUuid);
			}
		};
		return headers;
	}
	
	public static Integer getCriteriaId(Long maxValue){
		Integer i;
		if(maxValue!=null){	
			i =  maxValue.intValue()+1;
		}else{
			//num.add(0);
			i=1;
		}
		return i;
	}
	
	
}
