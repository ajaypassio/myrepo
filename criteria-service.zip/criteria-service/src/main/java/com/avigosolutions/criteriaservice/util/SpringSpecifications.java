package com.avigosolutions.criteriaservice.util;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.avigosolutions.criteriaservice.model.ClinicalTrial;
import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
import com.avigosolutions.criteriaservice.model.Program;
import com.avigosolutions.criteriaservice.model.ProgramCollaborator;
import com.avigosolutions.criteriaservice.model.StudySiteCoordinator;
import com.avigosolutions.criteriaservice.model.TherapeuticArea;
import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;

public class SpringSpecifications {

	public static Specification<Program> getProgramSpecification(ClinicalTrialFilterRequestModel filterModel) {

		return (root, query, cb) -> {
			List<Long> collaboratorList = filterModel.getCollaboratorList();
			List<Long> sponsorList = filterModel.getSponsorList();
			List<Long> therapeuticAreaList = filterModel.getTherapeuticAreaList();
			Root<ProgramCollaborator> rootPC = query.from(ProgramCollaborator.class);

			List<Predicate> predicates = new ArrayList<>();

			predicates.add(cb.isFalse(root.get("deleted")));// to get the record with deleted as false
			if (!CommonUtil.IsNullOrEmpty(filterModel.getProgramIdList())) {
				predicates.add(cb.isTrue(root.get("programId").in(filterModel.getProgramIdList())));
			}

			if (!CommonUtil.IsNullOrEmpty(collaboratorList)) {
				predicates.add(cb.isTrue(rootPC.get("collaborator").get("id").in(collaboratorList)));
				predicates.add(cb.equal(rootPC.get("program").get("programId"), root.get("programId")));
			}

			if (!CommonUtil.IsNullOrEmpty(sponsorList)) {
				predicates.add(cb.isTrue(root.get("sponsor").get("id").in(sponsorList)));
			}

			/*
			 * if(!CommonUtil.IsNullOrEmpty(therapeuticAreaList)) {
			 * predicates.add(cb.isTrue(root.get("therapeuticArea").get("id").in(
			 * therapeuticAreaList))); }
			 */

			query.distinct(true);

			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Specification<ClinicalTrial> getClinicalTrialSpecification(
			ClinicalTrialFilterRequestModel filterModel, List<Long> pgmIdList, boolean sortRequired) {
		List<Long> therapeuticAreaIdList = filterModel.getTherapeuticAreaList();
		String trialName = filterModel.getTrialName();
		List<Integer> statusIdList = filterModel.getStatusList();
		List<Long> conditionIdList = filterModel.getTrialConditionList();

		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (null != filterModel.getCoordinatorId()) {
				Root<StudySiteCoordinator> rootssc = query.from(StudySiteCoordinator.class);
				Root<ClinicalTrialStudySite> rootctss = query.from(ClinicalTrialStudySite.class);

				// Active list
				if (null != filterModel.getActiveList() && filterModel.getActiveList().size() > 0)
					predicates.add(cb.isTrue(rootctss.get("isActive").in(filterModel.getActiveList())));

				predicates.add(cb.equal(rootssc.get("coordinatorId"), filterModel.getCoordinatorId()));
				predicates.add(cb.and(
						cb.equal(rootssc.get("studySiteId"), rootctss.get("clinicalStudySiteId").get("studySiteId")),
						cb.equal(rootctss.get("clinicalStudySiteId").get("id"), root.get("id"))));

				/*
				 * List<Long> studySiteIds =
				 * this.studySiteCoordinatorRepository.findByCoordinatorId(filterModel.
				 * getCoordinatorId()).stream().map(ssc->ssc.getStudySiteId()).collect(
				 * Collectors.toList()); List<Long> trialIds =
				 * this.clinicalStudySiteRepository.findByClinicalStudySiteIdStudySiteId(
				 * studySiteIds.get(0)).stream().map(css->css.getId().getId()).collect(
				 * Collectors.toList());
				 * 
				 * predicates.add(cb.isTrue(root.get("id").in(trialIds)));
				 */

			}
			if (!CommonUtil.IsNullOrEmpty(pgmIdList)) {
				predicates.add(cb.isTrue(root.get("programId").in(pgmIdList)));
			} else {
				predicates.add(cb.isTrue(root.get("programId").in(filterModel.getProgramIdList())));
			}

			if (!CommonUtil.IsNullOrEmpty(therapeuticAreaIdList)) {
				predicates.add(cb.isTrue(root.get("therapeuticAreaId").in(therapeuticAreaIdList)));
			}

			if (!CommonUtil.IsNullOrEmpty(statusIdList)) {
				predicates.add(cb.isTrue(root.get("trialStatusId").in(statusIdList)));
			}

			if (!CommonUtil.IsNullOrEmpty(conditionIdList)) {
				predicates.add(cb.isTrue(root.get("trialConditionId").in(conditionIdList)));
			}

			if (!CommonUtil.isNullOrBlank(trialName)) {
				predicates.add(cb.like(root.get("trialName"), "%" + trialName + "%"));
			}

			/*
			 * Root<TherapeuticArea> therapeuticAreaRoot = null; if
			 * ("therapeuticAreaName".equals(filterModel.getSortBy())) { therapeuticAreaRoot
			 * = query.from(TherapeuticArea.class);
			 * predicates.add(cb.equal(root.get("therapeuticAreaId"),
			 * therapeuticAreaRoot.get("id"))); }
			 */

			if (sortRequired && !filterModel.getSortDirection().trim().isEmpty()) {
				query.orderBy(getTrialOrder(filterModel.getSortBy(), filterModel.getSortDirection(), cb, root, null));
			}

			// query.distinct(true);

			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	public static Order getTrialOrder(String column, String sortType, CriteriaBuilder cb,
			Root<ClinicalTrial> clinicalTrialRoot, Root<TherapeuticArea> therapeuticAreaRoot) {
		if ("trialName".equals(column) && !sortType.trim().isEmpty()) {
			if (sortType.equals("asc")) {
				return cb.asc(clinicalTrialRoot.get("trialName"));
			} else {
				return cb.desc(clinicalTrialRoot.get("trialName"));

			}
		} else if ("therapeuticAreaName".equals(column) && !sortType.trim().isEmpty()) {
			if (sortType.equals("asc")) {
				return cb.asc(clinicalTrialRoot.get("therapeuticAreaId"));

			} else {
				return cb.desc(clinicalTrialRoot.get("therapeuticAreaId"));

			}
		}
		return (cb.desc(clinicalTrialRoot.get("updatedOn")));

	}

}
