-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pdr_criteria
-- ------------------------------------------------------
-- Server version	5.7.21-log

--
-- Table structure for table `arm`
--

DROP TABLE IF EXISTS `arm`;

CREATE TABLE `arm` (
  `ArmId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ArmName` varchar(125) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ArmId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


--
-- Table structure for table `trialcondition`
--

DROP TABLE IF EXISTS `trialcondition`;


CREATE TABLE `trialcondition` (
  `TrialConditionId` bigint(20) NOT NULL AUTO_INCREMENT,
  `TrialConditionName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`TrialConditionId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Table structure for table `trialstatus`
--

DROP TABLE IF EXISTS `trialstatus`;


CREATE TABLE `trialstatus` (
  `TrialStatusId` int(11) NOT NULL AUTO_INCREMENT,
  `TrialStatusName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`TrialStatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Table structure for table `audit_history`
--

DROP TABLE IF EXISTS `audit_history`;

CREATE TABLE `audit_history` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EntityName` varchar(255) DEFAULT NULL,
  `ActionPerformed` varchar(255) DEFAULT NULL,
  `EntityContent` text,
  `ModifiedBy` bigint(20) DEFAULT NULL,
  `ModifiedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;

CREATE TABLE `city` (
  `CityId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CityName` varchar(255) DEFAULT NULL,
  `StateId` bigint(20) DEFAULT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CityId`)
) ENGINE=InnoDB AUTO_INCREMENT=18943 DEFAULT CHARSET=latin1;

--
-- Table structure for table `clinicaltrial`
--

DROP TABLE IF EXISTS `clinicaltrial`;

CREATE TABLE `clinicaltrial` (
  `TrialId` bigint(20) NOT NULL AUTO_INCREMENT,
  `TrialName` varchar(512) DEFAULT NULL,
  `TrialDescription` varchar(512) DEFAULT NULL,
  `TrialStartDate` datetime DEFAULT NULL,
  `TrialEndDate` datetime DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT NULL,
  `TrialConditionId` bigint(20) DEFAULT NULL,
  `NCTNumber` varchar(50) DEFAULT NULL,
  `Interventions` varchar(512) DEFAULT NULL,
  `TrialStatusId` int(11) DEFAULT NULL,
  `TrialJson` text,
  `ProgramId` bigint(20) DEFAULT NULL,
  `TherapeuticAreaId` bigint(20) DEFAULT NULL,
  `ArmId` bigint(20) DEFAULT NULL,
  `StageId` bigint(20) DEFAULT NULL,
  `StudySite` varchar(250) DEFAULT NULL,
  `trialLandingURL` varchar(250) DEFAULT NULL,
  `TrialShortCode` varchar(50) DEFAULT '',
  `SponsorId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`TrialId`),
  KEY `FK_Trial_TrialStatus_idx` (`TrialStatusId`),
  KEY `Program_ID_TRIAL` (`ProgramId`),
  KEY `fk_trial_condition_id` (`TrialConditionId`),
  CONSTRAINT `FK_Trial_TrialStatus` FOREIGN KEY (`TrialStatusId`) REFERENCES `trialstatus` (`TrialStatusId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_trial_condition_id` FOREIGN KEY (`TrialConditionId`) REFERENCES `trialcondition` (`TrialConditionId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;


--
-- Table structure for table `clinicaltrial_collaborator`
--

DROP TABLE IF EXISTS `clinicaltrial_collaborator`;

CREATE TABLE `clinicaltrial_collaborator` (
  `TrialId` bigint(20) NOT NULL,
  `CollaboratorId` bigint(20) NOT NULL,
  PRIMARY KEY (`TrialId`,`CollaboratorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `clinicaltrialstudysite`
--

DROP TABLE IF EXISTS `clinicaltrialstudysite`;

CREATE TABLE `clinicaltrialstudysite` (
  `TrialId` bigint(20) NOT NULL,
  `StudySiteId` bigint(20) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `IsActive` bit(1) DEFAULT b'1',
  PRIMARY KEY (`TrialId`,`StudySiteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `collaboratortype`
--

DROP TABLE IF EXISTS `collaboratortype`;


CREATE TABLE `collaboratortype` (
  `CollaboratorTypeId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CollaboratorTypeName` varchar(255) DEFAULT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CollaboratorTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Table structure for table `collaborator`
--

DROP TABLE IF EXISTS `collaborator`;

CREATE TABLE `collaborator` (
  `CollaboratorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CollaboratorName` varchar(255) DEFAULT NULL,
  `CollaboratorType` bigint(20) DEFAULT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CollaboratorId`),
  UNIQUE KEY `Collaborator_Name` (`CollaboratorName`),
  KEY `FK_Collaborator_Type` (`CollaboratorType`),
  CONSTRAINT `FK_Collaborator_Type` FOREIGN KEY (`CollaboratorType`) REFERENCES `collaboratortype` (`CollaboratorTypeId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;





--
-- Table structure for table `coordinator`
--

DROP TABLE IF EXISTS `coordinator`;


CREATE TABLE `coordinator` (
  `CoordinatorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CoordinatorName` varchar(50) NOT NULL,
  `Address1` varchar(100) DEFAULT NULL,
  `Address2` varchar(100) DEFAULT NULL,
  `EmailAddress` varchar(256) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`CoordinatorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;


CREATE TABLE `country` (
  `CountryId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CountryName` varchar(255) DEFAULT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CountryId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


--
-- Table structure for table `criteria`
--

DROP TABLE IF EXISTS `criteria`;


CREATE TABLE `criteria` (
  `CriteriaId` bigint(20) NOT NULL AUTO_INCREMENT,
  `TrialId` bigint(20) DEFAULT NULL,
  `TemplateId` bigint(20) DEFAULT NULL,
  `CriteriaName` varchar(512) NOT NULL,
  `CriteriaDescription` varchar(512) NOT NULL,
  `Qualifiers` text,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `IsInclude` bit(1) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `IsDeleted` bit(1) DEFAULT NULL,
  `OverAllOperator` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`CriteriaId`)
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8;


--
-- Table structure for table `criteriatemplate`
--

DROP TABLE IF EXISTS `criteriatemplate`;


CREATE TABLE `criteriatemplate` (
  `TemplateId` bigint(20) NOT NULL AUTO_INCREMENT,
  `TemplateName` varchar(512) DEFAULT NULL,
  `TemplateDescription` varchar(512) DEFAULT NULL,
  `TemplateSource` varchar(2000) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`TemplateId`),
  UNIQUE KEY `TemplateName_UNIQUE` (`TemplateName`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


--
-- Table structure for table `phase`
--

DROP TABLE IF EXISTS `phase`;


CREATE TABLE `phase` (
  `PhaseId` int(11) NOT NULL AUTO_INCREMENT,
  `PhaseName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`PhaseId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


--
-- Table structure for table `principalinvestigator`
--

DROP TABLE IF EXISTS `principalinvestigator`;


CREATE TABLE `principalinvestigator` (
  `PrincipalInvestigatorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `PrincipalInvestigatorName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `EmailAddress` varchar(256) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`PrincipalInvestigatorId`)
) ENGINE=InnoDB AUTO_INCREMENT=562 DEFAULT CHARSET=utf8;

--
-- Table structure for table `sponsor`
--

DROP TABLE IF EXISTS `sponsor`;


CREATE TABLE `sponsor` (
  `SponsorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `SponsorName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`SponsorId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


--
-- Table structure for table `stage`
--

DROP TABLE IF EXISTS `stage`;


CREATE TABLE `stage` (
  `StageId` bigint(20) NOT NULL AUTO_INCREMENT,
  `StageName` varchar(125) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`StageId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Table structure for table `programstatus`
--

DROP TABLE IF EXISTS `programstatus`;


CREATE TABLE `programstatus` (
  `StatusId` int(11) NOT NULL AUTO_INCREMENT,
  `StatusName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`StatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Table structure for table `therapeuticarea`
--

DROP TABLE IF EXISTS `therapeuticarea`;


CREATE TABLE `therapeuticarea` (
  `TherapeuticAreaId` bigint(20) NOT NULL AUTO_INCREMENT,
  `TherapeuticAreaName` varchar(125) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TherapeuticAreaId`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;


CREATE TABLE `program` (
  `ProgramID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ProgramName` varchar(255) DEFAULT NULL,
  `ProgramDesc` varchar(1500) DEFAULT NULL,
  `TherapeuticAreaId` bigint(20) DEFAULT NULL,
  `SponsorId` bigint(20) DEFAULT NULL,
  `PhaseId` int(11) DEFAULT NULL,
  `StartDate` datetime DEFAULT NULL,
  `EstimatedEndDate` datetime DEFAULT NULL,
  `StatusId` int(11) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `IsDeleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`ProgramID`),
  UNIQUE KEY `Program_Name` (`ProgramName`),
  KEY `fk_program_therapeutic_area_id` (`TherapeuticAreaId`),
  KEY `fk_program_sponsor_id` (`SponsorId`),
  KEY `fk_program_trial_status_id` (`StatusId`),
  KEY `fk_program_phase_id` (`PhaseId`),
  CONSTRAINT `fk_program_phase_id` FOREIGN KEY (`PhaseId`) REFERENCES `phase` (`PhaseId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_program_sponsor_id` FOREIGN KEY (`SponsorId`) REFERENCES `sponsor` (`SponsorId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_program_therapeutic_area_id` FOREIGN KEY (`TherapeuticAreaId`) REFERENCES `therapeuticarea` (`TherapeuticAreaId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_program_trial_status_id` FOREIGN KEY (`StatusId`) REFERENCES `programstatus` (`StatusId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


--
-- Table structure for table `program_collaborator`
--

DROP TABLE IF EXISTS `program_collaborator`;


CREATE TABLE `program_collaborator` (
  `ProgramId` bigint(20) NOT NULL,
  `CollaboratorId` bigint(20) NOT NULL,
  PRIMARY KEY (`ProgramId`,`CollaboratorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;





--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;


CREATE TABLE `question` (
  `QuestionId` bigint(20) NOT NULL AUTO_INCREMENT,
  `QuestionName` varchar(255) DEFAULT NULL,
  `Description` varchar(512) DEFAULT NULL,
  `Status` bit(1) DEFAULT b'1',
  `CriteriaId` bigint(20) DEFAULT NULL,
  `QualifierId` varchar(50) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `QuestionnaireId` bigint(20) DEFAULT NULL,
  `IsInclude` bit(1) DEFAULT b'0',
  `CorrectAnswer` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`QuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


--
-- Table structure for table `questionnaire`
--

DROP TABLE IF EXISTS `questionnaire`;


CREATE TABLE `questionnaire` (
  `QuestionnaireId` bigint(20) NOT NULL AUTO_INCREMENT,
  `QuestionnaireName` varchar(255) DEFAULT NULL,
  `Description` varchar(512) DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  `ProgramId` bigint(20) DEFAULT NULL,
  `Status` bit(1) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`QuestionnaireId`),
  KEY `FK_Questionnaire_ClinicalTrial` (`TrialId`),
  CONSTRAINT `FK_Questionnaire_ClinicalTrial` FOREIGN KEY (`TrialId`) REFERENCES `clinicaltrial` (`TrialId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;


--
-- Table structure for table `questionnairequestion`
--

DROP TABLE IF EXISTS `questionnairequestion`;


CREATE TABLE `questionnairequestion` (
  `QuestionQuestionnaireId` bigint(20) NOT NULL AUTO_INCREMENT,
  `QuestionId` bigint(20) DEFAULT NULL,
  `QuestionnaireId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`QuestionQuestionnaireId`),
  KEY `FK_Questionnaire_Question_idx` (`QuestionId`),
  KEY `FK_QQ_Questionnaire_idx` (`QuestionnaireId`),
  CONSTRAINT `FK_QQ_Question` FOREIGN KEY (`QuestionId`) REFERENCES `question` (`QuestionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_QQ_Questionnaire` FOREIGN KEY (`QuestionnaireId`) REFERENCES `questionnaire` (`QuestionnaireId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;


CREATE TABLE `state` (
  `StateId` bigint(20) NOT NULL AUTO_INCREMENT,
  `StateName` varchar(255) DEFAULT NULL,
  `Abbrev` varchar(255) DEFAULT NULL,
  `CountryId` bigint(20) DEFAULT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`StateId`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1 COMMENT='		';


--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;


CREATE TABLE `status` (
  `StatusId` int(11) NOT NULL AUTO_INCREMENT,
  `StatusName` varchar(50) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`StatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


--
-- Table structure for table `studysite`
--

DROP TABLE IF EXISTS `studysite`;


CREATE TABLE `studysite` (
  `StudySiteId` bigint(20) NOT NULL AUTO_INCREMENT,
  `StudySiteName` varchar(100) DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Address1` varchar(100) DEFAULT NULL,
  `Address2` varchar(100) DEFAULT NULL,
  `City` varchar(512) DEFAULT NULL,
  `State` varchar(512) DEFAULT NULL,
  `Country` varchar(512) DEFAULT NULL,
  `Zip` varchar(20) DEFAULT NULL,
  `EmailAddress` varchar(256) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `UltimateParentName` varchar(256) DEFAULT NULL,
  `Region` varchar(1000) DEFAULT NULL,
  `PrimaryTherapeuticArea` varchar(1000) DEFAULT NULL,
  `PrimaryIndication` varchar(50) DEFAULT NULL,
  `Active` bit(1) DEFAULT NULL,
  `StudySitePhaseId` bigint(20) DEFAULT NULL,
  `StudySiteIRBId` bigint(20) DEFAULT NULL,
  `StudySiteStatusId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`StudySiteId`)
) ENGINE=InnoDB AUTO_INCREMENT=1023 DEFAULT CHARSET=utf8;


--
-- Table structure for table `studysiteaudit`
--

DROP TABLE IF EXISTS `studysiteaudit`;


CREATE TABLE `studysiteaudit` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `StudySiteId` bigint(20) NOT NULL,
  `PreviousStatus` bit(1) DEFAULT NULL,
  `ChangedStatus` bit(1) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_StudySite_idx` (`StudySiteId`),
  CONSTRAINT `FK_StudySite_idx` FOREIGN KEY (`StudySiteId`) REFERENCES `studysite` (`StudySiteId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `studysitecoordinator`
--

DROP TABLE IF EXISTS `studysitecoordinator`;


CREATE TABLE `studysitecoordinator` (
  `StudySiteCoordinatorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CoordinatorId` bigint(20) NOT NULL,
  `StudySiteId` bigint(20) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`StudySiteCoordinatorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `studysiteirb`
--

DROP TABLE IF EXISTS `studysiteirb`;


CREATE TABLE `studysiteirb` (
  `StudysiteIRBId` bigint(20) NOT NULL AUTO_INCREMENT,
  `StudySiteIRBName` varchar(50) NOT NULL,
  `IRBDisplayName` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`StudysiteIRBId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


--
-- Table structure for table `studysitephase`
--

DROP TABLE IF EXISTS `studysitephase`;


CREATE TABLE `studysitephase` (
  `StudysitePhaseId` bigint(20) NOT NULL AUTO_INCREMENT,
  `StudySitePhaseName` varchar(50) NOT NULL,
  `StudySitePhaseDisplayName` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`StudysitePhaseId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


--
-- Table structure for table `studysiteprincipalinvestigator`
--

DROP TABLE IF EXISTS `studysiteprincipalinvestigator`;


CREATE TABLE `studysiteprincipalinvestigator` (
  `StudySitePrincipalInvestigatorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `PrincipalInvestigatorId` bigint(20) NOT NULL,
  `StudySiteId` bigint(20) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`StudySitePrincipalInvestigatorId`)
) ENGINE=InnoDB AUTO_INCREMENT=790 DEFAULT CHARSET=utf8;


--
-- Table structure for table `studysitestatus`
--

DROP TABLE IF EXISTS `studysitestatus`;


CREATE TABLE `studysitestatus` (
  `StudysiteStatusId` bigint(20) NOT NULL AUTO_INCREMENT,
  `StudySiteStatusName` varchar(50) NOT NULL,
  `StudySiteStatusDisplayName` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`StudysiteStatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;




-- Dump completed on 2018-06-07 12:41:29
