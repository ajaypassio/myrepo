INSERT INTO `coordinator` (`CoordinatorId`, `CoordinatorName`) VALUES ('1', 'Jawahar Siva');
INSERT INTO `studysite`
(`StudySiteId`,
`StudySiteName`,
`Latitude`,
`Longitude`,
`Address1`,
`Address2`,
`City`,
`State`,
`Country`,
`Zip`,
`EmailAddress`,
`PhoneNumber`,
`CreatedBy`,
`CreatedOn`,
`UpdatedBy`,
`UpdatedOn`,
`UltimateParentName`,
`Region`,
`PrimaryTherapeuticArea`,
`PrimaryIndication`,
`Active`,
`StudySitePhaseId`,
`StudySiteIRBId`,
`StudySiteStatusId`)
VALUES
(1,'Orange County Research Center, Inc.',33.7364,-117.8229,'14351 Myford Road','Suite B','Tustin','CA','united states','92780',NULL,'4056038068',1,'2018-06-07 17:25:12',1,'2018-06-07 17:25:12','Orange County Research Center, Inc.','USA/Canada','Endocrinology','Diabetes mellitus',b'1',NULL,NULL,NULL);

INSERT INTO `studysitecoordinator` (`StudySiteCoordinatorId`, `CoordinatorId`, `StudySiteId`, `TrialId`) VALUES ('1', '1', '1', '10');
INSERT INTO `clinicaltrialstudysite` (`TrialId`,`StudySiteId`,`CreatedBy`,`CreatedOn`,`UpdatedBy`,`UpdatedOn`,`IsActive`) VALUES (10,1,1,now(),1,now(),b'1');