UPDATE trialstatus SET TrialStatusName='Closed' WHERE TrialStatusId='2';
UPDATE trialstatus SET TrialStatusName='In Startup' WHERE TrialStatusId='4';
UPDATE trialstatus SET TrialStatusName='Completed' WHERE TrialStatusId='5';
DELETE FROM trialstatus WHERE TrialStatusId='6';
