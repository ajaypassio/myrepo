INSERT INTO `coordinator` (`CoordinatorId`, `CoordinatorName`) VALUES ('2', 'Karthika Arumugam');
UPDATE `studysitecoordinator` SET `CoordinatorId`='2' WHERE `CoordinatorId` ='1';
