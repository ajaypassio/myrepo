alter table `ClinicalTrial`
add  `TrialCollectionReady` int DEFAULT 0;


DROP TABLE IF EXISTS `TrialJobMap`;

CREATE TABLE `TrialJobMap` (
  `MapId` bigint(20) NOT NULL AUTO_INCREMENT,
  `CorrelationId` varchar(125) DEFAULT NULL,
  `TrialId` bigint(10) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`MapId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;