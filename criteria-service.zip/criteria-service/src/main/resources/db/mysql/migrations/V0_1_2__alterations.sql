alter table `TrialJobMap`
add  `JobStatus` varchar(100) DEFAULT 'unknown';