INSERT INTO `city` (`CityName`, `StateId`, `CreatedBy`) VALUES 
	('Doral', '11', '0'),
	('Ponte Vedra', '11', '0'),
	('McKinney', '48', '0'),
	('Fleming Island', '11', '0'),
	('Tamarac', '11', '0'),
	('Farmington Hills', '25', '0'),
	('Tustin', '6', '0');