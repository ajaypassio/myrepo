DROP TABLE IF EXISTS `StudySiteImportStatus`;
CREATE TABLE `StudySiteImportStatus` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `FileName` varchar(512) DEFAULT NULL,
  `TrialId` bigint(10) DEFAULT NULL,
  `ImportStatus` varchar(256) DEFAULT NULL,
  `ImportStatusData` varchar(max) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP, 
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;