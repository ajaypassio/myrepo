ALTER TABLE `clinicaltrial` 
CHANGE COLUMN `TrialName` `TrialName` NVARCHAR(512) NULL DEFAULT NULL ;

ALTER TABLE `clinicaltrial` 
CHANGE COLUMN `TrialShortCode` `TrialShortCode` NVARCHAR(50) NULL DEFAULT NULL ;