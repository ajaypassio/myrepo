alter table Criteria change column CriteriaName, CriteriaName nvarchar(512);
alter table Criteria change column CriteriaDescription,CriteriaDescription nvarchar(512);