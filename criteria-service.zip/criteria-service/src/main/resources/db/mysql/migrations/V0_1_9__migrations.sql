Alter table StudySiteImportStatus add OriginalFileName varchar(max) default null;
Alter table StudySiteImportStatus change column FileName, FileName varchar(max);