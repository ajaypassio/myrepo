SET IDENTITY_INSERT [dbo].[coordinator] ON;
INSERT INTO coordinator (CoordinatorId, CoordinatorName) VALUES ('1', 'Jawahar Siva');
SET IDENTITY_INSERT [dbo].[coordinator] OFF;

SET IDENTITY_INSERT [dbo].[StudySite] ON;
INSERT [dbo].[StudySite] ([StudySiteId], [Latitude], [Longitude], [City], [State], [Country], [Zip], [StudySiteName], [Address1], [Address2], [EmailAddress], [PhoneNumber], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn], [UltimateParentName], [Region], [PrimaryTherapeuticArea], [PrimaryIndication], [Active], [StudySitePhaseId], [StudySiteIRBId], [StudySiteStatusId]) VALUES (1, 33.7364, -117.8229, N'Tustin', N'CA', N'united states', N'92780', N'Orange County Research Center, Inc.', N'14351 Myford Road', N'Suite B', NULL, N'4056038068', 1, CAST(N'2018-06-09T05:16:31.750' AS DateTime), 1, CAST(N'2018-06-11T09:36:36.437' AS DateTime), N'Orange County Research Center, Inc.', N'USA/Canada', N'Endocrinology', N'Diabetes mellitus', 1, NULL, NULL, NULL);
SET IDENTITY_INSERT [dbo].[StudySite] OFF;

SET IDENTITY_INSERT [dbo].[studysitecoordinator] ON;
INSERT INTO studysitecoordinator (StudySiteCoordinatorId, CoordinatorId, StudySiteId, TrialId) VALUES ('1', '1', '1', '10');
SET IDENTITY_INSERT [dbo].[studysitecoordinator] OFF; 


insert into [ClinicalTrialStudySite]([TrialId]
      ,[StudySiteId]
      ,[CreatedBy]
      ,[CreatedOn]
      ,[UpdatedBy]
      ,[UpdatedOn]
      ,[IsActive]) values(10,1,1,CAST(N'2018-06-11T09:36:36.437' AS DateTime),1,CAST(N'2018-06-11T09:36:36.437' AS DateTime),1);


