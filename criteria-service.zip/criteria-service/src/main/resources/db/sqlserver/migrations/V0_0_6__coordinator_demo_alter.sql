SET IDENTITY_INSERT [dbo].[coordinator] ON;
INSERT INTO coordinator (CoordinatorId, CoordinatorName) VALUES ('2', 'Karthika Arumugam');
SET IDENTITY_INSERT [dbo].[coordinator] OFF;

SET IDENTITY_INSERT [dbo].[studysitecoordinator] ON;
UPDATE studysitecoordinator SET CoordinatorId='2' WHERE CoordinatorId='1';
SET IDENTITY_INSERT [dbo].[studysitecoordinator] OFF; 
