SET IDENTITY_INSERT [dbo].[Sponsor] ON;
INSERT [dbo].[Sponsor] ([SponsorId], [SponsorName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (2, N'Sponsor 1', 1, CAST(N'2017-10-12T00:00:00.0000000' AS DateTime2), 1, CAST(N'2017-10-12T00:00:00.0000000' AS DateTime2));
SET IDENTITY_INSERT [dbo].[Sponsor] OFF;

SET IDENTITY_INSERT [dbo].[Collaborator] ON;
INSERT [dbo].[Collaborator] ([CollaboratorId], [CollaboratorName], [CollaboratorType], [CreatedBy], [UpdatedBy], [CreatedOn], [UpdatedOn]) VALUES (8, N'CRO 1', 2, 1, 1, CAST(N'2018-06-08T17:08:44.0000000' AS DateTime2), CAST(N'2018-06-08T17:08:44.0000000' AS DateTime2));
SET IDENTITY_INSERT [dbo].[Collaborator] OFF;

