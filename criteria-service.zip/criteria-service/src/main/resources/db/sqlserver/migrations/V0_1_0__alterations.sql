ALTER table [dbo].[ClinicalTrial]
ALTER column  [TrialJson] VARCHAR(MAX);