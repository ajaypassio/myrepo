ALTER table [dbo].[ClinicalTrial]
ADD [TrialCollectionReady] [int]
GO
ALTER TABLE [dbo].[ClinicalTrial] ADD  DEFAULT (0) FOR [TrialCollectionReady]
GO
UPDATE [dbo].[ClinicalTrial]
SET [TrialCollectionReady]='0'
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrialJobMap](
	[MapId] [bigint] IDENTITY(1,1) NOT NULL,
	[CorrelationId] [varchar](512)  NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[CreatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [bigint] NULL,
	[UpdatedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[MapId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO