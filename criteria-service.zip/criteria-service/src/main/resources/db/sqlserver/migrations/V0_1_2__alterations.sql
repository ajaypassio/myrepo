ALTER table [dbo].[TrialJobMap]
ADD [JobStatus] [varchar](100)
GO
UPDATE [dbo].[TrialJobMap]
SET [JobStatus]='unknown'
GO
