SET IDENTITY_INSERT [dbo].[City] OFF
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('Doral', '11', '0')
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('Ponte Vedra', '11', '0')
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('McKinney', '48', '0')
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('Fleming Island', '11', '0')
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('Tamarac', '11', '0')
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('Farmington Hills', '25', '0')
INSERT [dbo].[City] ([CityName], [StateId], [CreatedBy]) VALUES ('Tustin', '6', '0')
SET IDENTITY_INSERT [dbo].[City] ON