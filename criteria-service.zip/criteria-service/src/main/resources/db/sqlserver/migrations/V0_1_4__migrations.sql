SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [StudySiteImportStatus](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FileName] [varchar](512)  NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[ImportStatus] [varchar](256) NULL,
	[ImportStatusData] varchar(max) DEFAULT NULL,
	[CreatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO