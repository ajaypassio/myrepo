DECLARE @ConstraintName nvarchar(2000);
SELECT @ConstraintName = Name FROM SYS.DEFAULT_CONSTRAINTS WHERE PARENT_OBJECT_ID = OBJECT_ID('clinicaltrial')
 AND PARENT_COLUMN_ID = (SELECT column_id FROM sys.columns WHERE NAME = N'TrialName' AND object_id = OBJECT_ID(N'clinicaltrial'));
 print @ConstraintName;
IF @ConstraintName IS NOT NULL
EXEC('ALTER TABLE clinicaltrial DROP CONSTRAINT ' + @ConstraintName);

alter table clinicaltrial alter column trialname nvarchar(512);


SELECT @ConstraintName = Name FROM SYS.DEFAULT_CONSTRAINTS WHERE PARENT_OBJECT_ID = OBJECT_ID('clinicaltrial')
 AND PARENT_COLUMN_ID = (SELECT column_id FROM sys.columns WHERE NAME = N'trialshortcode' AND object_id = OBJECT_ID(N'clinicaltrial'));
 print @ConstraintName;
IF @ConstraintName IS NOT NULL
EXEC('ALTER TABLE clinicaltrial DROP CONSTRAINT ' + @ConstraintName);

alter table clinicaltrial alter column trialshortcode nvarchar(50);