DECLARE @ConstraintName nvarchar(2000);
SELECT @ConstraintName = Name FROM SYS.DEFAULT_CONSTRAINTS WHERE PARENT_OBJECT_ID = OBJECT_ID('Criteria')
 AND PARENT_COLUMN_ID = (SELECT column_id FROM sys.columns WHERE NAME = N'CriteriaName' AND object_id = OBJECT_ID(N'Criteria'));
 print @ConstraintName;
IF @ConstraintName IS NOT NULL
EXEC('ALTER TABLE Criteria DROP CONSTRAINT ' + @ConstraintName);

alter table Criteria alter column CriteriaName nvarchar(512);


SELECT @ConstraintName = Name FROM SYS.DEFAULT_CONSTRAINTS WHERE PARENT_OBJECT_ID = OBJECT_ID('Criteria')
 AND PARENT_COLUMN_ID = (SELECT column_id FROM sys.columns WHERE NAME = N'CriteriaDescription' AND object_id = OBJECT_ID(N'Criteria'));
 print @ConstraintName;
IF @ConstraintName IS NOT NULL
EXEC('ALTER TABLE Criteria DROP CONSTRAINT ' + @ConstraintName);

alter table Criteria alter column CriteriaDescription nvarchar(512);