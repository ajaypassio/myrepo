SET IDENTITY_INSERT [dbo].[City] OFF
insert into city (cityname,stateid,createdby,createdon,updatedby,updatedon)values('Glendale',4,1,getdate(),1,getdate());