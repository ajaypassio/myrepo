Alter table StudySiteImportStatus add OriginalFileName varchar(max) default null;
Alter table StudySiteImportStatus alter column FileName varchar(max);