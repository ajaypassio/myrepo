Update collaborator set collaboratorname=concat('CRO #',collaboratorid);
Update Sponsor set Sponsorname=concat('Sponsor #',Sponsorid);