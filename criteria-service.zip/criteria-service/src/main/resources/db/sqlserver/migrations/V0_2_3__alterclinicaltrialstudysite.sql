ALTER TABLE clinicaltrialstudysite ADD RadiusValue INT; 
ALTER TABLE clinicaltrialstudysite ADD RadiusExempt bit DEFAULT '0' NOT NULL; 