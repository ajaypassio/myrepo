CREATE NONCLUSTERED INDEX udx_StudySiteCoordinator_ssId_crdId on StudySiteCoordinator (StudySiteId,CoordinatorId); 

CREATE NONCLUSTERED INDEX udx_StudySitePrincipalInvestigator_ssId_piId on StudySitePrincipalInvestigator (StudySiteId,PrincipalInvestigatorId); 

CREATE NONCLUSTERED INDEX udx_StudySiteAudit_ssId on StudySiteAudit (StudySiteId); 