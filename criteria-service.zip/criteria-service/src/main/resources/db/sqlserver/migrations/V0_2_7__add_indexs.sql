
--City
DROP INDEX IF EXISTS [udx_City_cName] ON [dbo].[City]
GO
CREATE NONCLUSTERED INDEX udx_City_cName on City (CityName);

DROP INDEX IF EXISTS [udx_City_sId] ON [dbo].[City]
GO
CREATE NONCLUSTERED INDEX udx_City_sId on City (StateId);

--ClinicalTrial
DROP INDEX IF EXISTS [udx_ClinicalTrial_pId] ON [dbo].[ClinicalTrial]
GO
CREATE NONCLUSTERED INDEX udx_ClinicalTrial_pId on ClinicalTrial (ProgramId);

DROP INDEX IF EXISTS [udx_ClinicalTrial_tName_pId] ON [dbo].[ClinicalTrial]
GO
CREATE NONCLUSTERED INDEX udx_ClinicalTrial_tName_pId on ClinicalTrial (TrialName,ProgramId);

DROP INDEX IF EXISTS [udx_ClinicalTrial_tsCode_tName] ON [dbo].[ClinicalTrial]
GO
CREATE NONCLUSTERED INDEX udx_ClinicalTrial_tsCode_tName on ClinicalTrial (TrialShortCode,TrialName);

--Collaborator  :: Check point
DROP INDEX IF EXISTS [udx_Collaborator_clbName] ON [dbo].[Collaborator]
GO
CREATE NONCLUSTERED INDEX udx_Collaborator_clbName on Collaborator (CollaboratorName);

DROP INDEX IF EXISTS [udx_Collaborator_clbType] ON [dbo].[Collaborator]
GO
CREATE NONCLUSTERED INDEX udx_Collaborator_clbType on Collaborator (CollaboratorType);

IF (OBJECT_ID('dbo.FK_Collaborator_CollaboratorType', 'F') IS NOT NULL)
	ALTER TABLE Collaborator DROP CONSTRAINT FK_Collaborator_CollaboratorType
GO	

ALTER TABLE [dbo].[Collaborator] WITH CHECK ADD CONSTRAINT [FK_Collaborator_CollaboratorType]
FOREIGN KEY ([CollaboratorType]) REFERENCES [dbo].[CollaboratorType]([CollaboratorTypeId]);


--Coordinator
DROP INDEX IF EXISTS [udx_Coordinator_crdName] ON [dbo].[Coordinator]
GO
CREATE NONCLUSTERED INDEX udx_Coordinator_crdName on Coordinator (CoordinatorName);

--Country
DROP INDEX IF EXISTS [udx_Country_cnName] ON [dbo].[Country]
GO
CREATE NONCLUSTERED INDEX udx_Country_cnName on Country (CountryName);

--Criteria
DROP INDEX IF EXISTS [udx_Criteria_trId] ON [dbo].[Criteria]
GO
CREATE NONCLUSTERED INDEX udx_Criteria_trId on Criteria (TrialId);

DROP INDEX IF EXISTS [udx_Criteria_tmplId] ON [dbo].[Criteria]
GO
CREATE NONCLUSTERED INDEX udx_Criteria_tmplId on Criteria (TemplateId);

--CriteriaTemplate
DROP INDEX IF EXISTS [udx_CriteriaTemplate_tmplName] ON [dbo].[CriteriaTemplate]
GO
CREATE NONCLUSTERED INDEX udx_CriteriaTemplate_tmplName on CriteriaTemplate (TemplateName);

--PrincipalInvestigator
DROP INDEX IF EXISTS [udx_PrincipalInvestigator_piName] ON [dbo].[PrincipalInvestigator]
GO
CREATE NONCLUSTERED INDEX udx_PrincipalInvestigator_piName on PrincipalInvestigator(PrincipalInvestigatorName);

--Program
DROP INDEX IF EXISTS [udx_Program_pName] ON [dbo].[Program]
GO
CREATE NONCLUSTERED INDEX udx_Program_pName on Program (ProgramName);

DROP INDEX IF EXISTS [udx_Program_phId] ON [dbo].[Program]
GO
CREATE NONCLUSTERED INDEX udx_Program_phId on Program (PhaseId);

DROP INDEX IF EXISTS [udx_Program_taId] ON [dbo].[Program]
GO
CREATE NONCLUSTERED INDEX udx_Program_taId on Program (TherapeuticAreaId);

DROP INDEX IF EXISTS [udx_Program_spId] ON [dbo].[Program]
GO
CREATE NONCLUSTERED INDEX udx_Program_spId on Program (SponsorId);

DROP INDEX IF EXISTS [udx_Program_stId] ON [dbo].[Program]
GO
CREATE NONCLUSTERED INDEX udx_Program_stId on Program (StatusId);

--Question
DROP INDEX IF EXISTS [udx_Question_qName] ON [dbo].[Question]
GO
CREATE NONCLUSTERED INDEX udx_Question_qName on Question(QuestionName);

DROP INDEX IF EXISTS [udx_Question_qName_qId] ON [dbo].[Question]
GO
CREATE NONCLUSTERED INDEX udx_Question_qName_qId on Question(QuestionnaireId);

DROP INDEX IF EXISTS [udx_Question_cId_qId] ON [dbo].[Question]
GO
CREATE NONCLUSTERED INDEX udx_Question_cId_qId on Question(CriteriaId,QualifierId);

--Questionnaire
DROP INDEX IF EXISTS [udx_Questionnaire_qName] ON [dbo].[Questionnaire]
GO
CREATE NONCLUSTERED INDEX udx_Questionnaire_qName on Questionnaire(QuestionnaireName);

DROP INDEX IF EXISTS [udx_Questionnaire_tId_pId] ON [dbo].[Questionnaire]
GO
CREATE NONCLUSTERED INDEX udx_Questionnaire_tId_pId on Questionnaire(TrialId, ProgramId);

--QuestionnaireQuestion
DROP INDEX IF EXISTS [udx_QuestionnaireQuestion_qId_qnId] ON [dbo].[QuestionnaireQuestion]
GO
CREATE NONCLUSTERED INDEX udx_QuestionnaireQuestion_qId_qnId on QuestionnaireQuestion(QuestionId,QuestionnaireId);

--Sponsor
DROP INDEX IF EXISTS [udx_Sponsor_sName] ON [dbo].[Sponsor]
GO
CREATE NONCLUSTERED INDEX udx_Sponsor_sName on Sponsor(SponsorName);

--State
DROP INDEX IF EXISTS [udx_State_StateName] ON [dbo].[State]
GO
CREATE NONCLUSTERED INDEX udx_State_StateName on State(StateName);

--StudySite
DROP INDEX IF EXISTS [udx_StudySite_ssName] ON [dbo].[StudySite]
GO
CREATE NONCLUSTERED INDEX udx_StudySite_ssName on StudySite (StudySiteName);

DROP INDEX IF EXISTS [udx_StudySite_Zip] ON [dbo].[StudySite]
GO
CREATE NONCLUSTERED INDEX udx_StudySite_Zip on StudySite (Zip);

DROP INDEX IF EXISTS [udx_StudySite_City_State] ON [dbo].[StudySite]
GO
CREATE NONCLUSTERED INDEX udx_StudySite_City_State on StudySite (City,State);

--StudySiteCoordinator
DROP INDEX IF EXISTS [udx_StudySiteCoordinator_cId] ON [dbo].[StudySiteCoordinator]
GO
CREATE NONCLUSTERED INDEX udx_StudySiteCoordinator_cId on StudySiteCoordinator(CoordinatorId);

DROP INDEX IF EXISTS [udx_StudySiteCoordinator_ssId] ON [dbo].[StudySiteCoordinator]
GO
CREATE NONCLUSTERED INDEX udx_StudySiteCoordinator_ssId on StudySiteCoordinator(StudySiteId);

DROP INDEX IF EXISTS [udx_StudySiteCoordinator_tId_ssId] ON [dbo].[StudySiteCoordinator]
GO
CREATE NONCLUSTERED INDEX udx_StudySiteCoordinator_tId_ssId on StudySiteCoordinator(TrialId,StudySiteId);

DROP INDEX IF EXISTS [udx_StudySiteCoordinator_ssId_cId_tId] ON [dbo].[StudySiteCoordinator]
GO
CREATE NONCLUSTERED INDEX udx_StudySiteCoordinator_ssId_cId_tId on StudySiteCoordinator(StudySiteId,CoordinatorId,TrialId);

DROP INDEX IF EXISTS [udx_StudySiteCoordinator_ssId_cId] ON [dbo].[StudySiteCoordinator]
GO
CREATE NONCLUSTERED INDEX udx_StudySiteCoordinator_ssId_cId on StudySiteCoordinator(StudySiteId,CoordinatorId); 

--TherapeuticArea
DROP INDEX IF EXISTS [udx_TherapeuticArea_taName] ON [dbo].[TherapeuticArea]
GO
CREATE NONCLUSTERED INDEX udx_TherapeuticArea_taName on TherapeuticArea(TherapeuticAreaName);

--TrialJobMap
DROP INDEX IF EXISTS [udx_TrialJobMap_crId] ON [dbo].[TrialJobMap]
GO
CREATE NONCLUSTERED INDEX udx_TrialJobMap_crId on TrialJobMap(CorrelationId);

--TrialCondition
DROP INDEX IF EXISTS [udx_TrialCondition_tcName] ON [dbo].[TrialCondition]
GO
CREATE NONCLUSTERED INDEX udx_TrialCondition_tcName on TrialCondition(TrialConditionName);

--StudySitePrincipalInvestigator 
DROP INDEX IF EXISTS [udx_StudySitePrincipalInvestigator_ssId_piId] ON [dbo].[StudySitePrincipalInvestigator]
GO
CREATE NONCLUSTERED INDEX udx_StudySitePrincipalInvestigator_ssId_piId on StudySitePrincipalInvestigator (StudySiteId,PrincipalInvestigatorId) ; 
 
--StudySiteAudit
DROP INDEX IF EXISTS [udx_StudySiteAudit_ssId] ON [dbo].[StudySiteAudit]
GO
CREATE NONCLUSTERED INDEX udx_StudySiteAudit_ssId on StudySiteAudit(StudySiteId) ;





















