ALTER TABLE principalInvestigator ADD NPI varchar(10); 
ALTER TABLE principalInvestigator ADD Specialty varchar(256);
ALTER TABLE principalInvestigator ADD Project varchar(256); 