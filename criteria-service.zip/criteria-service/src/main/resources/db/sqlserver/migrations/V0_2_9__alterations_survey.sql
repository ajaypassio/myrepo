ALTER TABLE ClinicalTrial ADD SsId bigint;
ALTER TABLE Program ADD SsId bigint;