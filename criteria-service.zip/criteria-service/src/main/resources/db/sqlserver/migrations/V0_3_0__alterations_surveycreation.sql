GO
/****** Object:  Table [dbo].[CollectorResponse]    Script Date: 10/4/2019 12:28:00 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CollectorResponse](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[SurveyCollectorId] [bigint] NOT NULL,
	[CollectorResponseExternalId] [bigint] NOT NULL,
	[PatientId] [varchar](250) NULL,
	[Status] [varchar](50) NOT NULL,
	[CustomVariables] [varchar](500) NULL,
	[QualifiedTrialIds] [varchar](500) NULL,
	[Incorrect] [int] NULL,
	[PartiallyCorrect] [int] NULL,
	[TotalQuestions] [int] NULL,
	[TotalScore] [int] NULL,
	[Score] [int] NULL,
	[Correct] [int] NULL,
	[AnalyzeURL] [varchar](500) NOT NULL,
	[CollectionMode] [varchar](100) NOT NULL,
	[RespondentId] [bigint] NULL,
	[Language] [varchar](10) NULL,
	[UserAgent] [varchar](500) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
	[PreviewURL] [varchar](500) NOT NULL,
	[SurveyVersion] [varchar](50) NOT NULL,
 CONSTRAINT [PK_CollectorResponse] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_CollectorResponse] UNIQUE NONCLUSTERED 
(
	[CollectorResponseExternalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CollectorResponseAnswer]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CollectorResponseAnswer](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[CollectorResponseQuestionId] [bigint] NOT NULL,
	[ChoiceId] [bigint] NULL,
	[IsCorrect] [bit] NOT NULL,
	[Score] [int] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[RowId] [bigint] NULL,
	[ColsId] [bigint] NULL,
	[DownloadURL] [varchar](500) NULL,
	[ContentType] [varchar](500) NULL,
	[TextData] [varchar](500) NULL,
	[TagData] [varchar](500) NULL,
	[SurveyAuditLogAnswerOptionsId] [bigint] NULL,
 CONSTRAINT [PK_CollectorResponseAnswer] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CollectorResponsePage]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CollectorResponsePage](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[SurveyCollectorResponseId] [bigint] NOT NULL,
	[PageId] [bigint] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
 CONSTRAINT [PK_CollectorResponsePage] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CollectorResponseQuestion]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CollectorResponseQuestion](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[CollectorResponsePageId] [bigint] NOT NULL,
	[QuestionId] [bigint] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
 CONSTRAINT [PK_CollectorResponseQuestion] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyAuditLog]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyAuditLog](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[SurveyId] [bigint] NOT NULL,
	[SurveyVersion] [varchar](50) NOT NULL,
	[Title] [varchar](50) NOT NULL,
	[Category] [varchar](50) NULL,
	[Language] [varchar](30) NULL,
	[QuestionCount] [int] NOT NULL,
	[PageCount] [int] NOT NULL,
	[ButtonsText] [varchar](200) NULL,
	[CustomVariables] [varchar](500) NULL,
	[HREF] [varchar](100) NOT NULL,
	[PreviewURL] [varchar](250) NOT NULL,
	[CollectURL] [varchar](250) NULL,
	[EditURL] [varchar](250) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_SurveyAuditLog] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyAuditLogAnswerChoice]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyAuditLogAnswerChoice](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[QuestionId] [bigint] NOT NULL,
	[Position] [int] NOT NULL,
	[Text] [varchar](250) NULL,
	[Visible] [bit] NOT NULL,
	[Weight] [int] NULL,
	[Description] [varchar](100) NULL,
	[Type] [varchar](50) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
	[ChoiceId] [bigint] NULL,
 CONSTRAINT [PK_SurveyAuditLogQuestionOptions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyAuditLogAnswerRow]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyAuditLogAnswerRow](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[QuestionId] [bigint] NOT NULL,
	[Position] [int] NOT NULL,
	[Text] [varchar](250) NULL,
	[Visible] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
	[RowId] [bigint] NULL,
 CONSTRAINT [PK_SurveyAuditLogAnswerRow] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyAuditLogPage]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyAuditLogPage](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[PageExternalId] [bigint] NOT NULL,
	[SurveyAuditLogId] [bigint] NOT NULL,
	[PagePosition] [int] NOT NULL,
	[PageTitle] [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[QuestionCount] [int] NOT NULL,
	[PageData] [varchar](1500) NULL,
	[PageHREF] [varchar](250) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_SurveyAuditLogPage] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyAuditLogQuestion]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyAuditLogQuestion](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[QuestionExternalId] [bigint] NOT NULL,
	[PageId] [bigint] NOT NULL,
	[Position] [int] NOT NULL,
	[HREF] [varchar](500) NOT NULL,
	[Headings] [varchar](500) NULL,
	[Family] [varchar](50) NULL,
	[SubType] [varchar](50) NULL,
	[Required] [bit] NOT NULL,
	[ForcedRanking] [bit] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
	[Visible] [bit] NULL,
	[Sorting] [varchar](10) NULL,
 CONSTRAINT [PK_SurveyAuditLogQuestion] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyCollector]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyCollector](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[CollectorExternalId] [bigint] NOT NULL,
	[SurveyId] [bigint] NOT NULL,
	[SurveyVersion] [varchar](50) NOT NULL,
	[Type] [varchar](50) NULL,
	[Status] [varchar](10) NULL,
	[ResponseCount] [bigint] NOT NULL,
	[RedirectURL] [varchar](250) NOT NULL,
	[HREF] [varchar](250) NOT NULL,
	[URL] [varchar](250) NOT NULL,
	[Name] [varchar](200) NOT NULL,
	[AllowMultipleResponses] [bit] NULL,
	[DisplaySurveyResults] [bit] NULL,
	[ClosedDate] [datetime] NULL,
	[AnonymousType] [varchar](50) NULL,
	[ResponseLimit] [bigint] NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_SurveyCollector] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_SurveyCollector] UNIQUE NONCLUSTERED 
(
	[CollectorExternalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyMaster]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyMaster](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[SurveyExternalId] [bigint] NOT NULL,
	[SurveyTitle] [varchar](50) NOT NULL,
	[SurveyDescription] [varchar](500) NULL,
	[Remarks] [varchar](500) NULL,
	[Status] [varchar](10) NOT NULL,
	[CurrentVersion] [varchar](50) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_SurveyMaster] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_SurveyMaster_SurveyExternalid] UNIQUE NONCLUSTERED 
(
	[SurveyExternalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SurveyTrialQualification]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyTrialQualification](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[SurveyId] [bigint] NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[QualifierScoreRangeFrom] [int] NOT NULL,
	[QualifierScoreRangeTo] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[CreatedBy] [varchar](50) NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_SurveyTrialQualification] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TrialSurveyXRef]    Script Date: 10/4/2019 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrialSurveyXRef](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ProgramId] [bigint] NULL,
	[TrialId] [bigint] NULL,
	[SurveyId] [bigint] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [varchar](50) NULL,
	[ModifiedDate] [datetime] NULL,
	[ModifiedBy] [varchar](50) NULL,
 CONSTRAINT [PK_TrialSurveyXRef] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CollectorResponseAnswer]  WITH CHECK ADD  CONSTRAINT [FK_CollectorResponseAnswer_CollectorResponseQuestion] FOREIGN KEY([CollectorResponseQuestionId])
REFERENCES [dbo].[CollectorResponseQuestion] ([ID])
GO
ALTER TABLE [dbo].[CollectorResponseAnswer] CHECK CONSTRAINT [FK_CollectorResponseAnswer_CollectorResponseQuestion]
GO
ALTER TABLE [dbo].[CollectorResponseAnswer]  WITH CHECK ADD  CONSTRAINT [FK_CollectorResponseAnswer_SurveyAuditLogAnswerOptions] FOREIGN KEY([SurveyAuditLogAnswerOptionsId])
REFERENCES [dbo].[SurveyAuditLogAnswerChoice] ([ID])
GO
ALTER TABLE [dbo].[CollectorResponseAnswer] CHECK CONSTRAINT [FK_CollectorResponseAnswer_SurveyAuditLogAnswerOptions]
GO
ALTER TABLE [dbo].[CollectorResponsePage]  WITH CHECK ADD  CONSTRAINT [FK_CollectorResponsePage_CollectorResponse] FOREIGN KEY([SurveyCollectorResponseId])
REFERENCES [dbo].[CollectorResponse] ([ID])
GO
ALTER TABLE [dbo].[CollectorResponsePage] CHECK CONSTRAINT [FK_CollectorResponsePage_CollectorResponse]
GO
ALTER TABLE [dbo].[CollectorResponsePage]  WITH CHECK ADD  CONSTRAINT [FK_CollectorResponsePage_SurveyAuditLogPage] FOREIGN KEY([PageId])
REFERENCES [dbo].[SurveyAuditLogPage] ([ID])
GO
ALTER TABLE [dbo].[CollectorResponsePage] CHECK CONSTRAINT [FK_CollectorResponsePage_SurveyAuditLogPage]
GO
ALTER TABLE [dbo].[CollectorResponseQuestion]  WITH CHECK ADD  CONSTRAINT [FK_CollectorResponseQuestion_CollectorResponsePage] FOREIGN KEY([CollectorResponsePageId])
REFERENCES [dbo].[CollectorResponsePage] ([ID])
GO
ALTER TABLE [dbo].[CollectorResponseQuestion] CHECK CONSTRAINT [FK_CollectorResponseQuestion_CollectorResponsePage]
GO
ALTER TABLE [dbo].[CollectorResponseQuestion]  WITH CHECK ADD  CONSTRAINT [FK_CollectorResponseQuestion_SurveyAuditLogQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[SurveyAuditLogQuestion] ([ID])
GO
ALTER TABLE [dbo].[CollectorResponseQuestion] CHECK CONSTRAINT [FK_CollectorResponseQuestion_SurveyAuditLogQuestion]
GO
ALTER TABLE [dbo].[SurveyAuditLog]  WITH CHECK ADD  CONSTRAINT [FK_SurveyAuditLog_SurveyMaster] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[SurveyMaster] ([ID])
GO
ALTER TABLE [dbo].[SurveyAuditLog] CHECK CONSTRAINT [FK_SurveyAuditLog_SurveyMaster]
GO
ALTER TABLE [dbo].[SurveyAuditLogAnswerChoice]  WITH CHECK ADD  CONSTRAINT [FK_SurveyAuditLogQuestionOptions_SurveyAuditLogQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[SurveyAuditLogQuestion] ([ID])
GO
ALTER TABLE [dbo].[SurveyAuditLogAnswerChoice] CHECK CONSTRAINT [FK_SurveyAuditLogQuestionOptions_SurveyAuditLogQuestion]
GO
ALTER TABLE [dbo].[SurveyAuditLogPage]  WITH CHECK ADD  CONSTRAINT [FK_SurveyAuditLogPage_SurveyAuditLog] FOREIGN KEY([SurveyAuditLogId])
REFERENCES [dbo].[SurveyAuditLog] ([ID])
GO
ALTER TABLE [dbo].[SurveyAuditLogPage] CHECK CONSTRAINT [FK_SurveyAuditLogPage_SurveyAuditLog]
GO
ALTER TABLE [dbo].[SurveyAuditLogQuestion]  WITH CHECK ADD  CONSTRAINT [FK_SurveyAuditLogQuestion_SurveyAuditLogPage] FOREIGN KEY([PageId])
REFERENCES [dbo].[SurveyAuditLogPage] ([ID])
GO
ALTER TABLE [dbo].[SurveyAuditLogQuestion] CHECK CONSTRAINT [FK_SurveyAuditLogQuestion_SurveyAuditLogPage]
GO
ALTER TABLE [dbo].[SurveyCollector]  WITH CHECK ADD  CONSTRAINT [FK_SurveyCollector_SurveyMaster] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[SurveyMaster] ([ID])
GO
ALTER TABLE [dbo].[SurveyCollector] CHECK CONSTRAINT [FK_SurveyCollector_SurveyMaster]
GO
ALTER TABLE [dbo].[SurveyTrialQualification]  WITH CHECK ADD  CONSTRAINT [FK_SurveyTrialQualification_SurveyMaster] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[SurveyMaster] ([ID])
GO
ALTER TABLE [dbo].[SurveyTrialQualification] CHECK CONSTRAINT [FK_SurveyTrialQualification_SurveyMaster]
GO
ALTER TABLE [dbo].[SurveyTrialQualification]  WITH CHECK ADD  CONSTRAINT [FK_SurveyTrialQualification_SurveyTrialQualification] FOREIGN KEY([ID])
REFERENCES [dbo].[SurveyTrialQualification] ([ID])
GO
ALTER TABLE [dbo].[SurveyTrialQualification] CHECK CONSTRAINT [FK_SurveyTrialQualification_SurveyTrialQualification]
GO
ALTER TABLE [dbo].[TrialSurveyXRef]  WITH CHECK ADD  CONSTRAINT [FK_TrialSurveyXRef_TrialSurveyXRef] FOREIGN KEY([SurveyId])
REFERENCES [dbo].[SurveyMaster] ([ID])
GO
ALTER TABLE [dbo].[TrialSurveyXRef] CHECK CONSTRAINT [FK_TrialSurveyXRef_TrialSurveyXRef]
GO
