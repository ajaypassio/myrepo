ALTER TABLE Criteria ADD InclusionCriteria text; 
ALTER TABLE Criteria ADD ExclusionCriteria text;