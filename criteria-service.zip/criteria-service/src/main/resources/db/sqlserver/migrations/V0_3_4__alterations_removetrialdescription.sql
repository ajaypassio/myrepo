ALTER TABLE ClinicalTrial DROP CONSTRAINT df_constraint_td;
DROP INDEX udx_ClinicalTrial_tsCode_tName ON ClinicalTrial;
ALTER TABLE ClinicalTrial DROP COLUMN TrialShortCode;
ALTER TABLE ClinicalTrial DROP COLUMN TrialDescription; 