GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [udx_ClinicalTrial_tsCode_tName]    Script Date: 11/19/2019 5:55:10 PM ******/
CREATE NONCLUSTERED INDEX [udx_ClinicalTrial_tsCode_tName] ON [dbo].[ClinicalTrial]
(
	[TrialName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO