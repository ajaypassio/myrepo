SET IDENTITY_INSERT [dbo].[TrialStatus] ON 

INSERT [dbo].[TrialStatus] ([TrialStatusId], [TrialStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (6, N'Initiated', 1, CAST(N'2017-10-12T00:00:00.000' AS DateTime), 1, CAST(N'2017-10-12T00:00:00.000' AS DateTime))
SET IDENTITY_INSERT [dbo].[TrialStatus] OFF