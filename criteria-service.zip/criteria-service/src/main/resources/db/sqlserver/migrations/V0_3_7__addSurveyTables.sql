USE [pdr_criteria_prod]
GO
/****** Object:  Table [dbo].[SurveyAssociation]    Script Date: 07/5/2020 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyAssociations](
    [Id] [bigint] IDENTITY(1,1) NOT NULL,
	[SprinttSurveyId] [bigint] NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[ProgramId] [bigint] NULL,
	[SprinttSurveyStatus] [tinyint] NOT NULL,
	[Remarks] [varchar](255) NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
 CONSTRAINT [PK_SurveyAssociation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
)
GO
/****** Object:  Table [dbo].[SurveyMaster]    Script Date: 20/4/2020 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyMaster](    
	[SprinttSurveyId] [bigint] IDENTITY(1,1) NOT NULL,	
	[SurveyId] [varchar](100) NOT NULL,
	[SurveyTitle] [varchar](100) NOT NULL,
	[SurveyDescription] [varchar](500) NULL,	
	[SurveyStatus] [tinyint] NOT NULL,	
	[SurveyToolId] [tinyint] NOT NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
CONSTRAINT [PK_SurveyMaster] PRIMARY KEY CLUSTERED 
(
	[SprinttSurveyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
)
GO
/****** Object:  Table [dbo].[SurveyTool]    Script Date: 23/4/2020 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyTool](
	[SurveyToolId] [tinyint] IDENTITY(1,1) NOT NULL,	
	[SurveyToolName] [varchar](100) NOT NULL,	
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,	
 CONSTRAINT [PK_SurveyTool] PRIMARY KEY CLUSTERED 
(
	[SurveyToolId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
)
GO
/****** Object:  Table [dbo].[SurveyStatus]    Script Date: 23/4/2020 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyStatus](
	[SurveyStatusId] [tinyint] IDENTITY(1,1) NOT NULL,	
	[SurveyStatus] [varchar](100) NULL,
	[Type] [varchar](20) NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,	
 CONSTRAINT [PK_SurveyStatus] PRIMARY KEY CLUSTERED 
(
	[SurveyStatusId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
)
GO
/****** Object:  Table [dbo].[SurveyShowHide]    Script Date: 23/4/2020 12:28:01 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SurveyShowHide](
	[Id] [int] IDENTITY(1,1) NOT NULL,	
	[Preference] [varchar](100) NULL,
	[Defualt] [tinyint] NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,	
 CONSTRAINT [PK_SurveyShowHide] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY] 
)
GO
INSERT INTO [dbo].[SurveyStatus] ([SurveyStatus],[Type],[CreatedBy],[CreatedOn]) VALUES ('DRAFT' ,'SurveyStatus','TestAdmin' ,GETDATE());
INSERT INTO [dbo].[SurveyStatus] ([SurveyStatus],[Type],[CreatedBy],[CreatedOn]) VALUES ('PUBLISHED' ,'SurveyStatus','TestAdmin' ,GETDATE());
INSERT INTO [dbo].[SurveyStatus] ([SurveyStatus],[Type],[CreatedBy],[CreatedOn]) VALUES ('ACTIVE' ,'SprinttSurveyStatus','TestAdmin' ,GETDATE());
INSERT INTO [dbo].[SurveyStatus] ([SurveyStatus],[Type],[CreatedBy],[CreatedOn]) VALUES ('INACTIVE' ,'SprinttSurveyStatus','TestAdmin' ,GETDATE());
INSERT INTO [dbo].[SurveyTool] ([SurveyToolName],[CreatedBy],[CreatedOn]) VALUES ('QUALTRICS','TestAdmin',GetDate());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Program' ,1,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Trials' ,0,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('SurveyTitle' ,1,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Sponsor' ,1,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Date Created' ,0,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Created By' ,0,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Data Modified' ,0,'TestAdmin',GETDATE());
GO