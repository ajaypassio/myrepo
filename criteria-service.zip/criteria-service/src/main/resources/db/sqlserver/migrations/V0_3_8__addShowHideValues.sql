USE [pdr_criteria_prod]
GO
update [dbo].[SurveyShowHide] set Preference ='Trial Name', Defualt=1 where id=2
update [dbo].[SurveyShowHide] set Preference ='Survey Title' where id=3
update [dbo].[SurveyShowHide] set Defualt =0 where id=4
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Questionnaire ID' ,1,'TestAdmin',GETDATE());
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Status' ,1,'TestAdmin',GETDATE());
GO