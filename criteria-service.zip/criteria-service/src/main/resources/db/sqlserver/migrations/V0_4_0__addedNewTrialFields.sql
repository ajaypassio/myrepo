ALTER TABLE ClinicalTrial ADD PatientHeadline VARCHAR (70);
ALTER TABLE ClinicalTrial ADD MessageToPatient VARCHAR (275);