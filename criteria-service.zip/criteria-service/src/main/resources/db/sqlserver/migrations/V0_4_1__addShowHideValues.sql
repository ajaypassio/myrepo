USE [pdr_criteria_prod]
GO
INSERT INTO [dbo].[SurveyShowHide]  ([Preference],[Defualt],[CreatedBy],[CreatedOn]) VALUES ('Version' ,1,'TestAdmin',GETDATE());
GO