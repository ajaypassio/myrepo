USE [pdr_criteria_prod]
GO
ALTER TABLE [dbo].[SurveyShowHide] ADD Sequence INT ;
GO

USE [pdr_criteria_prod]
GO
update [dbo].[SurveyShowHide] set Sequence='1' where Preference ='Program' ;
update [dbo].[SurveyShowHide] set Sequence='2' where Preference ='Trial Name' ;
update [dbo].[SurveyShowHide] set Sequence='3' where Preference ='Survey Title' ;
update [dbo].[SurveyShowHide] set Sequence='4' where Preference ='Version' ;
update [dbo].[SurveyShowHide] set Sequence='5' where Preference ='Sponsor' ;
update [dbo].[SurveyShowHide] set Sequence='6' where Preference ='Date Created' ;
update [dbo].[SurveyShowHide] set Sequence='7' where Preference ='Created By' ;
update [dbo].[SurveyShowHide] set Sequence='8' where Preference ='Data Modified' ;
update [dbo].[SurveyShowHide] set Sequence='9' where Preference ='Questionnaire ID' ;
update [dbo].[SurveyShowHide] set Sequence='10' where Preference ='Status' ;


GO





