USE [pdr_criteria_prod]
GO
ALTER TABLE  dbo.SurveyMaster ADD UNIQUE (SurveyId);
GO