ALTER TABLE ClinicalTrial DROP COLUMN PatientHeadline;
ALTER TABLE ClinicalTrial DROP COLUMN MessageToPatient;