GO



/****** Object:  Table [dbo].[PhysicianCriteria]    Script Date: 7/6/2021 5:48:07 PM ******/

SET ANSI_NULLS ON

GO



SET QUOTED_IDENTIFIER ON

GO



CREATE TABLE [dbo].[PhysicianCriteria](

                [CriteriaId] [bigint] NULL,       

                [QueryName] [nvarchar](100) NOT NULL,

                [UserName] [varchar](100) NOT NULL,

                [InclusionCriteria] [text] NULL,
                           
                [PhysicianLocation] [text] NULL,

                [StatusId] [bigint] NOT NULL,

                [TotalPhysicianCount] INT NULL,
                
                [Count1572] INT NULL,
                
                [CountQuest] INT NULL,
                 
                [CountQuestAnd1572] INT NULL,

                [TotalPatientsCount] INT NULL,

                [IsCountClicked] tinyInt NULL,

                [Remarks] [nvarchar](250) NULL,

                [CreatedOn] [datetime2](0) NULL,          

                [UpdatedOn] [datetime2](0) NULL,

PRIMARY KEY CLUSTERED

(

                [UserName] ASC

)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO