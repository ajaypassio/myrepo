// package com.avigosolutions.criteriaservice.controllers;

// import java.io.IOException;

// import org.junit.runner.RunWith;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.test.context.web.WebAppConfiguration;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;
// import org.springframework.web.context.WebApplicationContext;

// import com.avigosolutions.criteriaservice.controllers.ClinicalTrialController;
// import com.avigosolutions.criteriaservice.controllers.CollaboratorController;
// import com.avigosolutions.criteriaservice.controllers.CriteriaController;
// import com.avigosolutions.criteriaservice.controllers.ProgramController;
// import com.avigosolutions.criteriaservice.controllers.QuestionController;
// import com.avigosolutions.criteriaservice.controllers.QuestionnaireController;
// import com.avigosolutions.criteriaservice.controllers.TrialLookupController;
// import com.avigosolutions.criteriaservice.model.StudySite;
// import com.fasterxml.jackson.core.JsonParseException;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.DeserializationFeature;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.fasterxml.jackson.databind.ObjectMapper;

// @RunWith(SpringRunner.class)
// @SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
// @WebAppConfiguration
// public abstract class AbstractControllerTest {
// 	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
// 	@Autowired
// 	protected WebApplicationContext webApplicationContext;
	
// 	protected MockMvc mockMvc;

// 	protected void setUp() {
// 		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
// 	}
	
// 	protected void setUp(ClinicalTrialController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(PatientPortalController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(ProgramController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(CollaboratorController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(TrialLookupController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(QuestionnaireController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
// 	protected void setUp(QuestionController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
// 	protected void setUp(CriteriaController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(StudySite controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
	
// 	protected void setUp(StudysiteController controller) {
// 		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	}
// 	protected String mapToJson(Object obj) throws JsonProcessingException {
// 		ObjectMapper mapper = new ObjectMapper();
// 		return mapper.writeValueAsString(obj);
// 	}
	
// 	protected <T> T mapFromJson (String json, Class<T> clazz)
// 	throws JsonParseException, JsonMappingException, IOException {
// 		ObjectMapper mapper = new ObjectMapper();
// 		// https://stackoverflow.com/questions/4486787/jackson-with-json-unrecognized-field-not-marked-as-ignorable
// 		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
// 		return mapper.readValue(json, clazz);
// 	}
	
// }
