// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.TrialLookupController;
// import com.avigosolutions.criteriaservice.model.Phase;
// import com.avigosolutions.criteriaservice.model.Sponsor;
// import com.avigosolutions.criteriaservice.model.TrialStatus;
// import com.avigosolutions.criteriaservice.service.ClinicalTrialService;

// @Transactional
// @SpringBootTest
// @ActiveProfiles("test")
// public class ClinicalTrialLookupMockTest extends AbstractControllerTest {
	
// 	@Mock
// 	private ClinicalTrialService trialService;
	
// 	@InjectMocks
// 	private TrialLookupController controller;
	
// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
// 		setUp(controller);
// 	}
	
// 	/*@Test
// 	public void testGetAllSponsors() throws Exception {
// 		List<Sponsor> list = getSponsorsListStubData();
		
// 		when(trialService.getAllSponsors()).thenReturn(list);
		
// 		String uri = "/trials/lookup/sponsors";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).getAllSponsors();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetAllPhases() throws Exception {
// 		List<Phase> list = getPhaseListStubData();
		
// 		when(trialService.getAllPhases()).thenReturn(list);
		
// 		String uri = "/trials/lookup/phases";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).getAllPhases();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// */	@Test
// 	public void testGetAllTrialStatuses() throws Exception {
// 		List<TrialStatus> list = getTrialStatusListStubData();
		
// 		when(trialService.getAllTrialStatuses()).thenReturn(list);
		
// 		String uri = "/trials/lookup/trialstatuses";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).getAllTrialStatuses();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	private List<Sponsor> getSponsorsListStubData() {
// 		List<Sponsor> list = new ArrayList<>();
// 		Sponsor entity1 = new Sponsor().withName("Astra Zeneca");
// 		Sponsor entity2 = new Sponsor().withName("Quintiles IMS");
// 		list.add(entity1);
// 		list.add(entity2);
// 		return list;
// 	}
	
// 	private List<Phase> getPhaseListStubData() {
// 		List<Phase> list = new ArrayList<>();
// 		Phase entity1 = new Phase().withName("Phase I");
// 		Phase entity2 = new Phase().withName("Phase II");
// 		list.add(entity1);
// 		list.add(entity2);
// 		return list;
// 	}
// 	private List<TrialStatus> getTrialStatusListStubData() {
// 		List<TrialStatus> list = new ArrayList<>();
// 		TrialStatus entity1 = new TrialStatus().withName("Active");
// 		TrialStatus entity2 = new TrialStatus().withName("On Hold");
// 		list.add(entity1);
// 		list.add(entity2);
// 		return list;
// 	}

// }
