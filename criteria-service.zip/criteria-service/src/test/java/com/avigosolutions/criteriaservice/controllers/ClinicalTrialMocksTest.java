// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.ClinicalTrialController;
// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.service.ClinicalTrialService;

// @Transactional
// @SpringBootTest
// @ActiveProfiles("test")
// public class ClinicalTrialMocksTest extends AbstractControllerTest {
	
// 	private Long magicClinicalTrialId = new Long(100);
// 	@Mock
// 	private ClinicalTrialService trialService;
	
// 	@InjectMocks
// 	private ClinicalTrialController controller;
	
// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
// 		setUp(controller);
// 	}
	
// 	@Test
// 	public void testGetAllTrials() throws Exception {
// 		List<ClinicalTrial> list = getTrialListStubData();
		
// 		when(trialService.findAll()).thenReturn(list);
		
// 		String uri = "/trials/all";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).findAll();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneClinicalTrial() throws Exception {
// 		ClinicalTrial trial = getTrialStubData();
// 		Long id = trial.getTrialId();
		
// 		when(trialService.findOne(id)).thenReturn(trial);
		
// 		String uri = "/trials/{id}";
		
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri,id).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).findOne(id);
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneClinicalTrialNotFound() throws Exception {
// 		String uri = "/trials/{id}";
// 		Long id = Long.MAX_VALUE;
// 		when(trialService.findOne(id)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri, id)
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(trialService, times(1)).findOne(id);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testCreateClinicalTrial() throws Exception {
// 		String uri = "/trials/add";
// 		ClinicalTrial clinicalTrial = getTrialStubData();
// 		ResponseObjectModel respObj = new ResponseObjectModel();
// 		respObj.setStatus(200);
// 		when(trialService.save(any(ClinicalTrial.class))).thenReturn(respObj);
		
// 		String jsonStr = mapToJson(clinicalTrial);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.post(uri)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		ResponseObjectModel savedTrial = super.mapFromJson(content, ResponseObjectModel.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).save(any(ClinicalTrial.class));
// 		logger.info("toString: " + savedTrial.toString());
// 		Assert.assertEquals("failure - expected 201", 201, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);	
// 		Assert.assertEquals("failure - expected greeting status 200", 200, savedTrial.getStatus());
// 	}
// 	/*
// 	@Test
// 	public void testUpdateClinicalTrial() throws Exception {
// 		String uri = "/api/v1/trials/{id}";
// 		ClinicalTrial clinicalTrial = getTrialStubData();
// 		//Long id = clinicalTrial.getId();
// 		Long id = clinicalTrial.getTrialId();
		
// 		when(trialService.update(any(ClinicalTrial.class))).thenReturn(Optional.of(clinicalTrial));
		
// 		String jsonStr = mapToJson(clinicalTrial);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.put(uri, id)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		ClinicalTrial updatedClinicalTrial = super.mapFromJson(content, ClinicalTrial.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).update(any(ClinicalTrial.class));
		
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 		Assert.assertNotNull("failure ClinicalTrial updated and not returned", updatedClinicalTrial);
// 	}
	
// 	@Test
// 	public void testUpdateClinicalTrialNotFound() throws Exception {
// 		String uri = "/api/v1/trials/{id}";
// 		Long id = Long.MAX_VALUE;
// 		ClinicalTrial clinicalTrial = getTrialStubData();
		
// 		when(trialService.update(any(ClinicalTrial.class)))
// 			.thenReturn(Optional.empty());
		
// 		String jsonStr = mapToJson(clinicalTrial);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.put(uri, id)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(trialService, times(1)).update(any(ClinicalTrial.class));
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 200", 500, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	*/@Test
// 	public void testDeleteClinicalTrial() throws Exception {
// 		String uri = "/trials/delete/{id}";
		
// 		//ClinicalTrial clinicalTrial = getTrialStubData();
		
// 		// Mockito doesn't account for methods like delete which returns void
// 		// No need for when()
		
// 		//String jsonStr = mapToJson(clinicalTrial);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.delete(uri, magicClinicalTrialId)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							)
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(trialService, times(1)).delete(any(Long.class));
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	private List<ClinicalTrial> getTrialListStubData() {
// 		List<ClinicalTrial> list = new ArrayList<>();
// 		list.add(getTrialStubData());
		
// 		return list;
// 	}

// 	private ClinicalTrial getTrialStubData() {
// 		ClinicalTrial entity =  new ClinicalTrial().withTrialName("JUnit Mock Trial")
// 												  .withTrialId(magicClinicalTrialId);
// 		entity.withProgramId(2l).withProgram(new Program().withProgramId(2l).withName("Test Program"));
// 		return entity;
// 	}

// }
