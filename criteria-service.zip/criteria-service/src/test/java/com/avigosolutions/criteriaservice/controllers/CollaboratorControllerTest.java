// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.CollaboratorController;
// import com.avigosolutions.criteriaservice.model.Collaborator;
// import com.avigosolutions.criteriaservice.service.CollaboratorService;

// @Transactional
// @SpringBootTest
// @ActiveProfiles("test")
// public class CollaboratorControllerTest extends AbstractControllerTest {
	
// 	private long collaboratorId = 2L;
// 	@Mock
// 	private CollaboratorService collaboratorService;
	
// 	@InjectMocks
// 	private CollaboratorController controller;
	
// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
		
// 		setUp(controller);
// 	}
	
// 	@Test
// 	public void testGetAllCollaborators() throws Exception {
// 		List<Collaborator> list = getCollaboratorListStubData();
		
// 		when(collaboratorService.findAll()).thenReturn(list);
		
// 		String uri = "/collaborators/all";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(collaboratorService, times(1)).findAll();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneCollaborator() throws Exception {
// 		Collaborator collaborator = getCollaboratorStubData(collaboratorId);
// 		Long id = collaborator.getId();
		
// 		when(collaboratorService.findOne(id)).thenReturn(collaborator);
		
// 		String uri = "/collaborators/{id}";
		
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri,id).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(collaboratorService, times(1)).findOne(id);
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneCollaboratorNotFound() throws Exception {
// 		String uri = "/collaborators/{id}";
// 		Long id = Long.MAX_VALUE;
// 		when(collaboratorService.findOne(id)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri, id)
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(collaboratorService, times(1)).findOne(id);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testCreateCollaborator() throws Exception {
// 		String uri = "/collaborators/add";
		
// 		Collaborator createdCollaboratorMock = getCollaboratorStubData(collaboratorId);
		
// 		when(collaboratorService.save(any(Collaborator.class))).thenReturn(createdCollaboratorMock);
		
// 		Collaborator collaborator = getCollaboratorStubData(collaboratorId);
// 		String jsonStr = mapToJson(collaborator);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.post(uri)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		Collaborator savedCollaborator = super.mapFromJson(content, Collaborator.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(collaboratorService, times(1)).save(any(Collaborator.class));
// 		logger.info("toString: " + savedCollaborator.toString());
// 		Assert.assertEquals("failure - expected 201", 201, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);	
// 		Assert.assertEquals("failure - expected ", collaboratorId, savedCollaborator.getId().longValue());
// 	}
	
// 	@Test
// 	public void testUpdateCollaborator() throws Exception {
// 		String uri = "/collaborators/add/{id}";
// 		Collaborator collaborator = getCollaboratorStubData(collaboratorId);
// 		//Long id = Collaborator.getId();
// 		Long id = collaborator.getId();
		
// 		when(collaboratorService.update(any(Collaborator.class))).thenReturn(Optional.of(collaborator).get());
		
// 		String jsonStr = mapToJson(collaborator);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.put(uri, id)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		Collaborator updatedCollaborator = super.mapFromJson(content, Collaborator.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(collaboratorService, times(1)).update(any(Collaborator.class));
		
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 		Assert.assertNotNull("failure Collaborator updated and not returned", updatedCollaborator);
// 	}
	
	
// 	private List<Collaborator> getCollaboratorListStubData() {
// 		List<Collaborator> list = new ArrayList<>();
// 		list.add(getCollaboratorStubData(2l));
		
// 		return list;
// 	}

// 	private Collaborator getCollaboratorStubData(Long pId) {
// 		Collaborator entity = new Collaborator().withName("JUnit Mock Collaborator")
// 												  .withCollaboratorId(pId).withCollaboratorTypeId(2l);
// 		return entity;
// 	}
// }
