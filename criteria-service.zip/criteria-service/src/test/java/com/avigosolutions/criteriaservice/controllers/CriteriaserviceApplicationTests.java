// package com.avigosolutions.criteriaservice.controllers;

// import java.util.ArrayList;
// import java.util.Date;
// import java.util.List;
// import java.util.Optional;

// import org.junit.After;
// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Criteria;
// import com.avigosolutions.criteriaservice.model.CriteriaTemplate;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
// import com.avigosolutions.criteriaservice.service.CriteriaService;
// import com.avigosolutions.criteriaservice.service.CriteriaTemplateService;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class CriteriaserviceApplicationTests {

// 	@Autowired
// 	private CriteriaService criteriaService;
	
// 	@Autowired
// 	private ClinicalTrialService clinicalTrialService;
	
// 	@Autowired
// 	private CriteriaTemplateService criteriaTemplateService;
	
	
// 	private static final Long DEFAULT_TRAIL_ID = 10L;
// 	private Long criteriaTemplateId;
// 	private Long criteriaId;
	
// 	//@Test
// 	public void contextLoads() {
// 	}
	
// 	@Before
// 	public void setup() {
// 		CriteriaTemplate initialTemplate = new CriteriaTemplate().withTemplateName("Test Criteria Template");
// 		CriteriaTemplate crt =(CriteriaTemplate) criteriaTemplateService.save(initialTemplate).getData();
// 		criteriaTemplateId = crt.getTemplateId();
		
// 		Criteria sampleCriteria = new Criteria().withCriteriaDescription("Sample Criteria Desc")
// 				  .withCriteriaName("Sample Criteria JUnit")
// 				  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 						  	"\"class\": \"age\"," +
// 						  	"\"operator\": \"in_range\"," +
// 						  	"\"min\": \"17\"," +
// 						  	"\"max\": \"70\"" +
// 						  	" }")
// 				  .withTrialId(new Long(10))
// 				  .withIsInclude(false)
// 				  .withIsDeleted(true);
// 		Criteria sc = criteriaService.save(sampleCriteria);
// 		criteriaId = sc.getId();
		
// 	}
	
// 	@After
// 	public void tearDown() {
		
// 	}
	
// 	@Test
// 	public void testFindAllCriteria() {
// 		List<Criteria> list = criteriaService.findAll();
// 		Assert.assertNotNull("failure, collection not expected to be null", list);
// 	}
	
// 	@Test
// 	public void testFindOneCriteria() {		
// 		Criteria criteria = criteriaService.findOne(criteriaId);
		
// 		Assert.assertNotNull("failure, findOne Criteria not expected to be null", criteria);
// 		//Assert.assertEquals("failure expected Criteria id of 1", id, criteria.getCriteriaId());
// 	}
	
	
// 	@Rollback 
// 	@Test
// 	public void testCreateCriteria() {
		
// 		Criteria criteria = new Criteria().withCriteriaDescription("Criteria Desc")
// 										  .withCriteriaName("Criteria JUnit")
// 										  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 												  	"\"class\": \"age\"," +
// 												  	"\"operator\": \"in_range\"," +
// 												  	"\"min\": \"17\"," +
// 												  	"\"max\": \"70\"" +
// 												  	" }")
// 										  .withTrialId(new Long(1))
// 										  .withIsInclude(false)
// 										  .withIsDeleted(true);
// 		Criteria c2 = criteriaService.save(criteria);
		
// 		Assert.assertNotNull("failure, criteria create", c2);
// 		Assert.assertTrue("testCreateCriteria should have an id > 3", c2.getCriteriaId() > 3);
// 		//Assert.assertEquals("Criteria should have an id of 8", id, criteria.getCriteriaId());
// 	    Assert.assertTrue(criteria.getIsDeleted());
// 	    Assert.assertFalse(criteria.getIsInclude());
// 		//logger.info(criteria.toString());
									
// 	}
		
	
// 	@Rollback
// 	@Test
// 	public void testCreateCriteriaWithPrexistingTrial() {
		
// 		Long trialId = new Long(10);
// 		ClinicalTrial trial = clinicalTrialService.findOne(trialId);
		
// 		Criteria criteria = new Criteria().withCriteriaDescription("Criteria PreExistingtrial")
// 										  .withCriteriaName("Criteria with PreExistingtrial")
// 										  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 												  	"\"class\": \"age\"," +
// 												  	"\"operator\": \"in_range\"," +
// 												  	"\"min\": \"17\"," +
// 												  	"\"max\": \"70\"" +
// 												  	" }")
// 										  .withTrialId(trialId)
// 										  .withClinicalTrial(trial)
// 										  .withIsInclude(false)
// 										  .withIsDeleted(true);
// 		Criteria savedCriteria = criteriaService.save(criteria);
		
// 		Assert.assertNotNull("failure, criteria create", savedCriteria);
// //		Long criteriaId = 5L;
// //		Assert.assertEquals("Criteria should have an id of 5", criteriaId, savedCriteria.getCriteriaId());
// 		Assert.assertTrue("testCreateCriteria should have an id > 3", savedCriteria.getCriteriaId() > 3);
// 		Assert.assertEquals("Criteria should have same trial id",trialId, savedCriteria.getTrialId());
// 	    Assert.assertTrue(savedCriteria.getIsDeleted());
// 	    Assert.assertFalse(savedCriteria.getIsInclude());
// 		//logger.info(criteria.toString());
									
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testUpdateCriteria() {
		
// 		Criteria criteria = new Criteria().withCriteriaId(344L) 
// 									      .withCriteriaDescription("Criteria Desc Junit")
// 										  .withCriteriaName("Criteria JUnit")
// 										  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 												  	"\"class\": \"age\"," +
// 												  	"\"operator\": \"in_range\"," +
// 												  	"\"min\": \"800\"," +
// 												  	"\"max\": \"70000\"" +
// 												  	" }")
// 										  .withTrialId(new Long(1))
// 										  .withIsInclude(true)
// 										  .withIsDeleted(false);
// 		Criteria c2 = criteriaService.update(criteria);
// 		Assert.assertNotNull("failure, criteria create", c2);
// 		Long id = 344L;
// 		Assert.assertEquals("Criteria should have an id of 4", id, c2.getCriteriaId());
// 	    Assert.assertFalse(c2.getIsDeleted());
// 	    Assert.assertTrue(c2.getIsInclude());
// 		//logger.info(criteria.toString());
									
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateCriteriaWithoutCriteriaId() {
		
// 		Criteria criteria = new Criteria()
// 									      .withCriteriaDescription("Criteria Desc Junit")
// 										  .withCriteriaName("Criteria JUnit")
// 										  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 												  	"\"class\": \"age\"," +
// 												  	"\"operator\": \"in_range\"," +
// 												  	"\"min\": \"800\"," +
// 												  	"\"max\": \"70000\"" +
// 												  	" }")
// 										  .withTrialId(new Long(10))
// 										  .withIsInclude(true)
// 										  .withIsDeleted(false);
// 		Criteria c2 = criteriaService.update(criteria);
		
// 		Assert.assertNull("failure, testUpdateCriteriaWithoutCriteriaId", c2);
	    
// 		//logger.info(criteria.toString());
									
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateCriteria_withInvalidCriteriaId() {
		
// 		Criteria criteria = new Criteria().withCriteriaId(Long.MAX_VALUE)				
// 									      .withCriteriaDescription("Criteria Desc Junit")
// 										  .withCriteriaName("Criteria JUnit")
// 										  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 												  	"\"class\": \"age\"," +
// 												  	"\"operator\": \"in_range\"," +
// 												  	"\"min\": \"800\"," +
// 												  	"\"max\": \"70000\"" +
// 												  	" }")
// 										  .withTrialId(new Long(10))
// 										  .withIsInclude(true)
// 										  .withIsDeleted(false);
// 		Criteria c2 = criteriaService.update(criteria);
		
// 		Assert.assertNull("failure, testUpdateCriteria_withInvalidCriteriaId", c2);
	   
									
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateCriteriaWithNullTrialId() {
// 		Criteria criteria = new Criteria()
// 									      .withCriteriaDescription("Criteria Null Trial Id")
// 										  .withCriteriaName("Criteria JUnit")
// 										  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 												  	"\"class\": \"age\"," +
// 												  	"\"operator\": \"in_range\"," +
// 												  	"\"min\": \"800\"," +
// 												  	"\"max\": \"70000\"" +
// 												  	" }")										 
// 										  .withIsInclude(false)
// 										  .withIsDeleted(true);
// 		Criteria c2 = criteriaService.update(criteria);
// 		Assert.assertNull("failure, testUpdateCriteriaWithNullTrialId", c2);
// 	}
	
// 	@Test
// 	public void testGetCriteriaWithTrialId() {
		
// 		Long id = new Long(10);
// 		List<Criteria> criterias = criteriaService.findByTrialId(id);
		
// 		Assert.assertNotNull("failure, findByTrialId Criteria not expected to be null", criterias);
		
									
// 	}
	

	
// 	@Rollback
// 	@Test 
// 	public void testDeleteCriteria() {
// 		Long id = 2L;
// 		criteriaService.delete(id);
// 		Criteria c = criteriaService.findOne(id);		
// 		Assert.assertNull("failure, Criteria expected to be null after delete", c);
// 	}
	
// 	@Test
// 	public void testFindAllTrials() {
// 		List<ClinicalTrial> list = clinicalTrialService.findAll();
// 		Assert.assertNotNull("failure, collection not expected to be null", list);
// 	}
// 	@Test
// 	public void testFindOneClinicalTrial() {
// 		Long id = new Long(DEFAULT_TRAIL_ID);
// 		ClinicalTrial trial = clinicalTrialService.findOne(id);
		
// 		Assert.assertNotNull("failure, findOne Criteria not expected to be null", trial);
// 		//Assert.assertEquals("failure expected Criteria id of 1", id, criteria.getCriteriaId());
// 	}
	
// 	@Test
// 	public void testFindClinicalTrialWithAttributes() {
// 		Long id = new Long(DEFAULT_TRAIL_ID);
// 		ClinicalTrial trial = clinicalTrialService.findOne(id);
		
// 		Assert.assertNotNull("failure, find ClinicalTrial with Attributes not expected to be null", trial);
// 		Assert.assertNotNull("failure, find ClinicalTrial with Attributes, TrialStatus not expected to be null", trial.getTrialStatus());		
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testCreateClinicalTrial() {
// 		ClinicalTrial trial = new ClinicalTrial().withTrialName("JUnit Trial");
// 		ResponseObjectModel t2 = clinicalTrialService.save(trial);
// 		Assert.assertNotNull("failure, criteria create", t2);
// 		//Long id = 6L;
// 		//Assert.assertEquals("Criteria should have an id of 6", id, t2.getTrialId());
// 		Assert.assertTrue("testCreateClinicalTrial should have an id > 3", ((ClinicalTrial) t2.getData()).getTrialId() > 3);
// 		//logger.info(criteria.toString());
									
// 	}
	

// 	@Test
// 	public void testCreateClinicalTrialWithAttributes() {
// 		ClinicalTrial trial = new ClinicalTrial().withTrialName("Clinical Trial With Attributes");
									
	    		 
// 		ResponseObjectModel t2 = clinicalTrialService.save(trial);
		
// 		Assert.assertNotNull("failure, criteria create", t2);
// 		//Long id = 6L;
// 		//Assert.assertEquals("Criteria should have an id of 6", id, t2.getTrialId());
// 		Assert.assertTrue("testCreateClinicalTrialWithAttributes should have an id > 3", ((ClinicalTrial) t2.getData()).getTrialId() > 3);
// 		//logger.info(criteria.toString());
									
// 	}
	
// 	/*@Rollback
// 	@Test
// 	public void testCreateClinicalTrialWithCriterias() {
// 		ClinicalTrial trial = new ClinicalTrial().withTrialName("Trial with Criteria list");
// 		Criteria criteria1 = new Criteria()
// 			      .withCriteriaDescription("Criteria 1 with trial")
// 				  .withCriteriaName("Criteria with Trial 1")
// 				  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 						  	"\"class\": \"age\"," +
// 						  	"\"operator\": \"in_range\"," +
// 						  	"\"min\": \"800\"," +
// 						  	"\"max\": \"70000\"" +
// 						  	" }")										 
// 				  .withIsInclude(false)
// 				  .withIsDeleted(true);
// 		Criteria criteria2 = new Criteria()
// 			      .withCriteriaDescription("Criteria 2 with trial")
// 				  .withCriteriaName("Criteria with Trial 2")
// 				  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 						  	"\"class\": \"age\"," +
// 						  	"\"operator\": \"in_range\"," +
// 						  	"\"min\": \"800\"," +
// 						  	"\"max\": \"70000\"" +
// 						  	" }")										 
// 				  .withIsInclude(false)
// 				  .withIsDeleted(true);
// 		Set<Criteria> criterias = new HashSet<Criteria>();
// 		criterias.add(criteria1);
// 		criterias.add(criteria2);
// 		trial.withCriterias(criterias);
// 		ClinicalTrial t2 = clinicalTrialService.save(trial);
		
// 		Assert.assertNotNull("failure, criteria create", t2);
// //		Long id = 5L;
// //		Assert.assertEquals("Criteria should have an id of 5", id, t2.getTrialId());
// 		Assert.assertTrue("testCreateClinicalTrialWithCriterias should have an id > 3", t2.getTrialId() > 3);
// 		//logger.info(criteria.toString());
									
// 	}*/
// 	@Rollback
// 	@Test
// 	public void testUpdateClinicalTrial() {
// 		Long id = DEFAULT_TRAIL_ID;
// 		String trialName = "JUnit Update Trial " + new Date().toString();
// 		ClinicalTrial trial = new ClinicalTrial().withTrialId(id)
// 												 .withTrialName(trialName).withTrialJson("");
// 		ResponseObjectModel res = clinicalTrialService.update(trial);
// 		ClinicalTrial t2 = (ClinicalTrial) res.getData();
// 		Assert.assertNotNull("failure, clinical trial update", t2);
// 		Assert.assertEquals("Trial should have an id of 1", id, t2.getTrialId());
// 		logger.info("Trial Name: " + trialName);
// 		Assert.assertEquals("Trial doesn't have the right name ", trialName, t2.getTrialName());
									
// 	}
// 	@Rollback
// 	@Test 
// 	public void testUpdateClinicalTrial_withNonExistentID() {
// 		Long id = Long.MAX_VALUE;
// 		ClinicalTrial trial = new ClinicalTrial().withTrialId(id)
// 												 .withTrialName("JUnit Update Trial");
// 		ResponseObjectModel res = clinicalTrialService.update(trial);
// 		Object t2=  res.getData();
// 		Assert.assertTrue("failure, testUpdateClinicalTrial_withNonExistentID", t2 ==null);
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateClinicalTrialWithStatus() {
// 		Long id = DEFAULT_TRAIL_ID;
// 		String trialName = "JUnit Update Trial " + new Date().toString();
// 		ClinicalTrial trial = new ClinicalTrial().withTrialId(id)
// 												 .withTrialName(trialName)
// 												 .withTrialJson("")
// 												 .withTrialStatusId(1);
// 		ResponseObjectModel res = clinicalTrialService.update(trial);
// 		ClinicalTrial t2=(ClinicalTrial) res.getData();
// 		Assert.assertNotNull("failure, clinical trial update", t2);
// 		Assert.assertEquals("Trial should have an id of 1", id, t2.getTrialId());
// 		logger.info("Trial Name: " + trialName);
// 		Assert.assertEquals("Trial doesn't have the right name ", trialName, t2.getTrialName());
// 		Assert.assertEquals("Trial should have same trialstatus id of 1", 1, t2.getTrialStatusId().intValue());
// 	}

// 	@Rollback
// 	@Test
// 	public void testUpdateClinicalTrialWithPhase() {
// 		Long id = DEFAULT_TRAIL_ID;
// 		String trialName = "JUnit Update Trial with phase " + new Date().toString();
// 		ClinicalTrial trial = new ClinicalTrial().withTrialId(id)
// 												 .withTrialName(trialName).withTrialJson("");
// 		ResponseObjectModel res = clinicalTrialService.update(trial);
// 		ClinicalTrial t2= (ClinicalTrial) res.getData();
// 		Assert.assertNotNull("failure, clinical trial update", t2);
// 		Assert.assertEquals("Trial should have an id of 1", id, t2.getTrialId());
// 		logger.info("Trial Name: " + trialName);
// 		Assert.assertEquals("Trial doesn't have the right name ", trialName, t2.getTrialName());
		
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testUpdateClinicalTrialWithSponsor() {
// 		Long id = DEFAULT_TRAIL_ID;
// 		String trialName = "JUnit Update Trial with Sponsor" + new Date().toString();
// 		ClinicalTrial trial = new ClinicalTrial().withTrialId(id)
// 												 .withTrialName(trialName)
// 												 .withTrialJson("");

// 		ResponseObjectModel res = clinicalTrialService.update(trial);
// 		ClinicalTrial t2=(ClinicalTrial) res.getData();	
// 		Assert.assertNotNull("failure, clinical trial update", t2);		
// 		Assert.assertEquals("Trial should have an id of 1", id, t2.getTrialId());
// 		logger.info("Trial Name: " + trialName);
// 		Assert.assertEquals("Trial doesn't have the right name ", trialName, t2.getTrialName());					
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testCreateTrialWithProgramCollaborator() {
// 		ClinicalTrial trial = new ClinicalTrial().withTrialName("JUnit Trial");
// 		trial.withProgramId(2l);trial.withTrialStatusId(1);


// 		ResponseObjectModel res = clinicalTrialService.save(trial);

// 		ClinicalTrial t2=(ClinicalTrial) res.getData();	
// 		Assert.assertNotNull("failure, clinical trial update", t2);		
// 		Assert.assertEquals("Trial should have same name", "JUnit Trial", t2.getTrialName());
// 		Assert.assertEquals( 2l, t2.getProgramId().longValue());
// 	}
	
// 	@Rollback
// 	public void testUpdateTrialWithProgramCollaborator() {
// 		Long id = DEFAULT_TRAIL_ID;
// 		ClinicalTrial trial = clinicalTrialService.findOne(id);
// 		trial.withProgramId(2l);

// 		ResponseObjectModel res = clinicalTrialService.update(trial);
		
// 		/* 
// 		 * Please change this test case. The reponse model never invokes
// 		 * the setData method. Which is why this fails.
// 		 * Consider using another variable to test.
// 		 * Edit by: Sai Kiran (sdasika@avigosolutions.com)
// 		 */
// 		ClinicalTrial t2=(ClinicalTrial) res.getData();	
// 		Assert.assertNotNull("failure, clinical trial update", t2);		
// 		Assert.assertEquals("Trial should have an id of 1", id, t2.getTrialId());
// 		Assert.assertEquals( 2l, t2.getProgramId().longValue());
// 	}
	
// 	@Rollback 
// 	@Test
// 	public void testDeleteClinicalTrial() {
// 		Long id = DEFAULT_TRAIL_ID;
// 		clinicalTrialService.delete(id);
// 		ClinicalTrial t2 = clinicalTrialService.findOne(id);
// 		Assert.assertNull("failure, Criteria expected to be null after delete", t2);
		
// 	}
// 	@Test
// 	public void testFindAllTemplates() {
// 		List<CriteriaTemplate> list = criteriaTemplateService.findAll();
// 		Assert.assertNotNull("failure, collection not expected to be null", list);
// 	}
	
// 	@Test
// 	public void testFindOneCriteriaTemplate() {
// 		CriteriaTemplate template = criteriaTemplateService.findOne(criteriaTemplateId);		
// 		Assert.assertNotNull("failure, findOne CriteriaTemplate not expected to be null", template);
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testCreateCriteriaTemplate() {
// 		CriteriaTemplate template = new CriteriaTemplate().withTemplateName("JUnit Template");
// 		CriteriaTemplate t2 =(CriteriaTemplate) criteriaTemplateService.save(template).getData();	
// 		Assert.assertNotNull("failure, CriteriaTemplate create ", t2);	
// 		Assert.assertTrue("testCreateCriteriaTemplate should have an id > 1", t2.getTemplateId() > 1);	
// 	}
		
// 	@Rollback
// 	@Test
// 	public void testCreateCriteriaTemplateWithCriterias() {
// 		CriteriaTemplate template = new CriteriaTemplate().withTemplateName("Template with Criteria list");
// 		Criteria criteria1 = new Criteria()
// 			      .withCriteriaDescription("Criteria 1 with template")
// 				  .withCriteriaName("Criteria with Template 1")
// 				  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 						  	"\"class\": \"age\"," +
// 						  	"\"operator\": \"in_range\"," +
// 						  	"\"min\": \"800\"," +
// 						  	"\"max\": \"70000\"" +
// 						  	" }")										 
// 				  .withIsInclude(false)
// 				  .withIsDeleted(true);
// 		Criteria criteria2 = new Criteria()
// 			      .withCriteriaDescription("Criteria 2 with template")
// 				  .withCriteriaName("Criteria with Template 2")
// 				  .withCriteriaQualifier("{\"group\": \"demographics\"," +
// 						  	"\"class\": \"age\"," +
// 						  	"\"operator\": \"in_range\"," +
// 						  	"\"min\": \"800\"," +
// 						  	"\"max\": \"70000\"" +
// 						  	" }")										 
// 				  .withIsInclude(false)
// 				  .withIsDeleted(true);
// 		List<Criteria> criterias = new ArrayList<Criteria>();
// 		criterias.add(criteria1);
// 		criterias.add(criteria2);
// 		template.withCriterias(criterias);
// 		CriteriaTemplate t2 = (CriteriaTemplate) criteriaTemplateService.save(template).getData();
		
// 		Assert.assertNotNull("failure, criteria template create", t2);
// 		Assert.assertTrue("testCreateCriteriaTemplateWithCriterias should have an id > 1", t2.getTemplateId() > 1);
									
// 	}
 
// 	@Rollback
// 	@Test
// 	public void testUpdateCriteriaTemplate() {
// 		String templateName = "JUnit Update Template " + new Date().toString();
		
		
// 		CriteriaTemplate template1 = new CriteriaTemplate().withTemplateName("JUnit Template");
// 		CriteriaTemplate t1 =(CriteriaTemplate) criteriaTemplateService.save(template1).getData();	
// 		CriteriaTemplate template2 = new CriteriaTemplate().withTemplateId(t1.getTemplateId())
// 				 .withTemplateName(templateName);
// 		Optional<CriteriaTemplate> t2 =(Optional<CriteriaTemplate> ) criteriaTemplateService.update(template2).getData();
// 		Assert.assertNotNull("failure, criteria template update", t2.get());
// 		Assert.assertEquals("Template should have an id of 1", t1.getTemplateId(), t2.get().getTemplateId());
// 		logger.info("Template Name: " + templateName);
// 		Assert.assertEquals("Template doesn't have the right name ", templateName, t2.get().getTemplateName());
									
// 	}



// 	@Rollback
// 	@Test 
// 	public void testDeleteCriteriaTemplate() {
// 		Long id = 2L;
// 		criteriaTemplateService.delete(id);
// 		CriteriaTemplate t2 = criteriaTemplateService.findOne(id);
// 		Assert.assertNull("failure, CriteriaTemplate expected to be null after delete", t2);	
// 	}

// }
