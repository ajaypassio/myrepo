// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.dto.Features;
// import com.avigosolutions.criteriaservice.dto.Properties;
// import com.avigosolutions.criteriaservice.dto.StudySiteDto;
// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.model.Questionnaire;
// import com.avigosolutions.criteriaservice.response.model.StudySiteResponse;
// import com.avigosolutions.criteriaservice.service.ClinicalTrialService;
// import com.avigosolutions.criteriaservice.service.QuestionnaireService;
// import com.avigosolutions.criteriaservice.service.StudySiteService;

// @Transactional
// @SpringBootTest
// @ActiveProfiles("test")
// public class PatientPortalControllerTest extends AbstractControllerTest {

// 	private Long magicClinicalTrialId = new Long(4);
// 	@Mock
// 	private ClinicalTrialService trialService;

// 	/*@InjectMocks
// 	private ClinicalTrialController controller;*/
	
// 	@InjectMocks
// 	private PatientPortalController controller;

// 	@Mock
// 	QuestionnaireService questionnaireService;

// 	@Mock
// 	private StudySiteService studySiteService;

// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
// 		setUp(controller);
// 	}

// 	@Test
// 	public void testGetTrial() throws Exception {
// 		ClinicalTrial trial = getTrialStubData();

// 		when(trialService.findOne(10L)).thenReturn(trial);

// 		String uri = "/criteria/patient/trials/10";

// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);

// 		verify(trialService, times(1)).findOne(10L);

// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);

// 	}

// 	@Test
// 	public void testGetQuestionnaire() throws Exception {
// 		Questionnaire questionnaire = getQuestionnaireStubData();

// 		when(questionnaireService.findOne(1L)).thenReturn(questionnaire);

// 		String uri = "/criteria/patient/questionnaires/1";

// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);

// 		verify(questionnaireService, times(1)).findOne(1L);

// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);

// 	}

// 	@Test
// 	public void testGetStudySitesByZip() throws Exception {
// 		StudySiteResponse response = new StudySiteResponse();
// 		response.setMatchedStudySites(getListStudySiteDto());
// 		when(studySiteService.getStudySitesByTrialZipMiles(4L, 92890L, 50F)).thenReturn(response);
// 		String uri = "/criteria/patient/studysites/search/zip/miles?trialId=4&zip=92890&miles=50";
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);

// 		verify(studySiteService, times(1)).getStudySitesByTrialZipMiles(4L, 92890L, 50F);

// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);
// 	}


// 	private ClinicalTrial getTrialStubData() {
// 		ClinicalTrial entity = new ClinicalTrial().withTrialName("JUnit Mock Trial").withTrialId(magicClinicalTrialId);
// 		entity.withProgramId(2l).withProgram(new Program().withProgramId(2l).withName("Test Program"));
// 		return entity;
// 	}

// 	private Questionnaire getQuestionnaireStubData() {
// 		Questionnaire entity = new Questionnaire().withName("Questionnaire").withTrialId(magicClinicalTrialId);
// 		entity.withProgramId(2l);
// 		return entity;
// 	}
	
// 	private List<StudySiteDto> getListStudySiteDto() {
// 		List<StudySiteDto> entities = new ArrayList<StudySiteDto>();
// 		entities.add(getStudySiteDto());
// 		return entities;
// 	}
// 	private StudySiteDto getStudySiteDto() {
// 		StudySiteDto entity = new StudySiteDto();
// 		Features features=new Features();
// 		Properties property=new Properties();
// 		property.withStudySiteName("Test Mock1");
// 		property.withActive(true);
// 		features.setProperties(property);
// 		return entity;
// 	}
// }
