// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.ProgramController;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.service.ProgramService;

// @Transactional
// @SpringBootTest
// @ActiveProfiles("test")
// public class ProgramControllerTest extends AbstractControllerTest {
	
// 	private long programId = 2L;
// 	@Mock
// 	private ProgramService programService;
	
// 	@InjectMocks
// 	private ProgramController controller;
	
// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
		
// 		setUp(controller);
// 	}
	
// 	@Test
// 	public void testGetAllPrograms() throws Exception {
// 		List<Program> list = getProgramListStubData();
		
// 		when(programService.findAll()).thenReturn(list);
		
// 		String uri = "/programs/all";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(programService, times(1)).findAll();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneProgram() throws Exception {
// 		Program program = getProgramStubData(programId);
// 		Long id = program.getId();
		
// 		when(programService.findOne(id)).thenReturn(program);
		
// 		String uri = "/programs/{id}";
		
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri,id).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(programService, times(1)).findOne(id);
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneProgramNotFound() throws Exception {
// 		String uri = "/programs/{id}";
// 		Long id = Long.MAX_VALUE;
// 		when(programService.findOne(id)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri, id)
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(programService, times(1)).findOne(id);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testCreateProgram() throws Exception {
// 		String uri = "/programs/add";
		
// 		Program createdProgramMock = getProgramStubData(programId);
// 		ResponseObjectModel response=new ResponseObjectModel();
// 		when(programService.save(any(Program.class))).thenReturn(response);
		
// 		Program program = getProgramStubData(programId);
// 		String jsonStr = mapToJson(program);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.post(uri)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		Program savedProgram = super.mapFromJson(content, Program.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(programService, times(1)).save(any(Program.class));
// 		logger.info("toString: " + savedProgram.toString());
// 		Assert.assertEquals("failure - expected 201", 201, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);	
// 	}
	
// 	@Test
// 	public void testUpdateProgram() throws Exception {
// 		String uri = "/programs/add/{id}";
// 		Program program = getProgramStubData(programId);
// 		//Long id = Program.getId();
// 		Long id = program.getId();
// 		ResponseObjectModel response=new ResponseObjectModel();
// 		when(programService.update(any(Program.class))).thenReturn(Optional.of(response).get());
		
// 		String jsonStr = mapToJson(program);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.put(uri, id)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		Program updatedProgram = super.mapFromJson(content, Program.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(programService, times(1)).update(any(Program.class));
		
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 		Assert.assertNotNull("failure Program updated and not returned", updatedProgram);
// 	}
	
	
// 	private List<Program> getProgramListStubData() {
// 		List<Program> list = new ArrayList<>();
// 		list.add(getProgramStubData(2l));
		
// 		return list;
// 	}

// 	private Program getProgramStubData(Long pId) {
// 		Program entity = new Program().withName("JUnit Mock Program")
// 												  .withProgramId(pId);
	
// 		return entity;
// 	}
// }
