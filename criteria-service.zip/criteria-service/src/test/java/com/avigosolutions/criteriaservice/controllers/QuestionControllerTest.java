// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.QuestionController;
// import com.avigosolutions.criteriaservice.model.Question;
// import com.avigosolutions.criteriaservice.service.QuestionService;

// @Transactional
// @SpringBootTest
// @ActiveProfiles("test")
// public class QuestionControllerTest extends AbstractControllerTest {
	
// 	private long questionId = 4L;
// 	@Mock
// 	private QuestionService questionService;
	
// 	@InjectMocks
// 	private QuestionController controller;
	
// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
		
// 		setUp(controller);
// 	}
	
// 	@Test
// 	public void testGetAllQuestions() throws Exception {
// 		List<Question> list = getQuestionListStubData();
		
// 		when(questionService.findAll()).thenReturn(list);
		
// 		String uri = "/questions/all";
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(questionService, times(1)).findAll();
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneQuestion() throws Exception {
// 		Question question = getQuestionStubData();
// 		Long id = question.getQuestionId();
		
// 		when(questionService.findOne(id)).thenReturn(question);
		
// 		String uri = "/questions/{id}";
		
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri,id).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(questionService, times(1)).findOne(id);
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetQuestionByQuestionnaireId() throws Exception {
// 		List<Question> questionList = getQuestionListStubData();
// 		long id = 2L;
		
// 		when(questionService.findByQuestionnaireId(id)).thenReturn(questionList);
		
// 		String uri = "/questions/questionByQuestionnaireId";
		
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri).param("questionnaireId", ""+id).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(questionService, times(1)).findByQuestionnaireId(any(Long.class));
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	
		
// 	}
	
// 	@Test
// 	public void testGetOneQuestionNotFound() throws Exception {
// 		String uri = "/questions/{id}";
// 		Long id = Long.MAX_VALUE;
// 		when(questionService.findOne(id)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri, id)
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(questionService, times(1)).findOne(id);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testCreateQuestion() throws Exception {
// 		String uri = "/questions/add";
		
// 		Question createdQuestionMock = getQuestionStubData();
// 		createdQuestionMock.withQuestionId(5L);
		
// 		when(questionService.save(any(Question.class))).thenReturn(createdQuestionMock);
		
// 		Question question = getQuestionStubData();
// 		String jsonStr = mapToJson(question);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.post(uri)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		Question savedQuestion = super.mapFromJson(content, Question.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(questionService, times(1)).save(any(Question.class));
// 		logger.info("toString: " + savedQuestion.toString());
// 		Assert.assertEquals("failure - expected 201", 201, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);	
// 		Assert.assertEquals("failure - expected greeting id of 100", 5L, savedQuestion.getQuestionId());
// 	}
	
// 	@Test
// 	public void testUpdateQuestion() throws Exception {
// 		String uri = "/questions/add/{id}";
// 		Question question = getQuestionStubData();
// 		//Long id = Question.getId();
// 		Long id = question.getQuestionId();
		
// 		when(questionService.update(any(Question.class))).thenReturn(Optional.of(question).get());
		
// 		String jsonStr = mapToJson(question);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.put(uri, id)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		Question updatedQuestion = super.mapFromJson(content, Question.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(questionService, times(1)).update(any(Question.class));
		
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 		Assert.assertNotNull("failure Question updated and not returned", updatedQuestion);
// 	}
	
//    @Test
// 	public void testDeleteQuestion() throws Exception {
// 		String uri = "/questions/delete/{id}";
		
// 		Question Question = getQuestionStubData();
		

// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.delete(uri, questionId)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							)
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(questionService, times(1)).delete(any(Long.class));
		
// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
	
// 	private List<Question> getQuestionListStubData() {
// 		List<Question> list = new ArrayList<>();
// 		list.add(getQuestionStubData());
		
// 		return list;
// 	}

// 	private Question getQuestionStubData() {
// 		Question entity = new Question().withQuestionName("JUnit Mock Question")
// 												  .withQuestionId(questionId).withCriteriaId(1L);
	
// 		return entity;
// 	}



// }
