// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.Date;
// import java.util.HashSet;
// import java.util.List;
// import java.util.Set;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;

// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.QuestionnaireController;
// import com.avigosolutions.criteriaservice.dto.QuestionnaireDto;
// import com.avigosolutions.criteriaservice.model.Question;
// import com.avigosolutions.criteriaservice.model.Questionnaire;
// import com.avigosolutions.criteriaservice.service.QuestionnaireService;

// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class QuestionnaireControllerTests extends AbstractControllerTest {
// 	private Long magicQuestionnaireId = new Long(100);

// 	@Mock
// 	@Autowired
// 	QuestionnaireService questionnaireService;

// 	@InjectMocks
// 	private QuestionnaireController controller;

// 	@Test
// 	public void testGetQuestionnaires() {
// 		List<QuestionnaireDto> list = questionnaireService.findAll();
// 		for (QuestionnaireDto quest : list) {
// 			logger.info(quest.getQuestionnaireDescription());
// 		}
// 		Assert.assertNotNull("failure, collection not expected to be null", list);
// 	}

// 	@Test
// 	public void testGetQuestionnarieById() {
// 		Questionnaire questionnaire = questionnaireService.findOne(1L);
// 		if (questionnaire != null) {
// 			logger.info(questionnaire.getDescription());
// 		}
// 		//Assert.assertNotNull("failure, collection not expected to be null", questionnaire);

// 	}

// 	@Test
// 	public void testUpdateQuestionnaire() {
// 		Questionnaire questionnaire = questionnaireService.findOne(1L);
// 		if (questionnaire != null) {
// 			questionnaire.withDescription("This is the test update");

// 			questionnaireService.update(questionnaire);
// 		}
// 	}

// 	@Test
// 	public void testSaveQuestionnaire() {
// 		try {
// 			Questionnaire questionnaire = new Questionnaire();
// 			questionnaire.setCreatedBy(1L);
// 			questionnaire.withTrialId(4L);
// 			questionnaire.withDescription("This is the test");
// 			questionnaire.withName("Questionnaire1");
// 			questionnaire.withQuestions(getQuestions());
// 			questionnaire = questionnaireService.save(questionnaire).get();
// 			logger.info(questionnaire.getQuestionnaireId());
// 		} catch (Exception ex) {
// 			ex.printStackTrace();
// 		}
// 	}

// 	public List<Question> getQuestions() {
// 		List<Question> questionSet = new ArrayList<Question>();
// 		try {
// 			Question question = null;
// 			for (int q = 0; q < 10; q++) {
// 				question = new Question();
// 				question.withDescription(q + ". This is the test Question");
// 				question.withQuestionName(q + ". This is the test name");
// 				question.withCriteriaId(288L);
// 				questionSet.add(question);
// 			}

// 		} catch (Exception ex) {
// 			ex.printStackTrace();
// 		}
// 		return questionSet;
// 	}

// 	@Test
// 	public void testDeleteQuestionnaire() {
// 		questionnaireService.delete(1L);
// 	}

// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
// 		setUp(controller);
// 	}

// 	@Test
// 	public void testGetAllQuestionnaires() throws Exception {
// 		List<QuestionnaireDto> list = getQuestionnaireListStubData();

// 		when(questionnaireService.findAll()).thenReturn(list);

// 		String uri = "/questionnaires/all";

// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);

// 		verify(questionnaireService, times(1)).findAll();

// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);

// 	}

// 	private List<QuestionnaireDto> getQuestionnaireListStubData() {
// 		List<QuestionnaireDto> list = new ArrayList<>();
// 		list.add(getQuestionnaireStubData());

// 		return list;
// 	}

// 	private QuestionnaireDto getQuestionnaireStubData() {
// 		QuestionnaireDto entity = new QuestionnaireDto(1L,1L, 1L, "question",
// 				"description", "", null, "", "","", new Date(), new Date());
				

// 		return entity;
// 	}
// }
