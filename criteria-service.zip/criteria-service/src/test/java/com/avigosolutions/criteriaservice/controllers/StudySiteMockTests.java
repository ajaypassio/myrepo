// package com.avigosolutions.criteriaservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Matchers.anyObject;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.when;

// import java.util.Arrays;
// import java.util.List;
// import java.util.Optional;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.http.MediaType;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.controllers.StudysiteController;
// import com.avigosolutions.criteriaservice.dto.StudySiteDto;
// import com.avigosolutions.criteriaservice.model.StudySite;
// import com.avigosolutions.criteriaservice.request.model.StudySiteFilterRequestModel;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.service.StudySiteService;

// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class StudySiteMockTests extends AbstractControllerTest{
	
// 	private Long magicStudySiteId = new Long(31);
	
// 	private Long magicTrialId = new Long(5);

// 	@Mock
// 	@Autowired
// 	StudySiteService studySiteService;

// 	@InjectMocks
// 	StudysiteController studySiteController;
	
// 	@Before
// 	public void setup() {
// 		MockitoAnnotations.initMocks(this);
		
// 		setUp(studySiteController);
// 	}
	
// 	@Test
// 	public void  getAllStudySitesByTrialId() throws Exception {
// 		StudySite studySite = getStudySiteStubData();
// 		Long trialId = studySite.getId();
// 		ResponseObjectModel response =new ResponseObjectModel();
// 		when(studySiteService.getAllStudySitesByTrailId(trialId,null)).thenReturn((ResponseObjectModel) response);
// 		String jsonStr = mapToJson(null);
// 		String uri = "/studysites/all_studysites/{trialId}";
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.post(uri,trialId).contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).content(jsonStr))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);


// 		Assert.assertEquals("failure - expected 200", 400, status);

// 	}
	
// 	@Test
// 	public void  getStudySitesNotInTrialId() throws Exception {
// 		StudySite studySite = getStudySiteStubData();
// 		Long trialId = 5L;

// 		when(studySiteService.findByNotTrailIdIn(trialId)).thenReturn(Arrays.asList(studySite));

// 		String uri = "/studysites/notin/trial/{trialId}";
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri,trialId).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);

// 		verify(studySiteService, times(1)).findByNotTrailIdIn(trialId);

// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	

// 	}
	
	


// 	@Test
// 	public void  getStudySitesByStudySiteId() throws Exception {
// 		StudySite studySite = getStudySiteStubData();
// 		Long id = studySite.getId();

// 		when(studySiteService.getStudySitesByStudySiteId(id)).thenReturn(new StudySiteDto());

// 		String uri = "/studysites/studySite/{studySiteId}";


// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders.get(uri,id).accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();

// 		logger.info("status: " + status + " response: " + content);

// 		verify(studySiteService, times(1)).getStudySitesByStudySiteId(id);

// 		Assert.assertEquals("failure - expected 200", 200, status);
// 		Assert.assertTrue("failure expected return string len > 0", content.trim().length() > 0);	

// 	}


// 	private StudySite getStudySiteStubData() {
// 		StudySite entity = new StudySite().withId(2L);
// 		return entity;
// 	}
	
// 	@Test
// 	public void testGetStudySitesByStudySiteIdNotFound() throws Exception {
// 		String uri = "/studysites/studySite/{studySiteId}";
// 		StudySite studySite = getStudySiteStubData();
// 		Long id = studySite.getId();
// 		when(studySiteService.getStudySitesByStudySiteId(id)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri, id)
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(studySiteService, times(1)).getStudySitesByStudySiteId(id);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testGetTrials() throws Exception {
// 		String uri = "/studysites/studySite/{trialId}";
// 		Long id = Long.MAX_VALUE;
// 		when(studySiteService.getAllStudySitesByTrailId(id, null)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri, id)
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(studySiteService, times(1)).getStudySitesByStudySiteId(id);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testGetStudySiteByZip() throws Exception {
// 		String uri = "/studysites/search/zip/miles";
// 		Long trialId = 5L;
// 		Long zip = 30312L;
// 		Float miles =2.1F;
// 		when(studySiteService.getStudySitesByTrialZipMiles(trialId,zip,miles)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri)
// 				.param("trialId", trialId.toString())
// 				.param("zip", zip.toString())
// 				.param("miles", miles.toString())
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(studySiteService, times(1)).getStudySitesByTrialZipMiles(trialId,zip,miles);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
// 	@Test
// 	public void testGetStudySitesByLatLngMiles() throws Exception {
// 		String uri = "/studysites/all/latlng_miles";
// 		Float latitude = 31.2F;
// 		Float longitude = 31.2F;
// 		Float distance =2.1F;
// 		Long trialId = 5L;
// 		when(studySiteService.findByMiles(latitude,longitude,distance,trialId)).thenReturn(null);
		
// 		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get(uri)
// 				.param("latitude", latitude.toString())
// 				.param("longitude", longitude.toString())
// 				.param("distance", distance.toString())
// 				.param("trialId", trialId.toString())
// 				.accept(MediaType.APPLICATION_JSON))
// 				.andReturn();
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		verify(studySiteService, times(1)).findByMiles(latitude,longitude,distance,trialId);
		
// 		logger.info("status: " + status + " response: " + content);
		
// 		Assert.assertEquals("failure - expected 404", 404, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 	}
	
	
// 	@Test
// 	public void testCreateStudySite() throws Exception {
// 		String uri = "/studysites/add";
// 		StudySite studySite = getStudySiteStubData();
// 		ResponseObjectModel trial = new ResponseObjectModel();
// 		when(studySiteService.save(any(StudySite.class))).thenReturn(trial);
		
// 		String jsonStr = mapToJson(studySite);
		
// 		MvcResult result = mockMvc
// 				.perform(MockMvcRequestBuilders
// 							.post(uri)
// 							.contentType(MediaType.APPLICATION_JSON)
// 							.accept(MediaType.APPLICATION_JSON)
// 							.content(jsonStr))
// 				.andReturn();
		
// 		String content = result.getResponse().getContentAsString();
// 		int status = result.getResponse().getStatus();
		
// 		StudySite savedSite = super.mapFromJson(content, StudySite.class);
							
// 		logger.info("status: " + status + " response: " + content);
		
// 		verify(studySiteService, times(1)).save(any(StudySite.class));
// 		logger.info("toString: " + savedSite.toString());
// 		Assert.assertEquals("failure - expected 201", 201, status);
// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);	
// 	}
	
// 		public void testgetStudySitesByTrailId() throws Exception{
			
// 		}
		
// 		@Test
// 		public void testDeleteStudySite() throws Exception {
// 			String uri = "/studysites/delete/{id}";
			
// 			StudySite studySite = getStudySiteStubData();
			
					
// 			MvcResult result = mockMvc
// 					.perform(MockMvcRequestBuilders
// 								.delete(uri, magicStudySiteId)
// 								.contentType(MediaType.APPLICATION_JSON)
// 								.accept(MediaType.APPLICATION_JSON)
// 								)
// 					.andReturn();
			
// 			String content = result.getResponse().getContentAsString();
// 			int status = result.getResponse().getStatus();
			
			
// 			logger.info("status: " + status + " response: " + content);
			
// 			verify(studySiteService, times(1)).delete(any(Long.class));
			
// 			Assert.assertEquals("failure - expected 200", 200, status);
// 			Assert.assertTrue("failure expected return string len should be 0", content.trim().length() == 0);	
// 		}
		
// 		//@Rollback
// 		//@Test
// 		// commmented since both mock and autowired on the service is not working.
// 		public void testUpdateStudySite() {
			
// 		StudySite studySite = new StudySite().withId(30L) 
// 										      //.withStudySiteNumber("T964784")
// 											  .withUltimateParentName("JUnit");
																						
// 		Optional<StudySite> studySite2 = studySiteService.update(studySite);
// 			Assert.assertNotNull("failure, StudySite create", studySite2);
// 			Long id = 1L;
// 			Assert.assertEquals("StudySite should have an id of 4", id, studySite2.get().getId());								
// 		}
		
	
		
// }
