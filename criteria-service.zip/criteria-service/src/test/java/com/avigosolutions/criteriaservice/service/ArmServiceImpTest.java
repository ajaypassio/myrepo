// package com.avigosolutions.criteriaservice.service; 

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertNull;
// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageRequest;

// import com.avigosolutions.criteriaservice.model.Arm;
// import com.avigosolutions.criteriaservice.repository.ArmRepository;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.util.PageBuilder;

// public class ArmServiceImpTest {

// 	@InjectMocks
// 	ArmServiceImp armServiceImpl;
	
// 	@Mock
// 	ArmRepository armRepository;
	
// 	protected final int page = 1;
// 	protected final int pageSize = 10;
// 	protected ResponseObjectModel responseObject;
// 	protected Arm arm;
// 	protected Page<Arm> pageList;
// 	protected PageRequest pageRequest;
	
// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		responseObject=new ResponseObjectModel();
// 		pageRequest = new PageRequest(page, pageSize);
// 		arm = new Arm();
// 		List<Arm> arms = new ArrayList<Arm>();
// 		arms.add(arm);
// 		pageList = new PageBuilder<Arm>()
// 	              .elements(arms)
// 	              .pageRequest(pageRequest)
// 	              .totalElements(arms.size())
// 	              .build();
// 	}
	
// 	/*
// 	 * Test getAll() method
// 	 * @params : int page, int pageSize
// 	 */
// 	@Test
// 	public void getAllTest() throws Exception { 
// 		when(armRepository.findAll(any(PageRequest.class))).thenReturn(pageList);
// 		ResponseObjectModel result = armServiceImpl.getAll(page, pageSize);
// 		assertEquals("Expected 200 :" , 200, result.getStatus());
// 		assertNotNull(result.getData());
// 	}
	
	
// 	/*
// 	 * Test getAll() method exception handling
// 	 * @params : int page, int pageSize
// 	 */
// 	@Test
// 	public void getAllTestException() throws Exception { 
// 		when(armRepository.findAll(any(PageRequest.class))).thenThrow(new NullPointerException());
// 		ResponseObjectModel result = armServiceImpl.getAll(page, pageSize);
// 		assertEquals("Expected 200 :" , 400, result.getStatus());
// 		assertNull(result.getData());
// 	}
// }
