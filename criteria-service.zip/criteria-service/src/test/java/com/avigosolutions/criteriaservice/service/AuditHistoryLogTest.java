// package com.avigosolutions.criteriaservice.service;

// import java.util.List;
// import java.util.Optional;

// import org.junit.After;
// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.audit.Action;
// import com.avigosolutions.criteriaservice.model.AuditHistory;
// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Collaborator;
// import com.avigosolutions.criteriaservice.model.Coordinator;
// import com.avigosolutions.criteriaservice.model.Criteria;
// import com.avigosolutions.criteriaservice.model.Question;
// import com.avigosolutions.criteriaservice.model.Questionnaire;
// import com.avigosolutions.criteriaservice.model.StudySite;
// import com.avigosolutions.criteriaservice.repository.AuditHistoryRepository;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class AuditHistoryLogTest {
// 	@Autowired
// 	private ClinicalTrialService trialService;
// 	@Autowired
// 	private StudySiteService studySiteService;
// 	@Autowired
// 	private CoordinatorService coordinatorService;
// 	@Autowired
// 	private CollaboratorService collaboratorService;
// 	@Autowired
// 	private CriteriaService criteriaService;
// 	@Autowired
// 	private QuestionnaireService questionnaireService;
// 	@Autowired
// 	private QuestionService questionService;
// 	@Autowired
// 	private AuditHistoryRepository auditRepo;
	
// 	private ClinicalTrial clinicalTrial;
// 	private StudySite studySite;
// 	private Coordinator coordinator;
// 	private Collaborator collaborator;
// 	private Criteria criteria;
// 	private Questionnaire questionnaire;
// 	private Question question;
// 	@Before
// 	public void setup() {
// 		clinicalTrial = new ClinicalTrial().withTrialName("SampleTrial").withTrialShortCode("samplecode");
// 		studySite = new StudySite().withActive(true).withCity("sampleCity");
// 		coordinator = new Coordinator().withName("SampleCoordinator");
// 		collaborator = new Collaborator().withName("SampleName").withCollaboratorTypeId(2L);
// 		criteria = new Criteria().withCriteriaName("SampleName").withCriteriaDescription("SampleDescription");
// 		questionnaire = new Questionnaire().withName("SampleName").withDescription("SampleDescription").withStatus(true).withTrialId(10L);
// 		question = new Question().withQuestionName("SampleName").withStatus(true);
		
// 	}

// 	@After
// 	public void tearDown() {

// 	}
// 	@Rollback
// 	@Test
// 	public void testSaveTrialAudit() {
// 		trialService.save(clinicalTrial);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateTrialAudit() {
// 		ResponseObjectModel save = trialService.save(clinicalTrial);
// 		ClinicalTrial updatedTrial = (ClinicalTrial)save.getData();
// 		updatedTrial.withTrialName("UpdatedTrial").withTrialShortCode("updatedcode").withTrialJson("");
// 		trialService.update(clinicalTrial);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedTrialAudit() {
// 		ResponseObjectModel save = trialService.save(clinicalTrial);
// 		ClinicalTrial updatedTrial = (ClinicalTrial)save.getData();
// 		updatedTrial.withTrialName("UpdatedTrial").withTrialShortCode("updatedcode");
// 		trialService.delete(updatedTrial.getTrialId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}

// 	@Rollback
// 	@Test
// 	public void testSaveStudySiteAudit() {
// 		studySiteService.save(studySite);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateStudySiteAudit() {
// 		ResponseObjectModel save = studySiteService.save(studySite);
// 		StudySite updatedStudySite = (StudySite)save.getData();
// 		updatedStudySite.withCity("UpdatedCity");
// 		studySiteService.update(updatedStudySite);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedStudySiteAudit() {
// 		ResponseObjectModel save = studySiteService.save(studySite);
// 		StudySite updatedStudySite = (StudySite)save.getData();
// 		updatedStudySite.withCity("UpdatedCity");
// 		studySiteService.delete(updatedStudySite.getId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testSaveCoordinatorAudit() {
// 		coordinatorService.save(coordinator);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateCoordinatorAudit() {
// 		Coordinator toBeUpdated = coordinatorService.save(coordinator);
// 		toBeUpdated.withName("UpdatedName");
// 		coordinatorService.update(toBeUpdated);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedCoordinatorAudit() {
// 		Coordinator toBeUpdated = coordinatorService.save(coordinator);
// 		toBeUpdated.withName("UpdatedName");
// 		coordinatorService.delete(toBeUpdated.getCoordinatorId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testSaveCollaboratorAudit() {
// 		collaboratorService.save(collaborator);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateCollaboratorAudit() {
// 		Collaborator toBeUpdated = collaboratorService.save(collaborator);
// 		toBeUpdated.withName("UpdatedName");
// 		collaboratorService.update(toBeUpdated);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedCollaboratorAudit() {
// 		Collaborator toBeUpdated = collaboratorService.save(collaborator);
// 		toBeUpdated.withName("UpdatedName");
// 		collaboratorService.delete(toBeUpdated.getId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testSaveCriteriaAudit() {
// 		criteriaService.save(criteria);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateCriteriaAudit() {
// 		Criteria toBeUpdated = criteriaService.save(criteria);
// 		toBeUpdated.withCriteriaName("UpdatedName");
// 		criteriaService.update(toBeUpdated);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedCriteriaAudit() {
// 		Criteria toBeUpdated = criteriaService.save(criteria);
// 		toBeUpdated.withCriteriaName("UpdatedName");
// 		criteriaService.delete(toBeUpdated.getId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testSaveQuestionnarieAudit() {
// 		questionnaireService.save(questionnaire);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateQuestionnarieAudit() {
// 		Optional<Questionnaire> toBeUpdated = questionnaireService.save(questionnaire);
// 		if(toBeUpdated.isPresent()) {
// 			questionnaire = toBeUpdated.get().withName("UpdatedName");
// 		}
// 		questionnaireService.update(questionnaire);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedQuestionnarieAudit() {
// 		Optional<Questionnaire> toBeUpdated = questionnaireService.save(questionnaire);
// 		if(toBeUpdated.isPresent()) {
// 			questionnaire = toBeUpdated.get().withName("UpdatedName");
// 		}
// 		questionnaireService.delete(questionnaire.getQuestionnaireId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testSaveQuestionAudit() {
// 		questionService.save(question);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
// 	}
// 	@Rollback
// 	@Test
// 	public void testUpdateQuestionAudit() {
// 		Question toBeUpdated = questionService.save(question);
// 		toBeUpdated.withQuestionName("UpdatedName");
// 		questionService.update(toBeUpdated);
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// 	@Rollback
// 	@Test
// 	public void testDeletedQuestionAudit() {
// 		Question toBeUpdated = questionService.save(question);
// 		toBeUpdated.withQuestionName("UpdatedName");
// 		questionService.delete(toBeUpdated.getQuestionId());
// 		List<AuditHistory> auditList = auditRepo.findAll();
// 		Assert.assertTrue("failure, insert Trial",auditList.size()>0);
		
// 	}
// }
