// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertNull;
// import static org.mockito.Matchers.*;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.doThrow;
// import static org.mockito.Mockito.times;
// import static org.mockito.Mockito.verify;
// import static org.mockito.Mockito.verifyNoMoreInteractions;
// import static org.mockito.Mockito.when;

// import java.text.SimpleDateFormat;
// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Date;
// import java.util.List;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.ArgumentCaptor;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageRequest;
// import org.springframework.data.domain.Sort;
// import org.springframework.data.jpa.domain.Specification;
// import org.springframework.test.context.TestPropertySource;

// import com.avigosolutions.criteriaservice.messaging.TrialSourceBean;
// import com.avigosolutions.criteriaservice.model.Arm;
// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Phase;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.model.ProgramStatus;
// import com.avigosolutions.criteriaservice.model.Sponsor;
// import com.avigosolutions.criteriaservice.model.Status;
// import com.avigosolutions.criteriaservice.model.StudySite;
// import com.avigosolutions.criteriaservice.model.TherapeuticArea;
// import com.avigosolutions.criteriaservice.model.TrialStatus;
// import com.avigosolutions.criteriaservice.repository.ArmRepository;
// import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
// import com.avigosolutions.criteriaservice.repository.CollaboratorRepository;
// import com.avigosolutions.criteriaservice.repository.PhaseRepository;
// import com.avigosolutions.criteriaservice.repository.ProgramRepository;
// import com.avigosolutions.criteriaservice.repository.SponsorRepository;
// import com.avigosolutions.criteriaservice.repository.StageRepository;
// import com.avigosolutions.criteriaservice.repository.StatusRepository;
// import com.avigosolutions.criteriaservice.repository.TherapeuticAreaRepository;
// import com.avigosolutions.criteriaservice.repository.TrialJobMapRepository;
// import com.avigosolutions.criteriaservice.repository.TrialStatusRepository;
// import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.util.PageBuilder;

// public class ClinicalTrialServiceImplTest {

// 	@InjectMocks
// 	ClinicalTrialServiceImpl clinicalTrialServiceImpl;

// 	@Mock
// 	ClinicalTrialRepository clinicalTrialRepository;
	
// 	@Mock
// 	TrialSourceBean trialSourceBean;

// 	@Mock
// 	private SponsorRepository sponsorRepository;

// 	@Mock
// 	private PhaseRepository phaseRepository;

// 	@Mock
// 	private TrialStatusRepository trialStatusRepository;

// 	@Mock
// 	private StatusRepository statusRepository;

// 	@Mock
// 	private ProgramRepository programRepository;

// 	@Mock
// 	private CollaboratorRepository collaboratorRepository;

// 	@Mock
// 	private TherapeuticAreaRepository therapeuticAreaRepository;

// 	@Mock
// 	private StageRepository stageRepository;

// 	@Mock
// 	private ArmRepository armRepository;
// 	@Mock
// 	private TrialJobMapRepository trialJobMapRepository;

// 	protected final int page = 1;
// 	protected final int pageSize = 10;
// 	protected ResponseObjectModel responseObject;
// 	protected ClinicalTrial clinicalTrial1, clinicalTrial2, clinicalTrial3;
// 	protected Program pgm1;
// 	protected Page<ClinicalTrial> pageList, emptyPageList;
// 	protected Page<Program> pageProgram;
// 	protected Page<Sponsor> sponsorPage;
// 	protected PageRequest pageRequest;
// 	protected List<Long> trialIds;
// 	protected List<ClinicalTrial> clinicalTrialList, clinicalTrialList1;
// 	protected List<TherapeuticArea> therapeuticAreaList;
// 	protected List<Sponsor> sponsorList;
// 	protected List<Phase> phaseList;
// 	protected List<TrialStatus> trialStatusList;
// 	protected List<Status> statusList;
// 	protected ClinicalTrialFilterRequestModel clinicalTrialFilterRequestModel;
// 	protected String trialName = "";

// 	@Before
// 	public void init() {
// 		MockitoAnnotations.initMocks(this);
// 		responseObject = new ResponseObjectModel();
// 		clinicalTrialFilterRequestModel = new ClinicalTrialFilterRequestModel();
// 		pageRequest = new PageRequest(page, pageSize);
// 		clinicalTrial1 = new ClinicalTrial();
// 		clinicalTrial2 = new ClinicalTrial();
// 		clinicalTrial3 = new ClinicalTrial();
// 		dataSetup();
// 		clinicalTrialList = new ArrayList<ClinicalTrial>();
// 		clinicalTrialList.add(clinicalTrial1);
// 		clinicalTrialList.add(clinicalTrial2);
// 		clinicalTrialList1 = new ArrayList<ClinicalTrial>();
// 		clinicalTrialList1.add(clinicalTrial3);
// 		pageList = new PageBuilder<ClinicalTrial>().elements(clinicalTrialList).pageRequest(pageRequest)
// 				.totalElements(clinicalTrialList.size()).build();
// 		emptyPageList = new PageBuilder<ClinicalTrial>().elements(new ArrayList<ClinicalTrial>())
// 				.pageRequest(pageRequest).totalElements(0).build();
// 		pageProgram = new PageBuilder<Program>().elements(new ArrayList<Program>()).pageRequest(pageRequest).build();
// 		trialIds = new ArrayList<Long>();
// 		trialIds.add(1L);

// 		sponsorList = new ArrayList<>();
// 		Sponsor sponsor1 = new Sponsor();
// 		sponsorList.add(sponsor1);

// 		phaseList = new ArrayList<>();
// 		Phase phase1 = new Phase();
// 		phaseList.add(phase1);

// 		therapeuticAreaList = new ArrayList<>();
// 		TherapeuticArea tarea = new TherapeuticArea();
// 		therapeuticAreaList.add(tarea);

// 		trialStatusList = new ArrayList<>();
// 		TrialStatus tstatus = new TrialStatus();
// 		trialStatusList.add(tstatus);

// 		statusList = new ArrayList<>();
// 		Status status = new Status();
// 		statusList.add(status);

// 		sponsorPage = new PageBuilder<Sponsor>().elements(sponsorList).pageRequest(pageRequest)
// 				.totalElements(sponsorList.size()).build();
// 	}

// 	private void dataSetup() {
// 		String sDate1 = "31/01/2018";
// 		String sDate2 = "25/02/2018";
// 		try {
// 			clinicalTrial1.setCreatedOn(new SimpleDateFormat("dd/MM/yyyy").parse(sDate1));
// 			clinicalTrial2.setCreatedOn(new SimpleDateFormat("dd/MM/yyyy").parse(sDate2));
// 		} catch (Exception e) {
// 			clinicalTrial1.setCreatedOn(new Date());
// 			clinicalTrial2.setCreatedOn(new Date());
// 		}

// 		clinicalTrial1 = clinicalTrial1.withTrialId(1L).withTrialName("Name1").withProgramId(1L).withTrialStatusId(1).withTrialJson("");
// 		clinicalTrial2 = clinicalTrial2.withTrialId(2L).withTrialName("Name2").withProgramId(2L).withTrialStatusId(1).withTrialJson("");
		
// 		pgm1 = new Program().withProgramId(1L).withProgramStatus(new ProgramStatus().withStatusId(1));

// 	}

// 	/*
// 	 * This method is to test findByTrialIdIn() method
// 	 */
// 	@Test
// 	public void findByTrialIdInTest() throws Exception {
// 		when(clinicalTrialRepository.findByIdIn(anyListOf(Long.class))).thenReturn(clinicalTrialList);
// 		List<ClinicalTrial> trialList = clinicalTrialServiceImpl.findByTrialIdIn(trialIds);
// 		assertEquals(trialList.size(), clinicalTrialList.size());
// 	}

// 	/*
// 	 * This method is to test findByTrialIdIn() method with clinicalTrial having
// 	 * Sponsor and Phase details
// 	 */
// 	@Test
// 	public void findByTrialIdInTest_withSponsorId() throws Exception {
// 		when(clinicalTrialRepository.findByIdIn(anyListOf(Long.class))).thenReturn(clinicalTrialList1);
// 		when(sponsorRepository.findOne(anyLong())).thenReturn(new Sponsor().withSponsorId(1L));
// 		when(phaseRepository.findOne(anyInt())).thenReturn(new Phase().withPhaseId(1));
// 		List<ClinicalTrial> trialList = clinicalTrialServiceImpl.findByTrialIdIn(trialIds);
// 		assertEquals(clinicalTrialList1.size(), trialList.size());
// 	}

// 	/*
// 	 * This method is to test findByTrialIdIn() method when we get empty list from
// 	 * repository
// 	 */
// 	@Test
// 	public void findByTrialIdInEmptyTest() throws Exception {
// 		when(clinicalTrialRepository.findByIdIn(anyListOf(Long.class))).thenReturn(new ArrayList<ClinicalTrial>());
// 		List<ClinicalTrial> trialList = clinicalTrialServiceImpl.findByTrialIdIn(trialIds);
// 		assertNotNull(trialList);
// 		assertEquals(trialList.size(), 0);
// 	}

// 	/*
// 	 * This method is to test findAll() method
// 	 */
// 	@Test
// 	public void findAllTest() throws Exception {
// 		when(clinicalTrialRepository.findAll(any(Sort.class))).thenReturn(clinicalTrialList);
// 		List<ClinicalTrial> trialList = clinicalTrialServiceImpl.findAll();

// 		ArgumentCaptor<Sort> sortArgument = ArgumentCaptor.forClass(Sort.class);
// 		verify(clinicalTrialRepository, times(1)).findAll(sortArgument.capture());
// 		Sort actualSort = sortArgument.getValue();

// 		assertEquals(Sort.Direction.DESC, actualSort.getOrderFor("createdOn").getDirection());
// 		assertEquals(trialList.size(), clinicalTrialList.size());
// 	}

// 	/*
// 	 * This method is to test findAll() method when we get empty list from
// 	 * repository
// 	 */
// 	@Test
// 	public void findAllEmptyTest() throws Exception {
// 		when(clinicalTrialRepository.findAll(any(Sort.class))).thenReturn(new ArrayList<ClinicalTrial>());
// 		List<ClinicalTrial> trialList = clinicalTrialServiceImpl.findAll();
// 		assertNotNull(trialList);
// 		assertEquals(trialList.size(), 0);
// 	}

// 	/*
// 	 * This method is to test findAll(ClinicalTrialFilterRequestModel) method
// 	 */
// 	@Test
// 	public void findAllWithFilterTest() throws Exception {
// 		Specification<ClinicalTrial> alias1 = any();
// 		when(clinicalTrialRepository.findAll(alias1, any(PageRequest.class))).thenReturn(pageList);
// 		Specification<Program> alias2 = any();
// 		when(programRepository.findAll(alias2, any(PageRequest.class))).thenReturn(pageProgram);
// 		ResponseObjectModel response = clinicalTrialServiceImpl.findAll(
// 				clinicalTrialFilterRequestModel.withPageSize(pageList.getNumberOfElements()).withSortBy("sponsorName"));
// 		assertNotNull(response.getData());
// 	}

// 	/*
// 	 * This method is to test findAll(ClinicalTrialFilterRequestModel) method when
// 	 * we get empty list from repository
// 	 */
// 	@Test(expected = java.lang.IllegalArgumentException.class)
// 	public void findAllEmptyWithFilterTest() throws Exception {
// 		when(clinicalTrialRepository.findAll(any(PageRequest.class))).thenReturn(emptyPageList);
// 		ResponseObjectModel response = clinicalTrialServiceImpl
// 				.findAll(clinicalTrialFilterRequestModel.withPageSize(emptyPageList.getNumberOfElements()));
// 	}

// 	@Test(expected = java.lang.IllegalArgumentException.class)
// 	public void getTrialsByPageCriteriaTest() throws Exception {
// 		when(clinicalTrialRepository.findByTrialNameContaining(anyString(), any(PageRequest.class)))
// 				.thenReturn(emptyPageList);
// 		when(clinicalTrialRepository.findByIdIn(anyListOf(Long.class), any(PageRequest.class))).thenReturn(emptyPageList);
// 		when(clinicalTrialRepository.findByIdNotIn(anyListOf(Long.class), any(PageRequest.class))).thenReturn(emptyPageList);
// 		when(clinicalTrialRepository.findAll(any(PageRequest.class))).thenReturn(emptyPageList);
// 		ResponseObjectModel response = clinicalTrialServiceImpl
// 				.getTrialsByPageCriteria(clinicalTrialFilterRequestModel.withPageSize(emptyPageList.getNumberOfElements()));
// 		assertEquals(pageList.getSize(), response.getTotal());
// 	}

// 	/*
// 	 * This method is to test findOne(id) method
// 	 */
// 	@Test
// 	public void findOneTest() throws Exception {
// 		when(clinicalTrialRepository.findOne(any(Long.class))).thenReturn(clinicalTrialList.get(0));
// 		ClinicalTrial response = clinicalTrialServiceImpl.findOne(0L);
// 		assertEquals(response.getCreatedOn(), clinicalTrialList.get(0).getCreatedOn());
// 	}

// 	/*
// 	 * This method is to test findOne(id) method when the get null
// 	 */
// 	@Test
// 	public void findOneNullTest() throws Exception {
// 		when(clinicalTrialRepository.findOne(any(Long.class))).thenReturn(null);
// 		ClinicalTrial response = clinicalTrialServiceImpl.findOne(0L);
// 		assertNull(response);
// 	}

// 	/*
// 	 * This method is to test save(ClinicalTrial) method
// 	 */
// 	@Test
// 	public void saveTest() throws Exception {
// 		when(clinicalTrialRepository.save(any(ClinicalTrial.class))).thenReturn(clinicalTrialList.get(0));
// 		when(programRepository.findOne(any(Long.class))).thenReturn(pgm1);
// 		when(programRepository.save(any(Program.class))).thenReturn(pgm1);
// 		when(clinicalTrialRepository.findByProgramId(any(Long.class))).thenReturn(clinicalTrialList);
		
// 		ResponseObjectModel response = clinicalTrialServiceImpl.save(clinicalTrialList.get(0));
// 		assertEquals(200, response.getStatus());
// 		assertEquals(clinicalTrialList.get(0), response.getData());
// 	}

// 	/*
// 	 * This method is to test save(ClinicalTrial) method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void saveExceptionTest() throws Exception {
// 		when(clinicalTrialRepository.save(any(ClinicalTrial.class))).thenThrow(new NullPointerException());
// 		ResponseObjectModel response = clinicalTrialServiceImpl.save(clinicalTrialList.get(0));
// 	}

// 	/*
// 	 * This method is to test update(ClinicalTrial) method when the trail name
// 	 * exists
// 	 */
// 	@Test
// 	public void updateExistingTrailNameTest() throws Exception {
// 		when(clinicalTrialRepository.save(any(ClinicalTrial.class))).thenReturn(clinicalTrialList.get(0));
// 		when(clinicalTrialRepository.findOne(any(Long.class))).thenReturn(clinicalTrialList.get(0));
// 		when(clinicalTrialRepository.findByTrialNameAndIdNot(anyString(), any(Long.class)))
// 				.thenReturn(clinicalTrialList);
// 		ResponseObjectModel response = clinicalTrialServiceImpl.update(clinicalTrialList.get(1));
// 		assertEquals(302, response.getStatus());
// 		assertNull(response.getData());
// 	}

// 	/*
// 	 * This method is to test update(ClinicalTrial) method when the trail name
// 	 * exists
// 	 */
// 	@Test
// 	public void updateTest() throws Exception {
// 		when(clinicalTrialRepository.save(any(ClinicalTrial.class))).thenReturn(clinicalTrialList.get(0));
// 		when(clinicalTrialRepository.findOne(any(Long.class))).thenReturn(clinicalTrialList.get(0));
// 		when(clinicalTrialRepository.findByTrialNameAndIdNot(anyString(), any(Long.class)))
// 				.thenReturn(new ArrayList<>());
		
// 		when(programRepository.findOne(any(Long.class))).thenReturn(pgm1);
// 		when(programRepository.save(any(Program.class))).thenReturn(pgm1);
// 		//when(trialSourceBean.publishTrialChange)
// 		when(clinicalTrialRepository.findByProgramId(any(Long.class))).thenReturn(clinicalTrialList);
		
// 		ResponseObjectModel response = clinicalTrialServiceImpl.update(clinicalTrialList.get(1));
// 		assertEquals(200, response.getStatus());
// 		assertEquals(clinicalTrialList.get(0), response.getData());
// 	}

// 	/*
// 	 * This method is to test update(ClinicalTrial) method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void updateExceptionTest() throws Exception {
// 		when(clinicalTrialRepository.save(any(ClinicalTrial.class))).thenThrow(new NullPointerException());
// 		when(clinicalTrialRepository.findOne(any(Long.class))).thenReturn(clinicalTrialList.get(1));
// 		when(clinicalTrialRepository.findByTrialNameAndIdNot(anyString(), any(Long.class)))
// 				.thenReturn(new ArrayList<>());
// 		ResponseObjectModel response = clinicalTrialServiceImpl.update(clinicalTrialList.get(1));
// 	}

// 	/*
// 	 * This method is to test delete(id) method when the trail name exists
// 	 */
// 	@Test
// 	public void deleteTest() throws Exception {
// 		doNothing().when(clinicalTrialRepository).delete(any(ClinicalTrial.class));
// 		clinicalTrialServiceImpl.delete(clinicalTrialList.get(1).getTrialId());
// 	}

// 	/*
// 	 * This method is to test delete(id) method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void deleteExceptionTest() throws Exception {
// 		doThrow(new NullPointerException()).when(clinicalTrialRepository).delete(any(Long.class));
// 		clinicalTrialServiceImpl.delete(clinicalTrialList.get(1).getTrialId());
// 	}

// 	/*
// 	 * This method is to test getAllTherapeuticAreas() method
// 	 */
// 	@Test
// 	public void getAllTherapeuticAreasTest() throws Exception {
// 		when(therapeuticAreaRepository.findAll()).thenReturn(therapeuticAreaList);
// 		List<TherapeuticArea> phases = clinicalTrialServiceImpl.getAllTherapeuticAreas();
// 		assertEquals(phaseList.size(), phases.size());
// 	}

// 	/*
// 	 * This method is to test getAllTherapeuticAreas() method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void getAllTherapeuticAreasExceptionTest() throws Exception {
// 		when(therapeuticAreaRepository.findAll()).thenThrow(new NullPointerException());
// 		clinicalTrialServiceImpl.getAllTherapeuticAreas();
// 	}

// 	/*
// 	 * This method is to test getClinicalTrialsByProgramId(id) method
// 	 */
// 	@Test
// 	public void getClinicalTrialsByProgramIdTest() throws Exception {
// 		when(clinicalTrialRepository.findByProgramId(anyLong())).thenReturn(clinicalTrialList);
// 		List<ClinicalTrial> trials = clinicalTrialServiceImpl.getClinicalTrialsByProgramId(1L);
// 		assertEquals(clinicalTrialList.size(), trials.size());
// 	}

// 	/*
// 	 * This method is to test getClinicalTrialsByProgramId(id) method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void getClinicalTrialsByProgramIdExceptionTest() throws Exception {
// 		when(clinicalTrialRepository.findByProgramId(anyLong())).thenThrow(new NullPointerException());
// 		List<ClinicalTrial> trials = clinicalTrialServiceImpl.getClinicalTrialsByProgramId(1L);
// 	}

// 	/*
// 	 * This method is to test getAllTrialStatuses() method
// 	 */
// 	@Test
// 	public void getAllTrialStatusTest() throws Exception {
// 		when(trialStatusRepository.findAll()).thenReturn(trialStatusList);
// 		List<TrialStatus> tstatuses = clinicalTrialServiceImpl.getAllTrialStatuses();
// 		assertEquals(trialStatusList.size(), tstatuses.size());
// 	}

// 	/*
// 	 * This method is to test getAllTrialStatuses() method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void getAllTrialStatusExceptionTest() throws Exception {
// 		when(trialStatusRepository.findAll()).thenThrow(new NullPointerException());
// 		clinicalTrialServiceImpl.getAllTrialStatuses();
// 	}

// 	/*
// 	 * This method is to test getAllStatus() method
// 	 */
// 	@Test
// 	public void getAllStatusTest() throws Exception {
// 		when(statusRepository.findAll()).thenReturn(statusList);
// 		List<Status> statuses = clinicalTrialServiceImpl.getAllStatus();
// 		assertEquals(statusList.size(), statuses.size());
// 	}

// 	/*
// 	 * This method is to test getAllStatus() method for exception
// 	 */
// 	@Test(expected = java.lang.NullPointerException.class)
// 	public void getAllStatusExceptionTest() throws Exception {
// 		when(statusRepository.findAll()).thenThrow(new NullPointerException());
// 		clinicalTrialServiceImpl.getAllStatus();
// 	}

// 	/*
// 	 * This method is to test getAllSponsors() method
// 	 * 
// 	 * @Test public void getSponsorsBySearchTest() throws Exception {
// 	 * when(sponsorRepository.findAll(any(PageRequest.class))).thenReturn(
// 	 * sponsorPage);
// 	 * when(sponsorRepository.findByNameContaining(anyString(),any(PageRequest.class
// 	 * ))).thenReturn(sponsorPage); List<Sponsor> sponsors =
// 	 * clinicalTrialServiceImpl.getSponsorsBySearch("sponserName",page,pageSize);
// 	 * assertEquals(sponsorList.size(),sponsors.size()); }
// 	 * 
// 	 * 
// 	 * This method is to test getAllSponsors() method for exception
// 	 * 
// 	 * @Test(expected = java.lang.NullPointerException.class) public void
// 	 * getSponsorsBySearchExceptionTest() throws Exception {
// 	 * when(sponsorRepository.findAll(any(PageRequest.class))).thenThrow(new
// 	 * NullPointerException());
// 	 * clinicalTrialServiceImpl.getSponsorsBySearch("sponserName",page,pageSize); }
// 	 */
// }
