// package com.avigosolutions.criteriaservice.service;

// import java.util.List;

// import org.junit.After;
// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.model.Collaborator;
// import com.avigosolutions.criteriaservice.service.CollaboratorService;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class CollaboratorServiceTest {

// 	@Autowired
// 	private CollaboratorService collaboratorService;
	
	
// 	private static final Long DEFAULT_COLLAB_ID = 3l;
	
// 	//@Test
// 	public void contextLoads() {
// 	}
	
// 	@Before
// 	public void setup() {
		
// 	}
	
// 	@After
// 	public void tearDown() {
		
// 	}
	
// 	@Test
// 	public void testFindAllCollaborator() {
// 		List<Collaborator> list = collaboratorService.findAll();
// 		Assert.assertNotNull("failure, collection not expected to be null", list);
// 	}
	
// 	@Test
// 	public void testFindOneCollaborator() {
// 		Long id = new Long(DEFAULT_COLLAB_ID);
// 		Collaborator collaborator = collaboratorService.findOne(id);
		
// 		Assert.assertNotNull("failure, findOne Collaborator not expected to be null", collaborator);
// 		Assert.assertNotNull("failure, findOne Collaborator not expected to be null", collaborator.getCollaboratorType());
// 	}
	
// 	@Rollback
// 	@Test 
// 	public void testCreateCollaborator() {
// 		Collaborator collaborator = new Collaborator();
// 		collaborator.withCollaboratorTypeId(2).withName("Test Collaborator1322");
// 		collaborator = collaboratorService.save(collaborator);
// 		Assert.assertNotNull("failure, Create Collaborator not expected to be null", collaborator);
// 	}
	
// 	@Rollback
// 	@Test 
// 	public void testCreateCollaboratorDuplicate() {
// 		Collaborator collaborator = new Collaborator();
// 		collaborator.withCollaboratorTypeId(2).withName("IQVIA");
// 		collaborator = collaboratorService.save(collaborator);
// 		Assert.assertNull("failure, Create duplicate Collaborator expected to be null", collaborator);
// 	}
	
// 	@Rollback
// 	@Test 
// 	public void testUpdateCollaborator() {
// 		Long id = new Long(DEFAULT_COLLAB_ID);
// 		Collaborator collaborator = collaboratorService.findOne(id);
// 		collaborator.withCollaboratorTypeId(3l);
// 		collaborator = collaboratorService.update(collaborator);
// 		Assert.assertNotNull("failure, findOne Collaborator not expected to be null", collaborator);
// 	}
	
// 	//@Rollback
// 	//@Test
// 	// commented as this testing not valid functionally.
// 	public void testDeleteCollaborator() {
// 		Long id = new Long(DEFAULT_COLLAB_ID);
// 		boolean done = collaboratorService.delete(id);
// 		Assert.assertTrue("failure, Delete Collaborator", done);
// 	}

// }
