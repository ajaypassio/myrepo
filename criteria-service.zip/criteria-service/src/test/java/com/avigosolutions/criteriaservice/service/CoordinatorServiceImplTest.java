// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.avigosolutions.criteriaservice.model.Coordinator;
// import com.avigosolutions.criteriaservice.repository.CoordinatorRepository;

// public class CoordinatorServiceImplTest {

// 	@InjectMocks
// 	CoordinatorServiceImpl coordinatorServiceImpl;
	
// 	@Mock
// 	CoordinatorRepository coordinatorRepositTory;
	
// 	protected long coordinatorId = 3L;
// 	protected Coordinator coordinator;
// 	protected List<Coordinator> coordinators;
	
// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		coordinator = new Coordinator();
// 		coordinator.withCoordinatorId(coordinatorId);
// 		coordinators = new ArrayList<Coordinator>();
// 		coordinators.add(coordinator);
// 	}
	
// 	/*
// 	 * Test findAll() method
// 	 */
// 	@Test
// 	public void findAllTest() throws Exception {
// 		when(coordinatorRepositTory.findAll()).thenReturn(coordinators);
// 		List<Coordinator> result = coordinatorServiceImpl.findAll();
// 		assertEquals("Expected match :", result, coordinators);
// 	}
	
// 	/*
// 	 * Test findOne() method
// 	 */
// 	@Test
// 	public void findOneTest() throws Exception {
// 		when(coordinatorRepositTory.findOne(coordinatorId)).thenReturn(coordinator);
// 		Coordinator result = coordinatorServiceImpl.findOne(coordinatorId);
// 		assertEquals("Expected match :", result, coordinator);
// 	}
	
	
// 	/*
// 	 * Test save() method
// 	 */
// 	@Test
// 	public void saveTest() throws Exception {
// 		coordinator.withName("Test Name");
// 		when(coordinatorRepositTory.save(coordinator)).thenReturn(coordinator);
// 		Coordinator result = coordinatorServiceImpl.save(coordinator);
// 		assertEquals("Expected match :", result, coordinator);
// 	}
	
	
// 	/*
// 	 * Test update() method
// 	 */
// 	@Test
// 	public void updateTest() throws Exception {
// 		coordinator.withName("Test Name 2");
// 		when(coordinatorRepositTory.save(coordinator)).thenReturn(coordinator);
// 		Coordinator result = coordinatorServiceImpl.update(coordinator);
// 		assertEquals("Expected match :", result, coordinator);
// 	}
	
// 	/*
// 	 * Test delete() method
// 	 */
// 	@Test
// 	public void deleteTest() throws Exception {
// 		doNothing().when(coordinatorRepositTory).delete(coordinatorId);
// 		Boolean result = coordinatorServiceImpl.delete(coordinatorId);
// 		assertEquals("Expected match :", result, true);
// 	}
	
// 	/*
// 	 * Test delete() method pass null as coordinatorId
// 	 */
// 	@Test
// 	public void deleteNullTest() throws Exception { 
// 		Boolean result = coordinatorServiceImpl.delete(null);
// 		assertEquals("Expected match :", result, false);
// 	}
	
// }
