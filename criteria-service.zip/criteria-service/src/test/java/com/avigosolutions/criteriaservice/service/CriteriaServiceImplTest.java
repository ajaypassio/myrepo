// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Matchers.any;
// import static org.mockito.Matchers.anyLong;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;

// import javax.persistence.Query;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Criteria;
// import com.avigosolutions.criteriaservice.model.CriteriaTemplate;
// import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
// import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
// import com.avigosolutions.criteriaservice.repository.CriteriaTemplateRepository;

// public class CriteriaServiceImplTest {

// 	@InjectMocks
// 	CriteriaServiceImpl criteriaServiceImpl;
	
// 	@Mock
// 	private CriteriaRepository criteriaRepository;
	
// 	@Mock
// 	private ClinicalTrialRepository clinicalTrialRepository;
	
// 	@Mock
// 	Query query;
	
// 	protected List<Criteria> criterias;
// 	Criteria criteria;
	 
// 	protected static long criteriaId = 3L;
// 	protected static long criteriaTemplateId = 3L;
// 	protected static long trailId = 3L;
// 	protected CriteriaTemplate criteriaTemplate;
// 	protected List<CriteriaTemplate> criteriaTemplates;
// 	protected ClinicalTrial clinicalTrial;
	
// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		criterias = new ArrayList<Criteria>();
// 		criteria = new Criteria();
// 		criteria.withCriteriaId(criteriaId);
// 		criteria.withTemplateId(criteriaTemplateId);
// 		criteria.withTrialId(trailId);
// 		criterias.add(criteria);
		
// 		clinicalTrial = new ClinicalTrial();
// 		clinicalTrial.withTrialId(trailId);
// 	}
	
// 	/*
// 	 * Test findAll() method
// 	 */
// 	@Test
// 	public void findAllTest() throws Exception {
// 		when(criteriaRepository.findAll()).thenReturn(criterias);
// 		List<Criteria> result = criteriaServiceImpl.findAll();
// 		assertEquals("Expected match :", criterias, result);
// 	}

	
// 	/*
// 	 * Test findOne() method
// 	 */
// 	@Test
// 	public void findOneTest() throws Exception {
// 		when(criteriaRepository.findOne(criteriaTemplateId)).thenReturn(criteria);
// 		Criteria result = criteriaServiceImpl.findOne(criteriaId);
// 		assertEquals("Expected match :", criteria, result);
// 	}
	
	
	
// 	/*
// 	 * Test findByTrialId() method
// 	 */
// 	@Test
// 	public void findByTrialIdTest() throws Exception {
// 		when(criteriaRepository.findByTrialId(trailId)).thenReturn(criterias);
// 		List<Criteria> result = criteriaServiceImpl.findByTrialId(trailId);
// 		assertEquals("Expected match :", result, criterias);
// 	}
	
	
	
// 	/*
// 	 * Test findByTrialId() method
// 	 */
// 	@Test
// 	public void findByTemplateIdTest() throws Exception {
// 		when(criteriaRepository.findByTemplateId(criteriaTemplateId)).thenReturn(criterias);
// 		List<Criteria> result = criteriaServiceImpl.findByTemplateId(criteriaTemplateId);
// 		assertEquals("Expected match :", result, criterias);
// 	}
	
	
// 	/*
// 	 * Test save() method
// 	 */
// 	@Test
// 	public void saveTest() throws Exception { 
// 		when(criteriaRepository.save(criteria)).thenReturn(criteria);
// 		Criteria result = criteriaServiceImpl.save(criteria);
// 		assertEquals("Expected match :", criteria, result);
// 	}
	
// 	/*
// 	 * Test save() method null value
// 	 */
// 	@Test
// 	public void saveNullTest() throws Exception {  
// 		Criteria result = criteriaServiceImpl.save(null);
// 		assertEquals("Expected match :", null, result);
// 	}
	
	
// 	/*
// 	 * Test update() method
// 	 */
// 	@Test
// 	public void updateTest() throws Exception {
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		when(criteriaRepository.save(criteria)).thenReturn(criteria);
// 		Criteria result = criteriaServiceImpl.update(criteria);
// 		assertEquals("Expected match :", criteria, result);
// 	}
	
	
// 	/*
// 	 * Test update() method null criteria id
// 	 */
// 	@Test
// 	public void updateNullCriteriaIdTest() throws Exception {
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		when(criteriaRepository.save(criteria)).thenReturn(criteria);
// 		Criteria result = criteriaServiceImpl.update(criteria);
// 		assertEquals("Expected match :", criteria, result);
// 	}
	
	
// 	/*
// 	 * Test update() method with clinical trail
// 	 */
// 	@Test
// 	public void updateClinicalTrailTest() throws Exception {
// 		criteria.withClinicalTrial(clinicalTrial);
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(clinicalTrial);
// 		when(clinicalTrialRepository.save(clinicalTrial)).thenReturn(clinicalTrial);
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		when(criteriaRepository.save(criteria)).thenReturn(criteria);
// 		Criteria result = criteriaServiceImpl.update(criteria);
// 		assertEquals("Expected match :", criteria, result);
// 	}
	
// 	/*
// 	 * Test update() method with null clinical trail
// 	 */
// 	@Test
// 	public void updateClinicalTrailNullTest() throws Exception {
// 		criteria.withClinicalTrial(clinicalTrial);
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(null);
// 		when(clinicalTrialRepository.save(clinicalTrial)).thenReturn(clinicalTrial);
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		when(criteriaRepository.save(criteria)).thenReturn(criteria);
// 		Criteria result = criteriaServiceImpl.update(criteria);
// 		assertEquals("Expected match :", criteria, result);
// 	}
	
	
// 	/*
// 	 * Test findByIdIn() 
// 	 */
// 	@Test
// 	public void findByIdInTest() throws Exception {
// 		List<Long> ids = new ArrayList<Long>();
// 		ids.add(1L);
// 		when(criteriaRepository.findByIdIn(ids)).thenReturn(criterias); 
// 		List<Criteria> result = criteriaServiceImpl.findByIdIn(ids);
// 		assertEquals("Expected match :", criterias, result);
// 	}
	
	
// 	/*
// 	 * Test delete() 
// 	 */
// 	@Test
// 	public void deleteTest() throws Exception { 
// 		 criteriaServiceImpl.delete(null); 
// 	}
// }
