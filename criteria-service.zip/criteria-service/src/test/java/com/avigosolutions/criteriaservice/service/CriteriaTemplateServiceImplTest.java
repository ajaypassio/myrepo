// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Matchers.any;
// import static org.mockito.Matchers.anyLong;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;

// import javax.persistence.Query;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.avigosolutions.criteriaservice.model.Criteria;
// import com.avigosolutions.criteriaservice.model.CriteriaTemplate; 
// import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
// import com.avigosolutions.criteriaservice.repository.CriteriaTemplateRepository;

// public class CriteriaTemplateServiceImplTest {

// 	@InjectMocks
// 	CriteriaTemplateServiceImpl criteriaTemplateServiceImpl;
	
// 	@Mock
// 	private CriteriaRepository criteriaRepository;
	
// 	@Mock
// 	private CriteriaTemplateRepository criteriaTemplateRepository;
	
// 	@Mock
// 	Query query;
	
// 	protected static long criteriaTemplateId = 3L;
// 	protected CriteriaTemplate criteriaTemplate;
// 	protected List<CriteriaTemplate> criteriaTemplates;
	
// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		criteriaTemplate = new CriteriaTemplate();
// 		criteriaTemplate.withTemplateId(criteriaTemplateId);
// 		criteriaTemplates = new ArrayList<CriteriaTemplate>();
// 		criteriaTemplates.add(criteriaTemplate);
// 	}
	
// 	/*
// 	 * Test findAll() method
// 	 */
// 	@Test
// 	public void findAllTest() throws Exception {
// 		when(criteriaTemplateRepository.findAll()).thenReturn(criteriaTemplates);
// 		List<CriteriaTemplate> result = criteriaTemplateServiceImpl.findAll();
// 		assertEquals("Expected match :", result, criteriaTemplates);
// 	}
	
// 	/*
// 	 * Test findOne() method
// 	 */
// 	@Test
// 	public void findOneTest() throws Exception {
// 		when(criteriaTemplateRepository.findOne(criteriaTemplateId)).thenReturn(criteriaTemplate);
// 		CriteriaTemplate result = criteriaTemplateServiceImpl.findOne(criteriaTemplateId);
// 		assertEquals("Expected match :", result, criteriaTemplate);
// 	}
	
	
// 	/*
// 	 * Test save() method
// 	 */
// 	@Test
// 	public void saveTest() throws Exception { 
// 		when(criteriaTemplateRepository.save(criteriaTemplate)).thenReturn(criteriaTemplate);
// 		CriteriaTemplate result = (CriteriaTemplate) criteriaTemplateServiceImpl.save(criteriaTemplate).getData();
// 		assertEquals("Expected match :", result, criteriaTemplate);
// 	}
	
// 	/*
// 	 * Test save() method pass null value
// 	 */
// 	@Test
// 	public void saveNullTest() throws Exception {  
// 		CriteriaTemplate result =(CriteriaTemplate) criteriaTemplateServiceImpl.save(null).getData();
// 		assertEquals("Expected match :", result, null);
// 	}
	
// 	/*
// 	 * Test save() method with questionnaire
// 	 */
// 	@Test
// 	public void saveQuestionnaireTest() throws Exception {
// 		List<Criteria> criterias = new ArrayList<Criteria>();
// 		Criteria criteria = new Criteria();
// 		criteria.withTemplateId(criteriaTemplateId);
// 		criterias.add(criteria);
// 		criteriaTemplate.withCriterias(criterias);
// 		when(criteriaRepository.save(any(Criteria.class))).thenReturn(criteria);
// 		when(criteriaTemplateRepository.save(criteriaTemplate)).thenReturn(criteriaTemplate);
// 		CriteriaTemplate result = (CriteriaTemplate) criteriaTemplateServiceImpl.save(criteriaTemplate).getData();
// 		assertEquals("Expected match :", result, criteriaTemplate);
// 	}
	
// 	/*
// 	 * Test update() method
// 	 */
// 	@Test
// 	public void updateTest() throws Exception { 
// 		Optional<CriteriaTemplate> expected = Optional.ofNullable(criteriaTemplate);
// 		when(criteriaTemplateRepository.findById(anyLong())).thenReturn(criteriaTemplate);
// 		when(criteriaTemplateRepository.save(criteriaTemplate)).thenReturn(criteriaTemplate);
// 		Optional<CriteriaTemplate> result =(Optional<CriteriaTemplate> ) criteriaTemplateServiceImpl.update(criteriaTemplate).getData();
// 		assertEquals("Expected match :", expected, result);
// 	}
	
// 	/*
// 	 * Test delete() method
// 	 */
// //	@Test
// //	public void deleteTest() throws Exception { 
// //		 when(query.executeUpdate()).thenReturn(1);
// //		criteriaTemplateServiceImpl.delete(criteriaTemplateId); 
// //	}
	
// 	/*
// 	 * Test delete() method pass null as coordinatorId
// 	 */
// 	@Test
// 	public void deleteNullTest() throws Exception { 
// 		criteriaTemplateServiceImpl.delete(null); 
// 	}
	
// }
