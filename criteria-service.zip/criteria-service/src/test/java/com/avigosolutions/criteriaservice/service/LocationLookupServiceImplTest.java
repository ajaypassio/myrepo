// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Matchers.any;
// import static org.mockito.Matchers.anyListOf;
// import static org.mockito.Matchers.anyString;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.List;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.data.domain.PageRequest;

// import com.avigosolutions.criteriaservice.model.City;
// import com.avigosolutions.criteriaservice.model.State;
// import com.avigosolutions.criteriaservice.repository.CityRepository;
// import com.avigosolutions.criteriaservice.repository.StateRepository;

// public class LocationLookupServiceImplTest {

// 	@InjectMocks
// 	LocationLookupServiceImpl locationLookupServiceImpl;
	
// 	@Mock
// 	private CityRepository cityRepository;
	
// 	@Mock
// 	private StateRepository stateRepository;
	
// 	protected static int page = 1;
// 	protected static int pageSize = 10;
// 	protected PageRequest pageRequest;
	
// 	// City
// 	protected long cityId = 3L;
// 	protected static String cityName = "Alaskha";
// 	protected City city;
// 	protected List<City> cities;	
	
// 	// State
// 	protected long stateId = 3L;
// 	protected static String stateName = "FL";
// 	protected State state;
// 	protected List<State> states;
	
// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		pageRequest = new PageRequest(page, pageSize);
// 		// City
// 		city = new City();
// 		city.withId(cityId);
// 		city.withCityName(cityName);
// 		cities = new ArrayList<City>();
// 		cities.add(city);
		
// 		//State
// 		state = new State();
// 		state.withId(cityId);
// 		state.withStateName(cityName);
// 		states = new ArrayList<State>();
// 		states.add(state);
// 	}
	
// 	/*
// 	 * Test getCitiesList() method
// 	 */
// 	@Test
// 	public void getCitiesListTest() throws Exception {
// 		when(cityRepository.findByCityNameContaining(cityName, pageRequest)).thenReturn(cities);
// 		List<City> result = locationLookupServiceImpl.getCitiesList(cityName, page, pageSize);
// 		assertEquals("Expected match :", result, cities);
// 	}
	
// 	/*
// 	 * Test getStatesList() method
// 	 */
// 	@Test
// 	public void getStatesListTest() throws Exception {
// 		when(stateRepository.findByStateNameContaining(stateName, pageRequest)).thenReturn(states);
// 		List<State> result = locationLookupServiceImpl.getStatesList(stateName, page, pageSize);
// 		assertEquals("Expected match :", result, states);
// 	}
	
// 	@Test
// 	public void getCitiesForStatesListTest() throws Exception {
// 		when(cityRepository.findByCityNameContainingAndStateIdIn(anyString(), anyListOf(Long.class), any(PageRequest.class))).thenReturn(cities);
// 		List<City> result = locationLookupServiceImpl.getCitiesListForStates(Arrays.asList(22L,11L), cityName, page, pageSize);
// 		assertEquals("Expected match :", result, cities);
// 	}
	 
	
// }
