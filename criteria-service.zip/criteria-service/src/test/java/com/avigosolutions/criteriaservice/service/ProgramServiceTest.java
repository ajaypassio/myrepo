// package com.avigosolutions.criteriaservice.service;

// import java.util.HashSet;
// import java.util.List;
// import java.util.Set;

// import org.junit.After;
// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.model.Collaborator;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.service.ProgramService;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class ProgramServiceTest {

// 	@Autowired
// 	private ProgramService programService;

// 	private static final Long DEFAULT_PROG_ID = 2l;

// 	@Before
// 	public void setup() {

// 	}

// 	@After
// 	public void tearDown() {

// 	}

// 	@Test
// 	public void testFindAllPrograms() {
// 		List<Program> list = programService.findAll();
// 		Assert.assertNotNull("failure, collection not expected to be null", list);
// 	}

// 	@Test
// 	public void testFindOneCriteria() {
// 		Long id = new Long(DEFAULT_PROG_ID);
// 		Program program = programService.findOne(id);

// 		Assert.assertNotNull("failure, findOne Program not expected to be null", program);
// 		// Assert.assertEquals("failure expected Criteria id of 1", id,
// 		// criteria.getCriteriaId());
// 	}

// 	@Rollback
// 	@Test
// 	public void testCreateProgram() {
// 		Collaborator col = new Collaborator().withCollaboratorId(3L);
// 		Set<Collaborator> collaboratorSet = new HashSet<>();
// 		collaboratorSet.add(col);
// 		Program program = new Program().withProgramId(1l).withName("Test program 11").withCollaborators(collaboratorSet);		
// 		programService.save(program);
// 		Assert.assertNotNull("failure, Create Program not expected to be null", program);
// 	}

// 	@Rollback
// 	@Test
// 	public void testCreateProgramDuplicate() {
// 		Program program = new Program().withName("NASH Program");

// 		program =(Program) programService.save(program).getData();
// 		Assert.assertNull("failure, Create Duplicate Program expected to be null", program);
// 	}

// 	@Rollback
// 	@Test
// 	public void testUpdateProgram() {
// 		Collaborator col = new Collaborator().withCollaboratorId(3L);
// 		Set<Collaborator> collaboratorSet = new HashSet<>();
// 		collaboratorSet.add(col);
// 		Long id = new Long(DEFAULT_PROG_ID);
// 		Program program = programService.findOne(id);
// 		program.withName("Test Program 222").withCollaborators(collaboratorSet);

// 		program =(Program) programService.update(program).getData();
// 		Assert.assertEquals("failure, update program", "Test Program 222", program.getName());
// 	}

// 	@Rollback
// 	@Test
// 	public void testDeleteProgram() {
// 		Long id = new Long(DEFAULT_PROG_ID);
// 		boolean deleted = programService.delete(id);
// 		Assert.assertTrue("failure, Delete", deleted);
// 	}

// }
