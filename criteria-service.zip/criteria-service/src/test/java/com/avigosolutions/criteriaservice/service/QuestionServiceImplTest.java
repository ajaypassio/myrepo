// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.doThrow;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.Mockito;
// import org.mockito.MockitoAnnotations;

// import com.avigosolutions.criteriaservice.model.Coordinator;
// import com.avigosolutions.criteriaservice.model.Question;
// import com.avigosolutions.criteriaservice.model.Questionnaire;
// import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
// import com.avigosolutions.criteriaservice.repository.QuestionRepository;
// import com.avigosolutions.criteriaservice.repository.QuestionnaireRepository;

// public class QuestionServiceImplTest {
	
// 	@InjectMocks
// 	QuestionServiceImpl questionServiceImpl;
	
// 	@Mock
// 	QuestionnaireRepository questionnaireRepository;
	
// 	@Mock
// 	QuestionRepository questionRepository;
	
// 	@Mock
// 	CriteriaRepository criteriaRepository;
	
// 	protected Question question;
// 	protected List<Question> questions;
// 	protected long questionId = 2L;
// 	protected long questionaireId = 3L;
	
// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		question = new Question();
// 		question.withQuestionId(questionId);
// 		question.withQuestionnaireId(questionaireId);
// 		questions = new ArrayList<Question>();
// 		questions.add(question);
// 	}
	
// 	/*
// 	 * findAll() method test
// 	 */
	
// 	@Test
// 	public void findAllTest() throws Exception{
// 		when(questionRepository.findAll()).thenReturn(questions);
// 		List<Question> result = questionServiceImpl.findAll();
// 		assertEquals("Expected match :", questions, result);
// 	}
	
	
// 	/*
// 	 * findOne() method test
// 	 */
	
// 	@Test
// 	public void findOneTest() throws Exception{
// 		when(questionRepository.findOne(questionId)).thenReturn(question);
// 		Question result = questionServiceImpl.findOne(questionId);
// 		assertEquals("Expected match :", question, result);
// 	}
	
// 	/*
// 	 * findByQuestionnaireId() method test
// 	 */
	
// 	@Test
// 	public void findByQuestionnaireIdTest() throws Exception{
// 		when(questionRepository.findByQuestionnaireId(questionaireId)).thenReturn(questions);
// 		List<Question> result = questionServiceImpl.findByQuestionnaireId(questionaireId);
// 		assertEquals("Expected match :", questions, result);
// 	} 
	
	
// 	/*
// 	 * save() method test
// 	 */
	
// 	@Test
// 	public void saveTest() throws Exception{
// 		when(questionRepository.findOne(questionId)).thenReturn(question);
// 		when(questionRepository.save(question)).thenReturn(question);
// 		Question result = questionServiceImpl.save(question);
// 		assertEquals("Expected match :", question, result);
// 	}
	
	
// 	/*
// 	 * save() method test null check
// 	 */
	
// 	@Test
// 	public void saveTestNull() throws Exception{ 
// 		Question result = questionServiceImpl.save(null);
// 		assertEquals("Expected match :", null, result);
// 	}
	
// 	/*
// 	 * update() method test
// 	 */
	
// 	@Test
// 	public void updateTest() throws Exception{
// 		when(questionRepository.findOne(questionId)).thenReturn(question);
// 		when(questionRepository.save(question)).thenReturn(question);
// 		Question result = questionServiceImpl.update(question);
// 		assertEquals("Expected match :", question, result);
// 	} 
	
// 	/*
// 	 * update() method test with Questionnaire object
// 	 */
	
// 	@Test
// 	public void updateQuestionnaireTest() throws Exception{
// 		Questionnaire questionnaire = new Questionnaire();
// 		questionnaire.withQuestionnaireId(questionaireId);
// 		questionnaire.withName("Test Data");
// 		// Set questionnaire to question object
// 		question.withQuestionnaire(questionnaire);
// 		when(questionRepository.findOne(questionId)).thenReturn(question);
// 		when(questionRepository.save(question)).thenReturn(question);
// 		when(questionnaireRepository.findOne(questionaireId)).thenReturn(questionnaire);
// 		when(questionnaireRepository.save(questionnaire)).thenReturn(questionnaire);
// 		Question result = questionServiceImpl.update(question);
// 		assertEquals("Expected match :", question, result);
// 	} 
	
// 	/*
// 	 * Test delete() method
// 	 */
// 	@Test
// 	public void deleteTest() throws Exception {
// 		doNothing().when(questionRepository).delete(questionId);
// 		Boolean result = questionServiceImpl.delete(questionId);
// 		assertEquals("Expected match :",true, result);
// 	}
	
	
// 	/*
// 	 * Test delete() method null check
// 	 */
// 	@Test
// 	public void deleteNullTest() throws Exception { 
// 		Boolean result = questionServiceImpl.delete(null);
// 		assertEquals("Expected match :", false, result);
// 	}
	
// 	/*
// 	 * Test delete() method exception handling
// 	 */
// 	@Test
// 	public void deleteExceptionTest() throws Exception {
// 		doThrow(new NullPointerException()).when(questionRepository).delete(questionId); 
// 		Boolean result = questionServiceImpl.delete(questionId);
// 		assertEquals("Expected match :", false, result);
// 	}
	
// 	/*
// 	 * Test findByIdIn() function
// 	 */
// 	@Test
// 	public void findByIdInTest() throws Exception {
// 		List<Long> ids = new ArrayList<Long>();
// 		ids.add(1L);
// 		ids.add(2L);
// 		when(questionRepository.findByIdIn(ids)).thenReturn(questions);
// 		List<Question> result= questionServiceImpl.findByIdIn(ids);
// 		assertEquals("Expected match :", questions, result);
// 	}

	 
// }
