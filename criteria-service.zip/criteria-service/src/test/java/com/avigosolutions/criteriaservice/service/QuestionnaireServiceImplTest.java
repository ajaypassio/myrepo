// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertFalse;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertNull;
// import static org.junit.Assert.assertTrue;
// import static org.mockito.Matchers.*;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.text.SimpleDateFormat;
// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Date;
// import java.util.List;
// import java.util.Optional;

// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.mockito.Spy;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageRequest;
// import org.springframework.test.util.ReflectionTestUtils;
// import org.springframework.web.client.RestTemplate;

// import com.avigosolutions.criteriaservice.dto.QuestionnaireDto;
// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.Criteria;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.model.Question;
// import com.avigosolutions.criteriaservice.model.Questionnaire;
// import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
// import com.avigosolutions.criteriaservice.repository.CriteriaRepository;
// import com.avigosolutions.criteriaservice.repository.ProgramRepository;
// import com.avigosolutions.criteriaservice.repository.QuestionRepository;
// import com.avigosolutions.criteriaservice.repository.QuestionnaireRepository;
// import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.util.PageBuilder;

// public class QuestionnaireServiceImplTest {
	
// 	@Mock
// 	RestTemplate restTemplate;
	
// 	@InjectMocks
// 	@Spy
// 	QuestionnaireServiceImpl questionnaireServiceImpl;
	
// 	@Mock
// 	QuestionnaireRepository questionnaireRepository;

// 	@Mock
// 	ProgramRepository programRepository;
	
// 	@Mock
// 	ClinicalTrialRepository clinicalTrialRepository;
	
// 	@Mock
// 	QuestionRepository questionRepository;
	
// 	@Mock
// 	CriteriaRepository criteriaRepository;
	
	
// 	protected final int page = 1;
// 	protected final int pageSize = 10;
// 	protected ResponseObjectModel responseObject;
// 	protected Questionnaire questionnaire1,questionnaire2,questionnaire3;
// 	protected Question question1,question2;
// 	protected Page<Questionnaire> pageList,emptyPageList;
// 	protected PageRequest pageRequest;

// 	protected List<Questionnaire> questionnaireList1;
// 	protected List<Question> questionList1;

// 	protected ClinicalTrialFilterRequestModel clinicalTrialFilterRequestModel;
	
// 	@Before
// 	public void init() {
// 		MockitoAnnotations.initMocks(this);
// 		responseObject=new ResponseObjectModel();
// 		questionnaireList1 = new ArrayList<>();
// 		questionList1 = new ArrayList<>();
// 		pageRequest = new PageRequest(page, pageSize);
// 		questionnaire1 = new Questionnaire();
// 		questionnaire2 = new Questionnaire();
// 		questionnaire3 = new Questionnaire();		
// 		question1 = new Question();
// 		question2 = new Question();	
// 		dataSetup();
		
// 		pageList = new PageBuilder<Questionnaire>()
// 	              .elements(questionnaireList1)
// 	              .pageRequest(pageRequest)
// 	              .totalElements(questionnaireList1.size())
// 	              .build();
// 		emptyPageList = new PageBuilder<Questionnaire>()
// 	              .elements(new ArrayList<Questionnaire>())
// 	              .pageRequest(pageRequest)
// 	              .totalElements(0)
// 	              .build();
		
// 		ReflectionTestUtils.setField(questionnaireServiceImpl, "participantServiceSubstituteURL", "http://participant-service/api/v1/participant/addCRMSubstitution?key=:SUB_KEY&value=:SUB_VALUE");		
// 		ReflectionTestUtils.setField(questionnaireServiceImpl, "patientPortalLandingPageURL", "http://patient-portal/assets/outreach/landing_page.html?qid=:QUESTIONNAIRE_ID&pid=%patientID%");
		
		
// 	}
	
// 	@After
// 	public void cleanup() {
// 		responseObject=null;
// 		questionnaireList1 = null;
// 		questionList1 = null;
// 		pageRequest = null;
// 		questionnaire1 = null;
// 		questionnaire2 = null;
// 		questionnaire3 = null;		
// 		question1 = null;
// 		question2 = null;		
// 		pageList = null;
// 		emptyPageList = null;		
// 	}
	
// 	private void dataSetup() {
// 		String sDate1="31/01/2018";  
// 		String sDate2="25/02/2018";
// 		try {
// 			questionnaire1.setCreatedOn(new SimpleDateFormat("dd/MM/yyyy").parse(sDate1));
// 			questionnaire2.setCreatedOn(new SimpleDateFormat("dd/MM/yyyy").parse(sDate2));
// 		}catch(Exception e) {
// 			questionnaire1.setCreatedOn(new Date());
// 			questionnaire2.setCreatedOn(new Date());
// 		}
// 		questionnaire1.withQuestions(Arrays.asList(question1.withQuestionName("question1").withCriteriaId(1L)));
// 		questionnaire2.withQuestions(Arrays.asList(question2.withQuestionName("question2").withCriteriaId(2L)));
// 		questionList1.add(question1.withQuestionName("question1").withCriteriaId(1L));
// 		questionList1.add(question2.withQuestionName("question2").withCriteriaId(2L));		
		
// 		questionnaireList1.add(questionnaire1.withTrialId(1L).withQuestionnaireId(1L).withQuestions(questionList1));
// 		questionnaireList1.add(questionnaire2.withTrialId(1L).withQuestionnaireId(2L));
		
// 	}

// 	@Test
// 	public void findAllTest() {
// 		Program program = new Program().withProgramId(1L).withName("Test program 11");	
// 		ClinicalTrial clinicalTrial1 = new ClinicalTrial().withTrialId(1L).withTrialName("Name1").withProgramId(1L);
// 		when(questionnaireRepository.findAll()).thenReturn(questionnaireList1);
// 		when(programRepository.findOne(anyLong())).thenReturn(program);
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(clinicalTrial1);

// 		List<QuestionnaireDto> questionList = questionnaireServiceImpl.findAll();
// 		assertNotNull(questionList);
// 		assertEquals(questionnaireList1.size(),questionList.size());
// 	}
	
// 	@Test
// 	public void findOneTest() {
		
// 		when(questionnaireRepository.findOne(anyLong())).thenReturn(questionnaire1);
// 		Criteria criteria = new Criteria().withCriteriaId(1l).withIsInclude(true);
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		Questionnaire question1 = questionnaireServiceImpl.findOne(1L);
// 		assertNotNull(question1);
// 		assertEquals(question1.getCreatedOn(),questionnaireList1.get(0).getCreatedOn());
// 	}
	
// 	@Test
// 	public void saveTest() {
// 		ClinicalTrial clinicalTrial1 = new ClinicalTrial().withTrialId(1L).withTrialName("Name1");
// 		when(questionnaireRepository.save(any(Questionnaire.class))).thenReturn(questionnaireList1.get(0));
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(clinicalTrial1);
// 		Optional<Questionnaire> response= questionnaireServiceImpl.save(questionnaireList1.get(0));        
// 		assertTrue(response.isPresent());
// 		assertEquals(questionnaireList1.get(0).getCreatedOn(),response.get().getCreatedOn());
// 		assertEquals(questionnaireList1.get(0).getQuestionnaireId(),response.get().getQuestions().get(0).getQuestionnaireId().longValue());
// 	}
	
// 	@Test
// 	public void saveNoQuestionsTest() {
// 		when(questionnaireRepository.save(any(Questionnaire.class))).thenReturn(questionnaireList1.get(1));
// 		ClinicalTrial clinicalTrial1 = new ClinicalTrial().withTrialId(1L).withTrialName("Name1");
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(clinicalTrial1);
// 		Optional<Questionnaire> response= questionnaireServiceImpl.save(questionnaireList1.get(1));        
// 		assertTrue(response.isPresent());
// 		assertEquals(questionnaireList1.get(1).getCreatedOn(),response.get().getCreatedOn());
// 		assertNotNull(response.get().getQuestions());
// 	}
	
// 	@Test
// 	public void saveNullTest() {
// 		when(questionnaireRepository.save(any(Questionnaire.class))).thenReturn(questionnaireList1.get(0));
// 		Optional<Questionnaire> response = questionnaireServiceImpl.save(null);        
// 		assertFalse(response.isPresent());
// 	}
	
	
// 	@Test
// 	public void updateTest() {
// 		when(questionnaireRepository.findOne(anyLong())).thenReturn(questionnaire1);
// 		when(questionnaireRepository.save(any(Questionnaire.class))).thenReturn(questionnaireList1.get(0));
// 		ClinicalTrial clinicalTrial1 = new ClinicalTrial().withTrialId(1L).withTrialName("Name1");
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(clinicalTrial1);
// 		Optional<Questionnaire> response = questionnaireServiceImpl.update(questionnaireList1.get(0));        
// 		assertTrue(response.isPresent());
// 	}
	
// 	@Test
// 	public void updateNullTest() {
// 		when(questionnaireRepository.findOne(anyLong())).thenReturn(questionnaire1);
// 		when(questionnaireRepository.save(any(Questionnaire.class))).thenReturn(questionnaireList1.get(0));
// 		Optional<Questionnaire> response = questionnaireServiceImpl.update(null);        
// 		assertFalse(response.isPresent());
// 	}
	
// 	@Test
// 	public void deleteTest() {
// 		doNothing().when(questionnaireRepository).delete(anyLong());		
// 		questionnaireServiceImpl.delete(1L);
// 	}
	
// 	@Test
// 	public void findAllQuestionnaireIdTest() {
// 		when(questionnaireRepository.findById(anyLong())).thenReturn(questionnaire1);
// 		Criteria criteria = new Criteria().withCriteriaId(1l).withIsInclude(true);
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		Questionnaire question1 = questionnaireServiceImpl.findAllQuestionnaireId(1L);
// 		assertNotNull(question1);
// 		assertEquals(question1.getCreatedOn(),questionnaireList1.get(0).getCreatedOn());
// 	}
	
// 	@Test
// 	public void findAllQuestionnaireIdsTest() {
// 		List<Long> ids = new ArrayList<Long>();
// 		ids.add(1L);
// 		when(questionnaireRepository.findByIdIn(anyList())).thenReturn(questionnaireList1);
// 		Criteria criteria = new Criteria().withCriteriaId(1l).withIsInclude(true);
// 		when(criteriaRepository.findOne(anyLong())).thenReturn(criteria);
// 		List<Questionnaire> question1 = questionnaireServiceImpl.findAllQuestionnaireIds(ids);
// 		assertNotNull(question1);
// 		assertEquals(questionnaireList1.get(0).getCreatedOn(),question1.get(0).getCreatedOn());
// 	}
	
// }
