// package com.avigosolutions.criteriaservice.service;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.model.Question;
// import com.avigosolutions.criteriaservice.model.Questionnaire;
// import com.avigosolutions.criteriaservice.request.model.ClinicalTrialFilterRequestModel;
// import com.avigosolutions.criteriaservice.request.model.QuestionnaireFilterRequestModel;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class QuestionnaireServiceTest {

// 	@Autowired
// 	QuestionnaireService questionnaireService;

// 	@Autowired
// 	QuestionService questionService;

// 	protected final int page = 1;
// 	protected final int pageSize = 10;
// 	protected ResponseObjectModel responseObject;

// 	protected ClinicalTrialFilterRequestModel clinicalTrialFilterRequestModel;

// 	@Before
// 	public void init() {
// 		responseObject = new ResponseObjectModel();
// 	}

// 	@After
// 	public void cleanup() {
// 		responseObject = null;
// 	}

// 	@Test
// 	public void findAllTest() {
// 		QuestionnaireFilterRequestModel filter = getQuestionairFilterMode();
// 		questionnaireService.retrieveQuestionnaires(filter,"program");
// 	}

// 	@Test
// 	@Rollback
// 	public void updateQuestionnaire() {
// 		List<Question> questionList = new ArrayList<>();
// 		questionList.add(new Question().withQuestionName("Are you interested in this trial?").withCorrectAnswer("Yes"));
// 		Questionnaire newQuestionnaire = new Questionnaire().withName("Sample Questionnaire").withDescription("Sample").withTrialId(10L).withQuestions(questionList);
// 		Questionnaire savedQuestionnaire = questionnaireService.save(newQuestionnaire).get();
// 		Questionnaire ct = questionnaireService.findOne(savedQuestionnaire.getQuestionnaireId());
// 		List<Question> questions = ct.getQuestions();
		
// 		for (Question question : questions) {
// 			question.withQuestionnaireId(ct.getQuestionnaireId()).withQuestionName("testing1");
// 		}
// 		ct.withDescription("testing1");
// 		questions.add(new Question().withQuestionnaireId(ct.getQuestionnaireId()).withQuestionName("").withDescription("testting "));
// 		questionnaireService.update(ct);
// 	}

// 	private QuestionnaireFilterRequestModel getQuestionairFilterMode() {
// 		QuestionnaireFilterRequestModel filter = new QuestionnaireFilterRequestModel();
// 		filter.withTrialId(4l).withPageSize(10).withSortDirection("asc");
// 		return filter;
// 	}
// }
