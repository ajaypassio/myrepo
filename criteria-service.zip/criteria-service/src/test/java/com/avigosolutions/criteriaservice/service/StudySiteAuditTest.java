// package com.avigosolutions.criteriaservice.service;

// import java.util.Date;
// import java.util.HashSet;
// import java.util.List;
// import java.util.Optional;
// import java.util.Set;

// import org.junit.After;
// import org.junit.AfterClass;
// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.BeforeClass;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.model.Collaborator;
// import com.avigosolutions.criteriaservice.model.Program;
// import com.avigosolutions.criteriaservice.model.StudySite;
// import com.avigosolutions.criteriaservice.model.StudySiteAudit;
// import com.avigosolutions.criteriaservice.repository.StudySiteAuditRepository;
// import com.avigosolutions.criteriaservice.response.model.StudySiteAuditResponse;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class StudySiteAuditTest {
	
// 	@Autowired
// 	StudySiteService studySiteService;
	
// 	@Autowired
// 	private StudySiteAuditRepository studySiteAuditRepository;
	
// 	private Long studySiteAuditId;

// 	@Before
// 	public void setup() {
// 		StudySiteAudit studySiteAudit = new StudySiteAudit();
// 		studySiteAudit.setStudySiteId(1L);
// 		studySiteAudit.setPreviousStatus(true);
// 		studySiteAudit.setChangedStatus(false);
// 		studySiteAudit.setUpdatedBy(121L);
// 		studySiteAudit.setUpdatedOn(new Date());
// 		StudySiteAudit savedStudySiteAudit = studySiteAuditRepository.save(studySiteAudit);
// 		studySiteAuditId = savedStudySiteAudit.getId();
// 	}

// 	@After
// 	public void tearDown() {
// 		studySiteAuditRepository.deleteAll();

// 	}
	
// 	@Test
// 	@Rollback
// 	public void testFindAuditLogStudySite() {
// 		List<StudySiteAuditResponse> auditReportList = studySiteService.getStudySiteAuditReport(1L);
// 		Assert.assertNotNull("failure, collection not expected to be null", auditReportList);
// 		Assert.assertEquals("audit report length",auditReportList.size(),1);
// 	}
	
// 	@Rollback
// 	@Test
// 	public void testUpdateStudySite() {
// 		StudySite studySite = new StudySite().withId(1L).withActive(false);

// 		Optional<StudySite> updatedStudySite = studySiteService.update(studySite);
// 		List<StudySiteAuditResponse> auditReportList = studySiteService.getStudySiteAuditReport(1L);
// 		Assert.assertTrue("failure, update program", updatedStudySite.isPresent());
// 		Assert.assertNotNull(auditReportList);
// 	}

// }
