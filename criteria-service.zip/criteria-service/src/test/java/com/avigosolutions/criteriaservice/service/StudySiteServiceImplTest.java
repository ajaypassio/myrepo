// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertFalse;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertNull;
// import static org.junit.Assert.assertTrue;
// import static org.mockito.Matchers.any;
// import static org.mockito.Matchers.anyDouble;
// import static org.mockito.Matchers.anyFloat;
// import static org.mockito.Matchers.anyListOf;
// import static org.mockito.Matchers.anyLong;
// import static org.mockito.Matchers.anyObject;
// import static org.mockito.Matchers.anyString;
// import static org.mockito.Mockito.when;

// import java.io.IOException;
// import java.text.SimpleDateFormat;
// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Date;
// import java.util.List;
// import java.util.Optional;
// import java.util.Scanner;
// import java.util.stream.Collectors;

// import org.hamcrest.Matchers;
// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.ArgumentMatcher;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageRequest;
// import org.springframework.data.jpa.domain.Specification;
// import org.springframework.mock.web.MockMultipartFile;
// import org.springframework.test.util.ReflectionTestUtils;
// import org.springframework.test.web.client.MockRestServiceServer;
// import org.springframework.web.client.RestTemplate;

// import com.avigosolutions.criteriaservice.dto.CoordinatorDto;
// import com.avigosolutions.criteriaservice.dto.Properties;
// import com.avigosolutions.criteriaservice.dto.StudySiteDto;
// import com.avigosolutions.criteriaservice.model.City;
// import com.avigosolutions.criteriaservice.model.ClinicalStudySiteId;
// import com.avigosolutions.criteriaservice.model.ClinicalTrial;
// import com.avigosolutions.criteriaservice.model.ClinicalTrialStudySite;
// import com.avigosolutions.criteriaservice.model.Coordinator;
// import com.avigosolutions.criteriaservice.model.PrincipalInvestigator;
// import com.avigosolutions.criteriaservice.model.State;
// import com.avigosolutions.criteriaservice.model.StudySite;
// import com.avigosolutions.criteriaservice.model.StudySitePrincipalInvestigator;
// import com.avigosolutions.criteriaservice.repository.CityRepository;
// import com.avigosolutions.criteriaservice.repository.ClinicalStudySiteRepository;
// import com.avigosolutions.criteriaservice.repository.ClinicalTrialRepository;
// import com.avigosolutions.criteriaservice.repository.CoordinatorRepository;
// import com.avigosolutions.criteriaservice.repository.PrincipalInvestigatorRepository;
// import com.avigosolutions.criteriaservice.repository.StateRepository;
// import com.avigosolutions.criteriaservice.repository.StudySiteAuditRepository;
// import com.avigosolutions.criteriaservice.repository.StudySiteCoordinatorRepository;
// import com.avigosolutions.criteriaservice.repository.StudySitePrincipalInvestigatorRepository;
// import com.avigosolutions.criteriaservice.repository.StudySiteRepository;
// import com.avigosolutions.criteriaservice.request.model.LocationSearch;
// import com.avigosolutions.criteriaservice.request.model.StudySiteFilterRequestModel;
// import com.avigosolutions.criteriaservice.response.model.FileResponseModel;
// import com.avigosolutions.criteriaservice.response.model.ResponseObjectModel;
// import com.avigosolutions.criteriaservice.response.model.StudySiteResponse;
// import com.avigosolutions.criteriaservice.util.CommonUtil;
// import com.avigosolutions.criteriaservice.util.PageBuilder;



// public class StudySiteServiceImplTest {
	
// 	@Mock
// 	private StudySiteRepository studySiteRepository;
// 	@Mock
// 	protected RestTemplate restTemplate;

// 	@Mock
// 	private ClinicalStudySiteRepository clinicalStudySiteRepository;

// 	@Mock
// 	private StudySitePrincipalInvestigatorRepository studySitePrincipalInvestigatorRepository;

// 	@Mock
// 	private PrincipalInvestigatorRepository principalInvestigatorRepository;

// 	@Mock
// 	private StudySiteCoordinatorRepository studySiteCoordinatorRepository;
	
// 	@Mock
// 	private StudySiteAuditRepository studySiteAuditRepository;

// 	@Mock
// 	private ClinicalTrialRepository clinicalTrialRepository;

// 	@Mock
// 	private CoordinatorRepository coordinatorRepository;
	
// 	@Mock
// 	private CityRepository cityRepository;
	
// 	@Mock
// 	private StateRepository stateRepository;
	
// 	@InjectMocks
// 	private StudySiteServiceImpl studySiteServiceImpl;
	
// 	private MockMultipartFile multipartFile,csvMultipartFile;
	
// 	@Autowired
// 	private MockRestServiceServer server;
	
	
// 	protected final int page = 1;
// 	protected final int pageSize = 10;
// 	protected ResponseObjectModel responseObject;
// 	protected StudySite site1,site2,site3;
// 	protected ClinicalTrial trial1,trial2;
// 	//protected Question question1,question2;
// 	protected Page<StudySite> pageList,emptyPageList;
// 	protected PageRequest pageRequest;
// 	protected Properties properties;
// 	protected List<StudySite> siteList1;
// 	protected List<ClinicalTrial> trialList1;
// 	protected List<ClinicalTrialStudySite> lstClinicalTrialStudySite;
// 	protected List<String> mpList;
// 	protected List<Coordinator> coordinators;
// 	protected List<StudySitePrincipalInvestigator> lstStudySitePrincipalInvestigators;
// 	protected List<State> stateList;
// 	protected List<City> cityList;

// 	protected StudySiteFilterRequestModel studySiteFilterRequestModel;
	
	
// 	@Before
// 	public void init() {
// 		MockitoAnnotations.initMocks(this);
// 		ReflectionTestUtils.setField(studySiteServiceImpl,"participantUrl","http://localhost:9003/api/v1/participant/studysites/count/");
// 		responseObject=new ResponseObjectModel();
// 		siteList1 = new ArrayList<>();
// 		lstClinicalTrialStudySite = new ArrayList<>();
// 		trialList1 = new ArrayList<>();
// 		coordinators = new ArrayList<>();
// 		mpList = new ArrayList<String>();
// 		lstStudySitePrincipalInvestigators = new ArrayList<>();
// 		properties = new Properties();
// 		pageRequest = new PageRequest(page, pageSize);
// 		site1 = new StudySite();
// 		site2 = new StudySite();
// 		site3 = new StudySite();
// 		//restTemplate = new RestTemplate();
// 		//question1 = new Question();
// 		//question2 = new Question();	
// 		dataSetup();
		
// 		pageList = new PageBuilder<StudySite>()
// 	              .elements(siteList1)
// 	              .pageRequest(pageRequest)
// 	              .totalElements(siteList1.size())
// 	              .build();
// 		emptyPageList = new PageBuilder<StudySite>()
// 	              .elements(new ArrayList<StudySite>())
// 	              .pageRequest(pageRequest)
// 	              .totalElements(0)
// 	              .build();
		
// 		studySiteFilterRequestModel = new StudySiteFilterRequestModel();
// 		studySiteFilterRequestModel.setColumnToSort("Trial Name");
// 		studySiteFilterRequestModel.setPage(0);
// 		studySiteFilterRequestModel.setPageSize(10);
// 		studySiteFilterRequestModel.setStudySiteIds(siteList1.stream().map(StudySite::getId).collect(Collectors.toList()));
// 		studySiteFilterRequestModel.setCities(new ArrayList<String>());
// 		studySiteFilterRequestModel.setStates(new ArrayList<String>());
// 		studySiteFilterRequestModel.setDisabled(true);
		
		
// 		multipartFile = new MockMultipartFile("file","data.csv","text/csv", "Hello".getBytes() ) ;
// 		Coordinator co = new Coordinator();
// 		co.withName("coordinator1");
// 		co.withCoordinatorId(1L);
// 		coordinators.add(co);
		
// 		PrincipalInvestigator pi =new PrincipalInvestigator();
// 		pi.withName("PName");
// 		StudySitePrincipalInvestigator spi = new StudySitePrincipalInvestigator();
// 		spi.withStudySiteId(1L).withStudySitePrincipalInvestigatorId(1L).setStudySite(site1);
// 		spi.setPrincipalInvestigator(pi);
// 		lstStudySitePrincipalInvestigators.add(spi);
// 	}
	
// 	public String loadResourceAsString(String fileName)  {
// 		String contents= "";
// 		try {
// 			Scanner scanner = new Scanner(getClass().getClassLoader().getResourceAsStream(fileName));
// 			contents = scanner.useDelimiter("\\A").next();
// 			scanner.close();
// 		}catch(Exception e) {e.printStackTrace();}
// 	    return contents;
// 	}
	
// 	@After
// 	public void cleanup() {
// 		responseObject=null;
// 		siteList1 = null;
// 		pageRequest = null;
// 		site1 = null;
// 		site2 = null;
// 		site3 = null;				
// 		pageList = null;
// 		emptyPageList = null;		
// 	}
	
	
// 	private void dataSetup() {
// 		String sDate1="31/01/2018";  
// 		String sDate2="25/02/2018";
// 		try {
// 			site1.setCreatedOn(new SimpleDateFormat("dd/MM/yyyy").parse(sDate1));
// 			site2.setCreatedOn(new SimpleDateFormat("dd/MM/yyyy").parse(sDate2));
// 		}catch(Exception e) {
// 			site1.setCreatedOn(new Date());
// 			site2.setCreatedOn(new Date());
// 		}
				
		
// 		siteList1.add(site1.withId(1L));
// 		siteList1.add(site2.withId(2L));
// 		siteList1.add(site3.withActive(false));
		
// 		trial1 = new ClinicalTrial().withTrialId(1L);
// 		trial2 = new ClinicalTrial().withTrialId(2L);
		
// 		properties.withStudySiteId(1L);
		
// 		siteList1.forEach(ss->{
// 			lstClinicalTrialStudySite.add(new ClinicalTrialStudySite(new ClinicalStudySiteId(1L, ss.getId())));
// 		});
		
		
// 		stateList = new ArrayList<State>();
// 		stateList.add(new State().withId(1L).withStateName("Alabama").withAbbrev("AL"));
// 		stateList.add(new State().withId(2L).withStateName("Alaska").withAbbrev("AK"));
		
// 		cityList = new ArrayList<City>();
// 		cityList.add(new City().withId(1L).withCityName("Akron").withState(new State().withId(1L).withStateName("Alabama").withAbbrev("AL")));
// 		cityList.add(new City().withId(2L).withCityName("Albany").withState(new State().withId(1L).withStateName("Alabama").withAbbrev("AL")));
// 	}

		
// 	@Test
// 	public void saveTest() {
// 		when(studySiteRepository.save(any(StudySite.class))).thenReturn(siteList1.get(0));
// 		responseObject = studySiteServiceImpl.save(siteList1.get(0));
// 		assertEquals(200,responseObject.getStatus());
// 	}
	
	
// 	@Test
// 	public void saveNullTest() {
// 		when(studySiteRepository.save(any(StudySite.class))).thenReturn(siteList1.get(0));
// 		responseObject = studySiteServiceImpl.save(null);        
// 		assertNull(responseObject.getData());
// 	}
	
// 	@Test
// 	public void saveClinicalTrialStudySiteByTrailIdStudySiteIdsTest() {
// 		when(clinicalStudySiteRepository.save(anyListOf(ClinicalTrialStudySite.class))).thenReturn(lstClinicalTrialStudySite);
// 		Optional<List<ClinicalTrialStudySite>> res= studySiteServiceImpl.saveClinicalTrialStudySiteByTrailIdStudySiteIds(1L,siteList1.stream().map(StudySite::getId).collect(Collectors.toList()));        
// 		assertTrue(res.isPresent());
// 		assertEquals(siteList1.size(),res.get().size());
// 	}
	
// 	@Test
// 	public void saveClinicalTrialStudySiteByTrailIdStudySiteIdsNullTest() {
// 		when(studySiteRepository.save(anyListOf(StudySite.class))).thenReturn(null);
// 		Optional<List<ClinicalTrialStudySite>> res= studySiteServiceImpl.saveClinicalTrialStudySiteByTrailIdStudySiteIds(1L,siteList1.stream().map(StudySite::getId).collect(Collectors.toList()));        
// 		assertTrue(res.isPresent());
// 		assertTrue(res.get().isEmpty());
// 	}
	
// 	@Test
// 	public void updateStudySiteAlreadyExistsTest() {
// 		when(studySiteRepository.findByStudySiteNameAndIdNot(anyString(),anyLong())).thenReturn(siteList1);
// 		when(studySiteRepository.findByStudySiteName(anyString())).thenReturn(siteList1);
// 		when(studySiteRepository.findById(anyLong())).thenReturn(siteList1.get(2));
// 		responseObject = studySiteServiceImpl.updateStudySite(properties,null);
// 		assertEquals(201,responseObject.getStatus());
// 	}
	
// 	@Test
// 	public void updateStudySiteTest() {
// 		when(studySiteRepository.findByStudySiteNameAndIdNot(anyString(),anyLong())).thenReturn(null);
// 		when(studySiteRepository.findByStudySiteName(anyString())).thenReturn(null);
// 		when(studySiteRepository.findById(anyLong())).thenReturn(siteList1.get(2));
// 		responseObject = studySiteServiceImpl.updateStudySite(properties,null);
// 		assertEquals(200,responseObject.getStatus());
// 	}
	
// 	@Test
// 	public void getStudySitesByIdsTest() {
		
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class),any(PageRequest.class))).thenReturn(pageList);
// 		List<StudySiteDto> response = studySiteServiceImpl.getStudySitesByIds(siteList1.stream().map(StudySite::getId).collect(Collectors.toList()),0,10);
// 		assertNotNull(response);
// 		assertFalse(response.get(0).getFeatures().isEmpty());
// 	}
	
// 	@Test(expected=NullPointerException.class)
// 	public void getStudySitesByIdsNullTest() {
		
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class),any(PageRequest.class))).thenReturn(null);
// 		List<StudySiteDto> response = studySiteServiceImpl.getStudySitesByIds(siteList1.stream().map(StudySite::getId).collect(Collectors.toList()),0,10);
// 	}
	
// 	@Test
// 	public void findAllTest() {
		
// 		when(studySiteRepository.findAll()).thenReturn(siteList1);
// 		List<StudySiteDto> response = studySiteServiceImpl.findAll();
// 		assertNotNull(response);
// 		assertFalse(response.get(0).getFeatures().isEmpty());
// 	}
	
// 	@Test
// 	public void getTrialsByStudySiteIdTest() {
		
// 		when(clinicalStudySiteRepository
// 				.findByClinicalStudySiteIdStudySiteId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(clinicalTrialRepository.findOne(anyLong())).thenReturn(trial1);

// 		List<ClinicalTrial> response = studySiteServiceImpl.getTrialsByStudySiteId(1L);
// 		assertEquals(3,response.size());
// 		assertEquals(1L,response.get(0).getTrialId().longValue());
		
// 	}
	
// 	@Test
// 	public void getStudySitesByTrialZipMilesTest() {
		
// 		when(studySiteRepository
// 				.findByCinicalTrialStudySitesClinicalStudySiteIdIdAndLatitudeLessThanAndLatitudeGreaterThanAndLongitudeGreaterThanAndLongitudeLessThanAndActiveTrue(anyLong(),anyDouble(),anyDouble(),anyDouble(),anyDouble())).thenReturn(siteList1);
// 		when(studySiteRepository.findByCinicalTrialStudySitesClinicalStudySiteIdIdAndZip(anyLong(),anyString())).thenReturn(siteList1);

// 		StudySiteResponse response = studySiteServiceImpl.getStudySitesByTrialZipMiles(1L,15212L,1.0f);
// 		assertEquals(1,response.getMatchedStudySites().size());
		
// 	}
	
	
// 	@Test
// 	public void getStudySitesByTrialZipMilesNullTest() {
		
// 		when(studySiteRepository
// 				.findByCinicalTrialStudySitesClinicalStudySiteIdIdAndLatitudeLessThanAndLatitudeGreaterThanAndLongitudeGreaterThanAndLongitudeLessThanAndActiveTrue(anyLong(),anyDouble(),anyDouble(),anyDouble(),anyDouble())).thenReturn(null);
// 		when(studySiteRepository.findByCinicalTrialStudySitesClinicalStudySiteIdIdAndZip(anyLong(),anyString())).thenReturn(null);

// 		StudySiteResponse response = studySiteServiceImpl.getStudySitesByTrialZipMiles(1L,5000L,1.0f);
// 		assertNull(response.getMatchedStudySites());
		
// 	}
	
	
	
// 	@Test
// 	public void findByMilesTest() {
		
// 		when(studySiteRepository
// 				.findByMiles(anyFloat(),anyFloat(),anyFloat(),anyFloat(),anyLong())).thenReturn(siteList1);
		
// 		List<StudySiteDto> response = studySiteServiceImpl.findByMiles(88.00f,88.0f,77.0f,1L);
// 		assertEquals(1,response.size());
// 		assertEquals(1L,response.get(0).getTrialId().longValue());
		
// 	}
	
	
// 	//@Test
// 	public void getAllStudySitesByTrailIdTest() {
// 		when(clinicalStudySiteRepository
// 				.findByClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository
// 				.findByIdInAndActiveFalse(anyListOf(Long.class),any(PageRequest.class))).thenReturn(pageList);
		
// 		responseObject = studySiteServiceImpl.getAllStudySitesByTrailId(1L,studySiteFilterRequestModel);
// 		assertEquals(0,responseObject.getStatus());
// 		assertNotNull(responseObject.getData());
		
// 	}
	
// 	/*@Test
// 	public void getAllStudySitesByTrailIdTest_2() {
// 		ResponseObjectModel res = new ResponseObjectModel();
// 		Map<String,String> map =new HashMap<>();
// 		map.put("count","2");
// 		map.put("id","2");
// 		ResponseEntity<ResponseObjectModel> re = ResponseEntity.ok(res);
		
// 		HttpHeaders headers = CommonUtil.getHttpHeaders();
// 		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		
// 		res.setStatus(200);
// 		res.setData(map);
// 		when(restTemplate.exchange(eq("http://localhost:9003/api/v1/participant/studysites/count/1"),eq(HttpMethod.GET),Matchers.<HttpEntity<?>>any(),eq(ResponseObjectModel.class))).thenReturn(re);
// 		when(clinicalStudySiteRepository
// 				.findByClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdInAndStateInOrCityInAndActiveFalse(anyListOf(Long.class),anyListOf(String.class),anyListOf(String.class),any(PageRequest.class))).thenReturn(pageList);
// 		this.server.expect(requestTo("http://localhost:9003/api/v1/participant/studysites/count/1")).andRespond(withSuccess("ok",MediaType.APPLICATION_JSON));
// 		mpList.add("FLorida");
// 		studySiteFilterRequestModel.setStates(mpList);
// 		studySiteFilterRequestModel.setColumnToSort("referred");
// 		responseObject = studySiteServiceImpl.getAllStudySitesByTrailId(1L,studySiteFilterRequestModel);
// 		assertEquals(0,responseObject.getStatus());
// 		assertNotNull(responseObject.getData());
		
// 	}*/
	
// 	@Test
// 	public void saveToFileTest() {
		
// 		boolean saveFileFailed = false;
// 		try {
// 			studySiteServiceImpl.saveToFile(multipartFile, "data.csv");
// 		} catch (IOException e) {
// 			// TODO Auto-generated catch block
// 			e.printStackTrace();
// 			saveFileFailed = true;
// 		}

// 		assertFalse(saveFileFailed);
// 	}
	
// 	//@Test
// 	public void importStudySiteFromCSV() {
// 		csvMultipartFile  = new MockMultipartFile("file","studysite.csv","text/csv", loadResourceAsString("studysite.csv").getBytes() ) ;
// 		FileResponseModel response = studySiteServiceImpl.importStudySiteFromCSV(csvMultipartFile, 1L);
// 		assertEquals(1,response.getTotalRows());
		
// 		csvMultipartFile  = new MockMultipartFile("file","studysite.csv","text/csv", loadResourceAsString("studysite_nozip.csv").getBytes() ) ;
// 		FileResponseModel response1 = studySiteServiceImpl.importStudySiteFromCSV(csvMultipartFile, 1L);
// 		assertEquals(1,response1.getInvalidRows());
		
// 		csvMultipartFile  = new MockMultipartFile("file","studysite.txt","text/csv", "Hello".getBytes() ) ;
// 		FileResponseModel response2 = studySiteServiceImpl.importStudySiteFromCSV(csvMultipartFile, 1L);
// 		assertEquals("Invalid File",response2.getMessage());
// 	}
	
// 	@Test
// 	public void getCoordinatorsList() {
		
// 		when(coordinatorRepository.findByNameContaining(anyString(),any(PageRequest.class))).thenReturn(coordinators);
// 		List<CoordinatorDto> response = studySiteServiceImpl.getCoordinatorsList("coordinator",1L, 0, 5);
// 		assertNotNull(response);
// 		assertEquals(coordinators.get(0).getCoordinatorId(),response.get(0).getId().longValue());
// 	}
	
	
// 	@Test
// 	public void getStudySitesByIds() {
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when(studySitePrincipalInvestigatorRepository
// 				.findByStudySiteIdIn(anyListOf(Long.class))).thenReturn(lstStudySitePrincipalInvestigators);
// 		List<StudySiteDto> response = studySiteServiceImpl.getStudySitesByIds(siteList1.stream().map(StudySite::getId).collect(Collectors.toList()));
// 		assertNotNull(response);
// 		assertEquals(siteList1.get(0).getId(),response.get(0).getFeatures().get(0).getProperties().getStudySiteId());
// 	}
	
// 	@Test
// 	public void getAllTest_1() {
// 		when(studySiteRepository.findByActiveFalse(any(PageRequest.class))).thenReturn(pageList);
// 		when(studySiteRepository.findByStudySiteNameContainingAndStateInOrCityIn(anyString(),anyListOf(String.class),anyListOf(String.class),any(PageRequest.class))).thenReturn(pageList);
// 		when(studySiteRepository.findByActiveTrue(any(PageRequest.class))).thenReturn(pageList);
// 		Specification<StudySite> alias = any();
// 		when(studySiteRepository.findAll(alias,any(PageRequest.class))).thenReturn(pageList);
		
// 		responseObject = studySiteServiceImpl.getAll(studySiteFilterRequestModel);
// 		assertEquals(0,responseObject.getStatus());
// 		assertNotNull(responseObject.getData());
		
// 		studySiteFilterRequestModel.setDisabled(false);
// 		ResponseObjectModel responseObject1 = studySiteServiceImpl.getAll(studySiteFilterRequestModel);		
// 		assertEquals(0,responseObject1.getStatus());
// 		assertNotNull(responseObject1.getData());
		
// 		studySiteFilterRequestModel.setActive(true);		
// 		ResponseObjectModel responseObject2 = studySiteServiceImpl.getAll(studySiteFilterRequestModel);		
// 		assertEquals(0,responseObject2.getStatus());
// 		assertNotNull(responseObject2.getData());
		
// 	}
	
// 	@Test
// 	public void getAllTest_2() {
		
// 		studySiteFilterRequestModel.setCities(Arrays.asList("Newyork","Los Angeles"));
// 		when(studySiteRepository.findByStateInOrCityInAndActiveFalse(anyListOf(String.class),anyListOf(String.class),any(PageRequest.class))).thenReturn(pageList);
// 		Specification<StudySite> alias = any();
// 		when(studySiteRepository.findAll(alias,any(PageRequest.class))).thenReturn(pageList);
				
// 		responseObject = studySiteServiceImpl.getAll(studySiteFilterRequestModel);
// 		assertEquals(0,responseObject.getStatus());
// 		assertNotNull(responseObject.getData());
		
// 	}
	
// 	@Test
// 	public void getAllTest_3() {
		
// 		studySiteFilterRequestModel.setStudySiteName("Name1");
// 		when(studySiteRepository.findByStudySiteNameContainingAndActiveFalse(anyString(),any(PageRequest.class))).thenReturn(pageList);
// 		when(studySiteRepository.findByStudySiteNameContaining(anyString(),any(PageRequest.class))).thenReturn(pageList);
// 		when(studySiteRepository.findByStudySiteNameContainingAndActiveTrue(anyString(),any(PageRequest.class))).thenReturn(pageList);
// 		Specification<StudySite> alias = any();
// 		when(studySiteRepository.findAll(alias,any(PageRequest.class))).thenReturn(pageList);

		
// 		responseObject = studySiteServiceImpl.getAll(studySiteFilterRequestModel);
// 		assertEquals(0,responseObject.getStatus());
// 		assertNotNull(responseObject.getData());
		
// 		studySiteFilterRequestModel.setDisabled(false);
// 		ResponseObjectModel responseObject1 = studySiteServiceImpl.getAll(studySiteFilterRequestModel);		
// 		assertEquals(0,responseObject1.getStatus());
// 		assertNotNull(responseObject1.getData());
		
// 		studySiteFilterRequestModel.setActive(true);		
// 		ResponseObjectModel responseObject2 = studySiteServiceImpl.getAll(studySiteFilterRequestModel);	
// 		assertEquals(0,responseObject2.getStatus());
// 		assertNotNull(responseObject2.getData());
// 	}
	
// 	@Test
// 	public void getAllTest_4() {
// 		studySiteFilterRequestModel.setCities(Arrays.asList("Newyork","Los Angeles"));
// 		studySiteFilterRequestModel.setStudySiteName("Name1");
// 		when(studySiteRepository.findByStudySiteNameContainingAndActiveFalse(anyString(),any(PageRequest.class))).thenReturn(pageList);
// 		when(studySiteRepository.findByStudySiteNameContainingAndStateInOrCityIn(anyString(),anyListOf(String.class),anyListOf(String.class),any(PageRequest.class))).thenReturn(pageList);		
// 		when(studySiteRepository.findByStudySiteNameContainingAndStateInOrCityInAndActiveFalse(anyString(),anyListOf(String.class),anyListOf(String.class),any(PageRequest.class))).thenReturn(pageList);
// 		when(studySiteRepository.findByStudySiteNameContainingAndActiveTrueAndStateInOrCityIn(anyString(),anyListOf(String.class),anyListOf(String.class),any(PageRequest.class))).thenReturn(pageList);
// 		Specification<StudySite> alias = any();
// 		when(studySiteRepository.findAll(alias,any(PageRequest.class))).thenReturn(pageList);
		
// 		responseObject = studySiteServiceImpl.getAll(studySiteFilterRequestModel);
// 		assertEquals(0,responseObject.getStatus());
// 		assertNotNull(responseObject.getData());
		
// 		studySiteFilterRequestModel.setDisabled(false);
// 		ResponseObjectModel responseObject1 = studySiteServiceImpl.getAll(studySiteFilterRequestModel);
// 		assertEquals(0,responseObject1.getStatus());
// 		assertNotNull(responseObject1.getData());
		
// 		studySiteFilterRequestModel.setActive(true);		
// 		ResponseObjectModel responseObject2 = studySiteServiceImpl.getAll(studySiteFilterRequestModel);	
// 		assertEquals(0,responseObject2.getStatus());
// 		assertNotNull(responseObject2.getData());
		
// 	}
	
// 	@Test
// 	public void getStudySiteStatesByTrialIdTest_1() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when(stateRepository.findByAbbrevIn(anyListOf(String.class))).thenReturn(stateList);
		
// 		List<State> stateList = studySiteServiceImpl.getStudySiteStatesByTrialId(1L);

// 		assertEquals(2,stateList.size());
// 		assertNotNull(stateList);
// 	}
	

// 	@Test
// 	public void getStudySiteCitiesByTrialIdTest_1() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when( cityRepository.findByCityNameIn(anyListOf(String.class))).thenReturn(cityList);
		
// 		List<City> cityList = studySiteServiceImpl.getStudySiteCitiesByTrialId(1L,new LocationSearch());

// 		assertEquals(2,cityList.size());
// 		assertNotNull(cityList);
		
		
// 	}
	
// 	@Test
// 	public void getStudySiteStatesByTrialIdTest_2() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when(stateRepository.findByAbbrevIn(anyListOf(String.class))).thenReturn(new ArrayList<State>());
		
// 		List<State> stateList = studySiteServiceImpl.getStudySiteStatesByTrialId(1L);

// 		assertEquals(0,stateList.size());
// 		assertNotNull(stateList);
// 	}
	

// 	@Test
// 	public void getStudySiteCitiesByTrialIdTest_2() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when( cityRepository.findByCityNameIn(anyListOf(String.class))).thenReturn(new ArrayList<City>());
		
// 		List<City> cityList = studySiteServiceImpl.getStudySiteCitiesByTrialId(1L,new LocationSearch());

// 		assertEquals(0,cityList.size());
// 		assertNotNull(cityList);
		
		
// 	}
	
// 	@Test
// 	public void getCitiesListForStatesTest_1() {
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when( cityRepository.findAll()).thenReturn(cityList);
		
// 		List<City> cityList = studySiteServiceImpl.getCitiesListForStates(stateList.stream().map(s->s.getId()).collect(Collectors.toList()),"",null,0,-1);

// 		assertEquals(2,cityList.size());
// 		assertNotNull(cityList);
// 	}
	
// 	@Test
// 	public void getCitiesListForStatesTest_2() {
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findByIdIn(anyListOf(Long.class))).thenReturn(siteList1);
// 		when( cityRepository.findAll()).thenReturn(cityList);
// 		when( cityRepository.findByCityNameIn(anyListOf(String.class))).thenReturn(cityList);
		
// 		List<City> cityList = studySiteServiceImpl.getCitiesListForStates(stateList.stream().map(s->s.getId()).collect(Collectors.toList()),"",1L,0,-1);

// 		assertEquals(2,cityList.size());
// 		assertNotNull(cityList);
// 	}
	
// 	@Test
// 	public void getStudySiteStatesTest_1() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findAll()).thenReturn(siteList1);
// 		when(stateRepository.findByAbbrevIn(anyListOf(String.class))).thenReturn(stateList);
		
// 		List<State> stateList = studySiteServiceImpl.getStudySiteStates();

// 		assertEquals(2,stateList.size());
// 		assertNotNull(stateList);
// 	}
	

// 	@Test
// 	public void getStudySiteCitiesTest_1() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findAll()).thenReturn(siteList1);
// 		when( cityRepository.findByCityNameIn(anyListOf(String.class))).thenReturn(cityList);
		
// 		List<City> cityList = studySiteServiceImpl.getStudySiteCities();

// 		assertEquals(2,cityList.size());
// 		assertNotNull(cityList);
		
		
// 	}
	
// 	@Test
// 	public void getStudySiteStatesTest_2() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findAll()).thenReturn(siteList1);
// 		when(stateRepository.findByAbbrevIn(anyListOf(String.class))).thenReturn(new ArrayList<State>());
		
// 		List<State> stateList = studySiteServiceImpl.getStudySiteStates();

// 		assertEquals(0,stateList.size());
// 		assertNotNull(stateList);
// 	}
	

// 	@Test
// 	public void getStudySiteCitiesTest_2() {
		
// 		when(clinicalStudySiteRepository.findByIsActiveTrueAndClinicalStudySiteIdId(anyLong())).thenReturn(lstClinicalTrialStudySite);
// 		when(studySiteRepository.findAll()).thenReturn(siteList1);
// 		when( cityRepository.findByCityNameIn(anyListOf(String.class))).thenReturn(new ArrayList<City>());
		
// 		List<City> cityList = studySiteServiceImpl.getStudySiteCities();

// 		assertEquals(0,cityList.size());
// 		assertNotNull(cityList);
		
		
// 	}
	
// }
