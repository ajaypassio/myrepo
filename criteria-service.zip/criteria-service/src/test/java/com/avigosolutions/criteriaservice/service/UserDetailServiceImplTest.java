// package com.avigosolutions.criteriaservice.service;

// import static org.junit.Assert.assertNull;

// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.criteriaservice.dto.UserDetails;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class UserDetailServiceImplTest {

// 	//@InjectMocks
// 	@Autowired
// 	UserDetailService userDetailService;

// 	@Before
// 	public void setUp() {
// 		MockitoAnnotations.initMocks(this);
// 		/*injectField(userDetailServiceImpl, "springAuthUser", "serviceacc");
// 		injectField(userDetailServiceImpl, "springAuthPassword", "ENC(0yaOTcaFy96Ttsun2+fCIQ==)");
// 		injectField(userDetailServiceImpl, "springAppUrlFormat", "http://localhost:9004/api/v1/appusers/%s");*/
		
// 	}

// 	@Test
// 	public void testGetUserDetails() {
// 		/*UserDetails ud = new UserDetails();
// 		ud.setUserName("sample test");
// 		ResponseEntity<UserDetails> response = new ResponseEntity<UserDetails>(ud, HttpStatus.OK);
// 		when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), anyObject(), eq(UserDetails.class)))
// 				.thenReturn(response);*/
// 		UserDetails userDetails = userDetailService.getUserDetails(11L);
// 		assertNull(userDetails);
// 		/*assertNotNull(userDetails.getUserName());
// 		assertTrue("failed for condition", "sample test".equals(userDetails.getUserName()));*/
// 	}

// 	public void injectField(final Object injectable, final String fieldname, final Object value) {
// 		try {
// 			final java.lang.reflect.Field field = injectable.getClass().getDeclaredField(fieldname);
// 			final boolean origionalValue = field.isAccessible();
// 			field.setAccessible(true);
// 			field.set(injectable, value);
// 			field.setAccessible(origionalValue);
// 		} catch (final NoSuchFieldException | IllegalAccessException e) {
// 			throw new RuntimeException(e.getMessage(), e);
// 		}
// 	}
// }
