/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.beanvalidation.validators;

import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.LEARNING_MODEL_DOC_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.LEARNING_MODEL_LINKS_SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.LEARNING_MODEL_LINKS_SELF_HREF;
import static com.pearson.glp.lpb.constant.CommonConstants.RESOURCES_DOT;
import static com.pearson.glp.lpb.constant.CommonConstants.LINKS_SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.LINKS_SELF_HREF;
import static com.pearson.glp.lpb.constant.ValidationMessages.IS_INVALID;
import static com.pearson.glp.lpb.constant.ValidationMessages.IS_REQUIRED;

import com.pearson.glp.lpb.beanvalidation.annotations.AssetConstraint;
import com.pearson.glp.lpb.data.model.Resources;
import com.pearson.glp.lpb.data.model.LearningModel;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.utils.ValidationUtils;
import org.apache.commons.lang.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.*;
import java.util.function.Predicate;

/**
 * The Class AssetValidator.
 */
public class AssetValidator implements ConstraintValidator<AssetConstraint, NonPrimitiveAsset> {

  /**
   * Instantiates a new asset validator.
   */
  public AssetValidator() {
    super();
  }

  @Override
  public boolean isValid(NonPrimitiveAsset nonPrimitiveAsset, ConstraintValidatorContext context) {
    Optional<LearningModel> learningModel = Optional
        .ofNullable(nonPrimitiveAsset.getLearningModel());
    Optional<Map<String, Resources>> resources = Optional
        .ofNullable(nonPrimitiveAsset.getResources());

    Predicate<Object> isNotNull = (value) -> value != null;
    boolean isLearningModelValid = true;
    if (learningModel.isPresent()) {
      isLearningModelValid = validateLearningModel(learningModel.get(), isNotNull, context);
    }
    boolean isResourceValid = true;
    if (resources.isPresent()) {
      isResourceValid = resources.get().entrySet().stream()
          .filter(resource -> validateResourceLink(resource, isNotNull, context))
          .count() == resources.get().size();
    }
    return isLearningModelValid && isResourceValid;
  }

  /**
   * Validate Learning Model docType and Link
   *
   * @param learningModel
   * @param isNotNull
   * @param context
   * @return
   */
  private Boolean validateLearningModel(LearningModel learningModel, Predicate<Object> isNotNull,
      ConstraintValidatorContext context) {
    boolean isLearningModelValid = true;
    if (!DocType.LEARNINGMODEL.value().equals(learningModel.getDocType())) {
      ValidationUtils.buildConstraintViolation(context, IS_INVALID,
          Optional.of(LEARNING_MODEL_DOC_TYPE));
      isLearningModelValid = false;
    } else {
      if (isNotNull.test(learningModel.getLinks())) {
        if (!isNotNull.test(learningModel.getLinks().get(SELF))) {
          ValidationUtils.buildConstraintViolation(context, IS_REQUIRED,
              Optional.of(LEARNING_MODEL_LINKS_SELF));
          isLearningModelValid = false;
        } else {
          if (StringUtils.isEmpty(learningModel.getLinks().get(SELF).getHref())) {
            ValidationUtils.buildConstraintViolation(context, IS_REQUIRED,
                Optional.of(LEARNING_MODEL_LINKS_SELF_HREF));
            isLearningModelValid = false;
          }
        }
      }
    }
    return isLearningModelValid;
  }

  /**
   * Validate Resource Link
   *
   * @param resource
   * @param isNotNull
   * @param context
   * @return
   */
  private Boolean validateResourceLink(Map.Entry<String, Resources> resource,
      Predicate<Object> isNotNull, ConstraintValidatorContext context) {
    Boolean isResourceLinkValid = true;
    if (isNotNull.test(resource.getValue().getLinks())) {
      if (!isNotNull.test(resource.getValue().getLinks().get(SELF))) {
        ValidationUtils.buildConstraintViolation(context, IS_REQUIRED,
            Optional.of(RESOURCES_DOT + resource.getKey() + LINKS_SELF));
        isResourceLinkValid = false;
      } else {
        if (StringUtils.isEmpty(resource.getValue().getLinks().get(SELF).getHref())) {
          ValidationUtils.buildConstraintViolation(context, IS_REQUIRED,
              Optional.of(RESOURCES_DOT + resource.getKey() + LINKS_SELF_HREF));
          isResourceLinkValid = false;
        }
      }
    }
    return isResourceLinkValid;
  }
}