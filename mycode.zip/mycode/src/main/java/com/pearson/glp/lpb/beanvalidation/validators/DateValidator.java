/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.beanvalidation.validators;

import static com.pearson.glp.lpb.constant.LoggingConstants.FORMATTED_DATE_AND_TIME;

import com.pearson.glp.lpb.beanvalidation.annotations.DateConstraint;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Optional;

/**
 * The Class DateValidator.
 *
 * @author bharat.aggarwal
 */
public class DateValidator implements ConstraintValidator<DateConstraint, String> {

  /**
   * Instantiates a new date validator.
   */
  public DateValidator() {
    super();
  }

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(DateValidator.class);

  /**
   * Validate date string
   *
   * @param dateString
   * @param context
   * @return
   */
  @Override
  public boolean isValid(String dateString, ConstraintValidatorContext context) {
    Optional<String> dateOptional = Optional.ofNullable(dateString);
    if (dateOptional.isPresent()) {
      Optional<LocalDateTime> localDateTime = Optional.ofNullable(getLocalDateTime(dateString));
      return localDateTime.isPresent();
    }
    return true;
  }

  /**
   * Get the date time with validation
   *
   * @param dateString
   * @return
   */
  private LocalDateTime getLocalDateTime(String dateString) {
    LocalDateTime localDateTime = null;
    try {
      localDateTime = LocalDateTime.parse(dateString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    } catch (DateTimeParseException ex) {
      LOGGER.debug(FORMATTED_DATE_AND_TIME, dateString);
    }
    return localDateTime;
  }
}
