/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import lombok.experimental.UtilityClass;

/**
 * The Class LMValidationConstants.
 * 
 * @author srishti.singh
 */
@UtilityClass
public class LMValidationConstants {

  /** The Constant OF_RESOURCE_ID. */
  public static final String OF_RESOURCE_ID = " of resource ID ";

  /** The Constant AND_VERSION. */
  public static final String AND_VERSION = " and version ";

  /** The Constant VALID_RESOURCE. */
  public static final String VALID_RESOURCE = "ValidResource";

  /** The Constant DOES_NOT_MATCH_ANY_KEY_PATTERN. */
  public static final String DOES_NOT_MATCH_ANY_KEY_PATTERN = " does not match any Key Pattern";

  /** The Constant LEARNING_MODEL_NOT_FOUND_FOR_ID. */
  public static final String LEARNING_MODEL_NOT_FOUND_FOR_ID = "Learning Model not found for Id ";

  /** The Constant UNABLE_TO_FETCH_RESOURCE_FOR_ID. */
  public static final String UNABLE_TO_FETCH_RESOURCE_FOR_ID = "An Error occurred while fetching resource for ID ";

  /** The Constant ERROR_VALIDATING. */
  public static final String ERROR_VALIDATING = "Error validating";

  /** The Constant COMMA_SEPARATOR_REGEX. */
  public static final String COMMA_SEPARATOR_REGEX = "\\s*,\\s*";

}
