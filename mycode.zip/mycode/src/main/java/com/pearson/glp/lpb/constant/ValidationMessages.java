/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import lombok.experimental.UtilityClass;

/**
 * The Class ValidationMessages.
 */
@UtilityClass
public class ValidationMessages {

  /** The Constant IS_REQUIRED */
  public static final String IS_REQUIRED = "is required";

  /** The Constant COMPLETED_ALLOWED */
  public static final String COMPLETED_ALLOWED = "field is invalid : only COMPLETED is allowed";

  /** The Constant INCORRECT_ENUM_VALUE. */
  public static final String INCORRECT_ENUM_VALUE = "has incorrect value";

  /** The Constant EMPTY_KEYPATTERN. */
  public static final String EMPTY_KEYPATTERN = "should be a valid regex";

  /** The Constant INCORRECT_DATE_FORMAT. */
  public static final String INCORRECT_DATE_FORMAT = "invalid date format";

  /** The Constant INVALID_ASSETGRAPH. */
  public static final String INVALID_NODES = "invalid nodes present";

  /** The Constant IS_INVALID. */
  public static final String IS_INVALID = " is invalid";

  /** The Constant INVALID_LANGUAGE_INPUT. */
  public static final String INCORRECT_LANG = "invalid language code";

  /** The Constant INCORRECT_BOOLEAN. */
  public static final String INCORRECT_BOOLEAN = "invalid boolean value";

  /** The Constant ASSESSMENT_ALREADY_EXIST. */
  public static final String ASSESSMENT_ALREADY_EXIST = "Content metadata id and version already exist with id and version :";

}
