/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.UUID;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;

import lombok.Data;

/**
 * The Class Asset.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "_ver", "_bssVer", "_docType", "_assetType", "_links" })
@Document
/**
 * Instantiates a new asset.
 */
@Data
/*
 * (non-Javadoc)
 * 
 * @see java.lang.Object#hashCode()
 */
public class Asset implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 7624386946747798220L;

  /** The id. */
  @Id
  private transient String id;

  /** (Required). */
  @SerializedName("_id")
  @JsonProperty("_id")
  @Field("_id")
  private String _id;

  /** (Required). */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  @Field("_ver")
  private String ver;

  /** (Required). */
  @SerializedName("_bssVer")
  @JsonProperty("_bssVer")
  @Field("_bssVer")
  private Integer bssVer;

  /** (Required). */
  @SerializedName("_docType")
  @JsonProperty("_docType")
  @Field("_docType")
  private String docType;

  /** (Required). */
  @SerializedName("_assetType")
  @JsonProperty("_assetType")
  @Field("_assetType")
  private String assetType;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  @Field("_links")
  private LinkedHashMap<String, Link> links;

  public void addLinks(String rel, Link link) {
    if (this.links == null) {
      links = new LinkedHashMap<>();
    }
    links.put(rel, link);
  }

}
