/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import static com.pearson.glp.lpb.constant.ValidationMessages.IS_REQUIRED;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * The Class AssetGraph.
 * 
 * @author sourabh.aggarwal
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "startNode", "endNode", "relationships" })
@Setter
@Getter
public class AssetGraph implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -7531438020978906847L;

  /** The start node. */
  @JsonProperty("startNode")
  @NotBlank(message = IS_REQUIRED)
  private String startNode;

  /** The end node. */
  @JsonProperty("endNode")
  @NotBlank(message = IS_REQUIRED)
  private String endNode;

  /** The relationships. */
  @JsonProperty("relationships")
  @NotNull(message = IS_REQUIRED)
  private Relationships relationships;
}