/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The Class AssetModel.
 * 
 * @author sourabh.aggarwal
 */
@Document
@Setter
@Getter
@EqualsAndHashCode(callSuper = false)
public class AssetModel extends AssetModelPayload {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 2539391415177881956L;

  /** The id. */
  @Id
  private transient String id;

  /** The bss ver. */
  @SerializedName("_bssVer")
  @JsonProperty("_bssVer")
  @Field("_bssVer")
  private Integer bssVer;

  /** The created. */
  @SerializedName("_created")
  @JsonProperty("_created")
  @Field("_created")
  private String created;

  /** The last modified. */
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  @Field("_lastModified")
  private String lastModified;

  /** The doc type. */
  @SerializedName("_docType")
  @JsonProperty("_docType")
  @Field("_docType")
  private String docType;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  @Field("_links")
  private Map<String, Link> links;

  /**
   * Adds the links.
   *
   * @param rel
   *          the rel
   * @param link
   *          the link
   */
  public void addLinks(String rel, Link link) {
    if (this.links == null) {
      links = new LinkedHashMap<>();
    }
    links.put(rel, link);
  }
}