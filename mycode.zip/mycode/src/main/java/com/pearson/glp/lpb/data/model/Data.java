/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.List;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class Data.
 */
@Setter
@Getter
public class Data implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -8073066508212395113L;

  /** The resource type filter. */
  @SerializedName("resourceTypeFilter")
  @JsonProperty("resourceTypeFilter")
  @Field("resourceTypeFilter")
  private List<String> resourceTypeFilter;

  /** The doc type filter. */
  @SerializedName("docTypeFilter")
  @JsonProperty("docTypeFilter")
  @Field("docTypeFilter")
  private List<String> docTypeFilter;

  /** The asset filter. */
  @SerializedName("assetFilter")
  @JsonProperty("assetFilter")
  @Field("assetFilter")
  private List<String> assetFilter;

  /** The model selector. */
  @SerializedName("modelSelector")
  @JsonProperty("modelSelector")
  @Field("modelSelector")
  private List<String> modelSelector;

  /** The constraints. */
  @SerializedName("constraints")
  @JsonProperty("constraints")
  @Field("constraints")
  private Constraints constraints;

}