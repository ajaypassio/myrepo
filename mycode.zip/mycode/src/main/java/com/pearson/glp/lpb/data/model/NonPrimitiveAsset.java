/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import static com.pearson.glp.lpb.constant.ValidationMessages.IS_REQUIRED;
import static com.pearson.glp.lpb.constant.ValidationMessages.INCORRECT_LANG;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.validation.GroupSequence;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.beanvalidation.annotations.AssetConstraint;
import com.pearson.glp.lpb.beanvalidation.annotations.DateConstraint;
import com.pearson.glp.lpb.beanvalidation.groups.ClassLevelCheck;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The Class NonPrimitiveAsset.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "_bssVer", "_ver", "_created", "_lastModified", "expiresOn",
    "learningModel", "label", "tags", "language", "_docType", "_assetType", "assetClass",
    "objectives", "groups", "resources", "assetGraph", "resourcePlan", "configuration",
    "constraints", "extends", "extensions", "scope", "_links" })
@Document
@Data
@EqualsAndHashCode(callSuper = false)
@AssetConstraint(groups = ClassLevelCheck.class)
@GroupSequence({ NonPrimitiveAsset.class, ClassLevelCheck.class })
public class NonPrimitiveAsset extends Asset {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 6190004550882996562L;

  /** (Required). */
  /** The created. */
  @Field("_created")
  @SerializedName("_created")
  @JsonProperty("_created")
  private String created;

  /** The lastModified. */
  @Field("_lastModified")
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  private String lastModified;

  /** The createdBy. */
  @SerializedName("_createdBy")
  @JsonProperty("_createdBy")
  @Field("_createdBy")
  @NotBlank(message = IS_REQUIRED)
  private String createdBy;

  /** The expires on. */
  @JsonProperty("expiresOn")
  @Field("expiresOn")
  @SerializedName("expiresOn")
  @DateConstraint
  private String expiresOn;

  /** The label. */
  @SerializedName("label")
  @JsonProperty("label")
  @Field("label")
  private String label;

  /** The tags. */
  @SerializedName("tags")
  @JsonProperty("tags")
  @Field("tags")
  private String tags;

  /** The language. */
  @SerializedName("language")
  @JsonProperty("language")
  @Field("language")
  @Pattern(regexp = "^[a-z]{2}-[A-Z]{2}$", message = INCORRECT_LANG)
  private String language;

  /** The asset class. */
  @SerializedName("assetClass")
  @JsonProperty("assetClass")
  @Field("assetClass")
  private String assetClass;

  /** The objectives. */
  @SerializedName("objectives")
  @JsonProperty("objectives")
  @Field("objectives")
  private String objectives;

  /** The groups. */
  @SerializedName("groups")
  @JsonProperty("groups")
  @Field("groups")
  private Groups groups;

  /** The learning model. */
  @SerializedName("learningModel")
  @JsonProperty("learningModel")
  @Field("learningModel")
  @Valid
  @NotNull(message = IS_REQUIRED)
  private LearningModel learningModel;

  /** (Required). */
  @SerializedName("resources")
  @JsonProperty("resources")
  @Field("resources")
  @Valid
  @NotEmpty(message = IS_REQUIRED)
  protected LinkedHashMap<String, Resources> resources;

  /** (Required). */
  @SerializedName("assetGraph")
  @JsonProperty("assetGraph")
  @Field("assetGraph")
  @Valid
  @NotNull(message = IS_REQUIRED)
  private ArrayList<AssetGraph> assetGraph;

  /** (Required). */
  @SerializedName("resourcePlan")
  @JsonProperty("resourcePlan")
  @Field("resourcePlan")
  @Valid
  @NotNull(message = IS_REQUIRED)
  private ArrayList<ResourcePlan> resourcePlan;

  /** (Required). */
  @SerializedName("configuration")
  @JsonProperty("configuration")
  @Field("configuration")
  @NotNull(message = IS_REQUIRED)
  private Configuration configuration;

  /** (Required). */
  @SerializedName("constraints")
  @JsonProperty("constraints")
  @Field("constraints")
  @NotNull(message = IS_REQUIRED)
  private ArrayList<String> constraints;

  /** (Required). */
  @SerializedName("extends")
  @JsonProperty("extends")
  @Field("extends")
  @NotNull(message = IS_REQUIRED)
  protected Extends extend;

  /** (Required). */
  @SerializedName("extensions")
  @JsonProperty("extensions")
  @Field("extensions")
  @NotNull(message = IS_REQUIRED)
  private Extensions extensions;

  /** (Required). */
  @SerializedName("scope")
  @JsonProperty("scope")
  @Field("scope")
  @NotNull(message = IS_REQUIRED)
  private Scope scope;

  @Field("_status")
  private transient String status;

  /** The transient isLatest. */
  private transient Boolean isLatest;

  public NonPrimitiveAsset() {
    super();
  }

  public NonPrimitiveAsset(NonPrimitiveAssetPayload nonPrimitiveAsset) {
    this.created = nonPrimitiveAsset.getCreated();
    this.lastModified = nonPrimitiveAsset.getCreated();
    this.createdBy = nonPrimitiveAsset.getCreatedBy();
    this.expiresOn = nonPrimitiveAsset.getExpiresOn();
    this.label = nonPrimitiveAsset.getLabel();
    this.tags = nonPrimitiveAsset.getTags();
    this.language = nonPrimitiveAsset.getLanguage();
    this.assetClass = nonPrimitiveAsset.getAssetClass();
    this.objectives = nonPrimitiveAsset.getObjectives();
    this.groups = nonPrimitiveAsset.getGroups();
    this.learningModel = nonPrimitiveAsset.getLearningModel();
    this.resources = nonPrimitiveAsset.getResources();
    this.assetGraph = nonPrimitiveAsset.getAssetGraph();
    this.resourcePlan = nonPrimitiveAsset.getResourcePlan();
    this.configuration = nonPrimitiveAsset.getConfiguration();
    this.constraints = nonPrimitiveAsset.getConstraints();
    this.extend = nonPrimitiveAsset.getExtend();
    this.extensions = nonPrimitiveAsset.getExtensions();
    this.scope = nonPrimitiveAsset.getScope();
  }
}
