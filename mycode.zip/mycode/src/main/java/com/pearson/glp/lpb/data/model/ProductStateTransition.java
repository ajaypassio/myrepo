/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.Map;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The class ProductStateTransition.
 * 
 * @author srishti.singh
 */
@Document
@Getter
@Setter
@NoArgsConstructor
public class ProductStateTransition implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 851299958581019303L;

  /** The id. */
  @Id
  private transient String id;

  /** The productId. */
  @SerializedName("_id")
  @JsonProperty("_id")
  @Field("_id")
  private String productId;

  /** The ver. */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  @Field("_ver")
  private String ver;

  /** The created. */
  @SerializedName("_created")
  @JsonProperty("_created")
  @Field("_created")
  private String created;

  /** The last modified. */
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  @Field("_lastModified")
  private String lastModified;

  /** The previous state. */
  @SerializedName("previousState")
  @JsonProperty("previousState")
  @Field("previousState")
  private String previousState;

  /** The transition state. */
  @SerializedName("transitionState")
  @JsonProperty("transitionState")
  @Field("transitionState")
  private String transitionState;

  /** The reason. */
  @SerializedName("reason")
  @JsonProperty("reason")
  @Field("reason")
  private String reason;

  /** The reason code. */
  @SerializedName("reasonCode")
  @JsonProperty("reasonCode")
  @Field("reasonCode")
  private String reasonCode;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  @Field("_links")
  private Map<String, Link> links;

}
