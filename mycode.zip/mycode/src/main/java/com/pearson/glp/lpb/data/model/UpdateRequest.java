/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import static com.pearson.glp.lpb.constant.ValidationMessages.INCORRECT_BOOLEAN;
import static com.pearson.glp.lpb.constant.ValidationMessages.IS_REQUIRED;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * The Class UpdateRequest.
 */

/**
 * Instantiates a new update request.
 */
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "isMajorChange", "reason" })
public class UpdateRequest implements Serializable {

  /** The Constant serialVersionUID. */
  private final static long serialVersionUID = 2387318823939581799L;

  /** The is major change. */
  @JsonProperty("isMajorChange")
  @Pattern(regexp = "^(true|false)$", message = INCORRECT_BOOLEAN)
  @NotNull(message = IS_REQUIRED)
  private String isMajorChange;

  /** The reason. */
  @JsonProperty("reason")
  @NotBlank(message = IS_REQUIRED)
  private String reason;

}