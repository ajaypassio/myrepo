/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model.lm.resources;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * The Class CategorySchema.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "minProperties", "maxProperties" })

/**
 * Gets the min properties.
 *
 * @return the min properties
 */
@Getter

/**
 * Instantiates a new category schema.
 *
 * @param type
 *          the type
 * @param minProperties
 *          the min properties
 */
@AllArgsConstructor

/**
 * Instantiates a new category schema.
 */
@NoArgsConstructor
public class CategorySchema implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 4577114501675527017L;

  /** The type. */
  @JsonProperty("type")
  private String type;

  /** The min properties. */
  @JsonProperty("minProperties")
  private Integer minProperties;
  /** The max properties. */
  @JsonProperty("maxProperties")
  private Integer maxProperties;

}
