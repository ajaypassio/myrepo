/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.repository;

import static com.pearson.glp.lpb.constant.CommonConstants.ASSET_COUNT_VIEW_NAME;
import static com.pearson.glp.lpb.constant.CommonConstants.COUNT_VIEW_NAME;
import static com.pearson.glp.lpb.constant.CommonConstants.COUNT_ZERO;
import static com.pearson.glp.lpb.constant.CommonConstants.UNIQUE_ASSET_COUNT_VIEW;
import static com.pearson.glp.lpb.constant.CommonConstants.VIEW_DESIGN_NAME;

import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.ReactiveCouchbaseRepository;
import org.springframework.data.repository.util.ReactiveWrapperConverters;
import org.springframework.stereotype.Repository;

import com.couchbase.client.java.view.AsyncViewResult;
import com.couchbase.client.java.view.AsyncViewRow;
import com.couchbase.client.java.view.Stale;
import com.couchbase.client.java.view.ViewQuery;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;

import reactor.core.publisher.Mono;
import rx.Observable;

/**
 * The Interface NonPrimitiveAssetRepository.
 *
 * @author sankalp.katiyar
 */
@Repository
@ViewIndexed(designDoc = VIEW_DESIGN_NAME, viewName = ASSET_COUNT_VIEW_NAME, mapFunction = UNIQUE_ASSET_COUNT_VIEW)
public interface ContentRepository extends ReactiveCouchbaseRepository<NonPrimitiveAsset, String> {

  default Mono<String> fetchAllAssessments(String countKey) {
    ViewQuery query = ViewQuery.from(VIEW_DESIGN_NAME, ASSET_COUNT_VIEW_NAME);
    query.reduce(false).stale(Stale.FALSE).key(countKey);
    Observable observable = getCouchbaseOperations().queryView(query).flatMap(AsyncViewResult::rows)
        .map(AsyncViewRow::value).map(value -> {
          return value.toString();
        }).switchIfEmpty(Observable.just(null));
    return ReactiveWrapperConverters.toWrapper(observable, Mono.class);
  }

}