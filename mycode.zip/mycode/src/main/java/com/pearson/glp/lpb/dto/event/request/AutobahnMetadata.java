/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.event.request;

import java.io.Serializable;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Class AutobahnMetadata for holding metadata related to Autobahn message.
 * 
 *
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AutobahnMetadata implements Serializable {

  /**
   * The serialVersionUID.
   */
  private static final long serialVersionUID = 8176027129126945985L;

  /**
   * The action type.
   */
  private String actionType;

  /**
   * The correlation id.
   */
  private String correlationId;

  /**
   * The environmentCode.
   */
  private String environmentCode;

  /**
   * The message type code.
   */
  private String messageTypeCode;

  /**
   * The message version.
   */
  private String messageVersion;

  /**
   * The namespace.
   */
  private String namespace;

  /**
   * The originating system code.
   */
  private String originatingSystemCode;

  /**
   * The producer method.
   */
  private String producerMethod;

  /**
   * The received dt.
   */
  private String receivedDt;

  /**
   * The routing tags.
   */
  private Map<String, String> routingTags;
  /**
   * The stream.
   */
  private String stream;

  /**
   * The system username.
   */
  private String systemUsername;

  /**
   * The tracking id.
   */
  private String trackingId;

}
