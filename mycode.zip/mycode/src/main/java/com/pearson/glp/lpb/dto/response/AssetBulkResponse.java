/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.response;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.data.model.Asset;

import com.pearson.glp.lpb.data.model.Link;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

/**
 * The Class AssetBulkResponse.
 * 
 * @author sankalp.katiyar
 */

@Data
/**
 * Instantiates a new asset bulk response.
 */
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "count", "assets" })
public class AssetBulkResponse implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -1700900194868708176L;

  /** The count. */
  @NonNull
  @JsonProperty("_count")
  @SerializedName("_count")
  private Integer count;

  /** The assets. */
  @NonNull
  @JsonProperty("assets")
  @SerializedName("assets")
  private List<Asset> assets;

  /** The links. */
  @NonNull
  @JsonProperty("_links")
  @SerializedName("_links")
  private LinkedHashMap<String, Link> links;

  /**
   * Add Links
   *
   * @param rel
   * @param link
   */
  public void addLinks(String rel, Link link) {
    if (this.links == null) {
      links = new LinkedHashMap<>();
    }
    links.put(rel, link);
  }

  /**
   * @param count
   * @param assets
   */
  public AssetBulkResponse(Integer count, List<Asset> assets) {
    super();
    this.count = count;
    this.assets = assets;
  }

}