/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.response;

import java.io.Serializable;
import java.util.LinkedHashMap;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Link;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ProductPolicyResponse.
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductConfigurationResponse implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -423540156176245323L;

  /** The id. */
  @SerializedName("_id")
  @JsonProperty("_id")
  private String id;

  /** The ver. */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  private String ver;

  /** The bss ver. */
  @SerializedName("_bssVer")
  @JsonProperty("_bssVer")
  private Integer bssVer;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  private LinkedHashMap<String, Link> links;

  /** The configuration. */
  @SerializedName("configuration")
  @JsonProperty("configuration")
  private Configuration configuration;

}
