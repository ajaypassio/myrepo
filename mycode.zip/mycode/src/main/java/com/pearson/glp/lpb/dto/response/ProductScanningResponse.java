/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.response;

import java.io.Serializable;
import java.util.LinkedHashMap;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.data.model.Link;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author bharat.aggarwal
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductScanningResponse implements Serializable {

  private static final long serialVersionUID = 3855692148617964823L;

  @JsonProperty("_links")
  @SerializedName("_links")
  private LinkedHashMap<String, Link> links;

  /**
   * Add Links
   *
   * @param rel
   * @param link
   */
  public void addLinks(String rel, Link link) {
    if (this.links == null) {
      links = new LinkedHashMap<>();
    }
    links.put(rel, link);
  }

}
