/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.endpoints.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.COLON;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_ASSET_MODEL_ROUTES;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_PRODUCT_MODEL_ROUTES;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSET_MODELS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSET_MODELS_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSET_MODEL_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSET_MODEL_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_MODELS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_MODEL_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_MODEL_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_MODEL_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_ASSET_MODELS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_ASSET_MODELS_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_PRODUCT_MODELS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_PRODUCT_MODEL_VERSIONS;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODELS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODELS_VERSIONS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODEL_BY_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_MODELS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_MODELS_VERSIONS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_MODEL_BY_ID_ROUTE;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.errors.BaseHandlerFilterFunction;
import com.pearson.glp.lpb.handlers.LearningModelHandler;

import lombok.NoArgsConstructor;

/**
 * The Class LearningModelRoutes.
 *
 * @author srishti.singh
 */

/** The Constant log. */
@Configuration
@NoArgsConstructor
public class LearningModelRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(LearningModelRoutes.class);

  /**
   * The asset model handler.
   */
  @Autowired
  private LearningModelHandler learningModelHandler;

  /**
   * The service handler manager.
   */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /** The instance of BaseHandlerFilterFunction */
  @Autowired
  private BaseHandlerFilterFunction baseHandlerFilterFunction;

  /**
   * Learning model Routes.
   *
   * @return the router function
   */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Asset model routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> assetModelRoutes() throws ServiceException {

    try {

      return RouterFunctions.nest(RequestPredicates.path(contextPath),
          RouterFunctions
              .route(GET(ASSET_MODELS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ASSET_MODELS.name(),
                      context -> learningModelHandler.getLearningModels(context,
                          AssetType.AGGREGATE)))

              .andRoute(POST(ASSET_MODELS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(POST_ASSET_MODELS.name(),
                      learningModelHandler::createLearningModels))

              .andRoute(GET(ASSET_MODELS_VERSIONS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ASSET_MODELS_VERSIONS.name(),
                      context -> learningModelHandler.getLearningModelsVersions(context,
                          AssetType.AGGREGATE)))

              .andRoute(POST(ASSET_MODELS_VERSIONS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(POST_ASSET_MODELS_VERSIONS.name(),
                      context -> learningModelHandler.createLearningModelsVersions(context,
                          AssetType.AGGREGATE)))

              .andRoute(GET(ASSET_MODEL_BY_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ASSET_MODEL_BY_ID.name(),
                      context -> learningModelHandler.getLearningModelById(context,
                          AssetType.AGGREGATE)))

              .andRoute(GET(ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ASSET_MODEL_BY_ID_AND_VERSION_ID.name(),
                      context -> learningModelHandler.getLearningModelByVersionId(context,
                          AssetType.AGGREGATE)))
              .filter(baseHandlerFilterFunction));

    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_ASSET_MODEL_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_ASSET_MODEL_ROUTES + COLON + e.getMessage());
    }
  }

  /**
   * Product Model Routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> productModelRoutes() throws ServiceException {

    try {

      return RouterFunctions.nest(RequestPredicates.path(contextPath),
          RouterFunctions
              .route(GET(PRODUCT_MODELS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_PRODUCT_MODELS.name(),
                      context -> learningModelHandler.getLearningModels(context,
                          AssetType.PRODUCT)))

              .andRoute(POST(PRODUCT_MODELS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(POST_PRODUCT_MODELS.name(),
                      learningModelHandler::createLearningModels))

              .andRoute(GET(PRODUCT_MODELS_VERSIONS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_PRODUCT_MODEL_VERSIONS.name(),
                      context -> learningModelHandler.getLearningModelsVersions(context,
                          AssetType.PRODUCT)))

              .andRoute(POST(PRODUCT_MODELS_VERSIONS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(POST_PRODUCT_MODEL_VERSIONS.name(),
                      context -> learningModelHandler.createLearningModelsVersions(context,
                          AssetType.PRODUCT)))

              .andRoute(GET(PRODUCT_MODEL_BY_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_PRODUCT_MODEL_BY_ID.name(),
                      context -> learningModelHandler.getLearningModelById(context,
                          AssetType.PRODUCT)))

              .andRoute(GET(PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(
                      GET_PRODUCT_MODEL_BY_ID_AND_VERSION_ID.name(), context -> learningModelHandler
                          .getLearningModelByVersionId(context, AssetType.PRODUCT)))
              .filter(baseHandlerFilterFunction));

    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_PRODUCT_MODEL_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_PRODUCT_MODEL_ROUTES + COLON + e.getMessage());
    }
  }
}