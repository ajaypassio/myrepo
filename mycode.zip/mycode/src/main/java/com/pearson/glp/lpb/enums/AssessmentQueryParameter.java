/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.enums;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * The Enum AssessmentQueryParameter.
 */
public enum AssessmentQueryParameter {

  /** The contentmetadataid. */
  CONTENTMETADATAID("extensions.contentMetadata.id", "ID"),
  /** The contentmetadataversion. */
  CONTENTMETADATAVERSION("extensions.contentMetadata.version", "VERSION"),
  /** The page size. */
  PAGE_SIZE("pageSize", null),
  /** The page number. */
  PAGE_NUMBER("pageNumber", null);

  /** The value. */
  private final String value;
  /** The key. */
  private final String key;

  /**
   * Instantiates a new assessment query parameter.
   *
   * @param value
   *          the value
   */
  AssessmentQueryParameter(String value, String key) {
    this.value = value;
    this.key = key;
  }

  /**
   * Value.
   *
   * @return the string
   */
  @JsonValue
  public String value() {
    return this.value;
  }

  /**
   * Value.
   *
   * @return the string
   */
  public String key() {
    return this.key;
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.value;
  }

  /**
   * Gets the enum values.
   *
   * @return the enum values
   */
  public static List<String> getEnumValues() {
    List<String> enumValues = new ArrayList<>();
    for (AssessmentQueryParameter e : AssessmentQueryParameter.values()) {
      enumValues.add(e.value);
    }
    return enumValues;
  }
}
