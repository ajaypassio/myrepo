/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.enums;

import static com.pearson.glp.lpb.constant.CommonConstants.ASSESSMENT_ITEM_BY_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.constant.CommonConstants.NARRATIVES_BY_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.constant.CommonConstants.LEARNINGAPP_ITEM_BY_VERSION_ID_ROUTE;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * The Enum AssetType.
 */
public enum AssetType {

  /** The narrative. */
  NARRATIVE("NARRATIVE", NARRATIVES_BY_VERSION_ID_ROUTE),
  /** The assessment item. */
  ASSESSMENT_ITEM("ASSESSMENT-ITEM", ASSESSMENT_ITEM_BY_VERSION_ID_ROUTE),
  /** The learningApps item. */
  LEARNINGAPP_ITEM("LEARNINGAPP-ITEM", LEARNINGAPP_ITEM_BY_VERSION_ID_ROUTE),
  /** The instruction. */
  INSTRUCTION("INSTRUCTION", Routes.INSTRUCTION_BY_ID_AND_VERSION_ID_ROUTE.value()),
  /** The assessment. */
  ASSESSMENT("ASSESSMENT", Routes.ASSESSMENTS_BY_ID_AND_VERSION_ID_ROUTE.value()),
  /** The learningApps. */
  LEARNINGAPP("LEARNINGAPP", Routes.LEARNINGAPPS_BY_ID_AND_VERSION_ID_ROUTE.value()),
  /** The tool. */
  TOOL("TOOL", ""),
  /** The aggregate. */
  AGGREGATE("AGGREGATE", Routes.AGGREGATE_BY_ID_AND_VERSION_ID_ROUTE.value()),
  /** The product. */
  PRODUCT("PRODUCT", Routes.PRODUCT_BY_ID_AND_VERSION_ID_ROUTE.value()),
  /** The product model. */
  PRODUCTMODEL("PRODUCTMODEL", Routes.PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value()),
  /** The learningexperience. */
  LEARNINGEXPERIENCE("LEARNINGEXPERIENCE", ""),
  /** The engagementplan. */
  ENGAGEMENTPLAN("ENGAGEMENTPLAN", ""),
  /** The userengagement. */
  USERENGAGEMENT("USERENGAGEMENT", ""),
  /** The deliveryplan. */
  DELIVERYPLAN("DELIVERYPLAN", ""),
  /** The mastergraph. */
  MASTERGRAPH("MASTERGRAPH", ""),
  /** The learneroutcome. */
  LEARNEROUTCOME("LEARNEROUTCOME", ""),
  /** The evaluationplan. */
  EVALUATIONPLAN("EVALUATIONPLAN", ""),
  /** The userevaluation. */
  USEREVALUATION("USEREVALUATION", ""),
  /** The learningpolicy. */
  LEARNINGPOLICY("LEARNINGPOLICY", "");

  /** The value. */
  private final String value;
  private final String url;

  /**
   * Instantiates a new asset type.
   *
   * @param value
   *          the value
   */
  AssetType(String value, String url) {
    this.value = value;
    this.url = url;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.value;
  }

  /**
   * Value.
   *
   * @return the string
   */
  @JsonValue
  public String value() {
    return this.value;
  }

  /**
   * url.
   *
   * @return the string
   */
  public String url() {
    return this.url;
  }

  /**
   * Gets the enum values.
   *
   * @return the enum values
   */
  public static List<String> getEnumValues() {
    List<String> enumValues = new ArrayList<>();
    for (AssetType e : AssetType.values()) {
      enumValues.add(e.value);
    }
    return enumValues;
  }

  /**
   * Gets the key for ASSET_TYPE.
   *
   * @return the String
   */
  public static AssetType getKey(String value) {
    if (value.equals(ASSESSMENT_ITEM.value())) {
      return AssetType.ASSESSMENT_ITEM;
    }

    else if (value.equals(LEARNINGAPP_ITEM.value())) {
      return AssetType.LEARNINGAPP_ITEM;
    }
    return AssetType.valueOf(value);
  }
}