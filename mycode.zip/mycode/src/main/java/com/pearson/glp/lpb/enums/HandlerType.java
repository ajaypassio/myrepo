/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.enums;

/**
 * The Enum HandlerType.
 */
public enum HandlerType {

  /** The get asset models. */
  GET_ASSET_MODELS,
  /** The post asset models. */
  POST_ASSET_MODELS,
  /** The get asset models versions. */
  GET_ASSET_MODELS_VERSIONS,
  /** The post asset models versions. */
  POST_ASSET_MODELS_VERSIONS,
  /** The get asset model by id. */
  GET_ASSET_MODEL_BY_ID,
  /** The get asset model by id and version id. */
  GET_ASSET_MODEL_BY_ID_AND_VERSION_ID,
  /** The get product models. */
  GET_PRODUCT_MODELS,
  /** The post product models. */
  POST_PRODUCT_MODELS,
  /** The get product model versions. */
  GET_PRODUCT_MODEL_VERSIONS,
  /** The post product model versions. */
  POST_PRODUCT_MODEL_VERSIONS,
  /** The get product model by id. */
  GET_PRODUCT_MODEL_BY_ID,
  /** The get product model by id and version id. */
  GET_PRODUCT_MODEL_BY_ID_AND_VERSION_ID,
  /** The get task by id. */
  GET_TASK_BY_ID,
  /** The get aggregates. */
  GET_AGGREGATES,
  /** The get aggregate by id. */
  GET_AGGREGATE_BY_ID,
  /** The get aggregates versions. */
  GET_AGGREGATES_VERSIONS,
  /** The post aggregates versions. */
  POST_AGGREGATES_VERSIONS,
  /** The get aggregate by id and version id. */
  GET_AGGREGATE_BY_ID_AND_VERSION_ID,
  /** The get instructions. */
  GET_INSTRUCTIONS,
  /** The get instructions by id. */
  GET_INSTRUCTIONS_BY_ID,
  /** The get instruction versions. */
  GET_INSTRUCTION_VERSIONS,
  /** The post instructions versions. */
  POST_INSTRUCTIONS_VERSIONS,
  /** The get instruction by id and version id. */
  GET_INSTRUCTION_BY_ID_AND_VERSION_ID,
  /** The get products. */
  GET_PRODUCTS,
  /** The post products. */
  POST_PRODUCTS,
  /** The get product versions. */
  GET_PRODUCT_VERSIONS,
  /** The post product versions. */
  POST_PRODUCT_VERSIONS,
  /** The get product by id. */
  GET_PRODUCT_BY_ID,
  /** The get product by id and version id. */
  GET_PRODUCT_BY_ID_AND_VERSION_ID,
  /** The get entity by task id. */
  GET_ENTITY_BY_TASK_ID,
  /** The get product state transition. */
  GET_PRODUCT_STATE_TRANSITION,
  /** The post product state transition. */
  POST_PRODUCT_STATE_TRANSITION,
  /** The get product status. */
  GET_PRODUCT_STATUS,
  /** The put product status. */
  PUT_PRODUCT_STATUS,
  /** The get assessments by id. */
  GET_ASSESSMENTS_BY_ID,
  /** The get assessments by id and version id. */

  GET_ASSESSMENTS_BY_ID_AND_VERSION_ID,
  /** The get learningApps by id. */
  GET_LEARNINGAPPS_BY_ID,
  /** The get learningApps by id and version id. */
  GET_LEARNINGAPPS_BY_ID_AND_VERSION_ID,

  /** The post instructions. */
  POST_INSTRUCTIONS,
  /** The post aggregates. */
  POST_AGGREGATES,
  /** The post assessments. */
  POST_ASSESSMENTS,
  /** The post assessments versions. */
  POST_ASSESSMENTS_VERSIONS,
  /** The post learningapps. */
  POST_LEARNINGAPPS,
  /** The get assessments. */
  GET_ASSESSMENTS,

  /** The post embedded assets. */
  POST_EMBEDDED_ASSETS,

  /** The post config status. */
  POST_CONFIG_STATUS,

  /** The post learningapps versions. */
  POST_LEARNINGAPPS_VERSIONS;
  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.name();
  }
}