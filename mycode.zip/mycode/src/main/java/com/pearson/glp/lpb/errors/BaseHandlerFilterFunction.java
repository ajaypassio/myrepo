/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.errors;

import static com.pearson.glp.lpb.constant.LoggingConstants.INSIDE_FILTER_FROM_URL;
import static com.pearson.glp.lpb.constant.LoggingConstants.REQUIRED_ACCEPT_HEADERS_ARE_MISSING;
import static com.pearson.glp.lpb.constant.LoggingConstants.REQUIRED_CONTENT_TYPE_HEADERS_ARE_MISSING;

import javax.ws.rs.core.HttpHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.HandlerFilterFunction;
import org.springframework.web.reactive.function.server.HandlerFunction;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.lpb.utils.HandlerValidationUtil;

import reactor.core.publisher.Mono;

/**
 * The Class com.pearson.glp.lpb.errors.BaseHandlerFilterFunction.
 */
@Component
public class BaseHandlerFilterFunction
    implements HandlerFilterFunction<ServerResponse, ServerResponse> {

  /**
   * The logger.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(BaseHandlerFilterFunction.class);

  /** The validation util. */
  @Autowired
  private HandlerValidationUtil validationUtil;

  /**
   * The Constant APPLICATION_JSON_UTF.
   */
  private static final String APPLICATION_JSON_UTF = "application/json; charset=UTF-8";

  /**
   * The Constant APPLICATION_JSON_UTF8.
   */
  private static final String APPLICATION_JSON_UTF8 = "application/json;charset=UTF-8";

  /**
   * The Constant APPLICATION_JSON.
   */
  private static final String APPLICATION_JSON = "application/json";

  /**
   * The Constant APPLICATION_JSON_STREAM.
   */
  private static final String APPLICATION_JSON_STREAM = "application/stream+json";

  /*
   * (non-Javadoc)
   *
   * @see
   * org.springframework.web.reactive.function.server.HandlerFilterFunction#
   * filter(org.springframework.web.reactive.function.server.ServerRequest,
   * org.springframework.web.reactive.function.server.HandlerFunction)
   */
  @Override
  public Mono<ServerResponse> filter(ServerRequest serverRequest,
      HandlerFunction<ServerResponse> handlerFunction) {
    LOGGER.debug(INSIDE_FILTER_FROM_URL, serverRequest.uri());
    if (!isValidAcceptHeaderPresent(serverRequest)) {
      LOGGER.debug(REQUIRED_ACCEPT_HEADERS_ARE_MISSING, serverRequest.method(),
          serverRequest.uri());
      return ServerResponse.status(HttpStatus.NOT_ACCEPTABLE)
          .syncBody(validationUtil.prepareMediaTypeNotAcceptableResponse());
    } else if ((isMethod(serverRequest, HttpMethod.POST) || isMethod(serverRequest, HttpMethod.PUT))
        && !isJsonContentTypeHeader(serverRequest)) {
      LOGGER.debug(REQUIRED_CONTENT_TYPE_HEADERS_ARE_MISSING, serverRequest.method(),
          serverRequest.uri());
      return ServerResponse.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
          .syncBody(validationUtil.prepareUnsupportedMediaTypeResponse());
    }
    return handlerFunction.handle(serverRequest);
  }

  /**
   * Are required headers present.
   *
   * @param serverRequest
   *          the server request
   * @return true, if successful
   */
  private boolean isValidAcceptHeaderPresent(ServerRequest serverRequest) {
    return isJsonAcceptHeader(serverRequest) || (isMethod(serverRequest, HttpMethod.POST)
        && isJsonStreamAcceptHeaderApplicable(serverRequest)
        && isJsonStreamAcceptHeader(serverRequest));
  }

  /**
   * Checks if is method.
   *
   * @param serverRequest
   *          the server request
   * @param method
   *          the method
   * @return true, if is method
   */
  private boolean isMethod(ServerRequest serverRequest, HttpMethod method) {
    return serverRequest.method().matches(method.name());
  }

  /**
   * Checks if is json accept header.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is json accept header
   */
  private boolean isJsonAcceptHeader(ServerRequest serverRequest) {
    return serverRequest.headers().header(HttpHeaders.ACCEPT)
        .contains(MediaType.APPLICATION_JSON_VALUE);
  }

  /**
   * Checks if is json content type header.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is json content type header
   */
  private boolean isJsonContentTypeHeader(ServerRequest serverRequest) {
    return serverRequest.headers().header(HttpHeaders.CONTENT_TYPE).contains(APPLICATION_JSON)
        || serverRequest.headers().header(HttpHeaders.CONTENT_TYPE).contains(APPLICATION_JSON_UTF)
        || serverRequest.headers().header(HttpHeaders.CONTENT_TYPE).contains(APPLICATION_JSON_UTF8)
        || serverRequest.headers().header(HttpHeaders.CONTENT_TYPE)
            .contains(APPLICATION_JSON_STREAM);
  }

  /**
   * Checks if is json stream content type header.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is json stream content type header
   */
  private boolean isJsonStreamAcceptHeader(ServerRequest serverRequest) {
    return serverRequest.headers().header(HttpHeaders.ACCEPT)
        .contains(MediaType.APPLICATION_STREAM_JSON_VALUE);
  }

  /**
   * Checks if is json stream accept header applicable.
   *
   * @param request
   *          the request
   * @return true, if is json stream accept header applicable
   */
  private boolean isJsonStreamAcceptHeaderApplicable(ServerRequest request) {
    return request.pathVariables().values().isEmpty();
  }

}