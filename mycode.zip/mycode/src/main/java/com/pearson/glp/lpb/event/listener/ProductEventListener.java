/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.event.listener;

import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_RECEIVING_EVENT_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.PRODUCT_SETUP_STATE;
import static com.pearson.glp.lpb.constant.LoggingConstants.PRODUCT_SETUP_STATE_FAILED;
import static com.pearson.glp.lpb.constant.LoggingConstants.RECEIVING_EVENT_MESSAGE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import com.pearson.glp.core.handlers.base.ServiceHandlerManager;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerContext;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerVoidResponse;
import com.pearson.glp.crosscutting.isc.client.async.model.EventMessage;
import com.pearson.glp.lpb.constant.Events;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.event.request.AutobahnEventModel;
import com.pearson.glp.lpb.services.ProductService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The listener interface for receiving productComposeEvent events. The class
 * that is interested in processing a productComposeEvent event implements this
 * interface, and the object created with that class is registered with a
 * component using the component's <code>addProductComposeEventListener<code>
 * method. When the productComposeEvent event occurs, that object's appropriate
 * method is invoked.
 *
 * @author jeevansingh.dhami
 */
@Component
@DependsOn("serviceHandlerManager")
@EnableBinding(Events.class)
public class ProductEventListener {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductEventListener.class);

  /**
   * Instantiates a new product compose event listener.
   */
  public ProductEventListener() {
    super();
  }

  /** The handlers manager. */
  @Autowired
  private ServiceHandlerManager handlerManager;

  /** The product service. */
  @Autowired
  private ProductService productService;

  /**
   * Input handler.
   *
   * @param incomingEvent
   *          the incoming event
   */
  @StreamListener
  public void pmpMessageListener(
      @Input(Events.PRODUCT_METADATA_PUBLISHED_SIGNED) Flux<EventMessage> incomingEvent) {
    LOGGER.debug(RECEIVING_EVENT_MESSAGE + Events.PRODUCT_METADATA_PUBLISHED_SIGNED);
    handlerManager.registerIscHandlers(Events.PRODUCT_METADATA_PUBLISHED_SIGNED, incomingEvent,
        this::pmpMessageHandler, null, null);
  }

  /**
   * Event Service Handler.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<IscServiceHandlerVoidResponse> pmpMessageHandler(IscServiceHandlerContext context) {
    LOGGER.debug(RECEIVING_EVENT_MESSAGE + Events.PRODUCT_METADATA_PUBLISHED_SIGNED);
    Mono<AutobahnEventModel> eventMessage = context.getPayload(AutobahnEventModel.class);
    eventMessage.flatMap(productService::savePMPMessage).onErrorResume(error -> {
      LOGGER.error(ERROR_RECEIVING_EVENT_MESSAGE, error);
      return Mono.empty();
    }).switchIfEmpty(productSetupStateMessage())
        .subscribe(res -> LOGGER.debug(PRODUCT_SETUP_STATE_FAILED));
    return eventMessage.flatMap(message -> IscServiceHandlerVoidResponse.ok().build())
        .switchIfEmpty(IscServiceHandlerVoidResponse.error().build());
  }

  /**
   * Product Setup State Message
   * 
   * @return
   */
  private Mono<NonPrimitiveAsset> productSetupStateMessage() {
    LOGGER.debug(PRODUCT_SETUP_STATE);
    return Mono.empty();
  }

}