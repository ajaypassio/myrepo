/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.CONFIGURATION;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.FIELDS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.LoggingConstants.ASSET_MODEL_ID_AND_VERSION_ID_SHOULD_BE_IN_UUID_FORMAT;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATING_LEARNING_MODEL;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATING_LEARNING_MODEL_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_CREATING_LEARNING_MODEL;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_CREATING_LEARNING_MODEL_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_LEARNING_MODEL;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_INVALID_URL_FOR_PRODUCT_MODEL;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_LEARNING_MODEL;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_LEARNING_MODEL_VERSIONS;
import static com.pearson.glp.lpb.constant.LoggingConstants.LEARNING_MODEL_NOT_SAVED;
import static com.pearson.glp.lpb.constant.LoggingConstants.LEARNING_MODEL_VERSION_NOT_SAVED;
import static com.pearson.glp.lpb.constant.LoggingConstants.REQUESTED_RESOURCE_NOT_AVAILABLE;
import static com.pearson.glp.lpb.utils.CommonUtils.isUuid;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.internalServerError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.invalidRequestError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.objectNotFoundError;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.LoggingConstants;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.dto.response.AssetModelResponse;
import com.pearson.glp.lpb.dto.response.LearningModelResponse;
import com.pearson.glp.lpb.dto.response.ProductModelResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.ProductModelQueryParameter;
import com.pearson.glp.lpb.services.LearningModelService;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;

/**
 * Handler class responsible for serving the resources for AssetModel.
 *
 * @author srishti.singh
 */

@Component
public class LearningModelHandler implements CommonUtils {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(LearningModelHandler.class);

  /** The learning model service. */
  @Autowired
  private LearningModelService learningModelService;

  /** The config home. */
  @Value("${config.home:.}")
  private String configHome;

  /**
   * Instantiates a new learning model handler.
   */
  public LearningModelHandler() {
    super();
  }

  /**
   * Gets the learning models.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the learning models
   */
  public Mono<ServiceHandlerResponse> getLearningModels(ServiceHandlerContext context,
      AssetType assetType) {
    LOGGER.debug(LoggingConstants.FETCHING_ALL_LEARNING_MODEL_LATEST_VERSIONS);
    MultiValueMap<String, String> parameters = context.getAllParameters();
    List<String> params = ProductModelQueryParameter.getEnumValues();
    for (String obj : parameters.keySet()) {
      if (!params.contains(obj)) {
        return invalidRequestError(ERROR_INVALID_URL_FOR_PRODUCT_MODEL);
      }
    }
    String tag = parameters.getFirst(CommonConstants.TAG);
    LOGGER.debug(LoggingConstants.FETCHING_QUERY_PARAM, CommonConstants.TAG, tag);
    String label = parameters.getFirst(CommonConstants.LABEL);
    LOGGER.debug(LoggingConstants.FETCHING_QUERY_PARAM, CommonConstants.LABEL, label);
    String collectionDetails = parameters.getFirst(CommonConstants.COLLECTION_DETAILS);
    LOGGER.debug(LoggingConstants.FETCHING_QUERY_PARAM, CommonConstants.COLLECTION_DETAILS,
        collectionDetails);
    Mono<List<AssetModelResponse>> modelResponseListMono = learningModelService
        .findLearningModels(assetType.value(), tag, label);
    return modelResponseListMono
        .flatMap(responses -> mappingOfProductModelCollectionDetails(collectionDetails, responses,
            assetType.value()))
        .flatMap(assetModelResponses -> JsonPayloadServiceResponse.ok()
            .setHeader(CommonConstants.CONTENT_TYPE, CommonConstants.CONTENT_TYPE_HAL)
            .setPayload((CommonConstants.PRODUCT.equalsIgnoreCase(assetType.value()))
                ? new ProductModelResponse(assetModelResponses.size(), assetModelResponses)
                : new LearningModelResponse(assetModelResponses.size(), assetModelResponses)))
        .onErrorResume(ex -> {
          LOGGER.error(LoggingConstants.ERROR_FETCHING_LEARNING_MODEL, ex);
          return internalServerError(
              LoggingConstants.ERROR_FETCHING_LEARNING_MODEL + ex.getMessage());
        }).switchIfEmpty(invalidRequestError(LoggingConstants.INVALID_REQUEST));
  }

  /**
   * Mapping of product model collection details.
   *
   * @param collectionDetails
   *          the collection details
   * @param responses
   *          the responses
   * @return the list
   */
  public Mono<List<AssetModelResponse>> mappingOfProductModelCollectionDetails(
      String collectionDetails, List<AssetModelResponse> responses, String assetType) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_MAPPING_OF_PRODUCT_MODEL_COLLECTION_DETAILS);
    if (CommonConstants.PRODUCT.equals(assetType) && null != collectionDetails) {
      if (CommonConstants.LABEL.equals(collectionDetails)) {
        List<AssetModelResponse> productModelCollection = new ArrayList<>();
        responses
            .forEach(response -> productModelCollection.add(mapToProductModelCollection(response)));
        LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
            LoggingConstants.METHOD_MAPPING_OF_PRODUCT_MODEL_COLLECTION_DETAILS);
        return Mono.just(productModelCollection);
      }
      return Mono.empty();
    }
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.METHOD_MAPPING_OF_PRODUCT_MODEL_COLLECTION_DETAILS);
    return Mono.just(responses);
  }

  /**
   * Map to product model collection.
   *
   * @param response
   *          the response
   * @return the asset model response
   */
  public AssetModelResponse mapToProductModelCollection(AssetModelResponse response) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_MAP_TO_PRODUCT_MODEL_COLLECTION);
    AssetModelResponse assetModelResponse = new AssetModelResponse();
    assetModelResponse.set_assetType(response.get_assetType());
    assetModelResponse.set_docType(response.get_docType());
    assetModelResponse.set_bssVer(response.get_bssVer());
    assetModelResponse.set_id(response.get_id());
    assetModelResponse.set_ver(response.get_ver());
    assetModelResponse.set_links(response.get_links());
    assetModelResponse.setLabel(response.getLabel());
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.METHOD_MAP_TO_PRODUCT_MODEL_COLLECTION);
    return assetModelResponse;
  }

  /**
   * Creates the createLearningModels models.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createLearningModels(ServiceHandlerContext context) {

    LOGGER.debug(CREATING_LEARNING_MODEL);
    Mono<AssetModelPayload> assetModelPayload = context.getPayload(AssetModelPayload.class);
    return assetModelPayload.flatMap(payload -> {
      if (payload.get_id() != null && payload.getVer() != null
          && (!isUuid(payload.get_id()) || !isUuid(payload.getVer()))) {
        return invalidRequestError(ASSET_MODEL_ID_AND_VERSION_ID_SHOULD_BE_IN_UUID_FORMAT);
      }
      return createLearningModelResponse(learningModelService.createAssetModels(payload));
    }).onErrorResume(
        error -> setErrorResponse(error, ERROR_CREATING_LEARNING_MODEL, LEARNING_MODEL_NOT_SAVED));
  }

  /**
   * Gets the learning model by id.
   *
   * @param context
   *          the context
   * @return the learning model by id
   */
  public Mono<ServiceHandlerResponse> getLearningModelById(ServiceHandlerContext context,
      AssetType assetType) {
    String assetModelId = context.getParameter(ID);
    LOGGER.debug(GETTING_LEARNING_MODEL, assetModelId);
    Mono<AssetModelResponse> assetModel = learningModelService.findAssetModelById(assetModelId,
        assetType.value());
    return assetModel
        .flatMap(assetMod -> JsonPayloadServiceResponse.ok()
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(assetMod))
        .switchIfEmpty(objectNotFoundError(REQUESTED_RESOURCE_NOT_AVAILABLE));
  }

  /**
   * Gets the learning model by version id.
   *
   * @param context
   *          the context
   * @return the learning model by version id
   */
  public Mono<ServiceHandlerResponse> getLearningModelByVersionId(ServiceHandlerContext context,
      AssetType assetType) {
    String learningModelId = context.getParameter(ID);
    String learningModelVersionId = context.getParameter(VER);
    LOGGER.debug(GETTING_LEARNING_MODEL, learningModelId);
    Optional<String> fields = context.getOptionalParameter(FIELDS);
    if (fields.isPresent()) {
      return Optional.of(CONFIGURATION).equals(fields)
          ? getProductModelPolicyGroup(learningModelId, learningModelVersionId)
          : objectNotFoundError(LoggingConstants.ERROR_PRODUCT_MODEL_CONFIGURATION_NOT_FOUND);
    }
    Mono<AssetModelResponse> assetModel = learningModelService.findVersionById(learningModelId,
        learningModelVersionId, assetType.value());
    return assetModel
        .flatMap(assetMod -> JsonPayloadServiceResponse.ok()
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(assetMod))
        .switchIfEmpty(objectNotFoundError(REQUESTED_RESOURCE_NOT_AVAILABLE));
  }

  /**
   * Gets the product model policy group.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the product model policy group
   */
  private Mono<ServiceHandlerResponse> getProductModelPolicyGroup(String id, String version) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_GET_PRODUCT_MODEL_POLICY_GROUP);
    LOGGER.debug(LoggingConstants.FETCHING_CONFIGUARTION, id, version);
    return learningModelService.fetchProductModelConfiguration(id, version)
        .flatMap(configuration -> {
          LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
              LoggingConstants.METHOD_GET_PRODUCT_MODEL_POLICY_GROUP);
          return JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
              .setPayload(configuration);
        }).switchIfEmpty(objectNotFoundError(LoggingConstants.ERROR_PRODUCT_MODEL_NOT_FOUND));
  }

  /**
   * Gets the learning models versions.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the learning models versions
   */
  public Mono<ServiceHandlerResponse> getLearningModelsVersions(ServiceHandlerContext context,
      AssetType assetType) {
    String assetModelId = context.getParameter(ID);
    LOGGER.debug(GETTING_LEARNING_MODEL_VERSIONS, assetModelId);
    Mono<List<AssetModelResponse>> modelListMono = learningModelService
        .findAllVersionsById(assetModelId, assetType.value());
    return modelListMono
        .flatMap(assetModelResponses -> JsonPayloadServiceResponse.ok()
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload((PRODUCT.equalsIgnoreCase(assetType.value()))
                ? new ProductModelResponse(assetModelResponses.size(), assetModelResponses)
                : new LearningModelResponse(assetModelResponses.size(), assetModelResponses)))
        .onErrorResume(ex -> {
          LOGGER.error(ERROR_FETCHING_LEARNING_MODEL, ex);
          return internalServerError(ERROR_FETCHING_LEARNING_MODEL + ex.getMessage());
        });
  }

  /**
   * Add the learning models version.
   *
   * @param context
   *          the context
   * @return the learning models version
   */
  public Mono<ServiceHandlerResponse> createLearningModelsVersions(ServiceHandlerContext context,
      AssetType assetType) {
    String assetModelId = context.getParameter(ID);
    if (!isUuid(assetModelId)) {
      return objectNotFoundError(REQUESTED_RESOURCE_NOT_AVAILABLE);
    }
    Mono<AssetModelPayload> assetModelPayload = context.getPayload(AssetModelPayload.class);
    LOGGER.debug(CREATING_LEARNING_MODEL_VERSION, assetModelId);
    return assetModelPayload
        .flatMap(payload -> createLearningModelVersionResponse(
            learningModelService.createAssetModelVersion(payload, assetModelId, assetType.value())))
        .onErrorResume(exception -> setErrorResponse(exception, ERROR_CREATING_LEARNING_MODEL,
            LEARNING_MODEL_NOT_SAVED));
  }

  /**
   * Creates the learning model response.
   *
   * @param learningModel
   *          the learning model
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> createLearningModelResponse(
      Mono<AssetModelResponse> learningModel) {
    return learningModel
        .flatMap(assetMod -> JsonPayloadServiceResponse.withStatus(HttpStatus.CREATED)
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(assetMod))
        .onErrorResume(throwable -> setErrorResponse(throwable, ERROR_CREATING_LEARNING_MODEL,
            LEARNING_MODEL_NOT_SAVED));
  }

  /**
   * Creates the learning model version response.
   *
   * @param learningModel
   *          the asset model
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> createLearningModelVersionResponse(
      Mono<AssetModelResponse> learningModel) {
    return learningModel
        .flatMap(model -> JsonPayloadServiceResponse.withStatus(HttpStatus.CREATED)
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(model))
        .switchIfEmpty(objectNotFoundError(REQUESTED_RESOURCE_NOT_AVAILABLE))
        .onErrorResume(throwable -> setErrorResponse(throwable,
            ERROR_CREATING_LEARNING_MODEL_VERSION, LEARNING_MODEL_VERSION_NOT_SAVED));
  }
}