/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_STREAMING_WITH_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.CommonConstants.PAGE_SIZE;
import static com.pearson.glp.lpb.constant.CommonConstants.SPACE_CHAR;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSIONS_NOT_FOUND;
import static com.pearson.glp.lpb.constant.CommonConstants.DOUBLE_COLON;
import static com.pearson.glp.lpb.constant.CommonConstants.ALL;
import static com.pearson.glp.lpb.constant.LoggingConstants.API_TO_GET_LATEST_NON_PRIMITIVE_ASSET;
import static com.pearson.glp.lpb.constant.LoggingConstants.API_TO_GET_NO_PRIMITIVE_ASSET_VERSIONS;
import static com.pearson.glp.lpb.constant.LoggingConstants.API_TO_POST_ALL_NON_PRIMITIVE_ASSET;
import static com.pearson.glp.lpb.constant.LoggingConstants.ASSET_NOT_FOUND;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATING_NON_PRIMITIVE_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_ASSESSMENT_NOT_FOUND;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_NON_PRIMITIVE_ASSET;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_INVALID_URL_FOR_ASSESSMENT;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_NON_PRIMITIVE_ASSET;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_SPECIFIC_VERSIONS_NON_PRIMITIVE_ASSET_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.GET_ALL_ASSESSMENT;
import static com.pearson.glp.lpb.constant.LoggingConstants.NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.internalServerError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.invalidRequestError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.objectNotFoundError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.generateErrorResponse;

import java.util.List;

import com.pearson.glp.lpb.beanvalidation.groups.ClassLevelCheck;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.request.AssetVersionPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.AssessmentQueryParameter;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.services.NonPrimitiveAssetService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PaginationUtil;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import javax.validation.groups.Default;

/**
 * The Class NonPrimitiveAssetHandler.
 *
 * @author shubham.chaudhary
 */
@Component
@NoArgsConstructor
@AllArgsConstructor
public class NonPrimitiveAssetHandler implements CommonUtils {

  /**
   * The LOGGER.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(NonPrimitiveAssetHandler.class);

  /**
   * The Non Primitive Asset Service.
   */
  @Autowired
  private NonPrimitiveAssetService nonPrimitiveAssetService;

  /**
   * The Pagination Util.
   */
  @Autowired
  private PaginationUtil paginationUtil;

  /**
   * Gets the all assets.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the all assets
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getAllAssets(ServiceHandlerContext context,
      AssetType assetType) throws ServiceException {
    LOGGER.debug(API_TO_GET_LATEST_NON_PRIMITIVE_ASSET, assetType.value());

    MultiValueMap<String, String> parameters = context.getAllParameters();
    String pageSize = parameters.getFirst(PAGE_SIZE);
    String pageNumber = parameters.getFirst(PAGE_NUMBER);

    String paginationErrorMessage = paginationUtil.validatePagination(pageSize, pageNumber);
    if (StringUtils.isEmpty(paginationErrorMessage)) {
      pageSize = paginationUtil.preparePageSize(pageSize);
      pageNumber = paginationUtil.preparePageNumber(pageNumber);
    } else {
      PlatformErrorResponse platformErrorResponse = getPlatformErrorResponse(
          paginationErrorMessage);
      return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST)
          .setPayload(platformErrorResponse);
    }
    int limit = paginationUtil.getLimit(pageSize);
    int offset = paginationUtil.getOffset(pageNumber) - 1;
    Mono<Integer> assetBulkResponseCount = nonPrimitiveAssetService
        .countLatestAssetsByAssetType(assetType.value() + DOUBLE_COLON + ALL);
    return assetBulkResponseCount.flatMap(count -> {
      Mono<AssetBulkResponse> assetBulkResponse = nonPrimitiveAssetService
          .findAllAssetsWithLatestVersion(assetType.value(), limit, offset * limit, count);
      return assetBulkResponse
          .flatMap(response -> JsonPayloadServiceResponse.ok()
              .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(response))
          .switchIfEmpty(objectNotFoundError(
              assetType.value() + SPACE_CHAR + HttpStatus.NOT_FOUND.getReasonPhrase()))
          .onErrorResume(ex -> {
            log.error(ERROR_FETCHING_NON_PRIMITIVE_ASSET, assetType.value());
            return internalServerError(
                ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE + assetType.value());
          });
    });
  }

  /**
   * Creates the assets.
   *
   * @param context
   *          the service handler context
   * @param assetType
   *          the asset type
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAssets(ServiceHandlerContext context,
      AssetType assetType) {
    LOGGER.debug(API_TO_POST_ALL_NON_PRIMITIVE_ASSET, assetType.value());

    Flux<Tuple2<NonPrimitiveAssetPayload, List<String>>> nonPrimitiveAssetBulkPayload = context
        .getFluxPayloadWithGroupSupport(NonPrimitiveAssetPayload.class, Default.class,
            ClassLevelCheck.class);

    Flux<AssetResponse> resourceResponse = nonPrimitiveAssetService
        .createNonPrimitiveAssets(nonPrimitiveAssetBulkPayload, assetType);
    return JsonPayloadServiceResponse.withStatus(HttpStatus.MULTI_STATUS)
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_STREAMING_WITH_HAL).setFluxPayload(resourceResponse);
  }

  /**
   * Gets the asset by id.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the asset by id
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getAssetById(ServiceHandlerContext context,
      AssetType assetType) throws ServiceException {
    String assetId = context.getParameter(ID);
    LOGGER.debug(GETTING_NON_PRIMITIVE_ASSET, assetType.value(), assetId);
    Mono<NonPrimitiveAsset> nonPrimitiveAssetMono = nonPrimitiveAssetService
        .findById(CommonUtils.generateDocId(assetType.value(), assetId, StringUtils.EMPTY));
    return nonPrimitiveAssetMono
        .flatMap(nonPrimitiveAsset -> JsonPayloadServiceResponse.ok()
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(nonPrimitiveAsset))
        .switchIfEmpty(objectNotFoundError(
            assetType.value() + SPACE_CHAR + HttpStatus.NOT_FOUND.getReasonPhrase()))
        .onErrorResume(ex -> {
          LOGGER.error(ERROR_FETCHING_NON_PRIMITIVE_ASSET, assetType.value());
          return internalServerError(
              ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE + assetType.value());
        });
  }

  /**
   * Gets the asset versions.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the asset versions
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getAssetVersions(ServiceHandlerContext context,
      AssetType assetType) throws ServiceException {
    String assetId = context.getParameter(ID);
    LOGGER.debug(API_TO_GET_NO_PRIMITIVE_ASSET_VERSIONS, assetType.value(), assetId);
    Mono<AssetVersionsResponse> response = nonPrimitiveAssetService.findAllAssetVersions(assetId,
        assetType);

    return response
        .flatMap(assetVersionResponse -> assetVersionResponse.getCount() > 0
            ? JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
                .setPayload(assetVersionResponse)
            : objectNotFoundError(assetType.value() + VERSIONS_NOT_FOUND))
        .switchIfEmpty(objectNotFoundError(assetType.value() + VERSIONS_NOT_FOUND))
        .onErrorResume(ex -> {
          LOGGER.error(ERROR_FETCHING_NON_PRIMITIVE_ASSET, assetType.value(), ex);
          return internalServerError(
              ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE + assetType.value());
        });
  }

  /**
   * Creates the asset versions.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the mono
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> createAssetVersions(ServiceHandlerContext context,
      AssetType assetType) {
    String assetId = context.getParameter(ID);
    Mono<AssetVersionPayload> assetVersionPayload = context.getPayload(AssetVersionPayload.class,
        Default.class, ClassLevelCheck.class);
    LOGGER.debug(CREATING_NON_PRIMITIVE_VERSION, assetType.value(), assetId);

    return assetVersionPayload.flatMap(assetResponse -> {
      Mono<NonPrimitiveAsset> assetMono = nonPrimitiveAssetService
          .findById(CommonUtils.generateDocId(assetType.value(), assetId, StringUtils.EMPTY));
      return assetMono.flatMap(asset -> createAssetVersion(Mono.just(assetResponse), assetId,
          asset.getBssVer(), assetType)).switchIfEmpty(objectNotFoundError(ASSET_NOT_FOUND));
    }).onErrorResume(ex -> generateErrorResponse(ex));
  }

  /**
   * Gets the asset by asset id and version id.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the asset by asset id and version id
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getAssetByAssetIdAndVersionId(ServiceHandlerContext context,
      AssetType assetType) throws ServiceException {
    String assetId = context.getParameter(ID);
    String assetVersionId = context.getParameter(VER);
    LOGGER.debug(GETTING_SPECIFIC_VERSIONS_NON_PRIMITIVE_ASSET_ID, assetType.value(), assetId,
        assetVersionId);
    Mono<NonPrimitiveAsset> nonPrimitiveAsset = nonPrimitiveAssetService
        .findById(CommonUtils.generateDocId(assetType.value(), assetId, assetVersionId));

    return nonPrimitiveAsset
        .flatMap(nonPrimitive -> JsonPayloadServiceResponse.ok()
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(nonPrimitive))
        .switchIfEmpty(PlatformErrorUtils.objectNotFoundError(
            assetType.value() + SPACE_CHAR + HttpStatus.NOT_FOUND.getReasonPhrase()))
        .onErrorResume(ex -> {
          LOGGER.error(ERROR_FETCHING_NON_PRIMITIVE_ASSET, assetType.value(), ex);
          return PlatformErrorUtils
              .internalServerError(ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE + assetType.value());
        });
  }

  /**
   * Creates the asset version.
   *
   * @param assetVersionPayload
   *          the asset version payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> createAssetVersion(
      Mono<AssetVersionPayload> assetVersionPayload, String assetId, Integer bssVer,
      AssetType assetType) {
    Mono<AssetResponse> nonPrimitiveAsset = assetVersionPayload
        .flatMap(payload -> nonPrimitiveAssetService.createAssetVersion(payload, assetId, bssVer,
            assetType));
    return nonPrimitiveAsset.flatMap(payload -> {
      if (payload.getError() != null) {
        return JsonPayloadServiceResponse
            .withStatus(HttpStatus.valueOf(payload.getError().getStatus())).setPayload(payload);
      } else {
        return JsonPayloadServiceResponse.withStatus(HttpStatus.CREATED)
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(payload);
      }
    }).onErrorResume(ex -> getError(assetType, ex));
  }

  /**
   * Gets the error.
   *
   * @param assetType
   *          the asset type
   * @param ex
   *          the ex
   * @return the error
   */
  private Mono<ServiceHandlerResponse> getError(AssetType assetType, Throwable ex) {
    LOGGER.error(ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION, assetType.value(), ex);
    return internalServerError(assetType.value() + NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE);
  }

  /**
   * Gets the assessments.
   *
   * @param context
   *          the context
   * @return the assessments
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getAssessments(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(GET_ALL_ASSESSMENT);
    MultiValueMap<String, String> parameters = context.getAllParameters();
    if (!parameters.isEmpty()) {
      List<String> params = AssessmentQueryParameter.getEnumValues();
      if (parameters.keySet().stream().anyMatch(param -> !params.contains(param)))
        return invalidRequestError(ERROR_INVALID_URL_FOR_ASSESSMENT);
    }
    String pageSize = parameters.getFirst(PAGE_SIZE);
    String pageNumber = parameters.getFirst(PAGE_NUMBER);
    String paginationErrorMessage = paginationUtil.validatePagination(pageSize, pageNumber);
    if (!StringUtils.isEmpty(paginationErrorMessage)) {
      PlatformErrorResponse platformErrorResponse = getPlatformErrorResponse(
          paginationErrorMessage);
      return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST)
          .setPayload(platformErrorResponse);
    }
    parameters.remove(PAGE_SIZE);
    parameters.remove(PAGE_NUMBER);
    int limit = paginationUtil.getLimit(paginationUtil.preparePageSize(pageSize));
    int offset = paginationUtil.getOffset(paginationUtil.preparePageNumber(pageNumber)) - 1;
    Mono<AssetBulkResponse> product = nonPrimitiveAssetService.getAllAssessment(parameters, limit,
        offset);
    return product.flatMap(ob -> JsonPayloadServiceResponse.ok()
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(ob))
        .switchIfEmpty(objectNotFoundError(ERROR_ASSESSMENT_NOT_FOUND));
  }

  /**
   * Gets the platform error response.
   *
   * @param paginationErrorMessage
   *          the pagination error message
   * @return the platform error response
   */
  private PlatformErrorResponse getPlatformErrorResponse(String paginationErrorMessage) {
    PlatformErrorResponse platformErrorResponse = new PlatformErrorResponse();
    platformErrorResponse.setTimestamp(CommonUtils.getTimeStamp());
    platformErrorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
    platformErrorResponse.setError(HttpStatus.BAD_REQUEST.getReasonPhrase());
    platformErrorResponse.setMessage(paginationErrorMessage);
    return platformErrorResponse;
  }

}
