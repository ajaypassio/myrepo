/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import java.util.List;

import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.dto.response.AssetModelResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;

import reactor.core.publisher.Mono;

/**
 * The Interface AssetModelService.
 *
 * @author sourabh.aggarwal
 */
public interface LearningModelService {

  /**
   * Find learning models.
   *
   * @param assetType
   *          the asset type
   * @param tag
   *          the tag
   * @param label
   *          the label
   * @return the mono
   */
  Mono<List<AssetModelResponse>> findLearningModels(String assetType, String tag, String label);

  /**
   * Creates the asset models.
   *
   * @param assetModelPayload
   *          the asset model payload
   * @return the mono
   */
  Mono<AssetModelResponse> createAssetModels(AssetModelPayload assetModelPayload);

  /**
   * Find asset model by id.
   *
   * @param assetModelId
   *          the asset model id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetModelResponse> findAssetModelById(String assetModelId, String assetType);

  /**
   * Find all versions by id.
   *
   * @param assetModelId
   *          the asset model id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<List<AssetModelResponse>> findAllVersionsById(String assetModelId, String assetType);

  /**
   * Find version by id.
   *
   * @param learningModelId
   *          the learning model id
   * @param learningModelVersionId
   *          the learning model version id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetModelResponse> findVersionById(String learningModelId, String learningModelVersionId,
      String assetType);

  /**
   * Creates the asset model version.
   *
   * @param assetModelPayload
   *          the asset model payload
   * @param assetModelId
   *          the asset model id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetModelResponse> createAssetModelVersion(AssetModelPayload assetModelPayload,
      String assetModelId, String assetType);

  /**
   * Fetch product model configuration.
   *
   * @param productId
   *          the product id
   * @param productVer
   *          the product ver
   * @return the mono
   */
  Mono<ProductConfigurationResponse> fetchProductModelConfiguration(String productId,
      String productVer);

}