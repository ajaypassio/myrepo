/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.request.AssetVersionPayload;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.enums.AssetType;

import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.util.List;

/**
 * The Interface NonPrimitiveAssetService.java.
 * 
 * @author sankalp.katiyar
 */
public interface NonPrimitiveAssetService {

  /**
   * Find all asset versions.
   *
   * @param assetId
   *          the asset id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetVersionsResponse> findAllAssetVersions(String assetId, AssetType assetType);

  /**
   * find All Asset counts With Latest Version
   *
   * @param assetType
   * @return counts of Assets
   */
  Mono<Integer> countLatestAssetsByAssetType(String assetType);

  /**
   * find All Asset With Latest Version
   *
   * @param assetType,
   *          limit, offset, count
   * @return Mono<AssetBulkResponse> the asset type
   * @return the mono
   */
  Mono<AssetBulkResponse> findAllAssetsWithLatestVersion(String assetType, int limit, int offset,
      int count);

  /**
   * Creates the asset version.
   *
   * @param assetVersionPayload
   *          the asset version payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetResponse> createAssetVersion(AssetVersionPayload assetVersionPayload, String assetId,
      Integer bssVer, AssetType assetType);

  /**
   * Creates the Non Primitive Assets.
   *
   * @param nonPrimitiveAssetBulkPayload
   *          the Non Primitive Asset Bulk Payload
   * @param assetType
   *          the asset type *
   * @return the Flux of AssetResponse
   */
  Flux<AssetResponse> createNonPrimitiveAssets(
      Flux<Tuple2<NonPrimitiveAssetPayload, List<String>>> nonPrimitiveAssetBulkPayload,
      AssetType assetType);

  /**
   * Find by id.
   *
   * @param assetId
   *          the asset id
   * @return the mono
   */
  Mono<NonPrimitiveAsset> findById(String assetId);

  /**
   * Gets the all assessment.
   *
   * @param parameters
   *          the parameters
   * @param limit
   *          the limit
   * @param offset
   *          the offset
   * @return the all assessment
   */
  Mono<AssetBulkResponse> getAllAssessment(MultiValueMap<String, String> parameters, int limit,
      int offset);

  /**
   * Count all assessments.
   *
   * @param countKey
   *          the count key
   * @return the mono
   */
  Mono<String> fetchAllAssessments(String countKey);

}
