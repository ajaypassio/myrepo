/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import org.springframework.util.MultiValueMap;

import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.ConfigurationCompleteEventEntity;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.ProductStateTransition;
import com.pearson.glp.lpb.data.model.ProductStatus;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.request.ProductPayload;
import com.pearson.glp.lpb.dto.event.request.AutobahnEventModel;
import com.pearson.glp.lpb.dto.request.ProductStatusPayload;
import com.pearson.glp.lpb.dto.request.ProductVersionPayload;
import com.pearson.glp.lpb.dto.request.StateTransitionPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.ProductAssetResponse;
import com.pearson.glp.lpb.dto.response.ProductCollectionResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.dto.response.ProductsResponse;
import com.pearson.glp.lpb.enums.AssetType;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class ProductService.
 */
public interface ProductService {

  /**
   * Find product by id.
   *
   * @param id
   *          the id
   * @return the mono
   */
  Mono<NonPrimitiveAsset> findProductById(String id);

  /**
   * Find product by parameters.
   *
   * @param parameters
   * @return the Mono
   */
  Mono<ProductCollectionResponse> findProductCollection(MultiValueMap<String, String> parameters);

  /**
   * Find product collection with complete LA.
   *
   * @param parameters
   *          the parameters
   * @return the flux
   */
  Flux<NonPrimitiveAsset> findProductCollectionWithCompleteLA(
      MultiValueMap<String, String> parameters);

  /**
   * Find product by version.
   *
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the mono
   */
  Mono<NonPrimitiveAsset> findProductByVersion(String id, String ver);

  /**
   * Creates the product non primitive assets.
   *
   * @param productPayload
   *          the product payload
   * @param asset
   *          the asset
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<ProductsResponse> createProductNonPrimitiveAssets(ProductPayload productPayload, Asset asset,
      AssetType assetType);

  /**
   * Get all products.
   * 
   * @return the mono
   */
  Mono<AssetBulkResponse> getAllProducts();

  /**
   * Find product versions by id.
   *
   * @param id
   *          the id
   * @return the mono
   */
  Mono<AssetVersionsResponse> findProductVersionsById(String id);

  /**
   * Creates the asset version.
   *
   * @param productPayload
   *          the product version payload
   * @param asset
   *          the asset
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<ProductsResponse> createProductVersionNonPrimitiveAssets(
      ProductVersionPayload productPayload, Asset asset, String assetId, Integer bssVer,
      AssetType assetType);

  /**
   * Validate product.
   *
   * @param productPayload
   *          the product payload
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetResponse> validateProduct(ProductPayload productPayload, AssetType assetType);

  /**
   * Validate product.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  Mono<AssetResponse> validateProductVersion(ProductVersionPayload productVersionPayload,
      String assetId, Integer bssVer, AssetType assetType);

  /**
   * Find latest asset by id.
   *
   * @param assetModelId
   *          the asset model id
   * @return the mono
   */
  Mono<NonPrimitiveAsset> findLatestAssetById(String assetModelId);

  /**
   * Find latest asset version by id.
   *
   * @param assetId
   *          the assetId
   * @return the mono of NonPrimitiveAsset
   */
  Mono<NonPrimitiveAsset> findLatestAssetVersionById(String assetId);

  /**
   * Save product.
   *
   * @param payload
   *          the payload
   * @param asset
   *          the asset
   * @return the mono
   */
  Mono<ProductAssetResponse> saveProduct(NonPrimitiveAssetPayload payload, Asset asset);

  /**
   * Gets the state transition response.
   *
   * @param product
   *          the product
   * @param payload
   *          the payload
   * @param previousState
   * @return the state transition response
   */
  Mono<ProductStateTransition> getStateTransitionResponse(NonPrimitiveAsset product,
      StateTransitionPayload payload, String previousState);

  /**
   * Fetch product status.
   *
   * @param productId
   *          the product id
   * @return the mono
   */
  Mono<ProductStateTransition> fetchProductStateTransition(String docId);

  /**
   * Fetch product status.
   *
   * @param productId
   *          the product id
   * @return the mono
   */
  Mono<ProductStatus> fetchProductStatus(String productId);

  /**
   * Save status document.
   * 
   * @param productLA
   *
   * @param statusDoc
   *          the status doc
   * @param newStatus
   *          the new status
   * @return the mono
   */
  Mono<ProductStatus> saveStatusDocument(NonPrimitiveAsset productLA, ProductStatus statusDoc,
      ProductStatusPayload newStatus);

  /**
   * Fetch product configuration.
   *
   * @param productId
   *          the product id
   * @param productVer
   *          the product ver
   * @return the mono
   */
  Mono<ProductConfigurationResponse> fetchProductConfiguration(String productId, String productVer);

  /**
   * Fetch product asset type.
   *
   * @param id
   *          the product id
   * @param version
   *          the product version
   * @return the mono
   */
  Mono<ProductAssetClassType> getProductAssetTypes(String id, String version);

  /**
   * Setup product with review id.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param pmpMessage
   *          the pmp message
   */
  Mono<NonPrimitiveAsset> setupProductWithReviewId(NonPrimitiveAsset nonPrimitiveAsset,
      AutobahnEventModel pmpMessage);

  /**
   * Save PMP message.
   *
   * @param pmpMessage
   *          the pmp message
   * @return the mono
   */
  Mono<NonPrimitiveAsset> savePMPMessage(AutobahnEventModel pmpMessage);

  /**
   * Find PMP message if available then promote to SETUP.
   *
   * @param productLearningAsset
   *          the product Learning Asset
   * @return the mono
   */
  Mono<AutobahnEventModel> checkPMPMessage(Mono<NonPrimitiveAsset> productLearningAsset);

  /**
   * Save config complete event.
   *
   * @param entity
   *          the entity
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the mono
   */
  Mono<ConfigurationCompleteEventEntity> saveConfigCompleteEvent(
      ConfigurationCompleteEventEntity entity, String id, String ver);
}
