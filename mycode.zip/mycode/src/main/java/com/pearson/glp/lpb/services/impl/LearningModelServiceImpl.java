/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services.impl;

import static com.pearson.glp.lpb.constant.CommonConstants.AND;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSET_MODELS_ROUTE_URL;
import static com.pearson.glp.lpb.constant.CommonConstants.BSSVER_ID;
import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.DEFAULT_GROUP;
import static com.pearson.glp.lpb.constant.CommonConstants.FORWARD_SLASH;
import static com.pearson.glp.lpb.constant.CommonConstants.FOR_ASSET_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.POLICY_GROUPS;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT_MODEL_ROUTE_URL;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSIONS_URL;
import static com.pearson.glp.lpb.constant.CommonConstants.WITH;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATING_LEARNING_MODEL;
import static com.pearson.glp.lpb.constant.LoggingConstants.NON_ARRAY_POLICY_GROUP_ERROR;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_MODELS_ROUTE;
import static com.pearson.glp.lpb.utils.CommonUtils.prepareDocId;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.pearson.glp.core.errors.PlatformError;
import com.pearson.glp.core.utils.exception.PlatformException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.Events;
import com.pearson.glp.lpb.constant.LoggingConstants;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.dto.response.AssetModelResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.CacheRegion;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.enums.Routes;
import com.pearson.glp.lpb.event.publisher.EventPublisher;
import com.pearson.glp.lpb.services.EventService;
import com.pearson.glp.lpb.services.LearningModelService;
import com.pearson.glp.lpb.utils.CacheUtils;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.DateUtil;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class AssetModelServiceImpl.
 * 
 * @author sourabh.aggarwal
 */

@Service

/** The Constant log. */
@Slf4j
public class LearningModelServiceImpl implements LearningModelService {

  /** The repository. */
  @Autowired
  private LearningModelRepository repository;

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(LearningModelServiceImpl.class);

  /** The cacheService. */
  @Autowired
  private CacheUtils cacheService;

  /** The EventService. */
  @Autowired
  private EventService eventService;

  /**
   * Instantiates a new asset model service implementation.
   */

  public LearningModelServiceImpl() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.LearningModelService#findLearningModels(java.
   * lang.String, java.lang.String, java.lang.String)
   */
  @Override
  public Mono<List<AssetModelResponse>> findLearningModels(String assetType, String tag,
      String label) {
    return findLearningModelFlux(assetType, tag, label).map(this::translateToLearningModelResponse)
        .collectList();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.pearson.glp.lpb.services.AssetModelService#createAssetModels(com.
   * pearson.glp.lpb.data.model.AssetModelPayload)
   */
  @Override
  public Mono<AssetModelResponse> createAssetModels(AssetModelPayload assetModelPayload) {
    AssetModel assetModel = translateToAssetModel(assetModelPayload, true);
    log.debug(CREATING_LEARNING_MODEL + FOR_ASSET_TYPE + assetModel.getAssetType() + WITH
        + assetModel.get_id() + AND + assetModel.getVer());
    String docIdLatest = generateDocIdWithLatest(assetModelPayload.getAssetType(), assetModel);
    assetModel.addLinks(SELF,
        this.createSelfLink(assetModel.get_id(), assetModel.getVer(), assetModel.getAssetType()));

    Optional<Configuration> productConfiguation = Optional
        .ofNullable(assetModel.getConfiguration());

    if (PRODUCT.equalsIgnoreCase(assetModel.getAssetType())) {
      if (!ObjectUtils.isEmpty(assetModel.getLabel())) {
        StringBuilder defaultPolicy = new StringBuilder(assetModel.getLabel());
        productConfiguation.orElse(new Configuration()).put(POLICY_GROUPS,
            Arrays.asList(ObjectUtils.getDisplayString(defaultPolicy.append(DEFAULT_GROUP))));
      } else {
        productConfiguation.orElse(new Configuration()).put(POLICY_GROUPS,
            Arrays.asList(DEFAULT_GROUP));
      }
    }
    return validateAndSaveAssetModel(assetModel, docIdLatest);
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.AssetModelService#findAssetModelById(java.lang
   * .String)
   */
  @Override
  public Mono<AssetModelResponse> findAssetModelById(String assetModelId, String assetType) {
    return findById(assetModelId, assetType).map(this::translateToLearningModelResponse);
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.AssetModelService#findAllVersionsById(java.
   * lang.String)
   */
  @Override
  public Mono<List<AssetModelResponse>> findAllVersionsById(String assetModelId, String assetType) {
    return findVersions(assetModelId, assetType).map(this::translateToLearningModelResponse)
        .collectList();
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.AssetModelService#findVersionById(java.lang.
   * String, java.lang.String)
   */
  @Override
  public Mono<AssetModelResponse> findVersionById(String learningModelId,
      String learningModelVersionId, String assetType) {
    return findByIdAndVersion(learningModelId, learningModelVersionId, assetType)
        .map(this::translateToLearningModelResponse);
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.AssetModelService#addAssetModelVersion(com.
   * pearson.glp.lpb.data.model.AssetModelPayload, java.lang.String)
   */
  @Override
  public Mono<AssetModelResponse> createAssetModelVersion(AssetModelPayload assetModelPayload,
      String assetModelId, String assetType) {
    AssetModel assetModel = translateToAssetModel(assetModelPayload, false);
    log.debug(CREATING_LEARNING_MODEL + FOR_ASSET_TYPE + assetModel.getAssetType() + WITH
        + assetModel.get_id() + AND + assetModel.getVer());
    assetModel.set_id(assetModelId);
    String docIdLatest = generateDocIdWithLatest(assetModelPayload.getAssetType(), assetModel);
    assetModel.addLinks(SELF,
        this.createSelfLink(assetModel.get_id(), assetModel.getVer(), assetModel.getAssetType()));
    return validateAndSaveAssetModelVersion(assetModel, docIdLatest);
  }

  /**
   * Translate to learning model response.
   *
   * @param assetModel
   *          the asset model
   * @return the asset model response
   */
  private AssetModelResponse translateToLearningModelResponse(AssetModel assetModel) {
    AssetModelResponse assetModelResponse = CommonUtils.mapObject(assetModel,
        AssetModelResponse.class);
    assetModelResponse.set_created(assetModel.getCreated());
    assetModelResponse.setExtend(assetModel.getExtend());
    return assetModelResponse;
  }

  /**
   * Creates the instance model self links.
   *
   * @param assetModel
   *          the asset model
   */
  private void createInstanceModelSelfLinks(AssetModel assetModel) {
    if (PRODUCT.equalsIgnoreCase(assetModel.getAssetType())) {
      crateInstanceModelSelfLink(assetModel, PRODUCT_MODEL_ROUTE_URL);
    } else {
      crateInstanceModelSelfLink(assetModel, ASSET_MODELS_ROUTE_URL);
    }
  }

  /**
   * Creates the instance model self links based on provided URL.
   *
   * @param assetModel
   *          the asset model
   * @param url
   *          specified URL.
   */
  private void crateInstanceModelSelfLink(AssetModel assetModel, String url) {
    if (assetModel.getResources() != null) {
      assetModel.getResources().values().stream().forEach(n -> {
        if (n.getData() != null && n.getData().getInstanceModel() != null) {
          n.getData().getInstanceModel().addLinks(SELF,
              new Link(url + n.getData().getInstanceModel().getId() + VERSIONS_URL
                  + n.getData().getInstanceModel().getVer()));
        }
      });
    }
  }

  /**
   * Translate to asset model.
   *
   * @param assetModelPayload
   *          the asset model payload
   * @return the asset model
   */
  private AssetModel translateToAssetModel(AssetModelPayload assetModelPayload,
      boolean isBulkPost) {
    AssetModel assetModel = CommonUtils.mapObject(assetModelPayload, AssetModel.class);
    if (isBulkPost) {
      assetModel.set_id(assetModelPayload.get_id() != null ? assetModelPayload.get_id()
          : UUID.randomUUID().toString());
      assetModel.setVer(assetModelPayload.getVer() != null ? assetModelPayload.getVer()
          : UUID.randomUUID().toString());
    } else {
      assetModel.set_id(UUID.randomUUID().toString());
      assetModel.setVer(UUID.randomUUID().toString());
    }
    assetModel.setBssVer(BSSVER_ID);
    assetModel.setCreated(DateUtil.formatDateTime(LocalDateTime.now()).get());
    assetModel.setLastModified(DateUtil.formatDateTime(LocalDateTime.now()).get());
    assetModel.setDocType(DocType.LEARNINGMODEL.value());
    createInstanceModelSelfLinks(assetModel);
    return assetModel;
  }

  /**
   * Adds the self link.
   *
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @param assetType
   *          the asset type
   * @return the link
   */
  private Link createSelfLink(String id, String ver, String assetType) {
    Link link = new Link();
    String href = createHref(id, ver, assetType);
    link.setHref(href);
    return link;
  }

  /**
   * Creates the href.
   *
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @param assetType
   *          the asset type
   * @return the string
   */
  private String createHref(String id, String ver, String assetType) {
    String href = "";
    if (PRODUCT.equalsIgnoreCase(assetType)) {
      href = Routes.PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value();
    } else {
      href = Routes.ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value();
    }
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, ver);
    return href;
  }

  /**
   * validate asset model against json schema and persist it in to repository.
   *
   * @param assetModel
   *          asset model
   * @return error response if schema validation get fail otherwise generate a
   *         success response.
   */
  private Mono<AssetModelResponse> validateAndSaveAssetModel(AssetModel assetModel,
      String docIdLatest) {
    if (!CommonUtils.validatePolicyGroups(assetModel.getConfiguration())) {
      LOGGER.error(NON_ARRAY_POLICY_GROUP_ERROR);
      PlatformError platformError = new PlatformError(PlatformErrorCode.INVALID_REQUEST.getValue(),
          PlatformErrorCode.INVALID_REQUEST.getErrorCode(), NON_ARRAY_POLICY_GROUP_ERROR);
      return Mono.error(new PlatformException(HttpStatus.BAD_REQUEST.value(), platformError));
    } else {
      Mono<AssetModel> assetModelMono = repository.save(assetModel);
      return assetModelMono.flatMap(assetModelFromRepo -> {
        assetModel.setId(docIdLatest);
        return repository.save(assetModel).doOnSuccess(savedModel -> {
          cacheService.put(CacheRegion.LEARNING_MODEL,
              CommonUtils.generateLearningModelKey(savedModel.get_id(), savedModel.getVer()),
              savedModel);
          // also trigger an event to lap for it's cache refresh
          eventService.publishLearningModelEvent(Events.LEARNING_MODEL_UPDATED, savedModel);

        });
      }).map(this::translateToLearningModelResponse);
    }
  }

  /**
   * 1. validate asset model against json schema -> check if asset model with
   * same _id is exists into the system -> if exist persist it in to system.
   *
   * @param assetModel
   *          asset model
   * @return error response if schema validation get fail or asset is not
   *         present in the system, otherwise generate a success response.
   */
  private Mono<AssetModelResponse> validateAndSaveAssetModelVersion(AssetModel assetModel,
      String docIdLatest) {
    if (!CommonUtils.validatePolicyGroups(assetModel.getConfiguration())) {
      LOGGER.error(NON_ARRAY_POLICY_GROUP_ERROR);
      PlatformError platformError = new PlatformError(PlatformErrorCode.INVALID_REQUEST.getValue(),
          PlatformErrorCode.INVALID_REQUEST.getErrorCode(), NON_ARRAY_POLICY_GROUP_ERROR);
      return Mono.error(new PlatformException(HttpStatus.BAD_REQUEST.value(), platformError));
    } else {
      Mono<AssetModel> assetModelMono = repository.findById(docIdLatest)
          .flatMap(assetModelById -> repository.save(assetModel).flatMap(assetModelFromRepo -> {
            assetModel.setId(docIdLatest);
            return repository.save(assetModel);
          }));
      return assetModelMono.map(this::translateToLearningModelResponse);
    }
  }

  /**
   * Return docId with Latest Tag.
   *
   * @param assetModel
   *          the asset model
   * @param assetType
   *          the assetType
   * @return the String response
   */
  private String generateDocIdWithLatest(String assetType, AssetModel assetModel) {
    assetModel.setId(prepareDocId(assetType, assetModel.get_id(), assetModel.getVer()));
    return prepareDocId(assetType, assetModel.get_id(), true);
  }

  /**
   * Find learning model flux.
   *
   * @param assetType
   *          the asset type
   * @param tag
   *          the tag
   * @param label
   *          the label
   * @return the flux
   */
  private Flux<AssetModel> findLearningModelFlux(String assetType, String tag, String label) {
    String docId = prepareDocId(assetType);
    if (PRODUCT.equals(assetType)) {
      if (null != tag) {
        return repository.findLearningModelsWithTag(docId, tag);
      } else {
        return repository.findLearningModels(docId);
      }
    } else {
      if (null != tag && null != label) {
        return repository.findLearningModelsWithTagAndLabel(docId, tag, label);
      } else if (null != tag) {
        return repository.findLearningModelsWithTag(docId, tag);
      } else if (null != label) {
        return repository.findLearningModelsWithLabel(docId, label);
      } else {
        return repository.findLearningModels(docId);
      }
    }
  }

  /**
   * Find by id.
   *
   * @param learningModelId
   *          the learning model id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  private Mono<AssetModel> findById(String learningModelId, String assetType) {
    return repository.findById(prepareDocId(assetType, learningModelId, true));
  }

  /**
   * Find by id and version.
   *
   * @param learningModelId
   *          the learning model id
   * @param ver
   *          the ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  private Mono<AssetModel> findByIdAndVersion(String learningModelId, String ver,
      String assetType) {
    return repository.findById(prepareDocId(assetType, learningModelId, ver));
  }

  /**
   * Find versions.
   *
   * @param learningModelId
   *          the learning model id
   * @param assetType
   *          the asset type
   * @return the flux
   */
  private Flux<AssetModel> findVersions(String learningModelId, String assetType) {
    return repository.findLearningModels(prepareDocId(assetType, learningModelId, false));
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.ProductService#fetchProductConfiguration(java.
   * lang.String, java.lang.String)
   */
  public Mono<ProductConfigurationResponse> fetchProductModelConfiguration(String productId,
      String productVer) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_FETCH_PRODUCT_MODEL_CONFIGURATION);
    Mono<AssetModel> nonPrimitiveAsset = repository.findById(CommonUtils
        .nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCTMODEL, productId, productVer));
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.METHOD_FETCH_PRODUCT_MODEL_CONFIGURATION);
    return nonPrimitiveAsset.flatMap(asset -> buildProductModelPolicyConfigurationResponse(asset));
  }

  /**
   * Builds the policy model configuration response.
   *
   * @param asset
   *          the asset
   * @return the mono
   */
  private Mono<ProductConfigurationResponse> buildProductModelPolicyConfigurationResponse(
      AssetModel asset) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_BUILD_PRODUCT_MODEL_POLICY_CONFIGURATION_RESPONSE);
    ProductConfigurationResponse policyResponse = new ProductConfigurationResponse();
    policyResponse.setId(asset.get_id());
    policyResponse.setVer(asset.getVer());
    policyResponse.setBssVer(asset.getBssVer());
    StringBuilder link = new StringBuilder().append(PRODUCT_MODELS_ROUTE).append(FORWARD_SLASH)
        .append(asset.get_id()).append(CommonConstants.VERSIONS_URL).append(asset.getVer());
    Link selfLink = new Link(ObjectUtils.getDisplayString(link));
    LinkedHashMap<String, Link> selfLinks = new LinkedHashMap<>();
    selfLinks.put(SELF, selfLink);
    policyResponse.setLinks(selfLinks);
    policyResponse.setConfiguration(asset.getConfiguration());
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.METHOD_BUILD_PRODUCT_MODEL_POLICY_CONFIGURATION_RESPONSE);
    return Mono.just(policyResponse);
  }
}
