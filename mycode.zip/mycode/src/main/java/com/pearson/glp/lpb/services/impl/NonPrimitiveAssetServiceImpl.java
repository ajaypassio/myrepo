/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services.impl;

import static com.pearson.glp.lpb.constant.CommonConstants.AGGREGATES;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSESSMENTS;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSETS_PAGINATION_LINK_URL;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSET_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.INITIAL_BSS_VER;
import static com.pearson.glp.lpb.constant.CommonConstants.INSTRUCTIONS;
import static com.pearson.glp.lpb.constant.CommonConstants.NEXT_PAGE;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.CommonConstants.PAGE_SIZE;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_LINKS_RESOURCES;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCH_NON_PRIMITIVE_ASSET_LATEST_RESPONSE;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCH_NON_PRIMITIVE_ASSET_VERSIONS_RESPONSE;
import static com.pearson.glp.lpb.constant.LoggingConstants.GENERATE_ASSET_RESPONSE_FOR_REQUEST_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.GENERATE_ASSET_RESPONSE_WITH_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.MODEL_VALIDATION_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.NON_PRIMITIVE_ASSET_BUILD_ERROR;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;

import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.ValidationMessages;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.repository.ContentRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.dto.request.AssetVersionPayload;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.request.ValidationResult;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.EmbeddedAssetClass;
import com.pearson.glp.lpb.enums.EventType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.enums.Routes;
import com.pearson.glp.lpb.services.EventService;
import com.pearson.glp.lpb.services.NonPrimitiveAssetService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PaginationUtil;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;
import com.pearson.glp.lpb.validator.EmbeddedAssetValidator;
import com.pearson.glp.lpb.validator.LearningModelValidator;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

/**
 * The Class NonPrimitiveAssetServiceImpl.
 *
 * @author sankalp.katiyar
 */
@Service
public class NonPrimitiveAssetServiceImpl implements NonPrimitiveAssetService, CommonUtils {

  /**
   * The LOGGER.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(NonPrimitiveAssetServiceImpl.class);

  /**
   * The repository.
   */
  @Autowired
  private NonPrimitiveAssetRepository repository;

  @Autowired
  private ContentRepository contentRepository;

  /**
   * The validator.
   */
  @Autowired
  private LearningModelValidator validator;

  @Autowired
  private EmbeddedAssetValidator embeddedAssetValidator;

  /**
   * The Pagination Util.
   */
  @Autowired
  private PaginationUtil paginationUtil;

  /**
   * The validation enabled.
   */
  @Value("${validation.enabled:false}")
  private boolean validationEnabled;

  @Autowired
  private EventService eventService;

  @Value("${event.publish.enabled:false}")
  private boolean eventEnabled;

  /**
   * Instantiates a new asset model service implementation.
   */
  public NonPrimitiveAssetServiceImpl() {
    super();
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.NonPrimitiveAssetService#createAssetVersion(
   * com.pearson.glp.lpb.data.model.AssetPayload, java.lang.String)
   */
  @Override
  public Mono<AssetResponse> createAssetVersion(AssetVersionPayload assetVersionPayload,
      String assetId, Integer bssVer, AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = prepareAsset(assetVersionPayload, bssVer);
    nonPrimitiveAsset.set_id(assetId);
    nonPrimitiveAsset.setId(CommonUtils.generateDocId(assetType.value(), nonPrimitiveAsset.get_id(),
        nonPrimitiveAsset.getVer()));
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.addLinks(SELF, this.createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);

    LOGGER.debug(MODEL_VALIDATION_LOG, validationEnabled);
    if (validationEnabled) {
      return validator.validateLearningAssetWithLearningModel(nonPrimitiveAsset)
          .switchIfEmpty(saveAssetVersion(assetVersionPayload, nonPrimitiveAsset));
    } else {
      return saveAssetVersion(assetVersionPayload, nonPrimitiveAsset);
    }
  }

  /**
   * Save asset version.
   *
   * @param assetVersionPayload
   *          the asset version payload
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<AssetResponse> saveAssetVersion(AssetVersionPayload assetVersionPayload,
      NonPrimitiveAsset nonPrimitiveAsset) {
    return saveNonPrimitiveAssets(nonPrimitiveAsset).flatMap(asset -> {
      return Mono
          .just(prepareAssetResponse(asset, assetVersionPayload.getAsset().getContentMetadata()));
    }).onErrorResume(err -> {
      LOGGER.error(NON_PRIMITIVE_ASSET_BUILD_ERROR, err);
      nonPrimitiveAsset.setExtensions(new Extensions());
      setNonPrimitiveAssetExtensions(nonPrimitiveAsset, assetVersionPayload.getAsset());
      nonPrimitiveAsset.setId(null);
      return Mono.just(buildNonPrimitiveAssetResponseWithError(nonPrimitiveAsset,
          PlatformErrorCode.INTERNAL_SERVER_ERROR,
          HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()));
    });
  }

  /**
   * Creates the Non Primitive Assets.
   *
   * @param nonPrimitiveAssetBulkPayload
   *          the Non Primitive Asset Bulk Payload
   * @param assetType
   *          the asset type
   * @return the flux
   */
  @Override
  public Flux<AssetResponse> createNonPrimitiveAssets(
      Flux<Tuple2<NonPrimitiveAssetPayload, List<String>>> nonPrimitiveAssetBulkPayload,
      AssetType assetType) {
    return nonPrimitiveAssetBulkPayload.map(nonPrimitiveAsset -> {
      if (nonPrimitiveAsset.getT2() != null) {
        if (!nonPrimitiveAsset.getT2().isEmpty()) {
          ValidationResult validationResult = new ValidationResult();
          validationResult.setFailureFlag(Boolean.TRUE);
          validationResult.setErrors(nonPrimitiveAsset.getT2());
          nonPrimitiveAsset.getT1().setValidationResult(validationResult);
        }
      }
      return nonPrimitiveAsset.getT1();
    }).flatMap(assetRequest -> {
      // Unique Assessment Content Metadata Handling.
      if (assetType.equals(AssetType.ASSESSMENT)
          && ObjectUtils.isEmpty(assetRequest.getValidationResult())) {
        return getAllUniqueAssessment(prepareParameters(assetRequest)).flatMap(documentId -> {
          if (Optional.ofNullable(documentId).isPresent()) {
            String[] splitIdandVersion = documentId.split(CommonConstants.DOUBLE_COLON);
            return PlatformErrorUtils.invalidRequestAssetResponse(
                assetRequest.getContentMetadata(), ValidationMessages.ASSESSMENT_ALREADY_EXIST
                    + splitIdandVersion[2] + CommonConstants.DOUBLE_COLON + splitIdandVersion[4],
                null);
          }
          return buildNonPrimitiveAssetResponse(assetRequest, assetType);
        });
      }
      return buildNonPrimitiveAssetResponse(assetRequest, assetType);
    }).map(this::setEntityStatus);
  }

  /**
   * Prepare asset.
   *
   * @param assetVersionPayload
   *          the asset version payload
   * @param bssVer
   *          the bss ver
   * @return the non primitive asset
   */
  private NonPrimitiveAsset prepareAsset(AssetVersionPayload assetVersionPayload, Integer bssVer) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(assetVersionPayload.getAsset());
    if (!Objects.isNull(assetVersionPayload.getUpdateRequest()) && Boolean.TRUE.toString()
        .equals(assetVersionPayload.getUpdateRequest().getIsMajorChange())) {
      nonPrimitiveAsset.setBssVer(bssVer + 1);
    } else {
      nonPrimitiveAsset.setBssVer(bssVer);
    }
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, assetVersionPayload.getAsset());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setLastModified(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, assetVersionPayload.getAsset());
    return nonPrimitiveAsset;
  }

  /**
   * Prepare asset response.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param contentMetadata
   *          the content meta data
   * @return the asset response
   */
  private AssetResponse prepareAssetResponse(NonPrimitiveAsset nonPrimitiveAsset,
      ContentMetadata contentMetadata) {
    Asset asset = new Asset();
    asset.set_id(nonPrimitiveAsset.get_id());
    asset.setAssetType(nonPrimitiveAsset.getAssetType());
    asset.setBssVer(nonPrimitiveAsset.getBssVer());
    asset.setDocType(nonPrimitiveAsset.getDocType());
    asset.setId(nonPrimitiveAsset.getId());
    asset.setLinks(nonPrimitiveAsset.getLinks());
    asset.setVer(nonPrimitiveAsset.getVer());
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(asset);
    assetResponse.setContentMetadata(contentMetadata);
    return assetResponse;
  }

  /**
   * Build the Non Primitive Asset from the Non Primitive Asset Payload.
   *
   * @param nonPrimitiveAssetPayload
   *          the Non Primitive Payload
   * @param assetType
   *          the assetType
   * @return the Non Primitive Asset Payload
   */
  private Mono<AssetResponse> buildNonPrimitiveAssetResponse(
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload, AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(nonPrimitiveAssetPayload);

    if (!ObjectUtils.isEmpty(nonPrimitiveAssetPayload.getValidationResult())
        && nonPrimitiveAssetPayload.getValidationResult().getFailureFlag()) {
      String message = nonPrimitiveAssetPayload.getValidationResult().getErrors().toString();
      return PlatformErrorUtils.invalidRequestAssetResponse(
          nonPrimitiveAssetPayload.getContentMetadata(), message, null);
    } else if (AssetType.AGGREGATE.equals(assetType)
        && EmbeddedAssetClass.getEnumValues().contains(nonPrimitiveAsset.getAssetClass())) {
      return embeddedAssetValidator
          .validateEmbeddedAsset(nonPrimitiveAsset, nonPrimitiveAssetPayload.getContentMetadata())
          .switchIfEmpty(
              createNonPrimitiveAsset(nonPrimitiveAssetPayload, assetType, nonPrimitiveAsset));
    } else {
      return createNonPrimitiveAsset(nonPrimitiveAssetPayload, assetType, nonPrimitiveAsset);
    }
  }

  private Mono<AssetResponse> createNonPrimitiveAsset(
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload, AssetType assetType,
      NonPrimitiveAsset nonPrimitiveAsset) {
    try {
      String _id = UUID.randomUUID().toString();
      String _ver = UUID.randomUUID().toString();
      nonPrimitiveAsset.setId(CommonUtils.generateDocId(assetType.value(), _id, _ver));
      nonPrimitiveAsset.set_id(_id);
      nonPrimitiveAsset.setVer(_ver);
      nonPrimitiveAsset.setBssVer(INITIAL_BSS_VER);
      nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
      nonPrimitiveAsset.setAssetType(assetType.value());
      nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
      nonPrimitiveAsset.setLastModified(formatDateTime(LocalDateTime.now()).get());
      setNonPrimitiveAssetExtensions(nonPrimitiveAsset, nonPrimitiveAssetPayload);
      nonPrimitiveAsset.addLinks(SELF, createNonPrimitiveAssetSelfLink(assetType.url(),
          nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
      setNonPrimitiveAssetLinks(nonPrimitiveAsset);

      LOGGER.debug(MODEL_VALIDATION_LOG, validationEnabled);
      if (validationEnabled) {
        return validator.validateLearningAssetWithLearningModel(nonPrimitiveAsset).switchIfEmpty(
            saveNonPrimitiveAssets(nonPrimitiveAsset).map(this::buildNonPrimitiveAssetResponse));
      } else {
        return saveNonPrimitiveAssets(nonPrimitiveAsset).map(this::buildNonPrimitiveAssetResponse)
            .onErrorResume(ex -> {
              LOGGER.error(NON_PRIMITIVE_ASSET_BUILD_ERROR, ex);
              nonPrimitiveAsset.setExtensions(new Extensions());
              setNonPrimitiveAssetExtensions(nonPrimitiveAsset, nonPrimitiveAssetPayload);
              nonPrimitiveAsset.setId(null);
              return Mono.just(buildNonPrimitiveAssetResponseWithError(nonPrimitiveAsset,
                  PlatformErrorCode.INTERNAL_SERVER_ERROR,
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()));
            });
      }
    } catch (Exception ex) {
      LOGGER.error(NON_PRIMITIVE_ASSET_BUILD_ERROR, ex);
      nonPrimitiveAsset.setExtensions(new Extensions());
      setNonPrimitiveAssetExtensions(nonPrimitiveAsset, nonPrimitiveAssetPayload);
      nonPrimitiveAsset.setId(null);
      return Mono.just(buildNonPrimitiveAssetResponseWithError(nonPrimitiveAsset,
          PlatformErrorCode.INTERNAL_SERVER_ERROR,
          HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()));
    }
  }

  /**
   * Set the Links in the Non Primitive Asset.
   *
   * @param nonPrimitiveAsset
   *          the new non primitive asset links
   */
  private void setNonPrimitiveAssetLinks(NonPrimitiveAsset nonPrimitiveAsset) {
    try {
      if (!ObjectUtils.isEmpty(nonPrimitiveAsset.getLearningModel())) {
        nonPrimitiveAsset.getLearningModel().addLinks(SELF,
            createNonPrimitiveAssetSelfLink(Routes.ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value(),
                nonPrimitiveAsset.getLearningModel().getId(),
                nonPrimitiveAsset.getLearningModel().getVer()));
      }
      if (!ObjectUtils.isEmpty(nonPrimitiveAsset.getResources())) {
        nonPrimitiveAsset.getResources().values().forEach(resource ->

        resource.addLinks(SELF, createNonPrimitiveAssetSelfLink(
            AssetType.getKey(resource.getAssetType()).url(), resource.getId(), resource.getVer())));
      }
    } catch (Exception ex) {
      LOGGER.error(ERROR_LINKS_RESOURCES, ex);
    }

  }

  /**
   * Set the Extensions in the Non Primitive Asset.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param nonPrimitiveAssetPayload
   *          the non primitive asset payload
   */
  private void setNonPrimitiveAssetExtensions(NonPrimitiveAsset nonPrimitiveAsset,
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    if (nonPrimitiveAsset.getExtensions() != null) {
      nonPrimitiveAsset.getExtensions().put(CONTENT_METADATA,
          nonPrimitiveAssetPayload.getContentMetadata());
    }
  }

  /**
   * Save the Immutable Resource Model when content is available.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> saveNonPrimitiveAssets(NonPrimitiveAsset nonPrimitiveAsset) {
    Mono<NonPrimitiveAsset> mono = repository.save(nonPrimitiveAsset);
    return mono.flatMap(this::saveOrUpadateLatestDoc).doOnNext(nonPrimitive -> {
      if (eventEnabled) {
        eventService.publishEventMessage(EventType.NON_PRIMITIVE_LA_CREATED.value(), nonPrimitive)
            .subscribe();
      }
    });
  }

  /**
   * Save or upadate latest doc.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> saveOrUpadateLatestDoc(NonPrimitiveAsset nonPrimitiveAsset) {
    nonPrimitiveAsset.setIsLatest(Boolean.TRUE);
    nonPrimitiveAsset.setId(CommonUtils.generateDocId(nonPrimitiveAsset.getAssetType(),
        nonPrimitiveAsset.get_id(), StringUtils.EMPTY));
    return repository.save(nonPrimitiveAsset);
  }

  /**
   * Build the Asset Response from Non Primitive Asset Model.
   *
   * @param nonPrimitiveAsset
   *          the resource
   * @return the Asset Response
   */
  private AssetResponse buildNonPrimitiveAssetResponse(NonPrimitiveAsset nonPrimitiveAsset) {
    LOGGER.debug(GENERATE_ASSET_RESPONSE_FOR_REQUEST_ID,
        nonPrimitiveAsset.getExtensions().get(CONTENT_METADATA));
    AssetResponse response = new AssetResponse();
    response.setContentMetadata(
        (ContentMetadata) nonPrimitiveAsset.getExtensions().get(CONTENT_METADATA));
    if (nonPrimitiveAsset.getId() != null) {
      response.setAsset(generateAsset(nonPrimitiveAsset));
    }
    return response;
  }

  /**
   * Build the Asset Response with error from Non Primitive Asset Model.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param platformErrorCode
   *          the platform error code
   * @param message
   *          the message
   * @return the Asset Response
   */
  private AssetResponse buildNonPrimitiveAssetResponseWithError(NonPrimitiveAsset nonPrimitiveAsset,
      PlatformErrorCode platformErrorCode, String message) {
    AssetResponse response = buildNonPrimitiveAssetResponse(nonPrimitiveAsset);
    LOGGER.debug(GENERATE_ASSET_RESPONSE_WITH_ERROR,
        nonPrimitiveAsset.getExtensions().get(CONTENT_METADATA));
    response.setError(generatePlatformError(platformErrorCode, message));
    return response;
  }

  /**
   * Generate the Asset from the Non Primitive Asset.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the asset
   */
  private Asset generateAsset(NonPrimitiveAsset nonPrimitiveAsset) {
    Asset asset = new Asset();
    asset.set_id(nonPrimitiveAsset.get_id());
    asset.setVer(nonPrimitiveAsset.getVer());
    asset.setBssVer(nonPrimitiveAsset.getBssVer());
    asset.setDocType(nonPrimitiveAsset.getDocType());
    asset.setAssetType(nonPrimitiveAsset.getAssetType());
    asset.setLinks(nonPrimitiveAsset.getLinks());
    return asset;
  }

  /**
   * Generate the error response for Non Primitive Asset.
   *
   * @param platformErrorCode
   *          the platform error code
   * @param message
   *          the message
   * @return the platform error
   */
  private PlatformErrorResponse generatePlatformError(PlatformErrorCode platformErrorCode,
      String message) {
    return PlatformErrorUtils.prepareErrorResponse(platformErrorCode.getValue(),
        platformErrorCode.getErrorCode(), message, null);
  }

  /**
   * Creates the Non Primitive Asset self link.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the link
   */
  private Link createNonPrimitiveAssetSelfLink(String url, String id, String ver) {
    Link link = new Link();
    link.setHref(createNonPrimitiveAssetHref(url, id, ver));
    return link;
  }

  /**
   * Creates the href.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  private String createNonPrimitiveAssetHref(String url, String id, String ver) {
    String href = url;
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, ver);
    return href;
  }

  /**
   * Find All Asset Versions.
   *
   * @param assetId
   *          the asset id
   * @param assetType
   *          the asset type
   * @return the mono
   */
  @Override
  public Mono<AssetVersionsResponse> findAllAssetVersions(String assetId, AssetType assetType) {
    LOGGER.debug(FETCH_NON_PRIMITIVE_ASSET_VERSIONS_RESPONSE, assetType, assetId);
    Flux<NonPrimitiveAsset> assetFlux = repository
        .findAssets(getAllVersionsDocumentId(assetType, assetId));
    return assetFlux.collectList().map(this::translateToVersionResponse);
  }

  /**
   * translate List<Asset> to Mono<AssetVersionsResponse>.
   *
   * @param assets
   *          the assets
   * @return AssetVersionsResponse
   */
  private AssetVersionsResponse translateToVersionResponse(List<NonPrimitiveAsset> assets) {
    AssetVersionsResponse assetVersionResponse = new AssetVersionsResponse();
    assetVersionResponse.setVersions(new ArrayList<>());
    assetVersionResponse.setCount(assets.size());
    assets.forEach(asset -> {
      Asset setAssetVal = new Asset();
      setAssetVal.set_id(asset.get_id());
      setAssetVal.setAssetType(asset.getAssetType());
      setAssetVal.setBssVer(asset.getBssVer());
      setAssetVal.setDocType(asset.getDocType());
      setAssetVal.setId(asset.getId());
      setAssetVal.setLinks(asset.getLinks());
      setAssetVal.setVer(asset.getVer());
      assetVersionResponse.getVersions().add(setAssetVal);
    });
    return assetVersionResponse;
  }

  /**
   * find all Asset Models with Latest Version.
   *
   * @param countKey
   *          the countKey
   * @return Mono<Integer>
   */
  @Override
  public Mono<Integer> countLatestAssetsByAssetType(String countKey) {
    return repository.countAllLatestLearningAsset(countKey);
  }

  /**
   * find all Asset Models with Latest Version.
   *
   * @param assetType
   *          the asset type
   * @param limit
   *          the limit
   * @param offset
   *          the offset
   * @param count
   *          the count
   * @return Mono<AssetBulkResponse>
   */
  @Override
  public Mono<AssetBulkResponse> findAllAssetsWithLatestVersion(String assetType, int limit,
      int offset, int count) {
    LOGGER.debug(FETCH_NON_PRIMITIVE_ASSET_LATEST_RESPONSE, assetType);
    Flux<NonPrimitiveAsset> assetFlux = repository.findAllAssetsWithLatestDoc(limit + 1, offset,
        getDocRegex(assetType));
    Mono<List<NonPrimitiveAsset>> assetsMono = assetFlux.collectList();
    return assetsMono
        .map(assets -> translateToAssetResponse(assets, assetType, limit, offset, count));
  }

  /**
   * Gets the doc regex.
   *
   * @param assetType
   *          the asset type
   * @return the doc regex
   */
  private String getDocRegex(String assetType) {
    return new StringBuilder(CommonUtils.generateDocId(assetType, StringUtils.EMPTY,
        org.apache.commons.lang3.StringUtils.EMPTY)).append(CommonConstants.PERCENT_SIGN)
            .toString();
  }

  /**
   * Translate to asset response.
   *
   * @param assets
   *          the assets
   * @param assetType
   *          the asset type
   * @param limit
   *          the limit
   * @param offset
   *          the offset
   * @param count
   *          the count
   * @return the asset bulk response
   */
  private AssetBulkResponse translateToAssetResponse(List<NonPrimitiveAsset> assets,
      String assetType, int limit, int offset, int count) {
    AssetBulkResponse assetBulkResponse = new AssetBulkResponse();
    assetBulkResponse.setAssets(new ArrayList<>());
    assetBulkResponse.setCount(count);
    if (assets.size() > limit) {
      int currentPageNumber = offset / limit;
      assetBulkResponse.addLinks(NEXT_PAGE, createSelfLink(limit, currentPageNumber, assetType));
      assets.remove(limit);
    }
    assets.forEach(asset -> {
      Asset setAssetVal = new Asset();
      setAssetVal.set_id(asset.get_id());
      setAssetVal.setAssetType(asset.getAssetType());
      setAssetVal.setBssVer(asset.getBssVer());
      setAssetVal.setDocType(asset.getDocType());
      setAssetVal.setId(asset.getId());
      setAssetVal.setLinks(asset.getLinks());
      setAssetVal.setVer(asset.getVer());
      assetBulkResponse.getAssets().add(setAssetVal);
    });
    return assetBulkResponse;
  }

  /**
   * Creates the self link.
   *
   * @param pageSize
   *          the pageSize
   * @param currentPageNumber
   *          the page number
   * @param assetType
   *          the asset type
   * @return the link
   */
  private Link createSelfLink(Integer pageSize, Integer currentPageNumber, String assetType) {
    Link link = new Link();
    String href = createHref(pageSize, currentPageNumber, assetType);
    link.setHref(href);
    return link;
  }

  /**
   * Creates the href.
   *
   * @param pageSize
   *          the limit
   * @param currentPageNumber
   *          the page number
   * @param assetType
   *          the asset type
   * @return the string
   */
  private String createHref(int pageSize, int currentPageNumber, String assetType) {
    String href = StringUtils.EMPTY;
    String limit = String.valueOf(pageSize);

    if (AssetType.AGGREGATE.value().equalsIgnoreCase(assetType)) {
      href = ASSETS_PAGINATION_LINK_URL;
      href = href.replace(OPEN_PARANTHESIS + ASSET_TYPE + CLOSE_PARANTHESIS, AGGREGATES);
    } else if (AssetType.ASSESSMENT.value().equalsIgnoreCase(assetType)) {
      href = ASSETS_PAGINATION_LINK_URL;
      href = href.replace(OPEN_PARANTHESIS + ASSET_TYPE + CLOSE_PARANTHESIS, ASSESSMENTS);
    } else {
      href = ASSETS_PAGINATION_LINK_URL;
      href = href.replace(OPEN_PARANTHESIS + ASSET_TYPE + CLOSE_PARANTHESIS, INSTRUCTIONS);
    }
    href = href.replace(OPEN_PARANTHESIS + PAGE_SIZE + CLOSE_PARANTHESIS, limit);
    href = href.replace(OPEN_PARANTHESIS + PAGE_NUMBER + CLOSE_PARANTHESIS,
        String.valueOf(currentPageNumber + 2));
    return href;
  }

  /*
   * @see
   * com.pearson.glp.lpb.services.NonPrimitiveAssetService#findById(java.lang.
   * String)
   */
  @Override
  public Mono<NonPrimitiveAsset> findById(String assetId) {
    return repository.findById(assetId);
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.NonPrimitiveAssetService#getAllAssessment(org.
   * springframework.util.MultiValueMap)
   */
  @Override
  public Mono<AssetBulkResponse> getAllAssessment(MultiValueMap<String, String> parameters,
      int limit, int offset) {
    StringBuilder whereClause = prepareAssessmentWhereClause(parameters, AssetType.ASSESSMENT);
    String countKey = AssetType.ASSESSMENT.value()
        + prepareAssessmentCountKey(parameters).toString();
    Mono<Integer> assetBulkResponseCount = countLatestAssetsByAssetType(countKey);

    addSortAndPaginationParameters(whereClause, limit + 1, offset * limit);
    Flux<NonPrimitiveAsset> assetFlux = repository.findAssetByParameters(whereClause);

    Mono<List<NonPrimitiveAsset>> assetsMono = assetFlux.collectList();

    return assetBulkResponseCount.flatMap(count -> {
      return assetsMono.map(assets -> translateToAssetResponse(assets, AssetType.ASSESSMENT.value(),
          limit, offset, count));
    });
  }

  /**
   * Gets the all unique assessment.
   *
   * @param parameters
   *          the parameters
   * @return the all unique assessment
   */
  public Mono<String> getAllUniqueAssessment(MultiValueMap<String, String> parameters) {
    return fetchAllAssessments(prepareAssessmentCountKey(parameters).toString());
  }

  @Override
  public Mono<String> fetchAllAssessments(String countKey) {
    return contentRepository.fetchAllAssessments(countKey);
  }

}