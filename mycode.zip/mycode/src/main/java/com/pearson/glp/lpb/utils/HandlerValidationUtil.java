/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * The Class HandlerValidationUtil.
 * 
 * @author Nitin.tyagi1
 *
 */
@Component
@NoArgsConstructor
@AllArgsConstructor
public class HandlerValidationUtil {

  /** The errorUserDesc 400. */
  @Value("${errorUserDesc.400}")
  private String errorUserDesc400;

  /** The errorUserDesc 404. */
  @Value("${errorUserDesc.404}")
  private String errorUserDesc404;

  /** The errorUserDesc 405. */
  @Value("${errorUserDesc.405}")
  private String errorUserDesc405;

  /** The errorUserDesc 406. */
  @Value("${errorUserDesc.406}")
  private String errorUserDesc406;

  /** The errorUserDesc 415. */
  @Value("${errorUserDesc.415}")
  private String errorUserDesc415;

  /** The errorUserDesc 500. */
  @Value("${errorUserDesc.500}")
  private String errorUserDesc500;

  /**
   * Empty response.
   *
   * @return the mono
   */
  public Mono<JsonPayloadServiceResponse> emptyResponse() {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();

    jsonPayloadServiceResponse.setStatus(HttpStatus.NOT_FOUND.value());
    jsonPayloadServiceResponse.setPayload(prepareNotFoundResponse());

    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Prepare not found response.
   *
   * @return the error response
   */
  public PlatformErrorResponse prepareNotFoundResponse() {
    return prepareErrorResponse(HttpStatus.NOT_FOUND.value(),
        HttpStatus.NOT_FOUND.getReasonPhrase(), errorUserDesc404);
  }

  /**
   * Prepare bad request response.
   *
   * @return the error response
   */
  public PlatformErrorResponse prepareBadRequestResponse() {
    return prepareErrorResponse(HttpStatus.BAD_REQUEST.value(),
        HttpStatus.BAD_REQUEST.getReasonPhrase(), errorUserDesc400);
  }

  /**
   * Prepare server error response.
   *
   * @param message
   *          the message
   * @return the error response
   */
  public PlatformErrorResponse prepareServerErrorResponse(String message) {
    return prepareErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(),
        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), message);
  }

  /**
   * Prepare Method not allowed response.
   *
   * @return the error response
   */
  public PlatformErrorResponse prepareMethodNotAllowedResponse() {
    return prepareErrorResponse(HttpStatus.METHOD_NOT_ALLOWED.value(),
        HttpStatus.METHOD_NOT_ALLOWED.getReasonPhrase(), errorUserDesc405);
  }

  /**
   * Prepare unsupported media type response.
   *
   * @return the error response
   */
  public PlatformErrorResponse prepareUnsupportedMediaTypeResponse() {
    return prepareErrorResponse(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value(),
        HttpStatus.UNSUPPORTED_MEDIA_TYPE.getReasonPhrase(), errorUserDesc415);
  }

  /**
   * Prepare unsupported media type response.
   *
   * @return the error response
   */
  public PlatformErrorResponse prepareMediaTypeNotAcceptableResponse() {
    return prepareErrorResponse(HttpStatus.NOT_ACCEPTABLE.value(),
        HttpStatus.NOT_ACCEPTABLE.getReasonPhrase(), errorUserDesc406);
  }

  /**
   * Prepare error response.
   *
   * @param status
   *          the status
   * @param error
   *          the error
   * @param message
   *          the message
   * @return the error response
   */
  private PlatformErrorResponse prepareErrorResponse(int status, String error, String message) {
    PlatformErrorResponse response = new PlatformErrorResponse();
    response.setStatus(status);
    response.setError(error);
    response.setMessage(message);
    response.setTimestamp(CommonUtils.getTimeStamp());
    return response;
  }

}