/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;

import java.time.LocalDateTime;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.ConfigurationCompleteEventEntity;
import com.pearson.glp.lpb.data.model.EventEntity;
import com.pearson.glp.lpb.dto.request.ConfigurationCompleteEventPayload;
import com.pearson.glp.lpb.event.publisher.EventPublisher;

import reactor.core.publisher.Mono;

/**
 * The Class IscEventGenerator.
 */
@Component
public class IscEventGenerator {

  /** The event publisher. */
  private EventPublisher eventPublisher;

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(IscEventGenerator.class);

  /** The object mapper. */
  private ObjectMapper objectMapper = new ObjectMapper();

  /**
   * Instantiates a new user unique id generator.
   *
   * @param eventPublisher
   *          the event publisher
   */
  @Autowired
  public IscEventGenerator(EventPublisher eventPublisher) {
    this.eventPublisher = eventPublisher;
  }

  /**
   * Generate and publish event message.
   *
   * @param message
   *          the message
   * @return the mono
   */
  public Mono<ConfigurationCompleteEventEntity> generateAndPublishEventMessage(
      ConfigurationCompleteEventPayload message) {
    EventEntity<ConfigurationCompleteEventPayload> eventMessage = new EventEntity<>();
    eventMessage.setId(UUID.randomUUID().toString());
    eventMessage.setTimestamp(formatDateTime(LocalDateTime.now()).get());
    eventMessage.setPayload(message);
    eventMessage.setEventName(CommonConstants.CONFIGURATION_COMPLETED);
    LOGGER.debug("Inside IscEventGenerator :: creating eventmessage with eventname :: {}",
        CommonConstants.CONFIGURATION_COMPLETED);
    Mono<Boolean> publishAsnycEvent = eventPublisher
        .publishAsnycEvent(CommonConstants.CONFIGURATION_COMPLETED, message);
    return publishAsnycEvent.flatMap(status -> {
      ConfigurationCompleteEventEntity entity = new ConfigurationCompleteEventEntity();
      entity.setEventSend(status);
      entity.setEventMessage(eventMessage);
      return Mono.just(entity);
    });
  }
}
