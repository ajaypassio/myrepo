/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.CommonConstants.NUMBER_REGEX;
import static com.pearson.glp.lpb.constant.CommonConstants.ZERO_REGEX;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_MAX_PAGE_SIZE;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PAGE_SIZE;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PAGE_SIZE_AND_PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_LIMITS;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_OFFSET;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * The class PaginationUtil.
 *
 * @author shubham.chaudhary
 */
@Component
public class PaginationUtil {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(PaginationUtil.class);
  @Value("${defaultPageNumber}")
  private int defaultPageNumber;
  @Value("${defaultPageSize}")
  private int defaultPageSize;

  @Value("${defaultMaxPageSize}")
  private int defaultMaxPageSize;

  /**
   * Validate Pagination.
   *
   * @param pageSize
   *          the pageSize
   * @param pageNumber
   *          the pageNumber
   * @return boolean
   */
  public String validatePagination(String pageSize, String pageNumber) {

    String errorMessage = StringUtils.EMPTY;

    if (StringUtils.isEmpty(pageSize)) {
      pageSize = String.valueOf(defaultPageSize);
    }
    if (StringUtils.isEmpty(pageNumber)) {
      pageNumber = String.valueOf(defaultPageNumber);
    }
    if ((pageSize.matches(ZERO_REGEX) || !pageSize.matches(NUMBER_REGEX))
        && (pageNumber.matches(ZERO_REGEX) || !pageNumber.matches(NUMBER_REGEX))) {
      return ERROR_PAGE_SIZE_AND_PAGE_NUMBER;
    }
    if (pageSize.matches(ZERO_REGEX) || !pageSize.matches(NUMBER_REGEX)) {
      return ERROR_PAGE_SIZE;
    }
    if (pageNumber.matches(ZERO_REGEX) || !pageNumber.matches(NUMBER_REGEX)) {
      return ERROR_PAGE_NUMBER;
    }
    if (Integer.parseInt(pageSize) > defaultMaxPageSize) {
      return ERROR_MAX_PAGE_SIZE;
    }
    return errorMessage;
  }

  /**
   * Gets the Off set.
   *
   * @param pageNumber
   *          the pageNumber
   * @return the all offset
   */
  public int getOffset(String pageNumber) throws NumberFormatException {
    LOGGER.debug(GETTING_OFFSET);
    int offsetValue = Integer.parseInt(pageNumber);
    return offsetValue > 0 ? offsetValue : defaultPageNumber;
  }

  /**
   * Gets the Limit.
   *
   * @param pageSize
   *          the pageSize
   * @return the all limit
   */
  public int getLimit(String pageSize) throws NumberFormatException {
    LOGGER.debug(GETTING_LIMITS);
    int limitValue = Integer.parseInt(pageSize);
    return limitValue > 0 ? limitValue : defaultPageSize;
  }

  /**
   * Prepare page Size.
   *
   * @param pageSize
   *          the pageSize
   * @return pageSize
   */
  public String preparePageSize(String pageSize) {
    if (StringUtils.isEmpty(pageSize)) {
      return String.valueOf(defaultPageSize);
    }
    return pageSize;
  }

  /**
   * Prepare page number.
   *
   * @param pageNumber
   *          the pageNumber
   * @return pageSize
   */
  public String preparePageNumber(String pageNumber) {
    if (StringUtils.isEmpty(pageNumber)) {
      return String.valueOf(defaultPageNumber);
    }
    return pageNumber;
  }

}
