/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.STRING_JOINER_COMMA;
import static com.pearson.glp.lpb.constant.LoggingConstants.INVALID_REQUEST_PAYLOAD;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.pearson.glp.core.handlers.base.ServiceRuntimeException;
import com.pearson.glp.core.utils.exception.PlatformException;
import com.pearson.glp.crosscutting.isc.client.commons.exception.ValidationException;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.InvalidMediaTypeException;
import org.springframework.http.MediaType;

import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.PlatformErrorCode;

import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * The Interface PlatformErrorUtils.
 * 
 * @author sourabh.aggarwal
 */
public interface PlatformErrorUtils {

  /**
   * Object not found error.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> objectNotFoundError(String message) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.OBJECT_NOT_FOUND.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.OBJECT_NOT_FOUND.getValue(),
            PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), message, null));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Internal server error.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> internalServerError(String message) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue(),
            PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), message, null));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Invalid request error.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> invalidRequestError(String message) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.INVALID_REQUEST.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
            PlatformErrorCode.INVALID_REQUEST.getErrorCode(), message, null));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Invalid request error.
   * 
   * @param message
   *          the message
   * @param link
   *          the link
   * @return service handler response mono
   */
  static Mono<ServiceHandlerResponse> invalidRequestError(String message, Link link) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.INVALID_REQUEST.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
            PlatformErrorCode.INVALID_REQUEST.getErrorCode(), message, link));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Invalid request error.
   *
   * @param throwable
   *          the throwable
   * @return service handler response mono
   */
  static Mono<ServiceHandlerResponse> generateErrorResponse(Throwable throwable) {
    if (throwable instanceof ValidationException) {
      ValidationException validationException = (ValidationException) throwable;
      String errorMessage = validationException.getErrors().stream()
          .map(error -> error.getMessage()).collect(Collectors.joining(STRING_JOINER_COMMA));
      return invalidRequestError(errorMessage);
    } else if (throwable instanceof PlatformException) {
      PlatformException platformException = (PlatformException) throwable;
      String errorMessage = platformException.getErrors().stream().map(error -> error.getMessage())
          .collect(Collectors.joining(STRING_JOINER_COMMA));
      return invalidRequestError(errorMessage);
    } else if (throwable instanceof ServiceRuntimeException
        || throwable instanceof DecodingException) {
      return invalidRequestError(throwable.getMessage());
    } else {
      return internalServerError(throwable.getMessage());
    }
  }

  /**
   * Error Handler error response.
   *
   * @param throwable
   *          the throwable
   * @return service handler response mono
   */
  static Mono<ServerResponse> generateErrorServerResponse(Throwable throwable,
      PlatformErrorResponse response) {
    if (throwable instanceof ServiceRuntimeException || throwable instanceof DecodingException) {
      return ServerResponse.status(HttpStatus.BAD_REQUEST)
          .body(BodyInserters
              .fromObject(prepareErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
                  PlatformErrorCode.INVALID_REQUEST.getErrorCode(), throwable.getMessage(), null)));
    } else if (throwable instanceof DecodingException) {
      return ServerResponse.status(HttpStatus.BAD_REQUEST)
          .body(BodyInserters
              .fromObject(prepareErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
                  PlatformErrorCode.INVALID_REQUEST.getErrorCode(), throwable.getMessage(), null)));
    } else if (!(throwable instanceof IllegalStateException
        || throwable instanceof InvalidMediaTypeException)) {
      return ServerResponse.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(BodyInserters
              .fromObject(prepareErrorResponse(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue(),
                  PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), throwable.getMessage(),
                  null)));
    } else {
      return ServerResponse.status(HttpStatus.NOT_ACCEPTABLE)
          .contentType(MediaType.APPLICATION_JSON_UTF8).body(BodyInserters.fromObject(response));
    }
  }

  /**
   * Generate error response.
   *
   * @param metadata
   *          the metadata
   * @param message
   *          the message
   * @param links
   *          the links
   * @return the mono
   */
  static Mono<AssetResponse> invalidRequestAssetResponse(ContentMetadata metadata, String message,
      Link links) {
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setContentMetadata(metadata);
    assetResponse.setError(PlatformErrorUtils.prepareErrorResponse(HttpStatus.BAD_REQUEST.value(),
        PlatformErrorCode.INVALID_REQUEST.getErrorCode(), message, links));
    return Mono.just(assetResponse);
  }

  /**
   * Prepare error response.
   *
   * @param status
   *          the status
   * @param errorCode
   *          the error code
   * @param message
   *          the message
   * @param link
   *          the Link
   * @return the platform error
   */
  static PlatformErrorResponse prepareErrorResponse(int status, String errorCode, String message,
      Link link) {
    PlatformErrorResponse platformErrorResponse = new PlatformErrorResponse();
    platformErrorResponse.setStatus(status);
    platformErrorResponse.setError(errorCode);
    platformErrorResponse.setMessage(message);
    platformErrorResponse.setLink(link);
    platformErrorResponse.setTimestamp(CommonUtils.getTimeStamp());
    return platformErrorResponse;
  }
}