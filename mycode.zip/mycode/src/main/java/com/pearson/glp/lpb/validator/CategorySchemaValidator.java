/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.LMValidationConstants.VALID_RESOURCE;
import static com.pearson.glp.lpb.constant.LoggingConstants.CATEGORY_SCHEMA_LOG_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.CATEGORY_SCHEMA_VALIDATION_SUCCESSFUL;
import static com.pearson.glp.lpb.constant.LoggingConstants.MAX;
import static com.pearson.glp.lpb.constant.LoggingConstants.MIN;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.pearson.glp.lpb.data.model.lm.resources.CategorySchema;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;

/**
 * The Class CategorySchemaValidator is used for learning model validation of
 * non primitive assets.
 * 
 * @author srishti.singh
 */
@Component
public class CategorySchemaValidator {

  /** The Constant FULL_STOP_SPACE. */
  private static final String FULL_STOP_SPACE = ". ";

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(CategorySchemaValidator.class);

  /**
   * Check category schema.
   *
   * @param keyPatternMap
   *          the kp map
   * @return the mono
   */
  public String validateCategorySchema(Map<ResourceData, Integer> keyPatternMap) {
    StringBuilder errorBuilder = new StringBuilder();
    keyPatternMap.forEach((key, val) -> {
      CategorySchema categorySchema = key.getCategorySchema();
      if (categorySchema != null) {
        Integer minProp = categorySchema.getMinProperties();
        Integer maxProp = categorySchema.getMaxProperties();
        String keyPattern = key.getKeyPattern();
        if (minProp != null && minProp > val) {
          LOGGER.debug(MIN + CATEGORY_SCHEMA_LOG_MESSAGE, keyPattern, minProp, val);
          errorBuilder.append(val).append(RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN).append(keyPattern)
              .append(MIN).append(minProp).append(FULL_STOP_SPACE);
        }
        if (maxProp != null && val > maxProp) {
          LOGGER.debug(MAX + CATEGORY_SCHEMA_LOG_MESSAGE, keyPattern, maxProp, val);
          errorBuilder.append(val).append(RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN).append(keyPattern)
              .append(MAX).append(maxProp).append(FULL_STOP_SPACE);
        }
      }
    });
    if (errorBuilder.length() == 0) {
      LOGGER.debug(CATEGORY_SCHEMA_VALIDATION_SUCCESSFUL);
      errorBuilder.append(VALID_RESOURCE);
    }
    return errorBuilder.toString();
  }

}
