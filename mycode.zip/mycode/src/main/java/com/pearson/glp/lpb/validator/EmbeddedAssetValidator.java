/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.CommonConstants.COUNT_ZERO;
import static com.pearson.glp.lpb.constant.CommonConstants.END_NODE_POLICY_KEY;
import static com.pearson.glp.lpb.constant.CommonConstants.POLICY_KEY;
import static com.pearson.glp.lpb.constant.LMValidationConstants.AND_VERSION;
import static com.pearson.glp.lpb.constant.LMValidationConstants.ERROR_VALIDATING;
import static com.pearson.glp.lpb.constant.LMValidationConstants.UNABLE_TO_FETCH_RESOURCE_FOR_ID;
import static com.pearson.glp.lpb.constant.LMValidationConstants.VALID_RESOURCE;
import static com.pearson.glp.lpb.constant.LoggingConstants.CONFIGURATION_VALIDATION_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.RELATIONSHIP_VALIDATION_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCES_NOT_FOUND_FOR_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCE_VALIDATED_CORRECTLY;
import static com.pearson.glp.lpb.constant.LoggingConstants.VALIDATING_RESOURCE_ID_AND_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ASSETCLASS_CONFIGURATION_VALIDATION_ERROR;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.AssetGraph;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.EmbeddedResources;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class EmbeddedAssetValidator.
 * 
 * @author jeevansingh.dhami
 */
@Component
public class EmbeddedAssetValidator implements CommonUtils {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(EmbeddedAssetValidator.class);

  /** The repository. */
  @Autowired
  private NonPrimitiveAssetRepository repository;

  /**
   * Validate embedded asset.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param metadata
   * @return the mono
   */
  public Mono<AssetResponse> validateEmbeddedAsset(NonPrimitiveAsset nonPrimitiveAsset,
      ContentMetadata metadata) {
    return validateResources(nonPrimitiveAsset).filter(str -> !VALID_RESOURCE.equalsIgnoreCase(str))
        .collect(Collectors.toSet()).flatMap(errorSet -> {
          if (!errorSet.isEmpty()) {
            return PlatformErrorUtils.invalidRequestAssetResponse(metadata,
                String.join(CommonConstants.STRING_JOINER_COMMA, errorSet), null);
          } else {
            LOGGER.debug(RESOURCE_VALIDATED_CORRECTLY, metadata);
            return Mono.empty().cast(AssetResponse.class);
          }
        });
  }

  /**
   * Validate resources.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the flux
   */
  @SuppressWarnings("unchecked")
  private Flux<String> validateResources(NonPrimitiveAsset nonPrimitiveAsset) {
    Flux<String> validationStatus = Flux.fromIterable(new ArrayList<>());
    List<AssetGraph> assetGraphs = nonPrimitiveAsset.getAssetGraph();
    Configuration configuration = nonPrimitiveAsset.getConfiguration();
    int embeddedAssetCount = 0;
    for (AssetGraph assetGraph : assetGraphs) {
      if (!assetGraph.getRelationships().isEmpty()
          && assetGraph.getRelationships().containsKey(END_NODE_POLICY_KEY)) {
        embeddedAssetCount++;
        Map<String, String> policyKey = objectMapper
            .convertValue(assetGraph.getRelationships().get(END_NODE_POLICY_KEY), HashMap.class);
        String policy = policyKey.get(POLICY_KEY);

        if (configuration.containsKey(policy)) {
          EmbeddedResources resources = objectMapper.convertValue(configuration.get(policy),
              EmbeddedResources.class);
          LOGGER.debug(VALIDATING_RESOURCE_ID_AND_VERSION, resources.getId(), resources.getVer());
          Mono<NonPrimitiveAsset> npAsset = repository.findById(CommonUtils
              .generateDocId(resources.getAssetType(), resources.getId(), resources.getVer()));
          String assetClass = resources.getAssetClass();
          validationStatus = validationStatus.concatWith(npAsset.map(asset -> {
            if (Optional.ofNullable(assetClass).isPresent()
                && asset.getAssetClass().equals(assetClass)) {
              LOGGER.debug(RESOURCE_VALIDATED_CORRECTLY, asset.getId());
              return VALID_RESOURCE;
            } else {
              return ASSETCLASS_CONFIGURATION_VALIDATION_ERROR;
            }
          }).switchIfEmpty(checkIfResourceIsEmpty(resources.getId(), resources.getVer(), npAsset))
              .onErrorResume(error -> {
                StringBuilder builder = new StringBuilder(UNABLE_TO_FETCH_RESOURCE_FOR_ID);
                builder.append(resources.getId()).append(AND_VERSION)
                    .append(resources.getVer() + "." + error.getMessage());
                return Mono.just(builder.toString());
              }));
        } else {
          validationStatus = validationStatus.concatWith(Mono.just(CONFIGURATION_VALIDATION_ERROR));
        }
      }
    }
    if (embeddedAssetCount == COUNT_ZERO) {
      validationStatus = validationStatus.concatWith(Mono.just(RELATIONSHIP_VALIDATION_ERROR));
    }
    return validationStatus;
  }

  /**
   * Check if resource is empty.
   *
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @param pr
   *          the pr
   * @return the mono
   */
  private Mono<String> checkIfResourceIsEmpty(String id, String ver, Mono<NonPrimitiveAsset> pr) {
    return pr.flatMap(a -> Mono.just(ERROR_VALIDATING)).switchIfEmpty(Mono.just(new StringBuilder()
        .append(RESOURCES_NOT_FOUND_FOR_ID).append(id).append(AND_VERSION).append(ver).toString()));
  }

}
