/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.LMValidationConstants.AND_VERSION;
import static com.pearson.glp.lpb.constant.LMValidationConstants.OF_RESOURCE_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_VALIDATING_INSTANCE_SCHEMA;
import static com.pearson.glp.lpb.constant.LoggingConstants.INSTANCE_SCHEMA_ENUM_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.INSTANCE_SCHEMA_REQUIRED_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.MANDATORY_FIELD_FOR_RESOURCE_ID;
import static com.pearson.glp.lpb.constant.CommonConstants.STRING_JOINER_COMMA;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.lm.resources.InstanceSchema;
import com.pearson.glp.lpb.data.model.lm.resources.PropertyType;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;

/**
 * The Class InstanceSchemaValidator is used for learning model validation of
 * non primitive assets.
 * 
 * @author srishti.singh
 */
@Component
public class InstanceSchemaValidator {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(InstanceSchemaValidator.class);

  /**
   * Validate instance schema.
   *
   * @param resourceData
   *          the resource data
   * @param asset
   *          the asset
   * @return the list
   */
  public List<String> validateInstanceSchema(ResourceData resourceData, NonPrimitiveAsset asset) {
    InstanceSchema schema = resourceData.getInstanceSchema();
    List<String> requiredList = schema.getRequired();
    String resourceId = asset.get_id();
    String resourceVer = asset.getVer();

    // validate properties
    Map<String, PropertyType> schemaMap = schema.getProperties();
    List<String> errorList = new ArrayList<>();
    schemaMap.forEach((field, property) -> {
      Object fieldValue = getValueFromFieldName(asset, field);

      // validate required and enum values
      if (fieldValue == null && requiredList.contains(field)) {
        LOGGER.debug(INSTANCE_SCHEMA_REQUIRED_LOG, field, resourceId, resourceVer);
        errorList
            .add(field + MANDATORY_FIELD_FOR_RESOURCE_ID + resourceId + AND_VERSION + resourceVer);
      } else if (fieldValue != null
          && !property.getEnumVal().stream().filter(fieldValue::equals).findFirst().isPresent()) {
        LOGGER.debug(INSTANCE_SCHEMA_ENUM_LOG, field, resourceId, resourceVer,
            property.getEnumVal());
        errorList.add(field + OF_RESOURCE_ID + resourceId + AND_VERSION + resourceVer
            + " must match the enum value(s) "
            + String.join(STRING_JOINER_COMMA, property.getEnumVal()));
      }
    });
    return errorList;
  }

  /**
   * Gets the value from field name.
   *
   * @param asset
   *          the asset
   * @param fieldName
   *          the required
   * @return the value from field name
   */
  private Object getValueFromFieldName(NonPrimitiveAsset asset, String fieldName) {
    try {
      Object fieldValue = null;
      for (Field field : Asset.class.getDeclaredFields()) {
        JsonProperty jsonProperty = field.getAnnotation(JsonProperty.class);
        SerializedName serializedName = field.getAnnotation(SerializedName.class);
        if (jsonProperty != null && fieldName.equals(jsonProperty.value())) {
          fieldValue = new PropertyDescriptor(field.getName(), NonPrimitiveAsset.class)
              .getReadMethod().invoke(asset);
        } else if (serializedName != null && fieldName.equals(serializedName.value())) {
          fieldValue = new PropertyDescriptor(field.getName(), NonPrimitiveAsset.class)
              .getReadMethod().invoke(asset);
        }
      }
      return fieldValue;

    } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
        | IntrospectionException e) {
      LOGGER.error(ERROR_VALIDATING_INSTANCE_SCHEMA, asset.get_id(), asset.getVer(),
          e.getMessage());
      return null;
    }
  }

}
