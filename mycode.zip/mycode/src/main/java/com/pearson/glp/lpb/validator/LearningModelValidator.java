/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.CommonConstants.ASSETMODEL;
import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.DOUBLE_COLON;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCTMODEL;
import static com.pearson.glp.lpb.constant.CommonConstants.STRING_JOINER_COMMA;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSIONS_URL;
import static com.pearson.glp.lpb.constant.LMValidationConstants.AND_VERSION;
import static com.pearson.glp.lpb.constant.LMValidationConstants.COMMA_SEPARATOR_REGEX;
import static com.pearson.glp.lpb.constant.LMValidationConstants.DOES_NOT_MATCH_ANY_KEY_PATTERN;
import static com.pearson.glp.lpb.constant.LMValidationConstants.ERROR_VALIDATING;
import static com.pearson.glp.lpb.constant.LMValidationConstants.LEARNING_MODEL_NOT_FOUND_FOR_ID;
import static com.pearson.glp.lpb.constant.LMValidationConstants.OF_RESOURCE_ID;
import static com.pearson.glp.lpb.constant.LMValidationConstants.UNABLE_TO_FETCH_RESOURCE_FOR_ID;
import static com.pearson.glp.lpb.constant.LMValidationConstants.VALID_RESOURCE;
import static com.pearson.glp.lpb.constant.LoggingConstants.ASSET_CLASS_DOES_NOT_MATCH_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.DOES_NOT_MATCH_THE_ASSET_CLASS;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCHING_RESOURCE_FROM_DATABASE;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCHING_RESOURCE_FROM_LAP;
import static com.pearson.glp.lpb.constant.LoggingConstants.KEY_PATTERN_INCORRECT;
import static com.pearson.glp.lpb.constant.LoggingConstants.LEARNING_MODEL_VALIDATION_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.MODEL_VALIDATION_BEGINS;
import static com.pearson.glp.lpb.constant.LoggingConstants.MODEL_VALIDATION_SUCCESSFUL;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCES_NOT_FOUND_FOR_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCE_FETCH_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCE_VALIDATED_CORRECTLY;
import static com.pearson.glp.lpb.constant.LoggingConstants.VALIDATING_RESOURCE_ID_AND_VERSION;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.LearningModel;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.Resources;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceObject;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.CacheRegion;
import com.pearson.glp.lpb.enums.Routes;
import com.pearson.glp.lpb.utils.CacheUtils;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class LearningModelValidator.
 */
@Component
public class LearningModelValidator {

  /** The Constant ASSETCLASS. */
  private static final String ASSETCLASS = "assetClass ";

  /** The Constant FULL_STOP. */
  private static final String FULL_STOP = ". ";

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(LearningModelValidator.class);

  /** The repository. */
  @Autowired
  private NonPrimitiveAssetRepository repository;

  /** The isc sync client. */
  @Autowired
  private IscSyncClient iscSyncClient;

  /** The asset repo. */
  @Autowired
  private LearningModelRepository assetRepo;

  /** The instance schema validator. */
  @Autowired
  private InstanceSchemaValidator instanceSchemaValidator;

  /** The category schema validator. */
  @Autowired
  private CategorySchemaValidator categorySchemaValidator;

  /** The lap base url. */
  @Value("${lap.base.url}")
  private String lapBaseUrl;

  @Autowired
  private CacheUtils cacheService;

  /**
   * Instantiates a new asset and model validator.
   */
  public LearningModelValidator() {
    super();
  }

  /**
   * Validate learning asset with learning model.
   *
   * @param assetPayload
   *          the asset payload
   * @return the mono
   */
  public Mono<AssetResponse> validateLearningAssetWithLearningModel(
      NonPrimitiveAsset assetPayload) {
    ContentMetadata metadata = (ContentMetadata) assetPayload.getExtensions().get(CONTENT_METADATA);
    LOGGER.debug(MODEL_VALIDATION_BEGINS, metadata);

    String lmId = assetPayload.getLearningModel().getId();
    String lmVer = assetPayload.getLearningModel().getVer();

    Mono<AssetModel> assetModel = null;
    String key = CommonUtils.generateLearningModelKey(lmId, lmVer);
    Optional<AssetModel> cachedValue = cacheService.get(CacheRegion.LEARNING_MODEL, key)
        .map(o -> (AssetModel) o);
    if (cachedValue.isPresent()) {
      assetModel = Mono.just(cachedValue.get());
    } else {
      assetModel = findLearningModel(lmId, lmVer, assetPayload.getLearningModel().getAssetType())
          .flatMap(learningModel -> {
            cacheService.put(CacheRegion.LEARNING_MODEL, key, learningModel);
            return Mono.just(learningModel);
          });
    }

    Flux<String> errorList = validateResources(assetPayload.getResources(), assetModel,
        assetPayload.getLearningModel(), assetPayload.getAssetClass());
    return errorList.filter(str -> !VALID_RESOURCE.equalsIgnoreCase(str))
        .collect(Collectors.toSet()).flatMap(errorSet -> {
          if (!errorSet.isEmpty()) {
            return PlatformErrorUtils.invalidRequestAssetResponse(metadata,
                LEARNING_MODEL_VALIDATION_ERROR + errorSet,
                getLearningModelLink(assetPayload.getLearningModel(),
                    assetPayload.getLearningModel().getAssetType()));
          } else {
            LOGGER.debug(MODEL_VALIDATION_SUCCESSFUL, metadata);
            return Mono.empty().cast(AssetResponse.class);
          }
        });
  }

  /**
   * Gets the learning model link.
   *
   * @param learningModel
   *          the learning model
   * @param assetType
   *          the asset type
   * @return the learning model link
   */
  private Link getLearningModelLink(LearningModel learningModel, String assetType) {
    String path = Routes.ASSET_MODELS_ROUTE.value();
    if (AssetType.PRODUCT.name().equals(assetType)) {
      path = Routes.PRODUCT_MODELS_ROUTE.value();
    }
    String href = new StringBuilder().append(path).append("/").append(learningModel.getId())
        .append(VERSIONS_URL).append(learningModel.getVer()).toString();
    return new Link(href);
  }

  /**
   * Validate resources.
   *
   * @param laResources
   *          the laresources
   * @param assetModel
   *          the asset model
   * @param model
   *          the model
   * @param laAssetClass
   *          the asset class
   * @return the flux
   */
  private Flux<String> validateResources(Map<String, Resources> laResources,
      Mono<AssetModel> assetModel, LearningModel model, String laAssetClass) {

    Flux<String> errorList = Flux.fromIterable(new ArrayList<>());

    // check that assetClass of LA is same as assetClass of its LM.
    errorList = errorList.concatWith(assetModel.map(m -> validateAssetClass(laAssetClass, m)));

    Map<ResourceData, Integer> keyPatternMap = new HashMap<>();
    for (Entry<String, Resources> entry : laResources.entrySet()) {
      String resourceId = entry.getValue().getId();
      String resourceVer = entry.getValue().getVer();
      Mono<NonPrimitiveAsset> resource = getResourceLA(entry.getValue());
      errorList = errorList.concatWith(resource.zipWith(assetModel).map(tuple -> {
        LOGGER.debug(VALIDATING_RESOURCE_ID_AND_VERSION, resourceId, resourceVer);
        // Match assetClass with Key Pattern.
        NonPrimitiveAsset laResource = tuple.getT1();
        String assetClass = laResource.getAssetClass();
        // Updating Label, Extensions and assetClass from the resources for
        // event payload
        updateNonPrimitiveAsset(entry, laResource);
        Optional<Entry<String, ResourceObject>> lmResourceEntry = matchKeyPattern(assetClass,
            tuple.getT2().getResources());
        if (lmResourceEntry.isPresent()) {
          // Populate Key pattern map for category schema validation.
          addToKeyPatternMap(keyPatternMap, lmResourceEntry.get().getValue().getData());

          // Validate instance schema for resource that match key pattern.
          List<String> schemaErrorlist = instanceSchemaValidator
              .validateInstanceSchema(lmResourceEntry.get().getValue().getData(), laResource);
          if (CollectionUtils.isEmpty(schemaErrorlist)) {
            LOGGER.debug(RESOURCE_VALIDATED_CORRECTLY, resourceId);
            return VALID_RESOURCE;
          } else {
            return String.join(STRING_JOINER_COMMA, schemaErrorlist);
          }
        } else {
          LOGGER.debug(KEY_PATTERN_INCORRECT, assetClass, resourceId, resourceVer);
          return incorrectAssetClassErrorMessage(resourceId, resourceVer, assetClass);
        }
      }).switchIfEmpty(checkIfModelResourceIsEmpty(model.getId(), model.getVer(), assetModel,
          resourceId, resourceVer, resource)).onErrorResume(ex -> {
            LOGGER.error(RESOURCE_FETCH_ERROR, resourceId, resourceVer, ex.getMessage());
            return Mono.just(UNABLE_TO_FETCH_RESOURCE_FOR_ID + resourceId + AND_VERSION
                + resourceVer + FULL_STOP + ex.getMessage());
          }));
    }

    // Check max and min properties from category schema.
    errorList = errorList.concatWith(
        Mono.fromSupplier(() -> categorySchemaValidator.validateCategorySchema(keyPatternMap)));

    return errorList;
  }

  /**
   * Update non primitive asset.
   *
   * @param entry
   *          the entry
   * @param laResource
   *          the la resource
   */
  private void updateNonPrimitiveAsset(Entry<String, Resources> entry,
      NonPrimitiveAsset laResource) {
    if (StringUtils.isEmpty(entry.getValue().getLabel())) {
      entry.getValue().setLabel(laResource.getLabel());
    }

    if (StringUtils.isEmpty(entry.getValue().getExtensions())) {
      entry.getValue().setExtensions(laResource.getExtensions());
    }

    if (StringUtils.isEmpty(entry.getValue().getAssetClass())) {
      entry.getValue().setAssetClass(laResource.getAssetClass());
    }
  }

  /**
   * Validate asset class.
   *
   * @param assetClass
   *          the asset class
   * @param model
   *          the model
   * @return the string
   */
  private String validateAssetClass(String assetClass, AssetModel model) {
    if (assetClass != null && model.getAssetClass() != null
        && Arrays.stream(model.getAssetClass().split(COMMA_SEPARATOR_REGEX))
            .anyMatch(ac -> ac.equalsIgnoreCase(assetClass))) {
      return VALID_RESOURCE;
    }
    LOGGER.error(ASSET_CLASS_DOES_NOT_MATCH_LOG, assetClass, model.get_id(), model.getVer());
    return new StringBuilder(ASSETCLASS).append(assetClass).append(DOES_NOT_MATCH_THE_ASSET_CLASS)
        .toString();
  }

  /**
   * Incorrect label error message.
   *
   * @param resourceId
   *          the resource id
   * @param resVer
   *          the res ver
   * @param assetClass
   *          the label
   * @return the string
   */
  private String incorrectAssetClassErrorMessage(String resourceId, String resVer,
      String assetClass) {
    return new StringBuilder().append(ASSETCLASS).append(assetClass).append(OF_RESOURCE_ID)
        .append(resourceId).append(AND_VERSION).append(resVer)
        .append(DOES_NOT_MATCH_ANY_KEY_PATTERN).toString();
  }

  /**
   * Adds the to key pattern map.
   *
   * @param keyPatternMap
   *          the key pattern map
   * @param resourceObject
   *          the resource object
   */
  private void addToKeyPatternMap(Map<ResourceData, Integer> keyPatternMap,
      ResourceData resourceObject) {

    if (keyPatternMap.containsKey(resourceObject)) {
      keyPatternMap.put(resourceObject, keyPatternMap.get(resourceObject) + 1);
    } else {
      keyPatternMap.put(resourceObject, 1);
    }
  }

  /**
   * Check if model resource is empty.
   *
   * @param lmId
   *          the lm id
   * @param lmVer
   *          the lm ver
   * @param assetModel
   *          the asset model
   * @param resId
   *          the res id
   * @param resVer
   *          the res ver
   * @param resource
   *          the resource
   * @return the mono
   */
  private Mono<String> checkIfModelResourceIsEmpty(String lmId, String lmVer,
      Mono<AssetModel> assetModel, String resId, String resVer, Mono<NonPrimitiveAsset> resource) {
    return assetModel.flatMap(a -> checkIfResourceIsEmpty(resId, resVer, resource))
        .switchIfEmpty(Mono.just(new StringBuilder().append(LEARNING_MODEL_NOT_FOUND_FOR_ID)
            .append(lmId).append(AND_VERSION).append(lmVer).toString()));
  }

  /**
   * Check if resource is empty.
   *
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @param pr
   *          the pr
   * @return the mono
   */
  private Mono<String> checkIfResourceIsEmpty(String id, String ver, Mono<NonPrimitiveAsset> pr) {
    return pr.flatMap(a -> Mono.just(ERROR_VALIDATING)).switchIfEmpty(Mono.just(new StringBuilder()
        .append(RESOURCES_NOT_FOUND_FOR_ID).append(id).append(AND_VERSION).append(ver).toString()));
  }

  /**
   * Gets the resource LA.
   *
   * @param lavalue
   *          the lavalue
   * @return the resource LA
   */
  private Mono<NonPrimitiveAsset> getResourceLA(Resources lavalue) {
    if (lavalue.getAssetType().equalsIgnoreCase(AssetType.NARRATIVE.value())
        || lavalue.getAssetType().equalsIgnoreCase(AssetType.ASSESSMENT_ITEM.value())
        || lavalue.getAssetType().equalsIgnoreCase(AssetType.LEARNINGAPP_ITEM.value())) {
      // call to LAP
      LOGGER.debug(FETCHING_RESOURCE_FROM_LAP, lavalue.getId());
      return fetchFromLap(createSelfLink(lavalue));
    } else {
      // call LPB db
      LOGGER.debug(FETCHING_RESOURCE_FROM_DATABASE, lavalue.getId());
      return fetchFromDB(lavalue);
    }
  }

  /**
   * Fetch from lap.
   *
   * @param selfHref
   *          the self href
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> fetchFromLap(String selfHref) {
    Map<String, String> headersMap = new HashMap<>();
    return iscSyncClient.getObject(selfHref, headersMap, NonPrimitiveAsset.class,
        IscSyncResponseFormat.RAW);
  }

  /**
   * Creates the self link.
   *
   * @param lavalue
   *          the lavalue
   * @return the string
   */
  private String createSelfLink(Resources lavalue) {
    String href = lapBaseUrl + AssetType.getKey(lavalue.getAssetType()).url();
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, lavalue.getId());
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, lavalue.getVer());
    return href;
  }

  /**
   * Fetch from DB.
   *
   * @param resources
   *          the resources
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> fetchFromDB(Resources resources) {
    return repository.findById(CommonUtils.nonPrimitiveLearningAssetDocumentId(
        AssetType.valueOf(resources.getAssetType()), resources.getId(), resources.getVer()));
  }

  /**
   * Match key pattern.
   *
   * @param assetClass
   *          the assetClass
   * @param lmresources
   *          the lmresources
   * @return true, if successful
   */
  private Optional<Entry<String, ResourceObject>> matchKeyPattern(String assetClass,
      Map<String, ResourceObject> lmresources) {
    return lmresources.entrySet().stream().filter(entry -> assetClass != null && assetClass
        .toLowerCase().matches(entry.getValue().getData().getKeyPattern().toLowerCase()))
        .findFirst();
  }

  /**
   * Find learning model by id and version and asset type.
   *
   * @param learningModelId
   *          the learning model id
   * @param ver
   *          the ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  private Mono<AssetModel> findLearningModel(String learningModelId, String ver, String assetType) {
    String docId = null;
    if (PRODUCT.equals(assetType)) {
      docId = Stream.of(PRODUCTMODEL, DOUBLE_COLON, learningModelId, DOUBLE_COLON, ver)
          .collect(Collectors.joining());
    } else {
      docId = Stream.of(ASSETMODEL, DOUBLE_COLON, learningModelId, DOUBLE_COLON, ver)
          .collect(Collectors.joining());
    }
    return assetRepo.findById(docId);
  }
}