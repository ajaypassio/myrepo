/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_STREAMING_WITH_HAL;

import java.util.HashMap;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;

import io.restassured.RestAssured;
import reactor.core.publisher.Mono;

/**
 * The Class AssessmentsSuccessBase.
 * 
 * @author shubham.bansal
 */
public abstract class AssessmentsSuccessBase extends ProducerBase {

  /** The Constant RESPONSE_JSON. */
  private static final String ASSESSMENT_BY_ID_JSON_RESPONSE = "AssessmentsById.json";

  /** The Constant ASSESSMENT_GET_BY_ID_VERSION_JSON. */
  private static final String ASSESSMENT_GET_BY_ID_VERSION_JSON = "GetAssementByVersionId.json";

  /** The Constant ASSESSMENT_POST_JSON. */
  private static final String ASSESSMENT_POST_JSON = "AssessmentPostResponse.json";

  /** The Constant RESPONSE_JSON. */
  private static final String RESPONSE_JSON = "GetAssessmentsByQueryParam.json";

  /**
   * Sets the up.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setUp() throws ServiceException {
    RestAssured.port = this.port;
    RestAssured.baseURI = localhost;

    Mockito.when(nonPrimitiveHandler.getAssetById(Mockito.any(), Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload(convertJsonToObject(ASSESSMENT_BY_ID_JSON_RESPONSE, HashMap.class)));

    Mockito.when(nonPrimitiveHandler.getAssetByAssetIdAndVersionId(Mockito.any(), Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload(convertJsonToObject(ASSESSMENT_GET_BY_ID_VERSION_JSON, HashMap.class)));

    Mono<ServiceHandlerResponse> serverResponse = JsonPayloadServiceResponse
        .withStatus(HttpStatus.MULTI_STATUS)
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_STREAMING_WITH_HAL)
        .setPayload(convertJsonToObject(ASSESSMENT_POST_JSON, HashMap.class));

    Mockito.when(nonPrimitiveHandler.createAssets(Mockito.any(), Mockito.any()))
        .thenReturn(serverResponse);

    Mockito.when(nonPrimitiveHandler.getAssessments(Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload(convertJsonToObject(RESPONSE_JSON, HashMap.class)));
  }

}
