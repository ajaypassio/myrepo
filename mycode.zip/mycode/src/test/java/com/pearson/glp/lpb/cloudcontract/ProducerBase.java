/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import static org.junit.Assert.assertEquals;

import org.assertj.core.api.Assertions;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.kafka.test.rule.KafkaEmbedded;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.pearson.glp.core.validation.SchemaValidation;
import com.pearson.glp.lpb.LearningProductBuilderApp;
import com.pearson.glp.lpb.data.repository.ContentRepository;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.data.repository.ProductRepository;
import com.pearson.glp.lpb.data.repository.ProductStatusRepository;
import com.pearson.glp.lpb.data.repository.TaskRepository;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.handlers.LearningModelHandler;
import com.pearson.glp.lpb.handlers.NonPrimitiveAssetHandler;
import com.pearson.glp.lpb.handlers.ProductHandler;
import com.pearson.glp.lpb.handlers.TaskHandler;
import com.pearson.glp.lpb.services.EventService;
import com.pearson.glp.lpb.services.ProductService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.validator.LearningModelValidator;

import io.prometheus.client.CollectorRegistry;
import net.minidev.json.JSONArray;

/**
 * The Class ProducerBase.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {
    LearningProductBuilderApp.class, CouchbaseConfigurations.class })
@ActiveProfiles("testing")
public abstract class ProducerBase implements CommonUtils {

  /** The port. */
  @LocalServerPort
  protected int port;

  /** The Constant LOCALHOST. */
  protected static final String localhost = "http://localhost";

  /**
   * The asset model handler.
   */
  @MockBean
  public LearningModelHandler learningModelHandler;

  @MockBean
  public ProductService productService;

  /** The repository. */
  @MockBean
  public LearningModelRepository repository;

  /**
   * The product handler.
   */
  @MockBean
  public ProductHandler productHandler;

  /** The product repository. */
  @MockBean
  public ProductRepository productRepository;

  /**
   * The Non Primitive Asset Provisioning HandlerType .
   */
  @MockBean
  public NonPrimitiveAssetHandler nonPrimitiveHandler;

  /** The nonPrimitiveAssetRepository. */
  @MockBean
  public NonPrimitiveAssetRepository nonPrimitiveAssetRepository;

  /** The collector registry. */
  @MockBean
  public CollectorRegistry collectorRegistry;

  /** The taskRepository. */
  @MockBean
  public TaskRepository taskRepository;

  /** The event handler. */
  @MockBean
  private EventService eventService;

  /** The schema validation. */
  @MockBean
  public SchemaValidation schemaValidation;

  /** The validator. */
  @MockBean
  public LearningModelValidator validator;

  /** The statusRepository. */
  @MockBean
  private ProductStatusRepository statusRepository;

  @MockBean
  public TaskHandler longRunningTaskHandler;

  @MockBean
  public ContentRepository contentRepository;

  /** The Constant embeddedKafka. */
  @ClassRule
  public static final KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, 1, "messages");

  /**
   * Before class.
   */
  @BeforeClass
  public static void beforeClass() {
    System.setProperty("spring.kafka.bootstrap-servers", embeddedKafka.getBrokersAsString());
    System.setProperty("spring.cloud.stream.kafka.binder.zkNodes",
        embeddedKafka.getZookeeperConnectionString());

  }

  /**
   * Assert that value is A string.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAString(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.String.class);
    }
  }

  /**
   * Assert that value is A integer.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAInteger(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.Integer.class);
    }
  }

  /**
   * Assert that value is A bool.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsABool(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.Boolean.class);
    }
  }

  /**
   * Assert that value is long.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsLong(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.Long.class);
    }
  }

  /**
   * Assert that value is A map.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAMap(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.util.Map.class);
    }
  }

  /**
   * Assert that value is A list.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAList(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.util.List.class);
    }
  }

  /**
   * Assert that docTypes are LEARNINGCONTENT.
   *
   * @param val
   *          the val
   */
  public void assertThatDocTypesAreLearningContent(JSONArray val) {
    for (Object docType : val) {
      assertThatDocTypeIsLearningContent(docType);
    }
  }

  /**
   * Assert that docType is LEARNINGCONTENT.
   *
   * @param docType
   *          the doc type
   */
  public void assertThatDocTypeIsLearningContent(Object docType) {
    assertEquals(DocType.LEARNINGCONTENT.value(), docType);
  }

  /**
   * Assert that assetTypes are INSTRUCTION.
   *
   * @param val
   *          the val
   */
  public void assertThatAssetTypesAreInstruction(JSONArray val) {
    for (Object assetType : val) {
      assertThatAssetTypeIsInstruction(assetType);
    }
  }

  /**
   * Assert that assetType is INSTRUCTION.
   *
   * @param assetType
   *          the asset type
   */
  public void assertThatAssetTypeIsInstruction(Object assetType) {
    assertEquals(AssetType.INSTRUCTION.value(), assetType);
  }

  /**
   * Assert that assetType is ASSESSMENT.
   *
   * @param assetType
   *          the asset type
   */
  public void assertThatAssetTypeIsAssessment(Object assetType) {
    assertEquals(AssetType.ASSESSMENT.value(), assetType);
  }

  /**
   * Assert that assetType is LEARNINGAPP.
   *
   * @param assetType
   *          the asset type
   */
  public void assertThatAssetTypeIsLearningApp(Object assetType) {
    assertEquals(AssetType.LEARNINGAPP.value(), assetType);
  }
}
