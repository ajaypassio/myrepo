/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import io.restassured.RestAssured;
import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;

import java.util.HashMap;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static org.springframework.http.HttpStatus.OK;

/**
 * The Class ProductAssetTypesGetBase.
 *
 * @author sanket.gupta
 */
public abstract class ProductAssetTypesGetBase extends ProducerBase {

  /** The Constant GET_PRODUCT_ASSET_TYPES_JSON. */
  private static final String GET_PRODUCT_ASSET_TYPES_JSON = "ProductGetAssetTypesResponse.json";

  /**
   * This method is used to mock the methods call of product handler.
   */
  @Before
  public void setUp() throws ServiceException {
    RestAssured.port = this.port;
    RestAssured.baseURI = localhost;

    Mono<ServiceHandlerResponse> serviceHandlerResponse = JsonPayloadServiceResponse.ok()
        .setHeader(HttpHeaders.CONTENT_TYPE, CONTENT_TYPE_HAL).setStatus(OK.value())
        .setPayload(convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON, HashMap.class));
    Mockito.when(productHandler.getProductAssetTypes(Mockito.any()))
        .thenReturn(serviceHandlerResponse);
  }
}