/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import java.util.HashMap;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;

import io.restassured.RestAssured;

/**
 * The Class ProductStatusError400Base.
 * 
 * @author anshul.garg1
 */
public abstract class ProductStatusError400Base extends ProducerBase {

  /** The Constant PRODUCT_STATUS_GET_ERROR_400_JSON. */
  private static final String PRODUCT_STATUS_GET_ERROR_400_JSON = "ProductStatusGetError400.json";

  /**
   * Sets the up.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setUp() throws ServiceException {

    RestAssured.port = this.port;
    RestAssured.baseURI = localhost;
    Mockito.when(productHandler.updateProductStatus(Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.ok().setStatus(HttpStatus.BAD_REQUEST.value())
            .setPayload(convertJsonToObject(PRODUCT_STATUS_GET_ERROR_400_JSON, HashMap.class)));

  }
}
