/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.event.publisher;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.pearson.glp.crosscutting.isc.client.async.service.IscAsyncClient;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.dto.request.ConfigurationCompleteEventPayload;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class EventPublisherTest.
 * 
 * @author lokesh.sharma3
 */
public class EventPublisherTest {

  /** The event publisher. */
  @InjectMocks
  private EventPublisher eventPublisher;

  /** The isc async client. */
  @Mock
  private IscAsyncClient iscAsyncClient;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test publish asnyc event.
   */
  @Test
  public void testPublishAsnycEvent() {
    Mockito.when(iscAsyncClient.publishEventMessage(Mockito.anyString(), Mockito.any()))
        .thenReturn(Mono.just(Boolean.TRUE));
    ConfigurationCompleteEventPayload payload = new ConfigurationCompleteEventPayload();
    Mono<Boolean> publishAsnycEvent = eventPublisher
        .publishAsnycEvent(TestingConstants.CONFIGURATION_COMPLETED, payload);
    StepVerifier.create(publishAsnycEvent)
        .assertNext(res -> Assert.assertEquals(Boolean.TRUE, true)).verifyComplete();
  }
}
