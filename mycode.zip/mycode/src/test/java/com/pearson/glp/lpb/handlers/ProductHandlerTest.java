/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.CMS;
import static com.pearson.glp.lpb.constant.CommonConstants.CONFIGURATION;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.FIELDS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.INITIAL_BSS_VER;
import static com.pearson.glp.lpb.constant.CommonConstants.MESSAGE;
import static com.pearson.glp.lpb.constant.CommonConstants.NON_PRIMITIVE_SCHEMA_JSON;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.RESPONSE_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.RESPONSE_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.V2_SCHEMAS_NONPRIMITIVE_SCHEMA;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATE;
import static com.pearson.glp.lpb.constant.TestingConstants.BASE_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.COMPOSE;
import static com.pearson.glp.lpb.constant.TestingConstants.CONTENTMETADATA_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.ERROR_FETCHING_PRODUCT;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_PRODUCT_BY_ID_AND_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_TASK_URL;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTANCE_FAILED;
import static com.pearson.glp.lpb.constant.TestingConstants.INVALID_PARAM_VALUE;
import static com.pearson.glp.lpb.constant.TestingConstants.ONE_OF;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POLICY;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POST_VERSION_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE_CONTENTMETADATAID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.REVIEW;
import static com.pearson.glp.lpb.constant.TestingConstants.STATE_TRANSITION_PAYLOAD_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants.STATUS_LINK;
import static com.pearson.glp.lpb.constant.TestingConstants.TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.TASK_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.TASK_STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants.VERSION;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import com.pearson.glp.crosscutting.isc.client.commons.exception.ValidationError;
import com.pearson.glp.crosscutting.isc.client.commons.exception.ValidationException;
import com.pearson.glp.lpb.beanvalidation.groups.ClassLevelCheck;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.couchbase.client.core.CouchbaseException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.validation.SchemaValidation;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.ConfigurationCompleteEventEntity;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.ProductStateTransition;
import com.pearson.glp.lpb.data.model.ProductStatus;
import com.pearson.glp.lpb.data.repository.ConfigurationCompleteRepository;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.dto.request.ConfigurationCompleteEventPayload;
import com.pearson.glp.lpb.dto.request.ConfigurationCompleteStatus;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.request.ProductPayload;
import com.pearson.glp.lpb.dto.request.ProductStatusPayload;
import com.pearson.glp.lpb.dto.request.ProductVersionPayload;
import com.pearson.glp.lpb.dto.request.StateTransitionPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.dto.response.ProductAssetResponse;
import com.pearson.glp.lpb.dto.response.ProductCollectionResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.dto.response.ProductScanningResponse;
import com.pearson.glp.lpb.dto.response.ProductsResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.enums.ProductsStatus;
import com.pearson.glp.lpb.services.ProductScannerService;
import com.pearson.glp.lpb.services.ProductService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.IscEventGenerator;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;
import com.pearson.glp.lpb.utils.PrepareJsonNode;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import javax.validation.groups.Default;

/**
 * The Class ProductHandlerTest.
 * 
 * @author kavya.jain
 */
public class ProductHandlerTest implements CommonUtils {

  /** The product handler. */
  @InjectMocks
  private ProductHandler productHandler;

  /** The product repository. */
  @Mock
  private ProductService productService;

  /** The scanner service. */
  @Mock
  private ProductScannerService scannerService;

  /** The service handler context. */
  @Mock
  private ServiceHandlerContext serviceHandlerContext;

  /** The asset repo. */
  @Mock
  private LearningModelRepository assetRepo;

  /** The schemaValidation. */
  @Mock
  private SchemaValidation schemaValidation;

  /** The product id. */
  private Optional<String> productId = Optional.of(ID);

  /** The product tags. */
  private Optional<String> productTags = Optional.of(TAGS);

  /** The assetType tags. */
  private Optional<String> assetType = Optional.of(AGGREGATE);

  /** The product content metadata id. */
  private Optional<String> productContentMetadataId = Optional.of(CONTENTMETADATA_ID);

  /** The isc event generator. */
  @Mock
  private IscEventGenerator iscEventGenerator;

  /** The config repo. */
  @Mock
  private ConfigurationCompleteRepository configRepo;

  /**
   * Before method.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void beforeMethod() throws ServiceException {
    MockitoAnnotations.initMocks(this);

    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
    parameters.add("_id", PRODUCT_ID);

    Mockito.when(serviceHandlerContext.getAllParameters()).thenReturn(parameters);
    Mockito.when(serviceHandlerContext.getOptionalParameter(PRODUCT_ROUTE_CONTENTMETADATAID))
        .thenReturn(productContentMetadataId);
    Mockito.when(serviceHandlerContext.getOptionalParameter(PRODUCT_ROUTE_TAGS))
        .thenReturn(productTags);
    Mockito.when(serviceHandlerContext.getOptionalParameter(CommonConstants.ASSET_TYPE))
        .thenReturn(assetType);
    Mockito.when(serviceHandlerContext.getParameter(PRODUCT_ROUTE_ID)).thenReturn(PRODUCT_ID);
    Mockito.when(serviceHandlerContext.getParameter(VERSION)).thenReturn(PRODUCT_VERSION);
    Mockito.when(serviceHandlerContext.getHeader(CommonConstants.SOURCE))
        .thenReturn(Arrays.asList(CMS));
    StateTransitionPayload payload = convertJsonToObject(STATE_TRANSITION_PAYLOAD_JSON,
        StateTransitionPayload.class);
    Mockito.when(serviceHandlerContext.getPayload(StateTransitionPayload.class))
        .thenReturn(Mono.just(payload));
  }

  /**
   * Test testGetAllProducts.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProducts() throws ServiceException {

    Mockito.when(serviceHandlerContext.getAllParameters()).thenReturn(new LinkedMultiValueMap<>());

    Mockito.when(productService.getAllProducts()).thenReturn(Mono.just(findProductResponse()));

    // When
    Mono<ServiceHandlerResponse> response = productHandler.getProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.OK.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(NonPrimitiveAsset.class));
      StepVerifier.create(productObject.getPayload(NonPrimitiveAsset.class))
          .assertNext(productPayload -> assertNotEquals(0, productPayload)).expectComplete()
          .verify();
    }).verifyComplete();
  }

  /**
   * Test findProductResponse.
   *
   * @return the asset bulk sresponse
   */
  private ProductCollectionResponse findProductCollectionResponse() {
    ProductCollectionResponse productcollectionResponse = new ProductCollectionResponse();
    productcollectionResponse.setCount(1);
    return productcollectionResponse;
  }

  private AssetBulkResponse findProductResponse() {
    AssetBulkResponse assetBulkResponse = new AssetBulkResponse();
    assetBulkResponse.setCount(1);
    return assetBulkResponse;
  }

  /**
   * Find the product by id.
   *
   * @return the product response
   */
  private NonPrimitiveAsset findProductById() {
    NonPrimitiveAsset productResponse = new NonPrimitiveAsset();
    productResponse.set_id(PRODUCT_ID);

    return productResponse;
  }

  /**
   * Find product by ver.
   *
   * @return the product response
   */
  private NonPrimitiveAsset findProductByVer() {
    NonPrimitiveAsset productResponse = new NonPrimitiveAsset();
    productResponse.set_id(PRODUCT_ID);
    productResponse.setVer(PRODUCT_VERSION);
    productResponse.setLinks(new LinkedHashMap<>());
    productResponse.getLinks().put(CommonConstants.STATUS, new Link(STATUS_LINK));
    return productResponse;
  }

  /**
   * Test Find product by id.
   *
   * @throws ServiceException
   *           the ServiceException
   */
  @Test
  public void testFindProductById() throws ServiceException {

    // Given
    NonPrimitiveAsset productResponse = findProductById();
    ProductCollectionResponse productcollectionResponse = findProductCollectionResponse();
    MultiValueMap<String, String> parameters = serviceHandlerContext.getAllParameters();
    Mockito.when(productService.findProductById(PRODUCT_ID)).thenReturn(Mono.just(productResponse));
    Mockito.when(productService.findProductCollectionWithCompleteLA(parameters))
        .thenReturn(Flux.just(productResponse));

    // When
    Mono<ServiceHandlerResponse> response = productHandler.getProductById(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.OK.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(NonPrimitiveAsset.class));
    }).verifyComplete();

    Mockito.when(serviceHandlerContext.getOptionalParameter(PRODUCT_ROUTE_ID))
        .thenReturn(productId);

    // When
    response = productHandler.getProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.OK.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(NonPrimitiveAsset.class));
    }).verifyComplete();
  }

  /**
   * Test Find product by id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductByIdNotFound() throws ServiceException {

    // Given
    Mockito.when(productService.findProductById(PRODUCT_ID)).thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = productHandler.getProductById(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.NOT_FOUND.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(productObject.getPayload(PlatformErrorResponse.class))
          .assertNext(errorPayload -> {
            assertNotNull(errorPayload);
            assertEquals(HttpStatus.NOT_FOUND.value(), errorPayload.getStatus().intValue());
            assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(),
                errorPayload.getError());
          }).expectComplete().verify();
    }).verifyComplete();
  }

  /**
   * Test find product by ver.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductByVer() throws ServiceException {

    // Given
    NonPrimitiveAsset productResponse = findProductByVer();

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(productResponse));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductByIdAndVersion(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.OK.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(NonPrimitiveAsset.class));
    }).verifyComplete();
  }

  /**
   * Test Find product by id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductByVerNotFound() throws ServiceException {

    // Given
    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductByIdAndVersion(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.NOT_FOUND.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(productObject.getPayload(PlatformErrorResponse.class))
          .assertNext(errorPayload -> {
            assertNotNull(errorPayload);
            assertEquals(HttpStatus.NOT_FOUND.value(), errorPayload.getStatus().intValue());
          }).expectComplete().verify();
    }).verifyComplete();
  }

  /**
   * Test create products.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProducts() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));
    Mockito.when(productService.createProductNonPrimitiveAssets(Mockito.any(ProductPayload.class),
        Mockito.any(NonPrimitiveAsset.class), Mockito.any())).thenReturn(createTaskResponse());

    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(Mono.just(assetResponse));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.ACCEPTED.value()))
        .verifyComplete();
  }

  /**
   * Test create products task disable.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductsTaskDisable() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.doReturn(Mono.just(productsPayloadRequest)).when(serviceHandlerContext)
        .getPayload(ProductPayload.class, Default.class, ClassLevelCheck.class);
    PlatformErrorResponse platformErrorResponse = new PlatformErrorResponse();
    platformErrorResponse.setError("error");
    platformErrorResponse.setLink(new Link());
    platformErrorResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
    assetResponse.setError(platformErrorResponse);
    Mockito.doReturn(Mono.just(assetResponse)).when(productService)
        .validateProduct(Mockito.any(ProductPayload.class), Mockito.any());

    ProductAssetResponse productAssetResponse = new ProductAssetResponse(productNonPrimitiveAsset);
    Mockito.doReturn(Mono.just(productAssetResponse)).when(productService)
        .saveProduct(Mockito.any(NonPrimitiveAssetPayload.class), Mockito.any(Asset.class));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);
    // Then
    StepVerifier.create(productsResponse).assertNext(
        response -> assertEquals(response.getStatus(), HttpStatus.INTERNAL_SERVER_ERROR.value()))
        .verifyComplete();
  }

  /**
   * Test get product status.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductStatus() throws ServiceException {
    ProductStatus productStatus = getProductStatus();
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(productStatus));
    Mono<ServiceHandlerResponse> response = productHandler.getProductStatus(serviceHandlerContext);
    StepVerifier.create(response).assertNext(productStatusRes -> {
      assertNotNull(productStatusRes);
    }).verifyComplete();
  }

  /**
   * Gets the product status.
   *
   * @return the product status
   */
  private ProductStatus getProductStatus() {
    ProductStatus productStatus = new ProductStatus();
    productStatus.set_id(UUID.randomUUID().toString());
    productStatus.setLastModified("");
    productStatus.setStatus(REVIEW);
    productStatus.setId(UUID.randomUUID().toString());
    return productStatus;
  }

  /**
   * Test create new products.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNewProducts() throws ServiceException {

    // Given
    ProductVersionPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_VERSION_REQUEST,
        ProductVersionPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductVersionNonPrimitiveAsset(
        productsPayloadRequest, PRODUCT_ID, Integer.valueOf(1), AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductVersionPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.findLatestAssetVersionById(Mockito.any()))
        .thenReturn(Mono.just(productNonPrimitiveAsset));

    Mockito.when(productService.validateProductVersion(Mockito.any(ProductVersionPayload.class),
        Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(assetResponse));

    Mockito.when(productService.createProductVersionNonPrimitiveAssets(
        Mockito.any(ProductVersionPayload.class), Mockito.any(NonPrimitiveAsset.class),
        Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(createTaskResponse());

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .createNewProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.ACCEPTED.value()))
        .verifyComplete();
  }

  /**
   * Creates the product version non primitive asset.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset createProductVersionNonPrimitiveAsset(
      ProductVersionPayload productVersionPayload, String assetId, Integer bssVer,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = prepareAsset(productVersionPayload, bssVer);
    nonPrimitiveAsset.set_id(assetId);
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.addLinks(SELF, this.createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return nonPrimitiveAsset;
  }

  /**
   * Prepare asset.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param bssVer
   *          the bss ver
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset prepareAsset(ProductVersionPayload productVersionPayload,
      Integer bssVer) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productVersionPayload.getAsset());
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    if (!Objects.isNull(productVersionPayload.getUpdateRequest()) && Boolean.TRUE.toString()
        .equals(productVersionPayload.getUpdateRequest().getIsMajorChange())) {
      nonPrimitiveAsset.setBssVer(bssVer + 1);
    } else {
      nonPrimitiveAsset.setBssVer(bssVer);
    }
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productVersionPayload.getAsset());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productVersionPayload.getAsset());
    return nonPrimitiveAsset;
  }

  /**
   * Test create products schema fail.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductsSchemaFail() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(createProductBadErrorResponse());

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.BAD_REQUEST.value()))
        .verifyComplete();
  }

  /**
   * Prepare link.
   *
   * @return the link
   */
  private Link prepareLink() {
    Link link = new Link();
    link.setHref(V2_SCHEMAS_NONPRIMITIVE_SCHEMA);
    return link;
  }

  /**
   * Gets the json node.
   *
   * @return the json node
   */
  private Optional<JsonNode> getJsonNode() {

    ObjectMapper mapper = new ObjectMapper();
    PrepareJsonNode nodeBean = new PrepareJsonNode(INSTANCE_FAILED, ONE_OF);
    JsonNode node = mapper.valueToTree(nodeBean);
    Optional<JsonNode> jsonNode = Optional.of(node);
    return jsonNode;
  }

  /**
   * Test create product with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductWithException() throws ServiceException {
    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);

    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));

    Mockito
        .when(productService.createProductNonPrimitiveAssets(Mockito.any(ProductPayload.class),
            Mockito.any(NonPrimitiveAsset.class), Mockito.any()))
        .thenReturn(createProductTaskErrorResponse());

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse).assertNext(
        response -> assertEquals(response.getStatus(), HttpStatus.INTERNAL_SERVER_ERROR.value()))
        .verifyComplete();
  }

  /**
   * Creates the product non primitive asset.
   *
   * @param productPayload
   *          the product payload
   * @param assetType
   *          the asset type
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset createProductNonPrimitiveAsset(ProductPayload productPayload,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productPayload.getAsset());
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(INITIAL_BSS_VER);
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productPayload.getAsset());
    nonPrimitiveAsset.addLinks(SELF, createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return nonPrimitiveAsset;
  }

  /**
   * Sets the non primitive asset links.
   *
   * @param nonPrimitiveAsset
   *          the new non primitive asset links
   */
  private void setNonPrimitiveAssetLinks(NonPrimitiveAsset nonPrimitiveAsset) {
    nonPrimitiveAsset.getLearningModel().addLinks(SELF,
        createNonPrimitiveAssetSelfLink(ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value(),
            nonPrimitiveAsset.getLearningModel().getId(),
            nonPrimitiveAsset.getLearningModel().getVer()));

    nonPrimitiveAsset.getResources().values().forEach(resource -> {
      String url = AssetType.valueOf(resource.getAssetType()).url();
      resource.addLinks(SELF,
          createNonPrimitiveAssetSelfLink(url, resource.getId(), resource.getVer()));
    });
  }

  /**
   * Creates the non primitive asset self link.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the link
   */
  private Link createNonPrimitiveAssetSelfLink(String url, String id, String ver) {
    Link link = new Link();
    link.setHref(createNonPrimitiveAssetHref(url, id, ver));
    return link;
  }

  /**
   * Creates the non primitive asset href.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  private String createNonPrimitiveAssetHref(String url, String id, String ver) {
    String href = url;
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, ver);
    return href;
  }

  /**
   * Sets the non primitive asset extensions.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param nonPrimitiveAssetPayload
   *          the non primitive asset payload
   */
  private void setNonPrimitiveAssetExtensions(NonPrimitiveAsset nonPrimitiveAsset,
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    if (nonPrimitiveAsset.getExtensions() == null) {
      nonPrimitiveAsset.setExtensions(new Extensions());
    }
    nonPrimitiveAsset.getExtensions().put(CONTENT_METADATA,
        nonPrimitiveAssetPayload.getContentMetadata());
  }

  /**
   * Prepare Product Response.
   *
   * @return the product response
   */
  private Mono<ProductsResponse> createTaskResponse() {

    ProductsResponse productResponse = new ProductsResponse();
    productResponse.set_id(TASK_ID);
    productResponse.setStatus(TASK_STATUS);
    Link _link = new Link(GET_TASK_URL + TASK_ID);
    productResponse.set_link(_link);
    return Mono.just(productResponse);
  }

  /**
   * Creates the product task error response.
   *
   * @return the mono
   */
  private Mono<ProductsResponse> createProductTaskErrorResponse() {
    ProductsResponse response = new ProductsResponse();
    response.setError(
        PlatformErrorUtils.prepareErrorResponse(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue(),
            HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), "task creation failed", null));
    return Mono.just(response);
  }

  /**
   * Creates the product task error response.
   *
   * @return the mono
   */
  private Mono<AssetResponse> createProductBadErrorResponse() {
    AssetResponse response = new AssetResponse();
    response.setError(PlatformErrorUtils.prepareErrorResponse(HttpStatus.BAD_REQUEST.value(),
        HttpStatus.BAD_REQUEST.toString(), HttpStatus.BAD_REQUEST.getReasonPhrase(), null));
    return Mono.just(response);
  }

  /**
   * Test get product versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductVersions() throws ServiceException {

    // Given
    AssetVersionsResponse assetVersionsResponse = getAssetVersionResponse();
    Mockito.when(productService.findProductVersionsById(PRODUCT_ID))
        .thenReturn(Mono.just(assetVersionsResponse));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductVersions(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productVersions -> {
      assertNotNull(productVersions);
      assertEquals(HttpStatus.OK.value(), productVersions.getStatus());
      assertNotNull(productVersions.getPayload(AssetVersionsResponse.class));
      StepVerifier.create(productVersions.getPayload(AssetVersionsResponse.class))
          .assertNext(payload -> {
            assertNotNull(payload);
            assertEquals(payload.getCount(), assetVersionsResponse.getCount());
            assertEquals(payload.getVersions(), assetVersionsResponse.getVersions());
          }).expectComplete().verify();
    }).verifyComplete();
  }

  /**
   * Test update product status.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testUpdateProductStatus() throws ServiceException {

    // Given
    ProductStatusPayload productsPayloadRequest = convertJsonToObject(PRODUCT_STATUS_REQUEST,
        ProductStatusPayload.class);

    NonPrimitiveAsset productNonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);

    ProductStatus statusStored = convertJsonToObject(PRODUCT_STATUS, ProductStatus.class);

    Mockito.when(serviceHandlerContext.getPayload(ProductStatusPayload.class))
        .thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.findLatestAssetById(Mockito.any()))
        .thenReturn(Mono.just(productNonPrimitiveAsset));

    Mockito.when(productService.fetchProductStatus(Mockito.any()))
        .thenReturn(Mono.just(statusStored));

    Mockito.when(productService.saveStatusDocument(productNonPrimitiveAsset, statusStored,
        productsPayloadRequest)).thenReturn(Mono.just(statusStored));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .updateProductStatus(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(statusResponse -> {
      assertNotNull(statusResponse);
      assertEquals(HttpStatus.OK.value(), statusResponse.getStatus());
      assertNotNull(statusResponse.getPayload(ProductStatus.class));
      StepVerifier.create(statusResponse.getPayload(ProductStatus.class)).assertNext(payload -> {
        assertNotNull(payload);
        assertEquals(payload.getStatus(), COMPOSE);
      }).expectComplete().verify();
    }).verifyComplete();
  }

  /**
   * Test update product status exception.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testUpdateProductStatusException() throws Exception {
    // Given
    ProductStatusPayload productsPayloadRequest = convertJsonToObject(PRODUCT_STATUS_REQUEST,
        ProductStatusPayload.class);

    NonPrimitiveAsset productNonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);

    ProductStatus statusStored = convertJsonToObject(PRODUCT_STATUS, ProductStatus.class);

    Mockito.when(serviceHandlerContext.getPayload(ProductStatusPayload.class))
        .thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.findLatestAssetById(Mockito.any()))
        .thenReturn(Mono.just(productNonPrimitiveAsset));

    Mockito.when(productService.fetchProductStatus(Mockito.any()))
        .thenReturn(Mono.just(statusStored));

    Mockito.when(productService.saveStatusDocument(productNonPrimitiveAsset, statusStored,
        productsPayloadRequest)).thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .updateProductStatus(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      verifyInternalServerError(productResponse);
    }).verifyComplete();
  }

  /**
   * Test get product versions not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductVersionsNotFound() throws ServiceException {

    // Given
    Mockito.when(productService.findProductVersionsById(PRODUCT_ID)).thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductVersions(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productVersions -> {
      assertNotNull(productVersions);
      assertEquals(HttpStatus.NOT_FOUND.value(), productVersions.getStatus());
      assertNotNull(productVersions.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(productVersions.getPayload(PlatformErrorResponse.class))
          .assertNext(errorPayload -> {
            assertNotNull(errorPayload);
            assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(),
                errorPayload.getError());
          }).expectComplete().verify();
    }).verifyComplete();
  }

  /**
   * Test get product versions with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductVersionsWithException() throws ServiceException {

    // Given
    Mockito.when(productService.findProductVersionsById(PRODUCT_ID))
        .thenReturn(Mono.error(new ServiceException(ERROR_FETCHING_PRODUCT)));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductVersions(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      verifyInternalServerError(productResponse);
    }).verifyComplete();
  }

  /**
   * Test post product state transition.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testPostProductStateTransition() throws Exception {
    // Given
    NonPrimitiveAsset product = findProductByVer();

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(product));
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(createProductStatus(ProductsStatus.REVIEW.name())));
    ProductStateTransition stateTransitionResponse = new ProductStateTransition();
    Mockito.when(productService.getStateTransitionResponse(Mockito.any(), Mockito.any(),
        Mockito.anyString())).thenReturn(Mono.just(stateTransitionResponse));
    Mockito.when(productService.fetchProductStateTransition(Mockito.anyString()))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .postProductStateTransition(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(HttpStatus.CREATED.value(), productResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Test post product state transition exception.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testPostProductStateTransitionException() throws Exception {
    // Given
    NonPrimitiveAsset product = findProductByVer();

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(product));
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(createProductStatus(ProductsStatus.REVIEW.name())));
    Mockito.when(productService.getStateTransitionResponse(Mockito.any(), Mockito.any(),
        Mockito.anyString())).thenReturn(Mono.error(new Exception()));
    Mockito.when(productService.fetchProductStateTransition(Mockito.anyString()))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .postProductStateTransition(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      verifyInternalServerError(productResponse);
    }).verifyComplete();
  }

  /**
   * Test post product state transition invalid status.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testPostProductStateTransitionInvalidStatus() throws Exception {
    // Given
    NonPrimitiveAsset product = findProductByVer();

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(product));
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(createProductStatus(ProductsStatus.LIVE.name())));

    Mockito.when(productService.getStateTransitionResponse(Mockito.any(), Mockito.any(),
        Mockito.anyString())).thenReturn(Mono.error(new Exception()));
    Mockito.when(productService.fetchProductStateTransition(Mockito.anyString()))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .postProductStateTransition(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(transitionResponse -> {
      assertNotNull(transitionResponse);
      assertEquals(HttpStatus.BAD_REQUEST.value(), transitionResponse.getStatus());
      assertNotNull(transitionResponse.getPayload(PlatformErrorResponse.class));
    }).verifyComplete();
  }

  /**
   * Test post product state transition already live.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testPostProductStateTransitionAlreadyLive() throws Exception {
    // Given
    NonPrimitiveAsset product = findProductByVer();

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(product));
    ProductStateTransition stateTransitionResponse = new ProductStateTransition();
    stateTransitionResponse.setProductId(PRODUCT_ID);
    stateTransitionResponse.setVer(PRODUCT_VERSION);
    Mockito.when(productService.fetchProductStateTransition(Mockito.anyString()))
        .thenReturn(Mono.just(stateTransitionResponse));
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(createProductStatus(ProductsStatus.REVIEW.name())));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .postProductStateTransition(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(transitionResponse -> {
      assertNotNull(transitionResponse);
      assertEquals(HttpStatus.BAD_REQUEST.value(), transitionResponse.getStatus());
      assertNotNull(transitionResponse.getPayload(PlatformErrorResponse.class));
    }).verifyComplete();
  }

  /**
   * Verify internal server error.
   *
   * @param productResponse
   *          the product response
   * @throws AssertionError
   *           the assertion error
   */
  private void verifyInternalServerError(ServiceHandlerResponse productResponse)
      throws AssertionError {
    assertNotNull(productResponse);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), productResponse.getStatus());
    assertNotNull(productResponse.getPayload(PlatformErrorResponse.class));
    StepVerifier.create(productResponse.getPayload(PlatformErrorResponse.class))
        .assertNext(errorPayload -> {
          assertNotNull(errorPayload);
          assertEquals(PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(),
              errorPayload.getError());
        }).expectComplete().verify();
  }

  /**
   * Gets the asset version response.
   *
   * @return the asset version response
   */
  private AssetVersionsResponse getAssetVersionResponse() {
    AssetVersionsResponse assetVersionsResponse = new AssetVersionsResponse();
    assetVersionsResponse.setCount(1);
    Asset asset = new Asset();
    asset.set_id(PRODUCT_ID);
    asset.setVer(UUID.randomUUID().toString());
    asset.setBssVer(BASE_VERSION);
    asset.setId(UUID.randomUUID().toString());
    assetVersionsResponse.setVersions(Arrays.asList(asset));
    return assetVersionsResponse;
  }

  /**
   * Creates the product status.
   *
   * @param status
   *          the status
   * @return the product status
   */
  private ProductStatus createProductStatus(String status) {
    ProductStatus productStatus = new ProductStatus();
    productStatus.setStatus(status);
    return productStatus;
  }

  /**
   * Test create new products with header.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNewProductsWithHeader() throws ServiceException {

    // Given
    ProductVersionPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_VERSION_REQUEST,
        ProductVersionPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductVersionNonPrimitiveAsset(
        productsPayloadRequest, PRODUCT_ID, Integer.valueOf(1), AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductVersionPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));
    Mockito.when(serviceHandlerContext.getHeader(Mockito.any())).thenReturn(Arrays.asList(CMS));

    Mockito.when(productService.findLatestAssetVersionById(Mockito.any()))
        .thenReturn(Mono.just(productNonPrimitiveAsset));

    Mockito.when(productService.validateProductVersion(Mockito.any(ProductVersionPayload.class),
        Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(assetResponse));

    Mockito.when(productService.createProductVersionNonPrimitiveAssets(
        Mockito.any(ProductVersionPayload.class), Mockito.any(NonPrimitiveAsset.class),
        Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(createTaskResponse());

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .createNewProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.ACCEPTED.value()))
        .verifyComplete();
  }

  /**
   * Test create new products with invalid header.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNewProductsWithInvalidHeader() throws ServiceException {

    // Given
    ProductVersionPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_VERSION_REQUEST,
        ProductVersionPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductVersionNonPrimitiveAsset(
        productsPayloadRequest, PRODUCT_ID, Integer.valueOf(1), AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductVersionPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));
    List<String> list = new ArrayList<>();
    list.add(PRODUCT_ID);
    Mockito.when(serviceHandlerContext.getHeader(Mockito.any())).thenReturn(list);
    Mockito.when(productService.findLatestAssetVersionById(Mockito.any()))
        .thenReturn(Mono.just(productNonPrimitiveAsset));

    Mockito.when(productService.validateProductVersion(Mockito.any(ProductVersionPayload.class),
        Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(assetResponse));

    Mockito.when(productService.createProductVersionNonPrimitiveAssets(
        Mockito.any(ProductVersionPayload.class), Mockito.any(NonPrimitiveAsset.class),
        Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(createTaskResponse());

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .createNewProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.ACCEPTED.value()))
        .verifyComplete();
  }

  /**
   * Test create new products with no header.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNewProductsWithNoHeader() throws ServiceException {

    // Given
    ProductVersionPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_VERSION_REQUEST,
        ProductVersionPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductVersionNonPrimitiveAsset(
        productsPayloadRequest, PRODUCT_ID, Integer.valueOf(1), AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    productsPayloadRequest.setAsset(null);
    Mockito.when(serviceHandlerContext.getPayload(ProductVersionPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.error(generateValidationException()));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .createNewProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.BAD_REQUEST.value()))
        .verifyComplete();
  }

  /**
   * Test create products with header.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductsWithHeader() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.createProductNonPrimitiveAssets(Mockito.any(ProductPayload.class),
        Mockito.any(NonPrimitiveAsset.class), Mockito.any())).thenReturn(createTaskResponse());

    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(Mono.just(assetResponse));
    List<String> list = new ArrayList<>();
    list.add(CMS);
    Mockito.when(serviceHandlerContext.getHeader(Mockito.any())).thenReturn(list);

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.ACCEPTED.value()))
        .verifyComplete();
  }

  /**
   * Test create products with invalid header.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductsWithInvalidHeader() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.createProductNonPrimitiveAssets(Mockito.any(ProductPayload.class),
        Mockito.any(NonPrimitiveAsset.class), Mockito.any())).thenReturn(createTaskResponse());

    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(Mono.just(assetResponse));
    Mockito.when(serviceHandlerContext.getHeader(Mockito.any()))
        .thenReturn(Arrays.asList(PRODUCT_ID));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(response.getStatus(), HttpStatus.ACCEPTED.value()))
        .verifyComplete();
  }

  /**
   * Test create products with no header.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductsWithNoHeader() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    productsPayloadRequest.setAsset(null);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.error(generateValidationException()));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus()))
        .verifyComplete();
  }

  /**
   * Test get product status not found.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testGetProductStatusNotFound() throws Exception {

    // Given
    Mockito.when(serviceHandlerContext.getParameter(ID)).thenReturn(PRODUCT_ID);
    Mockito.when(productService.fetchProductStatus(Mockito.any())).thenReturn(Mono.empty());
    // When
    Mono<ServiceHandlerResponse> response = productHandler.getProductStatus(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(HttpStatus.NOT_FOUND.value(), productResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Test get product state transition.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testGetProductStateTransition() throws Exception {

    // Given
    Mockito.when(serviceHandlerContext.getParameter(ID)).thenReturn(PRODUCT_ID);
    Mockito.when(productService.fetchProductStateTransition(Mockito.any()))
        .thenReturn(Mono.just(new ProductStateTransition()));
    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductStateTransition(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(HttpStatus.OK.value(), productResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Test get product state transition not found.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testGetProductStateTransitionNotFound() throws Exception {

    // Given
    Mockito.when(serviceHandlerContext.getParameter(ID)).thenReturn(PRODUCT_ID);
    Mockito.when(productService.fetchProductStateTransition(Mockito.any()))
        .thenReturn(Mono.empty());
    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductStateTransition(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(HttpStatus.NOT_FOUND.value(), productResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Test get product policy.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testGetProductPolicy() throws Exception {

    // Given
    Mockito.when(productService.fetchProductConfiguration(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(getPolicyResponse()));
    Mockito.when(serviceHandlerContext.getOptionalParameter(FIELDS))
        .thenReturn(Optional.of(CONFIGURATION));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductByIdAndVersion(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(configResponse -> {
      assertNotNull(configResponse);
      assertEquals(HttpStatus.OK.value(), configResponse.getStatus());
    }).verifyComplete();

  }

  /**
   * Gets the policy response.
   *
   * @return the policy response
   */
  private ProductConfigurationResponse getPolicyResponse() {
    ProductConfigurationResponse policyResponse = new ProductConfigurationResponse();
    policyResponse.setId(PRODUCT_ID);
    policyResponse.setVer(PRODUCT_VERSION);
    policyResponse.setBssVer(INITIAL_BSS_VER);
    Link link = new Link();
    link.setHref("/v2/products/c875be88-45e3-48dd-b494-a598fbddb2d0/status");
    Links links = new Links();
    links.put(STATUS, link);
    policyResponse.setLinks(links);
    policyResponse.setConfiguration(getConfiguration());

    return policyResponse;
  }

  /**
   * Gets the configuration.
   *
   * @return the configuration
   */
  private Configuration getConfiguration() {
    Configuration configuration = new Configuration();
    ArrayList<String> policyGroups = new ArrayList<>();
    policyGroups.add(PRODUCT_POLICY);
    configuration.put("policyGroups", policyGroups);
    return configuration;
  }

  /**
   * Test get product policy not found.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testGetProductPolicyNotFound() throws Exception {
    Mockito.when(productService.fetchProductConfiguration(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.empty());
    Mockito.when(serviceHandlerContext.getOptionalParameter(FIELDS))
        .thenReturn(Optional.of(CONFIGURATION));

    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductByIdAndVersion(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(configResponse -> {
      assertNotNull(configResponse);
      assertEquals(HttpStatus.NOT_FOUND.value(), configResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Test get product policy invalid parameter value.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testGetProductPolicyInvalidParamValue() throws Exception {

    Mockito.when(serviceHandlerContext.getOptionalParameter(FIELDS))
        .thenReturn(INVALID_PARAM_VALUE);
    // When
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductByIdAndVersion(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(configResponse -> {
      assertNotNull(configResponse);
      assertEquals(HttpStatus.NOT_FOUND.value(), configResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Test get Product Asset Types handler method
   */
  @Test
  public void testGetProductAssetTypes() {
    // given
    serviceHandlerContext.getAllParameters().remove("_id");

    Mockito.when(productService.getProductAssetTypes(Mockito.any(), Mockito.any()))
        .thenReturn(prepareProductAssetClassTypeResponse());

    Mockito.when(productService.findProductByVersion(Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new NonPrimitiveAsset()));

    // when
    Mono<ServiceHandlerResponse> response = productHandler
        .getProductAssetTypes(serviceHandlerContext);

    // then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(HttpStatus.OK.value(), productResponse.getStatus());
    }).verifyComplete();
  }

  /**
   * Prepare Product Asset ClassType Response
   * 
   * @return Mono<ProductAssetClassType>
   */
  public Mono<ProductAssetClassType> prepareProductAssetClassTypeResponse() {
    final String getProductAssetTypeJson = "ProductGetAssetTypesResponse.json";
    ProductAssetClassType productAssetClassType = convertJsonToObject(getProductAssetTypeJson,
        ProductAssetClassType.class);
    return Mono.just(productAssetClassType);
  }

  /**
   * Test CreateProducts With taskDisable True
   * 
   * @throws ServiceException
   */
  @Test
  public void testCreateProductsWithtaskDisableTrue() throws ServiceException {
    final String TASK_DISABLE = "taskDisable";
    boolean taskDisable = (boolean) ReflectionTestUtils.getField(productHandler, TASK_DISABLE);
    if (!taskDisable)
      ReflectionTestUtils.setField(productHandler, TASK_DISABLE, Boolean.TRUE);

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));
    Mockito.when(productService.createProductNonPrimitiveAssets(Mockito.any(ProductPayload.class),
        Mockito.any(NonPrimitiveAsset.class), Mockito.any())).thenReturn(createTaskResponse());

    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(Mono.just(assetResponse));
    ProductAssetResponse productAssetResponse = new ProductAssetResponse(productNonPrimitiveAsset);
    Mockito.doReturn(Mono.just(productAssetResponse)).when(productService)
        .saveProduct(Mockito.any(NonPrimitiveAssetPayload.class), Mockito.any(Asset.class));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(HttpStatus.CREATED.value(), response.getStatus()))
        .verifyComplete();

    if (!taskDisable)
      ReflectionTestUtils.setField(productHandler, TASK_DISABLE, taskDisable);
  }

  @Test
  public void testCreateProductsWithInvalidPayload() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    productsPayloadRequest.setAsset(null);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.error(generateValidationException()));
    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus()))
        .verifyComplete();
  }

  @Test
  public void testCreateProductsWithError() throws ServiceException {
    final String TASK_DISABLE = "taskDisable";
    boolean taskDisable = (boolean) ReflectionTestUtils.getField(productHandler, TASK_DISABLE);
    if (!taskDisable)
      ReflectionTestUtils.setField(productHandler, TASK_DISABLE, Boolean.TRUE);

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    Mockito.when(serviceHandlerContext.getPayload(ProductPayload.class, Default.class,
        ClassLevelCheck.class)).thenReturn(Mono.just(productsPayloadRequest));

    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(Mono.just(assetResponse));
    Mockito.when(productService.saveProduct(Mockito.any(NonPrimitiveAssetPayload.class),
        Mockito.any(Asset.class))).thenReturn(Mono.error(new CouchbaseException()));

    // When
    Mono<ServiceHandlerResponse> productsResponse = productHandler
        .postProduct(serviceHandlerContext);
    // Then
    StepVerifier.create(productsResponse).assertNext(response -> assertNotNull(response))
        .verifyComplete();

    if (!taskDisable) {
      ReflectionTestUtils.setField(productHandler, TASK_DISABLE, taskDisable);
    }
  }

  /**
   * Test get product with response type hal.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductWithResponseTypeHal() throws ServiceException {

    // Given
    MultiValueMap<String, String> parameters = serviceHandlerContext.getAllParameters();
    Mockito.when(productService.findProductCollection(parameters))
        .thenReturn(Mono.just(new ProductCollectionResponse()));
    Mockito.when(serviceHandlerContext.getOptionalParameter(PRODUCT_ROUTE_ID))
        .thenReturn(productId);
    Mockito.when(serviceHandlerContext.getHeader(RESPONSE_TYPE))
        .thenReturn(Arrays.asList(RESPONSE_TYPE_HAL));

    // When
    Mono<ServiceHandlerResponse> response = productHandler.getProduct(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.OK.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(NonPrimitiveAsset.class));
    }).verifyComplete();
  }

  /**
   * Test post config status.
   */
  @Test
  public void testPostConfigStatus() {
    ConfigurationCompleteStatus configStatus = new ConfigurationCompleteStatus();
    Mockito.when(serviceHandlerContext.getParameter(ID)).thenReturn(PRODUCT_ID);
    Mockito.when(serviceHandlerContext.getParameter(VER)).thenReturn(PRODUCT_VERSION);
    Mockito.when(serviceHandlerContext.getPayload(ConfigurationCompleteStatus.class))
        .thenReturn(Mono.just(configStatus));
    Mono<NonPrimitiveAsset> product = Mono
        .just(convertJsonToObject(GET_PRODUCT_BY_ID_AND_VERSION, NonPrimitiveAsset.class));
    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(product);
    ConfigurationCompleteEventEntity details = new ConfigurationCompleteEventEntity();
    Mono<ConfigurationCompleteEventEntity> monoConfig = Mono.just(details);
    Mockito
        .when(iscEventGenerator
            .generateAndPublishEventMessage(Mockito.any(ConfigurationCompleteEventPayload.class)))
        .thenReturn(monoConfig);
    Mockito.when(
        productService.saveConfigCompleteEvent(Mockito.any(ConfigurationCompleteEventEntity.class),
            Mockito.anyString(), Mockito.anyString()))
        .thenReturn(monoConfig);

    Mono<ServiceHandlerResponse> response = productHandler.postConfigStatus(serviceHandlerContext);

    StepVerifier.create(response).assertNext(productObject -> {
      assertNotNull(productObject);
      assertEquals(HttpStatus.CREATED.value(), productObject.getStatus());
      assertNotNull(productObject.getPayload(ConfigurationCompleteEventEntity.class));
    }).verifyComplete();
  }

  /**
   * Test asset type scanning api.
   */
  @Test
  public void testAssetTypeScanningApi() {

    Mockito.when(serviceHandlerContext.getParameter(ID)).thenReturn(PRODUCT_ID);
    Mockito.when(serviceHandlerContext.getParameter(VER)).thenReturn(PRODUCT_VERSION);

    NonPrimitiveAsset productResponse = findProductByVer();
    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(productResponse));

    ProductStatus statusStored = convertJsonToObject(PRODUCT_STATUS, ProductStatus.class);
    statusStored.setStatus(ProductsStatus.SETUP.name());
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(statusStored));
    Mockito.when(scannerService.scanProduct(productResponse)).thenReturn(Mono.just(true));

    Mono<ServiceHandlerResponse> response = productHandler.assetTypeScanning(serviceHandlerContext);

    StepVerifier.create(response).assertNext(scanningResult -> {
      assertNotNull(scanningResult);
      assertEquals(HttpStatus.CREATED.value(), scanningResult.getStatus());
      assertNotNull(scanningResult.getPayload(ProductScanningResponse.class));
    }).verifyComplete();
  }

  /**
   * Test asset type scanning api failure.
   */
  @Test
  public void testAssetTypeScanningApiFailure() {

    Mockito.when(serviceHandlerContext.getParameter(ID)).thenReturn(PRODUCT_ID);
    Mockito.when(serviceHandlerContext.getParameter(VER)).thenReturn(PRODUCT_VERSION);

    NonPrimitiveAsset productResponse = findProductByVer();
    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(productResponse));

    ProductStatus statusStored = convertJsonToObject(PRODUCT_STATUS, ProductStatus.class);
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(statusStored));
    Mockito.when(scannerService.scanProduct(productResponse)).thenReturn(Mono.just(true));

    Mono<ServiceHandlerResponse> response = productHandler.assetTypeScanning(serviceHandlerContext);

    StepVerifier.create(response).assertNext(scanningResult -> {
      assertNotNull(scanningResult);
      assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), scanningResult.getStatus());
      assertNotNull(scanningResult.getPayload(PlatformErrorResponse.class));
    }).verifyComplete();
  }

  /**
   * Generate the Validation Exception
   *
   * @return
   */
  private ValidationException generateValidationException() {
    ValidationError validationError = new ValidationError(HttpStatus.BAD_REQUEST.value(),
        HttpStatus.BAD_REQUEST.toString(), HttpStatus.BAD_REQUEST.getReasonPhrase());
    return new ValidationException(HttpStatus.BAD_REQUEST.value(), validationError);
  }
}
