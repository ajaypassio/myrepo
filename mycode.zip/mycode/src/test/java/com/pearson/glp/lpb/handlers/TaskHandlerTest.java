/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.Task;
import com.pearson.glp.lpb.data.model.TaskResource;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.services.TaskService;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class NonPrimitiveAssetHandlerTest.
 *
 * @author sanket.Gupta
 */
public class TaskHandlerTest implements CommonUtils {

  /** The taskHandler. */
  @InjectMocks
  private TaskHandler taskHandler;

  /** The service handler context. */
  @Mock
  private ServiceHandlerContext serviceHandlerContext;

  /** The taskService. */
  @Mock
  private TaskService taskService;

  /** The task id. */
  private String taskId = null;

  /** The task. */
  private Task task = null;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
    task = new Task();
    taskId = UUID.randomUUID().toString();
    prepareTask(taskId);
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.ID)).thenReturn(taskId);
  }

  /**
   * Test get task by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetTaskById() throws ServiceException {
    // Given
    Mockito.when(taskService.findTaskBy_Id(taskId)).thenReturn(Mono.just(task));

    // When
    Mono<ServiceHandlerResponse> monoResponse = taskHandler.getTaskById(serviceHandlerContext);

    // Then
    StepVerifier.create(monoResponse).assertNext(response -> {
      assertNotNull(response);
      assertEquals(HttpStatus.OK.value(), response.getStatus());
      assertNotNull(response.getPayload(Task.class));
    }).verifyComplete();

  }

  /**
   * Test get task by id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetTaskByIdNotFound() throws ServiceException {
    // Given
    Mockito.when(taskService.findTaskBy_Id(taskId)).thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> monoResponse = taskHandler.getTaskById(serviceHandlerContext);

    // Then
    verifyObjectNotFoundResponse(monoResponse);

  }

  /**
   * Gets the task by id with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void GetTaskByIdWithException() throws ServiceException {
    // Given
    Mockito.when(taskService.findTaskBy_Id(taskId)).thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> monoResponse = taskHandler.getTaskById(serviceHandlerContext);

    // Then
    verifyInternalServerErrorResponse(monoResponse);
  }

  /**
   * Prepare task.
   *
   * @param taskId
   *          the task id
   */
  private void prepareTask(String taskId) {
    Task task = new Task();
    task.setId(UUID.randomUUID().toString());
    task.setStatus(TestingConstants.RUNNING_STATUS);
    task.setLinks(prepareLinks(TestingConstants.TASK_BYID_ROUTE, taskId, ""));
    TaskResource resource = new TaskResource();
    String resourceId = UUID.randomUUID().toString();
    String resourceVer = UUID.randomUUID().toString();
    resource.setId(resourceId);
    resource.setBssVer(1);
    resource.setVer(resourceVer);
    Links links = prepareLinks(TestingConstants.GET_PRODUCT_BY_VERSION_URL, resourceId,
        resourceVer);
    resource.setLinks(links);
    List<TaskResource> resources = new ArrayList<>();
    resources.add(resource);
    task.setResources(resources);
  }

  /**
   * Prepare links.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the links
   */
  private Links prepareLinks(String url, String id, String version) {
    Links links = new Links();
    Link link = new Link();
    url = url.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    url = url.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, version);
    link.setHref(url);
    links.put(SELF, link);
    return links;
  }

  /**
   * Verify object not found response.
   *
   * @param response
   *          the response
   */
  private void verifyObjectNotFoundResponse(Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.NOT_FOUND.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Verify internal server error response.
   *
   * @param response
   *          the response
   */
  private void verifyInternalServerErrorResponse(Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

}
