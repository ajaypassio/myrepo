/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.routes;

import static com.pearson.glp.lpb.constant.TestingConstants.LIVE;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.enums.Routes;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

/**
 * The Class NonPrimitiveAssetRoutesTest.
 *
 * @author sanket.Gupta
 */
public class InvalidMethodTypeRoutesTest extends BaseRouteTest {

  /**
   * Test Put Invalid Method Type.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testPutValidRoute() throws ServiceException {
    webTestClient.put().uri(contextPath + Routes.INSTRUCTIONS_ROUTE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
  }

  /**
   * Test Delete Invalid Method Type.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testDeleteValidRoute() throws ServiceException {
    webTestClient.delete().uri(contextPath + Routes.INSTRUCTIONS_ROUTE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
  }

  /**
   * Test Delete Invalid Method Type with invalid route .
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testDeleteInValidRoute() throws ServiceException {
    webTestClient.delete().uri(contextPath + Routes.INSTRUCTIONS_ROUTE + LIVE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.NOT_FOUND);
  }

}