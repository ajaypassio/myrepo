/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATES_QUERY_PARAMS;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATES_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATES_VERSION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATE_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATE_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.AGGREGATE_POST_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.AND;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSESSMENT_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSESSMENT_POST_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.EMBEDDED_ASSETS_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.EMBEDDED_ASSETS_POST_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.EMBEDDED_ASSETS_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.EQUALS;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_ASSESSMENT_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_INSTRUCTION_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_LEARNINGAPPS_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTIONS_QUERY_PARAMS;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_VERSION_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_VERSION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.INVALID_AGGREGATES_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.LEARNINGAPP_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.LEARNINGAPP_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.LEARNINGAPP_POST_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.LEARNINGAPP_VER;
import static com.pearson.glp.lpb.constant.TestingConstants.PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.TestingConstants.PAGE_SIZE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE_CONTENTMETADATAID;
import static com.pearson.glp.lpb.constant.TestingConstants.QUESTION_MARK;
import static com.pearson.glp.lpb.constant.TestingConstants.VERSIONS;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSESSMENT_POST_REQUEST;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.pearson.glp.lpb.constant.TestingConstants;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.request.AssetVersionPayload;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.Routes;
import com.pearson.glp.lpb.utils.CommonUtils;

import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class NonPrimitiveAssetRoutesTest.
 *
 * @author sanket.Gupta
 */
public class NonPrimitiveAssetRoutesTest extends BaseRouteTest implements CommonUtils {
  /**
   * Test the Instruction Bulk Post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkInstructionsPost() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(INSTRUCTION_POST_RESPONSE));

    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_REQUEST, NonPrimitiveAssetPayload.class);

    List<AssetResponse> assetResponses = webTestClient.post()
        .uri(contextPath + Routes.INSTRUCTIONS_ROUTE).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(nonPrimitiveAssetRequest), NonPrimitiveAssetPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetResponse.class).returnResult()
        .getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test the Instruction Bulk Post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkAssessmentPost() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(ASSESSMENT_POST_RESPONSE));

    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(ASSESSMENT_POST_REQUEST,
        NonPrimitiveAssetPayload.class);

    List<AssetResponse> assetResponses = webTestClient.post()
        .uri(contextPath + Routes.ASSESSMENTS_ROUTE).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(nonPrimitiveAssetRequest)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetResponse.class).returnResult()
        .getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test the Aggregates Bulk Post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkAggregatesPost() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(AGGREGATE_POST_RESPONSE));

    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(AGGREGATE_POST_REQUEST,
        NonPrimitiveAssetPayload.class);

    List<AssetResponse> assetResponses = webTestClient.post().uri(contextPath + AGGREGATES_ROUTE)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .syncBody(nonPrimitiveAssetRequest).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetResponse.class)
        .returnResult().getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test bulk embedded asset post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkEmbeddedAssetPost() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(EMBEDDED_ASSETS_POST_RESPONSE));

    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        EMBEDDED_ASSETS_POST_REQUEST, NonPrimitiveAssetPayload.class);

    List<AssetResponse> assetResponses = webTestClient.post()
        .uri(contextPath + EMBEDDED_ASSETS_ROUTE).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(nonPrimitiveAssetRequest)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetResponse.class).returnResult()
        .getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test bulk embedded asset post 5 xx.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkEmbeddedAssetPost5xx() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenThrow(new ServiceException(""));
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = new NonPrimitiveAssetPayload();
    List<AssetResponse> assetResponses = webTestClient.post()
        .uri(contextPath + EMBEDDED_ASSETS_ROUTE).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(nonPrimitiveAssetRequest)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR).expectBodyList(AssetResponse.class)
        .returnResult().getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNull(response.getAsset());
      Assert.assertNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test the Assessments Bulk Post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkAssessmentsPost() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(ASSESSMENT_POST_RESPONSE));

    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(AGGREGATE_POST_REQUEST,
        NonPrimitiveAssetPayload.class);

    List<AssetResponse> assetResponses = webTestClient.post().uri(contextPath + AGGREGATES_ROUTE)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .syncBody(nonPrimitiveAssetRequest).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetResponse.class)
        .returnResult().getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test the LearningApp Bulk Post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testBulkLearningAppsPost() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(LEARNINGAPP_POST_RESPONSE));

    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        LEARNINGAPP_POST_REQUEST, NonPrimitiveAssetPayload.class);

    List<AssetResponse> assetResponses = webTestClient.post()
        .uri(contextPath + Routes.LEARNINGAPPS_ROUTE).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(nonPrimitiveAssetRequest)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetResponse.class).returnResult()
        .getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test get instruction by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetInstructionById() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getNonPrimitiveAsset(AssetType.INSTRUCTION)));

    webTestClient.get().uri(this.contextPath + GET_INSTRUCTION_ROUTE + INSTRUCTION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get all instruction.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllInstruction() throws ServiceException {
    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 1, 0, 1))
        .thenReturn(Mono.just(prepareAssetBulkResponse()));

    webTestClient.get()
        .uri(this.contextPath + INSTRUCTIONS_QUERY_PARAMS + PAGE_SIZE + EQUALS + 2 + AND
            + PAGE_NUMBER + EQUALS + 2)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus();
  }

  /**
   * Test get all instruction.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllInstructionNegative() throws ServiceException {
    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 1, 0, 1))
        .thenReturn(Mono.just(prepareAssetBulkResponse()));

    webTestClient.get()
        .uri(this.contextPath + INSTRUCTIONS_QUERY_PARAMS + PAGE_SIZE + EQUALS + "-2" + AND
            + PAGE_NUMBER + EQUALS + 2)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test get all instruction.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  @Ignore
  public void testGetAllInstructionWithoutQueryParameters() throws ServiceException {
    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 1, 0, 1))
        .thenReturn(Mono.just(prepareAssetBulkResponse()));

    webTestClient.get().uri(this.contextPath + Routes.INSTRUCTIONS_ROUTE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test get all instruction with Exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllInstructionWithException() throws ServiceException {
    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 1, 0, 1))
        .thenReturn(Mono.error(new ServiceException(AssetType.INSTRUCTION.value())));

    webTestClient.get()
        .uri(this.contextPath + INSTRUCTIONS_QUERY_PARAMS + PAGE_SIZE + EQUALS + 2 + AND
            + PAGE_NUMBER + EQUALS + 2)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus();
  }

  /**
   * Test get all instruction Version.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllInstructionVersions() throws ServiceException {

    Mockito
        .when(nonPrimitiveAssetService.findAllAssetVersions(INSTRUCTION_ID, AssetType.INSTRUCTION))
        .thenReturn(Mono.just(prepareAssetVersionsResponse()));

    String url = this.contextPath + GET_INSTRUCTION_ROUTE + INSTRUCTION_ID + VERSIONS;

    webTestClient.get().uri(url).accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(AssetVersionsResponse.class);
  }

  /**
   * Test get all instruction version with Exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllInstructionVersionsWithException() throws ServiceException {
    Mockito
        .when(nonPrimitiveAssetService.findAllAssetVersions(INSTRUCTION_ID, AssetType.INSTRUCTION))
        .thenReturn(Mono.error(new ServiceException(AssetType.INSTRUCTION.value())));

    String url = this.contextPath + GET_INSTRUCTION_ROUTE + INSTRUCTION_ID + VERSIONS;

    webTestClient.get().uri(url).accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .is5xxServerError().expectBody(AssetVersionsResponse.class);
  }

  /**
   * Test get all aggregates.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAggregates() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.AGGREGATE.value(), 1, 0, 1))
        .thenReturn(Mono.just(prepareAssetBulkResponse()));

    webTestClient
        .get().uri(this.contextPath + AGGREGATES_QUERY_PARAMS + PAGE_SIZE + EQUALS + 2 + AND
            + PAGE_NUMBER + EQUALS + 2)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus();
  }

  /**
   * Test get all aggregates with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAggregatesWithException() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.AGGREGATE.value(), 1, 0, 1))
        .thenReturn(Mono.error(new ServiceException(AssetType.AGGREGATE.value())));

    webTestClient
        .get().uri(this.contextPath + AGGREGATES_QUERY_PARAMS + PAGE_SIZE + EQUALS + 1 + AND
            + PAGE_NUMBER + EQUALS + 2)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus();
  }

  /**
   * Test get all aggregate versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAggregateVersions() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.findAllAssetVersions(AGGREGATE_ID, AssetType.AGGREGATE))
        .thenReturn(Mono.just(prepareAssetVersionsResponse()));

    String url = this.contextPath + AGGREGATES_ROUTE + AGGREGATE_ID + VERSIONS;

    webTestClient.get().uri(url).accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(AssetVersionsResponse.class);
  }

  /**
   * Test get all aggregate versions with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAggregateVersionsWithException() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.findAllAssetVersions(AGGREGATE_ID, AssetType.AGGREGATE))
        .thenReturn(Mono.error(new ServiceException(AssetType.AGGREGATE.value())));

    String url = this.contextPath + AGGREGATES_ROUTE + AGGREGATE_ID + VERSIONS;

    webTestClient.get().uri(url).accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .is5xxServerError().expectBody(AssetVersionsResponse.class);
  }

  /**
   * Test get instruction by id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetInstructionsByIdNotFound() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());

    webTestClient.get().uri(this.contextPath + GET_INSTRUCTION_ROUTE + INSTRUCTION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(NonPrimitiveAssetPayload.class);
  }

  /**
   * Test get instruction by id with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetInstructionsByIdWithException() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.error(new ServiceException(INSTRUCTION_ID)));

    webTestClient.get().uri(this.contextPath + GET_INSTRUCTION_ROUTE + INSTRUCTION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is5xxServerError()
        .expectBody(NonPrimitiveAssetPayload.class);
  }

  /**
   * Test the Get Aggregate By Id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAggregatesById() throws ServiceException {
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset(AssetType.AGGREGATE);

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(nonPrimitiveAsset));

    webTestClient.get().uri(this.contextPath + AGGREGATES_ROUTE + AGGREGATE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAssetPayload.class);
  }

  /**
   * Test get aggregates by id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAggregatesByIdNotFound() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());

    webTestClient.get().uri(this.contextPath + AGGREGATES_ROUTE + INVALID_AGGREGATES_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(NonPrimitiveAssetPayload.class);
  }

  /**
   * Test get aggregates by id with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAggregatesByIdWithException() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.error(new ServiceException(INVALID_AGGREGATES_ID)));

    webTestClient.get().uri(this.contextPath + AGGREGATES_ROUTE + INVALID_AGGREGATES_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is5xxServerError()
        .expectBody(NonPrimitiveAssetPayload.class);
  }

  /**
   * Test Create Instruction Version.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateInstructionVersion() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any()))
        .thenReturn(Mono.just(prepareAsset()));
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(INSTRUCTION_POST_RESPONSE, AssetResponse.class)));
    String url = Routes.INSTRUCTIONS_VERSIONS_ROUTE.value()
        .replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());

    // Then
    List<AssetResponse> assetResponses = webTestClient.post().uri(contextPath + url)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .syncBody(nonPrimitiveAssetRequest).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isCreated().expectBodyList(AssetResponse.class).returnResult()
        .getResponseBody();
    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test Create Instruction Version Not Found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateInstructionVersionNotFound() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);

    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any())).thenReturn(Mono.empty());
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(INSTRUCTION_POST_RESPONSE, AssetResponse.class)));
    String url = Routes.INSTRUCTIONS_VERSIONS_ROUTE.value()
        .replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());

    // Then
    webTestClient.post().uri(contextPath + url).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).syncBody(nonPrimitiveAssetRequest)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound();
  }

  /**
   * Test Create Aggregate Version.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAggregateVersion() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        AGGREGATES_VERSION_POST_REQUEST, AssetVersionPayload.class);

    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any()))
        .thenReturn(Mono.just(prepareAsset()));
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(AGGREGATE_POST_RESPONSE, AssetResponse.class)));
    String url = Routes.AGGREGATES_VERSIONS_ROUTE.value().replace(
        OPEN_PARANTHESIS + CommonConstants.ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());

    // Then
    List<AssetResponse> assetResponses = webTestClient.post().uri(contextPath + url)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .syncBody(nonPrimitiveAssetRequest).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isCreated().expectBodyList(AssetResponse.class).returnResult()
        .getResponseBody();

    assetResponses.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test Create Aggregate Version Not Found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAggregateVersionNotFound() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        AGGREGATES_VERSION_POST_REQUEST, AssetVersionPayload.class);

    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any())).thenReturn(Mono.empty());
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(AGGREGATE_POST_RESPONSE, AssetResponse.class)));
    String url = Routes.AGGREGATES_VERSIONS_ROUTE.value().replace(
        OPEN_PARANTHESIS + CommonConstants.ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());
    // Then
    webTestClient.post().uri(contextPath + url).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(nonPrimitiveAssetRequest)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound();
  }

  /**
   * Test get instruction by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetInstructionByVersionId() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getNonPrimitiveAsset(AssetType.INSTRUCTION)));

    webTestClient.get()
        .uri(this.contextPath + INSTRUCTION_ROUTE + INSTRUCTION_ID + VERSIONS
            + INSTRUCTION_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get instruction by version id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetInstructionByVersionIdNotFound() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + INSTRUCTION_ROUTE + INSTRUCTION_ID + VERSIONS
            + INSTRUCTION_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get aggregate by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAggregateByVersionId() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getNonPrimitiveAsset(AssetType.AGGREGATE)));

    webTestClient.get()
        .uri(this.contextPath + AGGREGATES_ROUTE + AGGREGATE_ID + VERSIONS + AGGREGATE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get aggregate by version id not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAggregateByVersionIdNotFound() throws ServiceException {

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + AGGREGATES_ROUTE + AGGREGATE_ID + VERSIONS + AGGREGATE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Gets the non primitive asset response.
   *
   * @param assetType
   *          the asset type
   * @return the Non Primitive Asset response
   */
  private NonPrimitiveAsset getNonPrimitiveAsset(AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setLabel(ASSET_MODEL_LABEL);
    nonPrimitiveAsset.setTags(ASSET_MODEL_TAGS);
    nonPrimitiveAsset.setAssetType(assetType.value());
    return nonPrimitiveAsset;
  }

  /**
   * Prepare asset.
   *
   * @return the non primitive asset
   */
  private NonPrimitiveAsset prepareAsset() {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(1);
    return nonPrimitiveAsset;
  }

  /**
   * Prepare Asset Bulk Response.
   *
   * @return the asset response
   */
  private AssetBulkResponse prepareAssetBulkResponse() {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(1);
    AssetBulkResponse assetBulkResponse = new AssetBulkResponse();
    assetBulkResponse.setCount(1);
    assetBulkResponse.setAssets(Arrays.asList(nonPrimitiveAsset));
    return assetBulkResponse;
  }

  /**
   * Prepare Asset Version Response.
   *
   * @return the asset response
   */
  private AssetVersionsResponse prepareAssetVersionsResponse() {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(1);
    AssetVersionsResponse assetVersionsResponse = new AssetVersionsResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setVersions(Arrays.asList(nonPrimitiveAsset));
    return assetVersionsResponse;
  }

  /**
   * Generate the Flux of Asset Response.
   *
   * @param jsonPath
   *          the json path
   * @return the flux asset response
   * @throws ServiceException
   *           the service exception
   */
  private Flux<AssetResponse> getFluxAssetResponse(String jsonPath) throws ServiceException {
    AssetResponse assetResponse = convertJsonToObject(jsonPath, AssetResponse.class);
    return Flux.just(assetResponse);
  }

  /**
   * Test get Assessment by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssessmentById() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getNonPrimitiveAsset(AssetType.ASSESSMENT)));

    webTestClient.get().uri(this.contextPath + GET_ASSESSMENT_ROUTE + ASSESSMENT_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get learning app by id and version.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetLearningAppByIdAndVersion() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getNonPrimitiveAsset(AssetType.LEARNINGAPP)));

    webTestClient.get()
        .uri(
            this.contextPath + GET_LEARNINGAPPS_ROUTE + LEARNINGAPP_ID + VERSIONS + LEARNINGAPP_VER)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get learning app by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetLearningAppById() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getNonPrimitiveAsset(AssetType.LEARNINGAPP)));

    webTestClient.get().uri(this.contextPath + GET_LEARNINGAPPS_ROUTE + LEARNINGAPP_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(NonPrimitiveAsset.class);
  }

  /**
   * Test get assessments.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssessments() throws ServiceException {
    Mockito.when(nonPrimitiveAssetService.getAllAssessment(Mockito.any(), Mockito.anyInt(),
        Mockito.anyInt())).thenReturn(Mono.just(prepareAssetBulkResponse()));

    webTestClient.get()
        .uri(this.contextPath + GET_ASSESSMENT_ROUTE + QUESTION_MARK
            + PRODUCT_ROUTE_CONTENTMETADATAID + EQUALS + ASSESSMENT_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test Create assessment Version.
   */
  @Test
  public void testCreateAssessmentVersion() {
    // Given
    AssetVersionPayload assetVersionPayload = convertJsonToObject(
        TestingConstants.ASSESSMENTS_VERSION_POST_REQUEST, AssetVersionPayload.class);

    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(prepareAsset()));
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(TestingConstants.ASSESSMENT_VERSION_POST_RESPONSE,
            AssetResponse.class)));
    String url = Routes.ASSESSMENTS_ROUTE_VERSION.value()
        .replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());

    // Then
    List<AssetResponse> assetResponse = webTestClient.post().uri(contextPath + url)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .syncBody(assetVersionPayload).exchange().expectStatus().isCreated()
        .expectBodyList(AssetResponse.class).returnResult().getResponseBody();

    assetResponse.forEach(response -> {
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNull(response.getError());
    });
  }

  /**
   * Test Create assessment Version not found.
   */
  @Test
  public void testCreateAssessmentVersionNotFound() {
    // Given
    AssetVersionPayload assetVersionPayload = convertJsonToObject(
        TestingConstants.ASSESSMENTS_VERSION_POST_REQUEST, AssetVersionPayload.class);

    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(TestingConstants.ASSESSMENT_VERSION_POST_RESPONSE,
            AssetResponse.class)));
    String url = Routes.ASSESSMENTS_ROUTE_VERSION.value()
        .replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());

    // Then
    webTestClient.post().uri(contextPath + url).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(assetVersionPayload).exchange()
        .expectStatus().isNotFound();

  }

  /**
   * Test Create assessment Version with exception.
   */
  @Test
  public void testCreateAssessmentVersionWithException() {
    // Given
    AssetVersionPayload assetVersionPayload = convertJsonToObject(
        TestingConstants.ASSESSMENTS_VERSION_POST_REQUEST, AssetVersionPayload.class);

    // When
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.error(new ServiceException("")));
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(convertJsonToObject(TestingConstants.ASSESSMENT_VERSION_POST_RESPONSE,
            AssetResponse.class)));
    String url = Routes.ASSESSMENTS_ROUTE_VERSION.value()
        .replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, UUID.randomUUID().toString());

    // Then
    webTestClient.post().uri(contextPath + url).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON).syncBody(assetVersionPayload).exchange()
        .expectStatus().is5xxServerError();

  }

}