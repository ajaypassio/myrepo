/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.CONTENTMETADATA;
import static com.pearson.glp.lpb.constant.TestingConstants.EMBEDDED_ASSETS_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_DOCUMENT_INVALID__ASSETTYPE;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_DOCUMENT_INVALID__DOCTYPE;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_ERROR_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_VERSION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.TWO;
import static com.pearson.glp.lpb.utils.CommonUtilsTest.getUuid;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import rx.Observable;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.repository.util.ReactiveWrapperConverters;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;

import com.couchbase.client.core.CouchbaseException;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.repository.ContentRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.dto.request.AssetVersionPayload;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.services.impl.NonPrimitiveAssetServiceImpl;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PaginationUtil;
import com.pearson.glp.lpb.validator.EmbeddedAssetValidator;
import com.pearson.glp.lpb.validator.LearningModelValidator;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.Tuple2;

// TODO: Auto-generated Javadoc
/**
 * The Class NonPrimitiveAssetServiceImplTest.
 *
 * @author sanket.Gupta
 */

public class NonPrimitiveAssetServiceImplTest implements CommonUtils {

  /** The nonPrimitiveAssetService. */
  @InjectMocks
  private NonPrimitiveAssetServiceImpl nonPrimitiveAssetService;

  /** The nonPrimitiveAssetRepository. */
  @Mock
  private NonPrimitiveAssetRepository nonPrimitiveAssetRepository;

  /** The nonPrimitiveAssetRepository. */
  @Mock
  private ContentRepository contentRepository;

  @Mock
  private EmbeddedAssetValidator embeddedAssetValidator;

  /** The validator. */
  @Mock
  private LearningModelValidator modelValidator;

  @Mock
  private EventService eventService;

  @Mock
  private PaginationUtil paginationUtil;

  public NonPrimitiveAssetServiceImplTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
    Mockito.when(modelValidator.validateLearningAssetWithLearningModel(Mockito.any()))
        .thenReturn(Mono.empty());
    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    Mockito.when(
        eventService.publishEventMessage(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(iscResponse);
    Mockito.when(paginationUtil.preparePageSize(Mockito.anyString())).thenReturn("2");
    Mockito.when(paginationUtil.preparePageNumber(Mockito.anyString())).thenReturn("2");
  }

  /**
   * Test the Create Instructions. Also handles the positive case for incoming
   * request from CMS
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssets() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_REQUEST, NonPrimitiveAssetPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenReturn(getMonoNonPrimitiveAsset(AssetType.INSTRUCTION));

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getAsset().getVer());
      Assert.assertNotNull(response.getAsset().getBssVer());
      Assert.assertNotNull(response.getAsset().getDocType());
      Assert.assertNotNull(response.getAsset().getAssetType());
      Assert.assertNotNull(response.getAsset().get_id());
      Assert.assertNotNull(response.getAsset().getLinks());
      Assert.assertNull(response.getError());
      return true;
    }).verifyComplete();
    // When
    Flux<AssetResponse> assetResponseWithNull = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayloadWithNull(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponseWithNull).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getAsset().getVer());
      Assert.assertNotNull(response.getAsset().getBssVer());
      Assert.assertNotNull(response.getAsset().getDocType());
      Assert.assertNotNull(response.getAsset().getAssetType());
      Assert.assertNotNull(response.getAsset().get_id());
      Assert.assertNotNull(response.getAsset().getLinks());
      Assert.assertNull(response.getError());
      return true;
    }).verifyComplete();

  }

  @Test
  public void testCreateEmbeddedAssets() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        EMBEDDED_ASSETS_POST_REQUEST, NonPrimitiveAssetPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenReturn(getMonoNonPrimitiveAsset(AssetType.AGGREGATE));

    Mockito.when(embeddedAssetValidator.validateEmbeddedAsset(Mockito.any(NonPrimitiveAsset.class),
        Mockito.any(ContentMetadata.class))).thenReturn(Mono.empty().cast(AssetResponse.class));

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.AGGREGATE);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getAsset().getVer());
      Assert.assertNotNull(response.getAsset().getBssVer());
      Assert.assertNotNull(response.getAsset().getDocType());
      Assert.assertNotNull(response.getAsset().getAssetType());
      Assert.assertNotNull(response.getAsset().get_id());
      Assert.assertNotNull(response.getAsset().getLinks());
      Assert.assertNull(response.getError());
      return true;
    }).verifyComplete();

  }

  /**
   * Test create non primitive asset with CMS failure.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetWithCMSFailure() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_REQUEST, NonPrimitiveAssetPayload.class);
    nonPrimitiveAssetRequest.getValidationResult().setFailureFlag(Boolean.TRUE);

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();

    Mockito.when(contentRepository.fetchAllAssessments(Mockito.anyString()))
        .thenReturn(ReactiveWrapperConverters.toWrapper(Observable.just(null), Mono.class));
    nonPrimitiveAssetRequest.setAssetType(AssetType.ASSESSMENT.value());
    assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.ASSESSMENT);

    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();

    Mockito.when(contentRepository.fetchAllAssessments(Mockito.anyString())).thenReturn(Mono.just(
        "::_id::1bad6823-defb-40c4-a71f-cbb69d40b185::_ver::2345300c-6482-4b5f-90bc-8171b1da5f1c"));
    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();

    // When
    nonPrimitiveAssetRequest.setAssetType(AssetType.LEARNINGAPP.value());
    assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.LEARNINGAPP);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();

  }

  /**
   * Test the Create NonPrimitiveAsset with Exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetWithException() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_ERROR_REQUEST, NonPrimitiveAssetPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenThrow(new CouchbaseException());

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();
  }

  /**
   * Creates the instruction.
   *
   * @param instructionID
   *          the asset model id
   * @return instruction
   */
  private NonPrimitiveAsset createInstructionResponse(String instructionID) {
    NonPrimitiveAsset instruction = new NonPrimitiveAsset();
    instruction.set_id(instructionID);
    instruction.setVer(INSTRUCTION_VERSION);
    instruction.setCreated(formatDateTime(LocalDateTime.now()).get());
    instruction.setExpiresOn(formatDateTime(LocalDateTime.now()).get());
    instruction.setLabel(ASSET_MODEL_LABEL);
    instruction.setTags(ASSET_MODEL_TAGS);
    return instruction;
  }

  /**
   * Generate the Mono of Non Primitive Asset.
   *
   * @param jsonPath
   *          the json path
   * @return the mono non primitive asset
   * @throws ServiceException
   *           the service exception
   */
  private Mono<NonPrimitiveAsset> getMonoNonPrimitiveAsset(String jsonPath)
      throws ServiceException {
    NonPrimitiveAssetPayload assetPayload = convertJsonToObject(jsonPath,
        NonPrimitiveAssetPayload.class);
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(assetPayload);
    nonPrimitiveAsset.setVer(assetPayload.getVer());
    nonPrimitiveAsset.setBssVer(assetPayload.getBssVer());
    nonPrimitiveAsset.set_id(assetPayload.get_id());
    nonPrimitiveAsset.setAssetType(assetPayload.getAssetType());
    nonPrimitiveAsset.setDocType(assetPayload.getDocType());
    nonPrimitiveAsset.setLinks(assetPayload.getLinks());
    nonPrimitiveAsset.getExtensions().put(CONTENTMETADATA, assetPayload.getContentMetadata());
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    return Mono.just(nonPrimitiveAsset);
  }

  /**
   * Generate the Mono of Non Primitive Asset.
   *
   * @return the mono non primitive asset
   * @throws ServiceException
   *           the service exception
   */
  private Mono<NonPrimitiveAsset> getMonoNonPrimitiveAsset(AssetType assetType)
      throws ServiceException {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(getUuid());
    nonPrimitiveAsset.setVer(getUuid());
    nonPrimitiveAsset.setVer(getUuid());
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.setBssVer(1);
    nonPrimitiveAsset.addLinks(SELF, new Link());
    nonPrimitiveAsset.setExtensions(new Extensions());
    ContentMetadata contentMetadata = new ContentMetadata();
    contentMetadata.setId(getUuid());
    contentMetadata.setVersion(getUuid());
    nonPrimitiveAsset.getExtensions().put(CONTENT_METADATA, contentMetadata);
    return Mono.just(nonPrimitiveAsset);
  }

  /**
   * Test create asset version. Also handles the case for incoming request from
   * CMS.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetVersion() throws ServiceException {
    // Given
    String assetId = getUuid();
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenReturn(getMonoNonPrimitiveAsset(INSTRUCTION_POST_JSON));

    // When
    Mono<AssetResponse> assetResponse = nonPrimitiveAssetService
        .createAssetVersion(nonPrimitiveAssetRequest, assetId, 1, AssetType.INSTRUCTION);

    // Then
    verifyAssetResponse(assetResponse);

    // When
    nonPrimitiveAssetRequest.getUpdateRequest().setIsMajorChange(Boolean.FALSE.toString());
    assetResponse = nonPrimitiveAssetService.createAssetVersion(nonPrimitiveAssetRequest, assetId,
        1, AssetType.INSTRUCTION);

    // Then
    verifyAssetResponse(assetResponse);

    // When
    nonPrimitiveAssetRequest.setUpdateRequest(null);
    assetResponse = nonPrimitiveAssetService.createAssetVersion(nonPrimitiveAssetRequest, assetId,
        1, AssetType.INSTRUCTION);

    // Then
    verifyAssetResponse(assetResponse);

    // When
    assetResponse = nonPrimitiveAssetService.createAssetVersion(nonPrimitiveAssetRequest, assetId,
        1, AssetType.INSTRUCTION);

    // Then
    verifyAssetResponse(assetResponse);

    // When
    nonPrimitiveAssetRequest.getAsset().setLearningModel(null);
    nonPrimitiveAssetRequest.getAsset().setResources(null);
    assetResponse = nonPrimitiveAssetService.createAssetVersion(nonPrimitiveAssetRequest, assetId,
        1, AssetType.INSTRUCTION);

    // Then
    verifyAssetResponse(assetResponse);

  }

  /**
   * Verify asset response.
   *
   * @param assetResponse
   *          the asset response
   */
  private void verifyAssetResponse(Mono<AssetResponse> assetResponse) {
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getAsset().getVer());
      Assert.assertNotNull(response.getAsset().getBssVer());
      Assert.assertNotNull(response.getAsset().getDocType());
      Assert.assertNotNull(response.getAsset().getAssetType());
      Assert.assertNotNull(response.getAsset().get_id());
      Assert.assertNotNull(response.getAsset().getLinks());
      Assert.assertNull(response.getError());
      return true;
    }).verifyComplete();
  }

  /**
   * Test create asset version with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetVersionWithException() throws ServiceException {
    // Given
    String assetId = getUuid();
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenReturn(Mono.error(new CouchbaseException()));

    // When
    Mono<AssetResponse> assetResponse = nonPrimitiveAssetService
        .createAssetVersion(nonPrimitiveAssetRequest, assetId, 1, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getError());
      Assert.assertNotNull(response.getError().getMessage());
      Assert.assertNotNull(response.getError().getError());
      Assert.assertNotNull(response.getError().getStatus());
      Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(),
          response.getError().getStatus().intValue());
      Assert.assertNull(response.getAsset());
      return true;
    }).verifyComplete();
  }

  /**
   * Test create non primitive asset invalid doc type exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetInvalidDocTypeException() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_DOCUMENT_INVALID__DOCTYPE, NonPrimitiveAssetPayload.class);

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();
  }

  /**
   * Test create non primitive asset invalid asset type exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetInvalidAssetTypeException() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_DOCUMENT_INVALID__ASSETTYPE, NonPrimitiveAssetPayload.class);

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();
  }

  /**
   * Creates the nonPrimitive asset model.
   *
   * @param instructionId
   *          the instruction Id
   * @param isinstructionId
   *          the is instruction Id
   * @return the nonPrimitive asset model
   */
  private NonPrimitiveAsset createNonPrimitiveAsset(String instructionId, boolean isinstructionId) {
    NonPrimitiveAsset instructionModel = new NonPrimitiveAsset();
    if (isinstructionId) {
      instructionModel.set_id(instructionId);
    } else {
      instructionModel.set_id(getUuid());
    }
    instructionModel.setBssVer(1);
    instructionModel.setVer(getUuid());
    instructionModel.setCreated(formatDateTime(LocalDateTime.now()).get());
    instructionModel.setExpiresOn(formatDateTime(LocalDateTime.now()).get());
    instructionModel.setLabel(ASSET_MODEL_LABEL);
    instructionModel.setTags(ASSET_MODEL_TAGS);
    return instructionModel;
  }

  /**
   * Creates the non primitive asset.
   *
   * @param noOfAssetModels
   *          the no of asset models
   * @param instructionId
   *          the instruction id
   * @param isInstructionId
   *          the is instruction id
   * @return the list
   */
  private List<NonPrimitiveAsset> createNonPrimitiveAsset(int noOfAssetModels, String instructionId,
      boolean isInstructionId) {
    List<NonPrimitiveAsset> nonPrimitiveAssetList = new ArrayList<>();
    for (int i = 0; i < noOfAssetModels; i++) {
      nonPrimitiveAssetList.add(createNonPrimitiveAsset(instructionId, isInstructionId));
    }
    return nonPrimitiveAssetList;
  }

  /**
   * Test find all instruction models.
   */
  @Test
  public void testFindAllInstructionModels() {
    // Given
    List<NonPrimitiveAsset> nonPrimitiveAssets = getInstructionModels();
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setAssets(new ArrayList<>(nonPrimitiveAssets));
    Flux<NonPrimitiveAsset> assetModelFlux = Flux.fromIterable(nonPrimitiveAssets);

    Mockito.when(nonPrimitiveAssetRepository.findAllAssetsWithLatestDoc(Mockito.anyInt(),
        Mockito.anyInt(), Mockito.anyString())).thenReturn(assetModelFlux);

    // When
    Mono<AssetBulkResponse> assetModelList = nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 5, 0, 1);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      log.info("Response: {}", response.getAssets() + "");
      log.info("AssetModel: {}", nonPrimitiveAssets);
      assertNotNull(response);
      assertEquals(nonPrimitiveAssets.size(), response.getAssets().size());
      verifyAssetBulkResponse(nonPrimitiveAssets.get(0), response);
    }).verifyComplete();
  }

  /**
   * Test find all instruction models.
   */
  @Test
  public void testFindAllInstructionModelWithHrefLink() {
    // Given
    List<NonPrimitiveAsset> nonPrimitiveAssets = getInstructionModels();
    nonPrimitiveAssets.addAll(getInstructionModels());
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setAssets(new ArrayList<>(nonPrimitiveAssets));
    Flux<NonPrimitiveAsset> assetModelFlux = Flux.fromIterable(nonPrimitiveAssets);

    Mockito.when(nonPrimitiveAssetRepository.findAllAssetsWithLatestDoc(Mockito.anyInt(),
        Mockito.anyInt(), Mockito.anyString())).thenReturn(assetModelFlux);

    // When
    Mono<AssetBulkResponse> assetModelList = nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 1, 0, 1);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      log.info("Response: {}", response.getAssets() + "");
      log.info("AssetModel: {}", nonPrimitiveAssets);
      assertNotNull(response);
      assertEquals(nonPrimitiveAssets.size() - 1, response.getAssets().size());
      verifyAssetBulkResponse(nonPrimitiveAssets.get(0), response);
    }).verifyComplete();
  }

  /**
   * Test find all Aggregate models.
   */
  @Test
  public void testFindAllAggregateModelWithHrefLink() {
    // Given
    List<NonPrimitiveAsset> nonPrimitiveAssets = getInstructionModels();
    nonPrimitiveAssets.addAll(getInstructionModels());
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setAssets(new ArrayList<>(nonPrimitiveAssets));
    Flux<NonPrimitiveAsset> assetModelFlux = Flux.fromIterable(nonPrimitiveAssets);

    Mockito.when(nonPrimitiveAssetRepository.findAllAssetsWithLatestDoc(Mockito.anyInt(),
        Mockito.anyInt(), Mockito.anyString())).thenReturn(assetModelFlux);

    // When
    Mono<AssetBulkResponse> assetModelList = nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.AGGREGATE.value(), 1, 0, 1);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      log.info("Response: {}", response.getAssets() + "");
      log.info("AssetModel: {}", nonPrimitiveAssets);
      assertNotNull(response);
      assertEquals(nonPrimitiveAssets.size() - 1, response.getAssets().size());
      verifyAssetBulkResponse(nonPrimitiveAssets.get(0), response);
    }).verifyComplete();
  }

  /**
   * Test find all Assessment models.
   */
  @Test
  public void testFindAllAssessmentModelWithHrefLink() {
    // Given
    List<NonPrimitiveAsset> nonPrimitiveAssets = getInstructionModels();
    nonPrimitiveAssets.addAll(getInstructionModels());
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setAssets(new ArrayList<>(nonPrimitiveAssets));
    Flux<NonPrimitiveAsset> assetModelFlux = Flux.fromIterable(nonPrimitiveAssets);

    Mockito.when(nonPrimitiveAssetRepository.findAllAssetsWithLatestDoc(Mockito.anyInt(),
        Mockito.anyInt(), Mockito.anyString())).thenReturn(assetModelFlux);

    // When
    Mono<AssetBulkResponse> assetModelList = nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.ASSESSMENT.value(), 1, 0, 1);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      log.info("Response: {}", response.getAssets() + "");
      log.info("AssetModel: {}", nonPrimitiveAssets);
      assertNotNull(response);
      assertEquals(nonPrimitiveAssets.size() - 1, response.getAssets().size());
      verifyAssetBulkResponse(nonPrimitiveAssets.get(0), response);
    }).verifyComplete();
  }

  /**
   * Verify asset bulk response.
   *
   * @param assetModel
   *          the asset model
   * @param assetBulkResponse
   *          the asset bulk response
   */
  private void verifyAssetBulkResponse(NonPrimitiveAsset assetModel,
      AssetBulkResponse assetBulkResponse) {

    Asset assetVersion = assetBulkResponse.getAssets().get(0);
    assertEquals(assetModel.get_id(), assetVersion.get_id());
    assertEquals(assetModel.getBssVer(), assetVersion.getBssVer());
    assertEquals(assetModel.getVer(), assetVersion.getVer());
    assertEquals(assetModel.getDocType(), assetVersion.getDocType());
    assertEquals(assetModel.getAssetType(), assetVersion.getAssetType());
    assertEquals(assetModel.getDocType(), assetVersion.getDocType());

  }

  /**
   * Gets the instruction models.
   * 
   * @return the instruction models
   */
  private List<NonPrimitiveAsset> getInstructionModels() {
    List<NonPrimitiveAsset> assetList = new ArrayList<>();
    assetList.add(createAssetModel());
    return assetList;
  }

  /**
   * Create Asset.
   * 
   * @return the non primitive asset
   */
  private NonPrimitiveAsset createAssetModel() {
    NonPrimitiveAsset asset = new NonPrimitiveAsset();
    asset.set_id(getUuid());
    asset.setBssVer(1);
    String versionId = getUuid();
    asset.setVer(versionId);
    asset.setDocType(DocType.LEARNINGCONTENT.value());
    LinkedHashMap<String, Link> links = new LinkedHashMap<>();
    Link link = new Link();
    link.setHref("href: \"/v2/instructions/" + asset.get_id() + "/versions/" + versionId);
    links.put("self", link);
    asset.setLinks(links);

    return asset;
  }

  /**
   * Tests method findAllVersions in nonPrimitiveAssetServiceImpl.
   */
  @Test
  public void testFindAllVersions() {
    // Given
    final String instructionId = "instructionId";
    List<NonPrimitiveAsset> nonPrimitiveAssetList = createNonPrimitiveAsset(1, instructionId, true);
    Flux<NonPrimitiveAsset> nonPrimitiveAssetFlux = Flux.fromIterable(nonPrimitiveAssetList);

    // When
    Mockito.when(nonPrimitiveAssetRepository.findAssets(Mockito.anyString()))
        .thenReturn(nonPrimitiveAssetFlux);

    Mono<AssetVersionsResponse> assetVersionResponse = nonPrimitiveAssetService
        .findAllAssetVersions(instructionId, AssetType.INSTRUCTION);

    // verify
    StepVerifier.create(assetVersionResponse).assertNext(response -> {
      assertNotNull(response);
      assertEquals(nonPrimitiveAssetList.size(), response.getVersions().size());
      verifyAssetVersionsResponse(nonPrimitiveAssetList.get(0), response);
    }).verifyComplete();
  }

  /**
   * Verify asset response.
   *
   * @param asset
   *          the asset
   * @param assetVersionResponse
   *          the asset model response
   */
  private void verifyAssetVersionsResponse(NonPrimitiveAsset asset,
      AssetVersionsResponse assetVersionResponse) {
    Asset assetVersion = assetVersionResponse.getVersions().get(0);
    assertEquals(asset.get_id(), assetVersion.get_id());
    assertEquals(asset.getBssVer(), assetVersion.getBssVer());
    assertEquals(asset.getVer(), assetVersion.getVer());
    assertEquals(asset.getDocType(), assetVersion.getDocType());
    assertEquals(asset.getAssetType(), assetVersion.getAssetType());
    assertEquals(asset.getDocType(), assetVersion.getDocType());

  }

  /**
   * Test create asset version for null resources.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  @Ignore
  public void testCreateAssetVersionForNullResources() throws ServiceException {

    // Given
    String assetId = getUuid();
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);

    nonPrimitiveAssetRequest.getAsset().setResources(null);

    // When
    Mono<AssetResponse> assetResponseForResources = nonPrimitiveAssetService
        .createAssetVersion(nonPrimitiveAssetRequest, assetId, 1, AssetType.INSTRUCTION);

    // then
    StepVerifier.create(assetResponseForResources).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getError());
      return true;
    }).verifyComplete();

  }

  /**
   * Test find non primitive asset by id.
   */
  @Test
  public void testFindNonPrimitiveAssetById() {
    // Given
    Mockito.when(nonPrimitiveAssetRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(createInstructionResponse(INSTRUCTION_ID)));

    // When
    Mono<NonPrimitiveAsset> instructionMono = nonPrimitiveAssetService.findById(INSTRUCTION_ID);

    // Then
    StepVerifier.create(instructionMono).assertNext(resp -> {
      assertNotNull(resp);
    }).verifyComplete();

  }

  /**
   * Test find all instruction model.
   */
  @Test
  public void testFindAllInstructionModel() {
    // Given
    List<NonPrimitiveAsset> nonPrimitiveAssets = getInstructionModels();
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(4);
    assetVersionsResponse.setAssets(new ArrayList<>(nonPrimitiveAssets));
    Flux<NonPrimitiveAsset> assetModelFlux = Flux.fromIterable(nonPrimitiveAssets);

    Mockito.when(nonPrimitiveAssetRepository.findAllAssetsWithLatestDoc(Mockito.anyInt(),
        Mockito.anyInt(), Mockito.anyString())).thenReturn(assetModelFlux);

    // When
    Mono<AssetBulkResponse> assetModelList = nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 5, 1, 2);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(nonPrimitiveAssets.size(), response.getAssets().size());
      verifyAssetBulkResponse(nonPrimitiveAssets.get(0), response);
    }).verifyComplete();
  }

  /**
   * Test find all aggregate model.
   */
  @Test
  public void testFindAllAggregateModel() {
    // Given
    List<NonPrimitiveAsset> nonPrimitiveAssets = getInstructionModels();
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setAssets(new ArrayList<>(nonPrimitiveAssets));
    Flux<NonPrimitiveAsset> assetModelFlux = Flux.fromIterable(nonPrimitiveAssets);

    Mockito.when(nonPrimitiveAssetRepository.findAllAssetsWithLatestDoc(Mockito.anyInt(),
        Mockito.anyInt(), Mockito.anyString())).thenReturn(assetModelFlux);

    // When
    Mono<AssetBulkResponse> assetModelList = nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.AGGREGATE.value(), 1, 1, 4);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(nonPrimitiveAssets.size(), response.getAssets().size());
      verifyAssetBulkResponse(nonPrimitiveAssets.get(0), response);
    }).verifyComplete();
  }

  /**
   * Test create non primitive assets with event enabled.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetsWithEventEnabled() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_REQUEST, NonPrimitiveAssetPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenReturn(getMonoNonPrimitiveAsset(AssetType.INSTRUCTION));
    ReflectionTestUtils.setField(nonPrimitiveAssetService, "eventEnabled", Boolean.TRUE);

    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getAsset().getVer());
      Assert.assertNotNull(response.getAsset().getBssVer());
      Assert.assertNotNull(response.getAsset().getDocType());
      Assert.assertNotNull(response.getAsset().getAssetType());
      Assert.assertNotNull(response.getAsset().get_id());
      Assert.assertNotNull(response.getAsset().getLinks());
      Assert.assertNull(response.getError());
      return true;
    }).verifyComplete();

    nonPrimitiveAssetRequest.getValidationResult().setFailureFlag(Boolean.TRUE);

    assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      verifyErrorResponse(response);
      return true;
    }).verifyComplete();

  }

  /**
   * Test create non primitive assets with validation enabled.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetsWithValidationEnabled() throws ServiceException {
    // Given
    NonPrimitiveAssetPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_REQUEST, NonPrimitiveAssetPayload.class);
    Mockito.when(nonPrimitiveAssetRepository.save(Mockito.any()))
        .thenReturn(getMonoNonPrimitiveAsset(AssetType.INSTRUCTION));
    ReflectionTestUtils.setField(nonPrimitiveAssetService, "validationEnabled", true);
    // When
    Flux<AssetResponse> assetResponse = nonPrimitiveAssetService.createNonPrimitiveAssets(
        getNonPrimitiveAssetPayload(nonPrimitiveAssetRequest), AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(assetResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response.getContentMetadata());
      Assert.assertNotNull(response.getContentMetadata().getId());
      Assert.assertNotNull(response.getContentMetadata().getVersion());
      Assert.assertNotNull(response.getAsset());
      Assert.assertNotNull(response.getAsset().getVer());
      Assert.assertNotNull(response.getAsset().getBssVer());
      Assert.assertNotNull(response.getAsset().getDocType());
      Assert.assertNotNull(response.getAsset().getAssetType());
      Assert.assertNotNull(response.getAsset().get_id());
      Assert.assertNotNull(response.getAsset().getLinks());
      Assert.assertNull(response.getError());
      return true;
    }).verifyComplete();
  }

  /**
   * Verify error response.
   *
   * @param response
   *          the response
   */
  private void verifyErrorResponse(AssetResponse response) {
    Assert.assertNotNull(response.getContentMetadata());
    Assert.assertNotNull(response.getContentMetadata().getId());
    Assert.assertNotNull(response.getContentMetadata().getVersion());
    Assert.assertNotNull(response.getError());
    Assert.assertNotNull(response.getError().getMessage());
    Assert.assertNotNull(response.getError().getError());
    Assert.assertNotNull(response.getError().getStatus());
    Assert.assertNull(response.getAsset());
  }

  /**
   * Test get all assessment with parameter.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAssessmentWithParameter() throws ServiceException {
    LinkedMultiValueMap<String, String> linkedMultiValueMap = new LinkedMultiValueMap<String, String>();
    linkedMultiValueMap.add(TestingConstants.CONTENTMETADATA, TestingConstants.ASSESSMENT_ID);
    linkedMultiValueMap.add(TestingConstants.PAGE_NUMBER, TWO);
    linkedMultiValueMap.add(TestingConstants.PAGE_SIZE, TWO);

    NonPrimitiveAsset nonPrimitiveAssets = createAssetModel();
    AssetBulkResponse assetVersionsResponse = new AssetBulkResponse();
    assetVersionsResponse.setCount(1);
    assetVersionsResponse.setAssets(Arrays.asList(nonPrimitiveAssets));
    Mockito.when(paginationUtil.getLimit(Mockito.anyString())).thenReturn(2);
    Mockito.when(paginationUtil.getOffset(Mockito.anyString())).thenReturn(2);
    Mockito.when(nonPrimitiveAssetRepository.findAssetByParameters(Mockito.any()))
        .thenReturn(Flux.just(nonPrimitiveAssets));
    Mockito.when(nonPrimitiveAssetRepository.countAllLatestLearningAsset(Mockito.any()))
        .thenReturn(Mono.just(1));

    Mono<AssetBulkResponse> product = nonPrimitiveAssetService.getAllAssessment(linkedMultiValueMap,
        1, 1);

    StepVerifier.create(product).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(assetVersionsResponse.getCount(), resp.getCount());
    }).verifyComplete();

  }

  /**
   * Generate Non Primitive Asset Payload
   *
   * @param nonPrimitiveAssetPayload
   * @return
   */
  private Flux<Tuple2<NonPrimitiveAssetPayload, List<String>>> getNonPrimitiveAssetPayload(
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    List<String> errors = new ArrayList<>();
    return Flux.just(nonPrimitiveAssetPayload).zipWith(Flux.just(errors));
  }

  /**
   * Generate Non Primitive Asset Payload
   *
   * @param nonPrimitiveAssetPayload
   * @return
   */
  private Flux<Tuple2<NonPrimitiveAssetPayload, List<String>>> getNonPrimitiveAssetPayloadWithNull(
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    List<String> errors = new ArrayList<>();
    return Flux.just(nonPrimitiveAssetPayload).zipWith(Flux.empty());
  }

}
