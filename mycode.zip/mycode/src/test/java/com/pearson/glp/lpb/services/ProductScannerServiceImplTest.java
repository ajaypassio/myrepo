/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ASSESSMENT_ITEM_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ASSESSMENT_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_GET_ASSET_TYPE_RESONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_INDEX_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_INSTRCUTION_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_NARRATIVE_JSON;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.data.repository.ProductAssetClassTypeRepository;
import com.pearson.glp.lpb.data.repository.ProductRepository;
import com.pearson.glp.lpb.enums.EventType;
import com.pearson.glp.lpb.services.impl.ProductScannerServiceImpl;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class ProductScannerServiceImplTest.
 * 
 * @author jeevansingh.dhami
 */
public class ProductScannerServiceImplTest implements CommonUtils {

  /** The validator. */
  @InjectMocks
  private ProductScannerServiceImpl scanner;

  /** The repository. */
  @Mock
  private NonPrimitiveAssetRepository repository;

  /** The product repository. */
  @Mock
  private ProductRepository productRepository;

  /** The isc sync client. */
  @Mock
  private IscSyncClient iscSyncClient;

  /** The assetClassTypeRepository. */
  @Mock
  private ProductAssetClassTypeRepository assetClassTypeRepository;

  /** The event service. */
  @Mock
  private EventService eventService;

  /** The aggregate payload. */
  private NonPrimitiveAsset aggregate;

  /** The narrative payload. */
  private NonPrimitiveAsset narrative;

  /** The assessmentItem payload. */
  private NonPrimitiveAsset assessmentItem;

  /** The instruction payload. */
  private NonPrimitiveAsset instruction;

  /** The assessment payload. */
  private NonPrimitiveAsset assessment;

  /** The product. */
  private NonPrimitiveAsset product;

  /** The asset class type. */
  private ProductAssetClassType assetClassType;

  /**
   * Sets the up.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setUp() throws ServiceException {
    MockitoAnnotations.initMocks(this);
    aggregate = convertJsonToObject(PRODUCT_INDEX_JSON, NonPrimitiveAsset.class);
    narrative = convertJsonToObject(PRODUCT_NARRATIVE_JSON, NonPrimitiveAsset.class);
    assessmentItem = convertJsonToObject(PRODUCT_ASSESSMENT_ITEM_JSON, NonPrimitiveAsset.class);
    instruction = convertJsonToObject(PRODUCT_INSTRCUTION_JSON, NonPrimitiveAsset.class);
    assessment = convertJsonToObject(PRODUCT_ASSESSMENT_JSON, NonPrimitiveAsset.class);
    product = convertJsonToObject(PRODUCT_JSON, NonPrimitiveAsset.class);
    assetClassType = convertJsonToObject(PRODUCT_GET_ASSET_TYPE_RESONSE,
        ProductAssetClassType.class);
  }

  /**
   * Test scan product resources.
   */
  @Test
  public void testScanProductResources() {

    Mockito.when(productRepository.findById(Mockito.anyString())).thenReturn(Mono.just(product));
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(aggregate))
        .thenReturn(Mono.just(instruction)).thenReturn(Mono.just(assessment));
    Mockito.when(
        iscSyncClient.getObject(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(narrative)).thenReturn(Mono.just(assessmentItem));
    Mockito.when(assetClassTypeRepository.save(Mockito.any(ProductAssetClassType.class)))
        .thenReturn(Mono.just(assetClassType));
    Mockito.when(eventService.publishEventMessage(EventType.PRODUCT_READY_FOR_CONFIGURATION.value(),
        product)).thenReturn(Mono.just(true));
    Mono<Boolean> respone = scanner.scanProduct(product);

    StepVerifier.create(respone).expectNextMatches(res -> {
      assertEquals(Boolean.TRUE, res);
      return true;
    }).verifyComplete();

  }

  /**
   * Test scan product resources error while fetching from DB.
   */
  @Test
  public void testScanProductResourcesErrorFetchingFromDB() {

    Mockito.when(productRepository.findById(Mockito.anyString())).thenReturn(Mono.just(product));
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.error(new Exception()));
    Mockito.when(eventService.publishEventMessage(EventType.PRODUCT_READY_FOR_CONFIGURATION.value(),
        product)).thenReturn(Mono.just(true));
    Mono<Boolean> response = scanner.scanProduct(product);

    StepVerifier.create(response).verifyError();
  }

  /**
   * Test scan product resources error while fetching from LAP.
   */
  @Test
  public void testScanProductResourcesErrorFetchingFromLAP() {

    Mockito.when(productRepository.findById(Mockito.anyString())).thenReturn(Mono.just(product));
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(aggregate))
        .thenReturn(Mono.just(instruction)).thenReturn(Mono.just(assessment));
    Mockito.when(
        iscSyncClient.getObject(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException("error")));
    Mono<Boolean> response = scanner.scanProduct(product);

    StepVerifier.create(response).verifyError();
  }

}