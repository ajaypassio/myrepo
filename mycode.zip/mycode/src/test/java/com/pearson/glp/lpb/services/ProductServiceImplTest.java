/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.INITIAL_BSS_VER;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.POLICY_GROUPS;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCTIZATION;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.TITLE;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSETCLASSTYPES;
import static com.pearson.glp.lpb.constant.TestingConstants.COMPOSE;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_PRODUCT_ASSET_TYPES_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_TASK_URL;
import static com.pearson.glp.lpb.constant.TestingConstants.OLD_PRODUCT_STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_DOCUMENT_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_DOCUMENT_VERSION_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_GET_ASSET_TYPE_RESONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POLICY;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POST_VERSION_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS_REVIEW_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS_SETUP;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.REVIEW;
import static com.pearson.glp.lpb.constant.TestingConstants.STATE_TRANSITION_PAYLOAD_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.TASK_STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants._STATUS;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.couchbase.client.core.CouchbaseException;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Extends;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.ProductStateTransition;
import com.pearson.glp.lpb.data.model.ProductStatus;
import com.pearson.glp.lpb.data.model.Productization;
import com.pearson.glp.lpb.data.model.Task;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.data.repository.PMPMessageRepository;
import com.pearson.glp.lpb.data.repository.ProductAssetClassTypeRepository;
import com.pearson.glp.lpb.data.repository.ProductRepository;
import com.pearson.glp.lpb.data.repository.ProductStateTransitionRepository;
import com.pearson.glp.lpb.data.repository.ProductStatusRepository;
import com.pearson.glp.lpb.data.repository.TaskRepository;
import com.pearson.glp.lpb.dto.event.request.AutobahnEvent;
import com.pearson.glp.lpb.dto.event.request.AutobahnEventModel;
import com.pearson.glp.lpb.dto.event.request.AutobahnPayLoad;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.request.ProductPayload;
import com.pearson.glp.lpb.dto.request.ProductStatusPayload;
import com.pearson.glp.lpb.dto.request.ProductVersionPayload;
import com.pearson.glp.lpb.dto.request.StateTransitionPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.ProductAssetResponse;
import com.pearson.glp.lpb.dto.response.ProductCollectionResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.dto.response.ProductsResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.ProductsStatus;
import com.pearson.glp.lpb.enums.TaskStatus;
import com.pearson.glp.lpb.services.impl.ProductScannerServiceImpl;
import com.pearson.glp.lpb.services.impl.ProductServiceImpl;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.validator.LearningModelValidator;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class ProductServiceImplTest.
 */
public class ProductServiceImplTest implements CommonUtils {

  /** The constant ONE. */
  private static final Integer ONE = Integer.valueOf(1);

  /** The product service. */
  @InjectMocks
  private ProductServiceImpl productService;

  /** The product repository. */
  @Mock
  private ProductRepository productRepository;

  /** The validator. */
  @Mock
  private LearningModelValidator modelValidator;

  /** The TaskRepository. */
  @Mock
  private TaskRepository taskRepository;

  /** The EventHandler. */
  @Mock
  private EventService eventService;

  /** The nonPrimitiveAssetRepository. */
  @Mock
  private NonPrimitiveAssetRepository nonPrimitiveAssetRepository;

  /** The asset repo. */
  @Mock
  private LearningModelRepository assetRepo;

  /** The statusRepository. */
  @Mock
  private ProductStatusRepository statusRepository;

  /** The statusRepository. */
  @Mock
  private PMPMessageRepository pmpMessageRepository;

  /** The state repository. */
  @Mock
  private ProductStateTransitionRepository stateRepository;

  /** The asset class type repo. */
  @Mock
  private ProductAssetClassTypeRepository assetClassTypeRepo;

  /** The scanner service. */
  @Mock
  private ProductScannerServiceImpl scannerService;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);

    ProductStatus status = new ProductStatus();
    String lastModified = formatDateTime(LocalDateTime.now()).get();
    status.setLastModified(lastModified);
    Mockito.when(statusRepository.save(Mockito.any())).thenReturn(Mono.just(status));
    Mockito.when(statusRepository.findById(Mockito.anyString())).thenReturn(Mono.just(status));
    ReflectionTestUtils.setField(productService, "configHome", "config");
  }

  /**
   * Test Get All Product.
   *
   * @throws ServiceException
   *           the ServiceException
   */
  @Test
  public void testGetAllProducts() throws ServiceException {

    NonPrimitiveAsset productResponse = getProductResponse();
    AssetBulkResponse assetBulkResponse = new AssetBulkResponse(ONE,
        Arrays.asList(getAsset(productResponse)));

    Mockito.when(productRepository.findByAssetType(Mockito.anyString()))
        .thenReturn(Flux.just(productResponse));

    Mono<AssetBulkResponse> product = productService.getAllProducts();

    StepVerifier.create(product).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(assetBulkResponse.getCount(), resp.getCount());
    }).verifyComplete();
  }

  /**
   * Test Get Product Asset Types.
   *
   * @throws ServiceException
   *           the ServiceException
   */
  @Test
  public void testGetProductAssetTypes() throws ServiceException {

    ProductAssetClassType productAssetClassType = convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON,
        ProductAssetClassType.class);

    Mockito.when(assetClassTypeRepo.findById(Mockito.anyString()))
        .thenReturn(Mono.just(productAssetClassType));

    Mono<ProductAssetClassType> productAssetClassTypeMono = productService
        .getProductAssetTypes(PRODUCT_ID, PRODUCT_VERSION);

    StepVerifier.create(productAssetClassTypeMono).assertNext(assetClassType -> {
      assertNotNull(assetClassType);
      assertEquals(assetClassType.get_id(), productAssetClassType.get_id());
    }).verifyComplete();
  }

  /**
   * Gets the product response.
   *
   * @return the product response
   */
  private NonPrimitiveAsset getProductResponse() {
    NonPrimitiveAsset productResponse = new NonPrimitiveAsset();
    productResponse.set_id(PRODUCT_ID);
    productResponse.setTags(TAGS);
    productResponse.setVer(UUID.randomUUID().toString());
    return productResponse;
  }

  /**
   * Gets the product response query parameter.
   *
   * @return the product response query parameter
   */
  private AssetBulkResponse getProductResponseQueryParameter() {
    AssetBulkResponse productResponse = new AssetBulkResponse();
    productResponse.setAssets(new ArrayList<>());
    productResponse.setCount(1);
    return productResponse;
  }

  /**
   * Test Find product by Id.
   *
   * @throws ServiceException
   *           the ServiceException
   */
  // @Test
  public void testFindProductById() throws ServiceException {

    NonPrimitiveAsset productResponse = getProductResponse();

    Mockito.when(productRepository.getById(Mockito.anyString()))
        .thenReturn(Mono.just(productResponse));

    Mono<NonPrimitiveAsset> product = productService.findProductById(PRODUCT_ID);

    StepVerifier.create(product).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(resp.get_id(), productResponse.get_id());
    }).verifyComplete();
  }

  /**
   * Test find product by parameter.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductByParameter() throws ServiceException {
    // Given
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
    // parameters.add(ID, PRODUCT_ID);
    parameters.add(_STATUS, _STATUS);
    parameters.add(CommonConstants.COLLECTION_DETAILS, "label,configuration,extensions");
    NonPrimitiveAsset productResponse = getProductResponse();
    AssetBulkResponse assetBulkResponse = getProductResponseQueryParameter();

    Mockito.when(productRepository.findProductByParameters(Mockito.any()))
        .thenReturn(Flux.just(productResponse));

    // When
    Mono<ProductCollectionResponse> product = productService.findProductCollection(parameters);

    // Then
    StepVerifier.create(product).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(resp.getCount(), assetBulkResponse.getCount());
    }).verifyComplete();
  }

  /**
   * Test find latest asset by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindLatestAssetById() throws ServiceException {

    NonPrimitiveAsset productResponse = getProductResponse();

    Mockito.when(productRepository.findById(PRODUCT_ID)).thenReturn(Mono.just(productResponse));

    Mono<NonPrimitiveAsset> product = productService.findLatestAssetById(PRODUCT_ID);

    StepVerifier.create(product).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(resp.get_id(), productResponse.get_id());
    }).verifyComplete();
  }

  /**
   * Test find product by ver.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductByVer() throws ServiceException {

    NonPrimitiveAsset productResponse = getProductResponse();

    Mockito.when(productRepository.findById(PRODUCT_DOCUMENT_ID))
        .thenReturn(Mono.just(productResponse));

    Mono<NonPrimitiveAsset> product = productService.findProductByVersion(PRODUCT_ID,
        PRODUCT_VERSION);

    StepVerifier.create(product).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(resp.getVer(), productResponse.getVer());
    }).verifyComplete();
  }

  /**
   * Test create product non primitive assets.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductNonPrimitiveAssets() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);
    Task task = createTask();
    Mockito.when(taskRepository.save(Mockito.any())).thenReturn(Mono.just(task));

    Mockito.when(nonPrimitiveAssetRepository.save(productsPayloadRequest.getAsset()))
        .thenReturn(Mono.just(productsPayloadRequest.getAsset()));

    Mockito.when(productRepository.save(productNonPrimitiveAsset))
        .thenReturn(Mono.just(productNonPrimitiveAsset));

    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    Mockito
        .when(eventService.publishEvent(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(iscResponse);

    // When
    Mono<ProductsResponse> productsResponse = productService.createProductNonPrimitiveAssets(
        productsPayloadRequest, productNonPrimitiveAsset, AssetType.PRODUCT);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(TASK_STATUS, response.getStatus())).verifyComplete();

    StepVerifier.create(Mono.just(task))
        .assertNext(response -> assertEquals(TaskStatus.RUNNING.name(), response.getStatus()))
        .verifyComplete();

    StepVerifier.create(iscResponse).assertNext(response -> assertEquals(Boolean.TRUE, response))
        .verifyComplete();

  }

  /**
   * Test save status document.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testSaveStatusDocument() throws ServiceException {

    // Given
    ProductStatusPayload newStatus = convertJsonToObject(PRODUCT_STATUS_REQUEST,
        ProductStatusPayload.class);
    ProductStatusPayload nullStatus = new ProductStatusPayload();
    nullStatus.setStatus(null);
    ProductStatus oldStatus = convertJsonToObject(OLD_PRODUCT_STATUS, ProductStatus.class);
    ProductStatus newSavedStatus = convertJsonToObject(PRODUCT_STATUS, ProductStatus.class);
    NonPrimitiveAsset productLA = convertJsonToObject(PRODUCT_JSON, NonPrimitiveAsset.class);
    Mockito.when(statusRepository.save(Mockito.any())).thenReturn(Mono.just(newSavedStatus));
    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    Mockito.when(
        eventService.publishEventMessage(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(iscResponse);
    Mockito.when(productRepository.getById(Mockito.anyString()))
        .thenReturn(getNonPrimitiveResponse());
    Mockito.when(productRepository.deleteById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(getNonPrimitiveResponse());

    // When
    Mono<ProductStatus> statusResponseDraft = productService.saveStatusDocument(productLA,
        oldStatus, newStatus);

    Mono<ProductStatus> statusResponseNull = productService.saveStatusDocument(productLA, oldStatus,
        nullStatus);

    // Then
    StepVerifier.create(statusResponseDraft)
        .assertNext(response -> assertEquals(COMPOSE, response.getStatus())).verifyComplete();

    StepVerifier.create(iscResponse).assertNext(response -> assertEquals(Boolean.TRUE, response))
        .verifyComplete();

    StepVerifier.create(statusResponseNull).assertNext(response -> {
      assertNotNull(response);
      assertEquals(String.valueOf(HttpStatus.BAD_REQUEST.value()),
          String.valueOf(response.getError().getStatus()));
    }).verifyComplete();

  }

  /**
   * Test save status document in review.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testSaveStatusDocumentInReview() throws ServiceException {

    // Given
    ProductAssetClassType assetClassType = convertJsonToObject(PRODUCT_GET_ASSET_TYPE_RESONSE,
        ProductAssetClassType.class);
    ProductStatusPayload reviewStatus = new ProductStatusPayload();
    reviewStatus.setStatus(REVIEW);

    ProductStatus oldStatus = convertJsonToObject(PRODUCT_STATUS_SETUP, ProductStatus.class);

    ProductStatus nextSavedStatus = convertJsonToObject(PRODUCT_STATUS_REVIEW_JSON,
        ProductStatus.class);

    NonPrimitiveAsset productLA = convertJsonToObject(PRODUCT_JSON, NonPrimitiveAsset.class);

    Mockito.when(statusRepository.save(Mockito.any())).thenReturn(Mono.just(nextSavedStatus));
    Mockito
        .when(assetClassTypeRepo.findById(
            CommonUtils.generateDocId(ASSETCLASSTYPES, productLA.get_id(), productLA.getVer())))
        .thenReturn(Mono.just(assetClassType));

    Mockito.when(
        eventService.publishEventMessage(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(Mono.just(true));
    Mockito.when(productRepository.getById(Mockito.anyString()))
        .thenReturn(getNonPrimitiveResponse());
    Mockito.when(productRepository.deleteById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(getNonPrimitiveResponse());
    // When
    Mono<ProductStatus> statusResponse = productService.saveStatusDocument(productLA, oldStatus,
        reviewStatus);
    // Then
    StepVerifier.create(statusResponse)
        .assertNext(response -> assertEquals(REVIEW, response.getStatus())).verifyComplete();
  }

  /**
   * Test create product version non primitive assets.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductVersionNonPrimitiveAssets() throws ServiceException {

    // Given
    ProductVersionPayload productsVersionPayloadRequest = convertJsonToObject(
        PRODUCT_POST_VERSION_REQUEST, ProductVersionPayload.class);
    NonPrimitiveAsset productVersionNonPrimitiveAsset = createProductVersionNonPrimitiveAsset(
        productsVersionPayloadRequest, PRODUCT_ID, ONE, AssetType.PRODUCT);
    Task task = createTask();
    Mockito.when(taskRepository.save(Mockito.any())).thenReturn(Mono.just(task));

    Mockito.when(nonPrimitiveAssetRepository.save(productVersionNonPrimitiveAsset))
        .thenReturn(Mono.just(productVersionNonPrimitiveAsset));

    Mockito.when(taskRepository.findBy_id(Mockito.any())).thenReturn(Mono.just(task));

    Mockito.when(productRepository.save(productVersionNonPrimitiveAsset))
        .thenReturn(Mono.just(productVersionNonPrimitiveAsset));

    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    Mockito
        .when(eventService.publishEvent(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(iscResponse);

    // When
    Mono<ProductsResponse> productsResponse = productService.createProductVersionNonPrimitiveAssets(
        productsVersionPayloadRequest, productVersionNonPrimitiveAsset, PRODUCT_ID, ONE,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> assertEquals(TASK_STATUS, response.getStatus())).verifyComplete();

    StepVerifier.create(Mono.just(task))
        .assertNext(response -> response.getStatus().equals(TaskStatus.COMPLETED.name()))
        .verifyComplete();

    StepVerifier.create(iscResponse).assertNext(response -> assertEquals(Boolean.TRUE, response))
        .verifyComplete();

  }

  /**
   * Test validate product.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidateProduct() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    AssetModel assetModel = createProductModel();
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetResponse> response = productService.validateProduct(productsPayloadRequest,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    // When
    response = productService.validateProduct(productsPayloadRequest, AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    productsPayloadRequest.getAsset().setConfiguration(null);
    // When
    response = productService.validateProduct(productsPayloadRequest, AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    Configuration configuration = new Configuration();
    configuration.put(POLICY_GROUPS, Collections.emptyList());

    productsPayloadRequest.getAsset().setConfiguration(configuration);
    // When
    response = productService.validateProduct(productsPayloadRequest, AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();
  }

  /**
   * Test validate product version.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidateProductVersion() throws ServiceException {

    // Given
    ProductVersionPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_VERSION_REQUEST,
        ProductVersionPayload.class);
    AssetModel assetModel = createProductModel();
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetResponse> response = productService.validateProductVersion(productsPayloadRequest,
        PRODUCT_ID, ONE, AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    // When
    response = productService.validateProductVersion(productsPayloadRequest, PRODUCT_ID, ONE,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    Configuration configuration = new Configuration();
    List<String> policyGroups = new ArrayList<>();
    policyGroups.add(TITLE + TAGS);
    configuration.put(POLICY_GROUPS, policyGroups);
    productsPayloadRequest.getAsset().setConfiguration(configuration);

    // When
    response = productService.validateProductVersion(productsPayloadRequest, PRODUCT_ID, ONE,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    configuration = new Configuration();
    policyGroups.add(TITLE + PRODUCT_ID);
    configuration.put(POLICY_GROUPS, policyGroups);
    productsPayloadRequest.getAsset().setConfiguration(configuration);

    // When
    response = productService.validateProductVersion(productsPayloadRequest, PRODUCT_ID, ONE,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    configuration = new Configuration();
    policyGroups = new ArrayList<>();
    policyGroups.add(PRODUCT_ID);
    configuration.put(POLICY_GROUPS, policyGroups);
    productsPayloadRequest.getAsset().setConfiguration(configuration);

    // When
    response = productService.validateProductVersion(productsPayloadRequest, PRODUCT_ID, ONE,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

  }

  /**
   * Creates the product model.
   *
   * @return the asset model
   */
  private AssetModel createProductModel() {
    AssetModel assetModel = new AssetModel();
    assetModel.set_id(UUID.randomUUID().toString());
    Configuration configuration = new Configuration();
    List<String> policyGroups = new ArrayList<>();
    policyGroups.add(PRODUCT_POLICY);
    configuration.put(POLICY_GROUPS, policyGroups);
    assetModel.setConfiguration(configuration);
    return assetModel;
  }

  /**
   * Creates the product non primitive asset.
   *
   * @param productPayload
   *          the product payload
   * @param assetType
   *          the asset type
   * @return the non primitive asset
   */
  private NonPrimitiveAsset createProductNonPrimitiveAsset(ProductPayload productPayload,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productPayload.getAsset());
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(INITIAL_BSS_VER);
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productPayload.getAsset());
    nonPrimitiveAsset.addLinks(SELF, createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return nonPrimitiveAsset;
  }

  /**
   * Creates the product version non primitive asset.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the non primitive asset
   */
  private NonPrimitiveAsset createProductVersionNonPrimitiveAsset(
      ProductVersionPayload productVersionPayload, String assetId, Integer bssVer,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = prepareAsset(productVersionPayload, bssVer);
    nonPrimitiveAsset.set_id(assetId);
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.addLinks(SELF, this.createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return nonPrimitiveAsset;
  }

  /**
   * Prepare asset.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param bssVer
   *          the bss ver
   * @return the non primitive asset
   */
  private NonPrimitiveAsset prepareAsset(ProductVersionPayload productVersionPayload,
      Integer bssVer) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productVersionPayload.getAsset());
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    if (!Objects.isNull(productVersionPayload.getUpdateRequest()) && Boolean.TRUE.toString()
        .equals(productVersionPayload.getUpdateRequest().getIsMajorChange())) {
      nonPrimitiveAsset.setBssVer(bssVer + 1);
    } else {
      nonPrimitiveAsset.setBssVer(bssVer);
    }
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productVersionPayload.getAsset());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productVersionPayload.getAsset());
    return nonPrimitiveAsset;
  }

  /**
   * Sets the non primitive asset links.
   *
   * @param nonPrimitiveAsset
   *          the new non primitive asset links
   */
  private void setNonPrimitiveAssetLinks(NonPrimitiveAsset nonPrimitiveAsset) {
    nonPrimitiveAsset.getLearningModel().addLinks(SELF,
        createNonPrimitiveAssetSelfLink(ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value(),
            nonPrimitiveAsset.getLearningModel().getId(),
            nonPrimitiveAsset.getLearningModel().getVer()));

    nonPrimitiveAsset.getResources().values().forEach(resource -> {
      String url = AssetType.valueOf(resource.getAssetType()).url();
      resource.addLinks(SELF,
          createNonPrimitiveAssetSelfLink(url, resource.getId(), resource.getVer()));
    });
  }

  /**
   * Creates the non primitive asset self link.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the link
   */
  private Link createNonPrimitiveAssetSelfLink(String url, String id, String ver) {
    Link link = new Link();
    link.setHref(createNonPrimitiveAssetHref(url, id, ver));
    return link;
  }

  /**
   * Creates the non primitive asset href.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  private String createNonPrimitiveAssetHref(String url, String id, String ver) {
    String href = url;
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, ver);
    return href;
  }

  /**
   * Sets the non primitive asset extensions.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param nonPrimitiveAssetPayload
   *          the non primitive asset payload
   */
  private void setNonPrimitiveAssetExtensions(NonPrimitiveAsset nonPrimitiveAsset,
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    Productization productization = new Productization();
    productization.setId(UUID.randomUUID().toString());
    productization.setProductId(UUID.randomUUID().toString());
    if (nonPrimitiveAsset.getExtensions() == null) {
      nonPrimitiveAsset.setExtensions(new Extensions());
    }
    if (Optional.ofNullable(productization.getProductId()).isPresent()) {
      nonPrimitiveAsset.getExtensions().put(PRODUCTIZATION, productization);
    }
    nonPrimitiveAsset.getExtensions().put(CONTENT_METADATA,
        nonPrimitiveAssetPayload.getContentMetadata());

  }

  /**
   * Test create product non primitive assets error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductNonPrimitiveAssetsError() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(
        productsPayloadRequest, AssetType.PRODUCT);

    Mockito.when(taskRepository.save(Mockito.any()))
        .thenReturn(Mono.error(new CouchbaseException()));

    Mockito.when(productRepository.save(productNonPrimitiveAsset))
        .thenReturn(Mono.just(productNonPrimitiveAsset));
    // When
    Mono<ProductsResponse> productsResponse = productService.createProductNonPrimitiveAssets(
        productsPayloadRequest, productNonPrimitiveAsset, AssetType.PRODUCT);

    // Then
    StepVerifier.create(productsResponse)
        .assertNext(response -> Assert.assertNotNull(response.getError())).verifyComplete();

  }

  /**
   * Creates the long running task.
   *
   * @return the long running task
   */
  private Task createTask() {
    Task task = new Task();
    String longRunningId = UUID.randomUUID().toString();
    Link _link = new Link(GET_TASK_URL + longRunningId);
    task.setId(UUID.randomUUID().toString());
    task.set_id(longRunningId);
    Links links = new Links();
    links.putIfAbsent(SELF, _link);
    task.setLinks(links);
    task.setStatus(TaskStatus.RUNNING.name());
    task.setResources(new ArrayList<>());
    return task;

  }

  /**
   * Test find product versions by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductVersionsById() throws ServiceException {

    // Given
    NonPrimitiveAsset productNonPrimitiveAsset = getProductResponse();
    AssetVersionsResponse assetVersionsResponse = new AssetVersionsResponse(ONE,
        Arrays.asList(getAsset(productNonPrimitiveAsset)));
    Mockito.when(productRepository.findGetAllVersion(PRODUCT_DOCUMENT_VERSION_ID))
        .thenReturn(Flux.just(productNonPrimitiveAsset));

    // When
    Mono<AssetVersionsResponse> response = productService.findProductVersionsById(PRODUCT_ID);

    // Then
    StepVerifier.create(response).assertNext(productVersion -> {
      assertNotNull(productVersion);
      assertEquals(assetVersionsResponse.getCount(), productVersion.getCount());
      assertEquals(assetVersionsResponse.getVersions(), productVersion.getVersions());
    }).verifyComplete();
  }

  /**
   * Test get state transition response.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetStateTransitionResponse() throws ServiceException {
    // Given
    StateTransitionPayload payload = convertJsonToObject(STATE_TRANSITION_PAYLOAD_JSON,
        StateTransitionPayload.class);
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset liveProduct = createProductNonPrimitiveAsset(productsPayloadRequest,
        AssetType.PRODUCT);
    liveProduct.setExtend(null);
    Mockito.when(
        eventService.publishEventMessage(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(Mono.just(true));
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(Mono.just(liveProduct));
    Mockito.when(stateRepository.save(Mockito.any()))
        .thenReturn(Mono.just(buildStateTransition(payload)));

    // When
    Mono<ProductStateTransition> response = productService.getStateTransitionResponse(liveProduct,
        payload, ProductsStatus.REVIEW.name());

    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(payload.getReason(), productResponse.getReason());
      assertEquals(payload.getReasonCode(), productResponse.getReasonCode());
    }).verifyComplete();

    Productization productization = (Productization) liveProduct.getExtensions()
        .get(PRODUCTIZATION);
    productization.setProductId(null);

    // When
    Mono<ProductStateTransition> response2 = productService.getStateTransitionResponse(liveProduct,
        payload, ProductsStatus.REVIEW.name());

    // Then
    StepVerifier.create(response2).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(payload.getReason(), productResponse.getReason());
      assertEquals(payload.getReasonCode(), productResponse.getReasonCode());
    }).verifyComplete();

    payload.setTransitionState("COMPOSE");
    response = productService.getStateTransitionResponse(liveProduct, payload,
        ProductsStatus.REVIEW.name());

    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(payload.getReason(), productResponse.getReason());
      assertEquals(payload.getReasonCode(), productResponse.getReasonCode());
    }).verifyComplete();
  }

  /**
   * Builds the state transition.
   *
   * @param payload
   *          the payload
   * @return the product state transition
   */
  private ProductStateTransition buildStateTransition(StateTransitionPayload payload) {
    ProductStateTransition stateTransition = new ProductStateTransition();
    stateTransition.setReason(payload.getReason());
    stateTransition.setReasonCode(payload.getReasonCode());
    return stateTransition;
  }

  /**
   * Test Fetch product status.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFetchProductStatus() throws ServiceException {
    // When
    Mono<ProductStatus> response = productService.fetchProductStatus("");

    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
    }).verifyComplete();
  }

  /**
   * Gets the asset.
   *
   * @param productNonPrimitiveAsset
   *          the product non primitive asset
   * @return the asset
   */
  private Asset getAsset(NonPrimitiveAsset productNonPrimitiveAsset) {

    Asset asset = new Asset();
    asset.set_id(productNonPrimitiveAsset.get_id());
    asset.setVer(productNonPrimitiveAsset.getVer());
    asset.setBssVer(productNonPrimitiveAsset.getBssVer());
    asset.setId(UUID.randomUUID().toString());
    return asset;
  }

  /**
   * Test validate product no extension.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  @Ignore
  public void testValidateProductNoExtension() throws ServiceException {

    // Given
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    productsPayloadRequest.getAsset().setExtensions(null);

    // When
    Mono<AssetResponse> response = productService.validateProduct(productsPayloadRequest,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).consumeErrorWith(err -> Assert.assertNotNull(err)).verify();

  }

  /**
   * Test validate product version no major change.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidateProductVersionNoMajorChange() throws ServiceException {

    // Given
    ProductVersionPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_VERSION_REQUEST,
        ProductVersionPayload.class);
    AssetModel assetModel = createProductModel();
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    productsPayloadRequest.getUpdateRequest().setIsMajorChange(Boolean.FALSE.toString());
    // When
    Mono<AssetResponse> response = productService.validateProductVersion(productsPayloadRequest,
        PRODUCT_ID, ONE, AssetType.AGGREGATE);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

    // When
    response = productService.validateProductVersion(productsPayloadRequest, PRODUCT_ID, ONE,
        AssetType.PRODUCT);

    // Then
    StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getAsset()))
        .verifyComplete();

  }

  /**
   * Test get state transition response with extends.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetStateTransitionResponseWithExtends() throws ServiceException {
    // Given
    StateTransitionPayload payload = convertJsonToObject(STATE_TRANSITION_PAYLOAD_JSON,
        StateTransitionPayload.class);
    ProductPayload productsPayloadRequest = convertJsonToObject(PRODUCT_POST_REQUEST,
        ProductPayload.class);
    NonPrimitiveAsset liveProduct = createProductNonPrimitiveAsset(productsPayloadRequest,
        AssetType.PRODUCT);
    liveProduct.setExtend(null);
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(Mono.just(liveProduct));
    Mockito.when(stateRepository.save(Mockito.any()))
        .thenReturn(Mono.just(buildStateTransition(payload)));
    liveProduct.setExtend(new Extends());

    Mockito.when(
        eventService.publishEventMessage(Mockito.anyString(), Mockito.any(NonPrimitiveAsset.class)))
        .thenReturn(Mono.just(true));

    // When
    Mono<ProductStateTransition> response = productService.getStateTransitionResponse(liveProduct,
        payload, ProductsStatus.REVIEW.name());

    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
      assertEquals(payload.getReason(), productResponse.getReason());
      assertEquals(payload.getReasonCode(), productResponse.getReasonCode());
    }).verifyComplete();
  }

  /**
   * Test fetch product state.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFetchProductState() throws ServiceException {
    // Given
    Mockito.when(stateRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(new ProductStateTransition()));

    // When
    Mono<ProductStateTransition> response = productService.fetchProductStateTransition("");

    // Then
    StepVerifier.create(response).assertNext(productResponse -> {
      assertNotNull(productResponse);
    }).verifyComplete();
  }

  /**
   * Test fetch product configuration.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFetchProductConfiguration() throws ServiceException {
    // Given
    Mockito.when(productRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getProductResponse()));

    // When
    Mono<ProductConfigurationResponse> response = productService
        .fetchProductConfiguration(PRODUCT_ID, PRODUCT_VERSION);

    // Then
    StepVerifier.create(response).assertNext(configResponse -> {
      assertNotNull(configResponse);
    }).verifyComplete();
  }

  /**
   * Test Save Product
   * 
   * @throws ServiceException
   */
  @Test
  public void testSaveProduct() throws ServiceException {
    // Given

    Mockito.when(productRepository.save(Mockito.any())).thenReturn(getNonPrimitiveResponse());

    // When
    Mono<ProductAssetResponse> response = productService.saveProduct(new NonPrimitiveAssetPayload(),
        new NonPrimitiveAsset());

    // Then
    StepVerifier.create(response).assertNext(nonPrimitiveResponse -> {
      assertNotNull(nonPrimitiveResponse);
      // assertNotNull(nonPrimitiveResponse.get_status());
    }).verifyComplete();
  }

  @Test
  public void testSaveProductError() throws ServiceException {
    // Given

    Mockito.when(productRepository.save(Mockito.any()))
        .thenReturn(Mono.error(new CouchbaseException()));

    // When
    Mono<ProductAssetResponse> saveProductResponse = productService
        .saveProduct(new NonPrimitiveAssetPayload(), new NonPrimitiveAsset());

    // Then

    StepVerifier.create(saveProductResponse).assertNext(res -> assertNotNull(res)).verifyComplete();
    StepVerifier.create(saveProductResponse).assertNext(response -> {
      assertNotNull(response);
      // assertNotNull(nonPrimitiveResponse.get_status());
    }).verifyComplete();
  }

  /**
   * Test Check PMP Message
   *
   * @throws ServiceException
   */
  @Test
  public void testCheckPMPMessage() throws ServiceException {
    NonPrimitiveAsset nonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    ContentMetadata contentMetadata = new ContentMetadata();
    contentMetadata.setId(PRODUCT_ID);
    contentMetadata.setVersion(VER);
    Extensions extensions = new Extensions();
    extensions.put(CONTENT_METADATA, contentMetadata);
    nonPrimitiveAsset.setExtensions(extensions);
    ProductStatus productStatus = convertJsonToObject(PRODUCT_STATUS_SETUP, ProductStatus.class);
    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    // Given
    Mockito.when(productRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(pmpMessageRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getPMPMessage()));
    Mockito.when(productRepository.deleteById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(statusRepository.save(Mockito.any())).thenReturn(Mono.just(productStatus));
    Mockito.when(eventService.publishEventMessage(Mockito.anyString(), Mockito.any()))
        .thenReturn(iscResponse);
    Mockito.when(scannerService.scanProduct(Mockito.any())).thenReturn(Mono.just(true));

    // When
    Mono<AutobahnEventModel> pmpMessageMono = productService
        .checkPMPMessage(Mono.just(nonPrimitiveAsset));

    // Then
    StepVerifier.create(pmpMessageMono).assertNext(pmpMessage -> assertNotNull(pmpMessage))
        .verifyComplete();
  }

  /**
   * Test Save Existing PMP Message
   *
   * @throws ServiceException
   */
  @Test
  public void testSavePMPMessage() throws ServiceException {
    NonPrimitiveAsset nonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);
    ProductStatus productStatus = convertJsonToObject(PRODUCT_STATUS_SETUP, ProductStatus.class);
    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    // Given
    Mockito.when(productRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(pmpMessageRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(getPMPMessage()));
    Mockito.when(pmpMessageRepository.save(Mockito.any())).thenReturn(Mono.just(getPMPMessage()));
    Mockito.when(productRepository.deleteById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(statusRepository.save(Mockito.any())).thenReturn(Mono.just(productStatus));
    Mockito.when(eventService.publishEventMessage(Mockito.anyString(), Mockito.any()))
        .thenReturn(iscResponse);
    Mockito.when(scannerService.scanProduct(Mockito.any())).thenReturn(Mono.just(true));

    // When
    Mono<NonPrimitiveAsset> nonPrimitiveAssetMono = productService.savePMPMessage(getPMPMessage());

    // Then
    StepVerifier.create(nonPrimitiveAssetMono).verifyComplete();
  }

  /**
   * Test Save New PMP Message
   *
   * @throws ServiceException
   */
  @Test
  public void testSaveNewPMPMessage() throws ServiceException {
    NonPrimitiveAsset nonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    ProductStatus productStatus = convertJsonToObject(PRODUCT_STATUS_SETUP, ProductStatus.class);
    Mono<Boolean> iscResponse = Mono.just(Boolean.TRUE);
    // Given
    Mockito.when(productRepository.findById(Mockito.anyString()))
        .thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(productRepository.getProductBy(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(addProductization(nonPrimitiveAsset)));
    Mockito.when(pmpMessageRepository.findById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito.when(pmpMessageRepository.save(Mockito.any())).thenReturn(Mono.just(getPMPMessage()));
    Mockito.when(productRepository.deleteById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito.when(productRepository.save(Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(statusRepository.save(Mockito.any())).thenReturn(Mono.just(productStatus));
    Mockito.when(eventService.publishEventMessage(Mockito.anyString(), Mockito.any()))
        .thenReturn(iscResponse);
    Mockito.when(scannerService.scanProduct(Mockito.any())).thenReturn(Mono.just(false));

    // When
    Mono<NonPrimitiveAsset> nonPrimitiveAssetMono = productService.savePMPMessage(getPMPMessage());

    // Then
    StepVerifier.create(nonPrimitiveAssetMono)
        .assertNext(primitiveAsset -> assertNotNull(primitiveAsset)).verifyComplete();
  }

  /**
   * get Non Primitive Response
   * 
   * @return Mono<NonPrimitiveAsset>
   */
  private Mono<NonPrimitiveAsset> getNonPrimitiveResponse() {
    NonPrimitiveAsset response = new NonPrimitiveAsset();
    response.setId(ID);
    Extensions ext = new Extensions();
    ext.put(CommonConstants.CONTENT_METADATA, "contentMetadata");
    response.setExtensions(new Extensions());
    return Mono.just(response);
  }

  /**
   * get Non Primitive Response
   *
   * @return
   */
  private NonPrimitiveAsset addProductization(NonPrimitiveAsset nonPrimitiveAsset) {
    LinkedHashMap<String, String> productization = new LinkedHashMap<>();
    productization.put(ID, UUID.randomUUID().toString());
    nonPrimitiveAsset.getExtensions().put(PRODUCTIZATION, productization);
    return nonPrimitiveAsset;
  }

  /**
   * Generate the PMP Message
   *
   * @return
   */
  private AutobahnEventModel getPMPMessage() {
    AutobahnEventModel pmpMessage = new AutobahnEventModel();
    AutobahnEvent autobahnEvent = new AutobahnEvent();
    AutobahnPayLoad autobahnPayLoad = new AutobahnPayLoad();
    pmpMessage.setAutobahnEvent(autobahnEvent);
    autobahnEvent.setPayload(autobahnPayLoad);
    pmpMessage.setId(UUID.randomUUID().toString());
    autobahnPayLoad.setContentUrn(UUID.randomUUID().toString());
    autobahnPayLoad.setVersionUrn(UUID.randomUUID().toString());
    autobahnPayLoad.setProductId(UUID.randomUUID().toString());
    autobahnPayLoad.setProductPlatformCode(UUID.randomUUID().toString());
    return pmpMessage;
  }

}