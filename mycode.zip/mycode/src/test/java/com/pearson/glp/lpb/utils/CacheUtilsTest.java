/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.enums.CacheRegion;

/**
 * The Class CacheUtilsTest.
 */
public class CacheUtilsTest {

  /** The Constant CACHE_SIZE. */
  private static final int CACHE_SIZE = 5;

  /** The cache util. */
  private CacheUtils cacheUtil;

  /** The cache key. */
  private String cacheKey = "testKey";

  /** The Constant CACHE_TTL. */
  private static final int CACHE_TTL = 10;

  /**
   * Setup.
   */
  @Before
  public void setup() {
    cacheUtil = new CacheUtils();
    ReflectionTestUtils.setField(cacheUtil, "cacheMaxLimit", CACHE_SIZE);
    ReflectionTestUtils.setField(cacheUtil, "cacheEnabled", true);
    ReflectionTestUtils.setField(cacheUtil, "cacheMaxTimeToLive", CACHE_TTL);
    cacheUtil.init();
  }

  /**
   * Test cache when enabled.
   */
  @Test
  public void testCacheWhenEnabled() {
    // When
    Optional<Object> resultfailure = cacheUtil.get(CacheRegion.LEARNING_MODEL, cacheKey);
    // Then
    if (resultfailure.isPresent()) {
      fail("Cache should not have any data at initialization.");
    }

    // Given
    AssetModel value = new AssetModel();
    cacheUtil.put(CacheRegion.LEARNING_MODEL, cacheKey, value);
    // When
    Optional<Object> resultSuccess = cacheUtil.get(CacheRegion.LEARNING_MODEL, cacheKey);
    // Then
    if (!resultSuccess.isPresent()) {
      fail("Cache should contain the data when added.");
    } else {
      assertEquals(value, (AssetModel) resultSuccess.get());
    }
  }

  /**
   * Test cache when disabled.
   */
  @Test
  public void testCacheWhenDisabled() {
    // Given
    ReflectionTestUtils.setField(cacheUtil, "cacheEnabled", false);
    cacheUtil.put(CacheRegion.LEARNING_MODEL, cacheKey, new AssetModel());

    // When
    Optional<Object> result = cacheUtil.get(CacheRegion.LEARNING_MODEL, cacheKey);
    // Then
    if (result.isPresent()) {
      fail("Cache should not have any data at initialization.");
    }
  }

  /**
   * Test cache evict.
   */
  @Test
  public void testCacheEvict() {
    // Given
    AssetModel value = new AssetModel();
    for (int i = 0; i <= CACHE_SIZE; i++) {
      cacheUtil.put(CacheRegion.LEARNING_MODEL, cacheKey + i, value);
    }

    // When
    Optional<Object> resultFail = cacheUtil.get(CacheRegion.LEARNING_MODEL, cacheKey + "0");
    // Then
    assertEquals(resultFail, Optional.empty());

    // When
    Optional<Object> resultSuccess = cacheUtil.get(CacheRegion.LEARNING_MODEL,
        cacheKey + CACHE_SIZE);
    // Then
    if (resultSuccess.isPresent()) {
      assertEquals(value, (AssetModel) resultSuccess.get());
    } else {
      fail("Most recently used element should be available.");
    }
  }

}
