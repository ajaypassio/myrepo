/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static com.pearson.glp.lpb.constant.CommonConstants.DATE_FORMAT_JSON;

import org.junit.Test;

/**
 * The Class DateUtilTest.
 * 
 * @author sourabh.aggarwal
 */
public class DateUtilTest {

  /**
   * Instantiates a new date util test.
   */
  public DateUtilTest() {
    super();
  }

  /**
   * Test current timestamp.
   */
  @Test
  public void testCurrentTimestamp() {
    // Then
    assertNotNull(DateUtil.currentTimestamp());
  }

  /**
   * Test format date time.
   */
  @Test
  public void testFormatDateTime() {
    // Given
    long timestamp = 1536298264000L;
    String pattern = DATE_FORMAT_JSON;

    // Then
    assertNotNull(DateUtil.formatDateTime(timestamp, pattern));
  }

  /**
   * Test format date time with pattern is in valid.
   */
  @Test
  public void testFormatDateTimeWithPatternIsInValid() {
    // Given
    long timestamp = 1536298264000L;
    String pattern = null;

    // Then
    assertNull(DateUtil.formatDateTime(timestamp, pattern));
  }

  /**
   * Test format date time with null date time.
   */
  @Test
  public void testFormatDateTimeWithNullValue() {
    assertThat(DateUtil.formatDateTime(null)).isEmpty();
  }
}