/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

/**
 * The Class PlatformErrorResponseUtilsTest.
 * 
 * @author sourabh.aggarwal
 */
public class PlatformErrorResponseUtilsTest {

  /**
   * Instantiates a new platform error utils test.
   */
  public PlatformErrorResponseUtilsTest() {
    super();
  }

  /**
   * Test object not found error.
   */
  @Test
  public void testObjectNotFoundError() {
    // Given
    String message = "Learning Asset Model not found";

    // Then
    assertNotNull(PlatformErrorUtils.objectNotFoundError(message));
  }

  /**
   * Test internal server error.
   */
  @Test
  public void testInternalServerError() {
    // Given
    String message = "Error while converting JSON to Java object";

    // Then
    assertNotNull(PlatformErrorUtils.internalServerError(message));
  }

  /**
   * Test invalid request error.
   */
  @Test
  public void testInvalidRequestError() {
    // Given
    String message = "Error in validating asset model schema";

    // Then
    assertNotNull(PlatformErrorUtils.invalidRequestError(message));
  }
}