/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import com.pearson.glp.lpb.beanvalidation.validators.AssetValidator;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.utils.CommonUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;

import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_REQUEST;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * The Class AssetValidatorTest.
 *
 * @author sanket.gupta
 */
public class AssetValidatorTest implements CommonUtils {

  @InjectMocks
  private AssetValidator validator;

  @Mock
  private ConstraintValidatorContext context;

  @Mock
  private ConstraintViolationBuilder violationBuilder;

  @Mock
  private NodeBuilderCustomizableContext nodeBuilderCustomizableContext;

  public AssetValidatorTest() {
    super();
  }

  /**
   * Setup that executes before running every test method.
   */
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    Mockito.when(context.buildConstraintViolationWithTemplate(Mockito.anyString()))
        .thenReturn(violationBuilder);
    Mockito.when(violationBuilder.addPropertyNode(Mockito.anyString()))
        .thenReturn(nodeBuilderCustomizableContext);
  }

  /**
   * Test Asset Validator
   */
  @Test
  public void testAssetValidator() {
    // Given
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset();

    // When
    Boolean valid = validator.isValid(nonPrimitiveAsset, context);

    // Then
    assertTrue(valid);
  }

  /**
   * Test Asset Validator Without Learning Model
   */
  @Test
  public void testAssetValidatorWithOutLearningModel() {
    // Given
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset();
    nonPrimitiveAsset.setLearningModel(null);
    nonPrimitiveAsset.setResources(null);

    // When
    Boolean valid = validator.isValid(nonPrimitiveAsset, context);

    // Then
    assertTrue(valid);
  }

  /**
   * Test Asset Validator With Invalid Learning Model
   */
  @Test
  public void testAssetValidatorWithInvalidLearningModel() {
    // Given
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset();
    nonPrimitiveAsset.getLearningModel().setDocType(DocType.LEARNINGCONTENT.value());

    // When
    Boolean valid = validator.isValid(nonPrimitiveAsset, context);

    // Then
    assertFalse(valid);
  }

  /**
   * Test Asset Validator With No Links
   */
  @Test
  public void testAssetValidatorWithNoLinks() {
    // Given
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset();
    nonPrimitiveAsset.getLearningModel().setLinks(null);
    nonPrimitiveAsset.getResources().entrySet()
        .forEach(resource -> resource.getValue().setLinks(null));

    // When
    Boolean valid = validator.isValid(nonPrimitiveAsset, context);

    // Then
    assertTrue(valid);
  }

  /**
   * Test Asset Validator With Invalid Learning Model
   */
  @Test
  public void testAssetValidatorWithNoSelf() {
    // Given
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset();
    nonPrimitiveAsset.getLearningModel().getLinks().clear();
    nonPrimitiveAsset.getResources().entrySet()
        .forEach(resource -> resource.getValue().getLinks().clear());

    // When
    Boolean valid = validator.isValid(nonPrimitiveAsset, context);

    // Then
    assertFalse(valid);
  }

  /**
   * Test Asset Validator With Invalid Learning Model
   */
  @Test
  public void testAssetValidatorWithNoHref() {
    // Given
    NonPrimitiveAsset nonPrimitiveAsset = getNonPrimitiveAsset();
    nonPrimitiveAsset.getLearningModel().getLinks().get(SELF).setHref(null);
    nonPrimitiveAsset.getResources().entrySet()
        .forEach(resource -> resource.getValue().getLinks().get(SELF).setHref(null));

    // When
    Boolean valid = validator.isValid(nonPrimitiveAsset, context);

    // Then
    assertFalse(valid);
  }

  /**
   * Generate Non Primitive Asset.
   *
   * @return non primitive asset
   */
  private NonPrimitiveAsset getNonPrimitiveAsset() {
    NonPrimitiveAssetPayload nonPrimitiveAsset = convertJsonToObject(INSTRUCTION_POST_REQUEST,
        NonPrimitiveAssetPayload.class);
    return nonPrimitiveAsset;
  }

}