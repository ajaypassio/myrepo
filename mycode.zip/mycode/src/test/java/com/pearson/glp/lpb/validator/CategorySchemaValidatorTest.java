/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.LMValidationConstants.VALID_RESOURCE;
import static com.pearson.glp.lpb.constant.LoggingConstants.MAX;
import static com.pearson.glp.lpb.constant.LoggingConstants.MIN;
import static com.pearson.glp.lpb.constant.LoggingConstants.RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.data.model.lm.resources.CategorySchema;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;

/**
 * The Class CategorySchemaValidatorTest.
 * 
 * @author srishti.singh
 */
public class CategorySchemaValidatorTest {

  /** The Constant INVALID_MAX. */
  private static final int INVALID_MAX = 1;

  /** The Constant INVALID_MIN. */
  private static final int INVALID_MIN = 4;

  /** The Constant OBJECT. */
  private static final String OBJECT = "Object";

  /** The validator. */
  private CategorySchemaValidator validator;

  /** The key pattern. */
  private String keyPattern = "INSTRUCTION";

  /** The key. */
  private ResourceData key;

  /** The key pattern map. */
  private Map<ResourceData, Integer> keyPatternMap;

  /**
   * Setup.
   */
  @Before
  public void setup() {
    validator = new CategorySchemaValidator();
    key = new ResourceData();
    key.setKeyPattern(keyPattern);
    keyPatternMap = new HashMap<>();
    keyPatternMap.put(key, 2);
  }

  /**
   * Test category schema with min error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCategorySchemaWithMinError() throws ServiceException {
    // Given
    CategorySchema categorySchema = new CategorySchema(OBJECT, INVALID_MIN, null);
    key.setCategorySchema(categorySchema);

    // When
    String result = validator.validateCategorySchema(keyPatternMap);

    // Then
    assertNotNull(result);
    String expected = new StringBuilder().append(keyPatternMap.get(key))
        .append(RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN).append(keyPattern).append(MIN)
        .append(INVALID_MIN).append(". ").toString();
    assertEquals(expected, result);

  }

  /**
   * Test category schema with max error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCategorySchemaWithMaxError() throws ServiceException {
    // Given
    CategorySchema categorySchema = new CategorySchema(OBJECT, null, INVALID_MAX);
    key.setCategorySchema(categorySchema);

    // When
    String result = validator.validateCategorySchema(keyPatternMap);

    // Then
    assertNotNull(result);
    String expected = new StringBuilder().append(keyPatternMap.get(key))
        .append(RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN).append(keyPattern).append(MAX)
        .append(INVALID_MAX).append(". ").toString();
    assertEquals(expected, result);

  }

  /**
   * Test category schema with correct values.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCategorySchemaWithCorrectValues() throws ServiceException {
    // Given
    CategorySchema categorySchema = new CategorySchema(OBJECT, 2, 3);
    key.setCategorySchema(categorySchema);

    // When
    String result = validator.validateCategorySchema(keyPatternMap);

    // Then
    assertNotNull(result);
    assertEquals(VALID_RESOURCE, result);
  }

  /**
   * Test with null category schema.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testWithNullCategorySchema() throws ServiceException {
    // Given
    key.setCategorySchema(null);
    // When
    String result = validator.validateCategorySchema(keyPatternMap);

    // Then
    assertNotNull(result);
    assertEquals(VALID_RESOURCE, result);
  }

}
