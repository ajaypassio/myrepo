/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.TestingConstants.ASSESSMENT_BY_ID_JSON_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.EMBEDDED_ASSETS_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.CONTENTMETADATA;
import static org.junit.Assert.assertNotNull;

import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class EmbeddedAssetValidatorTest implements CommonUtils {

  /** The validator. */
  @InjectMocks
  private EmbeddedAssetValidator validator;

  /** The repository. */
  @Mock
  private NonPrimitiveAssetRepository repository;

  /** The asset payload. */
  private NonPrimitiveAsset assessmentAsset;

  /** The asset payload. */
  private NonPrimitiveAsset primitiveAssetPayload;

  /**
   * Setup that executes before running every test method.
   */
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    NonPrimitiveAssetPayload payload = convertJsonToObject(EMBEDDED_ASSETS_POST_REQUEST,
        NonPrimitiveAssetPayload.class);
    primitiveAssetPayload = payload;
    Extensions extensions = new Extensions();
    extensions.put(CONTENTMETADATA, payload.getContentMetadata());
    primitiveAssetPayload.setExtensions(extensions);
    primitiveAssetPayload.setAssetType(AssetType.AGGREGATE.value());
    assessmentAsset = convertJsonToObject(ASSESSMENT_BY_ID_JSON_RESPONSE, NonPrimitiveAsset.class);

  }

  @Test
  public void testValidateEmbeddedAsset() throws ServiceException {

    // Given
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(assessmentAsset));
    // When
    Mono<AssetResponse> validationResponse = validator.validateEmbeddedAsset(primitiveAssetPayload,
        (ContentMetadata) primitiveAssetPayload.getExtensions().get(CONTENTMETADATA));

    // Then
    StepVerifier.create(validationResponse).expectComplete().verify();
  }

  @Test
  public void testValidateEmbeddedAssetValidationFail() throws ServiceException {

    // Given
    primitiveAssetPayload.setConfiguration(new Configuration());

    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(assessmentAsset));

    // When
    Mono<AssetResponse> validationResponse = validator.validateEmbeddedAsset(primitiveAssetPayload,
        (ContentMetadata) primitiveAssetPayload.getExtensions().get(CONTENTMETADATA));

    // Then
    StepVerifier.create(validationResponse).assertNext(response -> {
      assertNotNull(response.getError());
    }).verifyComplete();
  }

  @Test
  public void testValidateEmbeddedAssetResourceNotFound() throws ServiceException {

    // Given
    Mockito.when(repository.findById(Mockito.anyString()))
        .thenReturn(Mono.empty().cast(NonPrimitiveAsset.class));
    // When
    Mono<AssetResponse> validationResponse = validator.validateEmbeddedAsset(primitiveAssetPayload,
        (ContentMetadata) primitiveAssetPayload.getExtensions().get(CONTENTMETADATA));

    // Then
    StepVerifier.create(validationResponse).assertNext(response -> {
      assertNotNull(response.getError());
    }).verifyComplete();
  }

}