package contracts.aggregates.error400;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
  description "."
  request {
	method POST()
	urlPath('/lpb/v2/aggregates')
	headers {
	  header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(
        "assets": [
          $(
          "contentMetadata": $(
          "id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('09b7ff3b-25e6-47be-a1cd-300cf6ea8b33')),
          "version": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('455c4472-184f-4e3e-a4d4-a89e858b1d03'))
          ),
          "resources": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "assetGraph": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "resourcePlan": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "configuration": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "constraints": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
         "extends": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
         "extensions": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "scope": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
          )
        ]
        )
  }
  response {
    headers {   
      contentType('''application/stream+json; application/hal+json; charset=UTF-8''')
        }
    status 207
    bodyMatchers {
      jsonPath('$.error.timestamp', byType())
	  jsonPath('$.status', byType())
      jsonPath('$.error.status', byType())
	  jsonPath('$.error', byType())
      jsonPath('$.error.error', byType())
	  jsonPath('$.error.message', byType())
	  jsonPath('$.entityStatus', byType())
	  jsonPath('$.contentMetadata', byType())
	  jsonPath('$.contentMetadata.id', byType())
	  jsonPath('$.contentMetadata.version', byType())
    }
    body('''{
  "entityStatus": "Error",
  "status": 400,
  "contentMetadata": {
    "id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
    "version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
  },
  "error": {
    "timestamp": "2018-12-20T10:08:19+00:00",
    "status": 400,
    "error": "BAD REQUEST",
    "message": "The request does not comply with the expected schema."
  }
}'''
    )
	}
  priority 2
}