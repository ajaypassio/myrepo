package contracts.aggregates.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
	method GET()
	urlPath('/lpb/v2/aggregates')
	headers {
	  header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
jsonPath('$._count', byType())
jsonPath('$.assets', byCommand('assertThatValueIsAMap($it)'))
jsonPath('$.assets[*]._id', byCommand('assertThatValueIsAString($it)'))
jsonPath('$.assets[*]._ver', byCommand('assertThatValueIsAString($it)'))
jsonPath('$.assets[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
jsonPath('$.assets[*]._createdBy', byCommand('assertThatValueIsAString($it)'))
jsonPath('$.assets[*]._docType', byCommand('assertThatValueIsAString($it)'))
jsonPath('$.assets[*]._assetType', byCommand('assertThatValueIsAString($it)'))
jsonPath('$.assets[*]._links', byCommand('assertThatValueIsAMap($it)'))
jsonPath('$.assets[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
jsonPath('$.assets[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
    }
	
    body('''{
  "_count": 2,
  "assets": [
    {
      "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
     "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae87",
     "_bssVer": 1,
     "_createdBy": "Admin",
     "_docType": "LEARNINGCONTENT",
      "_assetType": "AGGREGATE",
      "_links": {
        "self": {
          "href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/16f6de1c-d5f8-4e0e-8c41-94a68c9cae87"
        }
      }
    },
    {
      "_id": "243b49fb-24a0-4081-8970-efd55773f33c",
      "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae90",
     "_bssVer": 1,
     "_createdBy": "Admin",
     "_docType": "LEARNINGCONTENT",
      "_assetType": "AGGREGATE",
      "_links": {
        "self": {
          "href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f33c/versions/16f6de1c-d5f8-4e0e-8c41-94a68c9cae90"
        }
      }
    }
  ]
}''')
  }
}