package contracts.aggregatesBySpecificVersion.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  priority 1
  description "."
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/aggregates/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672'))))
    headers {
            header('''Accept''', '''application/json''')
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
	  jsonPath('$._id', byRegex(uuid()))
      jsonPath('$._bssVer', byType())
      jsonPath('$._ver', byRegex(uuid()))
      jsonPath('$._created', byType())
      jsonPath('$._createdBy', byType())
      jsonPath('$._lastModified', byType())
      jsonPath('$._docType', byType())
      jsonPath('$._assetType', byType())
      jsonPath('$.learningModel', byType())
      jsonPath('$.tags', byType())
      jsonPath('$.label', byType())
      jsonPath('$.language', byType())
      jsonPath('$.assetClass', byType())
      jsonPath('$.objectives', byType())
      jsonPath('$.groups', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.resourcePlan', byType())
      jsonPath('$.resourcePlan[*].label',byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetGraph', byType())
      jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.configuration', byType())
      jsonPath('$.constraints', byType())
      jsonPath('$.extends', byType())
      jsonPath('$.extensions', byType())
      jsonPath('$.scope', byType())
      jsonPath('$._links', byType())
      jsonPath('$._links.self', byType())
      jsonPath('$._links.self.href', byType())
    }
	
    body('''
		{
   "_id":"8883c099-1762-43fe-9ad8-4c9aaa6eafa2",
   "_bssVer":1,
   "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
   "_created":"2018-11-27T04:10:50+00:00",
   "_createdBy":"",
   "_lastModified":"2018-11-27T04:10:50+00:00",
   "_docType":"LEARNINGCONTENT",
   "_assetType":"AGGREGATE",
   "learningModel":{
      "_resourceType":"LEARNINGASSET",
      "_docType":"LEARNINGMODEL",
      "_assetType":"AGGREGATE",
      "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
      "_bssVer":1,
      "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "_links":{
         "self":{
            "href":"/v2/assetModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
         }
      }
   },
   "tags":"REVEL",
   "label":"CHAPTER",
   "language":"en-US",
   "assetClass":"",
   "objectives":"",
   "groups":{

   },
   "resources":{
      "1d9d706a-a1f0-4e48-9d49-bd4211978445":{
         "_id":"1d9d706a-a1f0-4e48-9d49-bd4211978445",
         "_bssVer":1,
         "_ver":"b6671312-87b1-4b66-bc07-851e535d541c",
         "_resourceType":"LEARNINGASSET",
         "_docType":"LEARNINGCONTENT",
         "_assetType":"AGGREGATE",
         "_links":{
            "self":{
               "href":"/v2/aggregates/1d9d706a-a1f0-4e48-9d49-bd4211978445/versions/b6671312-87b1-4b66-bc07-851e535d541c"
            }
         }
      },
      "1ee23e47-c02e-4fa8-a337-c89e6f97460e":{
         "_id":"1ee23e47-c02e-4fa8-a337-c89e6f97460e",
         "_bssVer":1,
         "_ver":"2889be8e-f004-44d3-b5f5-192e3836604f",
         "_resourceType":"LEARNINGASSET",
         "_docType":"LEARNINGCONTENT",
         "_assetType":"AGGREGATE",
         "_links":{
            "self":{
               "href":"/v2/aggregates/1ee23e47-c02e-4fa8-a337-c89e6f97460e/versions/2889be8e-f004-44d3-b5f5-192e3836604f"
            }
         }
      }
   },
   "resourcePlan":[
      {
         "label":"",
         "resourceElementType":"HEADING",
         "resourceRef":"",
         "resourceElements":[
            {
               "label":"slate1",
               "resourceElementType":"slate",
               "resourceElements":[

               ],
               "resourceRef":"1d9d706a-a1f0-4e48-9d49-bd4211978445"
            },
            {
               "label":"slate2",
               "resourceElementType":"slate",
               "resourceElements":[

               ],
               "resourceRef":"1ee23e47-c02e-4fa8-a337-c89e6f97460e"
            }
         ]
      }
   ],
   "assetGraph":[
      {
         "startNode":"self",
         "endNode":"1d9d706a-a1f0-4e48-9d49-bd4211978445",
         "relationships":{

         }
      },
      {
         "startNode":"1d9d706a-a1f0-4e48-9d49-bd4211978445",
         "endNode":"1ee23e47-c02e-4fa8-a337-c89e6f97460e",
         "relationships":{

         }
      }
   ],
   "configuration":{

   },
   "constraints":[

   ],
   "extends":{

   },
   "extensions":{},
   "scope":{

   },
   "_links":{
      "self":{
         "href":"/v2/aggregates/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
      }
   }
}
''')
  }
}