package contracts.aggregatesByVersions.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    urlPath(value(consumer(regex('/lpb/v2/aggregates/'+uuid()+'/versions'))))
	
	
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._count', byType())
      jsonPath('$.versions', byType())
      jsonPath('$.versions[*]._id', byRegex(uuid()))
      jsonPath('$.versions[*]._ver', byRegex(uuid()))
      jsonPath('$.versions[*]._createdBy', byType())
      jsonPath('$.versions[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
      jsonPath('$.versions[*]._docType', byType())
      jsonPath('$.versions[*]._assetType', byType())
      jsonPath('$.versions[*]._links', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.versions[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.versions[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
    }
    body('''
       {
 "_count": 3,
 "versions": [
 {
 "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
 "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae87",
 "_createdBy": "Admin",
 "_bssVer": 1,
 "_docType": "LEARNINGCONTENT",
 "_assetType": "AGGREGATE",
 "_links": {
 "self": {
 "href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/16f6de1c-d5f8-4e0e-8c41-94a68c9cae87"
 }
 }
 },
 {
 "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
 "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae88",
 "_createdBy": "Admin",
 "_bssVer": 1,
 "_docType": "LEARNINGCONTENT",
 "_assetType": "AGGREGATE",
 "_links": {
 "self": {
 "href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/16f6de1c-d5f8-4e0e-8c41-94a68c9cae88"
 }
 }
 },
 {
 "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
 "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae89",
 "_createdBy": "Admin",
 "_bssVer": 1,
 "_docType": "LEARNINGCONTENT",
 "_assetType": "AGGREGATE",
 "_links": {
 "self": {
 "href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/16f6de1c-d5f8-4e0e-8c41-94a68c9cae89"
 }
 }
 }
 ]
}
        ''')
  }
}