package contracts.assessments.error404;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 404"
    request {
        method GET()
    	urlPath($(  consumer(regex('/lpb/v2/assessments/.*')),
        producer('/lpb/v2/assessments/18f67618-1f1f-4f59-a86c-961aacb2806e')))
    
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
    	headers { contentType(applicationJsonUtf8()) }
        status 404
        bodyMatchers {
	      jsonPath('$.timestamp', byType())
	      jsonPath('$.status', byType())
	      jsonPath('$.error', byType())
	      jsonPath('$.message', byType())
        }
        body('''
			{
			  "timestamp": "2018-12-20T10:08:19+00:00",
			  "status": 404,
			  "error": "NOT FOUND",
			  "message": "The requested resource is not available"
			}
        ''')
    }
    priority 2
}
