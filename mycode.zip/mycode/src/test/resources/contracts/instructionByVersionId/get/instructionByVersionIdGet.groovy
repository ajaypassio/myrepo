package contracts.instructionByVersionId.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672'))))
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._id', byRegex(uuid()))
      jsonPath('$._bssVer', byType())
      jsonPath('$._ver', byRegex(uuid()))
      jsonPath('$._created', byType())
      jsonPath('$._createdBy', byType())
      jsonPath('$._lastModified', byType())
      jsonPath('$._docType', byCommand('assertThatDocTypeIsLearningContent($it)'))
      jsonPath('$._assetType', byCommand('assertThatAssetTypeIsInstruction($it)'))
      jsonPath('$.label', byType())
      jsonPath('$.tags', byType())
      jsonPath('$.learningModel', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.resourcePlan', byType())
      jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetGraph', byType())
      jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.configuration', byType())
      jsonPath('$.constraints', byType())
      jsonPath('$.extends', byType())
      jsonPath('$.extensions', byType())
      jsonPath('$.scope', byType())
      jsonPath('$._links', byType())
      jsonPath('$._links.self', byType())
      jsonPath('$._links.self.href', byType())
    }
    body('''
       {
  "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
  "_bssVer": 1,
  "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
  "_created": "2018-11-27T04:10:50+00:00",
  "_createdBy": "Admin",
  "_lastModified": "2018-11-27T04:10:50+00:00",
  "_docType": "LEARNINGCONTENT",
  "_assetType": "INSTRUCTION",
  "label": "INSTRUCTION",
  "tags": "REVEL",
  "learningModel": {
    "_resourceType": "LEARNINGASSET",
    "_docType": "LEARNINGCONTENT",
    "_assetType": "INSTRUCTION",
    "_id": "d65ecb2a-5f88-469f-8729-a59992621494",
    "_bssVer": 1,
    "_ver": "4443ecaa-ddb7-4969-ad69-7a5fbbdee7b7",
    "_links": {
      "self": {
        "href": "/v2/assetModels/d65ecb2a-5f88-469f-8729-a59992621494/versions/4443ecaa-ddb7-4969-ad69-7a5fbbdee7b7"
      }
    }
  },
  "resources": {
    "59ef75be-17a3-49cd-8d9f-82a133d7f71f": {
      "_id": "59ef75be-17a3-49cd-8d9f-82a133d7f71f",
      "_bssVer": 1,
      "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "createdBy": "Admin",
      "_resourceType": "LEARNINGASSET",
      "_docType": "LEARNINGCONTENT",
      "_assetType": "NARRATIVE",
      "_links": {
        "self": {
          "href": "/v2/narratives/59ef75be-17a3-49cd-8d9f-82a133d7f71f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
        }
      }
    },
    "7e501ab1-1ee8-42ee-9ebf-1cd3e1e2244e": {
      "_id": "7e501ab1-1ee8-42ee-9ebf-1cd3e1e2244e",
      "_bssVer": 1,
      "_ver": "e00765cb-1cff-4c73-99b6-d289d431f99b",
      "createdBy": "Admin",
      "_resourceType": "LEARNINGASSET",
      "_docType": "LEARNINGCONTENT",
      "_assetType": "NARRATIVE",
      "_links": {
        "self": {
          "href": "/v2/narratives/7e501ab1-1ee8-42ee-9ebf-1cd3e1e2244e/versions/e00765cb-1cff-4c73-99b6-d289d431f99b"
        }
      }
    }
  },
  "resourcePlan": [
    {
      "label": "",
      "resourceElementType": "HEADING",
      "resourceRef": "",
      "resourceElements": [
        {
          "label": "slate1",
          "resourceElementType": "slate",
          "resourceElements": [],
          "resourceRef": "59ef75be-17a3-49cd-8d9f-82a133d7f71f"
        },
        {
          "label": "slate2",
          "resourceElementType": "slate",
          "resourceElements": [],
          "resourceRef": "7e501ab1-1ee8-42ee-9ebf-1cd3e1e2244e"
        }
      ]
    }
  ],
  "assetGraph": [
    {
      "startNode": "self",
      "endNode": "59ef75be-17a3-49cd-8d9f-82a133d7f71f",
      "relationships": {
        
      }
    },
    {
      "startNode": "59ef75be-17a3-49cd-8d9f-82a133d7f71f",
      "endNode": "7e501ab1-1ee8-42ee-9ebf-1cd3e1e2244e",
      "relationships": {
        
      }
    }
  ],
  "configuration": {
    
  },
  "constraints": [],
  "extends": {
    
  },
  "extensions": {},
  "scope": {
    
  },
  "_links": {
    "self": {
      "href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
    }
  }
}
        ''')
  }
  priority 1
}