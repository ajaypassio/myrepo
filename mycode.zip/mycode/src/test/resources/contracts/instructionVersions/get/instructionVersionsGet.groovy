package contracts.instructionVersions.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/instructions/'+uuid()+'/versions')), producer('/lpb/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions')))
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._count', byType())
      jsonPath('$.versions', byType())
      jsonPath('$.versions[*]._id', byRegex(uuid()))
      jsonPath('$.versions[*]._ver', byRegex(uuid()))
      jsonPath('$.versions[*]._createdBy', byType())
      jsonPath('$.versions[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
      jsonPath('$.versions[*]._docType', byCommand('assertThatDocTypesAreLearningContent($it)'))
      jsonPath('$.versions[*]._assetType', byCommand('assertThatAssetTypesAreInstruction($it)'))
      jsonPath('$.versions[*]._links', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.versions[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.versions[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
    }
    body('''
       {
  "_count": 3,
  "versions": [
    {
      "_id": "24f1966f-4e7c-4115-8a57-a289e8b45c8c",
      "_ver": "ab3d4b43-af9c-43f0-9374-5294748f1b01",
      "_createdBy": "Admin",
      "_bssVer": 1,
      "_docType": "LEARNINGCONTENT",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions/ab3d4b43-af9c-43f0-9374-5294748f1b01"
        }
      }
    },
    {
      "_id": "24f1966f-4e7c-4115-8a57-a289e8b45c8c",
      "_ver": "7cdb5001-727f-4fdd-9dc6-1ba967bd2f37",
      "_createdBy": "Admin",
      "_bssVer": 1,
      "_docType": "LEARNINGCONTENT",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions/7cdb5001-727f-4fdd-9dc6-1ba967bd2f37"
        }
      }
    },
    {
      "_id": "24f1966f-4e7c-4115-8a57-a289e8b45c8c",
      "_ver": "426e3ab6-d7fd-4c9c-adc8-fbffdc466c6c",
      "_createdBy": "Admin",
      "_bssVer": 1,
      "_docType": "LEARNINGCONTENT",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions/426e3ab6-d7fd-4c9c-adc8-fbffdc466c6c"
        }
      }
    }
  ]
}
        ''')
  }
}