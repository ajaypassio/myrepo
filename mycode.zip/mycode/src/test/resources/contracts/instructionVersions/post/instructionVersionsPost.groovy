package contracts.instructionVersions.post;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
  description "."
  request {
    method POST()
    url(value(consumer(regex('/lpb/v2/instructions/'+uuid()+'/versions')), producer('/lpb/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions')))
    headers {
      header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(
        "updateRequest": $(
        "isMajorChange": $(consumer(regex('true|false')), producer('true')),
        "reason": $(consumer(regex('.*')))
        ),
        "asset": $(
        "contentMetadata": $(
        "id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a')),
        "version": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('b1e38cf9-aa76-43bd-94da-31197cb33130'))
        ),
        "learningModel": $(
        "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
        "_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
        "_assetType": $(consumer('INSTRUCTION'), producer('INSTRUCTION')),
        "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
        "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
        "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'))
        ),
        "tags": $(consumer(regex('\\w+')), producer('REVEL')),
        "label": $(consumer(regex('\\w+')), producer('CHAPTER')),
        "language": $(consumer(regex('.*')), producer('en-US')),
        "assetClass": $(consumer(regex('.*')), producer('')),
        "objectives": $(consumer(regex('.*')), producer('')),
        // "groups" : {},

        "resources": $(
        "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f": $(
        "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
        "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
        "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
        "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
        "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
        "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
        "_assetType": $(consumer(regex('NARRATIVE')), producer('NARRATIVE'))
        ),
        "0ba5f959-de96-4c03-a95b-ede6ffba9b4c": $(
        "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c')),
        "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
        "_ver":  $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('5a811b23-7131-4273-b977-a0da1ad6f38b')),
        "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
        "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
        "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
        "_assetType": $(consumer(regex('NARRATIVE')), producer('NARRATIVE'))
        )
        ),
        "assetGraph": [
          $(
          "startNode": $(consumer(regex('.+')), producer('self')),
          "endNode": $(consumer(regex('.+')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'))
          // "relationships": {}
          ),
          $(
          "startNode": $(consumer(regex('.+')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
          "endNode": $(consumer(regex('.+')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c'))
          //"relationships": {}
          )
        ],
        "resourcePlan": [
          $(
          "label": $(consumer(regex('[A-Za-z]+')), producer('BLOCK')),
          "resourceElementType": $(consumer(regex('[A-Za-z]+')), producer('HEADING')),
          "resourceRef":  $(consumer(regex('.*')), producer('resourceRef')),
          "resourceElements": [
            $(
            "label": $(consumer(regex('.+')), producer('slate1')),
            "resourceElementType": $(consumer(regex('.+')), producer('slate')),
            "resourceElements": [],
            "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'))
            ),
            $(
            "label": $(consumer(regex('.+')), producer('slate2')),
            "resourceElementType": $(consumer(regex('.+')), producer('slate')),
            "resourceElements": [],
            "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c'))
            )
          ]
          )
        ],
        // "configuration": $({}),
        "constraints": []
        //"extends": {},
        //"extensions": {},
        //"scope": {}
        )
        )
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 201
    bodyMatchers {
      jsonPath('$.asset', byType())
      jsonPath('$.asset._id', byRegex(uuid()))
      jsonPath('$.asset._ver', byRegex(uuid()))
      jsonPath('$.asset._bssVer', byType())
      jsonPath('$.asset._createdBy', byType())
      jsonPath('$.asset._docType', byCommand('assertThatDocTypeIsLearningContent($it)'))
      jsonPath('$.asset._assetType', byCommand('assertThatAssetTypeIsInstruction($it)'))
      jsonPath('$.asset._links', byType())
      jsonPath('$.asset._links.self', byType())
      jsonPath('$.asset._links.self.href', byType())
      jsonPath('$.contentMetadata', byType())
      jsonPath('$.contentMetadata.id', byType())
      jsonPath('$.contentMetadata.version', byType())
      jsonPath('$.entityStatus', byType())
	  jsonPath('$.status', byType())
    }
    body('''{
  "asset": {
    "_id": "24f1966f-4e7c-4115-8a57-a289e8b45c8c",
    "_ver": "426e3ab6-d7fd-4c9c-adc8-fbffdc466c6c",
    "_bssVer": 1,
    "_createdBy": "Admin",
    "_docType": "LEARNINGCONTENT",
    "_assetType": "INSTRUCTION",
    "_links": {
      "self": {
        "href": "/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions/426e3ab6-d7fd-4c9c-adc8-fbffdc466c6c"
      }
    }
  },
  "contentMetadata": {
    "id": "37711975-e1ea-489e-a040-2658979d2cd5",
    "version": "44f04c37-008b-4872-a619-8c5e6ee427ed"
  },
  "entityStatus": "Success",
  "status": 201 
}''')
  }
}