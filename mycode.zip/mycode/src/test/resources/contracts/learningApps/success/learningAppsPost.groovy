package contracts.learningApps.success;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
  description "."
  request {
	method POST()
	urlPath('/lpb/v2/learningApps')
	headers {
	  header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(
        "assets": [
          $(
          "learningModel": $(
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
           "_assetType": $(consumer('LEARNINGAPP'), producer('LEARNINGAPP')),
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d7f436ad-9fe2-456b-bdbb-52603c1ae949')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('e109b19b-29ce-4caf-bff5-6fe9b1da9b5c'))
          ),
          "resources": $(
          "3e17260b-3ccd-4fd4-bff1-b622012351f4": $(
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('1b5353c2-c203-4008-81ef-3256ea56a2d4')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
          "_assetType": $(consumer('LEARNINGAPP-ITEM'), producer('LEARNINGAPP-ITEM'))
          ),
          "18c06ad5-a247-42ff-b3ac-8525cf097ae4": $(
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('18c06ad5-a247-42ff-b3ac-8525cf097ae4')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver":  $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('5a811b23-7131-4273-b977-a0da1ad6f38b')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
          "_assetType": $(consumer('LEARNINGAPP-ITEM'), producer('LEARNINGAPP-ITEM'))
          )
          ),
          "assetGraph": [
            $(

            "startNode": $(consumer(regex('.+')), producer('self')),
            "endNode": $(consumer(regex('.+')), producer('self'))
            // "relationships": {}

            ),
            $(
            "startNode": $(consumer(regex('.+')), producer('self')),
            "endNode": $(consumer(regex('.+')), producer('self'))
            //"relationships": {}
            )
          ],
          "resourcePlan": [
            $(
            "label": $(consumer(regex('[A-Za-z0-9 ]+')), producer('Learning App 1')),
            "resourceElementType": $(consumer(regex('[A-Za-z]+')), producer('writingsolutions')),
            "resourceRef":  $(consumer(regex('.*')), producer('32f42ce8')),
            "resourceElements": [
          
            ]
            )
          ],
         "configuration": $(
optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
),
         "constraints": [],
        "extends":  $(
optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
),
        "extensions":  $(
optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
),
         "scope":  $(
optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
)
          )
        ]
        )
  }
  response {
    headers {   contentType('''application/stream+json; application/hal+json; charset=UTF-8''')  }
	status 207
	bodyMatchers {
	  jsonPath('$.asset', byType())
	  jsonPath('$.status', byType())
	  jsonPath('$.asset._id', byRegex(uuid()))
	  jsonPath('$.asset._ver', byRegex(uuid()))
	  jsonPath('$.asset._bssVer', byType())
	  jsonPath('$.asset._docType', byCommand('assertThatDocTypeIsLearningContent($it)'))
	  jsonPath('$.asset._assetType', byCommand('assertThatAssetTypeIsLearningApp($it)'))
	  jsonPath('$.asset._links', byType())
	  jsonPath('$.asset._links.self', byType())
	  jsonPath('$.asset._links.self.href', byType())
	  jsonPath('$.contentMetadata', byType())
	  jsonPath('$.contentMetadata.id', byType())
	  jsonPath('$.contentMetadata.version', byType())
	  jsonPath('$.entityStatus', byType())
	}
	body('''
{
 "entityStatus": "Success",
 "status": 201,
 "contentMetadata": {
   "id": "0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
   "version": "0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
 },
 "asset": {
   "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
   "_bssVer": 1,
   "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
   "_docType": "LEARNINGCONTENT",
   "_assetType": "LEARNINGAPP",
   "_links": {
     "self": {
       "href": "/v2/learningApps/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
     }
   }
 }
}
''')
  }
  priority 1
}