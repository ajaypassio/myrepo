package contracts.policyGroupByProductModelIdVersion.error404;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "GET Policy group from Product Model by id and version :: should return 404 for invalid value of query param."
    priority 2
    request {
          method GET()
          url(value(consumer(regex('/lpb/v2/productModels/.*/versions/.*')))){
          queryParameters {
          parameter 'fields': value(consumer(matching(".*")), producer("configuration"))
          }
      }
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
    	headers { contentType(applicationJsonUtf8()) }
        status 404
        bodyMatchers {
	      jsonPath('$.timestamp', byType())
	      jsonPath('$.status', byType())
	      jsonPath('$.error', byType())
	      jsonPath('$.message', byType())
        }
        body('''
			{
    "status": 404,
    "error": "Not Found",
    "message": "Product model configuration does not exists.",
    "timestamp": "2019-02-28T08:22:01+00:00"
}
        ''')
    }
}
