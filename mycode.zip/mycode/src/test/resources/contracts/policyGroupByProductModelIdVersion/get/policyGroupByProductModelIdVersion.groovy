package contracts.policyGroupByProductModelIdVersion.get;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "GET Policy group from Product Model by id and version"
  priority 1
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/productModels/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/81480dd1-80d1-4393-8db7-7d90d633ad36')))){
      queryParameters {
        parameter 'fields': value(consumer(matching("configuration")), producer("configuration"))
      }
    }
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers { contentType('''application/hal+json; charset=UTF-8''') }
    status 200
    bodyMatchers {
      jsonPath('$._id', byType())
      jsonPath('$._ver', byType())
      jsonPath('$._bssVer', byType())
      jsonPath('$._links', byType())
      jsonPath('$._links.self', byType())
      jsonPath('$._links.self.href', byType())
      jsonPath('$.configuration', byType())
      jsonPath('$.configuration.policyGroups', byType())
    }
    body('''
{
    "_id": "0296f146-e15c-4d3e-8edd-89e59bd50f27",
    "_ver": "c5ef1ee9-5025-46e0-b48e-a6d43119996a",
    "_bssVer": 1,
    "_links": {
        "self": {
               "href": "/v2/productModels/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/c5ef1ee9-5025-46e0-b48e-a6d43119996a"
        }
    },
    "configuration": {
        "policyGroups": [
            "REVEL_DEFAULT"
        ]
    }
}
        ''')
  }
}
