package contracts.product.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method GET()
		urlPath(value(consumer(regex('/lpb/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456'))))
		headers {
			header('''Accept''', applicationJson())
		}
	}
	response {
		headers {   contentType('''application/hal+json; charset=UTF-8''')  }
		status 200
		bodyMatchers {
			jsonPath('$.assetGraph', byType())
			jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan', byType())
			jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElements', byType())
			jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.configuration', byType())
			jsonPath('$._ver', byType())
			jsonPath('$.groups', byType())
			jsonPath('$.language',  byType())
			jsonPath('$.label',  byType())
			jsonPath('$.assetClass',  byType())
			jsonPath('$.constraints', byType())
			jsonPath('$.tags',  byType())
			jsonPath('$._docType',  byType())
			jsonPath('$.extensions', byType())
			jsonPath('$.extends', byType())
			jsonPath('$._bssVer',  byType())
			jsonPath('$._createdBy',  byType())
			jsonPath('$.scope', byType())
			jsonPath('$._created', byType())
      jsonPath('$.expiresOn', byType())
      jsonPath('$._lastModified', byType())
			jsonPath('$.objectives', byType())
			jsonPath('$._id', byRegex(uuid()))
			jsonPath('$.learningModel', byType())
			jsonPath('$._assetType', byType())
			jsonPath('$._links',  byType())
			jsonPath('$._links.self',  byType())
			jsonPath('$._links.self.href', byType())
		}
		body('''
{
    "assetGraph": [
        {
            "startNode": "self",
            "endNode": "32f42ce8",
            "relationships": {}
        },
        {
            "startNode": "32f42ce8",
            "endNode": "self",
            "relationships": {}
        }
    ],
    "resourcePlan": [
        {
            "label": "INDEX",
            "resourceElementType": "HEADING",
            "resourceRef": "",
            "resourceElements": [
                {
                    "label": "INDEX",
                    "resourceElementType": "INDEX",
                    "resourceElements": [],
                    "resourceRef": "32f42ce8"
                }
            ]
        }
    ],
    "configuration": {
    	"policyGroups" : ["Revel_Default_8883c099-1762-43fe-9ad8-4c9aaa6eafa2::200a3768-17af-4f2f-9d4c-b07c6cdfc456",
            "TITLE_8883c099-1762-43fe-9ad8-4c9aaa6eafa2::200a3768-17af-4f2f-9d4c-b07c6cdfc456"]
    },
    "_links": {
        "self": {
            "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456"
        },
        "status": {
            "href": "/v2/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/status"
        }
    },
    "_ver": "200a3768-17af-4f2f-9d4c-b07c6cdfc456",
    "groups": {},
    "resources": {
        "32f42ce8": {
            "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
            "_bssVer": 1,
            "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
            "_resourceType": "LEARNINGASSET",
            "_docType": "LEARNINGCONTENT",
            "_assetType": "AGGREGATE",
            "_links": {
                "self": {
                    "href": "/v2/aggregates/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
                }
            }
        }
    },
    "language": "en-US",
    "label": "PRODUCT",
    "assetClass": "",
    "_assetType": "PRODUCT",
    "constraints": [],
    "tags": "REVEL",
    "_docType": "LEARNINGCONTENT",
    "extensions": {
		"contentMetadata":{
			"id": "dcd035ca-bc1a-11e8-a355-529269fb1459",
			"version": "06aa73bd-db72-4210-a88a-8c24ab3ff789"
		}
	},
    "extends": {},
    "_bssVer": 1,
    "_createdBy": "Admin",
    "learningModel": {
        "_resourceType": "LEARNINGASSET",
        "_docType": "LEARNINGMODEL",
        "_assetType": "PRODUCT",
        "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
        "_bssVer": 1,
        "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
        "_links": {
            "self": {
                "href": "/v2/productModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
            }
        }
    },
    "_created": "2018-11-27T04:10:50+00:00",
    "_lastModified": "2018-08-01T03:54:46+00:00",
    "expiresOn": "2020-12-12T18:29:50+00:00",
    "scope": {},
    "objectives": "",
    "_id": "8883c099-1762-43fe-9ad8-4c9aaa6eafa2"
}
''')
	}
    priority 1
}