package contracts.productAssetTypes.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
        urlPath($(consumer(regex('/lpb/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/.*')),
                producer('/lpb/v2/products/243b49fb-24a0-4081-8970-efd55773f32b/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc671/assetTypes')))
        headers {
            header('''Accept''', applicationJson())
        }
    }

    response {
        headers {
            contentType('''application/hal+json; charset=UTF-8''')
        }
        status 404
        bodyMatchers {
            jsonPath('$.timestamp', byType())
            jsonPath('$.status', byType())
            jsonPath('$.error', byType())
            jsonPath('$.message', byType())
        }
        body(
                '''{
				"timestamp": "2018-11-27T04:10:50+00:00",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Requested Resource Not Found"
			}'''
        )
    }
    priority 2
}
