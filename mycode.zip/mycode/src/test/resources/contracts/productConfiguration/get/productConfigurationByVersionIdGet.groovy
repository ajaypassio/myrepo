package contracts.productConfiguration.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
        urlPath($(consumer('/lpb/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672'),
                producer('/lpb/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')))
        {
            queryParameters {
                parameter("fields", "configuration")
            }
        }
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
        headers {   contentType('''application/hal+json; charset=UTF-8''')  }
        status 200
        bodyMatchers {
            jsonPath('$._id', byType())
            jsonPath('$._ver', byType())
            jsonPath('$._bssVer', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self',byType())
            jsonPath('$._links.self.href', byType())
            jsonPath('$.configuration', byType())
        }
        body('''
		{
   "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
   "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
   "_bssVer": 1,
   "_links": {
       "self": {
           "href": "/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
       }
   },
   "configuration": {
       "policyGroups": [
           "REVEL_Default_46d14271-baa9-4b51-9847-6de209a2e5cf::6dfcdcba-f8e3-4e8f-9a1d-e127b8b116da",
           "TITLE_46d14271-baa9-4b51-9847-6de209a2e5cf::6dfcdcba-f8e3-4e8f-9a1d-e127b8b116da"
       ]
   }
}
    ''')
    }
    priority 1
}


