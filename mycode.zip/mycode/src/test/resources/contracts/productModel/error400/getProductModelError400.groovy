package contracts.productModel.error400;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "ERROR 400"
  request {
    method GET()
    urlPath('/lpb/v2/productModels') {
      queryParameters {
        parameter("collectionDetail", "label")
      }
    }
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers { contentType('''application/hal+json; charset=UTF-8''') }
    status 400
    bodyMatchers {
      jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
    }
    body('''
      {
        "timestamp": "2019-01-30T06:54:03+00:00",
        "status": 400,
        "error": "Bad Request",
        "message": "Invalid URL. Mention valid search parameter."
      }
    ''')
  }
  priority 2
}