package contracts.productModel.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
     urlPath('/lpb/v2/productModels')
     {
     queryParameters {
    parameter("collectionDetails", "label")
    }
  }
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
        headers { contentType('''application/hal+json; charset=UTF-8''') }
        status 200
        bodyMatchers {
            jsonPath('$._count', byType())
            jsonPath('$.productModels', byType())
            jsonPath('$.productModels[*]._id', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.productModels[*]._ver', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._docType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._assetType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._links', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].label', byCommand('assertThatValueIsAString($it)'))
        }
        body('''
       {
    "_count": 1,
    "productModels": [
        {
            "_id": "8277ab2e-bf8d-4640-8582-78386e08bb23",
            "_bssVer": 1,
            "_ver": "9916b162-f0b5-456f-be27-c5ea6ffdffbe",
            "_docType": "LEARNINGMODEL",
            "_assetType": "PRODUCT",
            "_links": {
                "self": {
                    "href": "/v2/productModels/8277ab2e-bf8d-4640-8582-78386e08bb23/versions/9916b162-f0b5-456f-be27-c5ea6ffdffbe"
                }
            },
            "label": "PRODUCT"
        }
    ]
}
        ''')
    }
    priority 1
}

