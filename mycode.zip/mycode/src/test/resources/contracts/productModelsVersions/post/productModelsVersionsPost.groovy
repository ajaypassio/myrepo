package contracts.productModelsVersions.post

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method POST()
		url(value(consumer(regex('/lpb/v2/productModels/'+uuid()+'/versions')), producer('/lpb/v2/productModels/9cc1ef68-a2f5-49ea-a70d-3c451f94bb99/versions')))
		body('''
            {
                "_assetType": "PRODUCT",
                "expiresOn": "2020-12-12T18:29:50+00:00",
                "label": "PRODUCT",
                "_createdBy": "Admin",
                "tags": "REVEL",
                "language": "en_US",
                "assetClass": "",
                "objectives": "",
                "groups": {
                },
                "resources": {
                  "d441ee2a-4475-4511-969c-80cbbeba553e": {
                    "_resourceType": "INLINED",
                    "category": "model",
                    "data": {
                      "keyPattern": "INDEX-%5CS",
                      "categorySchema": {
                        "type": "object",
                        "minProperties": 1,
                        "maxProperties": 1
                      },
                      "instanceSchema": {
                        "type": "object",
                        "required": [
                          "_docType",
                          "_assetType"
                        ],
                        "properties": {
                          "_resourceType": {
                            "type": "string",
                            "enum": [
                              "LEARNINGASSET"
                            ]
                          },
                          "_docType": {
                            "type": "string",
                            "enum": [
                              "LEARNINGCONTENT"
                            ]
                          },
                          "_assetType": {
                            "type": "string",
                            "enum": [
                              "AGGREGATE"
                            ]
                          }
                        }
                      },
                      "instanceModel": {
                        "_id": "c24e2e28-4817-413e-85f3-b9dc32ebf401",
                        "_bssVer": 1,
                        "_ver": "c5ef1ee9-5025-46e0-b48e-a6d43119996a",
                        "_resourceType": "LEARNINGASSET",
                        "_docType": "LEARNINGMODEL",
                        "_assetType": "AGGREGATE"
                      }
                    }
                  }
                },
                "assetGraph": [
                  {
                    "relationships": {
                    },
                    "startNode": "self",
                    "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e"
                  },
                  {
                    "relationships": {
                    },
                    "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                    "endNode": "self"
                  }
                ],
                "resourcePlan": [
                  {
                    "label": "INDEX",
                    "resourceElementType": "INDEX",
                    "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                    "resourceElements": [
                    ]
                  }
                ],
                "configuration": {
                },
                "constraints": [
                ],
                "extends": {
                },
                "extensions": {
                },
                "scope": {
                }
              }

        ''')
        bodyMatchers {
            jsonPath('$._assetType', byRegex('[a-zA-Z]*'))
            jsonPath('$.expiresOn', byRegex(iso8601WithOffset()))
            jsonPath('$.label', byRegex(alphaNumeric()))
            jsonPath('$._createdBy', byRegex('[a-zA-Z]*'))
            jsonPath('$.tags', byRegex(alphaNumeric()))
            jsonPath('$.language', byRegex('[a-z]{2}[_][A-Za-z]{2}'))
            jsonPath('$.assetClass', byRegex('[a-zA-Z]*'))
            jsonPath('$.objectives', byEquality())
            jsonPath("\$.['assetGraph'][*].['startNode']", byRegex('[\\w-]+'))
            jsonPath("\$.['assetGraph'][*].['endNode']", byRegex('[\\w-]+'))
            jsonPath("\$.['resourcePlan'][*].['label']", byRegex('[\\w]+'))
            jsonPath("\$.['resourcePlan'][*].['resourceElementType']", byRegex('[\\w]+'))
            jsonPath("\$.['resourcePlan'][*].['resourceRef']", byRegex('[\\w-]+'))
        }
		headers {
			header('''Accept''', applicationJson())
      contentType(applicationJson())
		}
	}
	response {
		headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
		status 201
		bodyMatchers {
            jsonPath('$._id', byType())
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byType())
            jsonPath('$._created', byType())
            jsonPath('$._createdBy', byType())
            jsonPath('$._lastModified', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$.expiresOn', byType())
            jsonPath('$.label', byType())
            jsonPath('$.tags', byType())
            jsonPath('$.language', byType())
            jsonPath('$.assetClass', byType())
            jsonPath('$.objectives', byType())
            jsonPath('$.groups', byType())
            jsonPath('$.resources', byType())
            jsonPath('$.assetGraph', byType())
            jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.resourcePlan', byType())
            jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.configuration', byType())
            jsonPath('$.constraints', byType())
            jsonPath('$.extends', byType())
            jsonPath('$.extensions', byType())
            jsonPath('$.scope', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
        }
		body('''
        {
            "_id": "0296f146-e15c-4d3e-8edd-89e59bd50f27",
            "_bssVer": 1,
            "_ver": "18f67618-1f1f-4f59-a86c-961aacb2806e",
            "_created": "2018-11-27T04:10:50+00:00",
            "_createdBy": "Admin",
            "_lastModified": "2018-11-27T04:10:50+00:00",
            "_docType": "LEARNINGMODEL",
            "_assetType": "PRODUCT",
            "expiresOn": "2020-12-12T18:29:50+00:00",
            "label": "PRODUCT",
            "tags": "REVEL",
            "language": "en_US",
            "assetClass": "",
            "objectives": "",
            "groups": {
              
            },
            "resources": {
              "d441ee2a-4475-4511-969c-80cbbeba553e": {
                "_resourceType": "INLINED",
                "category": "model",
                "data": {
                  "keyPattern": "INDEX-%5CS",
                  "categorySchema": {
                    "type": "object",
                    "minProperties": 1,
                    "maxProperties": 1
                  },
                  "instanceSchema": {
                    "type": "object",
                    "required": [
                      "_docType",
                      "_assetType"
                    ],
                    "properties": {
                      "_resourceType": {
                        "type": "string",
                        "enum": [
                          "LEARNINGASSET"
                        ]
                      },
                      "_docType": {
                        "type": "string",
                        "enum": [
                          "LEARNINGCONTENT"
                        ]
                      },
                      "_assetType": {
                        "type": "string",
                        "enum": [
                          "AGGREGATE"
                        ]
                      }
                    }
                  },
                  "instanceModel": {
                    "_id": "c24e2e28-4817-413e-85f3-b9dc32ebf401",
                    "_bssVer": 1,
                    "_ver": "c5ef1ee9-5025-46e0-b48e-a6d43119996a",
                    "_resourceType": "LEARNINGASSET",
                    "_docType": "LEARNINGMODEL",
                    "_assetType": "AGGREGATE",
                    "_links": {
                      "self": {
                        "href": "/v2/productModels/c24e2e28-4817-413e-85f3-b9dc32ebf401/versions/c5ef1ee9-5025-46e0-b48e-a6d43119996a"
                      }
                    }
                  }
                }
              }
            },
            "assetGraph": [
              {
                "relationships": {
                  
                },
                "startNode": "self",
                "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e"
              },
              {
                "relationships": {
                  
                },
                "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                "endNode": "self"
              }
            ],
            "resourcePlan": [
              {
                "label": "INDEX",
                "resourceElementType": "INDEX",
                "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                "resourceElements": []
              }
            ],
            "configuration": {
              
            },
            "constraints": [],
            "extends": {
              
            },
            "extensions": {
              
            },
            "scope": {
              
            },
            "_links": {
              "self": {
                "href": "/v2/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/18f67618-1f1f-4f59-a86c-961aacb2806e"
              }
            }
          }
    '''
        )
	}
}