package contracts.productState.error406;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "Error 406"
  request {
    method GET()
    urlPath($(  consumer(regex('/lpb/v2/products/.*/versions/.*/stateTransitions')),
        producer('/lpb/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/18f67618-1f1f-4f59-a86c-961aacb2806e/stateTransitions')))
    headers {
      header('''Accept''', applicationJson())
    }
    }
  response {
    headers {   contentType(applicationJsonUtf8())  }
    status 406
    bodyMatchers {
      jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
    }
    body('''
    {
      "timestamp": "2018-12-20T10:08:19+00:00",
      "status": 406,
      "error": "NOT ACCEPTED",
      "message": "The resource cannot provide a representation that meets the request requirements in regards of its Accept"
    }
    ''')
  }
  priority 4
}