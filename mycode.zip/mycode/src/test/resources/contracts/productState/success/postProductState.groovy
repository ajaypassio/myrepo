package contracts.productState.success

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "Created 201"
	request {
		method POST()
		url $(consumer('/lpb/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1/stateTransitions'), 
            producer('/lpb/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1/stateTransitions'))		
		body(
            transitionState: $(consumer(regex('.+')),producer('LIVE')),
            contentMetadata: $(
                id: $(consumer(regex('.+')),producer('123456789')),
                version: $(consumer(regex('.+')),producer('123456789'))
                ),
            reason: $(consumer(regex('.+')),producer('Title Live after review')),
            reasonCode: $(consumer(regex('.+')),producer('157'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType('''application/hal+json; charset=UTF-8''')
			  }
		status 201
		bodyMatchers {
			jsonPath('$._id', byType())
			jsonPath('$._ver', byType())
			jsonPath('$._created', byType())
			jsonPath('$._lastModified', byType())
			jsonPath('$.previousState', byType())
			jsonPath('$.transitionState', byType())
			jsonPath('$.reason', byType())
			jsonPath('$.reasonCode', byType())
			jsonPath('$._links', byType())
			jsonPath('$._links.self', byType())
			jsonPath('$._links.self.href', byType())
      jsonPath('$._links.status', byType())
      jsonPath('$._links.status.href', byType())
		}
		body('''{
              "_id": "fc989a74-57e0-4be4-89c9-13e7dc75d293",
              "_ver": "bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1",
              "_created": "2018-05-18T19:16:15+00:00",
              "_lastModified": "2018-05-18T19:16:15+00:00",
              "previousState": "REVIEW",
              "transitionState": "LIVE",
              "reason": "Title Live after review",
              "reasonCode": "157",
              "_links": {
                "self": {
                  "href": "/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1"
                },
                "status": {
                  "href": "/v2/products/5cc49de2-734c-491f-b10c-0e084c5bae31/status"
                }
              }
            }''')
	}
	priority 1
}