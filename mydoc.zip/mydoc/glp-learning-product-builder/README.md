# Learning Product Builder
LPB creates the bundles of content and non-content Learning Assets (LA) and the Learning Model into a salable unit or a GLP product. It mainly assembles and structures LAs based on the given Learning Model. Products are the means by which GLP can create tailored Learning Experiences from authored content. The provisioning of authored products is done by the Learning Product Builder (LPB) microservice, in the publishing domain. Learning Models define how a set of Learning Assets can be combined and delivered. Products are as instances of those Learning Models, that is Learning Models of Asset Type "Product", which complete their structure with a selected set of Learning Assets and tailored configurations (when available).

### Documentation
[Technical documentation](https://one-confluence.pearson.com/display/GLPOCCC/HLD+-+Publishing+Domain) for LPB microservice.

### Prerequisites
  * Software: glp-learning-product-builder
  * JDK 1.8
  * Spring Boot.
  * Spring Reactive.
  * For Persistence, we are using Couchbase Server.
  * Netty as Embedded Server.
  * slf4j is used for logging.
  * Gradle 4.10 is used to build project.
  * For Static Code Analysis, we  use  Sonar for generating reports.
  * For Code Coverage Analysis, we use Jacoco.

### Installation and Build

  1. Move to the base of microservice folder i.e. ${PROJECT_CHECKOUT_FOLDER}\glp-learning-product-builder.

  2. Add proot id,password in gradle.properties.
  
  3. Run "gradle clean spotlessApply build" to build the project with unit test cases. It applies spotless formatting as well.

  4. Run "gradle clean spotlessApply build -x test" to build all the project without unit test cases.

  5. Import  the project to the IDE.  
  

#### Database 
  
  Add/edit database related information like bucketName,cluster username,cluster password at ${PROJECT_CHECKOUT_FOLDER}\glp-learning-product-builder\
  src\main\resources\application.properties .To enable auto indexing, couchbase auto-index is set to true.
   

#### Configs

  ###### Application configuration
  Add/edit application level properties at ${PROJECT_CHECKOUT_FOLDER}\glp-learning-product-builder\src\main\resource\application.properties.Edit config.home path in application.properties to the one mentioned in dockerfile.
  
  ###### Sonar configuration
  Add/edit sonar properties at ${PROJECT_CHECKOUT_FOLDER}\glp-learning-product-builder\config\sonar.properties.
 
  ###### Dockerfile
  Location of executable jar,config path of the service are specified at ${PROJECT_CHECKOUT_FOLDER}\glp-learning-product-builder\Dockerfile 

### Running the MicroService
   Move to the ${PROJECT_CHECKOUT_FOLDER}\glp-learning-product-builder\build\libs
   Execute command: java -jar lpb-0.0.1-SNAPSHOT-exec.jar

### Coding style tests 
   1. Code is fully reactive,no blocking code has been implemented.
   2. This project use Spotless Java to test coding styles.
   3. Code and branch coverage of the project is maintained greater than or equal to 80 percent.

### Deployment

##### PR build Job 

   Jenkins job url for PR build is available at (https://jenkins.gl-poc.com/blue/organizations/jenkins/PR-build-revel-learning-product-builder/)

##### Master build job

   Jenkins job url for master build is available at (https://jenkins.gl-poc.com/view/Revel-Gradle-Build-Jobs/job/GLP-Revel-Gradle-Builder-lpb/)


### Versioning

  API versioning is followed.

### License
PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 Copyright (c) 2017 Pearson Education, Inc.
 All Rights Reserved. 

 NOTICE: All information contained herein is, and remains the property of Pearson Education, Inc. The intellectual and technical concepts contained 
 herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 and Foreign Patents, patent applications, and are protected by trade secret 
 or copyright law. Dissemination of this information, reproduction of this  
 material, and copying or distribution of this software is strictly forbidden   
 unless prior written permission is obtained from Pearson Education, Inc.