/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import lombok.experimental.UtilityClass;

/**
 * The Class CommonConstants.
 * 
 * @author srishti.singh
 */

/**
 * Instantiates a new common constants.
 */
@UtilityClass
public class CommonConstants {

  /** The Constant ASSET_MODELS_ROUTE_URL. */
  public static final String ASSET_MODELS_ROUTE_URL = "/v2/assetModels/";

  /** The Constant VERSIONS_URL. */
  public static final String VERSIONS_URL = "/versions/";

  /** The Constant CREATED. */
  public static final String CREATED = "_created";

  /** The Constant PRODUCT_MODEL_ROUTE_URL. */
  public static final String PRODUCT_MODEL_ROUTE_URL = "/v2/productModels/";

  /** The Constant PRODUCT. */
  public static final String PRODUCT = "PRODUCT";

  /** The constant LEARNING_MODEL_SCHEMA_HREF to specify href. */
  public static final String LEARNING_MODEL_SCHEMA_HREF = "/v2/schemas/learningModelSchema";

  /** The constant SCHEMA_DIRECTORY. */
  public static final String SCHEMA_DIRECTORY = "/schema/";

  /** The Constant JSON_FILES. */
  public static final String JSON_FILES = "/jsonFiles/";

  /** The Constant SCHEMA_VALIDATION_ERROR. */
  public static final String SCHEMA_VALIDATION_ERROR = "The request does not comply with the expected schema.The value of the %s is invalid ,Please refer the schema from given link";

  /**
   * The Constant INSTANCE to get parent error property from schema validation
   * fail report.
   */
  public static final String INSTANCE = "instance";

  /**
   * The Constant POINTER to get error property from schema validation fail
   * report.
   */
  public static final String POINTER = "pointer";

  /**
   * The constant LEARNING_MODEL_SCHEMA to specify the json schema file name.
   */
  public static final String LEARNING_MODEL_SCHEMA = "learningModelSchema.json";

  /** The Constant PRDOUCT_STATUS_JSON. */
  public static final String PRDOUCT_STATUS_JSON = "ProductStatus.json";

  /** The Constant ID. */
  public static final String ID = "id";

  /** The Constant BSSVER_ID. */
  public static final Integer BSSVER_ID = 1;

  /** The Constant VERSION. */
  public static final String VERSION = "ver";

  /** The Constant COUNT. */
  public static final String COUNT = "count";

  /** The Constant PAGE_NUMBER. */
  public static final String PAGE_NUMBER = "pageNumber";

  /** The Constant PAGE_SIZE. */
  public static final String PAGE_SIZE = "pageSize";

  /** The Constant ASSET_TYPE. */
  public static final String ASSET_TYPE = "assetType";

  /** The Constant AGGREGATES. */
  public static final String AGGREGATES = "aggregates";

  /** The Constant INSTRUCTIONS. */
  public static final String INSTRUCTIONS = "instructions";

  /** The Constant NEXT_PAGE. */
  public static final String NEXT_PAGE = "nextPage";

  /** The Constant ASSETS_PAGINATION_LINK_URL. */
  public static final String ASSETS_PAGINATION_LINK_URL = "/v2/{assetType}?pageSize={pageSize}&pageNumber={pageNumber}";

  /** The Constant CONTENT_METADATA. */
  public static final String CONTENT_METADATA = "contentMetadata";

  /** The Constant VER. */
  public static final String VER = "ver";

  /** The Constant INITIAL_BSS_VER. */
  public static final Integer INITIAL_BSS_VER = 1;

  /** The Constant CLOSE_PARANTHESIS. */
  public static final String CLOSE_PARANTHESIS = "}";

  /** The Constant OPEN_PARANTHESIS. */
  public static final String OPEN_PARANTHESIS = "{";

  /** The Constant SELF. */
  public static final String SELF = "self";

  /** The Constant MESSAGE. */
  public static final String MESSAGE = "message";

  /** The Constant JSON_FILES_PATH. */
  public static final String JSON_FILES_PATH = "jsonFiles";

  /** The Constant COLON. */
  public static final String COLON = ":";

  /** The Constant OPEN_CLOSE_PARANTHESIS. */
  public static final String OPEN_CLOSE_PARANTHESIS = "{}";

  /** The Constant DATE_FORMAT_JSON. */
  public static final String DATE_FORMAT_JSON = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  /** The Constant LPB_CONTEXT_PATH. */
  public static final String LPB_CONTEXT_PATH = "/lpb";

  /** The Constant INSTRUCTIONS_POST. */
  public static final String INSTRUCTIONS_POST = "instructionsPost";

  /** The Constant NARRATIVES_BY_VERSION_ID_ROUTE. */
  public static final String NARRATIVES_BY_VERSION_ID_ROUTE = "/v2/narratives/{id}/versions/{ver}";

  /** The Constant ASSESSMENT_ITEM_BY_VERSION_ID_ROUTE. */
  public static final String ASSESSMENT_ITEM_BY_VERSION_ID_ROUTE = "/v2/assessmentItems/{id}/versions/{ver}";

  /** The Constant LEARNINGAPP_ITEM_BY_VERSION_ID_ROUTE. */
  public static final String LEARNINGAPP_ITEM_BY_VERSION_ID_ROUTE = "/v2/learningAppItems/{id}/versions/{ver}";

  /** The Constant GETTING_INSTRUCTION message. */
  public static final String GETTING_AGGREGATE = "Getting Aggregate for the following Id:{}  ";

  /** The Constant INSTRUCTION_NOT_FOUND_MESSAGE message. */
  public static final String AGGREGATE_NOT_FOUND_MESSAGE = "Aggregate Not Found";

  /** The Constant GET_INSTRUCTIONS_JSON. */
  public static final String GET_INSTRUCTIONS_JSON = "GetInstructionsResponse.json";

  /** The Constant POST_INSTRUCTIONS_JSON. */
  public static final String POST_INSTRUCTIONS_JSON = "PostInstructionsResponse.json";

  /** The Constant CREATE_INSTRUCTIONS_JSON. */
  public static final String CREATE_INSTRUCTIONS_JSON = "CreateInstructionsResponse.json";

  /** The Constant GET_INSTRUCTIONS_BYID_JSON. */
  public static final String GET_INSTRUCTIONS_BYID_JSON = "Instruction.json";

  /** The Constant GET_AGGREGATES_JSON. */
  public static final String GET_AGGREGATES_JSON = "GetAggregateResponse.json";

  /** The Constant POST_AGGREGATES_JSON. */
  public static final String POST_AGGREGATES_JSON = "PostAggregateResponse.json";

  /** The Constant GET_AGGREGATES_BYID_JSON. */
  public static final String GET_AGGREGATES_BYID_JSON = "GetAggregateById.json";

  /** The Constant AGGREGATES_VERSIONS_GET_JSON. */
  public static final String AGGREGATES_VERSIONS_GET_JSON = "AggregatesVersionsGetAll.json";

  /** The Constant AGGREGATES_VERSIONS_POST_JSON. */
  public static final String AGGREGATES_VERSIONS_POST_JSON = "AggregatesVersionsPost.json";

  /** The Constant GET_SPECIFIC_VERSION_AGGREGATE_JSON. */
  public static final String GET_SPECIFIC_VERSION_AGGREGATE_JSON = "GetSpecificVersionAggregateResponse.json";

  /** The Constant GET_INSTRUCTION_VERSIONS_JSON. */
  public static final String GET_INSTRUCTION_VERSIONS_JSON = "InstructionVersions.json";

  /** The constant VERSIONS_NOT_FOUND. */
  public static final String VERSIONS_NOT_FOUND = " Versions not found.";

  /** The Constant FOR_ASSET_TYPE. */
  public static final String FOR_ASSET_TYPE = " for Asset Type ";

  /** The Constant WITH. */
  public static final String WITH = " with ";

  /** The Constant SINGLE_QUOTE. */
  public static final String SINGLE_QUOTE = "'";

  /** The Constant EQUALS. */
  public static final String EQUALS = " = ";

  /** The Constant AND. */
  public static final String AND = " and ";

  /** The Constant ZERO_INDEX. */
  public static final int ZERO_INDEX = 0;

  /** The Constant GET_PRODUCT. */
  public static final String GET_PRODUCT = "getProducts";

  /** The Constant TAGS. */
  public static final String TAGS = "tags";

  /** The Constant CONTENTMETADATAID. */
  public static final String CONTENTMETADATAID = "extensions.contentMetadata.id";

  /** The Constant PRODUCTS_VERSIONS_RESPONSE_JSON. */
  public static final String PRODUCTS_VERSIONS_RESPONSE_JSON = "productsVersionsResponse.json";

  /** The Constant PRODUCT_BY_ID_AND_VERSION_RESPONSE_JSON. */
  public static final String PRODUCT_BY_ID_AND_VERSION_RESPONSE_JSON = "productsByIdAndVersion.json";

  /** The Constant PRODUCT_NEW_VERSION_RESPONSE_JSON. */
  public static final String PRODUCT_NEW_VERSION_RESPONSE_JSON = "productsNewVersion.json";

  /** The Constant PRODUCTS_RESPONSE_JSON. */
  public static final String PRODUCTS_RESPONSE_JSON = "ProductPostResponse.json";

  /** The Constant GET_PRODUCT_BY_ID_JSON. */
  public static final String GET_PRODUCT_BY_ID_JSON = "ProductsById.json";

  /** The Constant GET_PRODUCTS_RESPONSE_JSON. */
  public static final String GET_PRODUCTS_RESPONSE_JSON = "ProductGetResponse.json";

  /** The Constant V2_SCHEMAS_NONPRIMITIVE_SCHEMA. */
  public static final String V2_SCHEMAS_NONPRIMITIVE_SCHEMA = "/v2/schemas/nonPrimitive";

  /** The Constant NON_PRIMITIVE_SCHEMA_JSON. */
  public static final String NON_PRIMITIVE_SCHEMA_JSON = "nonPrimitive.json";

  /** The Constant ASSESSMENT_SCHEMA_JSON. */
  public static final String ASSESSMENT_SCHEMA_JSON = "assessmentSchema.json";

  /** The Constant LEARNING_APP_SCHEMA_JSON. */
  public static final String LEARNING_APP_SCHEMA_JSON = "learningAppsSchema.json";

  /** The Constant LEARNING_MODEL. */
  public static final String LEARNING_MODEL = "learningModel";

  /** The Constant APPEND_JSON. */
  public static final String APPEND_JSON = ".json";

  /** The Constant TASK. */
  public static final String TASK = "Task";

  /** The Constant STATUS. */
  public static final String STATUS = "status";

  /** The Constant HTTP. */
  public static final String HTTP = "http://";

  /** The Constant TAG. */
  public static final String TAG = "tag";

  /** The Constant LABEL. */
  public static final String LABEL = "label";

  /** The Constant SPACE_CHAR. */
  public static final String SPACE_CHAR = " ";

  /** The Constant FORWARD_SLASH. */
  public static final String FORWARD_SLASH = "/";

  /** The Constant TASK_ROUTE. */
  public static final String TASK_ROUTE = "/v2/tasks/";

  /** The Constant TASK_STATUS. */
  public static final String TASK_STATUS = "STARTED";

  /** The Constant TASK_STATUS. */
  public static final String FETCH_PRODUCT_STATE_TRANSITION = "Fetching state transition of product with id = {} and version= {}";

  /** The Constant FETCH_PRODUCT_STATUS. */
  public static final String FETCH_PRODUCT_STATUS = "Fetching status of product with id = {} and version= {}";

  /** The Constant FETCH_PRODUCT_ASSET_TYPE. */
  public static final String FETCH_PRODUCT_ASSET_TYPE = "Fetching status of product with id = {} and version= {}";

  /** The Constant INVALID_UUID. */
  public static final String INVALID_UUID = "ID provided is invalid UUID.";

  /** The Constant STATE_TRANSITION. */
  public static final String STATE_TRANSITION = "ST";

  /** The Constant DOUBLE_COLON. */
  public static final String DOUBLE_COLON = "::";

  /** The Constant VERSIONS. */
  public static final String VERSIONS = "version";

  /** The Constant REASON_CODE. */
  public static final String REASON_CODE = "reasonCode";

  /** The Constant REASON. */
  public static final String REASON = "reason";

  /** The Constant REVIEW_PRODUCT. */
  public static final String REVIEW_PRODUCT = "reviewProduct";

  /** The Constant LATEST. */
  public static final String LATEST = "LATEST";

  /** The Constant PERCENT_SIGN. */
  public static final String PERCENT_SIGN = "%";

  /** The Constant ASSETMODEL. */
  public static final String ASSETMODEL = "ASSETMODEL";

  /** The Constant ASSETCLASSTYPES. */
  public static final String ASSETCLASSTYPES = "ASSETCLASSTYPES";

  /** The Constant PMP. */
  public static final String PMP = "PMP";

  /** The Constant PRODUCTMODEL. */
  public static final String PRODUCTMODEL = "PRODUCTMODEL";

  /** The Constant EMBEDDED. */
  public static final String EMBEDDED = "_embedded";

  /** The Constant SOURCE. */
  public static final String SOURCE = "SOURCE";

  /** The Constant CMS. */
  public static final String CMS = "cms";

  /** The Constant CONTENT_TYPE. */
  public static final String CONTENT_TYPE = "Content-Type";

  /** The Constant CONTENT_TYPE_HAL. */
  public static final String CONTENT_TYPE_HAL = "application/hal+json; charset=UTF-8";

  /** The Constant CONTENT_TYPE_STREAMING_WITH_HAL. */
  public static final String CONTENT_TYPE_STREAMING_WITH_HAL = "application/stream+json; application/hal+json; charset=UTF-8";

  /** The Constant ERROR_MESSAGE_DOCTYPE. */
  public static final String ERROR_MESSAGE_DOCTYPE = "/resources/_docType\\\":instance value () not found in enum (possible values:";

  /** The Constant ERROR_MESSAGE_ASSET_TYPE. */
  public static final String ERROR_MESSAGE_ASSET_TYPE = "/resources/_assetType\\\":instance value () not found in enum (possible values:";

  /** The Constant COUNT_ZERO. */
  public static final int COUNT_ZERO = 0;

  /** The Constant VIEW_DESIGN_NAME. */
  public static final String VIEW_DESIGN_NAME = "lpb";

  /** The Constant COUNT_VIEW_NAME. */
  public static final String COUNT_VIEW_NAME = "learningAssetCount";

  /** The Constant LEARNING_ASSET_COUNT_VIEW. */
  public static final String LEARNING_ASSET_COUNT_VIEW = "function (doc, meta) { if(doc.isLatest && doc._docType == \"LEARNINGCONTENT\") { emit(doc._assetType, null); } }";

  /** The Constant V2_SCHEMAS_ASSESSMENT_SCHEMA. */
  public static final String V2_SCHEMAS_ASSESSMENT_SCHEMA = "/v2/schemas/assessmentSchema";

  /** The Constant STRING_JOINER_COMMA. */
  public static final String STRING_JOINER_COMMA = ", ";

  /** The Constant UPDATE_STATUS_FAILED. */
  public static final String UPDATE_STATUS_FAILED = "Invalid status update.";

  /** The Constant ASSET_TYPES_NOT_FOUND. */
  public static final String SCANNING_FAILED_MESSAGE = "Scanning Failed.";

  /** The Constant STATUSDOC. */
  public static final String STATUSDOC = "StateTransitionDocument.json";

  /** The Constant V2_SCHEMAS_LEARNINGAPP_SCHEMA. */
  public static final String V2_SCHEMAS_LEARNINGAPP_SCHEMA = "/v2/schemas/learningAppsSchema";

  /** The Constant CONFIGUARTION. */
  public static final String CONFIGURATION = "configuration";

  /** The Constant FIELDS. */
  public static final String FIELDS = "fields";

  /** The Constant POLICY_GROUPS. */
  public static final String POLICY_GROUPS = "policyGroups";

  /** The Constant TITLE. */
  public static final String TITLE = "TITLE_";

  /** The Constant DEFAULT_PREFIX. */
  public static final String DEFAULT_PREFIX = "REVEL_DEFAULT_";

  /** The Constant MAX_USER_POLICY_GROUPS. */
  public static final Integer MAX_USER_POLICY_GROUPS = 1;

  /** The Constant ABSTRACT_CATEGORY. */
  public static final String ABSTRACT_CATEGORY = "abstract";

  /** The Constant PRODUCT_BUILDER. */
  public static final String PRODUCT_BUILDER = "PRODUCTBUILDER";

  /** The Constant DEFAULT_LANGUAGE. */
  public static final String DEFAULT_LANGUAGE = "en-US";

  /** The Constant STATUS_PARAM. */
  public static final String STATUS_PARAM = "_status";

  /** The Constant COMMA_CHARACTER. */
  public static final String COMMA_CHARACTER = ",";

  /** The Constant COLLECTION_DETAILS. */
  public static final String COLLECTION_DETAILS = "collectionDetails";

  /** The Constant ASSET_TYPES. */
  public static final String ASSET_TYPES = "assetTypes";

  /** The Constant ZERO_REGEX. */
  public static final String ZERO_REGEX = "^[0]";

  /** The Constant NUMBER_REGEX. */
  public static final String NUMBER_REGEX = "[0-9]*";

  /** The Constant RESPONSE_TYPE. */
  public static final String RESPONSE_TYPE = "responseType";

  /** The Constant RESPONSE_TYPE_HAL. */
  public static final String RESPONSE_TYPE_HAL = "HAL";

  /** The Constant EMBEDDED_ASSET_JSON. */
  public static final String EMBEDDED_ASSETS_JSON = "EmbeddedAsset.json";

  /** The Constant PRODUCTIZATION. */
  public static final String PRODUCTIZATION = "productization";

  /** The Constant AssessmentByQueryParamResponse. */
  public static final String ASSESSMENT_BY_QUERY_PARAM_RESPONSE = "GetAssessmentsByQueryParam.json";

  /** The Constant ORDER_BY. */
  public static final String ORDER_BY = " ORDER BY ";

  /** The Constant DESC. */
  public static final String DESC = " DESC ";

  /** The Constant for Deafult Policy Group */
  public static final String DEFAULT_GROUP = "_DEFAULT";

  /** The Constant POLICY_KEY. */
  public static final String POLICY_KEY = "KEY";

  /** The Constant END_NODE_POLICY_KEY. */
  public static final String END_NODE_POLICY_KEY = "endNodePolicyKey";

}