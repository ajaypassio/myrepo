/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

/**
 * The Interface Events.
 */
public interface Events {

  /** The Constant PRODUCT_STATUS_COMPOSE. */
  String PRODUCT_PROMOTED_TO_COMPOSE = "PRODUCT_PROMOTED_TO_COMPOSE";

  /** The Constant PRODUCT_PROMOTED_TO_SETUP. */
  String PRODUCT_PROMOTED_TO_SETUP = "PRODUCT_PROMOTED_TO_SETUP";

  /** The Constant PRODUCT_METADATA_PUBLISHED_SIGNED. */
  String PRODUCT_METADATA_PUBLISHED_SIGNED = "ProductMetadataPublishedSIGNED";

  /**
   * Product compose channel.
   *
   * @return the subscribable channel
   */
  @Input(PRODUCT_PROMOTED_TO_COMPOSE)
  SubscribableChannel productComposeChannel();

  /**
   * Product setup channel.
   *
   * @return the subscribable channel
   */
  @Input(PRODUCT_PROMOTED_TO_SETUP)
  SubscribableChannel productSetupChannel();

  /**
   * Product pmp channel.
   *
   * @return the subscribable channel
   */
  @Input(PRODUCT_METADATA_PUBLISHED_SIGNED)
  SubscribableChannel productPMPChannel();
}
