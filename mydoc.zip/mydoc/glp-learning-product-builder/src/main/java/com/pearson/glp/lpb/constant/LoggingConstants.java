/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.LMValidationConstants.AND_VERSION;

import lombok.experimental.UtilityClass;

// TODO: Auto-generated Javadoc
/**
 * The Class LoggingConstants.
 */

/**
 * Instantiates a new logging constants.
 */
@UtilityClass
public class LoggingConstants {

  /** The Constant ERROR_REGISTERING_ASSET_MODEL_ROUTES. */
  public static final String ERROR_REGISTERING_ASSET_MODEL_ROUTES = "Error occurred registering Asset Model Routes";

  /** The Constant ERROR_REGISTERING_PRODUCT_MODEL_ROUTES. */
  public static final String ERROR_REGISTERING_PRODUCT_MODEL_ROUTES = "Error occurred registering Product Model Routes";

  /** The Constant ERROR_REGISTERING_TASK_ROUTES. */
  public static final String ERROR_REGISTERING_TASK_ROUTES = "Error occurred registering Task Routes";

  /** The Constant ERROR_PAGE_SIZE_AND_PAGE_NUMBER. */
  public static final String ERROR_PAGE_SIZE_AND_PAGE_NUMBER = "Page size and page number can only be a non-zero positive numeric value.";

  /** The Constant ERROR_MAX_PAGE_SIZE. */
  public static final String ERROR_MAX_PAGE_SIZE = "Max Page Size can be 50 only.";

  /** The Constant ERROR_PAGE_SIZE. */
  public static final String ERROR_PAGE_SIZE = "Page size can only be non-zero positive numeric value.";

  /** The Constant ERROR_PAGE_NUMBER. */
  public static final String ERROR_PAGE_NUMBER = "Page number can only be non-zero positive numeric value.";

  /** The Constant ERROR_REGISTERING_AGGREGATES_ROUTES. */
  public static final String ERROR_REGISTERING_AGGREGATES_ROUTES = "Error occurred while registering Aggregates Routes";

  /** The Constant ERROR_REGISTERING_INSTRUCTIONS_ROUTES. */
  public static final String ERROR_REGISTERING_INSTRUCTIONS_ROUTES = "Error occurred while registering Instructions Routes";

  /** The Constant ERROR_REGISTERING_INSTRUCTIONS_ROUTES. */
  public static final String ERROR_REGISTERING_ASSESSMENTS_ROUTES = "Error occurred while registering Assessments Routes";

  /** The Constant ERROR_REGISTERING_LEARNINGAPPS_ROUTES. */
  public static final String ERROR_REGISTERING_LEARNINGAPPS_ROUTES = "Error occurred while registering LearningApps Routes";

  /** The Constant ERROR_REGISTERING_PRODUCT_ROUTES. */
  public static final String ERROR_REGISTERING_PRODUCT_ROUTES = "Error occurred while registering Product Routes";

  /** The Constant ERROR_FETCHING_LEARNING_MODEL. */
  public static final String ERROR_FETCHING_LEARNING_MODEL = "Error occurred while fetching the learning models.";

  /** The Constant FETCHING_ALL_LEARNING_MODEL_LATEST_VERSIONS. */
  public static final String FETCHING_ALL_LEARNING_MODEL_LATEST_VERSIONS = "Fetching the latest version of all learning models";

  /** The Constant CREATING_LEARNING_MODEL. */
  public static final String CREATING_LEARNING_MODEL = "Creating learning model";

  /** The Constant GETTING_LEARNING_MODEL. */
  public static final String GETTING_LEARNING_MODEL = "Getting the learning model with ID : {} ";

  /** The Constant REQUESTED_RESOURCE_NOT_AVAILABLE. */
  public static final String REQUESTED_RESOURCE_NOT_AVAILABLE = "The requested resource is not available.";

  /** The Constant GETTING_LEARNING_MODEL_VERSIONS. */
  public static final String GETTING_LEARNING_MODEL_VERSIONS = "Fetching all the versions of learning model with id : {}";

  /** The Constant GETTING_TASK_BYID. */
  public static final String GETTING_TASK_BYID = "Getting Task with ID : {}";

  /** The Constant ERROR_FETCHING_TASK_BYID_MESSAGE. */
  public static final String ERROR_FETCHING_TASK_BYID_MESSAGE = "Error occurred while fetching the task with ID : {}";

  /** The Constant API_TO_GET_LATEST_NON_PRIMITIVE_ASSET. */
  public static final String API_TO_GET_LATEST_NON_PRIMITIVE_ASSET = "Calling API to GET Bulk {}.";

  /** The Constant ERROR_FETCHING_NON_PRIMITIVE_ASSET. */
  public static final String ERROR_FETCHING_NON_PRIMITIVE_ASSET = "Error occurred while fetching the {}.";

  /** The Constant ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE. */
  public static final String ERROR_FETCHING_NON_PRIMITIVE_ASSET_MESSAGE = "Error occurred while fetching the ";

  /** The Constant API_TO_POST_ALL_NON_PRIMITIVE_ASSET. */
  public static final String API_TO_POST_ALL_NON_PRIMITIVE_ASSET = "Calling API to POST Bulk {}.";

  /** The Constant GETTING_NON_PRIMITIVE_ASSET. */
  public static final String GETTING_NON_PRIMITIVE_ASSET = "Getting {} for the ID: {}";

  /** The Constant API_TO_GET_NO_PRIMITIVE_ASSET_VERSIONS. */
  public static final String API_TO_GET_NO_PRIMITIVE_ASSET_VERSIONS = "Calling API to Get {} Versions {}";

  /** The Constant CREATING_NON_PRIMITIVE_VERSION. */
  public static final String CREATING_NON_PRIMITIVE_VERSION = "Creating new version for {} asset {}. ";

  /** The Constant ASSET_NOT_FOUND. */
  public static final String ASSET_NOT_FOUND = "Asset Not Found.";

  /** The Constant INVALID_REQUEST_PAYLOAD. */
  public static final String INVALID_REQUEST_PAYLOAD = "Invalid Request Payload.";

  /** The Constant ASSET_MODEL_ID_AND_VERSION_ALREADY_EXISTS. */
  public static final String ASSET_MODEL_ID_AND_VERSION_ALREADY_EXISTS = "Asset Model Id and Version already exists.";

  /** The Constant ASSET_MODEL_ID_AND_VERSION_ID_SHOULD_BE_IN_UUID_FORMAT. */
  public static final String ASSET_MODEL_ID_AND_VERSION_ID_SHOULD_BE_IN_UUID_FORMAT = "Asset Model Id and Version Id should be in UUID format.";

  /** The Constant GETTING_SPECIFIC_VERSIONS_NON_PRIMITIVE_ASSET_ID. */
  public static final String GETTING_SPECIFIC_VERSIONS_NON_PRIMITIVE_ASSET_ID = "Getting {} for Id :{} and Version :{}";

  /** The Constant SCHEMA_VALIDATION_FAILS. */
  public static final String SCHEMA_VALIDATION_FAILS = "Schema validation fails :: {} ";

  /** The Constant ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION. */
  public static final String ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION = "Error creating {} version: {}";

  /** The Constant NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE. */
  public static final String NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE = " version could not be saved.";

  /** The Constant ERROR_INVALID_URL_FOR_PRODUCT. */
  public static final String ERROR_INVALID_URL_FOR_PRODUCT = "Invalid URL. Mention valid search parameter for product.";

  /** The Constant GETTING_ALL_PRODUCT. */
  public static final String GETTING_ALL_PRODUCT = "Getting All Products";

  /** The Constant ERROR_PRODUCT_NOT_FOUND. */
  public static final String ERROR_PRODUCT_NOT_FOUND = "Product not found.";

  /** The Constant ERROR_PRODUCT_MODEL_NOT_FOUND. */
  public static final String ERROR_PRODUCT_MODEL_NOT_FOUND = "Product model not found.";

  /** The Constant ERROR_PRODUCT_MODEL_CONFIGURATION_NOT_FOUND. */
  public static final String ERROR_PRODUCT_MODEL_CONFIGURATION_NOT_FOUND = "Product model configuration does not exists.";

  /** The Constant ERROR_PRODUCT_SCANNING_NOT_DONE. */
  public static final String ERROR_PRODUCT_SCANNING_NOT_DONE = "Product scanning is not done.";

  /** The Constant PARAM_NOT_ALLOWED_IN_FILTERING. */
  public static final String PARAM_NOT_ALLOWED_IN_FILTERING = " is not allowed for asset class filtering.";

  /** The Constant NOT_AVAILABLE. */
  public static final String NOT_AVAILABLE = " is not available.";

  /** The Constant REQUESTED_RESOURCE. */
  public static final String REQUESTED_RESOURCE = "The requested resource ";

  /** The Constant ERROR_PRODUCT_STATUS_NOT_FOUND. */
  public static final String ERROR_PRODUCT_STATUS_NOT_FOUND = "Product status not found.";

  /** The Constant GETTING_PRODUCT_FOR. */
  public static final String GETTING_PRODUCT_FOR = "Getting product for : {}";

  /** The Constant ERROR_FETCHING_PRODUCT. */
  public static final String ERROR_FETCHING_PRODUCT = "Error in fetching product.";

  /** The Constant ERROR_FETCHING_PRODUCT_MESSAGE. */
  public static final String ERROR_FETCHING_PRODUCT_MESSAGE = "Error in fetching product: {}";

  /** The Constant GETTING_PRODUCT_VERSIONS. */
  public static final String GETTING_PRODUCT_VERSIONS = "Getting product versions.";

  /** The Constant FETCHING_PRODUCT_BY_VERSION. */
  public static final String FETCHING_PRODUCT_BY_VERSION = "Fetching Product by version.";

  /** The Constant CREATING_NEW_PRODUCT_WITH_LATEST_VERSION. */
  public static final String CREATING_NEW_PRODUCT_WITH_LATEST_VERSION = "Creating new product with latest version";

  /** The Constant CREATING_NEW_PRODUCT. */
  public static final String CREATING_NEW_PRODUCT = "Creating new product";

  /** The Constant FETCHING_PRODUCT_BY_ID. */
  public static final String FETCHING_PRODUCT_BY_ID = "Fetching Product By Id with Latest Version";

  /** The Constant CREATING_LEARNING_MODEL_VERSION. */
  public static final String CREATING_LEARNING_MODEL_VERSION = "Creating new version for learning model with id : {} ";

  /** The Constant ERROR_CREATING_LEARNING_MODEL. */
  public static final String ERROR_CREATING_LEARNING_MODEL = "Error creating learning model: ";

  /** The Constant LEARNING_MODEL_NOT_SAVED. */
  public static final String LEARNING_MODEL_NOT_SAVED = "Learning Model could not be saved.";

  /** The Constant ERROR_CREATING_ASSET_MODEL_VERSION. */
  public static final String ERROR_CREATING_LEARNING_MODEL_VERSION = "Error creating learning model version: ";

  /** The Constant ERROR_JSON_TO_OBJECT_MAPPING. */
  public static final String ERROR_JSON_TO_OBJECT_MAPPING = "Error occurred while converting JSON to Java Object";

  /** The Constant NON_PRIMITIVE_ASSET_BUILD_ERROR. */
  public static final String NON_PRIMITIVE_ASSET_BUILD_ERROR = "Error occurred while building non primitive asset : ";

  /** The Constant GENERATE_ASSET_RESPONSE_FOR_REQUEST_ID. */
  public static final String GENERATE_ASSET_RESPONSE_FOR_REQUEST_ID = "Generate Asset Response for request id : ={}";

  /** The Constant GENERATE_ASSET_RESPONSE_WITH_ERROR. */
  public static final String GENERATE_ASSET_RESPONSE_WITH_ERROR = "Generate Asset Response with error for request id : {}";

  /** The Constant LEARNING_MODEL_VERSION_NOT_SAVED. */
  public static final String LEARNING_MODEL_VERSION_NOT_SAVED = "Learning Model version could not be saved.";

  /** The Constant FETCH_NON_PRIMITIVE_ASSET_LATEST_RESPONSE. */
  public static final String FETCH_NON_PRIMITIVE_ASSET_LATEST_RESPONSE = "Fetch latest {}";

  /** The Constant FETCH_NON_PRIMITIVE_ASSET_VERSIONS_RESPONSE. */
  public static final String FETCH_NON_PRIMITIVE_ASSET_VERSIONS_RESPONSE = "Fetch {}'s all Versions for {}";

  /** The Constant GETTING_PRODUCT_BY_ID_AND_VERSION. */
  public static final String GETTING_PRODUCT_BY_ID_AND_VERSION = "Getting Product By Id and Version";

  /** The Constant LEARNING_MODEL_VALIDATION_ERROR. */
  public static final String LEARNING_MODEL_VALIDATION_ERROR = "The request does not comply with the expected learning model. ";

  /** The Constant IS. */
  public static final String IS = " is ";

  /** The Constant IS_MORE_THAN_MAX. */
  public static final String MAX = ", maximum allowed is ";

  /** The Constant IS_LESS_THAN_MIN. */
  public static final String MIN = ", minimum allowed is ";

  /** The Constant RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN. */
  public static final String RESOURCE_ALLOWED_TO_MATCH_KEY_PATTERN = " resource(s) match the Key Pattern ";

  /** The Constant CATEGORY_SCHEMA_VALIDATION_SUCCESSFUL. */
  public static final String CATEGORY_SCHEMA_VALIDATION_SUCCESSFUL = "Category Schema validation successful.";

  /** The Constant CATEGORY_SCHEMA_LOG_MESSAGE. */
  public static final String CATEGORY_SCHEMA_LOG_MESSAGE = "resource occurance error for key pattern ={}. Expected ={}, Actual ={}";

  /** The Constant MODEL_VALIDATION_LOG. */
  public static final String MODEL_VALIDATION_LOG = "Model validation ={}.";

  /** The Constant ERROR_LINKS_RESOURCES. */
  public static final String ERROR_LINKS_RESOURCES = "Error while creating links for resources";

  /** The Constant TASK_CREATION_FAILED. */
  public static final String TASK_CREATION_FAILED = "task creation failed";

  /** The Constant GETTING_OFFSET. */
  public static final String GETTING_LIMITS = "Getting the Limits";

  /** The Constant GETTING_OFFSET. */
  public static final String GETTING_OFFSET = "Getting the Offsets";

  /** The Constant PUBLISHING_EVENT_MESSAGE. */
  public static final String PUBLISHING_EVENT_MESSAGE = "Publishing event for the event name : {}";

  /** The Constant ERROR_EVENT_MESSAGE. */
  public static final String ERROR_EVENT_MESSAGE = "Error : {} while publishing event : {}";

  /** The Constant PRODUCT_STATUS_NOT_FOUND. */
  public static final String PRODUCT_STATUS_NOT_FOUND = "Product Status Not Found";

  /** The Constant ERROR_IN_PRODUCT_STATE_TRANSITION. */
  public static final String ERROR_IN_PRODUCT_STATE_TRANSITION = "Error in product state transition. ";

  /** The Constant PRODUCT_IS_IN_LIVE_STATE. */
  public static final String PRODUCT_IS_IN_LIVE_STATE = "Product is already in LIVE state";

  /** The Constant PRODUCT_IS_IN_LIVE_STATE_LOG. */
  public static final String PRODUCT_IS_IN_LIVE_STATE_LOG = "Product with id {} and ver {} is in LIVE state.";

  /** The Constant STATE_TRANSITION_RESPONSE_LOG. */
  public static final String STATE_TRANSITION_RESPONSE_LOG = "Building state transition {}";

  /** The Constant REVIEW_PRODUCT_INFO_LOG. */
  public static final String REVIEW_PRODUCT_INFO_LOG = "Adding review product {} information to the live product.";

  /** The Constant PRODUCT_STATE_TRANSITION_BEGINS. */
  public static final String PRODUCT_STATE_TRANSITION_BEGINS = "Product state transition begins.";

  /** The Constant REVIEW_PRODUCT_IS_LIVE. */
  public static final String REVIEW_PRODUCT_IS_LIVE = "This review product is already Live with ID ";

  /** The Constant INVALID_METHOD_TYPE_ERROR_MESSAGE. */
  public static final String INVALID_METHOD_TYPE_ERROR_MESSAGE = "Error Handler - Method not allowed for PUT/DELETE ";

  /** LM validation log messages start. */
  /** The Constant MANDATORY_FIELD_FOR_RESOURCE_ID. */
  public static final String MANDATORY_FIELD_FOR_RESOURCE_ID = " must not be empty for resource ID ";

  /** The Constant INSTANCE_SCHEMA_REQUIRED_LOG. */
  public static final String INSTANCE_SCHEMA_REQUIRED_LOG = new StringBuilder()
      .append(OPEN_CLOSE_PARANTHESIS).append(MANDATORY_FIELD_FOR_RESOURCE_ID)
      .append(OPEN_CLOSE_PARANTHESIS).append(AND_VERSION).append(OPEN_CLOSE_PARANTHESIS).toString();

  /** The Constant INSTANCE_SCHEMA_ENUM_LOG. */
  public static final String INSTANCE_SCHEMA_ENUM_LOG = new StringBuilder()
      .append(OPEN_CLOSE_PARANTHESIS).append(LMValidationConstants.OF_RESOURCE_ID)
      .append(OPEN_CLOSE_PARANTHESIS).append(AND_VERSION).append(OPEN_CLOSE_PARANTHESIS)
      .append(" must match the enum value(s) ").append(OPEN_CLOSE_PARANTHESIS).toString();

  /** The Constant ERROR_VALIDATING_INSTANCE_SCHEMA. */
  public static final String ERROR_VALIDATING_INSTANCE_SCHEMA = "Error validating instance schema "
      + "for resource ID {} and version {}. {}";

  /** The Constant VALIDATING_RESOURCE_ID_AND_VERSION. */
  public static final String VALIDATING_RESOURCE_ID_AND_VERSION = "Validating resource Id {} and version {}";

  /** The Constant DOES_NOT_MATCH_THE_ASSET_CLASS. */
  public static final String DOES_NOT_MATCH_THE_ASSET_CLASS = " does not match the assetClass of learning model";

  /** The Constant ASSET_CLASS_DOES_NOT_MATCH_LOG. */
  public static final String ASSET_CLASS_DOES_NOT_MATCH_LOG = "assetClass {} does not match the assetClass of "
      + "learning model with ID {} and version {}";

  /** The Constant KEY_PATTERN_INCORRECT. */
  public static final String KEY_PATTERN_INCORRECT = "assetClass {} of resource ID {} and version "
      + "{} does not match any Key Pattern.";

  /** The Constant RESOURCE_FETCH_ERROR. */
  public static final String RESOURCE_FETCH_ERROR = "Unable to fetch resource for ID ={} and version ={}. ={}";

  /** The Constant RESOURCES_NOT_FOUND_FOR_ID. */
  public static final String RESOURCES_NOT_FOUND_FOR_ID = "Resources not found for Id ";

  /** The Constant RESOURCE_VALIDATED_CORRECTLY. */
  public static final String RESOURCE_VALIDATED_CORRECTLY = "Resource validated correctly ={}";

  /** The Constant MODEL_VALIDATION_BEGINS. */
  public static final String MODEL_VALIDATION_BEGINS = "Model validation for contentMetadata id ={} begins";

  /** The Constant MODEL_VALIDATION_SUCCESSFUL. */
  public static final String MODEL_VALIDATION_SUCCESSFUL = "Successful validation for contentMetadata id ={}";

  /** The Constant FETCHING_RESOURCE_FROM_DATABASE. */
  public static final String FETCHING_RESOURCE_FROM_DATABASE = "Fetching resource ={} from database";

  /** The Constant FETCHING_RESOURCE_FROM_LAP. */
  public static final String FETCHING_RESOURCE_FROM_LAP = "Fetching resource ={} from LAP";

  /** The Constant ERROR_IN_SAVING_PRDOUCT_STATUS. */
  public static final String ERROR_IN_SAVING_PRDOUCT_STATUS = "Error in saving product status: ";

  /** The Constant FETCH_PRODUCT. */
  public static final String FETCH_PRODUCT = "Fetching product with id = {} and version= {}";

  /** The Constant FETCHING_CONFIGUARTION. */
  public static final String FETCHING_CONFIGUARTION = "Fetching configuration for id ={} and version ={}. = {} ";

  /** The Constant INVALID_POLICY_GROUP_ERROR. */
  public static final String INVALID_POLICY_GROUP_ERROR = "Invalid policy group is provided to create a new version of Product.";

  /** The Constant NON_ARRAY_POLICY_GROUP_ERROR. */
  public static final String NON_ARRAY_POLICY_GROUP_ERROR = "Only an array of String value(s) is acceptable for 'policyGroups'.";

  /** The Constant MULTIPLE_POLICY_GROUPS_ERROR. */
  public static final String MULTIPLE_POLICY_GROUPS_ERROR = "Only one policy group is allowed to create a new version of Product.";

  /** The Constant RECEIVING_EVENT_MESSAGE. */
  public static final String RECEIVING_EVENT_MESSAGE = "Got event : ";

  /** The Constant ERROR_RECEIVING_EVENT_MESSAGE. */
  public static final String ERROR_RECEIVING_EVENT_MESSAGE = "Error while reading the Event or product resources not present";

  /** The Constant ERROR_SCANNING_FAILED_AND_RETRY_SCANNING. */
  public static final String ERROR_SCANNING_FAILED_AND_RETRY_SCANNING = "Scanning failed : {} retry the scanning: {}";

  /** The Constant SCANNING_PRODUCT_MESSAGE. */
  public static final String SCANNING_PRODUCT_MESSAGE = "Product scanning init ";

  /** The Constant SCANNING_COMPLETION_MESSAGE. */
  public static final String SCANNING_COMPLETION_MESSAGE = "Scan product completed  and event {} pulish successfully";

  /** The Constant SCANNING_FAILED_MESSAGE. */
  public static final String SCANNING_FAILED_MESSAGE = "Scanning failed due to either resource not found or event {} not published";

  /** The Constant ERROR_FETCHING_RESOURCE_MESSAGE_LPB. */
  public static final String ERROR_FETCHING_RESOURCE_MESSAGE_LPB = "Error while fetch resources from lpb id {} version {} ";

  /** The Constant ERROR_FETCHING_RESOURCE_MESSAGE_LAP. */
  public static final String ERROR_FETCHING_RESOURCE_MESSAGE_LAP = "Error while fetch resources from lap {} ";

  /** The Constant INSIDE_FILTER_FROM_URL. */
  public static final String INSIDE_FILTER_FROM_URL = "inside filter from url : {}";

  /** The Constant REQUIRED_ACCEPT_HEADERS_ARE_MISSING. */
  public static final String REQUIRED_ACCEPT_HEADERS_ARE_MISSING = "required accept headers are missing in {} request for url : {}";

  /** The Constant REQUIRED_CONTENT_TYPE_HEADERS_ARE_MISSING. */
  public static final String REQUIRED_CONTENT_TYPE_HEADERS_ARE_MISSING = "required content-type headers are missing in {} request for url : {}";

  /** The Constant PMP_RECEIVED_MESSAGE. */
  public static final String PMP_RECEIVED_MESSAGE = "PMP Message is received and is save in the database";

  /** The Constant PMP_MESSAGE_AVAILABLE. */
  public static final String PMP_MESSAGE_AVAILABLE = "PMP Message is available.";

  /** The Constant PMP_MESSAGE_NOT_AVAILABLE. */
  public static final String PMP_MESSAGE_NOT_AVAILABLE = "PMP Message is not available.";

  /** The Constant PMP_RECEIVED_FAILED_MESSAGE. */
  public static final String PMP_RECEIVED_FAILED_MESSAGE = "PMP Message is not received";

  /** The Constant PRODUCT_SETUP_STATE. */
  public static final String PRODUCT_SETUP_STATE = "Product is in setup state";

  /** The Constant PRODUCT_SETUP_STATE_FAILED. */
  public static final String PRODUCT_SETUP_STATE_FAILED = "Product failed to be in setup state";

  /** The Constant GET_PRODUCT_BY_ID. */
  public static final String GET_PRODUCT_BY_ID = "Fetching Latest version of Product with ID : {}";

  /** The Constant DELETE_PRODUCT_LATEST_VERSION. */
  public static final String DELETE_PRODUCT_LATEST_VERSION = "Delete current Latest version of Product with ID : {}";

  /** The Constant CREATE_PRODUCT_NEW_VERSION. */
  public static final String CREATE_PRODUCT_NEW_VERSION = "Creating a new version of Product with ID : {}";

  /** The Constant CREATE_PRODUCT_NEW_STATUS. */
  public static final String CREATE_PRODUCT_NEW_STATUS = "Creating a new Status {} of Product with ID : {}";

  /** The Constant CREATE_PRODUCT_LATEST_DOC. */
  public static final String CREATE_PRODUCT_LATEST_DOC = "Creating a latest document of Product with ID : {}";

  /** The Constant FETCHING_PMP_MESSAGE. */
  public static final String FETCHING_PMP_MESSAGE = "Fetching PMP message with ID : {}";

  /** The Constant GET_ALL_ASSESSMENT. */
  public static final String GET_ALL_ASSESSMENT = "Getting All Assessment";

  /** The Constant ERROR_INVALID_URL_FOR_ASSESSMENT. */
  public static final String ERROR_INVALID_URL_FOR_ASSESSMENT = "Invalid Request Param. Mention valid search parameter for assessment.";

  /** The Constant ERROR_ASSESSMENT_NOT_FOUND. */
  public static final String ERROR_ASSESSMENT_NOT_FOUND = "Assessment not found.";

  /** The Constant METHOD_GET_PRODUCT_MODEL_POLICY_GROUP. */
  public static final String METHOD_GET_PRODUCT_MODEL_POLICY_GROUP = "getProductModelPolicyGroup";

  /** The Constant METHOD_FETCH_PRODUCT_MODEL_CONFIGURATION. */
  public static final String METHOD_FETCH_PRODUCT_MODEL_CONFIGURATION = "fetchProductModelConfiguration";

  /** The Constant METHOD_BUILD_PRODUCT_MODEL_POLICY_CONFIGURATION_RESPONSE. */
  public static final String METHOD_BUILD_PRODUCT_MODEL_POLICY_CONFIGURATION_RESPONSE = "buildProductModelPolicyConfigurationResponse";

  /** The Constant METHOD_MAPPING_OF_PRODUCT_MODEL_COLLECTION_DETAILS. */
  public static final String METHOD_MAPPING_OF_PRODUCT_MODEL_COLLECTION_DETAILS = "mappingOfProductModelCollectionDetails";

  /** The Constant METHOD_MAP_TO_PRODUCT_MODEL_COLLECTION. */
  public static final String METHOD_MAP_TO_PRODUCT_MODEL_COLLECTION = "mapToProductModelCollection";

  /** The Constant METHOD_INVOCATION. */
  public static final String METHOD_INVOCATION = "Method invocation : {}";

  /** The Constant METHOD_TERMINATION. */
  public static final String METHOD_TERMINATION = "Method termination : {}";

  /** The Constant FETCHING_QUERY_PARAM. */
  public static final String FETCHING_QUERY_PARAM = "Fetching Query Param {}={}";

  /** The Constant INVALID_REQUEST. */
  public static final String INVALID_REQUEST = "Invalid Request.";

  /** The Constant ERROR_INVALID_URL_FOR_PRODUCT_MODEL. */
  public static final String ERROR_INVALID_URL_FOR_PRODUCT_MODEL = "Invalid URL. Mention valid search parameter for product model.";

  /** The Constant ERROR_OCCURRED_REGISTERING_EMBEDDED_ASSETS_ROUTES. */
  public static final String ERROR_OCCURRED_REGISTERING_EMBEDDED_ASSETS_ROUTES = "Error occurred registering Embedded Assets  Routes";

  /** The Constant ERROR_REGISTERING_EMBEDDED_ASSETS_ROUTES. */
  public static final String ERROR_REGISTERING_EMBEDDED_ASSETS_ROUTES = "Error occurred while registering embedded asset Routes";

  /** The Constant CONFIGURATION_VALIDATION_ERROR. */
  public static final String CONFIGURATION_VALIDATION_ERROR = "The request does not comply with the expected configuration. ";

  /** The Constant RELATIONSHIP_VALIDATION_ERROR. */
  public static final String RELATIONSHIP_VALIDATION_ERROR = "The request does not comply with the expected Relationship of an EmbeddedAsset. ";
}