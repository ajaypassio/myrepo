/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.util.LinkedHashMap;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The Class Extends.
 * 
 * @author sourabh.aggarwal
 */
/**
 * Instantiates a new extensions.
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
public class Extensions extends LinkedHashMap<String, Object> {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 2922992826822282048L;

}