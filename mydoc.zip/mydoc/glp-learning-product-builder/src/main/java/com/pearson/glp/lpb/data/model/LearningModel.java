/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class LearningModel.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_resourceType", "_docType", "_assetType", "_id", "_bssVer", "_ver",
    "_links" })
@Document
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class LearningModel implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 2409597918986619093L;

  /** (Required). */
  @JsonProperty("_resourceType")
  @SerializedName("_resourceType")
  @Field("_resourceType")
  private String resourceType;

  /** (Required). */
  @JsonProperty("_docType")
  @SerializedName("_docType")
  @Field("_docType")
  private String docType;

  /** (Required). */
  @JsonProperty("_assetType")
  @SerializedName("_assetType")
  @Field("_assetType")
  private String assetType;

  /** (Required). */
  @JsonProperty("_id")
  @SerializedName("_id")
  @Field("_id")
  private String id;

  /** (Required). */
  @JsonProperty("_bssVer")
  @SerializedName("_bssVer")
  @Field("_bssVer")
  private Integer bssVer;

  /** (Required). */
  @JsonProperty("_ver")
  @SerializedName("_ver")
  @Field("_ver")
  private String ver;

  /** (Required). */
  @JsonProperty("_links")
  @SerializedName("_links")
  @Field("_links")
  private Map<String, Link> links;

  /**
   * Adds the links.
   *
   * @param rel
   *          the rel
   * @param link
   *          the link
   */
  public void addLinks(String rel, Link link) {
    if (this.links == null) {
      links = new LinkedHashMap<>();
    }
    links.put(rel, link);
  }

}