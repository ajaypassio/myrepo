/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.couchbase.core.mapping.Document;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * The Class NonPrimitiveAsset.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "_bssVer", "_ver", "_created", "_lastModified", "expiresOn",
    "learningModel", "label", "tags", "language", "_docType", "_assetType", "assetClass",
    "objectives", "groups", "resources", "assetGraph", "resourcePlan", "configuration",
    "constraints", "extends", "extensions", "scope", "_links" })
@Document

/**
 * Instantiates a new non primitive learning asset.
 */
@Data
@EqualsAndHashCode(callSuper = false)

/*
 * (non-Javadoc)
 * 
 * @see com.pearson.glp.lpb.data.model.Asset#hashCode()
 */
public class NonPrimitiveAsset extends Asset {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 6190004550882996562L;

  /** (Required). */
  /** The created. */
  @Field("_created")
  @SerializedName("_created")
  @JsonProperty("_created")
  private String created;

  /** The lastModified. */
  @Field("_lastModified")
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  private String lastModified;

  /** The createdBy. */
  @SerializedName("_createdBy")
  @JsonProperty("_createdBy")
  @Field("_createdBy")
  private String createdBy;

  /** The expires on. */
  @JsonProperty("expiresOn")
  @Field("expiresOn")
  @SerializedName("expiresOn")
  private String expiresOn;

  /** The label. */
  @SerializedName("label")
  @JsonProperty("label")
  @Field("label")
  private String label;

  /** The tags. */
  @SerializedName("tags")
  @JsonProperty("tags")
  @Field("tags")
  private String tags;

  /** The language. */
  @SerializedName("language")
  @JsonProperty("language")
  @Field("language")
  private String language;

  /** The asset class. */
  @SerializedName("assetClass")
  @JsonProperty("assetClass")
  @Field("assetClass")
  private String assetClass;

  /** The objectives. */
  @SerializedName("objectives")
  @JsonProperty("objectives")
  @Field("objectives")
  private String objectives;

  /** The groups. */
  @SerializedName("groups")
  @JsonProperty("groups")
  @Field("groups")
  private Groups groups;

  /** The learning model. */
  @SerializedName("learningModel")
  @JsonProperty("learningModel")
  @Field("learningModel")
  private LearningModel learningModel;

  /** (Required). */
  @SerializedName("resources")
  @JsonProperty("resources")
  @Field("resources")
  protected LinkedHashMap<String, Resources> resources;

  /** (Required). */
  @SerializedName("assetGraph")
  @JsonProperty("assetGraph")
  @Field("assetGraph")
  private ArrayList<AssetGraph> assetGraph;

  /** (Required). */
  @SerializedName("resourcePlan")
  @JsonProperty("resourcePlan")
  @Field("resourcePlan")
  private ArrayList<ResourcePlan> resourcePlan;

  /** (Required). */
  @SerializedName("configuration")
  @JsonProperty("configuration")
  @Field("configuration")
  private Configuration configuration;

  /** (Required). */
  @SerializedName("constraints")
  @JsonProperty("constraints")
  @Field("constraints")
  private ArrayList<String> constraints;

  /** (Required). */
  @SerializedName("extends")
  @JsonProperty("extends")
  @Field("extends")
  protected Extends extend;

  /** (Required). */
  @SerializedName("extensions")
  @JsonProperty("extensions")
  @Field("extensions")
  private Extensions extensions;

  /** (Required). */
  @SerializedName("scope")
  @JsonProperty("scope")
  @Field("scope")
  private Scope scope;

  /** The transient isLatest. */
  private transient Boolean isLatest;

  public NonPrimitiveAsset() {
    super();
  }

  public NonPrimitiveAsset(NonPrimitiveAssetPayload nonPrimitiveAsset) {
    this.created = nonPrimitiveAsset.getCreated();
    this.lastModified = nonPrimitiveAsset.getCreated();
    this.createdBy = nonPrimitiveAsset.getCreatedBy();
    this.expiresOn = nonPrimitiveAsset.getExpiresOn();
    this.label = nonPrimitiveAsset.getLabel();
    this.tags = nonPrimitiveAsset.getTags();
    this.language = nonPrimitiveAsset.getLanguage();
    this.assetClass = nonPrimitiveAsset.getAssetClass();
    this.objectives = nonPrimitiveAsset.getObjectives();
    this.groups = nonPrimitiveAsset.getGroups();
    this.learningModel = nonPrimitiveAsset.getLearningModel();
    this.resources = nonPrimitiveAsset.getResources();
    this.assetGraph = nonPrimitiveAsset.getAssetGraph();
    this.resourcePlan = nonPrimitiveAsset.getResourcePlan();
    this.configuration = nonPrimitiveAsset.getConfiguration();
    this.constraints = nonPrimitiveAsset.getConstraints();
    this.extend = nonPrimitiveAsset.getExtend();
    this.extensions = nonPrimitiveAsset.getExtensions();
    this.scope = nonPrimitiveAsset.getScope();
  }
}
