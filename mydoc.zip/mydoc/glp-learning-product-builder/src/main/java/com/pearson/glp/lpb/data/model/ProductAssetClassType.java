/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.LinkedHashMap;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class ProductAssetClassType.
 */
@Document
@Getter
@Setter
public class ProductAssetClassType implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -6853168800219299708L;

  /** The id of document. */
  @Id
  private transient String id;

  /** The id of resource. */
  private String _id;

  /** The _ver. */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  @Field("_ver")
  private String ver;

  /** The bss ver. */
  @SerializedName("_bssVer")
  @JsonProperty("_bssVer")
  @Field("_bssVer")
  private Integer bssVer;

  /** The resource type. */
  @SerializedName("_resourceType")
  @JsonProperty("_resourceType")
  @Field("_resourceType")
  private String resourceType;

  /** The resource ctx. */
  @SerializedName("_resourceCtx")
  @JsonProperty("_resourceCtx")
  @Field("_resourceCtx")
  private String resourceCtx;

  /** The expires on. */
  private String expiresOn;

  /** The resource class. */
  private String resourceClass;

  /** The created on. */
  @SerializedName("_created")
  @JsonProperty("_created")
  @Field("_created")
  private String created;

  /** The _lastModified. */
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  @Field("_lastModified")
  private String lastModified;

  /** The label. */
  private String label;

  /** The tags. */
  private String tags;

  /** The language. */
  private String language;

  /** The content. */
  private Content content;

  /** The security. */
  private Extensions extensions;

  /** The scope. */
  private Scope scope;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  @Field("_links")
  private LinkedHashMap<String, Link> links;

  /**
   * Adds the links.
   *
   * @param rel
   *          the rel
   * @param link
   *          the link
   */
  public void addLinks(String rel, Link link) {
    if (this.links == null) {
      links = new LinkedHashMap<>();
    }
    links.put(rel, link);
  }

}
