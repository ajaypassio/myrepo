/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * The Class ProductResponse.
 * 
 * @author kavya.jain
 */
@Document
@Data
@EqualsAndHashCode(callSuper = false)
public class ProductNonPrimitiveAsset extends Asset {

  /**
   * 
   */
  private static final long serialVersionUID = -6504479534672337027L;

  /** (Required). */
  /** The created. */
  @Field("_created")
  @SerializedName("_created")
  @JsonProperty("_created")
  private String created;

  /** The expires on. */
  @JsonProperty("expiresOn")
  @Field("expiresOn")
  @SerializedName("expiresOn")
  private String expiresOn;

  /** The label. */
  @SerializedName("label")
  @JsonProperty("label")
  @Field("label")
  private String label;

  /** The tags. */
  @SerializedName("tags")
  @JsonProperty("tags")
  @Field("tags")
  private String tags;

  /** The language. */
  @SerializedName("language")
  @JsonProperty("language")
  @Field("language")
  private String language;

  /** The asset class. */
  @SerializedName("assetClass")
  @JsonProperty("assetClass")
  @Field("assetClass")
  private String assetClass;

  /** The objectives. */
  @SerializedName("objectives")
  @JsonProperty("objectives")
  @Field("objectives")
  private String objectives;

  /** The groups. */
  @SerializedName("groups")
  @JsonProperty("groups")
  @Field("groups")
  private Groups groups;

  /** The learning model. */
  @SerializedName("learningModel")
  @JsonProperty("learningModel")
  @Field("learningModel")
  private LearningModel learningModel;

  /** (Required). */
  @SerializedName("resources")
  @JsonProperty("resources")
  @Field("resources")
  protected LinkedHashMap<String, Resources> resources;

  /** (Required). */
  @SerializedName("assetGraph")
  @JsonProperty("assetGraph")
  @Field("assetGraph")
  private ArrayList<AssetGraph> assetGraph;

  /** (Required). */
  @SerializedName("resourcePlan")
  @JsonProperty("resourcePlan")
  @Field("resourcePlan")
  private ArrayList<ResourcePlan> resourcePlan;

  /** (Required). */
  @SerializedName("status")
  @JsonProperty("status")
  @Field("status")
  private Map<String, String> status;

  /** (Required). */
  @SerializedName("configuration")
  @JsonProperty("configuration")
  @Field("configuration")
  private Configuration configuration;

  /** (Required). */
  @SerializedName("constraints")
  @JsonProperty("constraints")
  @Field("constraints")
  private ArrayList<String> constraints;

  /** (Required). */
  @SerializedName("extends")
  @JsonProperty("extends")
  @Field("extends")
  protected Extends extend;

  /** The extensions. */
  @JsonProperty("extensions")
  @SerializedName("extensions")
  @Field("extensions")
  private Extensions extensions;

  /** (Required). */
  @SerializedName("scope")
  @JsonProperty("scope")
  @Field("scope")
  private Scope scope;

  public ProductNonPrimitiveAsset() {
    super();
  }

  public ProductNonPrimitiveAsset(NonPrimitiveAssetPayload nonPrimitiveAsset) {
    this.created = nonPrimitiveAsset.getCreated();
    this.expiresOn = nonPrimitiveAsset.getExpiresOn();
    this.label = nonPrimitiveAsset.getLabel();
    this.tags = nonPrimitiveAsset.getTags();
    this.language = nonPrimitiveAsset.getLanguage();
    this.assetClass = nonPrimitiveAsset.getAssetClass();
    this.objectives = nonPrimitiveAsset.getObjectives();
    this.groups = nonPrimitiveAsset.getGroups();
    this.learningModel = nonPrimitiveAsset.getLearningModel();
    this.resources = nonPrimitiveAsset.getResources();
    this.assetGraph = nonPrimitiveAsset.getAssetGraph();
    this.resourcePlan = nonPrimitiveAsset.getResourcePlan();
    this.configuration = nonPrimitiveAsset.getConfiguration();
    this.constraints = nonPrimitiveAsset.getConstraints();
    this.extend = nonPrimitiveAsset.getExtend();
    this.extensions = nonPrimitiveAsset.getExtensions();
    this.extensions.put(CONTENT_METADATA, nonPrimitiveAsset.getContentMetadata());
    this.scope = nonPrimitiveAsset.getScope();
  }

}
