/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.Map;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new status.
 * 
 * @author jeevansingh.dhami
 */
@Document
@EqualsAndHashCode
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "_status", "_lastModified", "_links" })
@Data
public class ProductStatus implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1199517324380078636L;

  /** The id. */
  @Id
  private transient String id;

  /** the _id. */
  @SerializedName("_id")
  @JsonProperty("_id")
  @Field("_id")
  private String _id;

  /** The status. */
  @SerializedName("_status")
  @JsonProperty("_status")
  @Field("_status")
  private String status;

  /** The last modified. */
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  @Field("_lastModified")
  private String lastModified;

  /** the links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  @Field("_links")
  private Map<String, Link> links;

  /** The content error. */
  @JsonProperty("error")
  private PlatformErrorResponse error;

}
