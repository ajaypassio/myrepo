/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class Task.
 */
@Document
@Data
@EqualsAndHashCode

/**
 * Instantiates a new task.
 */
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "_status", "_links", "resources" })
public class Task implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -9071104390216387533L;

  /** The id. */
  @Id
  private transient String id;

  /** The status. */
  @SerializedName("_id")
  @JsonProperty("_id")
  @Field("_id")
  public String _id;

  /** The status. */
  @SerializedName("_status")
  @JsonProperty("_status")
  @Field("_status")
  public String status;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  @Field("_links")
  public Links links;

  /** The resources. */
  @SerializedName("resources")
  @JsonProperty("resources")
  @Field("resources")
  // public Link resources;
  private List<TaskResource> resources;

}