/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.repository;

import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.repository.ReactiveCouchbaseRepository;
import org.springframework.stereotype.Repository;

import com.pearson.glp.lpb.data.model.AssetModel;

import reactor.core.publisher.Flux;

/**
 * The Interface AssetModelRepository.
 * 
 * @author srishti.singh
 */

@Repository
public interface LearningModelRepository extends ReactiveCouchbaseRepository<AssetModel, String> {

  /**
   * Find learning models.
   *
   * @param learningModelId
   *          the learning model id
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1")
  Flux<AssetModel> findLearningModels(String learningModelId);

  /**
   * Find learning models with label.
   *
   * @param learningModelId
   *          the learning model id
   * @param label
   *          the label
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1 AND UPPER(label) = UPPER($2)")
  Flux<AssetModel> findLearningModelsWithLabel(String learningModelId, String label);

  /**
   * Find learning models with tag.
   *
   * @param learningModelId
   *          the learning model id
   * @param tag
   *          the tag
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1 AND UPPER($2) WITHIN (SPLIT(UPPER(tags),','))")
  Flux<AssetModel> findLearningModelsWithTag(String learningModelId, String tag);

  /**
   * Find learning models with tag and label.
   *
   * @param learningModelId
   *          the learning model id
   * @param tag
   *          the tag
   * @param label
   *          the label
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1 AND UPPER($2) WITHIN (SPLIT(UPPER(tags),',')) AND UPPER(label) = UPPER($3)")
  Flux<AssetModel> findLearningModelsWithTagAndLabel(String learningModelId, String tag,
      String label);
}