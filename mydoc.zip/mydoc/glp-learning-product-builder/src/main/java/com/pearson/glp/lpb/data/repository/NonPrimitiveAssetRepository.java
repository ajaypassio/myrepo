/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.repository;

import static com.pearson.glp.lpb.constant.CommonConstants.COUNT_VIEW_NAME;
import static com.pearson.glp.lpb.constant.CommonConstants.COUNT_ZERO;
import static com.pearson.glp.lpb.constant.CommonConstants.LEARNING_ASSET_COUNT_VIEW;
import static com.pearson.glp.lpb.constant.CommonConstants.VIEW_DESIGN_NAME;

import com.couchbase.client.java.query.N1qlParams;
import com.couchbase.client.java.query.N1qlQuery;
import com.couchbase.client.java.query.Statement;
import com.couchbase.client.java.query.dsl.path.WherePath;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.ReactiveCouchbaseRepository;
import org.springframework.data.couchbase.repository.query.support.N1qlUtils;
import org.springframework.data.repository.util.ReactiveWrapperConverters;
import org.springframework.stereotype.Repository;

import com.couchbase.client.java.view.AsyncViewResult;
import com.couchbase.client.java.view.AsyncViewRow;
import com.couchbase.client.java.view.Stale;
import com.couchbase.client.java.view.ViewQuery;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import rx.Observable;

/**
 * The Interface NonPrimitiveAssetRepository.
 *
 * @author sankalp.katiyar
 */
@Repository
@ViewIndexed(designDoc = VIEW_DESIGN_NAME, viewName = COUNT_VIEW_NAME, mapFunction = LEARNING_ASSET_COUNT_VIEW)
public interface NonPrimitiveAssetRepository
    extends ReactiveCouchbaseRepository<NonPrimitiveAsset, String> {

  /**
   * Find assets.
   *
   * @param docTypeRegex
   *
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} where #{#n1ql.filter} AND meta().id like $1")
  Flux<NonPrimitiveAsset> findAssets(String docTypeRegex);

  /**
   * Find all assets with latest doc.
   *
   * @param limit
   *          the limit
   * @param offset
   *          the offset
   * @param docTypeRegex
   *          the doc type regex
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and meta(lpb).id like $3  LIMIT $1 OFFSET $2")
  Flux<NonPrimitiveAsset> findAllAssetsWithLatestDoc(int limit, int offset, String docTypeRegex);

  /**
   * Find the count of all latest learning asset by asset type
   *
   * @param assetType
   * @return
   */
  default Mono<Integer> countAllLatestLearningAsset(String assetType) {
    ViewQuery query = ViewQuery.from(VIEW_DESIGN_NAME, COUNT_VIEW_NAME);
    query.reduce(true).group(true).stale(Stale.FALSE);
    Observable observable = getCouchbaseOperations().queryView(query).flatMap(AsyncViewResult::rows)
        .filter(row -> assetType.equals(row.key().toString())).map(AsyncViewRow::value)
        .map(value -> Integer.valueOf(value.toString())).switchIfEmpty(Observable.just(COUNT_ZERO));
    return ReactiveWrapperConverters.toWrapper(observable, Mono.class);
  }

  /**
   * Find by asset type.
   *
   * @param documentIdRegex
   *          the document id regex
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1")
  Flux<NonPrimitiveAsset> findByAssetType(String documentIdRegex);

  /**
   * Find asset by parameters.
   *
   * @param whereClause
   *          the where clause
   * @return the flux
   */
  @SuppressWarnings("unchecked")
  default Flux<NonPrimitiveAsset> findAssetByParameters(StringBuilder whereClause) {

    WherePath selectFrom = N1qlUtils
        .createSelectFromForEntity(getCouchbaseOperations().getCouchbaseBucket().name());

    Statement statement = selectFrom.where(whereClause.toString());

    N1qlQuery query = N1qlQuery.simple(statement, N1qlParams.build());
    return ReactiveWrapperConverters
        .toWrapper(getCouchbaseOperations().findByN1QL(query, NonPrimitiveAsset.class), Flux.class);

  }

}