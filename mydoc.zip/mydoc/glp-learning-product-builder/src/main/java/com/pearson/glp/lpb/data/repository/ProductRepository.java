/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.data.repository;

import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.repository.ReactiveCouchbaseRepository;
import org.springframework.data.couchbase.repository.query.support.N1qlUtils;
import org.springframework.data.repository.util.ReactiveWrapperConverters;
import org.springframework.stereotype.Repository;

import com.couchbase.client.java.query.N1qlParams;
import com.couchbase.client.java.query.N1qlQuery;
import com.couchbase.client.java.query.Statement;
import com.couchbase.client.java.query.dsl.path.WherePath;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Interface ProductRepository.
 * 
 * @author kavya.jain
 *
 */
@Repository
public interface ProductRepository extends ReactiveCouchbaseRepository<NonPrimitiveAsset, String> {

  /**
   * Finds all products.
   *
   * @param documentIdRegex
   *          the documentIdRegex
   * @return the Flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1")
  Flux<NonPrimitiveAsset> findByAssetType(String documentIdRegex);

  /**
   * Find all products.
   *
   * @param contentUrn
   *          the contentUrn
   * @return the Mono
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like 'PRODUCT::LATEST%COMPOSE' AND extensions.contentMetadata.id = $1 "
      + "AND extensions.contentMetadata.version = $2 limit 1")
  Mono<NonPrimitiveAsset> getProductBy(String contentUrn, String versionUrn);

  /**
   * Find product by parameters.
   *
   * @param whereClause
   *          the where clause
   * @return the flux
   */
  @SuppressWarnings("unchecked")
  default Flux<NonPrimitiveAsset> findProductByParameters(StringBuilder whereClause) {

    WherePath selectFrom = N1qlUtils
        .createSelectFromForEntity(getCouchbaseOperations().getCouchbaseBucket().name());

    Statement statement = selectFrom.where(whereClause.toString());

    N1qlQuery query = N1qlQuery.simple(statement, N1qlParams.build());
    return ReactiveWrapperConverters
        .toWrapper(getCouchbaseOperations().findByN1QL(query, NonPrimitiveAsset.class), Flux.class);

  }

  /**
   * Find all versions by id.
   *
   * @param documentIdRegex
   *          the documentIdRegex
   * @return the flux
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1")
  Flux<NonPrimitiveAsset> findGetAllVersion(String documentIdRegex);

  /**
   * Gets the by id.
   *
   * @param documentIdRegex
   *          the document id regex
   * @return the by id
   */
  @Query("#{#n1ql.selectEntity} WHERE #{#n1ql.filter} AND meta().id like $1")
  Mono<NonPrimitiveAsset> getById(String documentIdRegex);
}