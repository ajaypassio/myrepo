/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.event.request;

import java.io.Serializable;
import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AutobahnPayLoad.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AutobahnPayLoad implements Serializable {
  /**
   * The serialVersionUID.
   */
  private static final long serialVersionUID = -8836137718047305685L;
  /**
   * The environment code.
   */
  private String environmentCode;
  /**
   * The message id.
   */
  private String messageId;
  /**
   * The message type code.
   */
  private String messageTypeCode;
  /**
   * The message version.
   */
  private String messageVersion;
  /**
   * The namespace code.
   */
  private String namespaceCode;

  /**
   * The originating system code.
   */
  private String originatingSystemCode;
  /**
   * The transaction dt.
   *
   */
  private String transactionDt;
  /**
   * The transaction type code.
   */
  private String transactionTypeCode;

  /** The product id. */
  private String productId;

  /** The content urn. */
  private String contentUrn;

  /** The version urn. */
  private String versionUrn;

  /** The product model name. */
  private String productModelName;

  /** The product platform code. */
  private String productPlatformCode;

}
