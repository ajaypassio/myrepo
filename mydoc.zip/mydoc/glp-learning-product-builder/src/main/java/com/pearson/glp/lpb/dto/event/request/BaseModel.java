/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.event.request;

import com.couchbase.client.java.repository.annotation.Id;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

import org.springframework.data.couchbase.core.mapping.Document;

/**
 * Base Class for all the domain model in the platform.
 *
 */
// @ApiModel
@Document
@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class BaseModel implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 3806991977726499647L;

  /**
   * System generated id field.
   */
  @JsonInclude(Include.NON_NULL)
  private String _id;

  /** System generated created date. */
  @JsonInclude(Include.NON_NULL)
  private Long _created;

  /** System generated updated date. */
  @JsonInclude(Include.NON_NULL)
  private Long _updated;

  /**
   * id field.
   */
  @Id
  protected String id;

  /** The created date. */
  private Long createdDate;

  /** The created by. */
  private String createdBy;

  /** The updated date. */
  private Long updatedDate;

  /** The updated by. */
  private String updatedBy;

  /** The tenant identifier. */
  private String tenantIdentifier;

  /** The doc type. */
  private String docType;
}