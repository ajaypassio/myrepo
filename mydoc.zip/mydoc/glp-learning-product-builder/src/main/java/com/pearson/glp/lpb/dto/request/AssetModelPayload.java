/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.lpb.data.model.AssetGraph;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Extends;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Groups;
import com.pearson.glp.lpb.data.model.ResourcePlan;
import com.pearson.glp.lpb.data.model.Scope;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceObject;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * The Class AssetModelPayload.
 * 
 * @author srishti.singh
 */
@Setter
@Getter
@EqualsAndHashCode
public class AssetModelPayload implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -4960342928059095715L;

  /** The asset type. */
  @SerializedName("_assetType")
  @JsonProperty("_assetType")
  @Field("_assetType")
  protected String assetType;

  /** The expires on. */
  @JsonProperty("expiresOn")
  protected String expiresOn;

  /** The label. */
  @JsonProperty("label")
  protected String label;

  /** The tags. */
  @JsonProperty("tags")
  protected String tags;

  /** The language. */
  @JsonProperty("language")
  protected String language;

  @SerializedName("_id")
  @JsonProperty("_id")
  @Field("_id")
  private String _id;

  @SerializedName("_ver")
  @JsonProperty("_ver")
  @Field("_ver")
  private String Ver;

  /** The created By. */
  @SerializedName("_createdBy")
  @JsonProperty("_createdBy")
  @Field("_createdBy")
  protected String _createdBy;

  /** The asset class. */
  @JsonProperty("assetClass")
  protected String assetClass;

  /** The objectives. */
  @JsonProperty("objectives")
  protected String objectives;

  /** The groups. */
  @JsonProperty("groups")
  protected Groups groups;

  /** The resources. */
  @JsonProperty("resources")
  protected LinkedHashMap<String, ResourceObject> resources;

  /** The asset graph. */
  @JsonProperty("assetGraph")
  protected ArrayList<AssetGraph> assetGraph;

  /** The resource plan. */
  @JsonProperty("resourcePlan")
  protected ArrayList<ResourcePlan> resourcePlan;

  /** The configuration. */
  @JsonProperty("configuration")
  protected Configuration configuration;

  /** The constraints. */
  @JsonProperty("constraints")
  protected ArrayList<Object> constraints;

  /** The extend. */
  @SerializedName("extends")
  @JsonProperty("extends")
  @Field("extends")
  protected Extends extend;

  /** The extensions. */
  @JsonProperty("extensions")
  protected Extensions extensions;

  /** The scope. */
  @JsonProperty("scope")
  protected Scope scope;

}