/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Instantiates a new product asset response.
 * 
 * @author jeevansingh.dhami
 */
@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductAssetResponse extends NonPrimitiveAsset {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -2019410811063635708L;
  /** The content error. */
  @JsonProperty("error")
  private PlatformErrorResponse error;

  /**
   * Instantiates a new product asset response.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   */
  public ProductAssetResponse(NonPrimitiveAsset nonPrimitiveAsset) {
    this.set_id(nonPrimitiveAsset.get_id());
    this.setCreatedBy(nonPrimitiveAsset.getCreatedBy());
    this.setAssetClass(nonPrimitiveAsset.getAssetClass());
    this.setAssetGraph(nonPrimitiveAsset.getAssetGraph());
    this.setAssetType(nonPrimitiveAsset.getAssetType());
    this.setBssVer(nonPrimitiveAsset.getBssVer());
    this.setConfiguration(nonPrimitiveAsset.getConfiguration());
    this.setConstraints(nonPrimitiveAsset.getConstraints());
    this.setCreated(nonPrimitiveAsset.getCreated());
    this.setLastModified(nonPrimitiveAsset.getLastModified());
    this.setDocType(nonPrimitiveAsset.getDocType());
    this.setExpiresOn(nonPrimitiveAsset.getExpiresOn());
    this.setExtend(nonPrimitiveAsset.getExtend());
    this.setExtensions(nonPrimitiveAsset.getExtensions());
    this.setGroups(nonPrimitiveAsset.getGroups());
    this.setLabel(nonPrimitiveAsset.getLabel());
    this.setLanguage(nonPrimitiveAsset.getLanguage());
    this.setLearningModel(nonPrimitiveAsset.getLearningModel());
    this.setLinks(nonPrimitiveAsset.getLinks());
    this.setObjectives(nonPrimitiveAsset.getObjectives());
    this.setResourcePlan(nonPrimitiveAsset.getResourcePlan());
    this.setResources(nonPrimitiveAsset.getResources());
    this.setScope(nonPrimitiveAsset.getScope());
    this.setTags(nonPrimitiveAsset.getTags());
    this.setVer(nonPrimitiveAsset.getVer());
  }

  /**
   * Instantiates a new product asset response.
   *
   * @param error
   *          the error
   */
  public ProductAssetResponse(PlatformErrorResponse error) {
    this.error = error;
  }

}