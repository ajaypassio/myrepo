/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.dto.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Extensions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ProductCollectionAsset.
 *
 * @author shubham.chaudhary
 */

@Setter
@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductCollectionAsset extends Asset implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 6087230580468016298L;

  /** The label. */
  @JsonProperty("label")
  private String label;

  /** The extensions. */
  @JsonProperty("extensions")
  private Extensions extensions;

  /** The configurations. */
  @JsonProperty("configuration")
  private Configuration configuration;

}
