/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.endpoints.routes;

import static org.springframework.web.reactive.function.server.RequestPredicates.DELETE;
import static org.springframework.web.reactive.function.server.RequestPredicates.PUT;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.errors.BaseHandlerFilterFunction;
import com.pearson.glp.lpb.errors.ErrorHandler;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * The Class Invalid Method Type Routes.
 *
 * @author sanket.gupta
 */
@Configuration
@NoArgsConstructor
@AllArgsConstructor
public class InvalidMethodTypeRoutes {

  /**
   * The context path.
   */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * The Error Handler.
   */
  @Autowired
  private ErrorHandler errorHandler;

  /** The instance of BaseHandlerFilterFunction */
  @Autowired
  private BaseHandlerFilterFunction baseHandlerFilterFunction;

  /**
   * Error Routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> errorRoutes() throws ServiceException {
    return RouterFunctions.nest(RequestPredicates.path(contextPath),
        RouterFunctions
            .route(PUT("/**").and(accept(MediaType.TEXT_PLAIN)),
                request -> errorHandler.getErrorResponse(request))
            .andRoute(POST("/**").and(accept(MediaType.TEXT_PLAIN)),
                request -> errorHandler.getErrorResponse(request))
            .andRoute(GET("/**").and(accept(MediaType.TEXT_PLAIN)),
                request -> errorHandler.getErrorResponse(request))
            .andRoute(DELETE("/**"), request -> errorHandler.getErrorResponse(request)));
  }
}
