/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.endpoints.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.COLON;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_AGGREGATES_ROUTES;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_ASSESSMENTS_ROUTES;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_EMBEDDED_ASSETS_ROUTES;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_INSTRUCTIONS_ROUTES;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_LEARNINGAPPS_ROUTES;
import static com.pearson.glp.lpb.enums.HandlerType.GET_AGGREGATES;
import static com.pearson.glp.lpb.enums.HandlerType.GET_AGGREGATES_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_AGGREGATE_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_AGGREGATE_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSESSMENTS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSESSMENTS_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ASSESSMENTS_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_INSTRUCTIONS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_INSTRUCTIONS_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_INSTRUCTION_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_INSTRUCTION_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_LEARNINGAPPS_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_LEARNINGAPPS_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.POST_AGGREGATES;
import static com.pearson.glp.lpb.enums.HandlerType.POST_AGGREGATES_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_ASSESSMENTS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_EMBEDDED_ASSETS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_INSTRUCTIONS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_INSTRUCTIONS_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_LEARNINGAPPS;
import static com.pearson.glp.lpb.enums.Routes.AGGREGATES_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.AGGREGATES_VERSIONS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.AGGREGATE_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.AGGREGATE_BY_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.ASSESSMENTS_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.ASSESSMENTS_BY_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.ASSESSMENTS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.EMBEDDED_ASSETS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.INSTRUCTIONS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.INSTRUCTIONS_VERSIONS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.INSTRUCTION_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.INSTRUCTION_BY_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.LEARNINGAPPS_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.LEARNINGAPPS_BY_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.LEARNINGAPPS_ROUTE;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.errors.BaseHandlerFilterFunction;
import com.pearson.glp.lpb.handlers.NonPrimitiveAssetHandler;

import lombok.NoArgsConstructor;

/**
 * The Class Non Primitive Asset Provisioning Routes.
 *
 * @author shubham.chaudhary
 *
 */
@Configuration

/**
 * Instantiates a new non primitive asset routes.
 */
@NoArgsConstructor
public class NonPrimitiveAssetRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(NonPrimitiveAssetRoutes.class);

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * The Non Primitive Asset Provisioning HandlerType.
   */
  @Autowired
  private NonPrimitiveAssetHandler nonPrimitiveHandler;

  /**
   * The service handler manager.
   */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /** The instance of BaseHandlerFilterFunction. */
  @Autowired
  private BaseHandlerFilterFunction baseHandlerFilterFunction;

  /**
   * Aggregates routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> aggregatesRoutes() throws ServiceException {

    try {
      return RouterFunctions.nest(RequestPredicates.path(contextPath), RouterFunctions
          .route(GET(AGGREGATES_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_AGGREGATES.name(),
                  context -> nonPrimitiveHandler.getAllAssets(context, AssetType.AGGREGATE)))

          .andRoute(POST(AGGREGATES_ROUTE.value()),
              serviceHandlerManager.getRestHandler(POST_AGGREGATES.name(),
                  context -> nonPrimitiveHandler.createAssets(context, AssetType.AGGREGATE)))

          .andRoute(GET(AGGREGATE_BY_ID_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_AGGREGATE_BY_ID.name(),
                  context -> nonPrimitiveHandler.getAssetById(context, AssetType.AGGREGATE)))

          .andRoute(GET(AGGREGATES_VERSIONS_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_AGGREGATES_VERSIONS.name(),
                  context -> nonPrimitiveHandler.getAssetVersions(context, AssetType.AGGREGATE)))

          .andRoute(POST(AGGREGATES_VERSIONS_ROUTE.value()),
              serviceHandlerManager.getRestHandler(POST_AGGREGATES_VERSIONS.name(),
                  context -> nonPrimitiveHandler.createAssetVersions(context, AssetType.AGGREGATE)))

          .andRoute(GET(AGGREGATE_BY_ID_AND_VERSION_ID_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_AGGREGATE_BY_ID_AND_VERSION_ID.name(),
                  context -> nonPrimitiveHandler.getAssetByAssetIdAndVersionId(context,
                      AssetType.AGGREGATE)))
          .filter(baseHandlerFilterFunction));
    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_AGGREGATES_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_AGGREGATES_ROUTES + COLON + e.getMessage());
    }
  }

  /**
   * Instructions routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> instructionsRoutes() throws ServiceException {
    try {
      return RouterFunctions.nest(RequestPredicates.path(contextPath), RouterFunctions
          .route(GET(INSTRUCTIONS_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_INSTRUCTIONS.name(),
                  context -> nonPrimitiveHandler.getAllAssets(context, AssetType.INSTRUCTION)))

          .andRoute(POST(INSTRUCTIONS_ROUTE.value()),
              serviceHandlerManager.getRestHandler(POST_INSTRUCTIONS.name(),
                  context -> nonPrimitiveHandler.createAssets(context, AssetType.INSTRUCTION)))

          .andRoute(GET(INSTRUCTION_BY_ID_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_INSTRUCTIONS_BY_ID.name(),
                  context -> nonPrimitiveHandler.getAssetById(context, AssetType.INSTRUCTION)))

          .andRoute(GET(INSTRUCTIONS_VERSIONS_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_INSTRUCTION_VERSIONS.name(),
                  context -> nonPrimitiveHandler.getAssetVersions(context, AssetType.INSTRUCTION)))

          .andRoute(POST(INSTRUCTIONS_VERSIONS_ROUTE.value()),
              serviceHandlerManager.getRestHandler(POST_INSTRUCTIONS_VERSIONS.name(),
                  context -> nonPrimitiveHandler.createAssetVersions(context,
                      AssetType.INSTRUCTION)))

          .andRoute(GET(INSTRUCTION_BY_ID_AND_VERSION_ID_ROUTE.value()),
              serviceHandlerManager.getRestHandler(GET_INSTRUCTION_BY_ID_AND_VERSION_ID.name(),
                  context -> nonPrimitiveHandler.getAssetByAssetIdAndVersionId(context,
                      AssetType.INSTRUCTION)))
          .filter(baseHandlerFilterFunction));
    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_INSTRUCTIONS_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_INSTRUCTIONS_ROUTES + COLON + e.getMessage());
    }
  }

  /**
   * Assessments routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> assessmentsRoutes() throws ServiceException {
    try {
      return RouterFunctions.nest(RequestPredicates.path(contextPath),
          RouterFunctions
              .route(POST(ASSESSMENTS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(POST_ASSESSMENTS.name(),
                      context -> nonPrimitiveHandler.createAssets(context, AssetType.ASSESSMENT)))

              .andRoute(GET(ASSESSMENTS_BY_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ASSESSMENTS_BY_ID.name(),
                      context -> nonPrimitiveHandler.getAssetById(context, AssetType.ASSESSMENT)))
              .andRoute(GET(ASSESSMENTS_BY_ID_AND_VERSION_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ASSESSMENTS_BY_ID_AND_VERSION_ID.name(),
                      context -> nonPrimitiveHandler.getAssetByAssetIdAndVersionId(context,
                          AssetType.ASSESSMENT)))
              .andRoute(GET(ASSESSMENTS_ROUTE.value()), serviceHandlerManager
                  .getRestHandler(GET_ASSESSMENTS.name(), nonPrimitiveHandler::getAssessments))
              .filter(baseHandlerFilterFunction));
    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_ASSESSMENTS_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_ASSESSMENTS_ROUTES + COLON + e.getMessage());
    }
  }

  /**
   * LearningApps routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> learningAppRoutes() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(POST(LEARNINGAPPS_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(POST_LEARNINGAPPS.name(),
                          context -> nonPrimitiveHandler.createAssets(context,
                              AssetType.LEARNINGAPP)))

                  .andRoute(GET(LEARNINGAPPS_BY_ID_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(GET_LEARNINGAPPS_BY_ID.name(),
                          context -> nonPrimitiveHandler.getAssetById(context,
                              AssetType.LEARNINGAPP)))
                  .andRoute(
                      GET(LEARNINGAPPS_BY_ID_AND_VERSION_ID_ROUTE
                          .value()),
                      serviceHandlerManager.getRestHandler(
                          GET_LEARNINGAPPS_BY_ID_AND_VERSION_ID.name(),
                          context -> nonPrimitiveHandler.getAssetByAssetIdAndVersionId(context,
                              AssetType.LEARNINGAPP)))
                  .filter(baseHandlerFilterFunction));
    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_LEARNINGAPPS_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_LEARNINGAPPS_ROUTES + COLON + e.getMessage());
    }
  }

  /**
   * Embedded assets routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> embeddedAssetsRoutes() throws ServiceException {

    try {
      return RouterFunctions.nest(RequestPredicates.path(contextPath),
          RouterFunctions
              .route(POST(EMBEDDED_ASSETS_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(POST_EMBEDDED_ASSETS.name(),
                      context -> nonPrimitiveHandler.createAssets(context, AssetType.AGGREGATE)))
              .filter(baseHandlerFilterFunction));
    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_EMBEDDED_ASSETS_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_EMBEDDED_ASSETS_ROUTES + COLON + e.getMessage());
    }
  }

}
