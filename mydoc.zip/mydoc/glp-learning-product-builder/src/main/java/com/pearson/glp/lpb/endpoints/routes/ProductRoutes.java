/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.endpoints.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.COLON;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_PRODUCT_ROUTES;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCTS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_BY_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_BY_ID_AND_VERSION_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_STATE_TRANSITION;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_STATUS;
import static com.pearson.glp.lpb.enums.HandlerType.GET_PRODUCT_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_PRODUCTS;
import static com.pearson.glp.lpb.enums.HandlerType.POST_PRODUCT_STATE_TRANSITION;
import static com.pearson.glp.lpb.enums.HandlerType.POST_PRODUCT_VERSIONS;
import static com.pearson.glp.lpb.enums.HandlerType.PUT_PRODUCT_STATUS;
import static com.pearson.glp.lpb.enums.Routes.GET_PRODUCT_ASSET_TYPES;
import static com.pearson.glp.lpb.enums.Routes.PRODUCTS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCTS_VERSIONS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_BY_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_STATUS;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_TRANSITION_STATE;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.POST;
import static org.springframework.web.reactive.function.server.RequestPredicates.PUT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;
import com.pearson.glp.lpb.errors.BaseHandlerFilterFunction;
import com.pearson.glp.lpb.handlers.ProductHandler;

import lombok.NoArgsConstructor;

/**
 * The Class Product Routes.
 *
 * @author kavya.jain
 */

@Configuration
@NoArgsConstructor
public class ProductRoutes {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductRoutes.class);

  /**
   * The Non Primitive Asset Provisioning HandlerType.
   */
  @Autowired
  private ProductHandler productHandler;

  /**
   * The service handler manager.
   */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /** The instance of BaseHandlerFilterFunction */
  @Autowired
  private BaseHandlerFilterFunction baseHandlerFilterFunction;

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Product routes.
   *
   * @return the router function
   */
  @Bean
  public RouterFunction<ServerResponse> routes() throws ServiceException {

    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(GET(PRODUCTS_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCTS.name(),
                          productHandler::getProduct))
                  .andRoute(GET(PRODUCTS_VERSIONS_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCT_VERSIONS.name(),
                          productHandler::getProductVersions))
                  .andRoute(POST(PRODUCTS_VERSIONS_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(POST_PRODUCT_VERSIONS.name(),
                          productHandler::createNewProduct))
                  .andRoute(POST(PRODUCTS_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(POST_PRODUCTS.name(),
                          productHandler::postProduct))
                  .andRoute(GET(PRODUCT_BY_ID_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCT_BY_ID.name(),
                          productHandler::getProductById))
                  .andRoute(GET(PRODUCT_BY_ID_AND_VERSION_ID_ROUTE.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCT_BY_ID_AND_VERSION_ID.name(),
                          productHandler::getProductByIdAndVersion))
                  .andRoute(GET(PRODUCT_TRANSITION_STATE.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCT_STATE_TRANSITION.name(),
                          productHandler::getProductStateTransition))
                  .andRoute(POST(PRODUCT_TRANSITION_STATE.value()),
                      serviceHandlerManager.getRestHandler(POST_PRODUCT_STATE_TRANSITION.name(),
                          productHandler::postProductStateTransition))
                  .andRoute(GET(PRODUCT_STATUS.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCT_STATUS.name(),
                          productHandler::getProductStatus))
                  .andRoute(PUT(PRODUCT_STATUS.value()),
                      serviceHandlerManager.getRestHandler(PUT_PRODUCT_STATUS.name(),
                          productHandler::updateProductStatus))
                  .andRoute(GET(GET_PRODUCT_ASSET_TYPES.value()),
                      serviceHandlerManager.getRestHandler(GET_PRODUCT_ASSET_TYPES.name(),
                          productHandler::getProductAssetTypes)))
          .filter(baseHandlerFilterFunction);
    }

    catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_PRODUCT_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_PRODUCT_ROUTES + COLON + e.getMessage());
    }
  }

}
