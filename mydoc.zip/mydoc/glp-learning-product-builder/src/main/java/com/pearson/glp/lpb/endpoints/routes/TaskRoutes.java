/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.endpoints.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.COLON;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_REGISTERING_TASK_ROUTES;
import static com.pearson.glp.lpb.enums.HandlerType.GET_ENTITY_BY_TASK_ID;
import static com.pearson.glp.lpb.enums.HandlerType.GET_TASK_BY_ID;
import static com.pearson.glp.lpb.enums.Routes.LONG_RUNNING_ENTITY_BY_TASK_ID_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.TASK_BY_ID_ROUTE;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;
import com.pearson.glp.lpb.errors.BaseHandlerFilterFunction;
import com.pearson.glp.lpb.handlers.TaskHandler;

import lombok.NoArgsConstructor;

/**
 * The Class TaskRoutes.
 *
 * @author sankalp.katiyar
 */
@Configuration
@NoArgsConstructor
public class TaskRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(TaskRoutes.class);

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /** The task handler. */
  @Autowired
  private TaskHandler taskHandler;

  /** The instance of BaseHandlerFilterFunction. */
  @Autowired
  private BaseHandlerFilterFunction baseHandlerFilterFunction;

  /**
   * The service handler manager.
   */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /**
   * Task route.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> taskRoute() throws ServiceException {

    try {
      return RouterFunctions.nest(RequestPredicates.path(contextPath),
          RouterFunctions
              .route(GET(TASK_BY_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_TASK_BY_ID.name(),
                      taskHandler::getTaskById))
              .andRoute(GET(LONG_RUNNING_ENTITY_BY_TASK_ID_ROUTE.value()),
                  serviceHandlerManager.getRestHandler(GET_ENTITY_BY_TASK_ID.name(),
                      taskHandler::getLongRunningEntityByTaskId))
              .filter(baseHandlerFilterFunction));
    } catch (ServiceException e) {
      LOGGER.error(ERROR_REGISTERING_TASK_ROUTES, e);
      throw new ServiceException(ERROR_REGISTERING_TASK_ROUTES + COLON + e.getMessage());
    }
  }

}
