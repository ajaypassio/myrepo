/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.enums;

import com.fasterxml.jackson.annotation.JsonValue;

import static javax.ws.rs.HttpMethod.GET;
import static javax.ws.rs.HttpMethod.POST;
import static javax.ws.rs.HttpMethod.PUT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * The Enum Routes.
 */
public enum Routes {

  /** The aggregates route. */
  AGGREGATES_ROUTE("/v2/aggregates", GET, POST),
  /** The aggregate by id route. */
  AGGREGATE_BY_ID_ROUTE("/v2/aggregates/{id}", GET),
  /** The aggregates versions route. */
  AGGREGATES_VERSIONS_ROUTE("/v2/aggregates/{id}/versions", GET, POST),
  /** The aggregate by id and version id route. */
  AGGREGATE_BY_ID_AND_VERSION_ID_ROUTE("/v2/aggregates/{id}/versions/{ver}", GET),
  /** The instructions route. */
  INSTRUCTIONS_ROUTE("/v2/instructions", GET, POST),
  /** The instruction by id route. */
  INSTRUCTION_BY_ID_ROUTE("/v2/instructions/{id}", GET),
  /** The instructions versions route. */
  INSTRUCTIONS_VERSIONS_ROUTE("/v2/instructions/{id}/versions", GET, POST),
  /** The instruction by id and version id route. */
  INSTRUCTION_BY_ID_AND_VERSION_ID_ROUTE("/v2/instructions/{id}/versions/{ver}", GET),
  /** The asset models route. */
  ASSET_MODELS_ROUTE("/v2/assetModels", GET, POST),
  /** The asset models versions route. */
  ASSET_MODELS_VERSIONS_ROUTE("/v2/assetModels/{id}/versions", GET, POST),
  /** The asset model by id route. */
  ASSET_MODEL_BY_ID_ROUTE("/v2/assetModels/{id}", GET),
  /** The asset model by id and version id route. */
  ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE("/v2/assetModels/{id}/versions/{ver}", GET),
  /** The product models route. */
  PRODUCT_MODELS_ROUTE("/v2/productModels", GET, POST),
  /** The product models versions route. */
  PRODUCT_MODELS_VERSIONS_ROUTE("/v2/productModels/{id}/versions", GET, POST),
  /** The product model by id route. */
  PRODUCT_MODEL_BY_ID_ROUTE("/v2/productModels/{id}", GET),
  /** The product model by id and version id route. */
  PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE("/v2/productModels/{id}/versions/{ver}", GET),
  /** The task by id route. */
  TASK_BY_ID_ROUTE("/v2/tasks/{id}", GET),
  /** The products route. */
  PRODUCTS_ROUTE("/v2/products", GET, POST),
  /** The products versions route. */
  PRODUCTS_VERSIONS_ROUTE("/v2/products/{id}/versions", GET, POST),
  /** The product by id route. */
  PRODUCT_BY_ID_ROUTE("/v2/products/{id}", GET),
  /** The product by id and version id route. */
  PRODUCT_BY_ID_AND_VERSION_ID_ROUTE("/v2/products/{id}/versions/{ver}", GET),
  /** The long running entity by task id route. */
  LONG_RUNNING_ENTITY_BY_TASK_ID_ROUTE("/v2/tasks/{id}/{entity}", GET),
  /** The product transition state. */
  PRODUCT_TRANSITION_STATE("/v2/products/{id}/versions/{ver}/stateTransitions", GET, POST),
  /** The product status. */
  PRODUCT_STATUS("/v2/products/{id}/versions/{ver}/status", GET, PUT),
  /** The get product asset types. */
  GET_PRODUCT_ASSET_TYPES("/v2/products/{id}/versions/{ver}/assetTypes", GET),
  /** The assessments route. */
  ASSESSMENTS_ROUTE("/v2/assessments", POST),
  /** The assessments by id route. */
  ASSESSMENTS_BY_ID_ROUTE("/v2/assessments/{id}", GET),
  /** The assessments by id and version id route. */
  ASSESSMENTS_BY_ID_AND_VERSION_ID_ROUTE("/v2/assessments/{id}/versions/{ver}", GET),
 /** The learningapps by id and version id route. */
  LEARNINGAPPS_BY_ID_AND_VERSION_ID_ROUTE("/v2/learningApps/{id}/versions/{ver}", GET),
  /** The learningapps by id route. */
  LEARNINGAPPS_BY_ID_ROUTE("/v2/learningApps/{id}", GET),
  /** The learningApps route. */
  LEARNINGAPPS_ROUTE("/v2/learningApps", POST),
  
  /** The embedded assets route. */
  EMBEDDED_ASSETS_ROUTE("/v2/embeddedAssets", POST);

  /** The url. */
  private final String url;
  private final List<String> allowedHttpMethods;

  /**
   * Instantiates a new routes.
   *
   * @param url
   *          the url
   */
  Routes(String url, String... allowedMethod) {
    this.url = url;
    this.allowedHttpMethods = new ArrayList<>();
    this.allowedHttpMethods.addAll(Arrays.asList(allowedMethod));
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.url;
  }

  /**
   * Value.
   *
   * @return the string
   */
  @JsonValue
  public String value() {
    return this.url;
  }

  /**
   * Value.
   *
   * @return the string
   */
  public List<String> getAllowedHttpMethods() {
    return this.allowedHttpMethods;
  }

}