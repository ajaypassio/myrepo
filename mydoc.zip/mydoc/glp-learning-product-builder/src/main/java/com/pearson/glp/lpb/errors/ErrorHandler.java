/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.errors;

import static com.pearson.glp.lpb.constant.CommonConstants.LPB_CONTEXT_PATH;
import static com.pearson.glp.lpb.constant.LoggingConstants.INVALID_METHOD_TYPE_ERROR_MESSAGE;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.lpb.enums.Routes;
import com.pearson.glp.lpb.utils.HandlerValidationUtil;
import com.sun.jersey.api.uri.UriTemplate;

import reactor.core.publisher.Mono;

/**
 * The Class ErrorHandler.
 *
 * @author Nitin.tyagi1
 */

@Component
@Order(-2)
public class ErrorHandler extends AbstractErrorWebExceptionHandler {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandler.class);

  /** The validation util. */
  @Autowired
  private HandlerValidationUtil validationUtil;

  /** The routes. */
  private List<Routes> routes = Arrays.asList(Routes.values());

  public ErrorHandler(ApplicationContext applicationContext,
      ServerCodecConfigurer serverCodecConfigurer) {
    super(new DefaultErrorAttributes(), new ResourceProperties(), applicationContext);
    super.setMessageWriters(serverCodecConfigurer.getWriters());
    super.setMessageReaders(serverCodecConfigurer.getReaders());
  }

  @Override
  protected RouterFunction<ServerResponse> getRoutingFunction(
      final ErrorAttributes errorAttributes) {
    LOGGER.debug("Error handler");
    return RouterFunctions.route(RequestPredicates.all(), this::getErrorResponse);
  }

  /**
   * Generate method not allowed error
   *
   * @param request
   *          the request
   * @return Mono of ServerResponse
   */
  public Mono<ServerResponse> getErrorResponse(ServerRequest request) {
    LOGGER.debug(INVALID_METHOD_TYPE_ERROR_MESSAGE);
    if (validateURI(request)) {
      if (!validateURIMethod(request)) {
        return ServerResponse.status(HttpStatus.METHOD_NOT_ALLOWED)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .body(BodyInserters.fromObject(validationUtil.prepareMethodNotAllowedResponse()));
      } else {
        return ServerResponse.status(HttpStatus.NOT_ACCEPTABLE)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .body(BodyInserters.fromObject(validationUtil.prepareMediaTypeNotAcceptableResponse()));
      }
    }
    return ServerResponse.status(HttpStatus.NOT_FOUND).contentType(MediaType.APPLICATION_JSON_UTF8)
        .body(BodyInserters.fromObject(validationUtil.prepareNotFoundResponse()));
  }

  private boolean validateURI(ServerRequest request) {
    return routes.stream().anyMatch(route -> new UriTemplate(LPB_CONTEXT_PATH + route)
        .match(removeEndingSlash(request.path()), new HashMap<>()));
  }

  private boolean validateURIMethod(ServerRequest request) {
    return routes.stream()
        .anyMatch(route -> new UriTemplate(LPB_CONTEXT_PATH + route)
            .match(removeEndingSlash(request.path()), new HashMap<>())
            && route.getAllowedHttpMethods().stream()
                .anyMatch(method -> method.equals(request.method().name())));
  }

  private String removeEndingSlash(String uri) {
    return uri.charAt(uri.length() - 1) == '/' ? uri.substring(0, uri.length() - 1) : uri;
  }

}
