/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.ASSET_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONFIGURATION;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.DOUBLE_COLON;
import static com.pearson.glp.lpb.constant.CommonConstants.FETCH_PRODUCT_ASSET_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.FETCH_PRODUCT_STATE_TRANSITION;
import static com.pearson.glp.lpb.constant.CommonConstants.FETCH_PRODUCT_STATUS;
import static com.pearson.glp.lpb.constant.CommonConstants.FIELDS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.RESPONSE_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.RESPONSE_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.STATE_TRANSITION;
import static com.pearson.glp.lpb.constant.CommonConstants.STRING_JOINER_COMMA;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSION;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSIONS;
import static com.pearson.glp.lpb.constant.CommonConstants.ZERO_INDEX;
import static com.pearson.glp.lpb.constant.LMValidationConstants.AND_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATING_NEW_PRODUCT;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATING_NEW_PRODUCT_WITH_LATEST_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_PRODUCT;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_INVALID_URL_FOR_PRODUCT;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_IN_PRODUCT_STATE_TRANSITION;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_IN_SAVING_PRDOUCT_STATUS;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PRODUCT_NOT_FOUND;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PRODUCT_SCANNING_NOT_DONE;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PRODUCT_STATUS_NOT_FOUND;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCHING_CONFIGUARTION;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCHING_PRODUCT_BY_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCHING_PRODUCT_BY_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCH_PRODUCT;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_ALL_PRODUCT;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_PRODUCT_VERSIONS;
import static com.pearson.glp.lpb.constant.LoggingConstants.INVALID_REQUEST_PAYLOAD;
import static com.pearson.glp.lpb.constant.LoggingConstants.NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.NOT_AVAILABLE;
import static com.pearson.glp.lpb.constant.LoggingConstants.PARAM_NOT_ALLOWED_IN_FILTERING;
import static com.pearson.glp.lpb.constant.LoggingConstants.PRODUCT_IS_IN_LIVE_STATE;
import static com.pearson.glp.lpb.constant.LoggingConstants.PRODUCT_IS_IN_LIVE_STATE_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.PRODUCT_STATE_TRANSITION_BEGINS;
import static com.pearson.glp.lpb.constant.LoggingConstants.PRODUCT_STATUS_NOT_FOUND;
import static com.pearson.glp.lpb.constant.LoggingConstants.REQUESTED_RESOURCE;
import static com.pearson.glp.lpb.constant.LoggingConstants.REVIEW_PRODUCT_IS_LIVE;
import static com.pearson.glp.lpb.constant.LoggingConstants.SCHEMA_VALIDATION_FAILS;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.internalServerError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.invalidRequestError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.objectNotFoundError;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.data.model.AssetClassType;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.ProductStatus;
import com.pearson.glp.lpb.dto.request.ProductPayload;
import com.pearson.glp.lpb.dto.request.ProductStatusPayload;
import com.pearson.glp.lpb.dto.request.ProductVersionPayload;
import com.pearson.glp.lpb.dto.request.StateTransitionPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.dto.response.ProductCollectionResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.ProductQueryParameter;
import com.pearson.glp.lpb.enums.ProductsStatus;
import com.pearson.glp.lpb.exceptions.SchemaValidationException;
import com.pearson.glp.lpb.services.ProductService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;

import lombok.NoArgsConstructor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class Product HandlerType.
 *
 * @author kavya.jain
 */
@Component
@NoArgsConstructor
public class ProductHandler implements CommonUtils {

  /** Product Service. */
  @Autowired
  private ProductService productService;

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductHandler.class);

  /** The task enabled. */
  @Value("${task.disable:true}")
  private boolean taskDisable;

  /**
   * Gets the product.
   *
   * @param context
   *          the context
   * @return the Product
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProduct(ServiceHandlerContext context)
      throws ServiceException {
    MultiValueMap<String, String> parameters = context.getAllParameters();
    if (parameters.isEmpty()) {
      return getAllProducts(context);
    }
    List<String> params = ProductQueryParameter.getEnumValues();
    for (String obj : parameters.keySet()) {
      if (!params.contains(obj)) {
        return invalidRequestError(ERROR_INVALID_URL_FOR_PRODUCT);
      }
    }
    List<String> responseTypeList = context.getHeader(RESPONSE_TYPE);
    boolean responseWithLA = CollectionUtils.isEmpty(responseTypeList)
        || !RESPONSE_TYPE_HAL.equals(responseTypeList.get(ZERO_INDEX));

    return getProductsByParameters(parameters, responseWithLA);
  }

  /**
   * Gets all Products.
   *
   * @param context
   *          the context
   * @return the Mono
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getAllProducts(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(GETTING_ALL_PRODUCT);
    Mono<AssetBulkResponse> product = productService.getAllProducts();
    return product.flatMap(ob -> JsonPayloadServiceResponse.ok()
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(ob))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
  }

  /**
   * Gets the products by parameters.
   *
   * @param parameters
   *          the parameters
   * @param responseWithLA
   *          the response with LA
   * @return the products by parameters
   */
  private Mono<ServiceHandlerResponse> getProductsByParameters(
      MultiValueMap<String, String> parameters, boolean responseWithLA) {
    if (responseWithLA) {
      Flux<NonPrimitiveAsset> product = productService
          .findProductCollectionWithCompleteLA(parameters);
      return product
          .collectList().flatMap(ob -> JsonPayloadServiceResponse.ok()
              .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(ob))
          .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
    } else {
      Mono<ProductCollectionResponse> product = productService.findProductCollection(parameters);
      return product.flatMap(ob -> JsonPayloadServiceResponse.ok()
          .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(ob))
          .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
    }
  }

  /**
   * Empty.
   *
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> empty() {
    return objectNotFoundError(ERROR_PRODUCT_NOT_FOUND);
  }

  /**
   * On error.
   *
   * @param error
   *          the error
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> onError() {
    return internalServerError(ERROR_FETCHING_PRODUCT);
  }

  /**
   * Gets the product versions.
   *
   * @param context
   *          the context
   * @return the product versions
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductVersions(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(GETTING_PRODUCT_VERSIONS);

    String id = context.getParameter("id");
    Mono<AssetVersionsResponse> assetVersionResponse = productService.findProductVersionsById(id);
    return assetVersionResponse
        .flatMap(
            response -> response.getCount() > 0
                ? JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
                    .setPayload(response)
                : objectNotFoundError(ERROR_PRODUCT_NOT_FOUND))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND))
        .onErrorResume(error -> onError());
  }

  /**
   * Gets the product by id and version.
   *
   * @param context
   *          the context
   * @return the product by id and version
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductByIdAndVersion(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(FETCHING_PRODUCT_BY_VERSION);

    String id = context.getParameter(ID);
    String version = context.getParameter(VERSION);
    Optional<String> fields = context.getOptionalParameter(FIELDS);
    if (fields.isPresent()) {
      return Optional.of(CONFIGURATION).equals(fields) ? getProductPolicy(id, version)
          : objectNotFoundError(ERROR_PRODUCT_NOT_FOUND);
    }

    Mono<NonPrimitiveAsset> product = productService.findProductByVersion(id, version);

    return product
        .flatMap(ob -> JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload(ob))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND))
        .onErrorResume(error -> onError());
  }

  /**
   * Creates the new product.
   *
   * @param context
   *          the context
   * @return the mono
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> createNewProduct(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(CREATING_NEW_PRODUCT_WITH_LATEST_VERSION);
    String assetId = context.getParameter(ID);
    Mono<ProductVersionPayload> productPayload = context.getPayload(ProductVersionPayload.class);
    return productPayload.flatMap(asset -> {
      if (Optional.ofNullable(asset.getAsset()).isPresent()) {
        Mono<NonPrimitiveAsset> productNonPrimitiveAssetMono = productService
            .findLatestAssetVersionById(
                nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, assetId));
        return productNonPrimitiveAssetMono
            .flatMap(productNonPrimitiveAsset -> createAssetVersion(Mono.just(asset), assetId,
                productNonPrimitiveAsset.getBssVer(), AssetType.PRODUCT))
            .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
      }
      return invalidRequestError(INVALID_REQUEST_PAYLOAD);
    }).switchIfEmpty(invalidRequestError(INVALID_REQUEST_PAYLOAD));
  }

  /**
   * Post product.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProduct(ServiceHandlerContext context) {
    LOGGER.debug(CREATING_NEW_PRODUCT);

    Mono<ProductPayload> productPayload = context.getPayload(ProductPayload.class);
    return productPayload.flatMap(payload -> {
      if (Optional.ofNullable(payload.getAsset()).isPresent()) {
        return createProductResponse(AssetType.PRODUCT, payload);
      }
      return invalidRequestError(INVALID_REQUEST_PAYLOAD);
    }).onErrorResume(ex -> getError(AssetType.PRODUCT, ex))
        .switchIfEmpty(invalidRequestError(INVALID_REQUEST_PAYLOAD));
  }

  /**
   * Gets the products by id.
   *
   * @param context
   *          the context
   * @return the products by id
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductById(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(FETCHING_PRODUCT_BY_ID);
    String id = context.getParameter(ID);
    Mono<NonPrimitiveAsset> product = productService.findProductById(id);

    return product.flatMap(ob -> JsonPayloadServiceResponse.ok()
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(ob))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
  }

  /**
   * Creates the asset version.
   *
   * @param productPayload
   *          the product payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> createAssetVersion(
      Mono<ProductVersionPayload> productPayload, String assetId, Integer bssVer,
      AssetType assetType) {

    return productPayload.flatMap(payload -> {
      if (Optional.ofNullable(payload.getAsset()).isPresent()) {
        return createProductVersionResponse(assetId, bssVer, assetType, payload);
      }
      return invalidRequestError(INVALID_REQUEST_PAYLOAD);
    }).onErrorResume(ex -> getError(assetType, ex));
  }

  /**
   * Creates the product version response.
   *
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @param payload
   *          the payload
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> createProductVersionResponse(String assetId, Integer bssVer,
      AssetType assetType, ProductVersionPayload payload) {
    return productService.validateProductVersion(payload, assetId, bssVer, assetType)
        .flatMap(response -> {
          if (response.getError() != null) {
            return getError(AssetType.PRODUCT.name(), response.getError());
          }
          if (taskDisable) {
            return productService.saveProduct(payload.getAsset(), response.getAsset())
                .flatMap(task -> JsonPayloadServiceResponse.withStatus(HttpStatus.CREATED)
                    .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(task))
                .onErrorResume(error -> getError(AssetType.PRODUCT, error));

          }
          return productService
              .createProductVersionNonPrimitiveAssets(payload, response.getAsset(), assetId, bssVer,
                  assetType)
              .flatMap(
                  task -> JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
                      .setStatus(HttpStatus.ACCEPTED).setPayload(task));
        });
  }

  /**
   * Gets the error.
   *
   * @param assetType
   *          the asset type
   * @param error
   *          the error
   * @return the error
   */
  private Mono<ServiceHandlerResponse> getError(String assetType, PlatformErrorResponse error) {
    if (HttpStatus.BAD_REQUEST.value() == error.getStatus()) {
      LOGGER.debug(SCHEMA_VALIDATION_FAILS, error.getMessage());
      return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST).setPayload(error);
    }
    LOGGER.error(ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION, assetType, error.getMessage());
    return internalServerError(assetType + NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE);

  }

  /**
   * Gets the error.
   *
   * @param assetType
   *          the asset type
   * @param ex
   *          the ex
   * @return the error
   */
  private Mono<ServiceHandlerResponse> getError(AssetType assetType, Throwable ex) {
    if (ex instanceof SchemaValidationException) {
      LOGGER.debug(SCHEMA_VALIDATION_FAILS, ex);
      SchemaValidationException exception = (SchemaValidationException) ex;
      return PlatformErrorUtils.invalidRequestError(exception.getMessage(), exception.getLink());

    }
    LOGGER.error(ERROR_CREATING_NON_PRIMITIVE_ASSET_VERSION, assetType.value(), ex);
    return internalServerError(assetType.value() + NON_PRIMITIVE_ASSET_VERSION_NOT_SAVED_MESSAGE);
  }

  /**
   * Creates the product response.
   *
   * @param assetType
   *          the asset type
   * @param payload
   *          the payload
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> createProductResponse(AssetType assetType,
      ProductPayload payload) {
    return productService.validateProduct(payload, assetType).flatMap(response -> {
      if (response.getError() != null) {
        return getError(AssetType.PRODUCT.name(), response.getError());
      }
      if (taskDisable) {
        return productService.saveProduct(payload.getAsset(), response.getAsset())
            .flatMap(task -> JsonPayloadServiceResponse.withStatus(HttpStatus.CREATED)
                .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(task))
            .onErrorResume(error -> getError(AssetType.PRODUCT, error));

      }
      return productService.createProductNonPrimitiveAssets(payload, response.getAsset(), assetType)
          .flatMap(
              task -> JsonPayloadServiceResponse.withStatus(HttpStatus.ACCEPTED).setPayload(task));
    });
  }

  /**
   * Gets the product state transition.
   *
   * @param context
   *          the context
   * @return the Product
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductStateTransition(ServiceHandlerContext context)
      throws ServiceException {
    LOGGER.debug(FETCH_PRODUCT_STATE_TRANSITION, context.getParameter(ID),
        context.getParameter(VERSION));
    return productService
        .fetchProductStateTransition(STATE_TRANSITION + DOUBLE_COLON + context.getParameter(ID)
            + DOUBLE_COLON + VERSIONS + DOUBLE_COLON + context.getParameter(VERSION))
        .flatMap(state -> JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload(state))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));

  }

  /**
   * Gets the product status.
   *
   * @param context
   *          the context
   * @return the product status
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductStatus(ServiceHandlerContext context)
      throws ServiceException {

    LOGGER.debug(FETCH_PRODUCT_STATUS, context.getParameter(ID), context.getParameter(VERSION));
    return productService
        .fetchProductStatus(productStatusDocumentId(AssetType.PRODUCT, context.getParameter(ID),
            context.getParameter(VERSION)))
        .flatMap(state -> JsonPayloadServiceResponse.ok().setPayload(state))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_STATUS_NOT_FOUND));
  }

  /**
   * updates the product status.
   *
   * @param context
   *          the context
   * @return the product status
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> updateProductStatus(ServiceHandlerContext context)
      throws ServiceException {
    String productId = context.getParameter(ID);
    String productVersion = context.getParameter(VERSION);
    LOGGER.debug(FETCH_PRODUCT, productId, productVersion);
    Mono<NonPrimitiveAsset> productNonPrimitiveAssetMono = productService
        .findLatestAssetById(CommonUtils.nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT,
            productId, productVersion));
    return productNonPrimitiveAssetMono.flatMap(productLA -> {
      Mono<ProductStatusPayload> productStatus = context.getPayload(ProductStatusPayload.class);
      LOGGER.debug(FETCH_PRODUCT_STATUS, productId, productVersion);
      return productService
          .fetchProductStatus(productStatusDocumentId(AssetType.PRODUCT, productId, productVersion))
          .flatMap(currentStatusDoc -> {
            return productStatus.flatMap(nextStatus -> {
              return productService.saveStatusDocument(productLA, currentStatusDoc, nextStatus)
                  .flatMap(newStatusDoc -> {
                    if (Optional.ofNullable(newStatusDoc.getError()).isPresent()) {
                      return getError(AssetType.PRODUCT.value(), newStatusDoc.getError());
                    }
                    return JsonPayloadServiceResponse.ok().setPayload(newStatusDoc);
                  }).onErrorResume(error -> {
                    LOGGER.error(ERROR_IN_SAVING_PRDOUCT_STATUS, error);
                    return internalServerError(ERROR_IN_SAVING_PRDOUCT_STATUS + error.getMessage());
                  });
            });
          }).switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_STATUS_NOT_FOUND));
    }).switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
  }

  /**
   * Gets the product asset types.
   *
   * @param context
   *          the context
   * @return the product status
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductAssetTypes(ServiceHandlerContext context)
      throws ServiceException {
    String id = context.getParameter(ID);
    String version = context.getParameter(VERSION);
    LOGGER.debug(FETCH_PRODUCT_ASSET_TYPE, id, version);
    Mono<ProductAssetClassType> productAssetTypeMono = productService.getProductAssetTypes(id,
        version);
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>(
        context.getAllParameters());
    parameters.remove(ID);
    parameters.remove(VERSION);
    Optional<String> assetType = context.getOptionalParameter(ASSET_TYPE);
    if (!parameters.isEmpty()) {
      String invalidParam = parameters.keySet().stream().filter(param -> !ASSET_TYPE.equals(param))
          .collect(Collectors.joining(STRING_JOINER_COMMA));
      if (assetType.isPresent() && StringUtils.isEmpty(invalidParam)) {
        productAssetTypeMono = productAssetTypeMono.map(productAssetType -> {
          List<AssetClassType> assetClassTypes = productAssetType.getContent().getData()
              .getAssetClassTypes().stream()
              .filter(classType -> classType.getAssetType().equals(assetType.get()))
              .collect(Collectors.toList());
          productAssetType.getContent().getData().setAssetClassTypes(assetClassTypes);
          return productAssetType;
        });
      } else {
        return invalidRequestError(invalidParam + PARAM_NOT_ALLOWED_IN_FILTERING);
      }
    }
    return productAssetTypeMono.flatMap(productAssetType -> {
      if (!parameters.isEmpty()
          && productAssetType.getContent().getData().getAssetClassTypes().isEmpty()) {
        return objectNotFoundError(REQUESTED_RESOURCE + assetType.get() + NOT_AVAILABLE);
      } else {
        return JsonPayloadServiceResponse.ok().setPayload(productAssetType);
      }
    }).onErrorResume(error -> onError()).switchIfEmpty(findProductByIdVersion(id, version));
  }

  /**
   * Check product is present or not and return error response accordingly
   *
   * @param id
   * @param version
   * @return
   */
  private Mono<ServiceHandlerResponse> findProductByIdVersion(String id, String version) {
    Mono<NonPrimitiveAsset> productMono = productService.findProductByVersion(id, version);
    return productMono
        .flatMap(productAssetType -> objectNotFoundError(ERROR_PRODUCT_SCANNING_NOT_DONE))
        .onErrorResume(error -> onError())
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));
  }

  /**
   * Creates the new state transition of a product.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProductStateTransition(ServiceHandlerContext context) {
    LOGGER.debug(PRODUCT_STATE_TRANSITION_BEGINS);
    String id = context.getParameter(ID);
    String version = context.getParameter(VERSION);
    Mono<StateTransitionPayload> payload = context.getPayload(StateTransitionPayload.class);
    Mono<NonPrimitiveAsset> product = productService.findProductByVersion(id, version);
    return product
        .flatMap(reviewProduct -> productService
            .fetchProductStateTransition(STATE_TRANSITION + DOUBLE_COLON + reviewProduct.get_id()
                + DOUBLE_COLON + VERSIONS + DOUBLE_COLON + reviewProduct.getVer())
            .flatMap(stateTransition -> invalidRequestError(REVIEW_PRODUCT_IS_LIVE
                + stateTransition.getProductId() + AND_VERSION + stateTransition.getVer()))
            .switchIfEmpty(getStateTransitionResponse(reviewProduct, payload, id, version)))
        .switchIfEmpty(empty());
  }

  /**
   * Gets the state transition response.
   *
   * @param reviewProduct
   *          the review product
   * @param payload
   *          the payload
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the state transition response
   */
  private Mono<ServiceHandlerResponse> getStateTransitionResponse(NonPrimitiveAsset reviewProduct,
      Mono<StateTransitionPayload> payload, String id, String version) {

    Mono<ProductStatus> prodStatus = productService.fetchProductStatus(
        productStatusDocumentId(AssetType.PRODUCT, reviewProduct.get_id(), reviewProduct.getVer()));
    return prodStatus.flatMap(stat -> {
      // Validate if status is live.
      if (ProductsStatus.LIVE.name().equals(stat.getStatus())) {
        LOGGER.debug(PRODUCT_IS_IN_LIVE_STATE_LOG, id, version);
        return invalidRequestError(PRODUCT_IS_IN_LIVE_STATE);
      }
      return payload
          .flatMap(stateTransPayload -> productService.getStateTransitionResponse(reviewProduct,
              stateTransPayload, stat.getStatus()))
          .flatMap(transitionResponse -> JsonPayloadServiceResponse.withStatus(HttpStatus.CREATED)
              .setPayload(transitionResponse))
          .onErrorResume(error -> {
            LOGGER.error(ERROR_IN_PRODUCT_STATE_TRANSITION, error);
            return internalServerError(ERROR_IN_PRODUCT_STATE_TRANSITION + error.getMessage());
          });

    }).switchIfEmpty(objectNotFoundError(PRODUCT_STATUS_NOT_FOUND));
  }

  /**
   * Gets the product policy.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the product policy
   */
  private Mono<ServiceHandlerResponse> getProductPolicy(String id, String version) {

    LOGGER.debug(FETCHING_CONFIGUARTION, id, version);
    return productService.fetchProductConfiguration(id, version)
        .flatMap(configuration -> JsonPayloadServiceResponse.ok()
            .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setPayload(configuration))
        .switchIfEmpty(objectNotFoundError(ERROR_PRODUCT_NOT_FOUND));

  }

}
