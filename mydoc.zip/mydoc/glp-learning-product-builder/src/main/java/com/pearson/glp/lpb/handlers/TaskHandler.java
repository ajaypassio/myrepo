/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.TASK;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_TASK_BYID_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.GETTING_TASK_BYID;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.internalServerError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.objectNotFoundError;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.data.model.Task;
import com.pearson.glp.lpb.services.TaskService;
import com.pearson.glp.lpb.utils.CommonUtils;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * The Class TaskHandler.
 *
 * @author sankalp.katiyar
 */
@Component
@AllArgsConstructor
@NoArgsConstructor
public class TaskHandler implements CommonUtils {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(TaskHandler.class);

  /** The task service. */
  @Autowired
  private TaskService taskService;

  /**
   * Gets the task by id.
   *
   * @param context
   *          the context
   * @return the task by id
   */
  public Mono<ServiceHandlerResponse> getTaskById(ServiceHandlerContext context) {
    String taskId = context.getParameter(ID);
    LOGGER.debug(GETTING_TASK_BYID, taskId);
    Mono<Task> taskMono = taskService.findTaskBy_Id(taskId);

    return taskMono
        .flatMap(task -> JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setPayload(task))
        .switchIfEmpty(objectNotFoundError(TASK + HttpStatus.NOT_FOUND.getReasonPhrase()))
        .onErrorResume(ex -> {
          LOGGER.error(ERROR_FETCHING_TASK_BYID_MESSAGE, taskId);
          return internalServerError(ERROR_FETCHING_TASK_BYID_MESSAGE + taskId);
        });

  }

  /**
   * Gets the entity by task id.
   *
   * @param context
   *          the context
   * @return the entity by task id
   */
  public Mono<ServiceHandlerResponse> getLongRunningEntityByTaskId(ServiceHandlerContext context) {
    return Mono.just(new JsonPayloadServiceResponse());
  }

}
