/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services.impl;

import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_EVENT_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.PUBLISHING_EVENT_MESSAGE;
import static com.pearson.glp.lpb.enums.RootNode.NONE;
import static com.pearson.glp.lpb.enums.RootNode.SELF;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.pearson.glp.crosscutting.isc.client.async.model.EventMessage;
import com.pearson.glp.crosscutting.isc.client.async.service.IscAsyncClient;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.event.request.EventPayload;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.services.EventService;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * The Class EventServiceImpl.
 */
@Service

/**
 * Instantiates a new event service impl.
 */
@NoArgsConstructor

/**
 * Instantiates a new event service impl.
 *
 * @param iscAsyncClient
 *          the isc async client
 */
@AllArgsConstructor
public class EventServiceImpl implements EventService {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(EventServiceImpl.class);

  /** The isc async client. */
  @Autowired
  private IscAsyncClient iscAsyncClient;

  /**
   * Publish event.
   *
   * @param eventName
   *          the event name
   * @param payload
   *          the payload
   * @return the mono
   */
  @Override
  public Mono<Boolean> publishEvent(String eventName, NonPrimitiveAsset payload) {
    return iscAsyncClient.publishEvent(eventName, prepareEventPayload(eventName, payload))
        .doOnSuccess(b -> LOGGER.info(PUBLISHING_EVENT_MESSAGE, eventName))
        .doOnError(err -> LOGGER.error(ERROR_EVENT_MESSAGE, err, eventName));
  }

  /**
   * Prepare event payload.
   *
   * @param eventName
   *          the event name
   * @param payload
   *          the payload
   * @return the string
   */
  private String prepareEventPayload(String eventName, NonPrimitiveAsset payload) {
    EventMessage eventMessage = new EventMessage();
    Gson gson = new Gson();
    eventMessage.setId(UUID.randomUUID().toString());
    eventMessage.setTimestamp(formatDateTime(LocalDateTime.now()).get());
    Map<String, NonPrimitiveAsset> product = new HashMap<>();
    product.put(CommonConstants.PRODUCT.toLowerCase(), payload);
    Map<String, Map<String, NonPrimitiveAsset>> embedded = new HashMap<>();
    embedded.put(CommonConstants.EMBEDDED, product);
    eventMessage.setPayload(gson.toJson(embedded));
    eventMessage.setEventName(eventName);
    return gson.toJson(eventMessage);
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.EventService#publishEventMessage(java.lang.
   * String, com.pearson.glp.lpb.data.model.NonPrimitiveAsset)
   */
  @Override
  public Mono<Boolean> publishEventMessage(String eventName, NonPrimitiveAsset payload) {
    EventPayload eventPayload = prepareEventPayload(payload);
    return iscAsyncClient.publishEventMessage(eventName, eventPayload)
        .doOnSuccess(bool -> LOGGER.info(PUBLISHING_EVENT_MESSAGE, eventName))
        .doOnError(err -> LOGGER.error(ERROR_EVENT_MESSAGE, err, eventName));
  }

  /**
   * Prepare event payload.
   *
   * @param asset
   *          the asset
   * @return the event payload
   */
  private EventPayload prepareEventPayload(NonPrimitiveAsset asset) {
    EventPayload eventPayload = new EventPayload();
    if (AssetType.PRODUCT.value().equals(asset.getAssetType())) {
      eventPayload.setRootNode(SELF.value());
    } else {
      eventPayload.setRootNode(NONE.value());
    }
    eventPayload.setResources(new ArrayList<>());
    eventPayload.setLearningAsset(asset);
    return eventPayload;
  }

}
