/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services.impl;

import static com.pearson.glp.lpb.constant.CommonConstants.ABSTRACT_CATEGORY;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSETCLASSTYPES;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSET_TYPES;
import static com.pearson.glp.lpb.constant.CommonConstants.COUNT_ZERO;
import static com.pearson.glp.lpb.constant.CommonConstants.DEFAULT_LANGUAGE;
import static com.pearson.glp.lpb.constant.CommonConstants.FORWARD_SLASH;
import static com.pearson.glp.lpb.constant.CommonConstants.INITIAL_BSS_VER;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT_BUILDER;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSIONS_URL;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_RESOURCE_MESSAGE_LAP;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_FETCHING_RESOURCE_MESSAGE_LPB;
import static com.pearson.glp.lpb.constant.LoggingConstants.SCANNING_PRODUCT_MESSAGE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCTS_ROUTE;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;
import com.pearson.glp.lpb.data.model.AssetClassType;
import com.pearson.glp.lpb.data.model.Content;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassData;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.Resources;
import com.pearson.glp.lpb.data.model.Scope;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.data.repository.ProductAssetClassTypeRepository;
import com.pearson.glp.lpb.data.repository.ProductRepository;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.EventType;
import com.pearson.glp.lpb.services.EventService;
import com.pearson.glp.lpb.services.ProductScannerService;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

/**
 * The Class ProductScannerServiceImpl.
 * 
 * @author jeevansingh.dhami
 */
@Service
public class ProductScannerServiceImpl implements ProductScannerService {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductScannerServiceImpl.class);

  /** The product repository. */
  @Autowired
  private ProductRepository productRepository;

  /** The assetClassTypeRepository. */
  @Autowired
  private ProductAssetClassTypeRepository assetClassTypeRepository;

  /** The non primitive asset repository. */
  @Autowired
  private NonPrimitiveAssetRepository nonPrimitiveAssetRepository;

  /** The isc sync client. */
  @Autowired
  private IscSyncClient iscSyncClient;

  /** The lap base url. */
  @Value("${lap.base.url}")
  private String lapBaseUrl;

  /** The event service. */
  @Autowired
  private EventService eventService;

  /**
   * Scan product.
   *
   * @param productId
   *          the product id
   * @param productVersion
   *          the product version
   * @return the mono
   */
  private Mono<Map<String, Set<String>>> scanProduct(String productId, String productVersion) {

    Mono<NonPrimitiveAsset> productMono = productRepository.findById(CommonUtils
        .nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT, productId, productVersion));
    Map<String, Set<String>> assetClassTypes = new HashMap<>();

    return productMono.flatMap(product -> {
      buildDistinctAssetClass(assetClassTypes, product);
      return scanAssets(product.getResources(), assetClassTypes);
    });

  }

  /**
   * Scan assets.
   *
   * @param linkedHashMap
   *          the linked hash map
   * @param assetClassTypes
   *          the asset class types
   * @return the mono
   * @throws ServiceException
   *           the service exception
   */
  private Mono<Map<String, Set<String>>> scanAssets(LinkedHashMap<String, Resources> linkedHashMap,
      Map<String, Set<String>> assetClassTypes) throws ServiceException {
    int resourceCount = COUNT_ZERO;
    List<Mono<Map<String, Set<String>>>> assetclassTypeCollection = new ArrayList<>();
    for (Entry<String, Resources> entry : linkedHashMap.entrySet()) {
      String resourceId = entry.getValue().getId();
      String resVer = entry.getValue().getVer();
      String assetType = entry.getValue().getAssetType();
      resourceCount++;
      if (!AssetType.NARRATIVE.value().equals(assetType)
          && !AssetType.ASSESSMENT_ITEM.value().equals(assetType)
          && !AssetType.LEARNINGAPP_ITEM.value().equals(assetType)) {

        Mono<NonPrimitiveAsset> nonPrimitiveAsset = nonPrimitiveAssetRepository.findById(CommonUtils
            .nonPrimitiveLearningAssetDocumentId(AssetType.valueOf(assetType), resourceId, resVer));
        Mono<Map<String, Set<String>>> assetClassMapExternal = nonPrimitiveAsset
            .flatMap(npAsset -> {
              if (Optional.ofNullable(npAsset).isPresent()) {
                buildDistinctAssetClass(assetClassTypes, npAsset);
                return Mono.zip(Mono.just(assetClassTypes),
                    scanAssets(npAsset.getResources(), assetClassTypes)).map(Tuple2::getT2);

              } else {
                LOGGER.error(ERROR_FETCHING_RESOURCE_MESSAGE_LPB, resourceId, resVer);
                throw new ServiceException(
                    ERROR_FETCHING_RESOURCE_MESSAGE_LPB + resourceId + resVer);
              }
            }).onErrorResume(error -> {
              LOGGER.error(ERROR_FETCHING_RESOURCE_MESSAGE_LPB, resourceId, resVer);
              throw new ServiceException(ERROR_FETCHING_RESOURCE_MESSAGE_LPB + resourceId + resVer);
            });
        assetclassTypeCollection.add(assetClassMapExternal);

        if (resourceCount == linkedHashMap.entrySet().size()) {
          Mono<Map<String, Set<String>>> assetClassMapInternal = Mono
              .zip(Mono.just(assetClassTypes), assetClassMapExternal).map(Tuple2::getT2);
          for (Mono<Map<String, Set<String>>> data : assetclassTypeCollection) {
            assetClassMapInternal = Mono.zip(assetClassMapInternal, data).map(Tuple2::getT2);
          }
          return assetClassMapInternal;
        }
      } else if (AssetType.NARRATIVE.value().equals(assetType)
          || AssetType.ASSESSMENT_ITEM.value().equals(assetType)
          || AssetType.LEARNINGAPP_ITEM.value().equals(assetType)) {
        return fetchFromLap(CommonUtils.createSelfLink(lapBaseUrl, entry.getValue()))
            .flatMap(npAsset -> {
              buildDistinctAssetClass(assetClassTypes, npAsset);
              return Mono.just(assetClassTypes);
            }).onErrorResume(error -> {
              LOGGER.error(ERROR_FETCHING_RESOURCE_MESSAGE_LAP, error);
              throw new ServiceException(ERROR_FETCHING_RESOURCE_MESSAGE_LAP + resourceId
                  + ERROR_FETCHING_RESOURCE_MESSAGE_LAP + resVer);
            });
      }
    }
    return Mono.just(assetClassTypes);

  }

  /**
   * Put if absent.
   *
   * @param assetClassTypes
   *          the asset class types
   * @param npAsset
   *          the npAsset
   */
  private void buildDistinctAssetClass(Map<String, Set<String>> assetClassTypes,
      NonPrimitiveAsset npAsset) {
    if (assetClassTypes.containsKey(npAsset.getAssetType())) {
      assetClassTypes.get(npAsset.getAssetType()).add(npAsset.getAssetClass());
    } else {
      Set<String> assetClass = new HashSet<>();
      assetClass.add(npAsset.getAssetClass());
      assetClassTypes.put(npAsset.getAssetType(), assetClass);
    }
  }

  /**
   * Fetch from lap.
   *
   * @param selfHref
   *          the self href
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> fetchFromLap(String selfHref) {
    Map<String, String> headersMap = new HashMap<>();
    return iscSyncClient.getObject(selfHref, headersMap, NonPrimitiveAsset.class,
        IscSyncResponseFormat.RAW);
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.ProductScannerService#scanProduct(reactor.core
   * .publisher.Mono)
   */
  @Override
  public Mono<Boolean> scanProduct(Mono<NonPrimitiveAsset> nonPrimitiveAsset) {
    LOGGER.debug(SCANNING_PRODUCT_MESSAGE);
    return nonPrimitiveAsset.flatMap(asset -> {

      return scanProduct(asset.get_id(), asset.getVer()).flatMap(map -> {
        return saveAssetClassDetails(map, asset).flatMap(data -> {
          // publish the event
          return eventService.publishEventMessage(EventType.PRODUCT_READY_FOR_CONFIGURATION.value(),
              asset);
        });
      });

    }).switchIfEmpty(Mono.just(false));
  }

  /**
   * Save asset class details.
   *
   * @param assetClass
   *          the asset class
   * @param asset
   *          the asset
   * @return the mono
   */
  private Mono<ProductAssetClassType> saveAssetClassDetails(Map<String, Set<String>> assetClass,
      NonPrimitiveAsset asset) {

    ProductAssetClassType model = createResourcesModel(asset, assetClass);

    return assetClassTypeRepository.save(model);
  }

  /**
   * Creates the resources model.
   *
   * @param asset
   *          the asset
   * @param assetClass
   *          the asset class
   * @return the product asset class type
   */
  private ProductAssetClassType createResourcesModel(NonPrimitiveAsset asset,
      Map<String, Set<String>> assetClass) {
    ProductAssetClassType model = new ProductAssetClassType();
    model.setId(CommonUtils.generateDocId(ASSETCLASSTYPES, asset.get_id(), asset.getVer()));
    model.set_id(UUID.randomUUID().toString());
    model.setVer(UUID.randomUUID().toString());
    model.setBssVer(INITIAL_BSS_VER);
    model.setCreated(formatDateTime(LocalDateTime.now()).get());
    model.setLabel("");
    model.setLanguage(DEFAULT_LANGUAGE);
    model.setLastModified(formatDateTime(LocalDateTime.now()).get());
    model.setResourceType(ASSETCLASSTYPES);
    model.setResourceClass(ASSETCLASSTYPES);
    model.setResourceCtx(PRODUCT_BUILDER);
    model.setScope(new Scope());
    model.setTags("");
    model.addLinks(SELF, createSelfLink(asset.get_id(), asset.getVer()));
    Extensions extensions = asset.getExtensions();
    ContentMetadata contentMetadata = new ContentMetadata();
    contentMetadata.setId(asset.get_id());
    contentMetadata.setVersion(asset.getVer());
    extensions.put(PRODUCT.toLowerCase(), contentMetadata);
    model.setExtensions(extensions);
    Content content = new Content();
    content.setCategory(ABSTRACT_CATEGORY);
    content.setModel(ASSETCLASSTYPES);
    ProductAssetClassData rData = new ProductAssetClassData();
    rData.setAssetClassTypes(new ArrayList<>());
    content.setData(rData);
    assetClass.keySet().stream().forEach(key -> {
      AssetClassType assetClassModel = new AssetClassType();
      assetClassModel.setAssetType(key);
      StringJoiner joiner = new StringJoiner(",");
      for (String val : assetClass.get(key)) {
        joiner.add(val);
      }
      assetClassModel.setAssetClass(joiner.toString());
      rData.getAssetClassTypes().add(assetClassModel);
    });
    model.setContent(content);
    return model;
  }

  /**
   * Creates the self link.
   *
   * @param model
   *          the model
   * @return the link
   */
  private Link createSelfLink(String productId, String productVer) {
    Link link = new Link();
    String url = PRODUCTS_ROUTE + FORWARD_SLASH + productId + VERSIONS_URL + productVer
        + FORWARD_SLASH + ASSET_TYPES;
    link.setHref(url);
    return link;
  }

}
