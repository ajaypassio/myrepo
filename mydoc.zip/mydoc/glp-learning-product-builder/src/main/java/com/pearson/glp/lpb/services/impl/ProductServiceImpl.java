/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services.impl;

import static com.pearson.glp.lpb.constant.CommonConstants.ASSETCLASSTYPES;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSETMODEL;
import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.COLLECTION_DETAILS;
import static com.pearson.glp.lpb.constant.CommonConstants.COMMA_CHARACTER;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.DEFAULT_GROUP;
import static com.pearson.glp.lpb.constant.CommonConstants.DOUBLE_COLON;
import static com.pearson.glp.lpb.constant.CommonConstants.FORWARD_SLASH;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.INITIAL_BSS_VER;
import static com.pearson.glp.lpb.constant.CommonConstants.JSON_FILES;
import static com.pearson.glp.lpb.constant.CommonConstants.MAX_USER_POLICY_GROUPS;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.PMP;
import static com.pearson.glp.lpb.constant.CommonConstants.POLICY_GROUPS;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCTIZATION;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCTMODEL;
import static com.pearson.glp.lpb.constant.CommonConstants.REASON;
import static com.pearson.glp.lpb.constant.CommonConstants.REASON_CODE;
import static com.pearson.glp.lpb.constant.CommonConstants.REVIEW_PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.SCANNING_FAILED_MESSAGE;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.STATE_TRANSITION;
import static com.pearson.glp.lpb.constant.CommonConstants.STATUS;
import static com.pearson.glp.lpb.constant.CommonConstants.STATUSDOC;
import static com.pearson.glp.lpb.constant.CommonConstants.TASK_ROUTE;
import static com.pearson.glp.lpb.constant.CommonConstants.TASK_STATUS;
import static com.pearson.glp.lpb.constant.CommonConstants.TITLE;
import static com.pearson.glp.lpb.constant.CommonConstants.UPDATE_STATUS_FAILED;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.CommonConstants.VERSIONS_URL;
import static com.pearson.glp.lpb.constant.CommonConstants.ZERO_INDEX;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATE_PRODUCT_LATEST_DOC;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATE_PRODUCT_NEW_STATUS;
import static com.pearson.glp.lpb.constant.LoggingConstants.CREATE_PRODUCT_NEW_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.DELETE_PRODUCT_LATEST_VERSION;
import static com.pearson.glp.lpb.constant.LoggingConstants.FETCHING_PMP_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.GENERATE_ASSET_RESPONSE_FOR_REQUEST_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.GENERATE_ASSET_RESPONSE_WITH_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.INVALID_POLICY_GROUP_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.LEARNING_MODEL_VALIDATION_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.MODEL_VALIDATION_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.MULTIPLE_POLICY_GROUPS_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.NON_ARRAY_POLICY_GROUP_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.NON_PRIMITIVE_ASSET_BUILD_ERROR;
import static com.pearson.glp.lpb.constant.LoggingConstants.PUBLISHING_EVENT_MESSAGE;
import static com.pearson.glp.lpb.constant.LoggingConstants.REVIEW_PRODUCT_INFO_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.STATE_TRANSITION_RESPONSE_LOG;
import static com.pearson.glp.lpb.constant.LoggingConstants.TASK_CREATION_FAILED;
import static com.pearson.glp.lpb.enums.Routes.PRODUCTS_ROUTE;
import static com.pearson.glp.lpb.enums.Routes.PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;

import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Extends;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.LearningModel;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.ProductStateTransition;
import com.pearson.glp.lpb.data.model.ProductStatus;
import com.pearson.glp.lpb.data.model.Productization;
import com.pearson.glp.lpb.data.model.Resources;
import com.pearson.glp.lpb.data.model.Task;
import com.pearson.glp.lpb.data.model.TaskResource;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.data.repository.PMPMessageRepository;
import com.pearson.glp.lpb.data.repository.ProductAssetClassTypeRepository;
import com.pearson.glp.lpb.data.repository.ProductRepository;
import com.pearson.glp.lpb.data.repository.ProductStateTransitionRepository;
import com.pearson.glp.lpb.data.repository.ProductStatusRepository;
import com.pearson.glp.lpb.data.repository.TaskRepository;
import com.pearson.glp.lpb.dto.event.request.AutobahnEventModel;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.request.ProductPayload;
import com.pearson.glp.lpb.dto.request.ProductStatusPayload;
import com.pearson.glp.lpb.dto.request.ProductVersionPayload;
import com.pearson.glp.lpb.dto.request.StateTransitionPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.dto.response.ProductAssetResponse;
import com.pearson.glp.lpb.dto.response.ProductCollectionAsset;
import com.pearson.glp.lpb.dto.response.ProductCollectionResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.dto.response.ProductsResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.EventType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.enums.ProductCollectionDetails;
import com.pearson.glp.lpb.enums.ProductsStatus;
import com.pearson.glp.lpb.enums.ResourceType;
import com.pearson.glp.lpb.enums.Routes;
import com.pearson.glp.lpb.enums.TaskStatus;
import com.pearson.glp.lpb.services.EventService;
import com.pearson.glp.lpb.services.ProductService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PlatformErrorUtils;
import com.pearson.glp.lpb.validator.LearningModelValidator;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class ProductServiceImpl.
 * 
 * @author jeevansingh.dhami
 */
@Service
public class ProductServiceImpl implements ProductService, CommonUtils {

  /**
   * The Constant VERSION.
   */
  private static final String VERSION = "version";

  /**
   * The Constant logger.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductServiceImpl.class);

  /**
   * The product repository.
   */
  @Autowired
  private ProductRepository productRepository;

  /**
   * The long running task repository.
   */
  @Autowired
  private TaskRepository taskRepository;

  /**
   * The event handler.
   */
  @Autowired
  private EventService eventService;

  /**
   * The validation enabled.
   */
  @Value("${validation.enabled:false}")
  private boolean validationEnabled;

  /**
   * The statusRepository.
   */
  @Autowired
  private ProductStatusRepository statusRepository;

  /**
   * The statusRepository.
   */
  @Autowired
  private ProductStateTransitionRepository stateRepository;

  /**
   * The PMPMessageRepository.
   */
  @Autowired
  private PMPMessageRepository pmpMessageRepository;

  /**
   * The validator.
   */
  @Autowired
  private LearningModelValidator validator;

  /**
   * The asset repo.
   */
  @Autowired
  private LearningModelRepository assetRepo;

  /** The asset class type repo. */
  @Autowired
  private ProductAssetClassTypeRepository assetClassTypeRepo;

  /** The config home. */
  @Value("${config.home:config}")
  private String configHome;

  /**
   * Instantiates a new product service impl.
   */
  public ProductServiceImpl() {
    super();
  }

  /**
   * Find product by Id.
   *
   * @param id
   *          the product response
   * @return Mono
   */
  @Override
  public Mono<NonPrimitiveAsset> findProductById(String id) {
    return productRepository
        .getById(nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, id));
  }

  /**
   * Find product by parameters.
   *
   * @param parameters
   *          the parameters
   * @return Flux
   */
  @Override
  public Mono<ProductCollectionResponse> findProductCollection(
      MultiValueMap<String, String> parameters) {
    Flux<NonPrimitiveAsset> product = productRepository
        .findProductByParameters(prepareWhereClause(parameters, AssetType.PRODUCT));
    return product.collectList().map(obj -> this.prepareProductCollection(obj, parameters));
  }

  @Override
  public Flux<NonPrimitiveAsset> findProductCollectionWithCompleteLA(
      MultiValueMap<String, String> parameters) {
    return productRepository
        .findProductByParameters(prepareWhereClause(parameters, AssetType.PRODUCT));
  }

  /**
   * Prepare product collection.
   *
   * @param productNonPrimitiveAssets
   *          the product non primitive assets
   * @param parameters
   *          the parameters
   * @return the product collection response
   */
  private ProductCollectionResponse prepareProductCollection(
      List<NonPrimitiveAsset> productNonPrimitiveAssets, MultiValueMap<String, String> parameters) {
    ProductCollectionResponse assetBulkResponse = new ProductCollectionResponse();
    assetBulkResponse.setAssets(new ArrayList<ProductCollectionAsset>());
    assetBulkResponse.setCount(productNonPrimitiveAssets.size());
    productNonPrimitiveAssets.forEach(productNonPrimitiveAsset -> {
      ProductCollectionAsset asset = new ProductCollectionAsset();
      asset.set_id(productNonPrimitiveAsset.get_id());
      asset.setAssetType(productNonPrimitiveAsset.getAssetType());
      asset.setBssVer(productNonPrimitiveAsset.getBssVer());
      asset.setDocType(productNonPrimitiveAsset.getDocType());
      asset.setVer(productNonPrimitiveAsset.getVer());
      asset.setLinks(productNonPrimitiveAsset.getLinks());
      Optional<String> collectionDetailsValue = Optional
          .ofNullable(parameters.getFirst(COLLECTION_DETAILS));
      collectionDetailsValue
          .ifPresent(value -> Stream.of(value.split(COMMA_CHARACTER)).forEach(param -> {
            if (ProductCollectionDetails.LABEL.value().equals(param)) {
              asset.setLabel(productNonPrimitiveAsset.getLabel());
            } else if (ProductCollectionDetails.EXTENSIONS.value().equals(param)) {
              asset.setExtensions(productNonPrimitiveAsset.getExtensions());
            } else if (ProductCollectionDetails.CONFIGURATIONS.value().equals(param)) {
              asset.setConfiguration(productNonPrimitiveAsset.getConfiguration());
            }
          }));

      assetBulkResponse.getAssets().add(asset);
    });
    return assetBulkResponse;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#findProductByVersion(java.lang.
   * String, java.lang.String)
   */
  @Override
  public Mono<NonPrimitiveAsset> findProductByVersion(String id, String version) {
    return productRepository
        .findById(CommonUtils.nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT, id, version));
  }

  /**
   * Creates the product task error response.
   *
   * @return the products response
   */
  private ProductsResponse createProductTaskErrorResponse() {
    ProductsResponse response = new ProductsResponse();
    response.setError(
        PlatformErrorUtils.prepareErrorResponse(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue(),
            HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), TASK_CREATION_FAILED, null));
    return response;
  }

  /**
   * Creates the product task response.
   *
   * @param taskId
   *          the task id
   * @return the products response
   */
  private ProductsResponse createProductTaskResponse(String taskId) {

    ProductsResponse productResponse = new ProductsResponse();
    productResponse.set_id(taskId);
    productResponse.setStatus(TASK_STATUS);
    Link link = new Link(TASK_ROUTE + taskId);
    productResponse.set_link(link);
    return productResponse;
  }

  /**
   * Creates the long running task.
   *
   * @param longRunningId
   *          the long running id
   * @return the mono
   */
  private Mono<Task> createTask(String longRunningId) {
    Task task = new Task();
    Link link = new Link(TASK_ROUTE + longRunningId);
    task.setId(UUID.randomUUID().toString());
    task.set_id(longRunningId);
    Links links = new Links();
    links.putIfAbsent(SELF, link);
    task.setLinks(links);
    task.setStatus(TaskStatus.RUNNING.name());
    task.setResources(new ArrayList<>());
    return taskRepository.save(task);

  }

  /**
   * Creates the product status.
   *
   * @param statusId
   *          the status id
   * @param statusValue
   *          the status value
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the mono
   */
  private Mono<ProductStatus> createProductStatus(String statusId, String statusValue, String id,
      String ver) {

    ProductStatus status = new ProductStatus();
    status.set_id(statusId);
    status.setStatus(statusValue);
    status.setId(productStatusDocumentId(AssetType.PRODUCT, id, ver));
    status.setLastModified(formatDateTime(LocalDateTime.now()).get());
    Link sLink = new Link(PRODUCTS_ROUTE + FORWARD_SLASH + id + CommonConstants.VERSIONS_URL + ver
        + FORWARD_SLASH + STATUS);
    Map<String, Link> slinks = new HashMap<>();
    slinks.put(SELF, sLink);
    status.setLinks(slinks);
    return statusRepository.save(status);

  }

  /**
   * Validate resources of learning assesst.
   *
   * @param productPayload
   *          the product payload
   * @return true, if successful
   */
  private Mono<AssetResponse> validateResourcesOfLearningAssesst(
      NonPrimitiveAssetPayload productPayload) {
    return Mono.empty();
  }

  /**
   * Update long running task.
   *
   * @param taskId
   *          the task id
   * @param productId
   *          the product id
   * @param ver
   *          the ver
   * @param status
   *          the status
   * @return the mono
   */
  private Mono<Task> updateTask(String taskId, String productId, String ver, String status) {
    Mono<Task> taskObj = taskRepository.findBy_id(taskId);
    TaskResource resource = new TaskResource();
    Link rLink = new Link(PRODUCTS_ROUTE + FORWARD_SLASH + productId + VERSIONS_URL + ver);

    Map<String, Link> rlinks = new HashMap<>();
    rlinks.put(SELF, rLink);
    if (!productId.isEmpty()) {
      resource.setVer(ver);
      resource.setBssVer(INITIAL_BSS_VER);
      resource.setId(productId);
      resource.setLinks(rlinks);
    }
    taskObj = taskObj.flatMap(lrTask -> saveLongReunningTask(lrTask, resource, status));

    return taskObj;

  }

  /**
   * Save long reunning task.
   *
   * @param lrTask
   *          the lr task
   * @param resource
   *          the resource
   * @param status
   *          the status
   * @return the mono
   */
  private Mono<Task> saveLongReunningTask(Task lrTask, TaskResource resource, String status) {

    lrTask.setResources(Arrays.asList(resource));
    lrTask.setStatus(status);
    return taskRepository.save(lrTask);
  }

  /**
   * Creates the status link.
   *
   * @param nonPrimitiveAsset
   *          the status id
   * @return the map
   */
  private Link createStatusLink(NonPrimitiveAsset nonPrimitiveAsset) {
    Link link = new Link();
    String url = PRODUCTS_ROUTE + FORWARD_SLASH + nonPrimitiveAsset.get_id() + VERSIONS_URL
        + nonPrimitiveAsset.getVer() + FORWARD_SLASH + STATUS;
    link.setHref(url);
    return link;
  }

  /**
   * Set the Links in the Non Primitive Asset.
   *
   * @param nonPrimitiveAsset
   *          the new non primitive asset links
   */
  private void setNonPrimitiveAssetLinks(NonPrimitiveAsset nonPrimitiveAsset) {
    nonPrimitiveAsset.getLearningModel().addLinks(SELF,
        createNonPrimitiveAssetSelfLink(PRODUCT_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value(),
            nonPrimitiveAsset.getLearningModel().getId(),
            nonPrimitiveAsset.getLearningModel().getVer()));

    nonPrimitiveAsset.getResources().values().forEach(resource -> {
      String url = AssetType.valueOf(resource.getAssetType()).url();
      resource.addLinks(SELF,
          createNonPrimitiveAssetSelfLink(url, resource.getId(), resource.getVer()));
    });
  }

  /**
   * Set the Extensions in the Non Primitive Asset.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param nonPrimitiveAssetPayload
   *          the non primitive asset payload
   */
  private void setNonPrimitiveAssetExtensions(NonPrimitiveAsset nonPrimitiveAsset,
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    if (nonPrimitiveAsset.getExtensions() == null) {
      nonPrimitiveAsset.setExtensions(new Extensions());
    }
    nonPrimitiveAsset.getExtensions().put(CONTENT_METADATA,
        nonPrimitiveAssetPayload.getContentMetadata());
  }

  /**
   * Save the Immutable Resource Model when content is available.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> saveNonPrimitiveAssets(NonPrimitiveAsset nonPrimitiveAsset) {
    return productRepository.save(nonPrimitiveAsset);
  }

  /**
   * Build the Asset Response from Non Primitive Asset Model.
   *
   * @param nonPrimitiveAsset
   *          the resource
   * @return the Asset Response
   */
  private ProductAssetResponse buildNonPrimitiveAssetResponse(NonPrimitiveAsset nonPrimitiveAsset) {
    LOGGER.debug(GENERATE_ASSET_RESPONSE_FOR_REQUEST_ID,
        nonPrimitiveAsset.getExtensions().get(CONTENT_METADATA));
    ProductAssetResponse assetResponse = new ProductAssetResponse(nonPrimitiveAsset);
    return assetResponse;
  }

  /**
   * Build the Asset Response with error from Non Primitive Asset Model.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param platformErrorCode
   *          the platform error code
   * @param message
   *          the message
   * @return the Asset Response
   */
  private ProductAssetResponse buildNonPrimitiveAssetResponseWithError(
      NonPrimitiveAsset nonPrimitiveAsset, PlatformErrorCode platformErrorCode, String message) {
    ProductAssetResponse response = buildNonPrimitiveAssetResponse(nonPrimitiveAsset);
    LOGGER.debug(GENERATE_ASSET_RESPONSE_WITH_ERROR,
        nonPrimitiveAsset.getExtensions().get(CONTENT_METADATA));
    response.setError(generatePlatformError(platformErrorCode, message));
    return response;
  }

  /**
   * Generate the error response for Non Primitive Asset.
   *
   * @param platformErrorCode
   *          the platform error code
   * @param message
   *          the message
   * @return the platform error
   */
  private PlatformErrorResponse generatePlatformError(PlatformErrorCode platformErrorCode,
      String message) {
    return PlatformErrorUtils.prepareErrorResponse(platformErrorCode.getValue(),
        platformErrorCode.getErrorCode(), message, null);
  }

  /**
   * Creates the Non Primitive Asset self link.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the link
   */
  private Link createNonPrimitiveAssetSelfLink(String url, String id, String ver) {
    Link link = new Link();
    link.setHref(createNonPrimitiveAssetHref(url, id, ver));
    return link;
  }

  /**
   * Creates the href.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  private String createNonPrimitiveAssetHref(String url, String id, String ver) {
    String href = url;
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, ver);
    return href;
  }

  /**
   * Get all products.
   *
   * @return Mono
   */
  @Override
  public Mono<AssetBulkResponse> getAllProducts() {
    Flux<NonPrimitiveAsset> assetFlux = productRepository
        .findByAssetType(getAllDocumentsId(AssetType.PRODUCT));
    return assetFlux.collectList().map(this::translateToProductResponse);
  }

  /**
   * Translate to product response.
   *
   * @param productNonPrimitiveAssets
   *          the product
   * @return the asset bulk response
   */
  private AssetBulkResponse translateToProductResponse(
      List<NonPrimitiveAsset> productNonPrimitiveAssets) {
    AssetBulkResponse assetBulkResponse = new AssetBulkResponse();
    assetBulkResponse.setAssets(new ArrayList<Asset>());
    assetBulkResponse.setCount(productNonPrimitiveAssets.size());
    productNonPrimitiveAssets.forEach(productNonPrimitiveAsset -> {
      Asset asset = new Asset();
      asset.set_id(productNonPrimitiveAsset.get_id());
      asset.setAssetType(productNonPrimitiveAsset.getAssetType());
      asset.setBssVer(productNonPrimitiveAsset.getBssVer());
      asset.setDocType(productNonPrimitiveAsset.getDocType());
      asset.setId(productNonPrimitiveAsset.getId());
      asset.setVer(productNonPrimitiveAsset.getVer());
      asset.setLinks(productNonPrimitiveAsset.getLinks());
      assetBulkResponse.getAssets().add(asset);
    });
    return assetBulkResponse;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#findProductVersionsById(java.
   * lang.String)
   */
  @Override
  public Mono<AssetVersionsResponse> findProductVersionsById(String id) {
    Mono<List<NonPrimitiveAsset>> productNonPrimitiveAssets = productRepository
        .findGetAllVersion(getAllVersionsDocumentId(AssetType.PRODUCT, id)).collectList();
    return productNonPrimitiveAssets.map(this::translateToVersionResponse);
  }

  /**
   * Translate to version response.
   *
   * @param productNonPrimitiveAssets
   *          the product non primitive assets
   * @return the asset versions response
   */
  private AssetVersionsResponse translateToVersionResponse(
      List<NonPrimitiveAsset> productNonPrimitiveAssets) {

    AssetVersionsResponse assetVersionsResponse = new AssetVersionsResponse();
    assetVersionsResponse.setCount(productNonPrimitiveAssets.size());
    assetVersionsResponse.setVersions(new ArrayList<>());

    productNonPrimitiveAssets
        .forEach(product -> setAssetVersionResponse(assetVersionsResponse, product));

    return assetVersionsResponse;
  }

  /**
   * Sets the asset version response.
   *
   * @param assetVersionsResponse
   *          the asset versions response
   * @param product
   *          the product
   */
  private void setAssetVersionResponse(AssetVersionsResponse assetVersionsResponse,
      NonPrimitiveAsset product) {
    Asset asset = new Asset();
    asset.set_id(product.get_id());
    asset.setAssetType(product.getAssetType());
    asset.setBssVer(product.getBssVer());
    asset.setDocType(product.getDocType());
    asset.setLinks(product.getLinks());
    asset.setVer(product.getVer());
    assetVersionsResponse.getVersions().add(asset);
  }

  /*
   * (non-Javadoc)
   *
   * @see com.pearson.glp.lpb.services.ProductService#
   * createProductVersionNonPrimitiveAssets(com.pearson.glp.lpb.data.model.
   * request.ProductVersionPayload, com.pearson.glp.lpb.data.model.Asset,
   * java.lang.String, java.lang.Integer, com.pearson.glp.lpb.enums.AssetType)
   */
  @Override
  public Mono<ProductsResponse> createProductVersionNonPrimitiveAssets(
      ProductVersionPayload productPayload, Asset asset, String assetId, Integer bssVer,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = (NonPrimitiveAsset) asset;
    String taskId = UUID.randomUUID().toString();
    Mono<Task> taskMono = createTask(taskId);
    startTaskWorker(productPayload.getAsset(), nonPrimitiveAsset, assetType, taskId);
    return taskMono.flatMap(task -> {
      return Mono.just(createProductTaskResponse(task.get_id()));
    }).onErrorResume(task -> Mono.just(createProductTaskErrorResponse()));
  }

  /**
   * Start task worker.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param productNonPrimitiveAsset
   *          the product non primitive asset
   * @param assetType
   *          the asset type
   * @param taskId
   *          the task id
   */
  private void startTaskWorker(NonPrimitiveAssetPayload productVersionPayload,
      NonPrimitiveAsset productNonPrimitiveAsset, AssetType assetType, String taskId) {
    new Thread(() -> validatedProductModelAndResources(productVersionPayload,
        productNonPrimitiveAsset, assetType, taskId)).start();
  }

  /**
   * Validated product model and resources.
   *
   * @param productPayload
   *          the product payload
   * @param productNonPrimitiveAsset
   *          the product non primitive asset
   * @param assetType
   *          the asset type
   * @param taskId
   *          the task id
   */
  public void validatedProductModelAndResources(NonPrimitiveAssetPayload productPayload,
      NonPrimitiveAsset productNonPrimitiveAsset, AssetType assetType, String taskId) {
    validateResourcesOfLearningAssesst(productPayload).flatMap(response -> {
      return updateTask(taskId, StringUtils.EMPTY, StringUtils.EMPTY, TaskStatus.ERROR.name());
    }).onErrorResume(
        error -> updateTask(taskId, StringUtils.EMPTY, StringUtils.EMPTY, TaskStatus.ERROR.name()))
        .switchIfEmpty(persistProduct(productPayload, productNonPrimitiveAsset, taskId))
        .subscribe();

  }

  /**
   * Persist product.
   *
   * @param productPayload
   *          the product payload
   * @param productNonPrimitiveAsset
   *          the product non primitive asset
   * @param taskId
   *          the task id
   * @return the mono
   */
  private Mono<Task> persistProduct(NonPrimitiveAssetPayload productPayload,
      NonPrimitiveAsset productNonPrimitiveAsset, String taskId) {
    String statusId = UUID.randomUUID().toString();
    productNonPrimitiveAsset.addLinks(STATUS, createStatusLink(productNonPrimitiveAsset));
    saveProductAssets(productPayload, productNonPrimitiveAsset).flatMap(response -> {

      return updateTask(taskId, response.get_id(), response.getVer(), TaskStatus.COMPLETED.name())
          .flatMap(task -> createProductStatus(statusId, ProductsStatus.DRAFT.name(),
              response.get_id(), response.getVer()));

    }).map(task -> eventService
        .publishEvent(EventType.PRODUCT_READY_FOR_CONFIGURATION.value(), productNonPrimitiveAsset)
        .subscribe(res -> {
          if (!res) {
            updateTask(taskId, StringUtils.EMPTY, StringUtils.EMPTY, TaskStatus.ERROR.name())
                .subscribe();
          }
        })).doOnError(task -> updateTask(taskId, StringUtils.EMPTY, StringUtils.EMPTY,
            TaskStatus.ERROR.name()).subscribe())
        .subscribe();
    return Mono.empty();
  }

  /**
   * Save product assets.
   *
   * @param productPayload
   *          the product payload
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<ProductAssetResponse> saveProductAssets(NonPrimitiveAssetPayload productPayload,
      NonPrimitiveAsset nonPrimitiveAsset) {

    return saveNonPrimitiveAssets(nonPrimitiveAsset).flatMap(
        model -> saveNonPrimitiveAssetLatest(model, model.get_id(), ProductsStatus.DRAFT.name()))
        .map(this::buildNonPrimitiveAssetResponse).onErrorResume(ex -> {
          LOGGER.error(NON_PRIMITIVE_ASSET_BUILD_ERROR, ex);
          setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productPayload);
          nonPrimitiveAsset.setId(null);
          return Mono.just(buildNonPrimitiveAssetResponseWithError(nonPrimitiveAsset,
              PlatformErrorCode.INTERNAL_SERVER_ERROR,
              HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()));
        });
  }

  /**
   * Save non primitive asset latest.
   *
   * @param model
   *          the model
   * @param status
   *          the status
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> saveNonPrimitiveAssetLatest(NonPrimitiveAsset model,
      String status) {
    if (status.equals(ProductsStatus.LIVE.name())) {
      model.setId(
          nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, model.get_id(), status));
    } else {
      model.setId(nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, model.get_id()));
    }
    return saveNonPrimitiveAssets(model);
  }

  /**
   * Save non primitive asset latest.
   *
   * @param model
   *          the model
   * @param id
   *          the id
   * @param status
   *          the status
   * @return the mono
   */
  private Mono<NonPrimitiveAsset> saveNonPrimitiveAssetLatest(NonPrimitiveAsset model, String id,
      String status) {
    model.setId(
        nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, model.get_id(), status));
    return saveNonPrimitiveAssets(model);
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#validateProduct(com.pearson.glp
   * .lpb.data.model.request.ProductPayload,
   * com.pearson.glp.lpb.enums.AssetType)
   */
  @Override
  public Mono<AssetResponse> validateProduct(ProductPayload productPayload, AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = createProductNonPrimitiveAsset(productPayload, assetType);
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return validateProductModel(nonPrimitiveAsset);
  }

  /**
   * Validate product model.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<AssetResponse> validateProductModel(NonPrimitiveAsset nonPrimitiveAsset) {
    LOGGER.debug(MODEL_VALIDATION_LOG, validationEnabled);
    Mono<AssetModel> assetModel = findLearningModelByIdAndVersionAndAssetType(
        nonPrimitiveAsset.getLearningModel().getId(), nonPrimitiveAsset.getLearningModel().getVer(),
        nonPrimitiveAsset.getLearningModel().getAssetType());
    if (validationEnabled) {
      return validator.validateLearningAssetWithLearningModel(nonPrimitiveAsset)
          .flatMap(this::onError).switchIfEmpty(validationResponse(nonPrimitiveAsset, assetModel));
    } else {
      return validationResponse(nonPrimitiveAsset, assetModel);
    }
  }

  /**
   * On error.
   *
   * @param err
   *          the err
   * @return the mono
   */
  private Mono<AssetResponse> onError(AssetResponse err) {
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setError(err.getError());
    return Mono.just(assetResponse);
  }

  /**
   * Validation response.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param assetModel
   *          the asset model
   * @return the mono
   */
  private Mono<AssetResponse> validationResponse(NonPrimitiveAsset nonPrimitiveAsset,
      Mono<AssetModel> assetModel) {
    return assetModel.flatMap(model -> {
      AssetResponse assetResponse = new AssetResponse();
      preparePolicyGroups(assetResponse, nonPrimitiveAsset, model);
      nonPrimitiveAsset.setConfiguration(model.getConfiguration());
      assetResponse.setAsset(nonPrimitiveAsset);
      return Mono.just(assetResponse);
    }).switchIfEmpty(onEmpty(nonPrimitiveAsset));

  }

  /**
   * Prepare policy groups.
   *
   * @param assetResponse
   *          the asset response
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param productModel
   *          the product model
   */
  @SuppressWarnings("unchecked")
  private void preparePolicyGroups(AssetResponse assetResponse, NonPrimitiveAsset nonPrimitiveAsset,
      AssetModel productModel) {
    Configuration modelConfiguration = productModel.getConfiguration();
    List<String> policyGroups = new ArrayList<>();
    Optional<Object> modelPolicyGroups = Optional.ofNullable(modelConfiguration.get(POLICY_GROUPS));
    modelPolicyGroups.ifPresent(modelPolicyGroup -> {
      Optional<String> defaultPolicyGroup = ((List<String>) modelPolicyGroup).stream()
          .filter(policyGroupName -> policyGroupName.endsWith(DEFAULT_GROUP)).findFirst();
      if (defaultPolicyGroup.isPresent())
        policyGroups.add(defaultPolicyGroup.get());
    });

    Optional<Configuration> productConfiguation = Optional
        .ofNullable(nonPrimitiveAsset.getConfiguration());

    if (!productConfiguation.isPresent()) {
      nonPrimitiveAsset.setConfiguration(new Configuration());
    }

    if (!CommonUtils.validatePolicyGroups(nonPrimitiveAsset.getConfiguration())) {
      assetResponse.setError(
          generatePlatformError(PlatformErrorCode.INVALID_REQUEST, NON_ARRAY_POLICY_GROUP_ERROR));
    }

    Optional<Object> productPolicyGroups = Optional
        .ofNullable(nonPrimitiveAsset.getConfiguration().get(POLICY_GROUPS));

    List<String> productPolicyGroupList = Collections.emptyList();
    if (productPolicyGroups.isPresent()) {
      productPolicyGroupList = ((List<String>) productPolicyGroups.get());
    }

    if (productPolicyGroupList.isEmpty()) {
      policyGroups.add(CommonUtils.generateUserGroupPolicyId(nonPrimitiveAsset.get_id(),
          nonPrimitiveAsset.getVer()));
    } else if (productPolicyGroupList.size() > MAX_USER_POLICY_GROUPS) {
      assetResponse.setError(
          generatePlatformError(PlatformErrorCode.INVALID_REQUEST, MULTIPLE_POLICY_GROUPS_ERROR));
    } else if (!productPolicyGroupList.get(ZERO_INDEX).startsWith(TITLE)) {
      assetResponse.setError(
          generatePlatformError(PlatformErrorCode.INVALID_REQUEST, INVALID_POLICY_GROUP_ERROR));
    } else {
      policyGroups.addAll(productPolicyGroupList);
    }
    modelConfiguration.put(POLICY_GROUPS, policyGroups);
  }

  /**
   * On empty.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @return the mono
   */
  private Mono<AssetResponse> onEmpty(NonPrimitiveAsset nonPrimitiveAsset) {
    return PlatformErrorUtils.invalidRequestAssetResponse(null, LEARNING_MODEL_VALIDATION_ERROR,
        getLearningModelLink(nonPrimitiveAsset.getLearningModel(),
            nonPrimitiveAsset.getLearningModel().getAssetType()));
  }

  /**
   * Gets the learning model link.
   *
   * @param learningModel
   *          the learning model
   * @param assetType
   *          the asset type
   * @return the learning model link
   */
  private Link getLearningModelLink(LearningModel learningModel, String assetType) {
    String path = Routes.ASSET_MODELS_ROUTE.value();
    if (AssetType.PRODUCT.name().equals(assetType)) {
      path = Routes.PRODUCT_MODELS_ROUTE.value();
    }
    StringBuilder href = new StringBuilder(path).append(FORWARD_SLASH).append(learningModel.getId())
        .append(VERSIONS_URL).append(learningModel.getVer());
    return new Link(href.toString());
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#validateProductVersion(com.
   * pearson.glp.lpb.data.model.request.ProductVersionPayload, java.lang.String,
   * java.lang.Integer, com.pearson.glp.lpb.enums.AssetType)
   */
  @Override
  public Mono<AssetResponse> validateProductVersion(ProductVersionPayload productVersionPayload,
      String assetId, Integer bssVer, AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = createProductVersionNonPrimitiveAsset(
        productVersionPayload, assetId, bssVer, assetType);
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return validateProductModel(nonPrimitiveAsset);
  }

  /**
   * Creates the product version non primitive asset.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param assetId
   *          the asset id
   * @param bssVer
   *          the bss ver
   * @param assetType
   *          the asset type
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset createProductVersionNonPrimitiveAsset(
      ProductVersionPayload productVersionPayload, String assetId, Integer bssVer,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = prepareAsset(productVersionPayload, bssVer);
    nonPrimitiveAsset.set_id(assetId);
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.addLinks(SELF, this.createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    return nonPrimitiveAsset;
  }

  /**
   * Prepare asset.
   *
   * @param productVersionPayload
   *          the product version payload
   * @param bssVer
   *          the bss ver
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset prepareAsset(ProductVersionPayload productVersionPayload,
      Integer bssVer) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productVersionPayload.getAsset());
    if (!Objects.isNull(productVersionPayload.getUpdateRequest())
        && productVersionPayload.getUpdateRequest().getIsMajorChange()) {
      nonPrimitiveAsset.setBssVer(bssVer + 1);
    } else {
      nonPrimitiveAsset.setBssVer(bssVer);
    }
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setId(CommonUtils.nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT,
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setLastModified(nonPrimitiveAsset.getCreated());
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productVersionPayload.getAsset());
    return nonPrimitiveAsset;
  }

  /**
   * Creates the product non primitive asset.
   *
   * @param productPayload
   *          the product payload
   * @param assetType
   *          the asset type
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset createProductNonPrimitiveAsset(ProductPayload productPayload,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productPayload.getAsset());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(INITIAL_BSS_VER);
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setLastModified(nonPrimitiveAsset.getCreated());
    nonPrimitiveAsset.addLinks(SELF, createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productPayload.getAsset());
    Optional<Configuration> productConfiguation = Optional
        .ofNullable(nonPrimitiveAsset.getConfiguration());
    if (productConfiguation.isPresent()) {
      productConfiguation.get().put(POLICY_GROUPS, Collections.emptyList());
    }
    return nonPrimitiveAsset;
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#createProductNonPrimitiveAssets
   * (com.pearson.glp.lpb.data.model.request.ProductPayload,
   * com.pearson.glp.lpb.data.model.Asset, com.pearson.glp.lpb.enums.AssetType)
   */
  @Override
  public Mono<ProductsResponse> createProductNonPrimitiveAssets(ProductPayload productPayload,
      Asset asset, AssetType assetType) {
    String taskId = UUID.randomUUID().toString();
    Mono<Task> taskMono = createTask(taskId);
    NonPrimitiveAsset productNonPrimitiveAsset = (NonPrimitiveAsset) asset;
    startTaskWorker(productPayload.getAsset(), productNonPrimitiveAsset, assetType, taskId);
    return taskMono.flatMap(task -> {
      return Mono.just(createProductTaskResponse(task.get_id()));
    }).onErrorResume(task -> Mono.just(createProductTaskErrorResponse()));
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#saveProduct(com.pearson.glp.lpb
   * .data.model.Asset)
   */
  @Override
  public Mono<ProductAssetResponse> saveProduct(NonPrimitiveAssetPayload payload, Asset asset) {
    NonPrimitiveAsset nonPrimitiveAsset = (NonPrimitiveAsset) asset;
    String statusId = UUID.randomUUID().toString();
    nonPrimitiveAsset.addLinks(STATUS, createStatusLink(nonPrimitiveAsset));
    nonPrimitiveAsset.setId(CommonUtils.nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT,
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    return saveProductAssets(payload, nonPrimitiveAsset).flatMap(response -> {
      createProductStatus(statusId, ProductsStatus.DRAFT.name(), response.get_id(),
          response.getVer()).subscribe();
      return Mono.just(response);
    });
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#findLatestAssetById(java.lang.
   * String, com.pearson.glp.lpb.enums.AssetType)
   */
  @Override
  public Mono<NonPrimitiveAsset> findLatestAssetById(String assetModelId) {
    return productRepository.findById(assetModelId);
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#findLatestAssetVersionById(java
   * .lang. String, com.pearson.glp.lpb.enums.AssetType)
   */
  @Override
  public Mono<NonPrimitiveAsset> findLatestAssetVersionById(String assetId) {
    return productRepository.getById(assetId);
  }

  /**
   * Find learning model by id and version and asset type.
   *
   * @param learningModelId
   *          the learning model id
   * @param ver
   *          the ver
   * @param assetType
   *          the asset type
   * @return the mono
   */
  private Mono<AssetModel> findLearningModelByIdAndVersionAndAssetType(String learningModelId,
      String ver, String assetType) {
    String docId = null;
    if (PRODUCT.equals(assetType)) {
      docId = PRODUCTMODEL + DOUBLE_COLON + learningModelId + DOUBLE_COLON + ver;
    } else {
      docId = ASSETMODEL + DOUBLE_COLON + learningModelId + DOUBLE_COLON + ver;
    }
    return assetRepo.findById(docId);
  }

  /**
   * Fetch status of the product.
   *
   * @param docId
   *          the doc id
   * @return the mono
   */
  @Override
  public Mono<ProductStateTransition> fetchProductStateTransition(String docId) {
    return stateRepository.findById(docId);
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#getStateTransitionResponse(com.
   * pearson.glp.lpb.data.model.NonPrimitiveAsset,
   * com.pearson.glp.lpb.dto.request.StateTransitionPayload, java.lang.String)
   */
  @Override
  public Mono<ProductStateTransition> getStateTransitionResponse(NonPrimitiveAsset liveProduct,
      StateTransitionPayload payload, String previousState) {

    buildReviewProductInfo(liveProduct);

    // Update the product to set it as a new Live product.
    liveProduct.set_id(UUID.randomUUID().toString());
    liveProduct.setVer(UUID.randomUUID().toString());
    liveProduct.setBssVer(INITIAL_BSS_VER);
    liveProduct.setId(CommonUtils.nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT,
        liveProduct.get_id(), liveProduct.getVer()));
    liveProduct.setCreated(formatDateTime(LocalDateTime.now()).get());
    liveProduct.setLinks(new LinkedHashMap<>());
    liveProduct.addLinks(SELF, createNonPrimitiveAssetSelfLink(AssetType.PRODUCT.url(),
        liveProduct.get_id(), liveProduct.getVer()));

    String statusId = UUID.randomUUID().toString();
    liveProduct.addLinks(STATUS, createStatusLink(liveProduct));
    // Update extensions
    liveProduct.getExtensions().put(CONTENT_METADATA, payload.getContentMetadata());
    liveProduct.getExtensions().put(REASON, payload.getReason());
    liveProduct.getExtensions().put(REASON_CODE, payload.getReasonCode());

    Mono<NonPrimitiveAsset> savedProduct = productRepository.save(liveProduct);
    publishEvent(EventType.PRODUCT_PROMOTED_TO_LIVE.value(), liveProduct);
    return savedProduct
        .flatMap(value -> saveNonPrimitiveAssetLatest(value, payload.getTransitionState()))
        .flatMap(product -> createProductStatus(statusId, payload.getTransitionState(),
            product.get_id(), product.getVer()))
        .flatMap(status -> buildAndSaveStateTransition(payload, liveProduct,
            status.getLastModified(), payload.getTransitionState(), previousState));
  }

  /**
   * Builds the state transition.
   *
   * @param payload
   *          the payload
   * @param product
   *          the product
   * @param lastModified
   *          the last modified
   * @param transitionState
   *          the transition state
   * @param previousState
   *          the previous state
   * @return the product state transition
   */
  private Mono<ProductStateTransition> buildAndSaveStateTransition(StateTransitionPayload payload,
      NonPrimitiveAsset product, String lastModified, String transitionState,
      String previousState) {
    Resources reviewProduct = (Resources) product.getExtend().get(REVIEW_PRODUCT);
    String stateTransitionId = STATE_TRANSITION + DOUBLE_COLON + reviewProduct.getId()
        + DOUBLE_COLON + VERSION + DOUBLE_COLON + reviewProduct.getVer();
    LOGGER.debug(STATE_TRANSITION_RESPONSE_LOG, stateTransitionId);
    ProductStateTransition stateTransition = new ProductStateTransition();
    stateTransition.setId(stateTransitionId);
    stateTransition.setProductId(product.get_id());
    stateTransition.setVer(product.getVer());
    stateTransition.setCreated(product.getCreated());
    stateTransition.setLastModified(lastModified);
    stateTransition.setPreviousState(previousState);
    stateTransition.setTransitionState(transitionState);
    stateTransition.setReason(payload.getReason());
    stateTransition.setReasonCode(payload.getReasonCode());
    stateTransition.setLinks(product.getLinks());
    return stateRepository.save(stateTransition);
  }

  /**
   * Builds the review product info.
   *
   * @param liveProduct
   *          the live product
   */
  private void buildReviewProductInfo(NonPrimitiveAsset liveProduct) {
    LOGGER.debug(REVIEW_PRODUCT_INFO_LOG, liveProduct.get_id());
    Resources reviewProduct = new Resources();
    reviewProduct.setId(liveProduct.get_id());
    reviewProduct.setVer(liveProduct.getVer());
    reviewProduct.setBssVer(liveProduct.getBssVer());
    reviewProduct.setAssetType(liveProduct.getAssetType());
    reviewProduct.setDocType(liveProduct.getDocType());
    reviewProduct.setResourceType(ResourceType.LEARNINGASSET.name());
    reviewProduct.setLinks(liveProduct.getLinks());

    if (liveProduct.getExtend() == null) {
      liveProduct.setExtend(new Extends());
    }
    liveProduct.getExtend().put(REVIEW_PRODUCT, reviewProduct);
  }

  /*
   * (non-Javadoc)
   *
   * @see com.pearson.glp.lpb.services.ProductfindGetAllVersionService#
   * fetchProductStatus(java.lang. String)
   */
  @Override
  public Mono<ProductStatus> fetchProductStatus(String productId) {
    return statusRepository.findById(productId);
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * com.pearson.glp.lpb.services.ProductService#saveStatusDocument(com.pearson.
   * glp.lpb.data.model.NonPrimitiveAsset,
   * com.pearson.glp.lpb.data.model.ProductStatus,
   * com.pearson.glp.lpb.dto.request.ProductStatusPayload)
   */
  @Override
  public Mono<ProductStatus> saveStatusDocument(NonPrimitiveAsset productLA,
      ProductStatus currentStatusDoc, ProductStatusPayload nextStatus) {
    Boolean isValidTransition = validateStatusDocument(currentStatusDoc.getStatus(),
        nextStatus.getStatus());
    if (isValidTransition) {
      if (ProductsStatus.COMPOSE.name().equals(nextStatus.getStatus())) {
        return draftToCompose(productLA, currentStatusDoc, nextStatus);

      } else {
        return setupToReview(productLA, currentStatusDoc, nextStatus);
      }
    } else {
      return Mono
          .just(createProductStatusErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
              HttpStatus.BAD_REQUEST.getReasonPhrase(), UPDATE_STATUS_FAILED, null));
    }

  }

  /**
   * Draft to compose.
   *
   * @param productLA
   *          the product LA
   * @param currentStatus
   *          the current status
   * @param nextStatus
   *          the next status
   * @return the mono
   */
  private Mono<ProductStatus> draftToCompose(NonPrimitiveAsset productLA,
      ProductStatus currentStatus, ProductStatusPayload nextStatus) {
    Mono<NonPrimitiveAsset> latestProduct = findLatestAssetVersionById(
        nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, productLA.get_id()));

    latestProduct.flatMap(model -> {
      productRepository.deleteById(model.getId()).subscribe();
      return saveNonPrimitiveAssetLatest(model, model.get_id(), nextStatus.getStatus());
    }).subscribe(product -> publishEvent(EventType.PRODUCT_PROMOTED_TO_COMPOSE.value(), productLA));

    currentStatus.setStatus(nextStatus.getStatus());
    Mono<ProductStatus> status = statusRepository.save(currentStatus);
    return status;
  }

  /**
   * Publish event.
   *
   * @param eventName
   *          the event name
   * @param productLA
   *          the product LA
   */
  private void publishEvent(String eventName, NonPrimitiveAsset productLA) {
    eventService.publishEventMessage(eventName, productLA).subscribe();
  }

  /**
   * Compose to review.
   *
   * @param productLA
   *          the product LA
   * @param statusDoc
   *          the status doc
   * @param newStatus
   *          the new status
   * @return the mono
   */

  private Mono<ProductStatus> setupToReview(NonPrimitiveAsset productLA, ProductStatus statusDoc,
      ProductStatusPayload newStatus) {
    Mono<ProductAssetClassType> assetClassTypeMono = assetClassTypeRepo.findById(
        CommonUtils.generateDocId(ASSETCLASSTYPES, productLA.get_id(), productLA.getVer()));
    Mono<NonPrimitiveAsset> latestProduct = findLatestAssetVersionById(
        nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, productLA.get_id()));

    return assetClassTypeMono.flatMap(assetClassTypes -> {
      return latestProduct.flatMap(model -> {
        productRepository.deleteById(model.getId()).subscribe();
        return saveNonPrimitiveAssetLatest(model, model.get_id(), newStatus.getStatus());
      }).flatMap(product -> {
        statusDoc.setStatus(newStatus.getStatus());
        Mono<ProductStatus> savedStatus = statusRepository.save(statusDoc);
        publishEvent(EventType.PRODUCT_PROMOTED_TO_REVIEW.value(), product);
        return savedStatus;
      });
    }).switchIfEmpty(
        Mono.just(createProductStatusErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
            HttpStatus.BAD_REQUEST.getReasonPhrase(), SCANNING_FAILED_MESSAGE, null)));
  }

  /**
   * Validate status document.
   *
   * @param oldStatus
   *          the old status
   * @param newStatus
   *          the new status
   * @return the boolean
   */
  @SuppressWarnings("unchecked")
  private Boolean validateStatusDocument(String oldStatus, String newStatus) {
    String schemaFilePath = new StringBuilder(configHome).append(JSON_FILES).append(STATUSDOC)
        .toString();
    Map<String, String> statusMap = convertSchemaToObject(schemaFilePath, HashMap.class);
    String allowedStates = String.join("-", oldStatus, newStatus);
    return statusMap.containsKey(allowedStates);
  }

  /**
   * Creates the product status error response.
   *
   * @param status
   *          the status
   * @param errorCode
   *          the error code
   * @param message
   *          the message
   * @param link
   *          the link
   * @return the product status
   */
  private ProductStatus createProductStatusErrorResponse(int status, String errorCode,
      String message, Link link) {
    ProductStatus response = new ProductStatus();
    response.setError(PlatformErrorUtils.prepareErrorResponse(status, errorCode, message, link));
    return response;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.pearson.glp.lpb.services.ProductService#fetchProductConfiguration(java.
   * lang.String, java.lang.String)
   */
  public Mono<ProductConfigurationResponse> fetchProductConfiguration(String productId,
      String productVer) {
    Mono<NonPrimitiveAsset> nonPrimitiveAsset = productRepository.findById(
        CommonUtils.nonPrimitiveLearningAssetDocumentId(AssetType.PRODUCT, productId, productVer));
    return nonPrimitiveAsset.flatMap(asset -> buildPolicyConfigurationResponse(asset));
  }

  /**
   * Builds the policy configuration response.
   *
   * @param asset
   *          the asset
   * @return the mono
   */
  private Mono<ProductConfigurationResponse> buildPolicyConfigurationResponse(
      NonPrimitiveAsset asset) {
    ProductConfigurationResponse policyResponse = new ProductConfigurationResponse();
    policyResponse.setId(asset.get_id());
    policyResponse.setVer(asset.getVer());
    policyResponse.setBssVer(asset.getBssVer());
    Link sLink = new Link(PRODUCTS_ROUTE + FORWARD_SLASH + asset.get_id()
        + CommonConstants.VERSIONS_URL + asset.getVer());
    LinkedHashMap<String, Link> slinks = new LinkedHashMap<>();
    slinks.put(SELF, sLink);
    policyResponse.setLinks(slinks);
    policyResponse.setConfiguration(asset.getConfiguration());
    return Mono.just(policyResponse);
  }

  /**
   * Fetch product asset type.
   *
   * @param id
   *          the product id
   * @param version
   *          the product version
   * @return the mono
   */
  @Override
  public Mono<ProductAssetClassType> getProductAssetTypes(String id, String version) {
    return assetClassTypeRepo.findById(CommonUtils.generateDocId(ASSETCLASSTYPES, id, version));
  }

  @Override
  public Mono<NonPrimitiveAsset> savePMPMessage(AutobahnEventModel pmpMessage) {
    String pmpMessageId = CommonUtils.generateDocId(PMP,
        pmpMessage.getAutobahnEvent().getPayload().getContentUrn(),
        pmpMessage.getAutobahnEvent().getPayload().getVersionUrn());
    pmpMessage.setId(pmpMessageId);
    Mono<AutobahnEventModel> pmpMessageMono = pmpMessageRepository.findById(pmpMessageId);
    return pmpMessageMono.map(message -> {
      message.setId(null);
      return message;
    }).switchIfEmpty(pmpMessageRepository.save(pmpMessage)).flatMap(pmp -> {
      if (!ObjectUtils.isEmpty(pmp.getId())) {
        Mono<NonPrimitiveAsset> productMono = productRepository.getProductBy(
            pmp.getAutobahnEvent().getPayload().getContentUrn(),
            pmp.getAutobahnEvent().getPayload().getVersionUrn());
        return productMono.flatMap(product -> setupProductWithReviewId(product, pmp));
      }
      return Mono.empty();
    });
  }

  @SuppressWarnings("unchecked")
  @Override
  public Mono<NonPrimitiveAsset> setupProductWithReviewId(NonPrimitiveAsset product,
      AutobahnEventModel pmpMessage) {
    String productMetaId = product.getId();
    String productId = product.get_id();
    String versionId = UUID.randomUUID().toString();
    String reviewId = pmpMessage.getAutobahnEvent().getPayload().getProductId();
    Extensions extensions = product.getExtensions();
    Optional<Object> productizationOptional = Optional.ofNullable(extensions.get(PRODUCTIZATION));
    Productization productization = new Productization();
    if (productizationOptional.isPresent()) {
      HashMap<String, String> map = (HashMap<String, String>) productizationOptional.get();
      productization.setProductId(map.get(ID));
      productization.setId(reviewId);
    } else {
      productization = new Productization();
      productization.setId(reviewId);
    }
    extensions.put(PRODUCTIZATION, productization);

    product.setExtensions(extensions);
    product.setVer(versionId);
    product.addLinks(SELF,
        createNonPrimitiveAssetSelfLink(AssetType.PRODUCT.url(), productId, versionId));
    product.addLinks(STATUS, createStatusLink(product));
    product.setId(CommonUtils.generateDocId(AssetType.PRODUCT.value(), productId, versionId));

    /* Save new version of Product */
    LOGGER.debug(CREATE_PRODUCT_NEW_VERSION, productId);
    return saveNonPrimitiveAssets(product).flatMap(model -> {
      /* Delete current Latest version of Product */
      LOGGER.debug(DELETE_PRODUCT_LATEST_VERSION, productId);
      productRepository.deleteById(productMetaId).subscribe();

      LOGGER.debug(CREATE_PRODUCT_NEW_STATUS, ProductsStatus.SETUP.name(), productId);
      createProductStatus(UUID.randomUUID().toString(), ProductsStatus.SETUP.name(), productId,
          versionId).subscribe();

      /* Save Latest version Document of Product */
      LOGGER.debug(CREATE_PRODUCT_LATEST_DOC, productId);
      return saveNonPrimitiveAssetLatest(product, productId, ProductsStatus.SETUP.name())
          .map(nonPrimitiveAsset -> {
            /* Publish PRODUCT_PROMOTED_TO_SETUP event */
            LOGGER.debug(PUBLISHING_EVENT_MESSAGE, EventType.PRODUCT_PROMOTED_TO_SETUP.value());
            publishEvent(EventType.PRODUCT_PROMOTED_TO_SETUP.value(), product);
            return nonPrimitiveAsset;
          });
    });
  }

  /**
   * Find PMP message if available then promote to SETUP.
   *
   * @param productLearningAsset
   *          the product Learning Asset
   * @return the mono
   */
  @SuppressWarnings("unchecked")
  @Override
  public Mono<AutobahnEventModel> checkPMPMessage(Mono<NonPrimitiveAsset> productLearningAsset) {
    return productLearningAsset.flatMap(asset -> {
      LinkedHashMap<String, String> contentMetadata = (LinkedHashMap<String, String>) asset
          .getExtensions().get(CONTENT_METADATA);
      String pmpMessageId = CommonUtils.generateDocId(PMP, contentMetadata.get(ID),
          contentMetadata.get(VERSION));
      LOGGER.debug(FETCHING_PMP_MESSAGE, pmpMessageId);
      Mono<AutobahnEventModel> pmpMessageMono = pmpMessageRepository.findById(pmpMessageId);
      return pmpMessageMono.flatMap(pmpMessage -> {
        Mono<NonPrimitiveAsset> latestProductMono = productRepository
            .findById(nonPrimitiveLearningAssetLatestDocumentId(AssetType.PRODUCT, asset.get_id(),
                ProductsStatus.COMPOSE.name()));
        return latestProductMono
            .flatMap(latestProduct -> setupProductWithReviewId(latestProduct, pmpMessage))
            .map(product -> pmpMessage);
      });
    });
  }

}