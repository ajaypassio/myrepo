/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.pearson.glp.lpb.enums.CacheRegion;

/**
 * The Class CacheUtils.
 * 
 * @author srishti.singh
 */
@Component
public class CacheUtils {

  /** The cache. */
  private ConcurrentMap<CacheRegion, Cache<String, Object>> cache = new ConcurrentHashMap<>();

  /** The cache enabled. */
  @Value("${cache.service.enabled:false}")
  private boolean cacheEnabled;

  /** The cache max limit. */
  @Value("${cache.max.limit:10}")
  private int cacheMaxLimit;

  /**
   * Put.
   *
   * @param cacheType
   *          the cache type
   * @param key
   *          the key
   * @param value
   *          the value
   */
  public void put(CacheRegion cacheType, String key, Object value) {
    if (cacheEnabled) {
      cache.get(cacheType).asMap().put(key, value);
    }
  }

  /**
   * Gets the.
   *
   * @param cacheType
   *          the cache type
   * @param key
   *          the key
   * @return the optional
   */
  public Optional<Object> get(CacheRegion cacheType, String key) {
    if (cacheEnabled) {
      return Optional.ofNullable(cache.get(cacheType).asMap().get(key));
    } else {
      return Optional.empty();
    }
  }

  /**
   * Initiates the cache.
   */
  @PostConstruct
  public void init() {
    if (cacheEnabled) {
      cache.put(CacheRegion.LEARNING_MODEL, initCache());
    }
  }

  /**
   * Inits the cache.
   *
   * @return the cache
   */
  private Cache<String, Object> initCache() {
    return CacheBuilder.newBuilder().maximumSize(cacheMaxLimit).build();
  }

}
