/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.CommonConstants.AND;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSESSMENT_ITEM_BY_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.constant.CommonConstants.ASSETMODEL;
import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.COLLECTION_DETAILS;
import static com.pearson.glp.lpb.constant.CommonConstants.COLON;
import static com.pearson.glp.lpb.constant.CommonConstants.DOUBLE_COLON;
import static com.pearson.glp.lpb.constant.CommonConstants.EQUALS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.JSON_FILES_PATH;
import static com.pearson.glp.lpb.constant.CommonConstants.LATEST;
import static com.pearson.glp.lpb.constant.CommonConstants.LEARNINGAPP_ITEM_BY_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.PERCENT_SIGN;
import static com.pearson.glp.lpb.constant.CommonConstants.POLICY_GROUPS;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCTMODEL;
import static com.pearson.glp.lpb.constant.CommonConstants.SINGLE_QUOTE;
import static com.pearson.glp.lpb.constant.CommonConstants.STATUS_PARAM;
import static com.pearson.glp.lpb.constant.CommonConstants.TITLE;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_JSON_TO_OBJECT_MAPPING;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.internalServerError;
import static com.pearson.glp.lpb.utils.PlatformErrorUtils.invalidRequestError;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.utils.exception.PlatformException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Resources;
import com.pearson.glp.lpb.dto.response.AssetBulkPostResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.EntityStatus;
import com.pearson.glp.lpb.enums.PlatformErrorCode;

import reactor.core.publisher.Mono;

/**
 * The interface CommonUtils.
 *
 * @author sourabh.aggarwal
 */
public interface CommonUtils {

  /** The log. */
  Logger log = LoggerFactory.getLogger(CommonUtils.class);

  /** The object mapper. */
  ObjectMapper objectMapper = new ObjectMapper();

  /**
   * Convert json to object.
   *
   * @param <T>
   *          the generic type
   * @param jsonFile
   *          the json file
   * @param classType
   *          the class type
   * @return the t
   * @throws ServiceException
   *           the service exception
   */
  default <T> T convertJsonToObject(String jsonFile, Class<T> classType) throws ServiceException {
    try {
      ClassLoader classLoader = getClass().getClassLoader();
      File file = new File(classLoader
          .getResource(JSON_FILES_PATH + "/" + FilenameUtils.getName(jsonFile)).getFile());
      log.debug(file.getPath() + " " + file.getAbsolutePath());
      objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
      return objectMapper.readValue(file, classType);
    } catch (final IOException exception) {
      log.error(ERROR_JSON_TO_OBJECT_MAPPING + COLON, exception);
      throw new ServiceException(ERROR_JSON_TO_OBJECT_MAPPING);
    }
  }

  /**
   * Convert json to object.
   *
   * @param <T>
   *          the generic type
   * @param schemaFilePath
   *          the path of json file
   * @param classType
   *          the class type
   * @return the t
   * @throws ServiceException
   *           the service exception
   */
  default <T> T convertSchemaToObject(String schemaFilePath, Class<T> classType)
      throws ServiceException {
    try {
      File file = FileUtils.getFile(schemaFilePath);
      objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
      return objectMapper.readValue(file, classType);
    } catch (final IOException exception) {
      log.error(ERROR_JSON_TO_OBJECT_MAPPING + COLON, exception);
      throw new ServiceException(ERROR_JSON_TO_OBJECT_MAPPING);
    }
  }

  /**
   * Map object.
   *
   * @param <T>
   *          the generic type
   * @param obj
   *          the obj
   * @param classType
   *          the class type
   * @return the t
   */
  static <T> T mapObject(Object obj, Class<T> classType) {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    return objectMapper.convertValue(obj, classType);
  }

  /**
   * sets the error response for schema validation fail or internal server
   * error.
   *
   * @param exception
   *          the exception
   * @param method
   *          the invoking method name
   * @param message
   *          header of message
   * @param href
   *          href to represents schema
   * @return error response with valid http status
   */
  default Mono<ServiceHandlerResponse> setErrorResponse(Throwable exception, String method,
      String message, String href) {
    if (exception instanceof PlatformException && PlatformErrorCode.INVALID_REQUEST.getValue()
        .equals(((PlatformException) exception).getHttpStatus())) {
      return createInvalidRequestError((PlatformException) exception, href);
    } else {
      log.error(method + OPEN_CLOSE_PARANTHESIS, exception);
      return internalServerError(message + exception.getMessage());
    }
  }

  /**
   * prepare invalid request error response for schema validation fail.
   *
   * @param platformException
   *          exception
   * @param href
   *          href to represents schema
   * @return server handler response containing bad request error.
   */
  default Mono<ServiceHandlerResponse> createInvalidRequestError(
      PlatformException platformException, String href) {
    String errorMessage = platformException.getErrors().get(0).getMessage();
    Link link = new Link();
    link.setHref(href);
    return invalidRequestError(errorMessage, link);
  }

  /**
   * Checks if is uuid.
   *
   * @param id
   *          the id
   * @return true, if is uuid
   */
  static boolean isUuid(String id) {
    try {
      UUID.fromString(id);
      return true;
    } catch (IllegalArgumentException ex) {
      return false;
    }
  }

  /**
   * Set entity status asset bulk post response.
   *
   * @param assetResponse
   *          the asset response
   * @return the asset bulk post response
   */
  default AssetBulkPostResponse setEntityStatus(AssetResponse assetResponse) {

    AssetBulkPostResponse assetBulkPostResponse = new AssetBulkPostResponse(assetResponse);
    if (ObjectUtils.isEmpty(assetResponse.getError())) {
      assetBulkPostResponse.setEntityStatus(EntityStatus.Success.toString());
      assetBulkPostResponse.setStatus(HttpStatus.CREATED.value());
    } else {
      assetBulkPostResponse.setEntityStatus(EntityStatus.Error.toString());
      assetBulkPostResponse.setStatus(assetResponse.getError().getStatus());
      assetBulkPostResponse.setError(assetResponse.getError());
    }
    return assetBulkPostResponse;
  }

  /**
   * Non primitive learning asset document id.
   *
   * @param assetType
   *          the asset type
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  static String nonPrimitiveLearningAssetDocumentId(AssetType assetType, String id, String ver) {
    return assetType.value() + CommonConstants.DOUBLE_COLON + id + CommonConstants.DOUBLE_COLON
        + ver;
  }

  /**
   * Non primitive learning asset latest document id.
   *
   * @param assetType
   *          the asset type
   * @param id
   *          the id
   * @return the string
   */
  default String nonPrimitiveLearningAssetLatestDocumentId(AssetType assetType, String id) {

    return new StringBuilder().append(assetType.value()).append(CommonConstants.DOUBLE_COLON)
        .append(CommonConstants.LATEST).append(CommonConstants.DOUBLE_COLON).append(id)
        .append(PERCENT_SIGN).toString();
  }

  /**
   * Non primitive learning asset latest document id.
   *
   * @param assetType
   *          the asset type
   * @param id
   *          the id
   * @param status
   *          the status
   * @return the string
   */
  default String nonPrimitiveLearningAssetLatestDocumentId(AssetType assetType, String id,
      String status) {

    return new StringBuilder().append(assetType.value()).append(CommonConstants.DOUBLE_COLON)
        .append(CommonConstants.LATEST).append(CommonConstants.DOUBLE_COLON).append(id)
        .append(CommonConstants.DOUBLE_COLON).append(status).toString();
  }

  /**
   * Product status document id.
   *
   * @param assetType
   *          the asset type
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  default String productStatusDocumentId(AssetType assetType, String id, String ver) {

    return assetType.value() + CommonConstants.DOUBLE_COLON + CommonConstants.STATUS
        + CommonConstants.DOUBLE_COLON + id + CommonConstants.DOUBLE_COLON + ver;
  }

  /**
   * Gets all versions document id.
   *
   * @param assetType
   *          the asset type
   * @param id
   *          the id
   * @return the all versions document id
   */
  default String getAllVersionsDocumentId(AssetType assetType, String id) {
    return assetType.value() + CommonConstants.DOUBLE_COLON + id + CommonConstants.PERCENT_SIGN;
  }

  /**
   * Gets all documents.
   *
   * @param assetType
   *          the asset type
   * @return the get all documents
   */
  default String getAllDocumentsId(AssetType assetType) {
    return assetType.value() + CommonConstants.DOUBLE_COLON + CommonConstants.LATEST
        + CommonConstants.PERCENT_SIGN;
  }

  /**
   * Generate doc id.
   *
   * @param type
   *          the type
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the string
   */
  static String generateDocId(String type, String id, String version) {
    if (!ObjectUtils.isEmpty(version)) {
      return new StringBuilder(type).append(CommonConstants.DOUBLE_COLON).append(id)
          .append(CommonConstants.DOUBLE_COLON).append(version).toString();

    }
    return new StringBuilder(type).append(CommonConstants.DOUBLE_COLON)
        .append(CommonConstants.LATEST).append(CommonConstants.DOUBLE_COLON).append(id).toString();
  }

  /**
   * Prepare doc id.
   *
   * @param type
   *          the type
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  static String prepareDocId(String type, String id, String ver) {
    return getLearningModel(type) + DOUBLE_COLON + id + DOUBLE_COLON + ver;
  }

  /**
   * Prepare doc id.
   *
   * @param type
   *          the type
   * @param id
   *          the id
   * @param latest
   *          the latest
   * @return the string
   */
  static String prepareDocId(String type, String id, boolean latest) {
    if (latest) {
      return getLearningModel(type) + DOUBLE_COLON + LATEST + DOUBLE_COLON + id;
    }
    return getLearningModel(type) + DOUBLE_COLON + id + DOUBLE_COLON + PERCENT_SIGN;
  }

  /**
   * Prepare doc id.
   *
   * @param type
   *          the type
   * @return the string
   */
  static String prepareDocId(String type) {
    return getLearningModel(type) + DOUBLE_COLON + LATEST + DOUBLE_COLON + PERCENT_SIGN;
  }

  /**
   * Gets the learning model.
   *
   * @param assetType
   *          the asset type
   * @return the learning model
   */
  static String getLearningModel(String assetType) {
    if (PRODUCT.equals(assetType)) {
      return PRODUCTMODEL;
    }
    return ASSETMODEL;
  }

  /**
   * Gets the time stamp.
   *
   * @return the time stamp
   */
  static String getTimeStamp() {
    return DateUtil.formatDateTime(LocalDateTime.now()).get();
  }

  /**
   * Creates the self link.
   *
   * @param baseUrl
   *          the base url
   * @param lavalue
   *          the lavalue
   * @return the string
   */
  static String createSelfLink(String baseUrl, Resources lavalue) {
    String href = "";
    if (AssetType.ASSESSMENT_ITEM.value().equals(lavalue.getAssetType())) {
      href = baseUrl + ASSESSMENT_ITEM_BY_VERSION_ID_ROUTE;
    } else if (AssetType.LEARNINGAPP_ITEM.value().equals(lavalue.getAssetType())) {
      href = baseUrl + LEARNINGAPP_ITEM_BY_VERSION_ID_ROUTE;
    } else {
      href = baseUrl + AssetType.valueOf(lavalue.getAssetType()).url();
    }
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, lavalue.getId());
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, lavalue.getVer());
    return href;
  }

  /**
   * Validate policy groups.
   *
   * @param configuration
   *          the configuration
   * @return true, if successful
   */
  static boolean validatePolicyGroups(Configuration configuration) {
    if (configuration != null && configuration.containsKey(POLICY_GROUPS)) {
      Optional<Object> policyGroups = Optional.ofNullable(configuration.get(POLICY_GROUPS));
      if (!policyGroups.isPresent() || !(policyGroups.get() instanceof List<?>)) {
        return false;
      }
      List<?> objectList = (List<?>) policyGroups.get();
      for (Object object : objectList) {
        if (!(object instanceof String)) {
          return false;
        }
      }

    }
    return true;
  }

  /**
   * Generate user group policy id.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the string
   */
  static String generateUserGroupPolicyId(String id, String version) {
    StringBuilder policyGroupId = new StringBuilder(TITLE).append(id).append(DOUBLE_COLON)
        .append(version);
    return policyGroupId.toString();
  }

  /**
   * Prepare where clause.
   *
   * @param parameters
   *          the parameters
   * @return the string builder
   */
  default StringBuilder prepareWhereClause(MultiValueMap<String, String> parameters,
      AssetType assetType) {
    StringBuilder metaId = new StringBuilder(getAllDocumentsId(assetType));
    if (parameters.keySet().contains(STATUS_PARAM)) {
      metaId.append(parameters.getFirst(STATUS_PARAM));
    }
    StringBuilder whereClause = new StringBuilder(" meta().id like ").append(SINGLE_QUOTE)
        .append(metaId).append(SINGLE_QUOTE);

    parameters.forEach((key, value) -> {
      if (!(key.contains(STATUS_PARAM) || key.contains(COLLECTION_DETAILS))) {
        whereClause.append(AND);
        whereClause.append(key);
        whereClause.append(EQUALS + SINGLE_QUOTE + parameters.getFirst(key) + SINGLE_QUOTE);
      }
    });
    whereClause.append(CommonConstants.ORDER_BY).append(CommonConstants.CREATED)
        .append(CommonConstants.DESC);
    return whereClause;
  }

}