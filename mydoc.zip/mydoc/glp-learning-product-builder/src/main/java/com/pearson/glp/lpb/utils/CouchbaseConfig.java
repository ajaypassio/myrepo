/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.couchbase.config.AbstractCouchbaseConfiguration;
import org.springframework.data.couchbase.core.convert.MappingCouchbaseConverter;
import org.springframework.data.couchbase.core.mapping.CouchbaseDocument;
import org.springframework.data.couchbase.core.mapping.CouchbaseMappingContext;
import org.springframework.data.couchbase.core.mapping.CouchbasePersistentEntity;
import org.springframework.data.couchbase.core.mapping.CouchbasePersistentProperty;
import org.springframework.data.couchbase.repository.support.IndexManager;
import org.springframework.data.mapping.context.MappingContext;
import org.springframework.data.util.TypeInformation;

@Configuration
public class CouchbaseConfig extends AbstractCouchbaseConfiguration {

  @Override
  protected List<String> getBootstrapHosts() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  protected String getBucketName() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  protected String getBucketPassword() {
    // TODO Auto-generated method stub
    return null;
  }

  @Bean
  @Override
  public MappingCouchbaseConverter mappingCouchbaseConverter() {
    CouchbaseMappingContext couchbaseMappingContext = new CouchbaseMappingContext();
    return new MyMappingCouchbaseConverter(couchbaseMappingContext);
  }

  private class MyMappingCouchbaseConverter extends MappingCouchbaseConverter {
    public MyMappingCouchbaseConverter(
        MappingContext<? extends CouchbasePersistentEntity<?>, CouchbasePersistentProperty> mappingContext) {
      super(mappingContext);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected <R> R read(final TypeInformation<R> type, final CouchbaseDocument source,
        final Object parent) {
      if (Object.class == typeMapper.readType(source, type).getType()) {
        return (R) source.export();
      } else {
        return super.read(type, source, parent);
      }
    }
  }

  /*
   * This method is to tell Spring container to auto create View, Primary and
   * secondary indexes It should be enabled only in DEV environment
   * (non-Javadoc)
   *
   * @see
   * org.springframework.data.couchbase.config.CouchbaseConfigurationSupport#
   * indexManager()
   *
   * @see
   * https://docs.spring.io/spring-data/couchbase/docs/current/reference/html/#
   * couchbase.repository.views
   *
   */
  @Override
  @Bean
  public IndexManager indexManager() {
    return new IndexManager(true, true, true);
  }
}
