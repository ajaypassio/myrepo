/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;

/**
 * The interface DateUtil.
 *
 * @author sourabh.aggarwal
 */
public interface DateUtil {

  /** The thousand. */
  int THOUSAND = 1000;

  /** The ISO_8601_FORMAT constant. */
  static final String ISO_8601_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'+00:00'";

  /**
   * Formats the input local date time into the given pattern.
   *
   * @param dateTime
   *          the date time to format
   * @return the optional formatted date time string, empty optional if date
   *         time or pattern null
   */
  static Optional<String> formatDateTime(final LocalDateTime dateTime) {
    Optional<String> formattedDateTime = Optional.empty();
    if (dateTime != null) {
      final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(ISO_8601_FORMAT);
      formattedDateTime = Optional.ofNullable(dateTime.format(formatter));
    }
    return formattedDateTime;
  }

  /**
   * Format date time.
   *
   * @param timestamp
   *          the timestamp
   * @param pattern
   *          the pattern
   * @return the string
   */
  static String formatDateTime(final long timestamp, final String pattern) {
    String formattedDateTime = null;
    if (StringUtils.isNotBlank(pattern)) {
      final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
      formattedDateTime = formatter
          .format(LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault()));
    }
    return formattedDateTime;
  }

  /**
   * Current timestamp.
   *
   * @return the long
   */
  static Long currentTimestamp() {
    return ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond() * THOUSAND;
  }

}