/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.V2_SCHEMAS_NONPRIMITIVE_SCHEMA;
import static com.pearson.glp.lpb.constant.LoggingConstants.INVALID_REQUEST_PAYLOAD;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.pearson.glp.core.errors.PlatformError;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.exceptions.SchemaValidationException;

import reactor.core.publisher.Mono;

/**
 * The Interface PlatformErrorUtils.
 * 
 * @author sourabh.aggarwal
 */
public interface PlatformErrorUtils {

  /**
   * Object not found error.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> objectNotFoundError(String message) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.OBJECT_NOT_FOUND.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.OBJECT_NOT_FOUND.getValue(),
            PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), message, null));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Internal server error.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> internalServerError(String message) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue(),
            PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), message, null));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Invalid request error.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> invalidRequestError(String message) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.INVALID_REQUEST.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
            PlatformErrorCode.INVALID_REQUEST.getErrorCode(), message, null));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * Invalid request error.
   * 
   * @param message
   *          the message
   * @param link
   *          the link
   * @return service handler response mono
   */
  static Mono<ServiceHandlerResponse> invalidRequestError(String message, Link link) {
    JsonPayloadServiceResponse jsonPayloadServiceResponse = new JsonPayloadServiceResponse();
    jsonPayloadServiceResponse.setStatus(PlatformErrorCode.INVALID_REQUEST.getValue());
    jsonPayloadServiceResponse
        .setPayload(prepareErrorResponse(PlatformErrorCode.INVALID_REQUEST.getValue(),
            PlatformErrorCode.INVALID_REQUEST.getErrorCode(), message, link));
    return Mono.just(jsonPayloadServiceResponse);
  }

  /**
   * emptyPayloadError.
   *
   * @return the mono
   */
  static Mono<ServiceHandlerResponse> invalidRequestPayload() {
    PlatformErrorResponse platformErrorResponse = new PlatformErrorResponse();
    platformErrorResponse.setTimestamp(CommonUtils.getTimeStamp());
    platformErrorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
    platformErrorResponse.setError(HttpStatus.BAD_REQUEST.getReasonPhrase());
    platformErrorResponse.setMessage(INVALID_REQUEST_PAYLOAD);
    return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST)
        .setHeader(CONTENT_TYPE, MediaType.APPLICATION_JSON.toString())
        .setPayload(platformErrorResponse);
  }

  /**
   * Generate error response.
   *
   * @param metadata
   *          the metadata
   * @param message
   *          the message
   * @param links
   *          the links
   * @return the mono
   */
  static Mono<AssetResponse> invalidRequestAssetResponse(ContentMetadata metadata, String message,
      Link links) {
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setContentMetadata(metadata);
    assetResponse.setError(PlatformErrorUtils.prepareErrorResponse(HttpStatus.BAD_REQUEST.value(),
        PlatformErrorCode.INVALID_REQUEST.getErrorCode(), message, links));
    return Mono.just(assetResponse);
  }

  /**
   * Prepare error response.
   *
   * @param status
   *          the status
   * @param errorCode
   *          the error code
   * @param message
   *          the message
   * @param link
   *          the Link
   * @return the platform error
   */
  static PlatformErrorResponse prepareErrorResponse(int status, String errorCode, String message,
      Link link) {
    PlatformErrorResponse platformErrorResponse = new PlatformErrorResponse();
    platformErrorResponse.setStatus(status);
    platformErrorResponse.setError(errorCode);
    platformErrorResponse.setMessage(message);
    platformErrorResponse.setLink(link);
    platformErrorResponse.setTimestamp(CommonUtils.getTimeStamp());
    return platformErrorResponse;
  }

  /**
   * Creates the schema validation exception.
   *
   * @param message
   *          the message
   * @return the mono
   */
  static SchemaValidationException prepareSchemaValidationExceptionResponse(String message) {
    Link link = new Link();
    link.setHref(V2_SCHEMAS_NONPRIMITIVE_SCHEMA);
    return new SchemaValidationException(HttpStatus.BAD_REQUEST.value(), new PlatformError(),
        HttpStatus.BAD_REQUEST.name(), message, CommonUtils.getTimeStamp(), link);
  }
}