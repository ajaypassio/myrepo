/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.mockito.Mockito;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;

import io.restassured.RestAssured;
import reactor.core.publisher.Mono;

/**
 * The Class InstructionVersionsPostBase.
 */
public abstract class InstructionVersionsPostBase extends ProducerBase {

  /** The Constant RESPONSE_JSON. */
  private static final String RESPONSE_JSON = "PostInstructionsResponse.json";

  /**
   * Sets the up.
   *
   * @throws ServiceException
   *           the service exception
   */
  @SuppressWarnings("unchecked")
  @Before
  public void setUp() throws ServiceException {
    RestAssured.port = this.port;
    RestAssured.baseURI = localhost;

    Map<String, Object> resourceAsMap = convertJsonToObject(RESPONSE_JSON, HashMap.class);

    Mono<ServiceHandlerResponse> serverResponse = JsonPayloadServiceResponse.ok()
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL).setStatus(201).setPayload(resourceAsMap);
    Mockito.when(nonPrimitiveHandler.createAssetVersions(Mockito.any(), Mockito.any()))
        .thenReturn(serverResponse);
  }

}
