/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_STREAMING_WITH_HAL;

import java.util.HashMap;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;

import io.restassured.RestAssured;
import reactor.core.publisher.Mono;

/**
 * @author sweta.malik
 *
 */

public abstract class LearningAppsError400Base extends ProducerBase {

  /** The Constant AGGREGATE_POST_ERROR_JSON. */
  private static final String LEARNINGAPPS_POST_ERROR_JSON = "LearningAppsPostError400Response.json";

  /**
   * Sets the up.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setUp() throws ServiceException {
    RestAssured.port = this.port;
    RestAssured.baseURI = localhost;

    Mono<ServiceHandlerResponse> serverResponsePost = JsonPayloadServiceResponse
        .withStatus(HttpStatus.MULTI_STATUS)
        .setHeader(CONTENT_TYPE, CONTENT_TYPE_STREAMING_WITH_HAL)
        .setPayload(convertJsonToObject(LEARNINGAPPS_POST_ERROR_JSON, HashMap.class));

    Mockito.when(nonPrimitiveHandler.createAssets(Mockito.any(), Mockito.any()))
        .thenReturn(serverResponsePost);
  }

}
