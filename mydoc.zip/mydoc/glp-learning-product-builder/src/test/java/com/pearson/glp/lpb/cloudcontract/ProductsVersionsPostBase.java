/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.cloudcontract;

import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_TYPE_HAL;
import static com.pearson.glp.lpb.constant.CommonConstants.PRODUCT_NEW_VERSION_RESPONSE_JSON;

import java.util.HashMap;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;

import io.restassured.RestAssured;

/**
 * The Class ProductsVersionsPostBase.
 */
/**
 * @author dinesh.kumar1
 *
 */
public abstract class ProductsVersionsPostBase extends ProducerBase {
  /**
   * Sets the up.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setUp() throws ServiceException {
    RestAssured.port = this.port;
    RestAssured.baseURI = localhost;
    Mockito.when(productHandler.createNewProduct(Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.ok().setHeader(CONTENT_TYPE, CONTENT_TYPE_HAL)
            .setStatus(HttpStatus.CREATED.value())
            .setPayload(convertJsonToObject(PRODUCT_NEW_VERSION_RESPONSE_JSON, HashMap.class)));
  }

}