/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;

/**
 * The Class CommonConstantsTest.
 * 
 * @author sourabh.aggarwal
 */
public class CommonConstantsTest {

  /**
   * Instantiates a new learning model constants test.
   */
  public CommonConstantsTest() {
    super();
  }

  /**
   * Test doc type category.
   */
  @Test
  public void testDocTypeCategory() {
    // Given
    String docType = "LEARNINGMODEL";

    // Then
    assertEquals(DocType.LEARNINGMODEL.value(), docType);
  }

  /**
   * Test asset type category.
   */
  @Test
  public void testAssetTypeCategory() {
    // Given
    String assetType = "INSTRUCTION";

    // Then
    assertEquals(AssetType.INSTRUCTION.value(), assetType);
  }
}