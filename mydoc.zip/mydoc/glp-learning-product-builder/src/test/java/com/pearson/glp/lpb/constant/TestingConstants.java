/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.constant;

import java.util.Optional;

/**
 * The Class TestingConstants.
 * 
 * @author sourabh.aggarwal
 */
public final class TestingConstants {

  /**
   * Instantiates a new testing constants.
   */
  private TestingConstants() {
    super();
  }

  /** The Constant ASSET_MODEL_LABEL. */
  public static final String ASSET_MODEL_LABEL = "INSTRUCTION";

  /** The Constant PRODUCT_MODEL_LABEL. */
  public static final String PRODUCT_MODEL_LABEL = "PRODUCT";

  /** The Constant ASSET_MODEL_TAGS. */
  public static final String ASSET_MODEL_TAGS = "REVEL";

  /** The Constant PRODUCT_MODEL_TAGS. */
  public static final String PRODUCT_MODEL_TAGS = "REVEL";

  /** The Constant ASSET_MODEL_TAGS. */
  public static final String ASSET_MODEL_CREATED_BY = "ADMIN";

  /** The Constant ASSET_MODEL_EXPIRES_ON. */
  public static final String ASSET_MODEL_EXPIRES_ON = "2020-12-12T18:29:50.588Z";

  /** The Constant ASSET_MODEL_ROUTE. */
  public static final String ASSET_MODEL_ROUTE = "/lpb/v2/assetModels/";

  /** The Constant PRODUCT_MODELS_ROUTE. */
  public static final String PRODUCT_MODEL_ROUTE = "/lpb/v2/productModels/";

  /** The Constant VERSIONS. */
  public static final String VERSIONS = "/versions/";

  /** The Constant ASSET_TYPES_WITH_PARAM. */
  public static final String ASSET_TYPES_WITH_PARAM = "/assetTypes?assetType";

  /** The Constant ASSET_TYPES. */
  public static final String ASSET_TYPES = "/assetTypes";

  /** The Constant INVALID_ASSET_MODEL_ROUTE. */
  public static final String INVALID_ASSET_MODEL_ROUTE = "/lpb/v1/assetModels/";

  /** The Constant ASSESSMENT. */
  public static final String ASSESSMENT = "ASSESSMENT";

  /** The Constant PRODUCT. */
  public static final String PRODUCT = "PRODUCT";

  /** The Constant ERROR_PAGE_SIZE_AND_PAGE_NUMBER. */
  public static final String ERROR_PAGE_SIZE_AND_PAGE_NUMBER = "Page size and page number can only be a non-zero positive numeric value.";

  /** The Constant ERROR_MAX_PAGE_SIZE. */
  public static final String ERROR_MAX_PAGE_SIZE = "Max Page Size can be 50 only.";

  /** The Constant ERROR_PAGE_SIZE. */
  public static final String ERROR_PAGE_SIZE = "Page size can only be non-zero positive numeric value.";

  /** The Constant ERROR_PAGE_NUMBER. */
  public static final String ERROR_PAGE_NUMBER = "Page number can only be non-zero positive numeric value.";

  /** The Constant DUMMY_RESOURCES_URL. */
  public static final String DUMMY_RESOURCES_URL = "/v2/assetModels/1/versions/2";

  /** The constant INSTRUCTION_POST_REQUEST. */
  public static final String INSTRUCTION_POST_REQUEST = "InstructionPostRequest.json";

  /** The constant AGGREGATE_POST_REQUEST. */
  public static final String AGGREGATE_POST_REQUEST = "AggregatePostRequest.json";

  /** The constant LEARNINGAPP_POST_REQUEST. */
  public static final String LEARNINGAPP_POST_REQUEST = "LearningAppPostRequest.json";

  /** The constant INSTRUCTION_POST_ERROR_REQUEST. */
  public static final String INSTRUCTION_POST_ERROR_REQUEST = "InstructionPostErrorRequest.json";

  /** The constant INSTRUCTION_POST_RESPONSE. */
  public static final String INSTRUCTION_POST_RESPONSE = "InstructionPostResponse.json";

  /** The constant AGGREGATE_POST_RESPONSE. */
  public static final String AGGREGATE_POST_RESPONSE = "AggregatePostResponse.json";

  /** The constant AGGREGATE_POST_RESPONSE. */
  public static final String ASSESSMENT_POST_RESPONSE = "AssessmentPostResponse.json";

  /** The constant LEARNINGAPP_POST_RESPONSE. */
  public static final String LEARNINGAPP_POST_RESPONSE = "LearningAppResponse.json";

  /** The constant INSTRUCTION_POST_JSON. */
  public static final String INSTRUCTION_POST_JSON = "InstructionPost.json";

  /** The constant INSTRUCTION_POST_REQUEST. */
  public static final String INSTRUCTION_VERSION_POST_REQUEST = "InstructionVersionPostRequest.json";

  /** The constant AGGREGATES_VERSION_POST_REQUEST. */
  public static final String AGGREGATES_VERSION_POST_REQUEST = "AggregateVersionPostRequest.json";

  /** The constant PRODUCT_JSON. */
  public static final String PRODUCT_JSON = "Product.json";

  /** The constant PRODUCT_EVENT_JSON. */
  public static final String PRODUCT_EVENT_JSON = "ProductEvent.json";

  /**
   * The Constant FIND_PROUDUCT_BY_ID_ROUTE.
   */
  public static final String FIND_PROUDUCT_BY_ID_ROUTE = "/v2/products/";

  /** The Constant FIND_PROUDUCT_BY_VER_ROUTE. */
  public static final String FIND_PROUDUCT_BY_VERSION_ROUTE = "/v2/products/{id}/versions/{ver}";

  /** The Constant INVALID_GET_INSTRUCTION_ROUTE. */
  public static final String INVALID_GET_INSTRUCTION_ROUTE = "/v2/instruction/";

  /** The Constant INSTRUCTION_ROUTE. */
  public static final String INSTRUCTION_ROUTE = "/v2/instructions/";

  /** The Constant BASE_VERSION. */
  public static final int BASE_VERSION = 1;

  /** The Constant GET_INSTRUCTION_ROUTE. */
  public static final String GET_INSTRUCTION_ROUTE = "/v2/instructions/";

  /** The constant INSTRUCTION_ID. */
  public static final String INSTRUCTION_ID = "1484b437-7ed5-4240-a450-2cf40aad9348";

  /** The constant INSTRUCTION_VERSION. */
  public static final String INSTRUCTION_VERSION = "092aca61-c1b3-4e2e-9ba8-51a2201d73b5";

  /** The Constant PRODUCT_ID. */
  public static final String PRODUCT_VERSION = "810a3768-17af-4f2f-9d4c-b07c6cdfc672";

  /** The constant AGGREGATE_ID. */
  public static final String AGGREGATE_ID = "243b49fb-24a0-4081-8970-efd55773f32c";

  /** The constant AGGREGATE_VERSION. */
  public static final String AGGREGATE_VERSION = "092aca61-c1b3-4e2e-9ba8-51a2201d73b5";

  /** The Constant RESOURCES_JSON_FILES. */
  public static final String RESOURCES_JSON_FILES = "src/main/resources/jsonFiles/";

  /** The Constant GET_AGGREGATES_BYID_JSON. */
  public static final String GET_AGGREGATES_BYID_JSON = "GetAggregateById.json";

  /** The constant INVALID_AGGREGATE_ID. */
  public static final String INVALID_AGGREGATES_ID = "902f10f9-5d06-498d-87c8-2284e7c8a293";

  /** The Constant AGGREGATES_ROUTE. */
  public static final String AGGREGATES_ROUTE = "/v2/aggregates/";

  /** The Constant INSTRUCTIONS_QUERY_PARAMS. */
  public static final String INSTRUCTIONS_QUERY_PARAMS = "/v2/instructions?";

  /** The Constant AGGREGATES_QUERY_PARAMS. */
  public static final String AGGREGATES_QUERY_PARAMS = "/v2/aggregates?";

  /** The Constant PAGE_SIZE. */
  public static final String PAGE_SIZE = "pageSize";

  /** The Constant COUNT. */
  public static final String COUNT = "count";

  /** The Constant AND. */
  public static final String AND = "&";

  /** The Constant PAGE_NUMBER. */
  public static final String PAGE_NUMBER = "pageNumber";

  /** The Constant AGGREGATES. */
  public static final String AGGREGATES = "AGGREGATE";

  /** The Constant TAGS. */
  public static final String TAGS = "REVEL";

  /** The constant AGGREGATE_POST_JSON. */
  public static final String AGGREGATE_POST_JSON = "AggregatePost.json";

  /** The Constant EMPTY_RESPONSE. */
  public static final String EMPTY_RESPONSE = "Empty Response";

  /** The Constant INSTRUCTION_VERSION_ID. */
  public static final String INSTRUCTION_VERSION_ID = "092aca61-c1b3-4e2e-9ba8-51a2201d73b5";

  /** The Constant INSTRUCTION_MODEL_NON_PRIMITIVE_JSON. */
  public static final String INSTRUCTION_MODEL_NON_PRIMITIVE_JSON = "SampleInstructionModelNPLA.json";

  /** The Constant NARRATIVES_JSON. */
  public static final String NARRATIVES_JSON = "Narratives.json";

  /** The Constant SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON. */
  public static final String SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON = "SampleInstructionsNonPrimitive.json";

  /** The Constant SAMPLE_INSTRUCTIONS_PRIMITIVE_JSON. */
  public static final String SAMPLE_INSTRUCTIONS_PRIMITIVE_JSON = "SampleInstructionsPrimitive.json";

  /** The Constant SLATE_1_INCORRECT. */
  public static final String SLATE_1_INCORRECT = "sLATE1-1";

  /** The Constant SLATE_1. */
  public static final String SLATE_1 = "SLATE-1";

  /** The Constant PRODUCT_ID. */
  public static final String PRODUCT_ID = "6ed571e9-febd-497f-b384-d88a979f456d";

  /** The Constant PRODUCT_ID. */
  public static final String PRODUCT_ID_2 = "eec73738-bc1a-11e8-a355-529269fb1459";

  /** The CONTENTMETADATA_ID. */
  public static final String CONTENTMETADATA_ID = "dcd035ca-bc1a-11e8-a355-529269fb1459";

  /** The Constant PRODUCTS_ROUTE. */
  public static final String PRODUCT_ROUTE = "/v2/products?";

  /** The Constant PRODUCT_ROUTE_BASE. */
  public static final String PRODUCT_ROUTE_BASE = "/v2/products";

  /** The Constant INVALI_PRODUCT_ROUTE. */
  public static final String INVALID_PRODUCT_ROUTE = "/v2/product";

  /** The Constant PRODUCT_ROUTE_ID. */
  public static final String PRODUCT_ROUTE_ID = "id";

  /** The Constant VER. */
  public static final String VERSION = "ver";

  /** The Constant PRODUCT_ROUTE_TAGS. */
  public static final String PRODUCT_ROUTE_TAGS = "tags";

  /** The Constant PRODUCT_ROUTE_CONTENTMETADATAID. */
  public static final String PRODUCT_ROUTE_CONTENTMETADATAID = "extensions.contentMetadata.id";

  /** The Constant CONTENTMETADATAID. */
  public static final String CONTENTMETADATA = "contentMetadata";

  /** The Constant EQUALS. */
  public static final String EQUALS = "=";

  /** The Constant ONE_OF. */
  public static final String ONE_OF = "oneOf";

  /** The Constant INSTANCE_FAILED. */
  public static final String INSTANCE_FAILED = "instance failed";
  /** The get product by version url. */
  public static final String GET_PRODUCT_BY_VERSION_URL = "/v2/products/{id}/versions/{ver}";

  /** The Constant TASK_BY_ID_ROUTE. */
  public static final String TASK_BYID_ROUTE = "/v2/tasks/{id}";

  /** The Constant TASK_BYID_PRODUCTS. */
  public static final String TASK_BYID_PRODUCTS = "/v2/tasks/{id}/products";

  /** The Constant RUNNING_STATUS. */
  public static final String RUNNING_STATUS = "RUNNING";

  /**
   * The constant SCHEMA_VALIDATION_FAIL_JSON which specifies error json node.
   */
  public static final String SCHEMA_VALIDATION_FAIL_JSON = "schemaValidationFail.json";

  /** The constant LEARNING_MODEL_SCHEMA_ROUTE to specify href. */
  public static final String LEARNING_MODEL_SCHEMA_ROUTE = "/lpb/v2/schemas/learningModelSchema";

  /** The constant LEARNING_MODEL_SCHEMA_ROUTE to specify href. */
  public static final String INVALID_LEARNING_MODEL_SCHEMA_ROUTE = "/lpb/v2/schemas/invalidLearningModelSchema";

  /** The constant PRODUCT_POST_REQUEST. */
  public static final String PRODUCT_POST_REQUEST = "PostProductRequest.json";

  /** The constant PRODUCT_POST_VERSION_REQUEST. */
  public static final String PRODUCT_POST_VERSION_REQUEST = "PostProductVersionRequest.json";

  /** The Constant TASK_ID. */
  public static final String TASK_ID = "5cf32763-9ad5-4cc8-a27c-d0a676c89dhi";

  /** The Constant TASK_STATUS. */
  public static final String TASK_STATUS = "STARTED";

  /** The Constant GET_TASK_URL. */
  public static final String GET_TASK_URL = "/v2/tasks/";

  /** The Constant ERROR_FETCHING_PRODUCT. */
  public static final String ERROR_FETCHING_PRODUCT = "Error in fetching product.";

  /** The Constant RESOURCES_KEY. */
  public static final String RESOURCES_KEY = "resourceKey";

  /** The Constant ASSET_MODEL_BY_VERSION_ID_ROUTE. */
  public static final String ASSET_MODEL_BY_VERSION_ID_ROUTE = "/v2/assetModels/{id}/versions/{ver}";

  /** The Constant INSTRUCTIONS_VERSIONS_ROUTE. */
  public static final String INSTRUCTIONS_VERSIONS_ROUTE = "/v2/instructions/{id}/versions";

  /** The Constant AGGREGATES_VERSIONS_ROUTE. */
  public static final String AGGREGATES_VERSIONS_ROUTE = "/v2/aggregates/{id}/versions";

  /** The Constant ASSET_MODEL_URI. */
  public static final String ASSET_MODEL_URI = "/lpb/v2/assetModels";

  /** The Constant PRODUCT_MODEL_URI. */
  public static final String PRODUCT_MODEL_URI = "/lpb/v2/productModels";

  /** The constant PRODUCT_STATE_TRANSITION_REQUEST. */
  public static final String PRODUCT_STATE_TRANSITION_REQUEST = "PostStateTransitionRequest.json";

  /** The Constant STATE_TRANSITION. */
  public static final String STATE_TRANSITION = "/stateTransitions";

  /** The Constant PRODUCT_STATUS. */
  public static final String PRODUCT_STATUS = "ProductStatus.json";

  /** The Constant PRODUCT_STATUS_SETUP. */
  public static final String PRODUCT_STATUS_SETUP = "ProductStatusSetup.json";

  /** The Constant STATUS. */
  public static final String STATUS = "status";

  /** The Constant PRODUCT_TRANSITION_STATUS. */
  public static final String PRODUCT_TRANSITION_STATUS = "c875be88-45e3-48dd-b494-a598fbddb2d0";

  /** The Constant PRODUCT_STATE_TRANSITION_RESPONSE. */
  public static final String PRODUCT_STATE_TRANSITION_RESPONSE = "ProductStateTransitionResponse.json";

  /** The Constant reason. */
  public static final String REASON = "reason";

  /** The Constant reasonCode. */
  public static final String REASON_CODE = "reasonCode";

  /** The Constant reasonCode. */
  public static final String LIVE = "LIVE";

  /** The Constant reasonCode. */
  public static final String REVIEW = "REVIEW";

  /** The Constant EMPTY. */
  public static final String EMPTY = "";

  /** The Constant REASON FOR TRANSITION. */
  public static final String REASON_FOR_TRANSITION = "Title Live after review";

  /** The Constant REASON FOR TRANSITION. */
  public static final String CODE_OF_REASON = "157";

  /** The Constant LAST_MODIFIED. */
  public static final String LAST_MODIFIED = "2018-05-18T19:16:15+00:00";

  /** The Constant STATE_TRANSITION_PAYLOAD_JSON. */
  public static final String STATE_TRANSITION_PAYLOAD_JSON = "StateTransitionPayload.json";

  /** The Constant STATUS_LINK. */
  public static final String STATUS_LINK = "/v2/products/ea13b152-fe9d-4cca-87b4-e16cb658a2d4/status";

  /** The Constant LATEST_DOCUMENT_ID. */
  public static final String LATEST_DOCUMENT_ID = "PRODUCT::LATEST::6ed571e9-febd-497f-b384-d88a979f456d::%";

  /** The Constant PRODUCT_DOCUMENT_ID. */
  public static final String PRODUCT_DOCUMENT_ID = "PRODUCT::6ed571e9-febd-497f-b384-d88a979f456d::810a3768-17af-4f2f-9d4c-b07c6cdfc672";

  /** The Constant PRODUCT_DOCUMENT__VERSION_ID. */
  public static final String PRODUCT_DOCUMENT_VERSION_ID = "PRODUCT::6ed571e9-febd-497f-b384-d88a979f456d%";

  /** The Constant PRODUCT_DOCUMENT__VERSION_ID. */
  public static final String INSTRUCTION_DOCUMENT_INVALID__DOCTYPE = "InstructionPostInvalidDocType.json";

  /** The Constant PRODUCT_DOCUMENT__VERSION_ID. */
  public static final String INSTRUCTION_DOCUMENT_INVALID__ASSETTYPE = "InstructionPostInvalidAssetType.json";

  /** The Constant GET_ASSESSMENT_ROUTE. */
  public static final String GET_ASSESSMENT_ROUTE = "/v2/assessments/";

  /** The constant ASSESSMENT_ID. */
  public static final String ASSESSMENT_ID = "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f";

  /** The constant INSTRUCTION. */
  public static final String INSTRUCTION = "INSTRUCTION";

  /** The Constant GET_LEARNINGAPPS_ROUTE. */
  public static final String GET_LEARNINGAPPS_ROUTE = "/v2/learningApps/";

  /** The Constant LEARNINGAPP_ID. */
  public static final String LEARNINGAPP_ID = "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f";

  /** The Constant LEARNINGAPP_VER. */
  public static final String LEARNINGAPP_VER = "810a3768-17af-4f2f-9d4c-b07c6cdfc670";

  /** The Constant PRODUCT_POLICY. */
  public static final String PRODUCT_POLICY = "Revel_Default_46d14271-baa9-4b51-9847-6de209a2e5cf::6dfcdcba-f8e3-4e8f-9a1d-e127b8b116da";

  /** The Constant INVALID_PARAM_VALUE. */
  public static final Optional<String> INVALID_PARAM_VALUE = Optional.of("config");

  /** The Constant COMPOSE. */
  public static final String COMPOSE = "COMPOSE";

  /** The Constant INVALID_UUID. */
  public static final String INVALID_UUID = "6ed571zzzzz";

  /** The Constant PRODUCT_STATUS_REQUEST. */
  public static final String PRODUCT_STATUS_REQUEST = "ProductStatusRequest.json";

  /** The Constant OLD_PRODUCT_STATUS. */
  public static final String OLD_PRODUCT_STATUS = "OldProductStatus.json";

  /** The Constant STATUS_URL. */
  public static final String STATUS_URL = "/status";

  /** The Constant PRODUCT_GET_ASSET_TYPE_RESONSE. */
  public static final String PRODUCT_GET_ASSET_TYPE_RESONSE = "ProductGetAssetTypesResponse.json";

  /** The Constant ASSETCLASSTYPES. */
  public static final String ASSETCLASSTYPES = "ASSETCLASSTYPES";

  /** The Constant PRODUCT_STATUS_REVIEW_JSON. */
  public static final String PRODUCT_STATUS_REVIEW_JSON = "ProductStatusReview.json";

  /** The Constant PRODUCT_INDEX_JSON. */
  public static final String PRODUCT_INDEX_JSON = "ProductIndex.json";

  /** The Constant PRODUCT_NARRATIVE_JSON. */
  public static final String PRODUCT_NARRATIVE_JSON = "ProductNarrative.json";

  /** The Constant PRODUCT_ASSESSMENT_ITEM_JSON. */
  public static final String PRODUCT_ASSESSMENT_ITEM_JSON = "ProductAssessmentItem.json";

  /** The Constant PRODUCT_INSTRCUTION_JSON. */
  public static final String PRODUCT_INSTRCUTION_JSON = "ProductInstruction.json";

  /** The Constant PRODUCT_ASSESSMENT_JSON. */
  public static final String PRODUCT_ASSESSMENT_JSON = "ProductAssessment.json";

  /** The Constant GET_PRODUCT_ASSET_TYPES_JSON. */
  public static final String GET_PRODUCT_ASSET_TYPES_JSON = "ProductGetAssetTypesResponse.json";

  /** The Constant AGGREGATE. */
  public static final String AGGREGATE = "AGGREGATE";

  /** The Constant _STATUS. */
  public static final String _STATUS = "_status";

  /** The Constant QUESTION_MARK. */
  public static final String QUESTION_MARK = "?";

  /** The Constant PERECENT_SIGN. */
  public static final String PERECENT_SIGN = "%";

  /** The Constant FOUR. */
  public static final int FOUR = 4;

  /** The Constant TEN. */
  public static final int TEN = 10;

  /** The Constant Default POLICY_GROUPS. */
  public static final String DEFAULT_POLICY_GROUPS = "REVEL_DEFAULT";

  /** The constant EMBEDDED_ASSETS_POST_REQUEST. */
  public static final String EMBEDDED_ASSETS_POST_REQUEST = "EmbeddedAssetPostRequest.json";

  /** The constant EMBEDDED_ASSET_POST_RESPONSE. */
  public static final String EMBEDDED_ASSETS_POST_RESPONSE = "EmbeddedAssetPostResponse.json";

  /** The constant EMBEDDED_ASSETS_ROUTE. */
  public static final String EMBEDDED_ASSETS_ROUTE = "/v2/embeddedAssets/";

  /** The Constant ASSESSMENT_BY_ID_JSON_RESPONSE. */
  public static final String ASSESSMENT_BY_ID_JSON_RESPONSE = "AssessmentsById.json";

}
