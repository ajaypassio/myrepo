/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.event.listener;

import java.time.LocalDateTime;
import java.util.UUID;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.event.request.EventPayload;
import com.pearson.glp.lpb.dto.event.request.AutobahnEvent;
import com.pearson.glp.lpb.dto.event.request.AutobahnEventModel;
import com.pearson.glp.lpb.dto.event.request.AutobahnPayLoad;
import com.pearson.glp.lpb.services.impl.ProductScannerServiceImpl;
import com.pearson.glp.lpb.services.impl.ProductServiceImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_EVENT_JSON;
import com.google.gson.Gson;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerContext;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerVoidResponse;
import com.pearson.glp.crosscutting.isc.client.commons.CrosscuttingEvent;
import com.pearson.glp.crosscutting.isc.client.commons.Event;
import com.pearson.glp.crosscutting.isc.client.commons.validation.BeanValidator;
import com.pearson.glp.lpb.constant.Events;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class ProductComposeEventListenerTest.
 */
public class ProductEventListenerTest implements CommonUtils {/*

  *//** The product compose event listener. *//*
  @InjectMocks
  private ProductEventListener productEventListener;

  *//** The product service impl. *//*
  @Mock
  private ProductServiceImpl productService;

  *//** The product scanning service impl. *//*
  @Mock
  private ProductScannerServiceImpl productScannerService;

  *//** The mapper. *//*
  @Mock
  private ObjectMapper mapper;

  *//** The Event ev. *//*
  protected Event ev = new Event() {

    @Override
    public String getTimestamp() {
      return LocalDateTime.now().toString();
    }

    @Override
    public String getPayload() {
      return new Gson().toJson(convertJsonToObject(PRODUCT_EVENT_JSON, EventPayload.class));
    }

    @Override
    public String getEventName() {
      return Events.PRODUCT_PROMOTED_TO_COMPOSE;
    }

    @Override
    public String getEventId() {
      return UUID.randomUUID().toString();
    }

    @Override
    public CrosscuttingEvent getCrosscuttingEvent() {
      return null;
    }
  };

  *//**
   * Instantiates a new product compose event listener test.
   *//*
  public ProductEventListenerTest() {
    super();
  }

  *//**
   * Setup.
   *//*
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    BeanValidator beanValidator = new BeanValidator();
    ReflectionTestUtils.setField(BeanValidator.class, "staticLink", beanValidator);
  }

  *//**
   * Product Compose Service Handler With Available PMP Message.
   *//*
  @Test
  public void testProductComposeServiceHandler() {

    Mockito.when(productService.checkPMPMessage(Mockito.any()))
        .thenReturn(Mono.just(getPMPMessage()));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener
        .productComposeServiceHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * Product Compose Service Handler PMP Not Available.
   *//*
  @Test
  public void testProductComposeServiceHandlerPMPNotAvailable() {

    Mockito.when(productService.checkPMPMessage(Mockito.any())).thenReturn(Mono.empty());

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener
        .productComposeServiceHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * Product Compose Service Handler With Error.
   *//*
  @Test
  public void testProductComposeServiceHandlerError() {

    Mockito.when(productService.checkPMPMessage(Mockito.any()))
        .thenReturn(Mono.error(new ServiceException(PRODUCT_JSON)));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener
        .productComposeServiceHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * PMP Message Handler.
   *//*
  @Test
  public void testPMPMessageHandler() {

    NonPrimitiveAsset nonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);

    Mockito.when(productService.savePMPMessage(Mockito.any()))
        .thenReturn(Mono.just(nonPrimitiveAsset));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener.pmpMessageHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * PMP Message Handler Product Not Available.
   *//*
  @Test
  public void testPMPMessageHandlerProductNotAvailable() {

    Mockito.when(productService.savePMPMessage(Mockito.any())).thenReturn(Mono.empty());

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener.pmpMessageHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * PMP Message Handler With Error.
   *//*
  @Test
  public void testPMPMessageHandlerError() {

    Mockito.when(productService.savePMPMessage(Mockito.any()))
        .thenReturn(Mono.error(new ServiceException(PRODUCT_JSON)));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener.pmpMessageHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * Product Setup Service Handler.
   *//*
  @Test
  public void testProductSetupServiceHandler() {

    Mockito.when(productScannerService.scanProduct(Mockito.any())).thenReturn(Mono.just(true));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener.productSetupServiceHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * Product Setup Service Handler Scanning Fail.
   *//*
  @Test
  public void testProductSetupServiceHandlerScanningFail() {

    Mockito.when(productScannerService.scanProduct(Mockito.any())).thenReturn(Mono.just(false));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener.productSetupServiceHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * Product Setup Service Handler Scanning Fail.
   *//*
  @Test
  public void testProductSetupServiceHandlerScanningError() {

    Mockito.when(productScannerService.scanProduct(Mockito.any()))
        .thenReturn(Mono.error(new ServiceException(PRODUCT_JSON)));

    IscServiceHandlerContext isc = new IscServiceHandlerContext(ev);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener.productSetupServiceHandler(isc);

    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  *//**
   * Generate the PMP Message
   *
   * @return
   *//*
  private AutobahnEventModel getPMPMessage() {
    AutobahnEventModel pmpMessage = new AutobahnEventModel();
    AutobahnEvent autobahnEvent = new AutobahnEvent();
    AutobahnPayLoad autobahnPayLoad = new AutobahnPayLoad();
    pmpMessage.setAutobahnEvent(autobahnEvent);
    autobahnEvent.setPayload(autobahnPayLoad);
    autobahnPayLoad.setContentUrn(UUID.randomUUID().toString());
    autobahnPayLoad.setVersionUrn(UUID.randomUUID().toString());
    autobahnPayLoad.setProductId(UUID.randomUUID().toString());
    autobahnPayLoad.setProductPlatformCode(UUID.randomUUID().toString());
    return pmpMessage;
  }
*/}