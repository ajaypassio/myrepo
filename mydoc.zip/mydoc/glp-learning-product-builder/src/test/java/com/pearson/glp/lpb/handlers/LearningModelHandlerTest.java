/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.CommonConstants.CMS;
import static com.pearson.glp.lpb.constant.CommonConstants.CONFIGURATION;
import static com.pearson.glp.lpb.constant.CommonConstants.DATE_FORMAT_JSON;
import static com.pearson.glp.lpb.constant.CommonConstants.FIELDS;
import static com.pearson.glp.lpb.constant.CommonConstants.SCHEMA_VALIDATION_ERROR;
import static com.pearson.glp.lpb.constant.CommonConstants.SOURCE;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_CREATED_BY;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_EXPIRES_ON;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static com.pearson.glp.lpb.utils.DateUtil.currentTimestamp;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.utils.exception.PlatformException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.dto.response.AssetModelResponse;
import com.pearson.glp.lpb.dto.response.LearningModelResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.dto.response.ProductModelResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.services.LearningModelService;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class AssetModelHandlerTest.
 *
 * @author sourabh.aggarwal
 */
public class LearningModelHandlerTest {

  /** The asset model handler. */
  @InjectMocks
  private LearningModelHandler learningModelHandler;

  /** The service handler context. */
  @Mock
  private ServiceHandlerContext serviceHandlerContext;

  /** The asset model service. */
  @Mock
  private LearningModelService assetModelService;

  /** The asset model payload. */
  private AssetModelPayload assetModelPayload;

  private String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";

  private String versionId = "a9b9ae2b-966c-4a66-a6ab-134d685cb99b";

  /**
   * Instantiates a new asset model handler test.
   */
  public LearningModelHandlerTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
    this.assetModelPayload = createAssetPayload();
    Mockito.when(serviceHandlerContext.getPayload(AssetModelPayload.class))
        .thenReturn(Mono.just(assetModelPayload));
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.ID)).thenReturn(assetModelId);
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.VER)).thenReturn(versionId);
    Mockito.when(serviceHandlerContext.getAllParameters())
        .thenReturn(Mockito.mock(MultiValueMap.class));
  }

  /**
   * Test get all asset models.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAssetModels() throws ServiceException {
    // Given
    List<AssetModelResponse> assetModelList = getAssetModels(4, null, false);
    Mockito.when(assetModelService.findLearningModels(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelList));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModels(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyLearningModelResponse(assetModelList, response);
  }

  /**
   * Test get all asset models with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAssetModelsWithException() throws ServiceException {
    // Given
    Mockito.when(assetModelService.findLearningModels(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModels(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyInternalServerErrorResponse(response);
  }

  /**
   * Test create asset models.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModels() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(null, false);
    Mockito.when(assetModelService.createAssetModels(Mockito.any(AssetModelPayload.class)))
        .thenReturn(Mono.just(assetModel));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModels(serviceHandlerContext);

    // Then
    verifyCreatedResponse(assetModel, response);
  }

  /**
   * Test get asset model by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelById() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(assetModelId, true);
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(assetModel));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModelById(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.OK.value(), obj.getStatus());
      assertNotNull(obj.getPayload(AssetModelResponse.class));
      StepVerifier.create(obj.getPayload(AssetModelResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(assetModel.get_assetType(), resp.get_assetType());
        assertEquals(assetModel.getLabel(), resp.getLabel());
        assertEquals(assetModel.getTags(), resp.getTags());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Test get asset model by id with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelByIdWithException() throws ServiceException {
    // Given
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModelById(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyObjectNotFoundResponse(response);
  }

  /**
   * Test get asset model by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelByVersionId() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(assetModelId, true);
    assetModel.set_ver(versionId);
    Mockito
        .when(
            assetModelService.findVersionById(assetModelId, versionId, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(assetModel));
    ProductConfigurationResponse configurationResponse = new ProductConfigurationResponse();
    configurationResponse.setId(assetModelId);
    configurationResponse.setVer(versionId);
    Configuration configuration = new Configuration();
    configurationResponse.setConfiguration(configuration);
    Mockito.when(assetModelService.fetchProductModelConfiguration(assetModelId, versionId))
        .thenReturn(Mono.just(configurationResponse));
    Mockito.when(serviceHandlerContext.getOptionalParameter(FIELDS))
        .thenReturn(Optional.of(CONFIGURATION));
    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModelByVersionId(serviceHandlerContext, AssetType.AGGREGATE);
    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.OK.value(), obj.getStatus());
      assertNotNull(obj.getPayload(AssetModelResponse.class));
      StepVerifier.create(obj.getPayload(AssetModelResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(assetModelId, resp.get_id());
        assertEquals(versionId, resp.get_ver());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  @Test
  public void testGetAssetModelByVersionIdNotFound() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(assetModelId, true);
    assetModel.set_ver(versionId);
    Mockito
        .when(
            assetModelService.findVersionById(assetModelId, versionId, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(assetModel));
    Mockito.when(serviceHandlerContext.getOptionalParameter(FIELDS))
        .thenReturn(Optional.of(CommonConstants.POLICY_GROUPS));
    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModelByVersionId(serviceHandlerContext, AssetType.AGGREGATE);
    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.NOT_FOUND.value(), obj.getStatus());
      assertNotNull(obj.getPayload(AssetModelResponse.class));
      StepVerifier.create(obj.getPayload(AssetModelResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * Test get asset model by version id with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelByVersionIdWithException() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(assetModelId, true);
    assetModel.set_ver(versionId);
    Mockito
        .when(
            assetModelService.findVersionById(assetModelId, versionId, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModelByVersionId(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyObjectNotFoundResponse(response);
  }

  /**
   * Test get asset models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelsVersions() throws ServiceException {
    // Given
    List<AssetModelResponse> assetModelList = getAssetModels(2, assetModelId, true);
    Mockito.when(assetModelService.findAllVersionsById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(assetModelList));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyLearningModelResponse(assetModelList, response);
  }

  /**
   * Test create asset models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModelsVersions() throws ServiceException {
    // Given
    Mono<AssetModelResponse> assetModelList = Mono.just(createAssetModel(assetModelId, true));
    AssetModelResponse expectedResponse = createAssetModel(assetModelId, true);
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(assetModelList);
    Mockito
        .when(
            assetModelService.createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(expectedResponse));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyCreatedResponse(expectedResponse, response);
  }

  /**
   * Test create asset models versions with invalid id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModelsVersionsWithInvalidId() throws ServiceException {
    // Given
    Mono<AssetModelResponse> assetModelList = Mono.just(createAssetModel(assetModelId, true));
    AssetModelResponse expectedResponse = createAssetModel(assetModelId, true);
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(assetModelList);
    Mockito
        .when(
            assetModelService.createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(expectedResponse));
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.ID)).thenReturn("jbjfhbsakf");
    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyObjectNotFoundResponse(response);
  }

  /**
   * Test create asset models versions with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModelsVersionsWithExceptionNotFound() throws ServiceException {
    // Given
    Mockito
        .when(
            assetModelService.createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyObjectNotFoundResponse(response);
  }

  /**
   * Test create asset models versions with exception internal error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModelsVersionsWithExceptionInternalError() throws ServiceException {
    // Given
    Mockito.when(assetModelService.createAssetModelVersion(Mockito.any(), Mockito.anyString(),
        Mockito.anyString())).thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyInternalServerErrorResponse(response);
  }

  /**
   * verify create asset models schema validation fail scenario.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateLearningModelsSchemaValidationFail() throws ServiceException {
    // Given
    Mockito.doReturn(Mono.error(createSchemaValidationFailResponse())).when(assetModelService)
        .createAssetModels(Mockito.any());

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModels(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.BAD_REQUEST.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.INVALID_REQUEST.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * verify create asset models schema validation fail scenario.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateLearningModelsPlatformErrorResponse() throws ServiceException {
    // Given
    Mockito.doReturn(Mono.error(createPlatformErrorResponse())).when(assetModelService)
        .createAssetModels(Mockito.any());

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModels(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * verify create asset models versions, schema validation fail scenario.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateLearningModelsVersionsSchemaValidationFail() throws ServiceException {
    // Given
    Mockito.doReturn(Mono.error(createSchemaValidationFailResponse())).when(assetModelService)
        .createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any());

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.BAD_REQUEST.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.INVALID_REQUEST.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * create schemavalidation fail response
   *
   * @return platformexception
   */
  private PlatformException createSchemaValidationFailResponse() {
    com.pearson.glp.core.errors.PlatformError platformError = new com.pearson.glp.core.errors.PlatformError(
        PlatformErrorCode.INVALID_REQUEST.getValue(),
        PlatformErrorCode.INVALID_REQUEST.getErrorCode(), SCHEMA_VALIDATION_ERROR);
    return new PlatformException(HttpStatus.BAD_REQUEST.value(), platformError);
  }

  /**
   * create schemavalidation fail response
   *
   * @return platformexception
   */
  private PlatformException createPlatformErrorResponse() {
    com.pearson.glp.core.errors.PlatformError platformError = new com.pearson.glp.core.errors.PlatformError(
        PlatformErrorCode.INTERNAL_SERVER_ERROR.getValue(),
        PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(),
        HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    return new PlatformException(HttpStatus.INTERNAL_SERVER_ERROR.value(), platformError);
  }

  /**
   * Verify created response.
   *
   * @param assetModel
   *          the asset model
   * @param response
   *          the response
   */
  private void verifyCreatedResponse(AssetModelResponse assetModel,
      Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.CREATED.value(), obj.getStatus());
      assertNotNull(obj.getPayload(AssetModelResponse.class));
      StepVerifier.create(obj.getPayload(AssetModelResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(assetModel.get_assetType(), resp.get_assetType());
        assertEquals(assetModel.getLabel(), resp.getLabel());
        assertEquals(assetModel.getTags(), resp.getTags());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Verify asset model response.
   *
   * @param assetModelList
   *          the asset model list
   * @param response
   *          the response
   */
  private void verifyLearningModelResponse(List<AssetModelResponse> assetModelList,
      Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.OK.value(), obj.getStatus());
      assertNotNull(obj.getPayload(LearningModelResponse.class));
      StepVerifier.create(obj.getPayload(LearningModelResponse.class)).assertNext(resp -> {
        assertEquals(assetModelList.size(), resp.getCount().intValue());
        assertNotNull(resp.getAssetModels());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * Verify internal server error.
   *
   * @param response
   *          the response
   */
  private void verifyInternalServerErrorResponse(Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Verify object not found error.
   *
   * @param response
   *          the response
   */
  private void verifyObjectNotFoundResponse(Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.NOT_FOUND.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Gets the asset models.
   *
   * @param noOfAssetModels
   *          the no of asset models
   * @param assetModelId
   *          the asset model id
   * @param isAssetModelId
   *          the is asset model id
   * @return the asset models
   */
  private List<AssetModelResponse> getAssetModels(int noOfAssetModels, String assetModelId,
      boolean isAssetModelId) {
    List<AssetModelResponse> assetModelList = new ArrayList<>();
    for (int i = 0; i < noOfAssetModels; i++) {
      assetModelList.add(createAssetModel(assetModelId, isAssetModelId));
    }
    return assetModelList;
  }

  /**
   * Creates the asset model.
   *
   * @param assetModelId
   *          the asset model id
   * @param isAssetModelId
   *          the is asset model id
   * @return the asset model
   */
  private AssetModelResponse createAssetModel(String assetModelId, boolean isAssetModelId) {
    AssetModelResponse assetModel = new AssetModelResponse();
    assetModel.set_id(isAssetModelId ? assetModelId : UUID.randomUUID().toString());
    assetModel.set_bssVer(1);
    assetModel.set_ver(UUID.randomUUID().toString());
    assetModel.set_created(formatDateTime(currentTimestamp(), DATE_FORMAT_JSON));
    assetModel.set_lastModified(formatDateTime(currentTimestamp(), DATE_FORMAT_JSON));
    assetModel.set_createdBy(ASSET_MODEL_CREATED_BY);
    assetModel.set_docType(DocType.LEARNINGMODEL.value());
    assetModel.set_assetType(AssetType.INSTRUCTION.value());
    assetModel.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModel.setLabel(ASSET_MODEL_LABEL);
    assetModel.setTags(ASSET_MODEL_TAGS);
    return assetModel;
  }

  /**
   * Creates the asset payload.
   *
   * @return the mono
   */
  private AssetModelPayload createAssetPayload() {
    AssetModel assetModel = new AssetModel();
    assetModel.setDocType(DocType.LEARNINGMODEL.value());
    assetModel.setAssetType(AssetType.INSTRUCTION.value());
    assetModel.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModel.setLabel(ASSET_MODEL_LABEL);
    assetModel.setTags(ASSET_MODEL_TAGS);
    return assetModel;
  }

  @Test
  public void testCreateAssetModelsWithHeader() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(null, false);
    Mockito.when(assetModelService.createAssetModels(Mockito.any(AssetModelPayload.class)))
        .thenReturn(Mono.just(assetModel));
    Mockito.when(serviceHandlerContext.getHeader(SOURCE)).thenReturn(Arrays.asList(CMS));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModels(serviceHandlerContext);

    // Then
    verifyCreatedResponse(assetModel, response);
  }

  @Test
  public void testCreateAssetModelsWithInvalidHeader() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(null, false);
    Mockito.when(assetModelService.createAssetModels(Mockito.any(AssetModelPayload.class)))
        .thenReturn(Mono.just(assetModel));
    Mockito.when(serviceHandlerContext.getHeader(SOURCE))
        .thenReturn(Arrays.asList(ASSET_MODEL_LABEL));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModels(serviceHandlerContext);

    // Then
    verifyCreatedResponse(assetModel, response);
  }

  @Test
  public void testCreateAssetModelsWithNoHeader() throws ServiceException {
    // Given
    AssetModelResponse assetModel = createAssetModel(null, false);
    Mockito.when(assetModelService.createAssetModels(Mockito.any(AssetModelPayload.class)))
        .thenReturn(Mono.just(assetModel));
    Mockito.when(serviceHandlerContext.getHeader(SOURCE)).thenReturn(null);

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModels(serviceHandlerContext);

    // Then
    verifyCreatedResponse(assetModel, response);
  }

  @Test
  public void testCreateAssetModelsVersionsWithHeader() throws ServiceException {
    // Given
    Mono<AssetModelResponse> assetModelList = Mono.just(createAssetModel(assetModelId, true));
    AssetModelResponse expectedResponse = createAssetModel(assetModelId, true);
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(assetModelList);
    Mockito
        .when(
            assetModelService.createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(expectedResponse));
    Mockito.when(serviceHandlerContext.getHeader(SOURCE)).thenReturn(Arrays.asList(CMS));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyCreatedResponse(expectedResponse, response);
  }

  @Test
  public void testCreateAssetModelsVersionsWithInvalidHeader() throws ServiceException {
    // Given
    Mono<AssetModelResponse> assetModelList = Mono.just(createAssetModel(assetModelId, true));
    AssetModelResponse expectedResponse = createAssetModel(assetModelId, true);
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(assetModelList);
    Mockito
        .when(
            assetModelService.createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(expectedResponse));
    Mockito.when(serviceHandlerContext.getHeader(SOURCE))
        .thenReturn(Arrays.asList(ASSET_MODEL_LABEL));

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyCreatedResponse(expectedResponse, response);
  }

  @Test
  public void testCreateAssetModelsVersionsWithNoHeader() throws ServiceException {
    // Given
    Mono<AssetModelResponse> assetModelList = Mono.just(createAssetModel(assetModelId, true));
    AssetModelResponse expectedResponse = createAssetModel(assetModelId, true);
    Mockito.when(assetModelService.findAssetModelById(assetModelId, AssetType.AGGREGATE.value()))
        .thenReturn(assetModelList);
    Mockito
        .when(
            assetModelService.createAssetModelVersion(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(expectedResponse));
    Mockito.when(serviceHandlerContext.getHeader(SOURCE)).thenReturn(null);

    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .createLearningModelsVersions(serviceHandlerContext, AssetType.AGGREGATE);

    // Then
    verifyCreatedResponse(expectedResponse, response);
  }

  /**
   * Test get all prodct models with collection details label.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProdctModelsWithCollectionDetailsLabel() throws ServiceException {
    // Given
    List<AssetModelResponse> assetModelList = getAssetModels(TestingConstants.FOUR, null, false);
    Mockito.when(assetModelService.findLearningModels(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelList));
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
    parameters.put(CommonConstants.COLLECTION_DETAILS, Arrays.asList(CommonConstants.LABEL));
    Mockito.when(serviceHandlerContext.getAllParameters()).thenReturn(parameters);
    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModels(serviceHandlerContext, AssetType.PRODUCT);
    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.OK.value(), obj.getStatus());
      assertNotNull(obj.getPayload(ProductModelResponse.class));
      StepVerifier.create(obj.getPayload(ProductModelResponse.class)).assertNext(resp -> {
        assertEquals(assetModelList.size(), resp.getCount().intValue());
        assertNotNull(resp.getProductModels());
      }).expectComplete().verify(Duration.ofMillis(TestingConstants.TEN));
    }).verifyComplete();
  }

  /**
   * Test get all prodct models with invalid collection details.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProdctModelsWithInvalidCollectionDetails() throws ServiceException {
    // Given
    List<AssetModelResponse> assetModelList = getAssetModels(TestingConstants.FOUR, null, false);
    Mockito.when(assetModelService.findLearningModels(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelList));
    MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
    parameters.put(CommonConstants.COLLECTION_DETAILS, Arrays.asList(CommonConstants.LATEST));
    Mockito.when(serviceHandlerContext.getAllParameters()).thenReturn(parameters);
    // When
    Mono<ServiceHandlerResponse> response = learningModelHandler
        .getLearningModels(serviceHandlerContext, AssetType.PRODUCT);
    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST.value(), obj.getStatus());
    }).verifyComplete();
  }

}
