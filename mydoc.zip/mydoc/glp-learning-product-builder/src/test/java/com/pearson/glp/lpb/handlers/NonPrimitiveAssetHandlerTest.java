/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.handlers;

import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_POST_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION_VERSION_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.TestingConstants.PAGE_SIZE;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.request.AssetVersionPayload;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetBulkPayload;
import com.pearson.glp.lpb.dto.response.AssetBulkResponse;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.services.NonPrimitiveAssetService;
import com.pearson.glp.lpb.utils.CommonUtils;
import com.pearson.glp.lpb.utils.PaginationUtil;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class NonPrimitiveAssetHandlerTest.
 *
 * @author sanket.Gupta
 */
public class NonPrimitiveAssetHandlerTest implements CommonUtils {

  /** The nonPrimitiveAssetHandler. */
  @InjectMocks
  private NonPrimitiveAssetHandler nonPrimitiveAssetHandler;

  /** The service handler context. */
  @Mock
  private ServiceHandlerContext serviceHandlerContext;

  /** The PaginationUtil. */
  @Mock
  private PaginationUtil paginationUtil;

  /** The nonPrimitiveAssetService. */
  @Mock
  private NonPrimitiveAssetService nonPrimitiveAssetService;

  /** The String instructionId. */
  private String instructionId = "1484b437-7ed5-4240-a450-2cf40aad9348";

  /** The String instructionVersionId. */
  private String instructionVersionId = "092aca61-c1b3-4e2e-9ba8-51a2201d73b5";

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.ID)).thenReturn(INSTRUCTION_ID,
        AssetType.INSTRUCTION.value());
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.ID)).thenReturn(instructionId);
    Mockito.when(serviceHandlerContext.getParameter(CommonConstants.VER))
        .thenReturn(instructionVersionId);
    Mockito.when(serviceHandlerContext.getOptionalParameter(PAGE_SIZE))
        .thenReturn(Optional.of("2"));
    Mockito.when(serviceHandlerContext.getOptionalParameter(PAGE_NUMBER))
        .thenReturn(Optional.of("2"));
    Mockito.when(serviceHandlerContext.getAllParameters())
        .thenReturn(Mockito.mock(MultiValueMap.class));
    Mockito.when(paginationUtil.getOffset(Mockito.anyString())).thenReturn(2);
    Mockito.when(paginationUtil.getLimit(Mockito.anyString())).thenReturn(2);
  }

  /**
   * Test the Create Instructions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAsset() throws ServiceException {
    // Given
    NonPrimitiveAssetBulkPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_POST_REQUEST, NonPrimitiveAssetBulkPayload.class);

    Mockito.when(serviceHandlerContext.getFluxPayload(NonPrimitiveAssetBulkPayload.class))
        .thenReturn(Flux.just(nonPrimitiveAssetRequest));

    Mockito.when(nonPrimitiveAssetService.createNonPrimitiveAssets(Mockito.any(), Mockito.any()))
        .thenReturn(getFluxAssetResponse(INSTRUCTION_POST_RESPONSE));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssets(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response)
        .assertNext(res -> assertEquals(res.getStatus(), HttpStatus.MULTI_STATUS.value()))
        .verifyComplete();
  }

  /**
   * Test get NonPrimitiveAsset by id positive.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetsByIdPositive() throws ServiceException {
    // Given
    NonPrimitiveAsset instruction = createInstructionResponse(INSTRUCTION_ID);
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(instruction));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetById(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.OK.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(NonPrimitiveAsset.class));
      StepVerifier.create(instructionObj.getPayload(NonPrimitiveAsset.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(resp.get_id(), instruction.get_id());
        assertEquals(resp.getLabel(), instruction.getLabel());
        assertEquals(resp.getTags(), instruction.getTags());
      }).expectComplete().verify();
    }).verifyComplete();

  }

  /**
   * Test get NonPrimitiveAsset by id negative.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetsByIdNegative() throws ServiceException {
    // Given
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetById(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.NOT_FOUND.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(instructionObj.getPayload(PlatformErrorResponse.class))
          .assertNext(resp -> {
            assertNotNull(resp);
            assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
            assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
          }).expectComplete().verify();
    }).verifyComplete();

  }

  /**
   * Test get NonPrimitiveAsset by id negative with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetsByIdWithException() throws ServiceException {
    // Given
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetById(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    verifyInternalServerErrorResponse(response);

  }

  /**
   * Creates the instruction.
   *
   * @param instructionId
   *          the asset model id
   * @return instruction
   */
  private NonPrimitiveAsset createInstructionResponse(String instructionId) {
    NonPrimitiveAsset instruction = new NonPrimitiveAsset();
    instruction.set_id(instructionId);
    instruction.setVer(INSTRUCTION_VERSION);
    instruction.setCreated(formatDateTime(LocalDateTime.now()).get());
    instruction.setLabel(ASSET_MODEL_LABEL);
    instruction.setTags(ASSET_MODEL_TAGS);
    return instruction;
  }

  /**
   * Generate the Flux of Asset Response.
   *
   * @param jsonPath
   *          the json path
   * @return the flux asset response
   * @throws ServiceException
   *           the service exception
   */
  private Flux<AssetResponse> getFluxAssetResponse(String jsonPath) throws ServiceException {
    AssetResponse assetResponse = convertJsonToObject(jsonPath, AssetResponse.class);
    return Flux.just(assetResponse);
  }

  /**
   * Prepare asset.
   *
   * @return the non primitive asset
   */
  private NonPrimitiveAsset prepareAsset() {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setId(UUID.fromString("d65ecb2a-5f88-469f-8729-a59992621494").toString());
    nonPrimitiveAsset.set_id("d65ecb2a-5f88-469f-8729-a59992621494");
    nonPrimitiveAsset.setBssVer(1);
    return nonPrimitiveAsset;
  }

  /**
   * Gets the creates the instruction version response.
   *
   * @return the creates the instruction version response
   * @throws ServiceException
   *           the service exception
   */
  private AssetResponse getCreateInstructionVersionResponse() throws ServiceException {
    AssetResponse assetResponse = convertJsonToObject(CommonConstants.POST_INSTRUCTIONS_JSON,
        AssetResponse.class);
    return assetResponse;

  }

  /**
   * Test create NonPrimitiveAsset version.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetVersion() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    Mockito.when(serviceHandlerContext.getPayload(AssetVersionPayload.class))
        .thenReturn(Mono.just(nonPrimitiveAssetRequest));

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any()))
        .thenReturn(Mono.just(prepareAsset()));
    Mockito
        .when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(getCreateInstructionVersionResponse()));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    verifyCreatedResponse(getCreateInstructionVersionResponse(), response);
  }

  /**
   * Test create non primitive asset version 4 XX error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetVersion4XXError() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = new AssetVersionPayload();
    Mockito.when(serviceHandlerContext.getPayload(AssetVersionPayload.class))
        .thenReturn(Mono.just(nonPrimitiveAssetRequest));

    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST, obj.getStatus());
      assertNotNull(obj.getErrors());
    });
  }

  /**
   * Testcreate assets 4 XX error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testcreateAssets4XXError() throws ServiceException {
    // Given
    NonPrimitiveAssetBulkPayload nonPrimitiveAssetRequest = new NonPrimitiveAssetBulkPayload();

    Mockito.when(serviceHandlerContext.getFluxPayload(NonPrimitiveAssetBulkPayload.class))
        .thenReturn(Flux.just(nonPrimitiveAssetRequest));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssets(serviceHandlerContext, AssetType.INSTRUCTION);
    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST, obj.getStatus());
    });
  }

  /**
   * Test create NonPrimitiveAsset version with exception not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetVersionWithExceptionBadRequest() throws ServiceException {
    // Given
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    Mockito.when(serviceHandlerContext.getPayload(AssetVersionPayload.class))
        .thenReturn(Mono.just(nonPrimitiveAssetRequest));

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());
    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));
    Mockito.when(serviceHandlerContext.getAllParameters().getFirst(CommonConstants.PAGE_SIZE))
        .thenReturn(PAGE_SIZE);
    Mockito.when(serviceHandlerContext.getAllParameters().getFirst(CommonConstants.PAGE_NUMBER))
        .thenReturn(PAGE_NUMBER);
    Mockito.when(paginationUtil.validatePagination(Mockito.anyString(), Mockito.anyString()))
        .thenReturn("");
    Mockito.when(paginationUtil.preparePageSize(Mockito.anyString())).thenReturn("2");
    Mockito.when(paginationUtil.preparePageNumber(Mockito.anyString())).thenReturn("2");

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    verifyObjectNotFoundResponse(response);
  }

  /**
   * Test create NonPrimitiveAsset version with model validation error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetVersionWithModelValidationError() throws ServiceException {
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    Mockito.when(serviceHandlerContext.getPayload(AssetVersionPayload.class))
        .thenReturn(Mono.just(nonPrimitiveAssetRequest));

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any()))
        .thenReturn(Mono.just(prepareAsset()));
    AssetResponse validationResponse = new AssetResponse();
    validationResponse.setError(new PlatformErrorResponse(HttpStatus.BAD_REQUEST.value(),
        PlatformErrorCode.INVALID_REQUEST.getErrorCode(), "", CommonUtils.getTimeStamp(), null));
    Mockito.when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(validationResponse));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST.value(), obj.getStatus());
      assertNotNull(obj.getPayload(AssetResponse.class));
      StepVerifier.create(obj.getPayload(AssetResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.BAD_REQUEST.value(), resp.getError().getStatus().intValue());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Test create NonPrimitiveAsset version with exception internal error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNonPrimitiveAssetVersionWithExceptionInternalError()
      throws ServiceException {
    AssetVersionPayload nonPrimitiveAssetRequest = convertJsonToObject(
        INSTRUCTION_VERSION_POST_REQUEST, AssetVersionPayload.class);
    Mockito.when(serviceHandlerContext.getPayload(AssetVersionPayload.class))
        .thenReturn(Mono.just(nonPrimitiveAssetRequest));

    Mockito.when(nonPrimitiveAssetService.findById(Mockito.any()))
        .thenReturn(Mono.just(prepareAsset()));
    Mockito.when(nonPrimitiveAssetService.createAssetVersion(Mockito.any(), Mockito.anyString(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .createAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    verifyInternalServerErrorResponse(response);
  }

  /**
   * Verify internal server error response.
   *
   * @param response
   *          the response
   */
  private void verifyInternalServerErrorResponse(Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.INTERNAL_SERVER_ERROR.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Verify created response.
   *
   * @param assetResponse
   *          the asset response
   * @param response
   *          the response
   */
  private void verifyCreatedResponse(AssetResponse assetResponse,
      Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.CREATED.value(), obj.getStatus());
      assertNotNull(obj.getPayload(AssetResponse.class));
      StepVerifier.create(obj.getPayload(AssetResponse.class)).assertNext(resp -> {
        assertNotNull(resp.getContentMetadata());
        assertNotNull(resp.getAsset());
        assertEquals(assetResponse.getAsset().getAssetType(), resp.getAsset().getAssetType());
        assertEquals(assetResponse.getAsset().getDocType(), resp.getAsset().getDocType());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Verify object not found response.
   *
   * @param response
   *          the response
   */
  private void verifyObjectNotFoundResponse(Mono<ServiceHandlerResponse> response) {
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.NOT_FOUND.value(), obj.getStatus());
      assertNotNull(obj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(obj.getPayload(PlatformErrorResponse.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
        assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Test get instruction by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetByVersionId() throws ServiceException {
    // Given
    NonPrimitiveAsset nonPrimitive = createInstructionModel(instructionId, true);
    nonPrimitive.setVer(instructionVersionId);
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.just(nonPrimitive));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetByAssetIdAndVersionId(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.OK.value(), obj.getStatus());
      assertNotNull(obj.getPayload(NonPrimitiveAsset.class));
      StepVerifier.create(obj.getPayload(NonPrimitiveAsset.class)).assertNext(resp -> {
        assertNotNull(resp);
        assertEquals(instructionId, resp.get_id());
        assertEquals(instructionVersionId, resp.getVer());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * Test get instruction by version id with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetByVersionIdWithException() throws ServiceException {
    // Given
    NonPrimitiveAsset nonPrimitive = createInstructionModel(instructionId, true);
    nonPrimitive.setVer(instructionId);
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString())).thenReturn(Mono.empty());

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetByAssetIdAndVersionId(serviceHandlerContext, AssetType.INSTRUCTION);

    verifyObjectNotFoundResponse(response);
  }

  /**
   * Test get non primitive asset by version id with internal server exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetByVersionIdWithInternalServerException()
      throws ServiceException {
    // Given
    Mockito.when(nonPrimitiveAssetService.findById(Mockito.anyString()))
        .thenReturn(Mono.error(new Exception()));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetByAssetIdAndVersionId(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    verifyInternalServerErrorResponse(response);
  }

  /**
   * Creates the instruction model.
   *
   * @param instructionId
   *          the instruction id
   * @param isInstructionId
   *          the is instruction id
   * @return the non primitive asset
   */
  private NonPrimitiveAsset createInstructionModel(String instructionId, boolean isInstructionId) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.set_id(isInstructionId ? instructionId : UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(TestingConstants.BASE_VERSION);
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    nonPrimitiveAsset.setLabel(TestingConstants.ASSET_MODEL_LABEL);
    nonPrimitiveAsset.setTags(TestingConstants.ASSET_MODEL_TAGS);
    return nonPrimitiveAsset;
  }

  /**
   * Test get NonPrimitiveAsset versions positive.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetsVersionsPositive() throws ServiceException {
    // Given
    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));
    AssetBulkResponse instruction = assetBulkModelResponse();
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 2, 2, 1))
        .thenReturn(Mono.just(instruction));

    Mockito.when(serviceHandlerContext.getAllParameters().getFirst(CommonConstants.PAGE_SIZE))
        .thenReturn("2");
    Mockito.when(serviceHandlerContext.getAllParameters().getFirst(CommonConstants.PAGE_NUMBER))
        .thenReturn("2");
    Mockito.when(paginationUtil.validatePagination(Mockito.anyString(), Mockito.anyString()))
        .thenReturn("");
    Mockito.when(paginationUtil.preparePageSize(Mockito.anyString())).thenReturn("2");
    Mockito.when(paginationUtil.preparePageNumber(Mockito.anyString())).thenReturn("2");

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAllAssets(serviceHandlerContext, AssetType.INSTRUCTION);

    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.OK.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(AssetBulkResponse.class));
      StepVerifier.create(instructionObj.getPayload(AssetBulkResponse.class)).assertNext(resp -> {
        log.info("instruction response {}", instruction);
        assertNotNull(resp);
        assertEquals(resp.getCount(), instruction.getCount());
        assertEquals(resp.getAssets(), instruction.getAssets());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Test get NonPrimitiveAsset versions negative.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetsVersionsNegative() throws ServiceException {
    // Given
    Mockito.when(nonPrimitiveAssetService
        .findAllAssetsWithLatestVersion(AssetType.INSTRUCTION.value(), 2, 2, 1))
        .thenReturn(Mono.empty());

    Mockito
        .when(nonPrimitiveAssetService.countLatestAssetsByAssetType(AssetType.INSTRUCTION.value()))
        .thenReturn(Mono.just(1));

    Mockito.when(serviceHandlerContext.getAllParameters().getFirst(CommonConstants.PAGE_SIZE))
        .thenReturn(PAGE_SIZE);
    Mockito.when(serviceHandlerContext.getAllParameters().getFirst(CommonConstants.PAGE_NUMBER))
        .thenReturn(PAGE_NUMBER);
    Mockito.when(paginationUtil.validatePagination(Mockito.anyString(), Mockito.anyString()))
        .thenReturn("");
    Mockito.when(paginationUtil.preparePageSize(Mockito.anyString())).thenReturn("2");
    Mockito.when(paginationUtil.preparePageNumber(Mockito.anyString())).thenReturn("2");

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAllAssets(serviceHandlerContext, AssetType.INSTRUCTION);
    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.NOT_FOUND.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(instructionObj.getPayload(PlatformErrorResponse.class))
          .assertNext(resp -> {
            assertNotNull(resp);
            assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
            assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
          }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();

  }

  /**
   * Creates the instruction response for latest version.
   *
   * @return the asset bulk response
   */
  private AssetBulkResponse assetBulkModelResponse() {
    AssetBulkResponse assetBulkResponse = new AssetBulkResponse();
    assetBulkResponse.setCount(1);
    Asset instruction = new Asset();
    instruction.set_id("1484b437-7ed5-4240-a450-2cf40aad9348");
    instruction.setVer("092aca61-c1b3-4e2e-9ba8-51a2201d73b5");
    instruction.setBssVer(1);
    instruction.setDocType(com.pearson.glp.lpb.enums.DocType.LEARNINGCONTENT.value());
    Link link = new Link();
    link.setHref(
        "/v2/instructions/1484b437-7ed5-4240-a450-2cf40aad9348/versions/092aca61-c1b3-4e2e-9ba8-51a2201d73b5");
    instruction.addLinks("self", link);
    List<Asset> list = new ArrayList<>();
    list.add(instruction);
    assetBulkResponse.setAssets(list);
    return assetBulkResponse;
  }

  /**
   * Test get NonPrimitiveAsset versions positive.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllNonPrimitiveAssetVersionsPositive() throws ServiceException {
    // Given
    AssetVersionsResponse instruction = createInstructionResponseForAlltVersions();
    Mockito
        .when(nonPrimitiveAssetService.findAllAssetVersions(instructionId, AssetType.INSTRUCTION))
        .thenReturn(Mono.just(instruction));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);
    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.OK.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(AssetBulkResponse.class));
      StepVerifier.create(instructionObj.getPayload(AssetBulkResponse.class)).assertNext(resp -> {
        log.info(instruction + "");
        assertNotNull(resp);
        assertEquals(resp.getCount(), instruction.getCount());
        assertEquals(resp.getAssets(), instruction.getVersions());
      }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * Test get NonPrimitiveAsset versions Not Found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllNonPrimitiveAssetVersionsNotFound() throws ServiceException {
    // Given
    AssetVersionsResponse assetVersionsResponse = new AssetVersionsResponse();
    assetVersionsResponse.setCount(0);
    Mockito
        .when(nonPrimitiveAssetService.findAllAssetVersions(instructionId, AssetType.INSTRUCTION))
        .thenReturn(Mono.just(assetVersionsResponse));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);
    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.NOT_FOUND.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(instructionObj.getPayload(PlatformErrorResponse.class))
          .assertNext(resp -> {
            assertNotNull(resp);
            assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
            assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
          }).expectComplete();
    }).verifyComplete();
  }

  /**
   * Test get NonPrimitiveAsset versions negative.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetNonPrimitiveAssetVersionsNegative() throws ServiceException {
    // Given
    Mockito
        .when(nonPrimitiveAssetService.findAllAssetVersions(instructionId, AssetType.INSTRUCTION))
        .thenReturn(Mono.empty());
    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssetVersions(serviceHandlerContext, AssetType.INSTRUCTION);
    // Then
    StepVerifier.create(response).assertNext(instructionObj -> {
      assertNotNull(instructionObj);
      assertEquals(HttpStatus.NOT_FOUND.value(), instructionObj.getStatus());
      assertNotNull(instructionObj.getPayload(PlatformErrorResponse.class));
      StepVerifier.create(instructionObj.getPayload(PlatformErrorResponse.class))
          .assertNext(resp -> {
            assertNotNull(resp);
            assertEquals(HttpStatus.NOT_FOUND.value(), resp.getStatus().intValue());
            assertEquals(PlatformErrorCode.OBJECT_NOT_FOUND.getErrorCode(), resp.getError());
          }).expectComplete().verify(Duration.ofMillis(10));
    }).verifyComplete();
  }

  /**
   * Creates the instruction response for latest version.
   *
   * @return the asset bulk response
   */
  private AssetVersionsResponse createInstructionResponseForAlltVersions() {
    AssetVersionsResponse assetVersionResponse = new AssetVersionsResponse();
    assetVersionResponse.setCount(1);
    Asset instruction = new Asset();
    instruction.set_id(instructionId);
    instruction.setVer("092aca61-c1b3-4e2e-9ba8-51a2201d73b5");
    instruction.setBssVer(1);
    instruction.setDocType(com.pearson.glp.lpb.enums.DocType.LEARNINGCONTENT.value());
    Link link = new Link();
    link.setHref(
        "/v2/instructions/1484b437-7ed5-4240-a450-2cf40aad9348/versions/092aca61-c1b3-4e2e-9ba8-51a2201d73b5");
    instruction.addLinks("self", link);
    return assetVersionResponse;
  }

  /**
   * Test get assessments.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssessments() throws ServiceException {

    Mockito.when(serviceHandlerContext.getAllParameters()).thenReturn(new LinkedMultiValueMap<>());

    Mockito.when(nonPrimitiveAssetService.getAllAssessment(Mockito.any()))
        .thenReturn(Mono.just(assetBulkModelResponse()));

    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssessments(serviceHandlerContext);

    // Then
    StepVerifier.create(response).assertNext(object -> {
      assertNotNull(object);
      assertEquals(HttpStatus.OK.value(), object.getStatus());
      assertNotNull(object.getPayload(NonPrimitiveAsset.class));
      StepVerifier.create(object.getPayload(NonPrimitiveAsset.class))
          .assertNext(payload -> assertNotEquals(0, payload)).expectComplete().verify();
    }).verifyComplete();
  }

  /**
   * Test get assessments with invalid parameter.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssessmentsWithInvalidParameter() throws ServiceException {
    LinkedMultiValueMap<String, String> linkedMultiValueMap = new LinkedMultiValueMap<String, String>();
    linkedMultiValueMap.add(TestingConstants.CONTENTMETADATA, TestingConstants.ASSESSMENT_ID);
    Mockito.when(serviceHandlerContext.getAllParameters()).thenReturn(linkedMultiValueMap);
    // When
    Mono<ServiceHandlerResponse> response = nonPrimitiveAssetHandler
        .getAssessments(serviceHandlerContext);
    // Then
    StepVerifier.create(response).assertNext(obj -> {
      assertNotNull(obj);
      assertEquals(HttpStatus.BAD_REQUEST, obj.getStatus());
      assertNotNull(obj.getErrors());
    });
  }

}
