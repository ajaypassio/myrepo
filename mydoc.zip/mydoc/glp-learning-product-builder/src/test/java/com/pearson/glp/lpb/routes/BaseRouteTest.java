/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.routes;

import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.kafka.test.rule.KafkaEmbedded;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.pearson.glp.core.validation.SchemaValidation;
import com.pearson.glp.lpb.LearningProductBuilderApp;
import com.pearson.glp.lpb.cloudcontract.CouchbaseConfigurations;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.data.repository.ProductRepository;
import com.pearson.glp.lpb.data.repository.ProductStatusRepository;
import com.pearson.glp.lpb.data.repository.TaskRepository;
import com.pearson.glp.lpb.services.LearningModelService;
import com.pearson.glp.lpb.services.NonPrimitiveAssetService;
import com.pearson.glp.lpb.services.ProductScannerService;
import com.pearson.glp.lpb.services.ProductService;
import com.pearson.glp.lpb.services.TaskService;

/**
 * The Class BaseRouteTest.
 *
 * @author sanket.Gupta
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {
    LearningProductBuilderApp.class, CouchbaseConfigurations.class })
@ActiveProfiles("testing")
public abstract class BaseRouteTest {

  /** The web test client. */
  @Autowired
  public WebTestClient webTestClient;

  /** The learning model service. */
  @MockBean
  public LearningModelService learningModelService;

  /** The repository. */
  @MockBean
  public LearningModelRepository repository;

  /** The nonPrimitiveAssetRepository. */
  @MockBean
  public NonPrimitiveAssetRepository nonPrimitiveAssetRepository;

  /** The nonPrimitiveAssetService. */
  @MockBean
  public NonPrimitiveAssetService nonPrimitiveAssetService;

  /** The product repository. */
  @MockBean
  public ProductRepository productRepository;

  /** The product service. */
  @MockBean
  public ProductService productService;

  /** The taskRepository. */
  @MockBean
  public TaskRepository taskRepository;

  /** The taskService. */
  @MockBean
  public TaskService taskService;

  /** The schema validation. */
  @MockBean
  public SchemaValidation schemaValidation;

  /** The statusRepository. */
  @MockBean
  public ProductStatusRepository statusRepository;

  @MockBean
  public ProductScannerService productScannerService;

  /** The Constant embeddedKafka. */
  @ClassRule
  public static final KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, 1, "messages");

  @BeforeClass
  public static void beforeClass() {
    System.setProperty("spring.kafka.bootstrap-servers", embeddedKafka.getBrokersAsString());
    System.setProperty("spring.cloud.stream.kafka.binder.zkNodes",
        embeddedKafka.getZookeeperConnectionString());
    System.setProperty("task.disable", "false");
  }

  @Value("${server.contextPath}")
  public String contextPath;
}
