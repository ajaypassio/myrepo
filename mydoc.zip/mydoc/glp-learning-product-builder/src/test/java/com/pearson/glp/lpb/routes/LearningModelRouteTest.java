/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.routes;

import static com.pearson.glp.lpb.constant.TestingConstants.ASSESSMENT;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_URI;
import static com.pearson.glp.lpb.constant.TestingConstants.INVALID_ASSET_MODEL_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_MODEL_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_MODEL_URI;
import static com.pearson.glp.lpb.constant.TestingConstants.VERSIONS;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.dto.response.AssetModelResponse;
import com.pearson.glp.lpb.dto.response.LearningModelResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.dto.response.ProductModelResponse;
import com.pearson.glp.lpb.enums.AssetType;

import reactor.core.publisher.Mono;

/**
 * The Class LearningModelRouteTest.
 *
 * @author srishti.singh
 */
public class LearningModelRouteTest extends BaseRouteTest {

  /** The Constant ASSET_MODEL_ID. */
  public static final String ASSET_MODEL_ID = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant ASSET_MODEL_VERSION_ID. */
  public static final String ASSET_MODEL_VERSION_ID = "672e01c3-cfba-4622-81b8-0ca9cc9c4b1e";

  /** The Constant ASSET_MODEL_ID. */
  public static final String PRODUCT_MODEL_ID = "46b49213-1bf1-46b4-9213-46222db8fc7c";

  /** The Constant PRODUCT_MODEL_VERSION_ID. */
  public static final String PRODUCT_MODEL_VERSION_ID = "8bdbe309-433c-4e95-b194-736399c1790b";

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test get all asset models.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAssetModels() throws ServiceException {

    List<AssetModelResponse> assetModelList = new ArrayList<>();
    assetModelList.add(getAssetModelResponse());
    assetModelList.add(getAssetModelResponse());

    Mockito
        .when(learningModelService.findLearningModels(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelList));

    webTestClient.get().uri(ASSET_MODEL_ROUTE).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isOk().expectBody(LearningModelResponse.class);
  }

  /**
   * Test create asset model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModel() throws ServiceException {

    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(ASSESSMENT);

    Mockito.when(learningModelService.createAssetModels(Mockito.any(AssetModelPayload.class)))
        .thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post().uri(ASSET_MODEL_ROUTE).accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful()
        .expectBody(AssetModel.class);

  }

  /**
   * Test get asset model by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelById() throws ServiceException {

    Mockito
        .when(learningModelService.findAssetModelById(ASSET_MODEL_ID, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.get().uri(ASSET_MODEL_ROUTE + ASSET_MODEL_ID).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(AssetModel.class);
  }

  /**
   * Test get all versions by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllVersionsById() throws ServiceException {

    List<AssetModelResponse> assetModelList = new ArrayList<>();
    assetModelList.add(getAssetModelResponse());
    assetModelList.add(getAssetModelResponse());

    Mockito
        .when(learningModelService.findAllVersionsById(ASSET_MODEL_ID, AssetType.AGGREGATE.value()))
        .thenReturn(Mono.just(assetModelList));

    webTestClient.get().uri(ASSET_MODEL_ROUTE + ASSET_MODEL_ID + VERSIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LearningModelResponse.class);
  }

  /**
   * Test create asset model versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssetModelVersions() throws ServiceException {

    List<AssetModelResponse> assetModelList = new ArrayList<>();
    assetModelList.add(getAssetModelResponse());

    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(ASSESSMENT);

    Mockito
        .when(learningModelService.createAssetModelVersion(Mockito.any(AssetModelPayload.class),
            Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(getAssetModelResponse()));

    Mockito.when(learningModelService.findAssetModelById(Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelList.get(0)));

    webTestClient.post().uri(ASSET_MODEL_ROUTE + ASSET_MODEL_VERSION_ID + VERSIONS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful()
        .expectBody(AssetModel.class);
  }

  /**
   * Test get asset model by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelByVersionId() throws ServiceException {

    Mockito.when(learningModelService.findVersionById(ASSET_MODEL_ID, ASSET_MODEL_VERSION_ID,
        AssetType.AGGREGATE.value())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.get().uri(ASSET_MODEL_ROUTE + ASSET_MODEL_ID + VERSIONS + ASSET_MODEL_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(AssetModel.class);
  }

  /**
   * Gets the asset model response.
   *
   * @return the asset model response
   */
  private AssetModelResponse getAssetModelResponse() {
    AssetModelResponse assetModelResponse = new AssetModelResponse();
    assetModelResponse.set_id(UUID.randomUUID().toString());
    assetModelResponse.set_ver(UUID.randomUUID().toString());
    assetModelResponse.setLabel(ASSET_MODEL_LABEL);
    assetModelResponse.setTags(ASSET_MODEL_TAGS);
    return assetModelResponse;
  }

  /**
   * Gets the product model response.
   *
   * @return the product model response
   */
  private AssetModelResponse getProductModelResponse() {
    AssetModelResponse assetModelResponse = new AssetModelResponse();
    assetModelResponse.set_id(UUID.randomUUID().toString());
    assetModelResponse.set_ver(UUID.randomUUID().toString());
    assetModelResponse.setLabel(PRODUCT_MODEL_LABEL);
    assetModelResponse.setTags(PRODUCT_MODEL_TAGS);
    return assetModelResponse;
  }

  /**
   * Test for wrong json type.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForWrongJsonType() throws ServiceException {
    webTestClient.get().uri(ASSET_MODEL_ROUTE).accept(MediaType.APPLICATION_PROBLEM_XML).exchange()
        .expectStatus().is4xxClientError();
  }

  /**
   * Test for invalid URI.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForInvalidURI() throws ServiceException {
    webTestClient.get().uri(INVALID_ASSET_MODEL_ROUTE).accept(MediaType.APPLICATION_PROBLEM_XML)
        .exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test create product model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductModel() throws ServiceException {

    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(PRODUCT);

    Mockito.when(learningModelService.createAssetModels(Mockito.any(AssetModelPayload.class)))
        .thenReturn(Mono.just(getProductModelResponse()));

    webTestClient.post().uri(PRODUCT_MODEL_ROUTE).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful()
        .expectBody(AssetModel.class);

  }

  /**
   * Test create product model versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductModelVersions() throws ServiceException {

    List<AssetModelResponse> assetModelList = new ArrayList<>();
    assetModelList.add(getAssetModelResponse());

    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(PRODUCT);

    Mockito
        .when(learningModelService.createAssetModelVersion(Mockito.any(AssetModelPayload.class),
            Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(getProductModelResponse()));

    Mockito.when(learningModelService.findAssetModelById(Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelList.get(0)));

    webTestClient.post().uri(PRODUCT_MODEL_ROUTE + PRODUCT_MODEL_ID + VERSIONS)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful()
        .expectBody(AssetModel.class);

  }

  @Test
  public void testForInvalidMethod() throws ServiceException {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(ASSESSMENT);

    webTestClient.put().uri(ASSET_MODEL_URI)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError()
        .expectBody(AssetModel.class);
  }

  /**
   * Test get product model by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductModelByVersionId() throws ServiceException {

    Mockito.when(learningModelService.findVersionById(PRODUCT_MODEL_ID, PRODUCT_MODEL_VERSION_ID,
        AssetType.PRODUCT.value())).thenReturn(Mono.just(getProductModelResponse()));

    webTestClient.get()
        .uri(PRODUCT_MODEL_ROUTE + PRODUCT_MODEL_ID + VERSIONS + PRODUCT_MODEL_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(AssetModel.class);
  }

  /**
   * Test get all versions by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProductModelVersionsById() throws ServiceException {

    List<AssetModelResponse> productModelList = new ArrayList<>();
    productModelList.add(getProductModelResponse());
    productModelList.add(getProductModelResponse());

    Mockito
        .when(learningModelService.findAllVersionsById(PRODUCT_MODEL_ID, AssetType.PRODUCT.value()))
        .thenReturn(Mono.just(productModelList));

    webTestClient.get().uri(PRODUCT_MODEL_ROUTE + PRODUCT_MODEL_ID + VERSIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ProductModelResponse.class);
  }

  /**
   * Test get all product models.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProductModels() throws ServiceException {

    List<AssetModelResponse> productModelList = new ArrayList<>();
    productModelList.add(getProductModelResponse());
    productModelList.add(getProductModelResponse());

    Mockito
        .when(learningModelService.findLearningModels(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(productModelList));

    webTestClient.get().uri(PRODUCT_MODEL_URI).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isOk().expectBody(ProductModelResponse.class);
  }

  /**
   * Get Test for invalid Accept Header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */

  @Test
  public void testForGetWithWrongUrl() throws ServiceException {
    webTestClient.get().uri(INVALID_ASSET_MODEL_ROUTE).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is4xxClientError();
  }

  /**
   * Get Test for wrong Accept Header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForGetWithWrongAcceptHeader() throws ServiceException {
    webTestClient.get().uri(ASSET_MODEL_URI).accept(MediaType.valueOf("application/ABC")).exchange()
        .expectStatus().is4xxClientError();
  }

  /**
   * Post Test for invalid Accept and Content-Type header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForPostWithInvalidAcceptWithValidContentType() throws ServiceException {

    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>(1);

    webTestClient.post().uri(PRODUCT_MODEL_URI).body(BodyInserters.fromFormData(formData))
        .accept(MediaType.APPLICATION_XML).exchange().expectStatus().is4xxClientError()
        .expectBody(PlatformErrorResponse.class);
  }

  /**
   * Post Test for invalid Content-Type UNSUPPORTED_MEDIA_TYPE(415).
   *
   * @throws ServiceException
   *           the service exception
   */

  @Test
  public void testForPostWithInvalidContentType() throws ServiceException {

    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>(1);

    webTestClient.post().uri(PRODUCT_MODEL_URI).contentType(MediaType.APPLICATION_FORM_URLENCODED)
        .body(BodyInserters.fromFormData(formData)).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is4xxClientError().expectBody(PlatformErrorResponse.class);

  }

  /**
   * Post Test for wrong Accept header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForPostWithWrongAcceptHeader() throws ServiceException {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(ASSESSMENT);

    webTestClient.post().uri(ASSET_MODEL_URI)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .header("Accept", "application/").exchange().expectStatus().is4xxClientError()
        .expectBody(PlatformErrorResponse.class);
  }

  /**
   * Post Test for invalid Accept header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForPostWithInvalidAcceptHeader() throws ServiceException {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(ASSESSMENT);

    webTestClient.post().uri(ASSET_MODEL_URI)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_ATOM_XML).exchange().expectStatus().is4xxClientError()
        .expectBody(PlatformErrorResponse.class);
  }

  /**
   * Test for invalid post with valid url METHOD_NOT_ALLOWED(405).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForInvalidPostWithValidUrl() throws ServiceException {
    webTestClient.post()
        .uri(PRODUCT_MODEL_ROUTE + PRODUCT_MODEL_ID + VERSIONS + PRODUCT_MODEL_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is4xxClientError();
  }

}