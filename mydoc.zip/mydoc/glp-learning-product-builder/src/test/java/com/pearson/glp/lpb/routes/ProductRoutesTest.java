/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.CONTENT_METADATA;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.INITIAL_BSS_VER;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.TAGS;
import static com.pearson.glp.lpb.constant.CommonConstants.TASK_STATUS;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.constant.TestingConstants.AND;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_TYPES;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_TYPES_WITH_PARAM;
import static com.pearson.glp.lpb.constant.TestingConstants.BASE_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.COMPOSE;
import static com.pearson.glp.lpb.constant.TestingConstants.EQUALS;
import static com.pearson.glp.lpb.constant.TestingConstants.ERROR_FETCHING_PRODUCT;
import static com.pearson.glp.lpb.constant.TestingConstants.FIND_PROUDUCT_BY_ID_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_PRODUCT_ASSET_TYPES_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.GET_TASK_URL;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION;
import static com.pearson.glp.lpb.constant.TestingConstants.INVALID_PRODUCT_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POLICY;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_POST_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE_BASE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_ROUTE_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATE_TRANSITION_RESPONSE;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_STATUS_REQUEST;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_VERSION;
import static com.pearson.glp.lpb.constant.TestingConstants.STATE_TRANSITION;
import static com.pearson.glp.lpb.constant.TestingConstants.STATE_TRANSITION_PAYLOAD_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.STATUS;
import static com.pearson.glp.lpb.constant.TestingConstants.STATUS_LINK;
import static com.pearson.glp.lpb.constant.TestingConstants.STATUS_URL;
import static com.pearson.glp.lpb.constant.TestingConstants.TASK_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.VERSIONS;
import static com.pearson.glp.lpb.enums.Routes.ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE;
import static com.pearson.glp.lpb.utils.DateUtil.formatDateTime;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.core.errors.PlatformError;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.Asset;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Extensions;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.ProductAssetClassType;
import com.pearson.glp.lpb.data.model.ProductStateTransition;
import com.pearson.glp.lpb.data.model.ProductStatus;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.request.ProductPayload;
import com.pearson.glp.lpb.dto.request.ProductStatusPayload;
import com.pearson.glp.lpb.dto.request.StateTransitionPayload;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.AssetVersionsResponse;
import com.pearson.glp.lpb.dto.response.ProductAssetResponse;
import com.pearson.glp.lpb.dto.response.ProductCollectionAsset;
import com.pearson.glp.lpb.dto.response.ProductCollectionResponse;
import com.pearson.glp.lpb.dto.response.ProductConfigurationResponse;
import com.pearson.glp.lpb.dto.response.ProductsResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.enums.ProductsStatus;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class ProductRoutesTest.
 * 
 * @author kavya.jain
 */
public class ProductRoutesTest extends BaseRouteTest implements CommonUtils {

  /**
   * Test get product by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductByParameters() throws ServiceException {
    NonPrimitiveAsset productResponse = getProductResponse();
    Mockito.when(productService.findProductCollectionWithCompleteLA(Mockito.any()))
        .thenReturn(Flux.just(productResponse));

    webTestClient.get().uri(this.contextPath + PRODUCT_ROUTE + PRODUCT_ROUTE_TAGS + EQUALS + TAGS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();

  }

  /**
   * Test Get Product Asset Types.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypes() throws ServiceException {

    ProductAssetClassType productAssetClassType = convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON,
        ProductAssetClassType.class);

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(productAssetClassType));

    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + ASSET_TYPES_WITH_PARAM + EQUALS + INSTRUCTION)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Test Get Product Asset Types With Out Param .
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypesWithOutParam() throws ServiceException {

    ProductAssetClassType productAssetClassType = convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON,
        ProductAssetClassType.class);

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(productAssetClassType));

    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    webTestClient
        .get().uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS
            + PRODUCT_VERSION + ASSET_TYPES)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Test Get Product Asset Types Not Found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypesNotFound() throws ServiceException {

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + ASSET_TYPES_WITH_PARAM + EQUALS + TAGS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound();
  }

  /**
   * Test Get Product Asset Types Not Found by query param.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypesNotFoundByQueryParam() throws ServiceException {

    ProductAssetClassType productAssetClassType = convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON,
        ProductAssetClassType.class);

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(productAssetClassType));

    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + ASSET_TYPES_WITH_PARAM + EQUALS + TAGS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound();
  }

  /**
   * Test Get Product Asset Types invalid query param.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypesInvalidQueryParam() throws ServiceException {

    ProductAssetClassType productAssetClassType = convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON,
        ProductAssetClassType.class);

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(productAssetClassType));

    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + ASSET_TYPES_WITH_PARAM + EQUALS + TAGS + AND + TAGS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test Get Product Asset Types invalid query param2.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypesInvalidQueryParam2() throws ServiceException {

    ProductAssetClassType productAssetClassType = convertJsonToObject(GET_PRODUCT_ASSET_TYPES_JSON,
        ProductAssetClassType.class);

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(productAssetClassType));

    Mockito.when(productService.findProductByVersion(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + ASSET_TYPES_WITH_PARAM + TAGS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test Get Product Asset Types Internal Server Error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductAssetTypesInternalServerError() throws ServiceException {

    Mockito.when(productService.getProductAssetTypes(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.error(new NullPointerException()));

    webTestClient.get()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + ASSET_TYPES_WITH_PARAM + EQUALS + TAGS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is5xxServerError();
  }

  /**
   * Test put product status.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testPutProductStatus() throws ServiceException {

    ProductStatus productResponse = createProductStatus(COMPOSE);
    productResponse.setStatus(ProductsStatus.DRAFT.name());

    NonPrimitiveAsset nonPrimitiveAsset = convertJsonToObject(PRODUCT_JSON,
        NonPrimitiveAsset.class);

    Mockito.when(productService.findLatestAssetById(Mockito.anyString()))
        .thenReturn(Mono.just(nonPrimitiveAsset));
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(productResponse));
    productResponse.setStatus(ProductsStatus.COMPOSE.name());
    Mockito
        .when(productService.saveStatusDocument(Mockito.any(NonPrimitiveAsset.class),
            Mockito.any(ProductStatus.class), Mockito.any(ProductStatusPayload.class)))
        .thenReturn(Mono.just(productResponse));
    ProductStatusPayload productPayload = convertJsonToObject(PRODUCT_STATUS_REQUEST,
        ProductStatusPayload.class);
    webTestClient.put()
        .uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + STATUS_URL)
        .accept(MediaType.APPLICATION_JSON).syncBody(productPayload).exchange().expectStatus()
        .isOk();

  }

  /**
   * Get Test for wrong Accept Header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForGetWithWrongAcceptHeader() throws ServiceException {
    webTestClient.get().uri(PRODUCT_ROUTE_BASE).accept(MediaType.valueOf("application/ABC"))
        .exchange().expectStatus().is4xxClientError();
  }

  /**
   * Post Test for invalid Accept and Content-Type header NOT_ACCEPTABLE(406).
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testForPostWithInvalidAcceptWithValidContentType() throws ServiceException {

    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>(1);

    webTestClient.post().uri(PRODUCT_ROUTE_BASE).body(BodyInserters.fromFormData(formData))
        .accept(MediaType.APPLICATION_XML).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Post Test for invalid Content-Type UNSUPPORTED_MEDIA_TYPE(415).
   *
   * @throws ServiceException
   *           the service exception
   */

  @Test
  public void testForPostWithInvalidContentType() throws ServiceException {

    MultiValueMap<String, String> formData = new LinkedMultiValueMap<>(1);

    webTestClient.post().uri(PRODUCT_ROUTE_BASE).contentType(MediaType.APPLICATION_FORM_URLENCODED)
        .body(BodyInserters.fromFormData(formData)).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is4xxClientError();

  }

  /**
   * Test invalid URL.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testInvalidURL() throws ServiceException {
    webTestClient.get().uri(INVALID_PRODUCT_ROUTE).accept(MediaType.APPLICATION_PROBLEM_XML)
        .exchange().expectStatus().is4xxClientError();
  }

  /**
   * Gets the product response.
   *
   * @return the product response
   */
  private NonPrimitiveAsset getProductResponse() {
    NonPrimitiveAsset productResponse = new NonPrimitiveAsset();
    productResponse.set_id(PRODUCT_ID);
    productResponse.setTags(TAGS);
    productResponse.setVer(PRODUCT_VERSION);
    Link link = new Link();
    link.setHref("/v2/products/c875be88-45e3-48dd-b494-a598fbddb2d0/status");
    Links links = new Links();
    links.put(STATUS, link);
    productResponse.setLinks(links);
    return productResponse;
  }

  /**
   * Gets the product response query parameter.
   *
   * @return the product response query parameter
   */
  private ProductCollectionResponse getProductResponseQueryParameter() {
    ProductCollectionResponse productCollectionResponse = new ProductCollectionResponse();
    productCollectionResponse.setAssets(new ArrayList<ProductCollectionAsset>());
    productCollectionResponse.setCount(1);

    return productCollectionResponse;
  }

  /**
   * Test Find product by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductById() throws ServiceException {

    NonPrimitiveAsset productResponse = getProductResponse();

    Mockito.when(productService.findProductById(PRODUCT_ID)).thenReturn(Mono.just(productResponse));

    webTestClient.get().uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();

  }

  /**
   * Test find product by ver.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindProductByVer() throws ServiceException {

    NonPrimitiveAsset productResponse = getProductResponse();

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(productResponse));

    webTestClient.get()
        .uri(new StringBuilder(this.contextPath).append(TestingConstants.FIND_PROUDUCT_BY_ID_ROUTE)
            .append(PRODUCT_ID).append(VERSIONS).append(PRODUCT_VERSION).toString())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();

  }

  /**
   * Test the Product Post.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testProductPost() throws ServiceException {
    ProductPayload productPayload = convertJsonToObject(PRODUCT_POST_REQUEST, ProductPayload.class);
    NonPrimitiveAsset productNonPrimitiveAsset = createProductNonPrimitiveAsset(productPayload,
        AssetType.PRODUCT);
    AssetResponse assetResponse = new AssetResponse();
    assetResponse.setAsset(productNonPrimitiveAsset);
    ProductAssetResponse productAssetResponse = new ProductAssetResponse(productNonPrimitiveAsset);
    Mockito.when(productService.validateProduct(Mockito.any(ProductPayload.class), Mockito.any()))
        .thenReturn(Mono.just(assetResponse));
    Mockito.when(productService.createProductNonPrimitiveAssets(Mockito.any(ProductPayload.class),
        Mockito.any(NonPrimitiveAsset.class), Mockito.any())).thenReturn(createTaskResponse());
    Mockito.when(productService.saveProduct(Mockito.any(NonPrimitiveAssetPayload.class),
        Mockito.any(Asset.class))).thenReturn(Mono.just(productAssetResponse));
    ProductsResponse productResponse = webTestClient.post().uri(contextPath + PRODUCT_ROUTE_BASE)
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .syncBody(productPayload).accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isAccepted().expectBody(ProductsResponse.class).returnResult().getResponseBody();
    Assert.assertEquals(productResponse.get_id(), TASK_ID);
    Assert.assertEquals(productResponse.getStatus(), TASK_STATUS);
  }

  /**
   * Creates the product non primitive asset.
   *
   * @param productPayload
   *          the product payload
   * @param assetType
   *          the asset type
   * @return the product non primitive asset
   */
  private NonPrimitiveAsset createProductNonPrimitiveAsset(ProductPayload productPayload,
      AssetType assetType) {
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset(productPayload.getAsset());
    nonPrimitiveAsset.setId(UUID.randomUUID().toString());
    nonPrimitiveAsset.set_id(UUID.randomUUID().toString());
    nonPrimitiveAsset.setVer(UUID.randomUUID().toString());
    nonPrimitiveAsset.setBssVer(INITIAL_BSS_VER);
    nonPrimitiveAsset.setDocType(DocType.LEARNINGCONTENT.value());
    nonPrimitiveAsset.setAssetType(assetType.value());
    nonPrimitiveAsset.setCreated(formatDateTime(LocalDateTime.now()).get());
    setNonPrimitiveAssetExtensions(nonPrimitiveAsset, productPayload.getAsset());
    nonPrimitiveAsset.addLinks(SELF, createNonPrimitiveAssetSelfLink(assetType.url(),
        nonPrimitiveAsset.get_id(), nonPrimitiveAsset.getVer()));
    setNonPrimitiveAssetLinks(nonPrimitiveAsset);
    return nonPrimitiveAsset;
  }

  /**
   * Sets the non primitive asset links.
   *
   * @param nonPrimitiveAsset
   *          the new non primitive asset links
   */
  private void setNonPrimitiveAssetLinks(NonPrimitiveAsset nonPrimitiveAsset) {
    nonPrimitiveAsset.getLearningModel().addLinks(SELF,
        createNonPrimitiveAssetSelfLink(ASSET_MODEL_BY_ID_AND_VERSION_ID_ROUTE.value(),
            nonPrimitiveAsset.getLearningModel().getId(),
            nonPrimitiveAsset.getLearningModel().getVer()));

    nonPrimitiveAsset.getResources().values().forEach(resource -> {
      String url = AssetType.valueOf(resource.getAssetType()).url();
      resource.addLinks(SELF,
          createNonPrimitiveAssetSelfLink(url, resource.getId(), resource.getVer()));
    });
  }

  /**
   * Creates the non primitive asset self link.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the link
   */
  private Link createNonPrimitiveAssetSelfLink(String url, String id, String ver) {
    Link link = new Link();
    link.setHref(createNonPrimitiveAssetHref(url, id, ver));
    return link;
  }

  /**
   * Creates the non primitive asset href.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param ver
   *          the ver
   * @return the string
   */
  private String createNonPrimitiveAssetHref(String url, String id, String ver) {
    String href = url;
    href = href.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    href = href.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, ver);
    return href;
  }

  /**
   * Sets the non primitive asset extensions.
   *
   * @param nonPrimitiveAsset
   *          the non primitive asset
   * @param nonPrimitiveAssetPayload
   *          the non primitive asset payload
   */
  private void setNonPrimitiveAssetExtensions(NonPrimitiveAsset nonPrimitiveAsset,
      NonPrimitiveAssetPayload nonPrimitiveAssetPayload) {
    if (nonPrimitiveAsset.getExtensions() == null) {
      nonPrimitiveAsset.setExtensions(new Extensions());
    }
    nonPrimitiveAsset.getExtensions().put(CONTENT_METADATA,
        nonPrimitiveAssetPayload.getContentMetadata());
  }

  /**
   * Prepare Product Response.
   *
   * @return the product response
   */
  private Mono<ProductsResponse> createTaskResponse() {

    ProductsResponse productResponse = new ProductsResponse();
    productResponse.set_id(TASK_ID);
    productResponse.setStatus(TASK_STATUS);
    Link _link = new Link(GET_TASK_URL + TASK_ID);
    productResponse.set_link(_link);
    return Mono.just(productResponse);
  }

  /**
   * Test get product versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductVersions() throws ServiceException {
    AssetVersionsResponse assetVersionsResponse = getAssetVersionResponse();
    Mockito.when(productService.findProductVersionsById(PRODUCT_ID))
        .thenReturn(Mono.just(assetVersionsResponse));

    webTestClient.get().uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(AssetVersionsResponse.class);
  }

  /**
   * Test get product versions not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductVersionsNotFound() throws ServiceException {
    Mockito.when(productService.findProductVersionsById(PRODUCT_ID)).thenReturn(Mono.empty());

    webTestClient.get().uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(PlatformError.class);
  }

  /**
   * Test get product versions with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductVersionsWithException() throws ServiceException {
    Mockito.when(productService.findProductVersionsById(PRODUCT_ID))
        .thenReturn(Mono.error(new ServiceException(ERROR_FETCHING_PRODUCT)));

    webTestClient.get().uri(this.contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is5xxServerError()
        .expectBody(PlatformError.class);
  }

  /**
   * Test get product transition state with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductTransitionState() throws ServiceException {

    ProductStateTransition stateTransitionResponse = convertJsonToObject(
        PRODUCT_STATE_TRANSITION_RESPONSE, ProductStateTransition.class);

    Mockito.when(productService.fetchProductStateTransition(Mockito.any()))
        .thenReturn(Mono.just(stateTransitionResponse));

    webTestClient.get()
        .uri(contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + STATE_TRANSITION)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ProductStateTransition.class).returnResult().getResponseBody();
  }

  /**
   * Test post product transition state with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testPostProductTransitionState() throws ServiceException {

    NonPrimitiveAsset product = new NonPrimitiveAsset();
    product.setLinks(new LinkedHashMap<>());
    product.getLinks().put(CommonConstants.STATUS, new Link(STATUS_LINK));

    Mockito.when(productService.findProductByVersion(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(product));
    Mockito.when(productService.fetchProductStateTransition(Mockito.anyString()))
        .thenReturn(Mono.empty());
    Mockito.when(productService.fetchProductStatus(Mockito.anyString()))
        .thenReturn(Mono.just(createProductStatus(ProductsStatus.REVIEW.name())));
    ProductStateTransition stateTransitionResponse = new ProductStateTransition();
    Mockito.when(productService.getStateTransitionResponse(Mockito.any(), Mockito.any(),
        Mockito.anyString())).thenReturn(Mono.just(stateTransitionResponse));
    StateTransitionPayload payload = convertJsonToObject(STATE_TRANSITION_PAYLOAD_JSON,
        StateTransitionPayload.class);

    webTestClient.post()
        .uri(contextPath + FIND_PROUDUCT_BY_ID_ROUTE + PRODUCT_ID + VERSIONS + PRODUCT_VERSION
            + STATE_TRANSITION)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .syncBody(payload).accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isCreated()
        .expectBody(ProductStateTransition.class).returnResult().getResponseBody();
  }

  /**
   * Creates the product status.
   *
   * @param status
   *          the status
   * @return the product status
   */
  private ProductStatus createProductStatus(String status) {
    ProductStatus productStatus = new ProductStatus();
    productStatus.setStatus(status);
    return productStatus;
  }

  /**
   * Gets the asset version response.
   *
   * @return the asset version response
   */
  private AssetVersionsResponse getAssetVersionResponse() {
    AssetVersionsResponse assetVersionsResponse = new AssetVersionsResponse();
    assetVersionsResponse.setCount(1);
    Asset asset = new Asset();
    asset.set_id(PRODUCT_ID);
    asset.setVer(UUID.randomUUID().toString());
    asset.setBssVer(BASE_VERSION);
    asset.setId(UUID.randomUUID().toString());
    assetVersionsResponse.setVersions(Arrays.asList(asset));
    return assetVersionsResponse;
  }

  /**
   * Test get product policy.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductPolicy() throws ServiceException {
    Mockito.when(productService.fetchProductConfiguration(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.just(getPolicyResponse()));

    webTestClient.get()
        .uri(new StringBuilder(this.contextPath).append(TestingConstants.FIND_PROUDUCT_BY_ID_ROUTE)
            .append(PRODUCT_ID).append(VERSIONS).append(PRODUCT_VERSION)
            .append("?fields=configuration").toString())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(Configuration.class);
  }

  /**
   * Test get product policy not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductPolicyNotFound() throws ServiceException {
    Mockito.when(productService.fetchProductConfiguration(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(new StringBuilder(this.contextPath).append(TestingConstants.FIND_PROUDUCT_BY_ID_ROUTE)
            .append(PRODUCT_ID).append(VERSIONS).append(PRODUCT_VERSION)
            .append("?fields=configuration").toString())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(PlatformError.class);
  }

  /**
   * Test get product policy bad request.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductPolicyBadRequest() throws ServiceException {
    Mockito.when(productService.fetchProductConfiguration(PRODUCT_ID, PRODUCT_VERSION))
        .thenReturn(Mono.empty());

    webTestClient.get()
        .uri(new StringBuilder(this.contextPath).append(TestingConstants.FIND_PROUDUCT_BY_ID_ROUTE)
            .append(PRODUCT_ID).append(VERSIONS).append(PRODUCT_VERSION).append("?fields=config")
            .toString())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(PlatformError.class);
  }

  /**
   * Gets the policy response.
   *
   * @return the policy response
   */
  private ProductConfigurationResponse getPolicyResponse() {
    ProductConfigurationResponse policyResponse = new ProductConfigurationResponse();
    policyResponse.setId(PRODUCT_ID);
    policyResponse.setVer(PRODUCT_VERSION);
    policyResponse.setBssVer(INITIAL_BSS_VER);
    Link link = new Link();
    link.setHref(new StringBuilder(TestingConstants.FIND_PROUDUCT_BY_ID_ROUTE).append(PRODUCT_ID)
        .append(VERSIONS).append(PRODUCT_VERSION).toString());
    Links links = new Links();
    links.put(SELF, link);
    policyResponse.setLinks(links);
    policyResponse.setConfiguration(getConfiguration());

    return policyResponse;
  }

  /**
   * Gets the configuration.
   *
   * @return the configuration
   */
  private Configuration getConfiguration() {
    Configuration configuration = new Configuration();
    ArrayList<String> policyGroups = new ArrayList<>();
    policyGroups.add(PRODUCT_POLICY);
    configuration.put("policyGroups", policyGroups);
    return configuration;
  }

  public ProductRoutesTest() {
    super();
  }

}