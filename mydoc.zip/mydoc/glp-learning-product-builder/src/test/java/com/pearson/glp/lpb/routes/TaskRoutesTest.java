/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.routes;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;
import static com.pearson.glp.lpb.enums.Routes.TASK_BY_ID_ROUTE;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.constant.CommonConstants;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.Task;
import com.pearson.glp.lpb.data.model.TaskResource;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;

/**
 * The Class TaskRoutesTest.
 *
 * @author sankalp.katiyar
 */
public class TaskRoutesTest extends BaseRouteTest implements CommonUtils {

  /** The task id. */
  private String taskId = null;

  /** The task. */
  private Task task = null;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
    task = new Task();
    taskId = UUID.randomUUID().toString();
    prepareTask(taskId);
  }

  /**
   * Test task routes.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void taskRoutes() throws ServiceException {
    Mockito.when(taskService.findTaskBy_Id(taskId)).thenReturn(Mono.just(task));

    String url = TASK_BY_ID_ROUTE.value()
        .replace(OPEN_PARANTHESIS + CommonConstants.ID + CLOSE_PARANTHESIS, taskId);

    webTestClient.get().uri(this.contextPath + url).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isOk().expectBody(Task.class);
  }

  /**
   * Test task routes with exception.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testTaskRoutesWithException() throws ServiceException {
    Mockito.when(taskService.findTaskBy_Id(taskId))
        .thenReturn(Mono.error(new ServiceException(taskId)));

    String url = TASK_BY_ID_ROUTE.value()
        .replace(OPEN_PARANTHESIS + CommonConstants.ID + CLOSE_PARANTHESIS, taskId);

    webTestClient.get().uri(this.contextPath + url).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is5xxServerError().expectBody(Task.class);
  }

  /**
   * Prepare task.
   *
   * @param taskId
   *          the task id
   */
  private void prepareTask(String taskId) {
    Task task = new Task();
    task.setId(UUID.randomUUID().toString());
    task.setStatus(TestingConstants.RUNNING_STATUS);
    task.setLinks(prepareLinks(TestingConstants.TASK_BYID_ROUTE, taskId, ""));
    TaskResource resource = new TaskResource();
    String resourceId = UUID.randomUUID().toString();
    String resourceVer = UUID.randomUUID().toString();
    resource.setId(resourceId);
    resource.setBssVer(1);
    resource.setVer(resourceVer);
    Links links = prepareLinks(TestingConstants.GET_PRODUCT_BY_VERSION_URL, resourceId,
        resourceVer);
    resource.setLinks(links);
    List<TaskResource> resources = new ArrayList<>();
    resources.add(resource);
    task.setResources(resources);
  }

  /**
   * Prepare links.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the links
   */
  private Links prepareLinks(String url, String id, String version) {
    Links links = new Links();
    Link link = new Link();
    url = url.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    url = url.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, version);
    link.setHref(url);
    links.put(SELF, link);
    return links;
  }

}