/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.stereotype.Component;

import com.pearson.glp.core.handlers.isc.IscServiceHandlerContext;
import com.pearson.glp.crosscutting.isc.client.async.service.IscAsyncClient;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.dto.event.request.EventPayload;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.EventType;
import com.pearson.glp.lpb.services.impl.EventServiceImpl;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class EventServiceTest.
 * 
 * @author anshul.garg
 *
 */
@Component
public class EventServiceTest {

  /** The event service mock. */
  @InjectMocks
  private EventServiceImpl eventService;

  /** The isc async client. */
  @Mock
  private IscAsyncClient iscAsyncClient;

  /** The isc service handler cxt. */
  @Mock
  private IscServiceHandlerContext iscServiceHandlerCxt;

  /**
   * Setup.
   */
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Publish async event test for success.
   */
  @Test
  public void testAsyncEventPublishSuccess() {
    Mockito.when(iscAsyncClient.publishEvent(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.just(Boolean.TRUE));

    Mockito.when(iscServiceHandlerCxt.getStringPayload()).thenReturn(Mono.just("payload"));
    final String testEvent = "testevent";
    Mono<Boolean> response = eventService.publishEvent(testEvent, new NonPrimitiveAsset());

    StepVerifier.create(response).expectNextMatches(resp -> {
      assertEquals(resp, Boolean.TRUE);
      return true;
    }).verifyComplete();
  }

  /**
   * Publish async event test for exception.
   */
  @Test
  public void testAsyncEventPublishException() {
    Mockito.when(iscAsyncClient.publishEvent(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(Mono.error(new RuntimeException()));

    final String testEvent = "testevent";
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setAssetType(AssetType.PRODUCT.value());
    Mono<Boolean> response = eventService.publishEvent(testEvent, nonPrimitiveAsset);

    StepVerifier.create(response).expectError().verify();
  }

  /**
   * Test async event publish message success.
   */
  @Test
  public void testAsyncEventPublishMessageSuccess() {
    Mockito.when(
        iscAsyncClient.publishEventMessage(Mockito.anyString(), Mockito.any(EventPayload.class)))
        .thenReturn(Mono.just(Boolean.TRUE));
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setAssetType(AssetType.AGGREGATE.value());
    Mono<Boolean> response = eventService
        .publishEventMessage(EventType.NON_PRIMITIVE_LA_CREATED.value(), nonPrimitiveAsset);

    StepVerifier.create(response).assertNext(resp -> {
      assertEquals(resp, Boolean.TRUE);
    }).verifyComplete();
  }

  /**
   * Test async event publish message exception.
   */
  @Test
  public void testAsyncEventPublishMessageException() {
    Mockito.when(
        iscAsyncClient.publishEventMessage(Mockito.anyString(), Mockito.any(EventPayload.class)))
        .thenReturn(Mono.error(new RuntimeException()));
    NonPrimitiveAsset nonPrimitiveAsset = new NonPrimitiveAsset();
    nonPrimitiveAsset.setAssetType(AssetType.PRODUCT.value());
    Mono<Boolean> response = eventService
        .publishEventMessage(EventType.NON_PRIMITIVE_LA_CREATED.value(), nonPrimitiveAsset);

    StepVerifier.create(response).verifyError();
  }
}
