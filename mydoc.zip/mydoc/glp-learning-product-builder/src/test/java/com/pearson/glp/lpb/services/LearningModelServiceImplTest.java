/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import static com.pearson.glp.lpb.constant.CommonConstants.POLICY_GROUPS;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_CREATED_BY;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_EXPIRES_ON;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.DUMMY_RESOURCES_URL;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.PRODUCT_MODEL_TAGS;
import static com.pearson.glp.lpb.constant.TestingConstants.RESOURCES_KEY;
import static com.pearson.glp.lpb.constant.TestingConstants.DEFAULT_POLICY_GROUPS;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.Configuration;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.lm.resources.InstanceModel;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceObject;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.dto.response.AssetModelResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.DocType;
import com.pearson.glp.lpb.services.impl.LearningModelServiceImpl;
import com.pearson.glp.lpb.utils.DateUtil;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class AssetModelServiceImplTest.
 *
 * @author sourabh.aggarwal
 */

public class LearningModelServiceImplTest {

  /** The asset model service impl. */
  @InjectMocks
  private LearningModelServiceImpl assetModelServiceImpl;

  /** The repository. */
  @Mock
  private LearningModelRepository repository;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Instantiates a new asset model service impl test.
   */
  public LearningModelServiceImplTest() {
    super();
  }

  /**
   * Test find all asset models.
   */
  @Test
  public void testFindAllAssetModels() {
    // Given
    List<AssetModel> assetModels = getAssetModels(2, null, false);
    assetModels.get(0).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "ASSETMODEL::12347a5d-c6c0-4d38-991b-dbea95e1a18b::12347a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModels(Mockito.any())).thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findLearningModels(AssetType.AGGREGATE.value(), null, null);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find all asset models with tag.
   */
  @Test
  public void testFindAllAssetModelsWithTag() {
    // Given
    List<AssetModel> assetModels = getAssetModels(2, null, false);

    assetModels.get(0).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "ASSETMODEL::12347a5d-c6c0-4d38-991b-dbea95e1a18b::12347a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModelsWithTag(Mockito.any(), Mockito.any()))
        .thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findLearningModels(AssetType.AGGREGATE.value(), ASSET_MODEL_TAGS, null);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find all asset models with label.
   */
  @Test
  public void testFindAllAssetModelsWithLabel() {
    // Given
    List<AssetModel> assetModels = getAssetModels(2, null, false);

    assetModels.get(0).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "ASSETMODEL::12347a5d-c6c0-4d38-991b-dbea95e1a18b::12347a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModelsWithLabel(Mockito.any(), Mockito.any()))
        .thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findLearningModels(AssetType.AGGREGATE.value(), null, ASSET_MODEL_LABEL);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find all asset models with tag and label.
   */
  @Test
  public void testFindAllAssetModelsWithTagAndLabel() {
    // Given
    List<AssetModel> assetModels = getAssetModels(2, null, false);

    assetModels.get(0).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "ASSETMODEL::12347a5d-c6c0-4d38-991b-dbea95e1a18b::12347a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(
        repository.findLearningModelsWithTagAndLabel(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findLearningModels(AssetType.AGGREGATE.value(), ASSET_MODEL_TAGS, ASSET_MODEL_LABEL);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find all product models.
   */
  @Test
  public void testFindAllProductModels() {
    // Given
    List<AssetModel> assetModels = getAssetModels(2, null, false);

    // set diff doc Ids
    assetModels.get(0).setId(
        "PRODUCTMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "PRODUCTMODEL::12347a5d-c6c0-4d38-991b-dbea95e1a18b::12347a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModels(Mockito.any())).thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findLearningModels(AssetType.PRODUCT.value(), null, null);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find all product models with tag.
   */
  @Test
  public void testFindAllProductModelsWithTag() {
    // Given
    List<AssetModel> assetModels = getAssetModels(2, null, false);

    assetModels.get(0).setId(
        "PRODUCTMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "PRODUCTMODEL::12347a5d-c6c0-4d38-991b-dbea95e1a18b::12347a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModelsWithTag(Mockito.any(), Mockito.any()))
        .thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findLearningModels(AssetType.PRODUCT.value(), PRODUCT_MODEL_TAGS, null);

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test create asset models.
   */
  @Test
  public void testCreateAssetModels() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    Configuration configuration = new Configuration();
    configuration.put(POLICY_GROUPS, Arrays.asList(DEFAULT_POLICY_GROUPS));

    assetModel.setConfiguration(configuration);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl
        .createAssetModels(createAssetModelPayload());

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModel.getConfiguration(), response.getConfiguration());
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create asset models with resource and data.
   */
  @Test
  public void testCreateAssetModelsWithResourceAndData() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl.createAssetModels(
        createLearningModelPayloadWithResource(true, false, AssetType.INSTRUCTION.value()));

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create asset models with resource and data.
   */
  @Test
  public void testCreateAssetModelsWithResourceAndInstanceModel() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl.createAssetModels(
        createLearningModelPayloadWithResource(true, true, AssetType.INSTRUCTION.value()));

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test find asset model by id.
   */
  @Test
  public void testFindAssetModelById() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    AssetModel assetModel = getAssetModels(1, assetModelId, false).get(0);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> monoAssetModelById = assetModelServiceImpl
        .findAssetModelById(assetModelId, AssetType.AGGREGATE.value());

    // Then
    StepVerifier.create(monoAssetModelById).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test find all versions by id.
   */
  @Test
  public void testFindAllVersionsById() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    List<AssetModel> assetModels = getAssetModels(3, assetModelId, true);

    assetModels.get(0).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18c");
    assetModels.get(2).setId(
        "ASSETMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18d");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModels(Mockito.any())).thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findAllVersionsById(assetModelId, AssetType.AGGREGATE.value());

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find version by id.
   */
  @Test
  public void testFindVersionById() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    String assetModelVer = "22357a5d-c6c0-4d38-991b-dbea95e1a18b";
    AssetModel assetModel = getAssetModels(1, assetModelId, true).get(0);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl.findVersionById(assetModelId,
        assetModelVer, AssetType.AGGREGATE.value());

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create asset model version.
   */
  @Test
  public void testCreateAssetModelVersion() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    AssetModel assetModel = getAssetModels(1, assetModelId, true).get(0);
    AssetModel a1 = new AssetModel();
    a1.setLinks(new LinkedHashMap<>());
    a1.addLinks("testLink", new Link());
    Mockito.doReturn(Mono.just(assetModel)).when(repository).save(Mockito.any());
    Mockito.doReturn(Mono.just(assetModel)).when(repository).findById(Mockito.anyString());
    AssetModelPayload assetModelPayload = createAssetModelPayload();
    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl
        .createAssetModelVersion(assetModelPayload, assetModelId, AssetType.AGGREGATE.value());

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create product model.
   */
  @Test
  public void testCreateProductModel() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    assetModel.setAssetType(PRODUCT_MODEL_LABEL);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl
        .createAssetModels(createProductModelPayload());

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create product model with data under resource.
   */
  @Test
  public void testCreateProductModelWithData() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl.createAssetModels(
        createLearningModelPayloadWithResource(true, false, PRODUCT_MODEL_LABEL));

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create product model with data and instance under resource.
   */
  @Test
  public void testCreateProductModelWithDataAndInstance() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl
        .createAssetModels(createLearningModelPayloadWithResource(true, true, PRODUCT_MODEL_LABEL));

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Gets the asset models.
   *
   * @param noOfAssetModels
   *          the no of asset models
   * @param assetModelId
   *          the asset model id
   * @param isAssetModelId
   *          the is asset model id
   * @return the asset models
   */
  private List<AssetModel> getAssetModels(int noOfAssetModels, String assetModelId,
      boolean isAssetModelId) {
    List<AssetModel> assetModelList = new ArrayList<>();
    for (int i = 0; i < noOfAssetModels; i++) {
      assetModelList.add(createAssetModel(assetModelId, isAssetModelId));
    }
    return assetModelList;
  }

  /**
   * Creates the asset model.
   *
   * @param assetModelId
   *          the asset model id
   * @param isAssetModelId
   *          the is asset model id
   * @return the asset model
   */
  private AssetModel createAssetModel(String assetModelId, boolean isAssetModelId) {
    AssetModel assetModel = new AssetModel();
    if (isAssetModelId) {
      assetModel.set_id(assetModelId);
    } else {
      assetModel.set_id(UUID.randomUUID().toString());
    }
    assetModel.setBssVer(1);
    assetModel.setVer(UUID.randomUUID().toString());
    assetModel.setCreated(DateUtil.formatDateTime(LocalDateTime.now()).get());
    assetModel.setLastModified(DateUtil.formatDateTime(LocalDateTime.now()).get());
    assetModel.set_createdBy(ASSET_MODEL_CREATED_BY);
    assetModel.setDocType(DocType.LEARNINGMODEL.value());
    assetModel.setAssetType(AssetType.INSTRUCTION.value());
    assetModel.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModel.setLabel(ASSET_MODEL_LABEL);
    assetModel.setTags(ASSET_MODEL_TAGS);
    assetModel.setResources(createResources());

    return assetModel;
  }

  /**
   * Creates the resources.
   *
   * @return the linked hash map
   */
  private LinkedHashMap<String, ResourceObject> createResources() {
    LinkedHashMap<String, ResourceObject> resourceMap = new LinkedHashMap<>();
    resourceMap.put("resourceKey", createResourceObject());
    return resourceMap;
  }

  /**
   * Creates the resource object.
   *
   * @return the resource object
   */
  private ResourceObject createResourceObject() {
    InstanceModel instanceModel = new InstanceModel();
    instanceModel.addLinks(SELF, new Link(DUMMY_RESOURCES_URL));
    instanceModel.setLinks(new LinkedHashMap<>());
    instanceModel.addLinks(SELF, new Link(DUMMY_RESOURCES_URL));
    ResourceData resourceData = new ResourceData();
    ResourceObject resourceObject = new ResourceObject();
    resourceData.setInstanceModel(instanceModel);
    resourceObject.setData(resourceData);
    return resourceObject;
  }

  /**
   * Creates the product model payload.
   *
   * @return the asset model payload
   */
  private AssetModelPayload createProductModelPayload() {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(PRODUCT_MODEL_LABEL);
    assetModelPayload.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModelPayload.setLabel(ASSET_MODEL_LABEL);
    assetModelPayload.setTags(ASSET_MODEL_TAGS);
    assetModelPayload.setResources(new LinkedHashMap<>());
    return assetModelPayload;
  }

  /**
   * Creates the asset model payload.
   *
   * @return the asset model payload
   */
  private AssetModelPayload createAssetModelPayload() {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(AssetType.INSTRUCTION.value());
    assetModelPayload.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModelPayload.setLabel(ASSET_MODEL_LABEL);
    assetModelPayload.setTags(ASSET_MODEL_TAGS);
    assetModelPayload.setResources(new LinkedHashMap<>());
    assetModelPayload.setConfiguration(new Configuration());
    return assetModelPayload;
  }

  /**
   * Verify asset model response.
   *
   * @param assetModel
   *          the asset model
   * @param assetModelResponse
   *          the asset model response
   */
  private void verifyAssetModelResponse(AssetModel assetModel,
      AssetModelResponse assetModelResponse) {
    assertEquals(assetModel.get_id(), assetModelResponse.get_id());
    assertEquals(assetModel.getBssVer(), assetModelResponse.get_bssVer());
    assertEquals(assetModel.getVer(), assetModelResponse.get_ver());
    assertEquals(assetModel.getDocType(), assetModelResponse.get_docType());
    assertEquals(assetModel.getAssetType(), assetModelResponse.get_assetType());
    assertEquals(assetModel.getExpiresOn(), assetModelResponse.getExpiresOn());
    assertEquals(assetModel.getLabel(), assetModelResponse.getLabel());
    assertEquals(assetModel.getTags(), assetModelResponse.getTags());
  }

  /**
   * Creates the Learning model payload specific to assetType
   * 
   * @param isDataRequired
   *          true if data required else false.
   * @param isInstanceModelRequired
   *          true if instance model required else false.
   * @return asset model payload.
   */
  private AssetModelPayload createLearningModelPayloadWithResource(boolean isDataRequired,
      boolean isInstanceModelRequired, String assetType) {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.set_createdBy(ASSET_MODEL_CREATED_BY);
    assetModelPayload.setAssetType(assetType);
    assetModelPayload.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModelPayload.setLabel(ASSET_MODEL_LABEL);
    assetModelPayload.setTags(ASSET_MODEL_TAGS);
    assetModelPayload.setResources(
        createResourceWithDataAndInstanceModel(isDataRequired, isInstanceModelRequired));
    return assetModelPayload;
  }

  /**
   * creates resource object with specified parameters.
   * 
   * @param isDataRequired
   *          true if data required else false.
   * @param isInstanceModelRequired
   *          true if instance model required else false.
   * @return resource object
   */
  private LinkedHashMap<String, ResourceObject> createResourceWithDataAndInstanceModel(
      boolean isDataRequired, boolean isInstanceModelRequired) {
    LinkedHashMap<String, ResourceObject> resourceMap = new LinkedHashMap<>();
    ResourceObject resourceObject = new ResourceObject();
    if (isDataRequired) {
      ResourceData resourceData = new ResourceData();
      if (isInstanceModelRequired) {
        InstanceModel instanceModel = new InstanceModel();
        resourceData.setInstanceModel(instanceModel);
      }
      resourceObject.setData(resourceData);
    }
    resourceMap.put(RESOURCES_KEY, resourceObject);
    return resourceMap;
  }

  /**
   * Test find product model by id.
   */
  @Test
  public void testFindProductModelById() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    AssetModel assetModel = getAssetModels(1, assetModelId, false).get(0);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> monoAssetModelById = assetModelServiceImpl
        .findAssetModelById(assetModelId, AssetType.PRODUCT.value());

    // Then
    StepVerifier.create(monoAssetModelById).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test find all product model versions by id.
   */
  @Test
  public void testFindAllProductModelVersionsById() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    List<AssetModel> assetModels = getAssetModels(3, assetModelId, true);

    assetModels.get(0).setId(
        "PRODUCTMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(1).setId(
        "PRODUCTMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");
    assetModels.get(2).setId(
        "PRODUCTMODEL::68757a5d-c6c0-4d38-991b-dbea95e1a18b::68757a5d-c6c0-4d38-991b-dbea95e1a18b");

    Flux<AssetModel> assetModelFlux = Flux.fromIterable(assetModels);
    Mockito.when(repository.findLearningModels(Mockito.any())).thenReturn(assetModelFlux);

    // When
    Mono<List<AssetModelResponse>> assetModelList = assetModelServiceImpl
        .findAllVersionsById(assetModelId, AssetType.PRODUCT.value());

    // Then
    StepVerifier.create(assetModelList).assertNext(response -> {
      assertNotNull(response);
      assertEquals(assetModels.size(), response.size());
      verifyAssetModelResponse(assetModels.get(0), response.get(0));
    }).verifyComplete();
  }

  /**
   * Test find product model version by id.
   */
  @Test
  public void testFindProductModelVersionById() {
    // Given
    String assetModelId = "68757a5d-c6c0-4d38-991b-dbea95e1a18b";
    String assetModelVer = "22357a5d-c6c0-4d38-991b-dbea95e1a18b";
    AssetModel assetModel = getAssetModels(1, assetModelId, false).get(0);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl.findVersionById(assetModelId,
        assetModelVer, AssetType.PRODUCT.value());

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }

  /**
   * Test create asset models with resource and data and config.
   */
  @Test
  public void testCreateAssetModelsWithConfig() {
    // Given
    AssetModel assetModel = createAssetModel(null, false);
    Mockito.when(repository.save(Mockito.any())).thenReturn(Mono.just(assetModel));
    Configuration configuration = new Configuration();
    configuration.put(POLICY_GROUPS, Arrays.asList("TITLE_GUID"));
    AssetModelPayload payload = createLearningModelPayloadWithResource(true, false,
        AssetType.INSTRUCTION.value());
    payload.setConfiguration(configuration);

    // When
    Mono<AssetModelResponse> assetModelMono = assetModelServiceImpl.createAssetModels(payload);

    // Then
    StepVerifier.create(assetModelMono).assertNext(response -> {
      assertNotNull(response);
      verifyAssetModelResponse(assetModel, response);
    }).verifyComplete();
  }
}