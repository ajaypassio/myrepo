/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.services;

import static com.pearson.glp.lpb.constant.CommonConstants.CLOSE_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.ID;
import static com.pearson.glp.lpb.constant.CommonConstants.OPEN_PARANTHESIS;
import static com.pearson.glp.lpb.constant.CommonConstants.SELF;
import static com.pearson.glp.lpb.constant.CommonConstants.VER;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.constant.TestingConstants;
import com.pearson.glp.lpb.data.model.Link;
import com.pearson.glp.lpb.data.model.Links;
import com.pearson.glp.lpb.data.model.Task;
import com.pearson.glp.lpb.data.model.TaskResource;
import com.pearson.glp.lpb.data.repository.TaskRepository;
import com.pearson.glp.lpb.services.impl.TaskServiceImpl;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class TaskServiceImplTest.
 *
 * @author sankalp.katiyar
 */
public class TaskServiceImplTest implements CommonUtils {

  /** The task service. */
  @InjectMocks
  private TaskServiceImpl taskService;

  /** The task repository. */
  @Mock
  private TaskRepository taskRepository;

  /** The task id. */
  private String taskId = null;

  /** The task. */
  private Task task = null;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
    task = new Task();
    taskId = UUID.randomUUID().toString();
    prepareTask(taskId);
  }

  /**
   * Test find task by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testFindTaskById() throws ServiceException {
    // Given
    Mockito.when(taskRepository.findBy_id(taskId)).thenReturn(Mono.just(task));

    // When
    Mono<Task> taskResponse = taskService.findTaskBy_Id(taskId);

    // Then
    StepVerifier.create(taskResponse).thenConsumeWhile(response -> {
      Assert.assertNotNull(response);
      return true;
    }).verifyComplete();
  }

  /**
   * Prepare task.
   *
   * @param taskId
   *          the task id
   */
  private void prepareTask(String taskId) {
    task.setId(UUID.randomUUID().toString());
    task.setStatus(TestingConstants.RUNNING_STATUS);
    task.setLinks(prepareLinks(TestingConstants.TASK_BYID_ROUTE, taskId, ""));
    TaskResource resource = new TaskResource();
    String resourceId = UUID.randomUUID().toString();
    String resourceVer = UUID.randomUUID().toString();
    resource.setId(resourceId);
    resource.setBssVer(1);
    resource.setVer(resourceVer);
    Links links = prepareLinks(TestingConstants.GET_PRODUCT_BY_VERSION_URL, resourceId,
        resourceVer);
    resource.setLinks(links);
    List<TaskResource> resources = new ArrayList<>();
    resources.add(resource);
    task.setResources(resources);
  }

  /**
   * Prepare links.
   *
   * @param url
   *          the url
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the links
   */
  private Links prepareLinks(String url, String id, String version) {
    url = url.replace(OPEN_PARANTHESIS + ID + CLOSE_PARANTHESIS, id);
    url = url.replace(OPEN_PARANTHESIS + VER + CLOSE_PARANTHESIS, version);
    Links links = new Links();
    Link link = new Link();
    link.setHref(url);
    links.put(SELF, link);
    return links;
  }

}
