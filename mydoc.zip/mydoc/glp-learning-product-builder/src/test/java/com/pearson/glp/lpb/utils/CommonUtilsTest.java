/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_EXPIRES_ON;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_LABEL;
import static com.pearson.glp.lpb.constant.TestingConstants.ASSET_MODEL_TAGS;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.UUID;

import org.junit.Test;

import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.dto.request.AssetModelPayload;
import com.pearson.glp.lpb.enums.AssetType;

// TODO: Auto-generated Javadoc
/**
 * The Class CommonUtilsTest.
 * 
 * @author sourabh.aggarwal
 */
public class CommonUtilsTest {

  /**
   * Instantiates a new common utils test.
   */
  public CommonUtilsTest() {
    super();
  }

  /**
   * Test map object.
   */
  @Test
  public void testMapObject() {
    // Given
    AssetModelPayload assetModelPayload = createAssetModelPayload();

    // When
    AssetModel assetModel = CommonUtils.mapObject(assetModelPayload, AssetModel.class);

    // Then
    assertNotNull(assetModel);
    assertEquals(ASSET_MODEL_LABEL, assetModel.getLabel());
    assertEquals(ASSET_MODEL_TAGS, assetModel.getTags());
  }

  /**
   * Creates the asset model payload.
   *
   * @return the asset model payload
   */
  private AssetModelPayload createAssetModelPayload() {
    AssetModelPayload assetModelPayload = new AssetModelPayload();
    assetModelPayload.setAssetType(AssetType.INSTRUCTION.value());
    assetModelPayload.setExpiresOn(ASSET_MODEL_EXPIRES_ON);
    assetModelPayload.setLabel(ASSET_MODEL_LABEL);
    assetModelPayload.setTags(ASSET_MODEL_TAGS);
    return assetModelPayload;
  }

  /**
   * Gets the uuid.
   *
   * @return the uuid
   */
  public static String getUuid() {
    return UUID.randomUUID().toString();
  }
}