/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.TestingConstants.EMPTY_RESPONSE;
import static org.hamcrest.CoreMatchers.is;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;

import reactor.test.StepVerifier;

/**
 * The Class ValidationUtilTest.
 */
public class HandlerValidationUtilTest {

  /** The errorUserDesc 400. */
  @Value("${errorUserDesc.400}")
  private String errorUserDesc400;

  /** The errorUserDesc 404. */
  @Value("${errorUserDesc.404}")
  private String errorUserDesc404;

  /** The errorUserDesc 405. */
  @Value("${errorUserDesc.405}")
  private String errorUserDesc405;

  /** The errorUserDesc 500. */
  @Value("${errorUserDesc.500}")
  private String errorUserDesc500;

  /** The errorUserDesc 415. */
  @Value("${errorUserDesc.415}")
  private String errorUserDesc415;

  /** The errorUserDesc 406. */
  @Value("${errorUserDesc.406}")
  private String errorUserDesc406;

  /**
   * Instantiates a new handler validation util test.
   */
  public HandlerValidationUtilTest() {
    super();
  }

  /** The validation util. */
  @InjectMocks
  private HandlerValidationUtil validationUtil;

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test empty response.
   */
  @Test
  public void testEmptyResponse() {

    StepVerifier.create(validationUtil.emptyResponse()).assertNext(
        res -> Assert.assertThat(EMPTY_RESPONSE, res.getStatus(), is(HttpStatus.NOT_FOUND.value())))
        .verifyComplete();
  }

  /**
   * Test prepare not found response.
   */
  @Test
  public void testPrepareNotFoundResponse() {
    PlatformErrorResponse response = new PlatformErrorResponse();
    response.setStatus(HttpStatus.NOT_FOUND.value());
    response.setError(HttpStatus.NOT_FOUND.getReasonPhrase());
    response.setMessage(errorUserDesc404);
    PlatformErrorResponse responseReturned = validationUtil.prepareNotFoundResponse();

    Assert.assertEquals(response.getError(), responseReturned.getError());

  }

  /**
   * Test prepare bad request response.
   */
  @Test
  public void testPrepareBadRequestResponse() {
    PlatformErrorResponse response = new PlatformErrorResponse();
    response.setStatus(HttpStatus.BAD_REQUEST.value());
    response.setError(HttpStatus.BAD_REQUEST.getReasonPhrase());
    response.setMessage(errorUserDesc400);
    PlatformErrorResponse responseReturned = validationUtil.prepareBadRequestResponse();

    Assert.assertEquals(response.getError(), responseReturned.getError());

  }

  /**
   * Prepare Method not allowed response.
   *
   * @return the error response
   */
  @Test
  public void testPrepareMethodNotAllowedResponse() {
    PlatformErrorResponse response = new PlatformErrorResponse();
    response.setStatus(HttpStatus.METHOD_NOT_ALLOWED.value());
    response.setError(HttpStatus.METHOD_NOT_ALLOWED.getReasonPhrase());
    response.setMessage(errorUserDesc405);
    PlatformErrorResponse responseReturned = validationUtil.prepareMethodNotAllowedResponse();

    Assert.assertEquals(response.getError(), responseReturned.getError());
  }

  /**
   * Test prepare server error response.
   */
  @Test
  public void testPrepareServerErrorResponse() {
    String message = "There is an internal server error";
    PlatformErrorResponse errorResponse = new PlatformErrorResponse();
    errorResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
    errorResponse.setError(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    errorResponse.setMessage(errorUserDesc500);
    PlatformErrorResponse responseReturned = validationUtil.prepareServerErrorResponse(message);

    Assert.assertEquals(errorResponse.getError(), responseReturned.getError());

  }

  /**
   * Test prepare unsupported media type response.
   */
  @Test
  public void testPrepareUnsupportedMediaTypeResponse() {
    PlatformErrorResponse response = new PlatformErrorResponse();
    response.setStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value());
    response.setError(HttpStatus.UNSUPPORTED_MEDIA_TYPE.getReasonPhrase());
    response.setMessage(errorUserDesc415);
    PlatformErrorResponse responseReturned = validationUtil.prepareUnsupportedMediaTypeResponse();

    Assert.assertEquals(response.getError(), responseReturned.getError());
  }

  /**
   * Testprepare media type not acceptable response.
   */
  @Test
  public void testprepareMediaTypeNotAcceptableResponse() {
    PlatformErrorResponse response = new PlatformErrorResponse();
    response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
    response.setError(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase());
    response.setMessage(errorUserDesc406);
    PlatformErrorResponse responseReturned = validationUtil.prepareMediaTypeNotAcceptableResponse();

    Assert.assertEquals(response.getError(), responseReturned.getError());
  }

}