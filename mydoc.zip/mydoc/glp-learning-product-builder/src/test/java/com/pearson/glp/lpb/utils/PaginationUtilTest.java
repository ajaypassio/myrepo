/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.utils;

import static com.pearson.glp.lpb.constant.LoggingConstants.ERROR_PAGE_SIZE_AND_PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.TestingConstants.ERROR_MAX_PAGE_SIZE;
import static com.pearson.glp.lpb.constant.TestingConstants.ERROR_PAGE_NUMBER;
import static com.pearson.glp.lpb.constant.TestingConstants.ERROR_PAGE_SIZE;
import static org.junit.Assert.assertEquals;

import java.lang.reflect.Field;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

/**
 * The Class PaginationUtilTest.
 */
public class PaginationUtilTest {

  /** The non numeric string. */
  private String nonNumericString;

  /** The positive numeric. */
  private String positiveNumeric;

  /** The negative numeric. */
  private String negativeNumeric;

  /** The invalid per max page size. */
  private String invalidPerMaxPageSize;

  /** The zero numeric. */
  private String zeroNumeric;

  /**
   * Instantiates a new pagination util test.
   */
  public PaginationUtilTest() {
    super();
  }

  /** The pagination util. */
  @InjectMocks
  private PaginationUtil paginationUtil;

  /**
   * Before method.
   *
   * @throws InstantiationException
   *           the instantiation exception
   * @throws IllegalAccessException
   *           the illegal access exception
   * @throws NoSuchFieldException
   *           the no such field exception
   * @throws SecurityException
   *           the security exception
   */
  @Before
  public void beforeMethod() throws InstantiationException, IllegalAccessException,
      NoSuchFieldException, SecurityException {

    nonNumericString = "TEST";
    positiveNumeric = "2";
    negativeNumeric = "-1";
    invalidPerMaxPageSize = "51";
    zeroNumeric = "0";

    MockitoAnnotations.initMocks(this);
    Field defaultPageNumber = paginationUtil.getClass().getDeclaredField("defaultPageNumber");
    defaultPageNumber.setAccessible(true);
    defaultPageNumber.set(paginationUtil, 1);
    Field defaultPageSize = paginationUtil.getClass().getDeclaredField("defaultPageSize");
    defaultPageSize.setAccessible(true);
    defaultPageSize.set(paginationUtil, 20);
    Field defaultMaxPageSize = paginationUtil.getClass().getDeclaredField("defaultMaxPageSize");
    defaultMaxPageSize.setAccessible(true);
    defaultMaxPageSize.set(paginationUtil, 50);
  }

  /**
   * Test validate pagination.
   */
  @Test
  public void testValidatePagination() {

    String errorMsg = paginationUtil.validatePagination(positiveNumeric, positiveNumeric);
    assertEquals(StringUtils.EMPTY, errorMsg);

    errorMsg = paginationUtil.validatePagination(StringUtils.EMPTY, positiveNumeric);
    assertEquals(StringUtils.EMPTY, errorMsg);

    errorMsg = paginationUtil.validatePagination(positiveNumeric, StringUtils.EMPTY);
    assertEquals(StringUtils.EMPTY, errorMsg);

    errorMsg = paginationUtil.validatePagination(negativeNumeric, negativeNumeric);
    assertEquals(ERROR_PAGE_SIZE_AND_PAGE_NUMBER, errorMsg);

    errorMsg = paginationUtil.validatePagination(nonNumericString, positiveNumeric);
    assertEquals(ERROR_PAGE_SIZE, errorMsg);

    errorMsg = paginationUtil.validatePagination(zeroNumeric, positiveNumeric);
    assertEquals(ERROR_PAGE_SIZE, errorMsg);

    errorMsg = paginationUtil.validatePagination(positiveNumeric, nonNumericString);
    assertEquals(ERROR_PAGE_NUMBER, errorMsg);

    errorMsg = paginationUtil.validatePagination(positiveNumeric, zeroNumeric);
    assertEquals(ERROR_PAGE_NUMBER, errorMsg);

    errorMsg = paginationUtil.validatePagination(invalidPerMaxPageSize, positiveNumeric);
    assertEquals(ERROR_MAX_PAGE_SIZE, errorMsg);

    errorMsg = paginationUtil.validatePagination(nonNumericString, nonNumericString);
    assertEquals(ERROR_PAGE_SIZE_AND_PAGE_NUMBER, errorMsg);

    errorMsg = paginationUtil.validatePagination(zeroNumeric, zeroNumeric);
    assertEquals(ERROR_PAGE_SIZE_AND_PAGE_NUMBER, errorMsg);
  }

  /**
   * Test get offset.
   */
  @Test
  public void testGetOffset() {

    int offset = paginationUtil.getOffset(positiveNumeric);
    assertEquals(positiveNumeric, String.valueOf(offset));

    offset = paginationUtil.getOffset(zeroNumeric);
    assertEquals("1", String.valueOf(offset));
  }

  /**
   * Test get limit.
   */
  @Test
  public void testGetLimit() {

    int limitValue = paginationUtil.getLimit(positiveNumeric);
    assertEquals(positiveNumeric, String.valueOf(limitValue));

    limitValue = paginationUtil.getLimit(zeroNumeric);
    assertEquals("20", String.valueOf(limitValue));
  }

  /**
   * Test prepare page size.
   */
  @Test
  public void testPreparePageSize() {

    String pageSize = paginationUtil.preparePageSize(positiveNumeric);
    assertEquals(positiveNumeric, String.valueOf(pageSize));

    pageSize = paginationUtil.preparePageSize(StringUtils.EMPTY);
    assertEquals("20", String.valueOf(pageSize));
  }

  /**
   * Test prepare page number.
   */
  @Test
  public void testPreparePageNumber() {

    String pageNumber = paginationUtil.preparePageNumber(positiveNumeric);
    assertEquals(positiveNumeric, String.valueOf(pageNumber));

    pageNumber = paginationUtil.preparePageNumber(StringUtils.EMPTY);
    assertEquals("1", String.valueOf(pageNumber));
  }

}