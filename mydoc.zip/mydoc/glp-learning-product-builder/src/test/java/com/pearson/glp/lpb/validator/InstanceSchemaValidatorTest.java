/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.LMValidationConstants.AND_VERSION;
import static com.pearson.glp.lpb.constant.LMValidationConstants.OF_RESOURCE_ID;
import static com.pearson.glp.lpb.constant.LoggingConstants.MANDATORY_FIELD_FOR_RESOURCE_ID;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION;
import static com.pearson.glp.lpb.constant.TestingConstants.SAMPLE_INSTRUCTIONS_PRIMITIVE_JSON;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.lm.resources.InstanceSchema;
import com.pearson.glp.lpb.data.model.lm.resources.PropertyType;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.utils.CommonUtils;

/**
 * The Class InstanceSchemaValidatorTest.
 * 
 * @author srishti.singh
 */
public class InstanceSchemaValidatorTest implements CommonUtils {

  /** The Constant ASSET_TYPE. */
  private static final String ASSET_TYPE = "_assetType";

  /** The Constant DOC_TYPE. */
  private static final String DOC_TYPE = "_docType";

  /** The validator. */
  private InstanceSchemaValidator validator;

  /** The asset. */
  private NonPrimitiveAsset asset;

  /** The resource data. */
  private ResourceData resourceData;

  /**
   * Setup.
   */
  @Before
  public void setup() {
    validator = new InstanceSchemaValidator();
    asset = getLearningAsset(SAMPLE_INSTRUCTIONS_PRIMITIVE_JSON);
    resourceData = createResourceData();
  }

  /**
   * Test instance schema validation.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testInstanceSchemaValidation() throws Exception {
    List<String> result = validator.validateInstanceSchema(resourceData, asset);
    assertNotNull(result);
    assertEquals(0, result.size());
  }

  /**
   * Test instance schema validation with incorrect asset type.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testInstanceSchemaValidationWithIncorrectAssetType() throws Exception {
    asset.setAssetType(AssetType.AGGREGATE.name());
    List<String> result = validator.validateInstanceSchema(resourceData, asset);
    assertNotNull(result);
    assertEquals(1, result.size());
    String expected = ASSET_TYPE + OF_RESOURCE_ID + asset.get_id() + AND_VERSION + asset.getVer()
        + " must match the enum value(s) " + String.join(", ",
            resourceData.getInstanceSchema().getProperties().get(ASSET_TYPE).getEnumVal());
    assertEquals(expected, result.get(0));
  }

  /**
   * Test instance schema validation with missing asset type.
   *
   * @throws Exception
   *           the exception
   */
  @Test
  public void testInstanceSchemaValidationWithMissingAssetType() throws Exception {
    asset.setAssetType(null);
    List<String> result = validator.validateInstanceSchema(resourceData, asset);
    assertNotNull(result);
    assertEquals(1, result.size());
    String expected = ASSET_TYPE + MANDATORY_FIELD_FOR_RESOURCE_ID + asset.get_id() + AND_VERSION
        + asset.getVer();
    assertEquals(expected, result.get(0));
  }

  /**
   * Gets the learning asset.
   *
   * @param fileName
   *          the file name
   * @return the learning asset
   */
  private NonPrimitiveAsset getLearningAsset(String fileName) {
    try {
      NonPrimitiveAsset asset = convertJsonToObject(fileName, NonPrimitiveAsset.class);
      return asset;
    } catch (ServiceException e) {
      return new NonPrimitiveAsset();
    }
  }

  /**
   * Creates the resource data.
   *
   * @return the resource data
   */
  private ResourceData createResourceData() {
    // create key pattern
    ResourceData data = new ResourceData();
    data.setKeyPattern("SLATE-[0-9]+");
    List<String> required = Arrays.asList(DOC_TYPE, ASSET_TYPE);
    Map<String, PropertyType> properties = new HashMap<>();
    String type = "string";
    PropertyType docTypeProperty = new PropertyType(type, Arrays.asList("LEARNINGCONTENT"));
    properties.put(DOC_TYPE, docTypeProperty);
    PropertyType assetTypeProperty = new PropertyType(type, Arrays.asList(INSTRUCTION));
    properties.put(ASSET_TYPE, assetTypeProperty);
    PropertyType resourceTypeProperty = new PropertyType(type, Arrays.asList("LEARNINGASSET"));
    properties.put("_resourceType", resourceTypeProperty);
    InstanceSchema instanceSchema = new InstanceSchema("object", required, properties);
    data.setInstanceSchema(instanceSchema);

    return data;
  }

}
