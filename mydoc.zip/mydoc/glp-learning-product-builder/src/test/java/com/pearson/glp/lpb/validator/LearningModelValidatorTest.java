/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.lpb.validator;

import static com.pearson.glp.lpb.constant.TestingConstants.CONTENTMETADATA;
import static com.pearson.glp.lpb.constant.TestingConstants.INSTRUCTION;
import static com.pearson.glp.lpb.constant.TestingConstants.NARRATIVES_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.SAMPLE_INSTRUCTIONS_PRIMITIVE_JSON;
import static com.pearson.glp.lpb.constant.TestingConstants.SLATE_1;
import static com.pearson.glp.lpb.constant.TestingConstants.SLATE_1_INCORRECT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Optional;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;
import com.pearson.glp.lpb.data.model.AssetModel;
import com.pearson.glp.lpb.data.model.ContentMetadata;
import com.pearson.glp.lpb.data.model.NonPrimitiveAsset;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceData;
import com.pearson.glp.lpb.data.model.lm.resources.ResourceObject;
import com.pearson.glp.lpb.data.repository.LearningModelRepository;
import com.pearson.glp.lpb.data.repository.NonPrimitiveAssetRepository;
import com.pearson.glp.lpb.dto.request.NonPrimitiveAssetPayload;
import com.pearson.glp.lpb.dto.response.AssetResponse;
import com.pearson.glp.lpb.dto.response.PlatformErrorResponse;
import com.pearson.glp.lpb.enums.AssetType;
import com.pearson.glp.lpb.enums.PlatformErrorCode;
import com.pearson.glp.lpb.utils.CacheUtils;
import com.pearson.glp.lpb.utils.CommonUtils;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class AssetAndModelValidatorTest.
 * 
 * @author srishti.singh
 */
public class LearningModelValidatorTest implements CommonUtils {

  /** The Constant COMMA. */
  private static final String COMMA = ",";

  /** The Constant NARRATIVE_1. */
  private static final String NARRATIVE_1 = "NARRATIVE-1";

  /** The Constant ASSET_CLASS. */
  private static final String ASSET_CLASS = INSTRUCTION + COMMA + NARRATIVE_1;

  /** The validator. */
  @InjectMocks
  private LearningModelValidator validator;

  /** The repository. */
  @Mock
  private NonPrimitiveAssetRepository repository;

  /** The isc sync client. */
  @Mock
  private IscSyncClient iscSyncClient;

  /** The asset repo. */
  @Mock
  private LearningModelRepository assetRepo;

  /** The instance schema validator. */
  @Mock
  private InstanceSchemaValidator instanceSchemaValidator;

  /** The category schema validator. */
  @Mock
  private CategorySchemaValidator categorySchemaValidator;

  @Mock
  private CacheUtils cacheService;

  /** The asset payload. */
  private NonPrimitiveAsset assetPayload;

  /** The asset payload. */
  private NonPrimitiveAsset primitiveAssetPayload;

  /**
   * Setup that executes before running every test method.
   */
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    assetPayload = getLearningAsset(SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON);
    primitiveAssetPayload = getLearningAsset(SAMPLE_INSTRUCTIONS_PRIMITIVE_JSON);
    Mockito.when(instanceSchemaValidator.validateInstanceSchema(Mockito.any(), Mockito.any()))
        .thenReturn(Collections.emptyList());
    Mockito.when(cacheService.get(Mockito.any(), Mockito.any()))
        .thenReturn(Optional.of(createLearningModel()));
  }

  /**
   * Creates the learning model.
   *
   * @return the mono
   */
  private AssetModel createLearningModel() {
    // create key pattern
    ResourceData data = new ResourceData();
    data.setKeyPattern("SLATE-[0-9]+");
    // create resource object
    ResourceObject resourceObj = new ResourceObject();
    resourceObj.setData(data);
    // create resources
    LinkedHashMap<String, ResourceObject> resources = new LinkedHashMap<>();
    resources.put(UUID.randomUUID().toString(), resourceObj);
    AssetModel model = new AssetModel();
    model.setResources(resources);
    model.setAssetClass(INSTRUCTION);
    return model;
  }

  /**
   * Creates the learning model primitive.
   *
   * @return the mono
   */
  private Mono<AssetModel> createLearningModelPrimitive() {
    // create key pattern
    ResourceData data = new ResourceData();
    data.setKeyPattern("NARRATIVE-[0-9]+");
    // create resource object
    ResourceObject resourceObj = new ResourceObject();
    resourceObj.setData(data);
    // create resources
    LinkedHashMap<String, ResourceObject> resources = new LinkedHashMap<>();
    resources.put(UUID.randomUUID().toString(), resourceObj);

    AssetModel model = new AssetModel();
    model.setResources(resources);
    model.setAssetClass(INSTRUCTION);
    return Mono.just(model);
  }

  /**
   * Gets the learning asset.
   *
   * @param fileName
   *          the file name
   * @return the learning asset
   */
  private NonPrimitiveAsset getLearningAsset(String fileName) {
    NonPrimitiveAsset asset;
    try {
      NonPrimitiveAssetPayload payload = convertJsonToObject(fileName,
          NonPrimitiveAssetPayload.class);
      asset = new NonPrimitiveAsset(payload);
      asset.getExtensions().put(CONTENTMETADATA, payload.getContentMetadata());
      return asset;
    } catch (ServiceException e) {
      return new NonPrimitiveAsset();
    }
  }

  /**
   * Test validation with resource from DB.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithResourceFromDB() throws ServiceException {
    // Given
    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setLabel(SLATE_1);
    data.setAssetClass(SLATE_1);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(assetPayload);

    // Then
    StepVerifier.create(assetResponse).expectComplete().verify();
  }

  /**
   * Test validation with resource from LAP.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithResourceFromLAP() throws ServiceException {
    // Given
    NonPrimitiveAsset data = getLearningAsset(NARRATIVES_JSON);
    data.setAssetType(AssetType.NARRATIVE.value());
    data.setLabel(NARRATIVE_1);
    data.setAssetClass(NARRATIVE_1);
    Mockito.when(cacheService.get(Mockito.any(), Mockito.any())).thenReturn(Optional.empty());
    Mockito.when(assetRepo.findById(Mockito.anyString()))
        .thenReturn(createLearningModelPrimitive());
    Mockito.when(
        iscSyncClient.getObject(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(data));

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(primitiveAssetPayload);

    // Then
    StepVerifier.create(assetResponse).expectComplete().verify();
  }

  /**
   * Test validation for incorrect key pattern.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationForIncorrectKeyPattern() throws ServiceException {
    // Given
    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setAssetClass(SLATE_1_INCORRECT);
    /*
     * Mockito.when(assetRepo.findById(Mockito.anyString()))
     * .thenReturn(Mono.just(createLearningModel()));
     */
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(assetPayload);

    // Then
    verifyBadRequest(assetResponse,
        (ContentMetadata) assetPayload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Test validation with exception in fetching resource.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithExceptionInFetchingResource() throws ServiceException {
    // Given
    Mockito.when(assetRepo.findById(Mockito.anyString()))
        .thenReturn(Mono.just(createLearningModel()));
    Mockito.when(
        iscSyncClient.getObject(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new RuntimeException()));

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(primitiveAssetPayload);

    // Then
    verifyBadRequest(assetResponse,
        (ContentMetadata) primitiveAssetPayload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Test validation with exception in fetching resource 1.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithExceptionInFetchingProductResource() throws ServiceException {
    // Given

    AssetModel assetModel = createLearningModel();
    assetModel.setAssetType(AssetType.PRODUCT.value());
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(assetModel));
    Mockito.when(
        iscSyncClient.getObject(Mockito.anyString(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new RuntimeException()));
    primitiveAssetPayload.getLearningModel().setAssetType(AssetType.PRODUCT.value());
    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(primitiveAssetPayload);

    // Then
    verifyBadRequest(assetResponse,
        (ContentMetadata) primitiveAssetPayload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Test validation for LA with learning model not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationForLAWithLearningModelNotFound() throws ServiceException {
    // Given
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.empty());

    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setLabel(SLATE_1);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));

    // When
    NonPrimitiveAsset nonPrimitiveAssetPayload = getLearningAsset(
        SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON);
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(nonPrimitiveAssetPayload);

    // Then
    verifyBadRequest(assetResponse,
        (ContentMetadata) nonPrimitiveAssetPayload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Test validation for LA with resource not found.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationForLAWithResourceNotFound() throws ServiceException {
    // Given
    Mockito.when(assetRepo.findById(Mockito.anyString()))
        .thenReturn(Mono.just(createLearningModel()));
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.empty());

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(assetPayload);

    // Then
    verifyBadRequest(assetResponse,
        (ContentMetadata) assetPayload.getExtensions().get(CONTENTMETADATA));
  }

  @Test
  public void testValidationForProductLA() throws ServiceException {
    // Given
    Mockito.when(cacheService.get(Mockito.any(), Mockito.any())).thenReturn(Optional.empty());
    AssetModel learningModel = createLearningModel();
    learningModel.setAssetType(AssetType.PRODUCT.value());
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(learningModel));

    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setLabel(SLATE_1);
    data.setAssetClass(SLATE_1);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));
    assetPayload.getLearningModel().setAssetType(AssetType.PRODUCT.value());

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(assetPayload);

    // Then
    StepVerifier.create(assetResponse).expectComplete().verify();
  }

  /**
   * Test validation with incorrect payload asset class.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithIncorrectPayloadAssetClass() throws ServiceException {
    // Given
    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setAssetClass(SLATE_1);

    NonPrimitiveAsset payload = getLearningAsset(SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON);
    payload.setAssetClass(SLATE_1);

    AssetModel learningModel = createLearningModel();
    learningModel.setAssetClass(ASSET_CLASS);
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(learningModel));
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));

    // When
    Mono<AssetResponse> assetResponse = validator.validateLearningAssetWithLearningModel(payload);

    // Then
    verifyBadRequest(assetResponse, (ContentMetadata) payload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Test validation with null asset class.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithNullAssetClass() throws ServiceException {
    // Given
    AssetModel learningModel = createLearningModel();
    learningModel.setAssetClass(null);
    Mockito.when(assetRepo.findById(Mockito.anyString())).thenReturn(Mono.just(learningModel));

    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setAssetClass(null);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));

    NonPrimitiveAsset payload = getLearningAsset(SAMPLE_INSTRUCTIONS_NON_PRIMITIVE_JSON);
    payload.setAssetClass(null);

    // When
    Mono<AssetResponse> assetResponse = validator.validateLearningAssetWithLearningModel(payload);

    // Then
    verifyBadRequest(assetResponse, (ContentMetadata) payload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Test validation with instance schema error.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testValidationWithInstanceSchemaError() throws ServiceException {
    // Given
    NonPrimitiveAsset data = new NonPrimitiveAsset();
    data.setAssetType(AssetType.INSTRUCTION.value());
    data.setAssetClass(SLATE_1);
    Mockito.when(repository.findById(Mockito.anyString())).thenReturn(Mono.just(data));
    Mockito.when(instanceSchemaValidator.validateInstanceSchema(Mockito.any(), Mockito.any()))
        .thenReturn(Arrays.asList("Instance Schema Error."));

    // When
    Mono<AssetResponse> assetResponse = validator
        .validateLearningAssetWithLearningModel(assetPayload);

    // Then
    verifyBadRequest(assetResponse,
        (ContentMetadata) assetPayload.getExtensions().get(CONTENTMETADATA));
  }

  /**
   * Verify bad request.
   *
   * @param assetResponse
   *          the asset response
   * @param contentMetadata
   *          the content metadata
   */
  private void verifyBadRequest(Mono<AssetResponse> assetResponse,
      ContentMetadata contentMetadata) {
    StepVerifier.create(assetResponse).assertNext(resp -> {
      assertNotNull(resp);
      assertEquals(contentMetadata, resp.getContentMetadata());
      PlatformErrorResponse error = resp.getError();
      assertEquals(HttpStatus.BAD_REQUEST.value(), error.getStatus().intValue());
      assertEquals(PlatformErrorCode.INVALID_REQUEST.getErrorCode(), error.getError());
    }).verifyComplete();
  }

}