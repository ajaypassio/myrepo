package contracts.aggregatesById.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  priority 1
  description "."
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/aggregates/8883c099-1762-43fe-9ad8-4c9aaa6eafa2'))))
    headers { header('''Accept''', '''application/json''') }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._id', byRegex(uuid()))
      jsonPath('$._bssVer', byType())
      jsonPath('$._ver', byRegex(uuid()))
      jsonPath('$._created', byType())
      jsonPath('$._createdBy', byType())
      jsonPath('$._lastModified', byType())
      jsonPath('$._docType', byType())
      jsonPath('$._assetType', byType())
      jsonPath('$.learningModel', byType())
      jsonPath('$.tags', byType())
      jsonPath('$.label', byType())
      jsonPath('$.language', byType())
      jsonPath('$.assetClass', byType())
      jsonPath('$.objectives', byType())
      jsonPath('$.groups', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.resourcePlan', byType())
      jsonPath('$.resourcePlan[*].label',byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetGraph', byType())
      jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.configuration', byType())
      jsonPath('$.constraints', byType())
      jsonPath('$.extends', byType())
      jsonPath('$.extensions', byType())
      jsonPath('$.scope', byType())
      jsonPath('$._links', byType())
      jsonPath('$._links.self', byType())
      jsonPath('$._links.self.href', byType())
    }

    body('''
		{
 "_id": "8883c099-1762-43fe-9ad8-4c9aaa6eafa2",
 "_bssVer": 1,
 "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
 "_created": "2018-11-27T04:10:50+00:00",
 "_createdBy": "Admin",
 "_lastModified": "2018-11-27T04:10:50+00:00",
 "_docType": "LEARNINGCONTENT",
 "_assetType": "AGGREGATE",
"learningModel": {
"_resourceType": "LEARNINGASSET",
"_docType": "LEARNINGMODEL",
"_assetType": "AGGREGATE",
"_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
"_bssVer": 1,
"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
"_links": {
"self": {
"href": "/v2/assetModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
}
}
},
"tags" : "REVEL",
"label" :"CHAPTER",
"language" : "en-US",
"assetClass" : "",
"objectives" : "",
"groups" : {},
 "resources": {
 "1cecce8a-1fba-4c64-bc28-0d05324bd507": {
 "_id": "1cecce8a-1fba-4c64-bc28-0d05324bd507",
 "_bssVer": 1,
 "createdBy": "Admin",
 "_ver": "bed61c15-fd56-46cd-bce8-9ad534bc9bd9",
 "_resourceType": "LEARNINGASSET",
"_docType": "LEARNINGCONTENT",
"_assetType": "AGGREGATE",
 "_links": {
 "self": {
 "href": "/v2/aggregates/1cecce8a-1fba-4c64-bc28-0d05324bd507/versions/bed61c15-fd56-46cd-bce8-9ad534bc9bd9"
 }
 }
 },
 "1e00862f-e218-43c4-8166-10254790c88d": {
 "_id": "1e00862f-e218-43c4-8166-10254790c88d",
 "_bssVer": 1,
 "createdBy": "Admin",
 "_ver": "64dc3b6b-7f3e-4db0-80a4-4e5e351295d6",
 "_resourceType": "LEARNINGASSET",
 "_docType": "LEARNINGCONTENT",
 "_assetType": "AGGREGATE",
 "_links": {
 "self": {
 "href": "/v2/aggregates/1e00862f-e218-43c4-8166-10254790c88d/versions/64dc3b6b-7f3e-4db0-80a4-4e5e351295d6"
 }
 }
 }
 },
 "resourcePlan": [
 {
 "label": "",
 "resourceElementType": "HEADING",
 "resourceRef": "",
 "resourceElements": [
 {
 "label": "slate1",
 "resourceElementType": "slate",
 "resourceElements": [],
 "resourceRef": "1cecce8a-1fba-4c64-bc28-0d05324bd507"
 },
 {
 "label": "slate2",
 "resourceElementType": "slate",
 "resourceElements": [],
 "resourceRef": "1e00862f-e218-43c4-8166-10254790c88d"
 }
 ]
 }
 ],
 "assetGraph": [
 {
 "startNode": "self",
 "endNode": "1cecce8a-1fba-4c64-bc28-0d05324bd507",
 "relationships": {}
 },
 {
 "startNode": "1cecce8a-1fba-4c64-bc28-0d05324bd507",
 "endNode": "1e00862f-e218-43c4-8166-10254790c88d",
 "relationships": {}
 }
 ],
 "configuration": {},
 "constraints": [],
 "extends": {},
 "extensions": {},
 "scope": {},
 "_links": {
 "self": {
 "href": "/v2/aggregates/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
 }
 }
}
''')
  }
}