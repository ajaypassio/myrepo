package contracts.assessments.error400;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Error 400"
	request {
		method GET()
		urlPath('/lpb/v2/assessments') {
			queryParameters { parameter ("extension.contentMetdata.id", value(consumer(matching("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")), producer("0016f24c-f2c5-440c-8f13-c12648411e97"))) }
		}
		headers {
			header('''Accept''', applicationJson())
        }
    }
    response {
    	headers { contentType('''application/hal+json; charset=UTF-8''') }
        status 400
        bodyMatchers {
	      jsonPath('$.timestamp', byType())
	      jsonPath('$.status', byType())
	      jsonPath('$.error', byType())
	      jsonPath('$.message', byType())
        }
        body('''
			{
			  "timestamp": "2019-01-30T06:54:03+00:00",
			  "status": 400,
			  "error": "Bad Request",
			  "message": "Invalid URL. Mention valid search parameter."
			}
		''')
    }
    priority 2
}
