package contracts.assetModels.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    urlPath('/lpb/v2/assetModels')
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._count', byType())
      jsonPath('$.assetModels', byType())
      jsonPath('$.assetModels[*]._id', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
      jsonPath('$.assetModels[*]._ver', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._created', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._createdBy', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._lastModified', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._docType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._assetType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].expiresOn', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*]._links', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].tags', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].language', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].assetClass', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].objectives', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].groups', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*].resources', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*].assetGraph', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetModels[*].assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*].resourcePlan', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetModels[*].resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetModels[*].resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetModels[*].configuration', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*].constraints', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetModels[*].extends', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*].extensions', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assetModels[*].scope', byCommand('assertThatValueIsAMap($it)'))
    }
    body('''
        {
          "_count": 1,
          "assetModels": [
            {
              "_id": "9cc1ef68-a2f5-49ea-a70d-3c451f94bb99",
              "_bssVer": 1,
              "_ver": "a9b9ae2b-966c-4a66-a6ab-134d685cb99b",
              "_created": "2018-11-27T04:10:50+00:00",
              "_createdBy": "Admin",
              "_lastModified": "2018-11-27T04:10:50+00:00",
              "_docType": "LEARNINGMODEL",
              "_assetType": "INSTRUCTION",
              "expiresOn": "2020-12-12T18:29:50+00:00",
              "label": "INSTRUCTION",
              "tags": "REVEL",
              "language": "en_US",
              "assetClass": "",
              "objectives": "",
              "groups": {},
			  "resources": {
			    "d441ee2a-4475-4511-969c-80cbbeba553e": {
			      "_resourceType": "INLINED",
			      "category": "model",
			      "data": {
			        "keyPattern": "MODULE-5CS",
			        "categorySchema": {
			          "type": "object",
			          "minProperties": 1
			        },
			        "instanceSchema": {
			          "type": "object",
			          "required": [
			            "_docType",
			            "_assetType"
			          ],
			          "properties": {
			            "_resourceType": {
			              "type": "string",
			              "enum": [
			                "LEARNINGASSET"
			              ]
			            },
			            "_docType": {
			              "type": "string",
			              "enum": [
			                "LEARNINGCONTENT"
			              ]
			            },
			            "_assetType": {
			              "type": "string",
			              "enum": [
			                "AGGREGATE"
			              ]
			            }
			          }
			        },
			        "instanceModel": {
			          "_id": "ff3de5a6-6008-4e2f-a8df-489480040397",
			          "_bssVer": 1,
			          "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
			          "_resourceType": "LEARNINGASSET",
			          "_docType": "LEARNINGMODEL",
			          "_assetType": "AGGREGATE",
			          "_links": {
			            "self": {
			              "href": "/v2/assetModels/ff3de5a6-6008-4e2f-a8df-489480040397/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
			            }
			          }
			        }
			      }
			    }
			  },
              "assetGraph": [
                {
                  "startNode": "self",
                  "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                  "relationships": {}
                },
                {
                  "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                  "endNode": "self",
                  "relationships": {}
                }
              ],
              "resourcePlan": [
                {
                  "label": "SLATE",
                  "resourceElementType": "SLATE",
                  "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                  "resourceElements": []
                }
              ],
              "configuration": {},
              "constraints": [],
              "extends": {},
              "extensions": {},
              "scope": {},
              "_links": {
                "self": {
                  "href": "/v2/assetModels/9cc1ef68-a2f5-49ea-a70d-3c451f94bb99/versions/a9b9ae2b-966c-4a66-a6ab-134d685cb99b"
                }
              }
            }
         ]
        }
        ''')
  }
}