package contracts.entityByTaskId.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/tasks/'+uuid()+'/instructions'))))
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType(applicationJsonUtf8())  }
    status 207
    bodyMatchers {
      jsonPath('$._count', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.resources[*].entityStatus', byType())
      jsonPath('$.resources[*].contentMetadata', byType())
      jsonPath('$.resources[*].asset', byType())
      jsonPath('$.resources[*].asset._id', byRegex(uuid()))
      jsonPath('$.resources[*].asset._ver', byRegex(uuid()))
      jsonPath('$.resources[*].asset._bssVer', byType())
      jsonPath('$.resources[*].asset._docType', byCommand('assertThatDocTypesAreLearningContent($it)'))
      jsonPath('$.resources[*].asset._assetType', byCommand('assertThatAssetTypesAreInstruction($it)'))
      jsonPath('$.resources[*].asset._links', byType())
      jsonPath('$.resources[*].asset._links.self', byType())
      jsonPath('$.resources[*].asset._links.self.href', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resources[*].error', byType())
      jsonPath('$.resources[*].error.timestamp', byType())
      jsonPath('$.resources[*].error.status', byCommand('assertThatValueIsAInteger($it)'))
      jsonPath('$.resources[*].error.error', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resources[*].error.message', byCommand('assertThatValueIsAString($it)'))
    }
    body('''
  {
    "_count": 2,
    "resources": [
      {
        "entityStatus": "Success",
        "contentMetadata": {
          "id": "8883c099",
          "version": "16f6de1c"
        },
      "asset": {
      "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
      "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "_bssVer": 1,
      "_docType": "LEARNINGCONTENT",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
        "href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
        }
      }
      }
      },
      {
        "entityStatus": "Error",
        "contentMetadata": {
          "id": "8883c099-1762-43fe-9ad8-4c9aaa6eafa2sdfdfgdfgdf",
          "version": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae87sfd"
        },
        "error": {
          "timestamp": "2018-12-20T10:08:19+00:00",
          "status": 404,
          "error": "Object not found",
          "message": "Content URL is not available."
        }
      }
    ]
  }
        ''')
  }
}