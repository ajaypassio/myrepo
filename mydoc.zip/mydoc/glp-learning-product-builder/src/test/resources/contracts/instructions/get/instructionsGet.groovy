package contracts.instructions.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    urlPath('/lpb/v2/instructions')
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._count', byType())
      jsonPath('$.assets', byType())
      jsonPath('$.assets[*]._id', byRegex(uuid()))
      jsonPath('$.assets[*]._ver', byRegex(uuid()))
      jsonPath('$.assets[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
      jsonPath('$.assets[*]._createdBy', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assets[*]._docType', byCommand('assertThatDocTypesAreLearningContent($it)'))
      jsonPath('$.assets[*]._assetType', byCommand('assertThatAssetTypesAreInstruction($it)'))
      jsonPath('$.assets[*]._links', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assets[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assets[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
    }
    body('''
       {
  "_count": 2,
  "assets": [
    {
      "_id": "24f1966f-4e7c-4115-8a57-a289e8b45c8c",
      "_ver": "ab3d4b43-af9c-43f0-9374-5294748f1b01",
      "_bssVer": 1,
      "_createdBy": "Admin",
      "_docType": "LEARNINGCONTENT",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/instructions/24f1966f-4e7c-4115-8a57-a289e8b45c8c/versions/ab3d4b43-af9c-43f0-9374-5294748f1b01"
        }
      }
    },
    {
      "_id": "61e6405a-ac31-11e8-98d0-529269fb1459",
      "_ver": "84e95048-5573-46ac-89cd-0f2c165d9c03",
      "_bssVer": 1,
      "_createdBy": "Admin",
      "_docType": "LEARNINGCONTENT",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/instructions/61e6405a-ac31-11e8-98d0-529269fb1459/versions/84e95048-5573-46ac-89cd-0f2c165d9c03"
        }
      }
    }
  ]
}
        ''')
  }
}