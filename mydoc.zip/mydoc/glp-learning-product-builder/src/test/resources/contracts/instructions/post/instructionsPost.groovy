package contracts.instructions.post;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
  description "."
  request {
    method POST()
    urlPath('/lpb/v2/instructions')
    headers {
      header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(
        "assets": [
          $(
          "contentMetadata": $(
          "id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('09b7ff3b-25e6-47be-a1cd-300cf6ea8b33')),
          "version": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('455c4472-184f-4e3e-a4d4-a89e858b1d03'))
          ),
          "learningModel": $(
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
          "_assetType": $(consumer('INSTRUCTION'), producer('INSTRUCTION')),
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d7f436ad-9fe2-456b-bdbb-52603c1ae949')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('e109b19b-29ce-4caf-bff5-6fe9b1da9b5c'))
          ),
          "resources": $(
          "3e17260b-3ccd-4fd4-bff1-b622012351f4": $(
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('1b5353c2-c203-4008-81ef-3256ea56a2d4')),
          "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
          "_assetType": $(consumer('NARRATIVE'), producer('NARRATIVE'))
          ),
          "18c06ad5-a247-42ff-b3ac-8525cf097ae4": $(
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('18c06ad5-a247-42ff-b3ac-8525cf097ae4')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver":  $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('5a811b23-7131-4273-b977-a0da1ad6f38b')),
          "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
          "_assetType": $(consumer('NARRATIVE'), producer('NARRATIVE'))
          )
          ),
          "assetGraph": [
            $(

            "startNode": $(consumer(regex('.+')), producer('self')),
            "endNode": $(consumer(regex('.+')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4'))
            // "relationships": {}

            ),
            $(
            "startNode": $(consumer(regex('.+')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4')),
            "endNode": $(consumer(regex('.+')), producer('18c06ad5-a247-42ff-b3ac-8525cf097ae4'))
            //"relationships": {}
            )
          ],
          "resourcePlan": [
            $(
            "label": $(consumer(regex('[A-Za-z]+')), producer('BLOCK')),
            "resourceElementType": $(consumer(regex('[A-Za-z]+')), producer('HEADING')),
            "resourceRef":  $(consumer(regex('.*')), producer('resourceRef')),
            "resourceElements": [
              $(
              "label": $(consumer(regex('.+')), producer('slate1')),
              "resourceElementType": $(consumer(regex('.+')), producer('slate')),
              "resourceElements": [],
              "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4'))
              ),
              $(
              "label": $(consumer(regex('.+')), producer('slate2')),
              "resourceElementType": $(consumer(regex('.+')), producer('slate')),
              "resourceElements": [],
              "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('18c06ad5-a247-42ff-b3ac-8525cf097ae4'))
              )
            ]
            )
          ],
          // "configuration": $({}),
          "constraints": []
          //"extends": {},
          //"extensions": {},
          //"scope": {}
          )
        ]
        )
  }
  response {
    headers {   contentType('''application/stream+json; application/hal+json; charset=UTF-8''')  }
    status 207
    bodyMatchers {
      jsonPath('$.asset', byType())
      jsonPath('$.asset._id', byRegex(uuid()))
      jsonPath('$.asset._ver', byRegex(uuid()))
      jsonPath('$.asset._bssVer', byType())
      jsonPath('$.asset._createdBy', byType())
      jsonPath('$.asset._docType', byCommand('assertThatDocTypeIsLearningContent($it)'))
      jsonPath('$.asset._assetType', byCommand('assertThatAssetTypeIsInstruction($it)'))
      jsonPath('$.asset._links', byType())
      jsonPath('$.asset._links.self', byType())
      jsonPath('$.asset._links.self.href', byType())
      jsonPath('$.contentMetadata', byType())
      jsonPath('$.contentMetadata.id', byType())
      jsonPath('$.contentMetadata.version', byType())
      jsonPath('$.entityStatus', byType())
      jsonPath('$.status', byType())
    }
    body('''
{
  "asset": {
    "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
    "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
    "_bssVer": 1,
    "_createdBy": "Admin",
    "_docType": "LEARNINGCONTENT",
    "_assetType": "INSTRUCTION",
    "_links": {
      "self": {
        "href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
      }
    }
  },
  "contentMetadata": {
    "id": "37711975-e1ea-489e-a040-2658979d2cd5",
    "version": "44f04c37-008b-4872-a619-8c5e6ee427ed"
  },
"entityStatus": "Success",
"status": 201 
}
''')
  }
  priority 1
}