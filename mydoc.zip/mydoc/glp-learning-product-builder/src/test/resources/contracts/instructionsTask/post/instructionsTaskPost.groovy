package contracts.instructionsTask.post;
import org.springframework.cloud.contract.spec.Contract;

Contract.make {
	description "."
	request {
	  method POST()
	  urlPath('/lpb/v2/instructions')
	  headers {
		header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(
		"longRunning":$(
				"callbackStrategy": $(consumer(regex('[A-Za-z]+')), producer('REQUIRED')),
				"callbackUrl": $(consumer(regex('NA')))
				),
		"assets": [
          $(
          
          "contentMetadata": $(
          "id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a')),
          "version": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('b1e38cf9-aa76-43bd-94da-31197cb33130'))
          ),
          "learningModel": $(
		  "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
          "_assetType": $(consumer('INSTRUCTION'), producer('INSTRUCTION')),
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
		  "_links":$("self":$("href":$(consumer(regex('[A-Za-z0-9-/]+')),producer('/v2/assetModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672'))))
          ),
          "resources": $(
          "3e17260b-3ccd-4fd4-bff1-b622012351f4": $(
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('52f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
          "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
          "_assetType": $(consumer('NARRATIVE'), producer('NARRATIVE'))
          ),
          "18c06ad5-a247-42ff-b3ac-8525cf097ae4": $(
          "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce9-61dd-4bbc-bba5-1fdc03a0af9f')),
          "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
          "_ver":  $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
          "createdBy": $(consumer(regex('[A-Za-z]+')), producer('ADMIN')),
          "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
          "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
          "_assetType": $(consumer('NARRATIVE'), producer('NARRATIVE'))
          )
          ),
          "assetGraph": [
            $(

            "startNode": $(consumer(regex('.+')), producer('self')),
            "endNode": $(consumer(regex('.+')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4'))
            // "relationships": {}

            ),
            $(
            "startNode": $(consumer(regex('.+')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4')),
            "endNode": $(consumer(regex('.+')), producer('18c06ad5-a247-42ff-b3ac-8525cf097ae4'))
            //"relationships": {}
            )
          ],
          "resourcePlan": [
            $(
            "label": $(consumer(regex('[A-Za-z]+')), producer('BLOCK')),
            "resourceElementType": $(consumer(regex('[A-Za-z]+')), producer('HEADING')),
            "resourceRef":  $(consumer(regex('.*')), producer('resourceRef')),
            "resourceElements": [
              $(
              "label": $(consumer(regex('.+')), producer('slate1')),
              "resourceElementType": $(consumer(regex('.+')), producer('slate')),
              "resourceElements": [],
              "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('3e17260b-3ccd-4fd4-bff1-b622012351f4'))
              ),
              $(
              "label": $(consumer(regex('.+')), producer('slate2')),
              "resourceElementType": $(consumer(regex('.+')), producer('slate')),
              "resourceElements": [],
              "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('18c06ad5-a247-42ff-b3ac-8525cf097ae4'))
              )
            ]
            )
          ],
		  "tags": $(consumer(regex('[A-Za-z]+')), producer('REVEL')),
		  "label": $(consumer(regex('[A-Za-z]+')), producer('INSTRUCTION')),
		  "language": $(consumer(regex('[A-Za-z-]+')), producer('en-US')),
          // "configuration": $({}),
          "constraints": []
          //"extends": {},
          //"extensions": {},
          //"scope": {}
          )
        ]
        )
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 202
    bodyMatchers {
      jsonPath('$._id', byRegex(uuid()))
      jsonPath('$.status', byType())
      jsonPath('$._links', byType())
      jsonPath('$._links.self', byType())
      jsonPath('$._links.self.href', byType())
     
    }
    body('''
{
  "_id": "e2858b5a-e724-4677-a647-d9292e2cef6b",
  "status": "STARTED",
  "_links": {
    "self": {
      "href": "/v2/tasks/e2858b5a-e724-4677-a647-d9292e2cef6b"
    }
  }
}
  ''')
  }
}