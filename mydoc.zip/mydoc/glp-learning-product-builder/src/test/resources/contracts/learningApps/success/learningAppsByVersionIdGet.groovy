package contracts.learningApps.success;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  priority 1
  request {
    method GET()
    urlPath($(  consumer(regex('/lpb/v2/learningApps/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
        producer('/lpb/v2/learningApps/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')))
    headers { header('''Accept''', '''application/json''') }
  }
  response {
    status 200
    headers { contentType('''application/hal+json; charset=UTF-8''') }
    bodyMatchers {
      jsonPath('$._id', byType())
      jsonPath('$._bssVer', byType())
      jsonPath('$._ver', byType())
      jsonPath('$._created', byType())
      jsonPath('$._lastModified', byType())
      jsonPath('$._createdBy',byType())
      jsonPath('$.expiresOn', byType())
      jsonPath('$.label', byType())
      jsonPath('$.tags', byType())
      jsonPath('$.language', byType())
      jsonPath('$._docType', byType())
      jsonPath('$._assetType', byType())
      jsonPath('$.assetClass', byType())
      jsonPath('$.objectives', byType())
      jsonPath('$.groups', byType())
      jsonPath('$.learningModel', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.assetGraph', byType())
      jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.resourcePlan', byType())
      jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.configuration', byType())
      jsonPath('$.constraints', byType())
      jsonPath('$.extends', byType())
      jsonPath('$.extensions', byType())
      jsonPath('$.scope', byType())
      jsonPath('$._links',byType())
    }
    body('''
          {
            "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
            "_bssVer": 1,
            "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
            "_created": "2018-05-18T19:16:15+00:00",
            "_lastModified": "2018-05-18T19:16:15+00:00",
            "_createdBy": "Admin",
            "expiresOn": "2018-11-11T20:14:21+00:00",
            "label": "learningapps",
            "tags": "REVEL",
            "language": "en-US",
            "_docType": "LEARNINGCONTENT",
            "_assetType": "LEARNINGAPP",
            "assetClass": "LEARNINGAPP",
            "objectives": "",
            "groups": {
              
            },
            "learningModel": {
              "_resourceType": "LEARNINGASSET",
              "_docType": "LEARNINGMODEL",
              "_assetType": "LEARNINGAPP",
              "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
              "_bssVer": 1,
              "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
              "_links": {
                
              }
            },
            "resources": {
              "32f42ce8": {
                "_resourceType": "LEARNINGASSET",
                "_docType": "LEARNINGCONTENT",
                "_assetType": "LEARNINGAPP-ITEM",
                "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
                "_bssVer": 1,
                "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
                "_links": {
                  
                }
              }
            },
            "assetGraph": [
              {
                "startNode": "self",
                "endNode": "self",
                "relationships": {
                  
                }
              }
            ],
            "resourcePlan": [
              {
                "label": "Learning App 1",
                "resourceElementType": "writingsolutions",
                "resourceElements": [],
                "resourceRef": "32f42ce8"
              }
            ],
            "configuration": {
              
            },
            "constraints": [],
            "extends": {
              
            },
            "extensions": {
              "contentMetadata": {
                "id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
                "version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
              }
            },
            "scope": {},
            "_links": {}
          }
''')
  }
}