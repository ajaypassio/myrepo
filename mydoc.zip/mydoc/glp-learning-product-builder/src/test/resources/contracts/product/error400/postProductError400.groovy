package contracts.product.error400;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
  description "Error Bad Request 400"
  request {
	method POST()
  url $(consumer(regex('/lpb/v2/products')))
	headers {
	  header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(

        asset:$(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
        )
  }
  response {
    headers {   
      contentType(applicationJsonUtf8())
        }
    status 400
    bodyMatchers {
      jsonPath('$.timestamp', byType())
	    jsonPath('$.status', byType())
      jsonPath('$.error', byType())
	    jsonPath('$.message', byType())
    }
    body('''{
  "timestamp": "2018-08-01T03:54:46+00:00",
  "status": 400,
  "error": "BAD REQUEST",
  "message": "The request does not comply with the expected schema."
  
}'''
    )
	}
  priority 2
}