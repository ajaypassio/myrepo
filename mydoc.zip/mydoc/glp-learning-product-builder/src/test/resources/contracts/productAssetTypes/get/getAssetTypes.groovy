package contracts.productAssetTypes.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Success 200"
    request {
        method GET()
        urlPath($(consumer(regex('/lpb/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672/assetTypes')),
                producer('/lpb/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672/assetTypes')))
        headers {
            header('''Accept''', applicationJson())
        }
    }

    response {
        headers {
            contentType('''application/hal+json; charset=UTF-8''')
        }
        status 200
        bodyMatchers {
            jsonPath('$._id',byRegex(uuid()))
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byRegex(uuid()))
            jsonPath('$._created', byType())
            jsonPath('$._lastModified', byType())
            jsonPath('$._resourceType', byType())
            jsonPath('$._resourceCtx', byType())
            jsonPath('$.resourceClass', byType())
            jsonPath('$.label', byType())
            jsonPath('$.tags', byType())
            jsonPath('$.language', byType())
            jsonPath('$.content', byType())
            jsonPath('$.content.category', byType())
            jsonPath('$.content.model', byType())
            jsonPath('$.content.data',byType())
            jsonPath('$.content.data.assetClassTypes',byType())
            jsonPath('$.content.data.assetClassTypes[*].assetType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.content.data.assetClassTypes[*].assetClass', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.extensions', byType())
            jsonPath('$.scope', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
        }
        body(
                '''{ 
                   "_id":"243b49fb-24a0-4081-8970-efd55773f32c",
                   "_bssVer":1,
                   "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
                   "_created":"2018-05-18T19:16:15+00:00",
                   "_lastModified":"2018-05-18T19:16:15+00:00",
                   "_resourceType":"USERDEFINED",
                   "_resourceCtx":"PRODUCTBUILDER",
                   "resourceClass":"ASSETCLASSTYPES",
                   "label":"",
                   "tags":"",
                   "language":"en_US",
                   "content":{ 
                      "category":"abstract",
                      "model":"assetClasstypes",
                      "data":{ 
                         "assetClassTypes":[ 
                            { 
                               "assetType":"ASSESSMENT",
                               "assetClass":"QUIZ,HOMEWORK,PRACTICE,TEST,DIAGNOSTIC"
                            },
                            { 
                               "assetType":"AGGREGATE",
                               "assetClass":"CHAPTER,SLATE,MODULE"
                            },
                            { 
                               "assetType":"INSTRUCTION",
                               "assetClass":"INSTRUCTION"
                            },
                            { 
                               "assetType":"NARRATIVE",
                               "assetClass":"NARRATIVE"
                            },
                            { 
                               "assetType":"PRODUCT",
                               "assetClass":"PRODUCT"
                            },
                            { 
                               "assetType":"ASSESSMENT-ITEM",
                               "assetClass":"ASSESSMENT-ITEM"
                            }
                         ]
                      }
                   },
                   "extensions":{ 
                      "contentMetadata":{ 
                         "id":"urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
                         "version":"urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
                      },
                      "product":{ 
                         "id":"ceaa82f3-32b5-4eb9-b2f4-bc06cb278273",
                         "version":"6d4e0fae-1ddc-4a01-a6c9-d6cde8e1740b"
                      }
                   },
                   "scope":{ 
                 
                   },
                   "_links":{ 
                      "self":{ 
                         "href":"/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672/assetTypes"
                      }
                   }
                }''')
    }
    priority 1
}
