package contracts.productModelById.get;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
     url(value(consumer(regex('/lpb/v2/productModels/'+uuid()))))
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
        headers { contentType('''application/hal+json; charset=UTF-8''') }
        status 200
        bodyMatchers {
            jsonPath('$._id', byType())
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byType())
            jsonPath('$._created', byType())
            jsonPath('$._createdBy',byType())
            jsonPath('$._lastModified', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$.expiresOn', byType())
            jsonPath('$._links',byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href',byType())
            jsonPath('$.label', byType())
            jsonPath('$.tags', byType())
            jsonPath('$.language', byType())
            jsonPath('$.assetClass', byType())
            jsonPath('$.objectives', byType())
            jsonPath('$.groups', byType())     
            jsonPath('$.groups', byType())
            jsonPath('$.resources', byType())
            jsonPath('$.assetGraph', byType())
            jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.resourcePlan', byType())
            jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.configuration', byType())
            jsonPath('$.constraints', byType())
            jsonPath('$.extends', byType())
            jsonPath('$.extensions', byType())
            jsonPath('$.scope', byType())
        }
        body('''
            {
              "assetGraph": [
                {
                  "relationships": {
                    
                  },
                  "startNode": "self",
                  "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e"
                },
                {
                  "relationships": {
                    
                  },
                  "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                  "endNode": "self"
                }
              ],
              "resourcePlan": [
                {
                  "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                  "resourceElementType": "INDEX",
                  "resourceElements": [],
                  "label": "INDEX"
                }
              ],
              "_links": {
                "self": {
                  "href": "/v2/productModels/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/c5ef1ee9-5025-46e0-b48e-a6d43119996a"
                }
              },
              "configuration": {
                
              },
              "_ver": "c5ef1ee9-5025-46e0-b48e-a6d43119996a",
              "groups": {
                
              },
              "resources": {
                "d441ee2a-4475-4511-969c-80cbbeba553e": {
                  "_resourceType": "INLINED",
                  "data": {
                    "keyPattern": "INDEX-%5CS",
                    "categorySchema": {
                      "type": "object",
                      "minProperties": 1
                    },
                    "instanceSchema": {
                      "type": "object",
                      "required": [
                        "_docType",
                        "_assetType"
                      ],
                      "properties": {
                        "_docType": {
                          "type": "string",
                          "enum": [
                            "LEARNINGCONTENT"
                          ]
                        },
                        "_resourceType": {
                          "type": "string",
                          "enum": [
                            "LEARNINGASSET"
                          ]
                        },
                        "_assetType": {
                          "type": "string",
                          "enum": [
                            "AGGREGATE"
                          ]
                        }
                      }
                    },
                    "instanceModel": {
                      "_docType": "LEARNINGMODEL",
                      "_resourceType": "LEARNINGASSET",
                      "_bssVer": 1,
                      "_links": {
                        "self": {
                          "href": "/v2/productModels/c24e2e28-4817-413e-85f3-b9dc32ebf401/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
                        }
                      },
                      "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
                      "_id": "c24e2e28-4817-413e-85f3-b9dc32ebf401",
                      "_assetType": "AGGREGATE"
                    }
                  },
                  "category": "model"
                }
              },
              "language": "en_US",
              "label": "PRODUCT",
              "assetClass": "",
              "_assetType": "PRODUCT",
              "constraints": [],
              "tags": "REVEL",
              "_docType": "LEARNINGMODEL",
              "extensions": {
                
              },
              "extends": {
                
              },
              "_bssVer": 1,
              "_createdBy": "Admin",
              "_created": "2018-11-27T04:10:50+00:00",
              "_lastModified": "2018-11-27T04:10:50+00:00",
              "scope": {
                
              },
              "expiresOn": "2020-12-12T18:29:50+00:00",
              "objectives": "",
              "_id": "0296f146-e15c-4d3e-8edd-89e59bd50f27"
            }
        ''')
    }
}
