package contracts.productModelsVersions.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method GET()
		url(value(consumer(regex('/lpb/v2/productModels/'+uuid()+'/versions')), producer('/lpb/v2/productModels/243b49fb-24a0-4081-8970-efd55773f32c/versions')))
		headers {
			header('''Accept''', applicationJson())
		}
	}
	response {
		headers { contentType('''application/hal+json; charset=UTF-8''') }
		status 200
		bodyMatchers {
            jsonPath('$._count', byType())
            jsonPath('$.productModels', byType())
            jsonPath('$.productModels[*]._id', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.productModels[*]._ver', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._created', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._lastModified', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._createdBy', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._docType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._assetType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].expiresOn', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*]._links', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].tags', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].language', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].assetClass', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].objectives', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].groups', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].groups', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].resources', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].assetGraph', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.productModels[*].assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].resourcePlan', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.productModels[*].resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.productModels[*].resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.productModels[*].configuration', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].constraints', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.productModels[*].extends', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].extensions', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.productModels[*].scope', byCommand('assertThatValueIsAMap($it)'))
        }
		body('''
         {
              "_count": 3,
              "productModels": [
                {
                  "assetGraph": [
                    {
                      "relationships": {
                        
                      },
                      "startNode": "self",
                      "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e"
                    },
                    {
                      "relationships": {
                        
                      },
                      "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                      "endNode": "self"
                    }
                  ],
                  "resourcePlan": [
                    {
                      "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                      "resourceElementType": "INDEX",
                      "resourceElements": [],
                      "label": "INDEX"
                    }
                  ],
                  "configuration": {
                    
                  },
                  "_links": {
                    "self": {
                      "href": "/v2/productModels/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/c5ef1ee9-5025-46e0-b48e-a6d43119996a"
                    }
                  },
                  "_ver": "c5ef1ee9-5025-46e0-b48e-a6d43119996a",
                  "groups": {
                    
                  },
                  "resources": {
                    "d441ee2a-4475-4511-969c-80cbbeba553e": {
                      "_resourceType": "INLINED",
                      "data": {
                        "keyPattern": "INDEX-%5CS",
                        "categorySchema": {
                          "type": "object",
                          "minProperties": 1
                        },
                        "instanceSchema": {
                          "type": "object",
                          "required": [
                            "_docType",
                            "_assetType"
                          ],
                          "properties": {
                            "_docType": {
                              "type": "string",
                              "enum": [
                                "LEARNINGCONTENT"
                              ]
                            },
                            "_resourceType": {
                              "type": "string",
                              "enum": [
                                "LEARNINGASSET"
                              ]
                            },
                            "_assetType": {
                              "type": "string",
                              "enum": [
                                "AGGREGATE"
                              ]
                            }
                          }
                        },
                        "instanceModel": {
                          "_docType": "LEARNINGMODEL",
                          "_resourceType": "LEARNINGASSET",
                          "_bssVer": 1,
                          "_links": {
                            "self": {
                              "href": "/v2/productModels/c24e2e28-4817-413e-85f3-b9dc32ebf401/versions/a786eba0-8b72-49b8-9799-4bca25cf3346"
                            }
                          },
                          "_ver": "a786eba0-8b72-49b8-9799-4bca25cf3346",
                          "_id": "c24e2e28-4817-413e-85f3-b9dc32ebf401",
                          "_assetType": "AGGREGATE"
                        }
                      },
                      "category": "model"
                    }
                  },
                  "language": "en_US",
                  "label": "PRODUCT",
                  "assetClass": "",
                  "_assetType": "PRODUCT",
                  "constraints": [],
                  "tags": "REVEL",
                  "_docType": "LEARNINGMODEL",
                  "extensions": {
                    
                  },
                  "extends": {
                    
                  },
                  "_bssVer": 1,
                  "_createdBy": "Admin",
                  "_created": "2018-11-27T04:10:50+00:00",
                  "_lastModified": "2018-11-27T04:10:50+00:00",
                  "scope": {
                    
                  },
                  "expiresOn": "2020-12-12T18:29:50+00:00",
                  "objectives": "",
                  "_id": "0296f146-e15c-4d3e-8edd-89e59bd50f27"
                },
                {
                  "assetGraph": [
                    {
                      "relationships": {
                        
                      },
                      "startNode": "self",
                      "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e"
                    },
                    {
                      "relationships": {
                        
                      },
                      "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                      "endNode": "self"
                    }
                  ],
                  "resourcePlan": [
                    {
                      "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                      "resourceElementType": "INDEX",
                      "resourceElements": [],
                      "label": "INDEX"
                    }
                  ],
                  "configuration": {
                    
                  },
                  "_links": {
                    "self": {
                      "href": "/v2/productModels/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/a9b9ae2b-966c-4a66-a6ab-134d685cb98c"
                    }
                  },
                  "_ver": "a9b9ae2b-966c-4a66-a6ab-134d685cb98c",
                  "groups": {
                    
                  },
                  "resources": {
                    "d441ee2a-4475-4511-969c-80cbbeba553e": {
                      "_resourceType": "INLINED",
                      "data": {
                        "keyPattern": "MODULE-5CS",
                        "categorySchema": {
                          "type": "object",
                          "minProperties": 1
                        },
                        "instanceSchema": {
                          "type": "object",
                          "required": [
                            "_docType",
                            "_assetType"
                          ],
                          "properties": {
                            "_docType": {
                              "type": "string",
                              "enum": [
                                "LEARNINGCONTENT"
                              ]
                            },
                            "_resourceType": {
                              "type": "string",
                              "enum": [
                                "LEARNINGASSET"
                              ]
                            },
                            "_assetType": {
                              "type": "string",
                              "enum": [
                                "AGGREGATE"
                              ]
                            }
                          }
                        },
                        "instanceModel": {
                          "_docType": "LEARNINGMODEL",
                          "_resourceType": "LEARNINGASSET",
                          "_bssVer": 1,
                          "_links": {
                            "self": {
                              "href": "/v2/productModels/c24e2e28-4817-413e-85f3-b9dc32ebf401/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
                            }
                          },
                          "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
                          "_id": "c24e2e28-4817-413e-85f3-b9dc32ebf401",
                          "_assetType": "AGGREGATE"
                        }
                      },
                      "category": "model"
                    }
                  },
                  "language": "en_US",
                  "label": "PRODUCT",
                  "assetClass": "",
                  "_assetType": "PRODUCT",
                  "constraints": [],
                  "tags": "REVEL",
                  "_docType": "LEARNINGMODEL",
                  "extensions": {
                    
                  },
                  "extends": {
                    
                  },
                  "_bssVer": 1,
                  "_createdBy": "Admin",
                  "_created": "2018-11-27T04:10:50+00:00",
                  "_lastModified": "2018-11-27T04:10:50+00:00",
                  "scope": {
                    
                  },
                  "expiresOn": "2020-12-12T18:29:50+00:00",
                  "objectives": "",
                  "_id": "0296f146-e15c-4d3e-8edd-89e59bd50f27"
                },
                {
                  "assetGraph": [
                    {
                      "relationships": {
                        
                      },
                      "startNode": "self",
                      "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e"
                    },
                    {
                      "relationships": {
                        
                      },
                      "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
                      "endNode": "self"
                    }
                  ],
                  "resourcePlan": [
                    {
                      "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
                      "resourceElementType": "INDEX",
                      "resourceElements": [],
                      "label": "INDEX"
                    }
                  ],
                  "configuration": {
                    
                  },
                  "_links": {
                    "self": {
                      "href": "/v2/productModels/0296f146-e15c-4d3e-8edd-89e59bd50f27/versions/a9b9ae2b-966c-4a66-a6ab-134d685cb99d"
                    }
                  },
                  "_ver": "a9b9ae2b-966c-4a66-a6ab-134d685cb99d",
                  "groups": {
                    
                  },
                  "resources": {
                    "d441ee2a-4475-4511-969c-80cbbeba553e": {
                      "_resourceType": "INLINED",
                      "data": {
                        "keyPattern": "INDEX-5CS",
                        "categorySchema": {
                          "type": "object",
                          "minProperties": 1
                        },
                        "instanceSchema": {
                          "type": "object",
                          "required": [
                            "_docType",
                            "_assetType"
                          ],
                          "properties": {
                            "_docType": {
                              "type": "string",
                              "enum": [
                                "LEARNINGCONTENT"
                              ]
                            },
                            "_resourceType": {
                              "type": "string",
                              "enum": [
                                "LEARNINGASSET"
                              ]
                            },
                            "_assetType": {
                              "type": "string",
                              "enum": [
                                "AGGREGATE"
                              ]
                            }
                          }
                        },
                        "instanceModel": {
                          "_docType": "LEARNINGMODEL",
                          "_resourceType": "LEARNINGASSET",
                          "_bssVer": 1,
                          "_links": {
                            "self": {
                              "href": "/v2/productModels/c24e2e28-4817-413e-85f3-b9dc32ebf401/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
                            }
                          },
                          "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
                          "_id": "c24e2e28-4817-413e-85f3-b9dc32ebf401",
                          "_assetType": "AGGREGATE"
                        }
                      },
                      "category": "model"
                    }
                  },
                  "language": "en_US",
                  "label": "PRODUCT",
                  "assetClass": "",
                  "_assetType": "PRODUCT",
                  "constraints": [],
                  "tags": "REVEL",
                  "_docType": "LEARNINGMODEL",
                  "extensions": {
                    
                  },
                  "extends": {
                    
                  },
                  "_bssVer": 1,
                  "_createdBy": "Admin",
                  "_created": "2018-11-27T04:10:50+00:00",
                  "_lastModified": "2018-11-27T04:10:50+00:00",
                  "scope": {
                    
                  },
                  "expiresOn": "2020-12-12T18:29:50+00:00",
                  "objectives": "",
                  "_id": "0296f146-e15c-4d3e-8edd-89e59bd50f27"
                }
              ]
            }
            '''
				)
	}
}