package contracts.productState.error400;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "Error 400"
  request {
    method GET()
    urlPath($(  consumer(regex('/lpb/v2/products/.*/versions/.*/stateTransitions')),
        producer('/lpb/v2/products/invalidId/versions/invalidVer/stateTransitions')))
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType(applicationJsonUtf8())  }
    status 400
    bodyMatchers {
      jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
    }
    body('''{
            "timestamp": "2018-12-20T10:08:19+00:00",
            "status": 400,
            "error": "Invalid Request : Invalid Uuid",
            "message": "There was an error processing the request."
          }
    ''')
  }
  priority 3
}