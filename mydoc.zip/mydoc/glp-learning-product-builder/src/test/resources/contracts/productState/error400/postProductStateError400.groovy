package contracts.productState.error400

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "Error Bad Request 400"
	request {
		method POST()
		url $(consumer(regex('/lpb/v2/products/[\\w-]+/versions/[\\w-]+/stateTransitions')))    
    body(
			transitionState: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
		}
		body('''{
              "timestamp": "2018-12-20T10:08:19+00:00",
              "status": 400,
              "error": "Schema Validation Error.",
              "message": "There was an error processing the request."
            }'''
    )
	}
	priority 3
}