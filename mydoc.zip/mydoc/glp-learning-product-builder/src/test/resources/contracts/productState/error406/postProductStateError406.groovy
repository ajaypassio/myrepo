package contracts.productState.error406

import org.springframework.cloud.contract.spec.Contract
Contract.make {
  description "Error Headers 406"
  request {
    method POST()
    url $(consumer(regex('/lpb/v2/products/[\\w-]+/versions/[\\w-]+/stateTransitions')))    
    body(
      transitionState: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
      )
    headers {
      header('''Accept''', applicationJson())
          contentType(applicationJson())
      }

  }
  response {
    headers {   
      contentType(applicationJsonUtf8())
        }
    status 406
    bodyMatchers {
      jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
    }
    body('''{
              "timestamp": "2018-12-20T10:08:19+00:00",
              "status": 406,
              "error": "NOT ACCEPTED",
              "message": "The resource cannot provide a representation that meets the request requirements in regards of its Accept"
            }'''
    )
  }
  priority 4
}