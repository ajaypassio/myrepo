package contracts.productStatus.error400

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "Error Bad Request 400"
	request {
		method PUT()
    url $(consumer(regex('/lpb/v2/products/[\\w-]+/versions/[\\w-]+/status')))
    body(
          _status: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
		}
		body('''{
              "timestamp": "2018-11-27T04:10:50+00:00",
              "status": 400,
              "error": "Bad Request.",
              "message": "There was an error processing the request."
            }'''
    )
	}
	priority 3
}