package contracts.productStatus.error404

import org.springframework.cloud.contract.spec.Contract
Contract.make {
  description "Error Not Found 404"
  request {
    method PUT()
        url $(consumer(regex('/lpb/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/status')), 
            producer('/lpb/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf2/status'))    
    body(
      _status: $(consumer(regex('.+')),producer('COMPOSE'))
      )
    headers {
      header('''Accept''', applicationJson())
          contentType(applicationJson())
      }
  }
  response {
    headers {   
      contentType(applicationJsonUtf8())
        }
    status 404
    bodyMatchers {
      jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
    }
    body('''{
              "timestamp": "2018-11-27T04:10:50+00:00",
              "status": 404,
              "error": "NOT FOUND",
              "message": "Requested Resource Not Found"
            }'''
    )
  }
  priority 2
}