package contracts.productStatus.success

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "Created 201"
	request {
		method PUT()
		url $(consumer('/lpb/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1/status'), 
            producer('/lpb/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1/status'))		
		body(
            _status: $(consumer(regex('.+')),producer('COMPOSE'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType('''application/hal+json; charset=UTF-8''')
			  }
		status 201
		bodyMatchers {
			jsonPath('$._id', byType())
			jsonPath('$._status', byType())
			jsonPath('$._lastModified', byType())
			jsonPath('$._links', byType())
			jsonPath('$._links.self', byType())
			jsonPath('$._links.self.href', byType())
		}
		body('''{
              "_id": "5971ace2-ad1d-459f-ab34-f232a827ea2f",
              "_status": "COMPOSE",
              "_lastModified": "2018-11-27T04:10:50+00:00",
              "_links": {
              "self": {
                  "href": "/v2/products/fc989a74-57e0-4be4-89c9-13e7dc75d293/versions/bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1/status"
              }
            }
        }''')
	}
	priority 1
}