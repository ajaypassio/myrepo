package contracts.productsVersions.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method GET()
		urlPath(value(consumer(regex('/lpb/v2/products/[\\w-]+/versions'))))
		headers {
			header('''Accept''', applicationJson())
		}
	}
	response {
		headers {   contentType('''application/hal+json; charset=UTF-8''')  }
		status 200
		bodyMatchers {
			jsonPath('$._count', byType())
			jsonPath('$.versions', byType())
			jsonPath('$.versions[*]._links', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.versions[*].self', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.versions[*].self.href', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._ver', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._assetType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._docType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._bssVer', byType())
			jsonPath('$.versions[*]._id', byCommand('assertThatValueIsAString($it)'))
		}
		body('''
{
  "_count": 2,
  "versions": [
    {
      "_links": {
        "self": {
          "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
        }
      },
      "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "_assetType": "PRODUCT",
      "_docType": "LEARNINGCONTENT",
      "_bssVer": 1,
      "_id": "8883c099-1762-43fe-9ad8-4c9aaa6eafa2"
    },
		{
      "_links": {
        "self": {
          "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456"
        }
      },
      "_ver": "200a3768-17af-4f2f-9d4c-b07c6cdfc456",
      "_assetType": "PRODUCT",
      "_docType": "LEARNINGCONTENT",
      "_bssVer": 1,
      "_id": "8883c099-1762-43fe-9ad8-4c9aaa6eafa2"
    
}
  ]
}

''')
	}
}