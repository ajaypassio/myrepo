package contracts.taskById.get

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    url(value(consumer(regex('/lpb/v2/tasks/'+uuid()))))
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    headers {   contentType('''application/hal+json; charset=UTF-8''')  }
    status 200
    bodyMatchers {
      jsonPath('$._status', byType())
      jsonPath('$._count', byType())
      jsonPath('$._completed', byType())
      jsonPath('$._failed', byType())
      jsonPath('$._in_progress', byType()) 
      jsonPath('$._links', byType())
      jsonPath('$._links.self', byType())
      jsonPath('$._links.self.href', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.resources.href', byType())
    }
    body('''
      {
  "_status": "COMPLETED",
  "_count": 2,
  "_completed": 2,
  "_failed": 0,
  "_in_progress": 0,
   "_links": {
    "self": {
      "href": "/v2/tasks/e2858b5a-e724-4677-a647-d9292e2cef6b"
    }
  },
  "resources": {
    "href": "/v2/tasks/e2858b5a-e724-4677-a647-d9292e2cef6b/instructions"
  }
}
        ''')
  }
}