# Participant Service 
Participant serivce source code for microservice
CI using Jenkins and Azure Conatainer service via Kubernetes
# Database
Mysql Azure



