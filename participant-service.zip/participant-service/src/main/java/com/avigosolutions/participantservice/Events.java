package com.avigosolutions.participantservice;

public enum Events {
	PatientCampaign, AttemptQuestionnaire, SelectedStudySite,  SiteToContact, ScheduledVisit, SiteVisited, 
	PatientRejectConsent, PatientAcceptConsent, PatientRejected, PatientThrough, PatientFailed, TrialCompleted;
}
