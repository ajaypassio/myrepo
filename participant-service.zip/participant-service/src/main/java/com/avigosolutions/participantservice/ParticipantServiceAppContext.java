package com.avigosolutions.participantservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

@Component
public class ParticipantServiceAppContext implements ApplicationContextAware {

	public static ApplicationContext ac;
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public void setApplicationContext(ApplicationContext applicationContext) {
		logger.info("Application context initialized");
		ac = applicationContext;
	}

	public static <T> T getBean(String name, Class<T> type) {
		return ac.getBean(name, type);
	}

	public static <T> T getBean(Class<T> type) {
		return ac.getBean(type);
	}
}
