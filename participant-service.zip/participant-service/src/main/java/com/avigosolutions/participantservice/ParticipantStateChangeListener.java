package com.avigosolutions.participantservice;

import org.springframework.messaging.Message;
import org.springframework.statemachine.state.State;

public interface ParticipantStateChangeListener {
	public void onStateChange(State<States, Events> state, Message<Events> message);
	public States retrieveState(String participantId, Long trialId);
}