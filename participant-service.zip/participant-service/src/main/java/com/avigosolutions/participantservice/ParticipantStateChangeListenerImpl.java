package com.avigosolutions.participantservice;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.statemachine.state.State;
import org.springframework.stereotype.Component;

import com.avigosolutions.participantservice.common.Constants;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.service.ParticipantStudySiteService;
import com.avigosolutions.participantservice.service.ParticipantTrialService;

@Component
public class ParticipantStateChangeListenerImpl implements ParticipantStateChangeListener {

	private static Logger logger = LoggerFactory.getLogger(ParticipantStateChangeListenerImpl.class);

	Map<String, States> statusMap = new ConcurrentHashMap<>();

	@Autowired
	ParticipantStudySiteService participantStudySiteService;
	@Autowired
	ParticipantTrialService participantTrialService;

	@Override
	@Transactional
	public void onStateChange(State<States, Events> state, Message<Events> message) {
		ParticipantTrialState participantTrial = message.getHeaders().get(Constants.PARTICIPANT_TRIAL,
				ParticipantTrialState.class);
		Long trialId = participantTrial.getTrialId();
		String participantId = participantTrial.getParticipantId();
		int sourceStateId = participantTrial.getSourceStateCode();

		int toStateId = state.getId().getCode();
		statusMap.put(participantId + trialId, state.getId());
		// Retrieve and update participant studysite status information
		ParticipantStudySite participantStudySite = participantStudySiteService
				.findByParticipantIdAndTrialId(participantId, trialId);
		
		if(participantStudySite == null) {
			return;
		}
		
		participantStudySite.withUpdatedOn(new Date()).withParticipantStatusId(toStateId)
				.withStatusNotes(participantTrial.getStatusNotes()).withNotes(participantTrial.getNotes());
		participantStudySite = participantStudySiteService.save(participantStudySite);
		// If same status no audit required
		if (sourceStateId == toStateId) {
			return;
		}
		String msg = participantId + " : " + trialId + " : " + toStateId;
		logger.info("Message Recieved:" + msg);
		participantTrialService.storeAuditSummary(participantStudySite, sourceStateId, toStateId);
	}

	@Override
	public States retrieveState(String participantId, Long trialId) {
		return statusMap.remove(participantId + trialId);
	}
}