package com.avigosolutions.participantservice;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.access.StateMachineAccess;
import org.springframework.statemachine.access.StateMachineFunction;
import org.springframework.statemachine.state.State;
import org.springframework.statemachine.support.DefaultStateMachineContext;
import org.springframework.statemachine.support.LifecycleObjectSupport;
import org.springframework.statemachine.support.StateMachineInterceptorAdapter;
import org.springframework.statemachine.transition.Transition;
import org.springframework.stereotype.Component;

@Component
public class ParticipantStateHandler extends LifecycleObjectSupport {

	@Autowired
	private StateMachine<States, Events> stateMachine;

	private Set<ParticipantStateChangeListener> listeners = new HashSet<>();

	@Override
	protected void onInit() throws Exception {
		stateMachine.getStateMachineAccessor()
				.doWithAllRegions(new StateMachineFunction<StateMachineAccess<States, Events>>() {
					@Override
					public void apply(StateMachineAccess<States, Events> function) {
						function.addStateMachineInterceptor(new StateMachineInterceptorAdapter<States, Events>() {

							@Override
							public void preStateChange(State<States, Events> state, Message<Events> message,
									Transition<States, Events> transition, StateMachine<States, Events> stateMachine) {
								listeners.forEach(listener -> listener.onStateChange(state, message));
							}
						});
					}
				});
	}

	public void registerListener(ParticipantStateChangeListener listener) {
		listeners.add(listener);
	}

	public synchronized void handleEvent(Message<Events> event, States sourceState) {
		stateMachine.stop();
		stateMachine.getStateMachineAccessor().doWithAllRegions(access -> access
				.resetStateMachine(new DefaultStateMachineContext<States, Events>(sourceState, null, null, null)));
		stateMachine.start();
		stateMachine.sendEvent(event);
	}

	public Set<Events> getAllPossibleEvents(States sourceState) {
		Set<Events> eventSet = stateMachine.getTransitions().stream().filter(x -> x.getSource().getId() == sourceState)
				.map(x -> x.getTrigger().getEvent()).collect(Collectors.toSet());
		return eventSet;
	}

	public Set<States> getAllPossibleStates(States sourceState) {
		Set<States> eventSet = stateMachine.getTransitions().stream().filter(x -> x.getSource().getId() == sourceState)
				.map(x -> x.getTarget().getId()).collect(Collectors.toSet());
		return eventSet;
	}

	public Optional<Events> getMatchingEvent(States sourceState, States targetState) {
		Optional<Events> event = stateMachine.getTransitions().stream()
				.filter(x -> (x.getSource().getId() == sourceState && x.getTarget().getId() == targetState))
				.map(x -> x.getTrigger().getEvent()).findFirst();
		return event;
	}
}