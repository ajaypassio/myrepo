package com.avigosolutions.participantservice;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.Schedules;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.avigosolutions.participantservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.participantservice.async.config.RetryPolicyClassifier;
import com.avigosolutions.participantservice.crm.async.service.CrmAsyncService;
import com.avigosolutions.participantservice.crm.async.service.CategoryRetryListener;
import com.avigosolutions.participantservice.crm.async.service.SendContactsRetryListener;

@EnableJpaAuditing
@EnableJpaRepositories
@SpringBootApplication
public class ParticipantserviceApplication {

	@Value("${sprintt.participantBulkInsert.async.processing.threadpool.size.initial}")
	private Integer corePoolSize;

	@Value("${sprintt.participantBulkInsert.async.processing.threadpool.size.max}")
	private Integer maxPoolSize;

	@Value("${sprintt.participantBulkInsert.async.processing.thread.prefix}")
	private String theadPrefixName;

	@Value("${sprintt.participantBulkInsert.async.processing.thread.keepalive.seconds}")
	private Integer keepAliveSeconds;

	@Value("${sprintt.participantBulkInsert.async.processing.thread.queue.capacity}")
	private Integer queueCapacity;

	// zyprr
	@Value("${sprintt.zyprr.contacts.async.processing.thread.initial.count}")
	private Integer zyprrCorePoolSize;

	@Value("${sprintt.zyprr.contacts.async.processing.thread.max.count}")
	private Integer zyprrMaxPoolSize;

	@Value("${sprintt.zyprr.contacts.async.processing.thread.prefix}")
	private String zyprrTheadPrefixName;

	@Value("${sprintt.zyprr.contacts.async.processing.thread.keepalive.seconds}")
	private Integer zyprrKeepAliveSeconds;

	@Value("${sprintt.zyprr.contacts.async.processing.thread.queue.capacity}")
	private Integer zyprrQueueCapacity;

	@Autowired
	CategoryRetryListener categoryRetryListener;

	@Autowired
	SendContactsRetryListener sendContactsRetryListener;

	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;

	@Autowired
	CrmAsyncService cRMAsyncService;

	public static void main(String[] args) {
		SpringApplication.run(ParticipantserviceApplication.class, args);
	}

	// Thread Call
	@Bean(name = "canThreadPoolTaskExecutor")
	public Executor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(corePoolSize);
		executor.setMaxPoolSize(maxPoolSize);
		executor.setKeepAliveSeconds(keepAliveSeconds);
		executor.setThreadNamePrefix(theadPrefixName);
		executor.setQueueCapacity(queueCapacity);
		executor.initialize();
		return executor;
	}

	@Bean(name = "crmThreadPoolTaskExecutor")
	public Executor zyprrThreadPoolTaskExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(zyprrCorePoolSize);
		executor.setMaxPoolSize(zyprrMaxPoolSize);
		executor.setKeepAliveSeconds(zyprrKeepAliveSeconds);
		executor.setThreadNamePrefix(zyprrTheadPrefixName);
		executor.setQueueCapacity(zyprrQueueCapacity);
		executor.initialize();
		return executor;
	}

	@Bean
	@DependsOn({ "asyncConfigLoaderBean", "categoryRetryListener" })
	public RetryTemplate retryCategoryTemplate() {
		RetryTemplate retryTemplate = new RetryTemplate();

		if (0 == asyncConfigLoaderBean.getCategoryRetryPolicy().intValue()) {
			FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
			backOffPolicy.setBackOffPeriod(asyncConfigLoaderBean.getCategoryRetryIntervalInitial() * 60L * 1000L);
			retryTemplate.setBackOffPolicy(backOffPolicy);
		} else {
			ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
			backOffPolicy.setInitialInterval(asyncConfigLoaderBean.getCategoryRetryIntervalInitial() * 60L * 1000L);
			backOffPolicy.setMaxInterval(asyncConfigLoaderBean.getCategoryRetryIntervalMax() * 60L * 1000L);
			backOffPolicy.setMultiplier(asyncConfigLoaderBean.getCategoryRetryIntervalMultiplier());
			retryTemplate.setBackOffPolicy(backOffPolicy);
		}

		retryTemplate.setRetryPolicy(new RetryPolicyClassifier(asyncConfigLoaderBean.getCategoryRetryAttempts()));
		retryTemplate.registerListener(categoryRetryListener);
		return retryTemplate;
	}

	@Bean
	@DependsOn({ "asyncConfigLoaderBean", "sendContactsRetryListener" })
	public RetryTemplate retrySendContactsTemplate() {
		RetryTemplate retryTemplate = new RetryTemplate();

		if (0 == asyncConfigLoaderBean.getSendContactsRetryPolicy().intValue()) {
			FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
			backOffPolicy.setBackOffPeriod(asyncConfigLoaderBean.getSendContactsRetryIntervalInitial() * 60L * 1000L);
			retryTemplate.setBackOffPolicy(backOffPolicy);
		} else {
			ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
			backOffPolicy.setInitialInterval(asyncConfigLoaderBean.getSendContactsRetryIntervalInitial() * 60L * 1000L);
			backOffPolicy.setMaxInterval(asyncConfigLoaderBean.getSendContactsRetryIntervalMax() * 60L * 1000L);
			backOffPolicy.setMultiplier(asyncConfigLoaderBean.getSendContactsRetryIntervalMultiplier());
			retryTemplate.setBackOffPolicy(backOffPolicy);
		}

		retryTemplate.setRetryPolicy(new RetryPolicyClassifier(asyncConfigLoaderBean.getSendContactsRetryAttempts()));
		retryTemplate.registerListener(sendContactsRetryListener);

		return retryTemplate;
	}
	@Bean(name = "batchThreadPoolTaskExecutor")
	@DependsOn("asyncConfigLoaderBean")
	public Executor threadPoolTaskExecutorForBatch() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(asyncConfigLoaderBean.getCorePoolSize());
		executor.setMaxPoolSize(asyncConfigLoaderBean.getMaxPoolSize());
		executor.setKeepAliveSeconds(asyncConfigLoaderBean.getKeepAliveSeconds());
		executor.setThreadNamePrefix(asyncConfigLoaderBean.getBatchThreadPrefixName());
		executor.setQueueCapacity(asyncConfigLoaderBean.getQueueCapacity());
		executor.initialize();
		return executor;
	}

	/*@Schedules({
			@Scheduled(initialDelayString = "${sprintt.zyprr.category.batch.delay.initial}",
					fixedDelayString = "${sprintt.zyprr.category.batch.delay.fixed}")
			// ,@Scheduled(cron = "${sprintt.savedsearch.batch.cron.expression}")
	})
	@DependsOn("crmAsyncService")
	public void startBatch() {
		cRMAsyncService.batchProcessCRMContacts();
	}*/
}
