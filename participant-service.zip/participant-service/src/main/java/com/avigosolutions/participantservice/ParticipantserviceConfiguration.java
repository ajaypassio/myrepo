package com.avigosolutions.participantservice;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.questdiagnostics.mongo.model.SurveyResponseInfoForAdmin;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForSiteCoord;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableWebMvc
@EnableSwagger2
@EnableScheduling
//@ComponentScan(basePackages = "com.avigosolutions.participantservice.controllers")
public class ParticipantserviceConfiguration extends WebMvcConfigurerAdapter {
	/*@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")		
			.allowedMethods("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS")
			.allowedOrigins("*");		

	}*/
		
	@Bean
	public Docket docConfig() {
		return new Docket(DocumentationType.SWAGGER_2)					.select()
					
					.apis(RequestHandlerSelectors.basePackage("com.avigosolutions")) // interested only in avigo controllers
					.paths(PathSelectors.any())
					.build()
					.apiInfo(restApiInfo())				
					.directModelSubstitute(LocalDate.class, String.class) // replace local date with String
					.genericModelSubstitutes(ResponseEntity.class)        // we don't want ResponseEntity (spring specific), we want the data that's wrapped inside
					;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    registry.addResourceHandler("swagger-ui.html")
	      .addResourceLocations("classpath:/META-INF/resources/");
	 
	    registry.addResourceHandler("/webjars/**")
	      .addResourceLocations("classpath:/META-INF/resources/webjars/");
	}
	
	private ApiInfo restApiInfo() {
		
		return new ApiInfo("Participant Service API", "Helps patients to attend Questionnaire", 
				"API TOS", "Terms of service", 
				new Contact("Avigo Solutions LLC", "http://www.avigosolutions.com", "contact@avigosolutions.com"), "", "",
				Collections.emptyList());
	}
	
	@Bean
	public SurveyResponseInfoForAdmin surveyResponseInfoForAdmin() {
	    return new SurveyResponseInfoForAdmin();
	}
	


	@Bean
	public SurveyResponseInfoForSiteCoord surveyResponseInfoForSiteCoord() {
	    return new SurveyResponseInfoForSiteCoord();
	}
	@Bean
    public CommonsRequestLoggingFilter logFilter() {
        CommonsRequestLoggingFilter filter
          = new CommonsRequestLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludePayload(true);
        filter.setMaxPayloadLength(10000);
        filter.setIncludeHeaders(true);
        filter.setBeanName("Date: "+new Date());
        filter.setAfterMessagePrefix("<<<<<<< REQUEST DATA : ");
        filter.setBeforeMessagePrefix(">>>>> REQUEST DATA : ");
        return filter;
    }
}