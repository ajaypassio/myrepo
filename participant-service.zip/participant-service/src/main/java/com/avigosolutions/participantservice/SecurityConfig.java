package com.avigosolutions.participantservice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.hibernate.validator.cfg.context.CrossParameterConstraintMappingContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Value("${sprintt.auth.user}")
	private String springAuthUser;
	
	@Value("${sprintt.auth.password}")
	private String springAuthPassword;
	
	@Value("${sprintt.auth.role}")
	private String springAuthRole;
	
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser(springAuthUser).password(springAuthPassword).roles(springAuthRole);
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		//http.cors().configurationSource(request -> new CorsConfiguration().applyPermitDefaultValues());
		/*CorsConfiguration configSource =  new CorsConfiguration().applyPermitDefaultValues();
		List<String> allowedMethods = new ArrayList<String>(Arrays.asList("GET","PUT","POST","DELETE"));
		configSource.setAllowedMethods(allowedMethods);
		configSource.addAllowedOrigin("*");*/
		http.csrf().disable();
		//http.cors().configurationSource(request -> configSource);
	}
	
	
}