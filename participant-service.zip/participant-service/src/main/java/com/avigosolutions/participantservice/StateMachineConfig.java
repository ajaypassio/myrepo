package com.avigosolutions.participantservice;

import java.util.EnumSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.Message;
import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.action.Action;
import org.springframework.statemachine.config.EnableStateMachine;
import org.springframework.statemachine.config.EnumStateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineConfigurationConfigurer;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;

@Configuration
// @EnableStateMachine
public class StateMachineConfig {

	private static Logger logger = LoggerFactory.getLogger(StateMachineConfig.class);

	@Configuration
	@EnableStateMachine
	public static class ParticipantStateMachineConfig extends EnumStateMachineConfigurerAdapter<States, Events> {
		@Autowired
		QuestionairAction questionnaire;

		@Override
		public void configure(StateMachineStateConfigurer<States, Events> states) throws Exception {
			states.withStates().initial(States.IDENTIFIED)
				.states(EnumSet.allOf(States.class));
		}

		@Override
		public void configure(StateMachineTransitionConfigurer<States, Events> transitions) throws Exception {
			transitions.withExternal().source(States.NEW).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.NEW).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.NEW).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.NEW).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.NEW).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.NEW).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.NEW).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.NEW).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.NEW).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.NEW).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.RANDOMIZED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.RANDOMIZED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.RANDOMIZED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.RANDOMIZED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.RANDOMIZED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.RANDOMIZED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.RANDOMIZED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.RANDOMIZED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.RANDOMIZED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.RANDOMIZED).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.SCREENING).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.SCREENING).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.SCREENING).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.SCREENING).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.SCREENING).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.SCREENING).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.SCREENING).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.SCREENING).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.SCREENING).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.SCREENING).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.SITE_CONTACTING).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.SITE_CONTACTING).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.VISIT_SCHEDUCLED).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.VISITED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.VISITED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.VISITED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.VISITED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.VISITED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.VISITED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.VISITED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.VISITED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.VISITED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.VISITED).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.CONSENTED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.CONSENTED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.CONSENTED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.CONSENTED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.CONSENTED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.CONSENTED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.CONSENTED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.CONSENTED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.CONSENTED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.CONSENTED).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.NOT_QUALIFIED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.NOT_QUALIFIED).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.NOT_INTERESTED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.NOT_INTERESTED).target(States.COMPLETED).event(Events.TrialCompleted).and()
				
				.withExternal().source(States.COMPLETED).target(States.NEW).event(Events.SelectedStudySite).and()
				.withExternal().source(States.COMPLETED).target(States.RANDOMIZED).event(Events.PatientThrough).and()
				.withExternal().source(States.COMPLETED).target(States.SCREENING).event(Events.PatientCampaign).and()
				.withExternal().source(States.COMPLETED).target(States.SITE_CONTACTING).event(Events.SiteToContact).and()
				.withExternal().source(States.COMPLETED).target(States.VISIT_SCHEDUCLED).event(Events.ScheduledVisit).and()
				.withExternal().source(States.COMPLETED).target(States.VISITED).event(Events.SiteVisited).and()
				.withExternal().source(States.COMPLETED).target(States.CONSENTED).event(Events.PatientAcceptConsent).and()
				.withExternal().source(States.COMPLETED).target(States.NOT_QUALIFIED).event(Events.PatientFailed).and()
				.withExternal().source(States.COMPLETED).target(States.NOT_INTERESTED).event(Events.PatientRejected).and()
				.withExternal().source(States.COMPLETED).target(States.COMPLETED).event(Events.TrialCompleted).and();
		}

		@Override
		public void configure(StateMachineConfigurationConfigurer<States, Events> config) throws Exception {
			config.withConfiguration().autoStartup(true);
		}
	}

	@Bean
	public QuestionairAction questionairAction() {
		return new QuestionairAction();
	}

	public static class QuestionairAction implements Action<States, Events> {

		@Override
		public void execute(StateContext<States, Events> context) {
			Message<Events> variables = context.getMessage();
			logger.info("QuestionairAction executed " + variables.toString());
		}
	}

}
