package com.avigosolutions.participantservice;

import java.util.HashMap;
import java.util.Map;

public enum States {
	IDENTIFIED(1), OUTREACHED(2), NEW(3), RANDOMIZED(4), SCREENING(5), SITE_CONTACTING(6), VISIT_SCHEDUCLED(
			7), VISITED(8), CONSENTED(9), NOT_QUALIFIED(10), NOT_INTERESTED(11), COMPLETED(12);
	private int code;
	private static final Map<Integer, States> lookup = new HashMap<>();

	static {
		for (States d : States.values()) {
			lookup.put(d.getCode(), d);
		}
	}

	States(int x) {
		this.code = x;
	}

	public int getCode() {
		return this.code;
	}

	public static States getStateByCode(int x) {
		return lookup.get(x);
	}

	public static void main(String args[]) {
		System.out.println(lookup.get(1));
	}
}
