package com.avigosolutions.participantservice.async.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AsyncConfigLoaderBean {
	
	@Value("${sprintt.zyprr.category.async.processing.threadpool.size.initial}")
	private Integer corePoolSize;
	
	@Value("${sprintt.zyprr.category.async.processing.threadpool.size.max}")
	private Integer maxPoolSize;
	
	@Value("${sprintt.zyprr.category.async.processing.thread.prefix}")
	private String theadPrefixName;
	
	@Value("${sprintt.zyprr.category.async.processing.thread.keepalive.seconds}")
	private Integer keepAliveSeconds;
	
	@Value("${sprintt.zyprr.category.async.processing.thread.queue.capacity}")
	private Integer queueCapacity;
	
	@Value("${sprintt.zyprr.category.save.retry.attempts}")
	private Integer categoryRetryAttempts;
	
	@Value("${sprintt.zyprr.category.save.retry.policy}")
	private Integer categoryRetryPolicy;
	
	@Value("${sprintt.zyprr.category.save.retry.interval.initial}")
	private Integer categoryRetryIntervalInitial;
	
	@Value("${sprintt.zyprr.category.save.retry.interval.max}")
	private Integer categoryRetryIntervalMax;
	
	@Value("${sprintt.zyprr.category.save.retry.interval.multiplier}")
	private Integer categoryRetryIntervalMultiplier;
	
	@Value("${sprintt.zyprr.category.sendcontacts.retry.attempts}")
	private Integer sendContactsRetryAttempts;	
	
	@Value("${sprintt.zyprr.category.sendcontacts.retry.policy}")
	private Integer sendContactsRetryPolicy;	
	
	@Value("${sprintt.zyprr.category.sendcontacts.retry.interval.initial}")
	private Integer sendContactsRetryIntervalInitial;
	
	@Value("${sprintt.zyprr.category.sendcontacts.retry.interval.max}")
	private Integer sendContactsRetryIntervalMax;
	
	@Value("${sprintt.zyprr.category.sendcontacts.retry.interval.multiplier}")
	private Integer sendContactsRetryIntervalMultiplier;
	
	@Value("${sprintt.zyprr.category.batch.retry.attempts}")
	private Integer batchRetryAttempts;	
	
	@Value("${sprintt.zyprr.category.batch.retry.policy}")
	private Integer batchRetryPolicy;	
	
	@Value("${sprintt.zyprr.category.batch.retry.interval.initial}")
	private Integer batchRetryIntervalInitial;
	
	@Value("${sprintt.zyprr.category.batch.retry.interval.max}")
	private Integer batchRetryIntervalMax;
	
	@Value("${sprintt.zyprr.category.batch.retry.interval.multiplier}")
	private Integer batchRetryIntervalMultiplier;

	@Value("${sprintt.zyprr.category.batch.delay.random}")
	private Integer batchRandomDelay;
	
	@Value("${sprintt.zyprr.category.async.processing.thread.batch.prefix}")
	private String batchThreadPrefixName;
	
	@Value("${sprintt.zyprr.batch.reset.time.interval}")
	private Integer batchResetInterval;
	
	@Value("${sprintt.zyprr.batch.deferred.time.interval}")
	private Integer batchDeferredInterval;
	
	@Value("${sprintt.zyprr.batch.attempts.max}")
	private Integer batchMaxAttempts;

	public String getBatchThreadPrefixName() {
		return batchThreadPrefixName;
	}
	
	public Integer getBatchRetryAttempts() {
		return batchRetryAttempts;
	}

	public Integer getBatchRetryPolicy() {
		return batchRetryPolicy;
	}

	public Integer getBatchRetryIntervalInitial() {
		return batchRetryIntervalInitial;
	}

	public Integer getBatchRetryIntervalMax() {
		return batchRetryIntervalMax;
	}
	
	public Integer getBatchResetInterval() {
		return batchResetInterval;
	}
	
	public Integer getBatchDeferredInterval() {
		return batchDeferredInterval;
	}
	
	public Integer getBatchMaxAttempts() {
		return batchMaxAttempts;
	}

	public Integer getBatchRetryIntervalMultiplier() {
		return batchRetryIntervalMultiplier;
	}

	public Integer getBatchRandomDelay() {
		return batchRandomDelay;
	}

	public Integer getCorePoolSize() {
		return corePoolSize;
	}

	public Integer getMaxPoolSize() {
		return maxPoolSize;
	}

	public String getTheadPrefixName() {
		return theadPrefixName;
	}

	public Integer getKeepAliveSeconds() {
		return keepAliveSeconds;
	}

	public Integer getQueueCapacity() {
		return queueCapacity;
	}

	public Integer getCategoryRetryAttempts() {
		return categoryRetryAttempts;
	}

	public Integer getCategoryRetryPolicy() {
		return categoryRetryPolicy;
	}

	public Integer getCategoryRetryIntervalInitial() {
		return categoryRetryIntervalInitial;
	}

	public Integer getCategoryRetryIntervalMax() {
		return categoryRetryIntervalMax;
	}

	public Integer getCategoryRetryIntervalMultiplier() {
		return categoryRetryIntervalMultiplier;
	}

	public Integer getSendContactsRetryAttempts() {
		return sendContactsRetryAttempts;
	}

	public Integer getSendContactsRetryPolicy() {
		return sendContactsRetryPolicy;
	}

	public Integer getSendContactsRetryIntervalInitial() {
		return sendContactsRetryIntervalInitial;
	}

	public Integer getSendContactsRetryIntervalMax() {
		return sendContactsRetryIntervalMax;
	}

	public Integer getSendContactsRetryIntervalMultiplier() {
		return sendContactsRetryIntervalMultiplier;
	}
}
