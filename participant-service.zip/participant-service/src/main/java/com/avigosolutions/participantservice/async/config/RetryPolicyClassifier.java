package com.avigosolutions.participantservice.async.config;

import org.springframework.classify.Classifier;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.NeverRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
 
public class RetryPolicyClassifier extends ExceptionClassifierRetryPolicy
{
   	private static final long serialVersionUID = -7L;

	public RetryPolicyClassifier( Integer maxAttempts)
    {
        final SimpleRetryPolicy simpleRetryPolicy = new SimpleRetryPolicy();
        simpleRetryPolicy.setMaxAttempts(maxAttempts);
 
        this.setExceptionClassifier( new Classifier<Throwable, RetryPolicy>()
        {
            private static final long serialVersionUID = 2L;

			@Override
            public RetryPolicy classify( Throwable classifiable )
            {
                // Don't Retry  when NullPointerException was thrown
                if ( classifiable instanceof NullPointerException)
                {
                	return new NeverRetryPolicy();
                }
 
                // Do retry for other exceptions                          
                return simpleRetryPolicy;
            }
        } );
    }
}
