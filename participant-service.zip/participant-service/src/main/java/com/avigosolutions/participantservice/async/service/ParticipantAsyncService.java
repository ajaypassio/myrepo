package com.avigosolutions.participantservice.async.service;

import java.util.List;
import java.util.concurrent.Future;

import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantJob;

public interface ParticipantAsyncService {
	public Future<List<Participant>> save(List<Participant> participantList,String userId, String correlationId);
	public void CheckAndUpdateJob(String correlationId,String userId,List<Participant> participantList);
	public void addParticipantJobLog(ParticipantJob job);
	public void addParticipantJobLogForCRMCategory(CRMCategory category,String correlationId);
	public void updateParticipantJobLog(String correlationId, Integer contactStatus);
}