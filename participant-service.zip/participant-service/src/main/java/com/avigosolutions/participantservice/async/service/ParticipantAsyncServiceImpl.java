package com.avigosolutions.participantservice.async.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.crm.constants.CRMContactConstants;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantJob;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.repository.ParticipantJobRepository;
import com.avigosolutions.participantservice.repository.ParticipantRepository;
import com.avigosolutions.participantservice.service.ParticipantStudySiteService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ParticipantAsyncServiceImpl implements ParticipantAsyncService {
	@Autowired
	ParticipantRepository participantRepository;

	@Autowired
	ParticipantJobRepository participantJobRepository;

	@Autowired
	ParticipantStudySiteService participantStudySiteService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Async("canThreadPoolTaskExecutor")
	public Future<List<Participant>> save(List<Participant> participantList, String userId, String correlationId) {
		logger.info(">>>Start Async Processing of Participants Save[Count=" + participantList.size()
				+ "] with Thread id: " + Thread.currentThread().getId());

		CheckAndUpdateJob(correlationId, userId, participantList);

		List<Participant> participants = participantRepository.save(participantList);
		participants.forEach(p -> p.withInternalId(0L));

		Set<ParticipantStudySite> pstudysites = new HashSet<>();
		for (Participant prtcpt : participantList) {
			// Trail ID not present no need to insert to child tables
			if (prtcpt.getTrialId() == 0) {
				continue;
			}
			ParticipantStudySite pstudysite = participantStudySiteService
					.findByParticipantIdAndTrialId(prtcpt.getParticipantId(), prtcpt.getTrialId());
			if (pstudysite == null) {
				pstudysite = new ParticipantStudySite();
				pstudysite.withParticipantId(prtcpt.getParticipantId()).withTrialId(prtcpt.getTrialId())
						.withParticipantStatusId(States.IDENTIFIED.getCode());
			}
			pstudysite.withScoreJSON(prtcpt.getScoreJSON());
			pstudysites.add(pstudysite);
		}
		try {
			if (!pstudysites.isEmpty()) {
				participantStudySiteService.save(new ArrayList<>(pstudysites));
			}
		} catch (Exception e) {
			logger.error("Error in initializing Participant studysite", e);
		}
		logger.info("<<< Completed Async Processing of Participants Save[Count=" + participantList.size()
				+ "] with Thread id: " + Thread.currentThread().getId());
		try {
			ParticipantJob job = participantJobRepository.findByCorrelationIdAndSavedSearchNameAndTrialId(correlationId,
					CRMContactConstants.JOB_INPROGRESS_PREFIX+participantList.get(0).getSearchName(), participantList.get(0).getTrialId());
			logger.info(">>After Save Participants, job=>" + job);
			if (job != null) {
				logger.info(">>>Updating the participant save result ParticipantJob for SavedSearch:"
						+ participantList.get(0).getSearchName() + " and TrialId:"
						+ participantList.get(0).getTrialId());
				job.withIsSaved(1).withUpdatedOn(new Date());
				participantJobRepository.save(job);
			}
		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
		}
		return new AsyncResult<>(participants);
	}

	public void CheckAndUpdateJob(String correlationId, String userId, List<Participant> participantList) {
		try {
			ParticipantJob job = participantJobRepository.findByCorrelationIdAndSavedSearchNameAndTrialId(correlationId,
					participantList.get(0).getSearchName(), participantList.get(0).getTrialId());
			if (job == null) {
				job = participantJobRepository.findByCorrelationIdAndSavedSearchNameAndTrialId(correlationId,
						CRMContactConstants.JOB_INPROGRESS_PREFIX + participantList.get(0).getSearchName(),
						participantList.get(0).getTrialId());
				job = job == null ? new ParticipantJob() : job;
			}
			logger.info(">>>Adding an entry in ParticipantJob for SavedSearch:" + participantList.get(0).getSearchName()
					+ " and TrialId:" + participantList.get(0).getTrialId());
			JSONArray participantJsonArray = new JSONArray();
			participantList.forEach(part -> {
				ObjectMapper mapper = new ObjectMapper();
				try {
					participantJsonArray.put(mapper.writeValueAsString(part));
				} catch (JsonProcessingException e) {
					logger.error("Error during conversion from Participant Object to String", e);
				}

			});

			job.withCorrelationId(correlationId).withCreatedBy(userId)
					.withSavedSearchName("INP_" + participantList.get(0).getSearchName())
					.withParticipantJson(participantJsonArray.toString())
					.withTrialId(participantList.get(0).getTrialId()).withIsCategoryCreated(0).withIsSaved(0)
					.withIsContactsPushed(0).withTotalContactBatchCount(getBatchCount(participantList.size(), 100))
					.withTrialName(participantList.get(0).getTrialName()).withCreatedOn(new Date()).withUpdatedOn(new Date())
					.withAttemptsMade(0).withIsDisabled(0);

			participantJobRepository.save(job);

		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
			//throw e;
		}
	}

	public void addParticipantJobLog(String correlationId, String userId, List<Participant> participantList) {
		try {
			ParticipantJob job = participantJobRepository.findByCorrelationIdAndSavedSearchNameAndTrialId(correlationId,
					participantList.get(0).getSearchName(), participantList.get(0).getTrialId());
			if (job == null) {
				job = new ParticipantJob();
			}
			logger.info(">>>Adding an entry in ParticipantJob for SavedSearch:" + participantList.get(0).getSearchName()
					+ " and TrialId:" + participantList.get(0).getTrialId());
			JSONArray participantJsonArray = new JSONArray();
			participantList.forEach(part -> {
				ObjectMapper mapper = new ObjectMapper();
				try {
					participantJsonArray.put(mapper.writeValueAsString(part));
				} catch (JsonProcessingException e) {
					logger.error("Error during conversion from Participant Object to String", e);
				}

			});

			job.withCorrelationId(correlationId).withCreatedBy(userId)
					.withSavedSearchName(participantList.get(0).getSearchName())
					.withParticipantJson(participantJsonArray.toString())
					.withTrialId(participantList.get(0).getTrialId()).withIsCategoryCreated(0).withIsSaved(0)
					.withIsContactsPushed(0).withBatchStatus("")
					.withTotalContactBatchCount(getBatchCount(participantList.size(), 100))
					.withTrialName(participantList.get(0).getTrialName()).withCreatedOn(new Date()).withUpdatedOn(new Date());
			participantJobRepository.save(job);

		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
			//throw e;
		}
	}

	public void addParticipantJobLogForCRMCategory(CRMCategory category, String correlationId) {
		try {
			ParticipantJob job = participantJobRepository.findByCorrelationIdAndSavedSearchNameAndTrialId(correlationId,
					category.getSearchName(), category.getTrialId());
			if (job != null) {
				logger.info(">>>Updating the category creation in ParticipantJob for SavedSearch:"
						+ category.getSearchName() + " and TrialId:" + category.getTrialId());
				job.withIsCategoryCreated(1).withUpdatedOn(new Date());
				participantJobRepository.save(job);
			}
		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
		}
	}

	public void addParticipantJobLog(ParticipantJob job) {
		try {
			if (job != null) {
				logger.info(">>>Adding/Updating Job to DB=>" + job);
				participantJobRepository.save(job.withUpdatedOn(new Date()));
			}
		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
		}
	}

	public void updateParticipantJobLog(String correlationId, Integer contactStatus) {
		try {
			ParticipantJob job = participantJobRepository.findByCorrelationIdEquals(correlationId);
			if (job != null) {
				logger.info(">>>Updating the ParticipantJob for Job:" + job);
				job.withIsContactsPushed(contactStatus).withUpdatedOn(new Date());
				participantJobRepository.save(job);
			}
		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
		}
	}

	private int getBatchCount(int totalpatients, int batchSize) {
		int countBatch100 = totalpatients / batchSize;
		int remain = totalpatients % batchSize;

		if (remain > 0) {
			countBatch100++;
		}

		logger.info("*******TotalBatch Count:" + countBatch100);
		return countBatch100;
	}

}
