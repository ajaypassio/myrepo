package com.avigosolutions.participantservice.audit;

import java.io.Serializable;

public class AuditEntry  implements Serializable  {

	private static final long serialVersionUID = 7445344365317803724L;

	private String name;
	
	private String content;
	
	private Action action;
	
	public AuditEntry(String name, String content, Action action){
		this.withAction(action).withName(name).withContent(content);
	}

	public String getName() {
		return name;
	}

	public AuditEntry withName(String name) {
		this.name = name;
		return this;
	}

	public String getContent() {
		return content;
	}

	public AuditEntry withContent(String content) {
		this.content = content;
		return this;
	}

	public Action getAction() {
		return action;
	}

	public AuditEntry withAction(Action action) {
		this.action = action;
		return this;
	}
}
