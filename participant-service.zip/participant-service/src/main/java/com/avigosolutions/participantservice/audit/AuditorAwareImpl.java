package com.avigosolutions.participantservice.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

import com.avigosolutions.participantservice.SecurityUtil;

class AuditorAwareImpl implements AuditorAware<Long> {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	SecurityUtil securityUtil;
    @Override
    public Long getCurrentAuditor() {
    	try {
    		String uName = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
    		logger.info("**** got username from Security Context Holder" + uName);
    		return securityUtil.getRoleId(uName);
    	}catch(Exception e) {
    		//should not blocked for Audit messages.
    		return 1L;
    	}
     }
}