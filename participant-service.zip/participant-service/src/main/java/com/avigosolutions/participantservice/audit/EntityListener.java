package com.avigosolutions.participantservice.audit;

import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.transaction.Transactional;

import com.avigosolutions.participantservice.model.AuditHistory;
import com.avigosolutions.participantservice.repository.AuditHistoryRepository;

import static javax.transaction.Transactional.TxType.MANDATORY;

public class EntityListener  {
	
    @PrePersist
    public void prePersist(Auditable<Long> target) {        
    	perform(new AuditEntry(target.getClass().getSimpleName(),target.toString(),Action.INSERTED));
    }

    @PreUpdate
    public void preUpdate(Auditable<Long> target) {
    	perform(new AuditEntry(target.getClass().getSimpleName(),target.toString(),Action.UPDATED));
    }

    @PreRemove
    public void preRemove(Auditable<Long> target) {
    	perform(new AuditEntry(target.getClass().getSimpleName(),target.toString(),Action.DELETED));
    }
    
    @Transactional(MANDATORY)
    private void perform(AuditEntry entry) {
    	AuditHistoryRepository auditHistoryRepository = ContextUtil.getBean("auditHistoryRepository", AuditHistoryRepository.class);
    	AuditHistory history =  new AuditHistory(entry);
    	auditHistoryRepository.save(history);
    }
}