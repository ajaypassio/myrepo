package com.avigosolutions.participantservice.common;

import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

@Component
public class CommonUtil {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public static int getDiffYears(Date first, Date last) {
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
		if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH)
				|| (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a.get(Calendar.DATE) > b.get(Calendar.DATE))) {
			diff--;
		}
		return diff;
	}

	public static Calendar getCalendar(Date date) {
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(date);
		return cal;
	}

	public static String convertDate(Date date) {
		DateFormat df = new SimpleDateFormat("MM-dd-yyyy");
		String text = df.format(date);
		System.out.println("The date is: " + text);
		return text;

	}

	public static boolean isNull(String str) {
		return str == null ? true : false;
	}

	public static boolean isNullOrBlank(String param) {
		if (isNull(param) || param.trim().length() == 0) {
			return true;
		}
		return false;
	}
	
	public static <T> boolean IsNullOrEmpty(Collection<T> list) {
	    return list == null || list.isEmpty();
	}
	
	public static boolean isNullOrEmpty(Date date) {
		if (null == date || date.toString().trim().isEmpty()) {
			return true;
		}
		return false;
	}
	
	public static PageRequest getPageRequest(int page, int size) {
		PageRequest pageRequest =  new PageRequest(page, size);
		return pageRequest;
	}	

	/*
	 * Function to generate PageRequest object based on the filter params
	 */
	public static PageRequest getPageRequest(int page, int size, String columnToSort, String sortType) {
		PageRequest pageRequest = new PageRequest(page, size);
		// Sorting will work only if the user passes the column name to sort with a
		// sorting order
		if (null != sortType && !sortType.equals("") && null != columnToSort && !columnToSort.equals("")) {
			if (sortType.equalsIgnoreCase(Constants.ASCENDING_ORDER)) {
				pageRequest = new PageRequest(page, size, Sort.Direction.ASC, columnToSort);
			} else if (sortType.equalsIgnoreCase(Constants.DESCENDING_ORDER)) {
				pageRequest = new PageRequest(page, size, Sort.Direction.DESC, columnToSort);
			}
		}
		return pageRequest;
	}

	/*public static int gcd(int p, int q) {
		if (q == 0)
			return p;
		else
			return gcd(q, p % q);
	}*/
	static int gcd(int x, int y)
    {
        int r=0, a, b;
        a = (x > y) ? x : y; // a is greater number
        b = (x < y) ? x : y; // b is smaller number
 
        r = b;
        while(a % b != 0)
        {
            r = a % b;
            a = b;
            b = r;
        }
        return r;
    }

	/*
	 * public static String ratio(int a, int b) { final int gcd = gcd(a, b);
	 * 
	 * return "" + (a / gcd + " : " + b / gcd) + ""; }
	 */
	public static String ratio(int a, int b) {
		int gcd = gcd(a, b);
		System.out.println(gcd);
		if (a > b) {
			a=a/gcd;
			b=b/gcd;
			gcd= gcd(a, b);
			// showAnswer(a/gcd, b/gcd);
			return "" + (a / gcd + " : " + b / gcd) + "";
		} else {
			// showAnswer(b/gcd, a/gcd);
			return "" + (b / gcd + " : " + a / gcd) + "";
		}
	}
	public static String getURLDecodeString(String encoded) {
		return URLDecoder.decode(encoded);
	}
	public static String getEncodedString(String message) {
	    message = message.replace( '\n' ,  '_' ).replace( '\r' , '_' )
	      .replace( '\t' , '_' );
	    message = ESAPI.encoder().encodeForHTML(message );
	    return message;
	}
	
	public boolean ValidateNumberString(String numString, String delimiter) {
		String delimExpr = (delimiter!=null && !delimiter.isEmpty())?"\\"+delimiter+"*":"";
		String numberRegex = "\\b([0-9]"+delimExpr+")+\\b";
		logger.info("Regular Expression:"+numberRegex);
		
		if(Pattern.matches(numberRegex, numString)) {
			return true;
		}else {
			return false;
		}
		
	}	
}
