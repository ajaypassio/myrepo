package com.avigosolutions.participantservice.common;

public class Constants {

	public static String ASCENDING_ORDER = "asc";
	public static String DESCENDING_ORDER = "desc";

	public static final String PARTICIPANT_ID = "participantId";
	public static final String PARTICIPANT_TRIAL = "participantTrial";
	public static final String TRIAL_ID = "trialId";
	public static final String STATUS_NOTES = "statusNotes";
	public static final String SOURCE_STATE_ID = "sourceStateId";
	public static final String FROM_STATUS = "fromStatus";
	public static final String TO_STATUS = "toStatus";
	public static final String STUDY_SITE_ID="studySiteId";
	public static final String PAGE="page";
	public static final String PAGESIZE="pageSize";
	public static final String NOTES = "notes";
	
}
