package com.avigosolutions.participantservice.controllers;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.crm.service.CRMContactsService;
import com.avigosolutions.participantservice.dto.ParticipantQuestionnaireDto;
import com.avigosolutions.participantservice.model.ParticipantQuestion;
import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
import com.avigosolutions.participantservice.request.model.CRMContactUpdateRequest;
import com.avigosolutions.participantservice.service.ParticipantQuestionService;
import com.avigosolutions.participantservice.service.ParticipantQuestionnaireService;
import com.avigosolutions.participantservice.service.ParticipantService;
import com.avigosolutions.participantservice.service.ParticipantStudySiteService;
import com.avigosolutions.participantservice.service.PatientConsentService;


@Controller
@RequestMapping(path = "/campaigns")
public class CampaignController {
	@Autowired
	ParticipantQuestionService participantQuestionService;

	@Autowired
	ParticipantQuestionnaireService participantQuestionnaireService;

	@Autowired
	ParticipantStudySiteService participantStudySiteService;

	@Autowired
	ParticipantService participantService;

	@Autowired
	private CRMContactsService crmContactsService;
	
	@Autowired
	PatientConsentService patientConsentService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(value = "/questionnaire/{trialId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<ParticipantQuestionnaire> saveParticipantQuestionnaire(@RequestHeader HttpHeaders headers,
			@RequestBody ParticipantQuestionnaire participantQuestionnaire, @PathVariable("trialId") String trialId) {
		ParticipantQuestionnaire savedParticipantQuestionnaire = participantQuestionnaireService
				.saveParticipantQuestionnaire(trialId, participantQuestionnaire);
		if (savedParticipantQuestionnaire == null)
			return new ResponseEntity<ParticipantQuestionnaire>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ParticipantQuestionnaire>(savedParticipantQuestionnaire, HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/questionnaire", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ParticipantQuestionnaire> getParticipantQuestionnaireByParticipantAndQuestionnaireId(
			@RequestHeader HttpHeaders headers, @RequestParam(value = "participant_id") String participantId,
			@RequestParam(value = "questionnaire_id") long questionnaireId, @RequestParam(value = "isEncoded",defaultValue ="true") boolean isEncoded) {

		ParticipantQuestionnaire existingOne = this.participantQuestionnaireService
				.getParticipantQuestionnaire(participantId, questionnaireId,isEncoded);
		return new ResponseEntity<ParticipantQuestionnaire>(existingOne, HttpStatus.CREATED);
	}

	/****
	 * Method to return Participant record for given ParticipantId
	 * 
	 * @param participantQuestionnaireId
	 * 
	 */

	@ResponseBody
	@RequestMapping(path = "/questionnaire/{participantQuestionnaireId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ParticipantQuestionnaire> getParticpantQuestionnaire(@RequestHeader HttpHeaders headers,
			@PathVariable("participantQuestionnaireId") Long participantQuestionnaireId) {
		ParticipantQuestionnaire participantQuestionnaire = this.participantQuestionnaireService
				.getParticipantQuestionnaire(participantQuestionnaireId);
		if (participantQuestionnaire == null)
			return new ResponseEntity<ParticipantQuestionnaire>(participantQuestionnaire, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ParticipantQuestionnaire>(participantQuestionnaire, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/questionnaire/participantQuestions/{participantQuestionId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ParticipantQuestion> getParticpantAnsweredQuestions(@RequestHeader HttpHeaders headers,
			@PathVariable("participantQuestionnaireId") Long participantQuestionId) {
		ParticipantQuestion participantQuestion = this.participantQuestionService
				.getParticipantQuestion(participantQuestionId);

		if (participantQuestion == null)
			return new ResponseEntity<ParticipantQuestion>(participantQuestion, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ParticipantQuestion>(participantQuestion, HttpStatus.OK);

	}

	/**
	 * 
	 * @param participantQuestionnaireId
	 * @return List of ParticipantQuestionnaires
	 */
	@ResponseBody
	@RequestMapping(path = "/participantQuestionnaires/{participantId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ParticipantQuestionnaireDto>> getParticipantQuestionnaires(
			@RequestHeader HttpHeaders headers, @PathVariable("participantId") String participantId) {
		List<ParticipantQuestionnaireDto> participantQuestionnaire = this.participantQuestionnaireService
				.getParticipantQuestionnaires(participantId);
		if (participantQuestionnaire == null)
			return new ResponseEntity<List<ParticipantQuestionnaireDto>>(participantQuestionnaire,
					HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ParticipantQuestionnaireDto>>(participantQuestionnaire, HttpStatus.OK);
	}

	/**
	 * 
	 * @param participantId
	 * @return List of ParticipantQuestionnaires and ParticipantQuestions associated
	 *         with those questionnaires
	 */
	@ResponseBody
	@RequestMapping(path = "/participantQuestionnairesAndQuestions/{participantId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ParticipantQuestionnaire>> getParticipantQuestionnairesAndQuestions(
			@RequestHeader HttpHeaders headers, @PathVariable("participantId") String participantId) {
		// String converted into encoded format
		participantId = CommonUtil.getEncodedString(participantId);
		
		List<ParticipantQuestionnaire> participantQuestionnaire = this.participantQuestionnaireService
				.getParticipantQuestionnairebyParticipantId(participantId);
		if (participantQuestionnaire == null)
			return new ResponseEntity<List<ParticipantQuestionnaire>>(participantQuestionnaire, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ParticipantQuestionnaire>>(participantQuestionnaire, HttpStatus.OK);
	}

	/**
	 * 
	 * @param participantQuestionnaireId
	 * @return LastQuestionAnswered from ParticipantQuestionnaire
	 */
	@RequestMapping(value = "/last_questionnaire/{participantQuestionnaireId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ParticipantQuestionnaire> getLastAnsweredQuestion(@RequestHeader HttpHeaders headers,
			@PathVariable("participantQuestionnaireId") Long participantQuestionnaireId) {
		System.out.println(participantQuestionnaireId);
		ParticipantQuestionnaire participantQuestionnare = this.participantQuestionnaireService
				.getParticipantQuestionnaire(participantQuestionnaireId);
		if (participantQuestionnare != null) {
			return new ResponseEntity<ParticipantQuestionnaire>(participantQuestionnare, HttpStatus.OK);
		}
		return new ResponseEntity<ParticipantQuestionnaire>(HttpStatus.NOT_FOUND);
	}
	
	//commented the method below based on disucssion for PDR 3415
	//@RequestMapping(value = "/question", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ParticipantQuestion> createQuestion(@RequestHeader HttpHeaders headers,
			@RequestBody ParticipantQuestion participantQuestion) {

		ParticipantQuestion existingOne = this.participantQuestionService.findByParticipantIdAndQuestionId(
				participantQuestion.getParticipantId(), participantQuestion.getQuestionId());
		if (existingOne != null) {
			existingOne.withAnswer(participantQuestion.getAnswer());
			participantQuestion = this.participantQuestionService.save(existingOne);
		} else {
			participantQuestion = this.participantQuestionService.save(participantQuestion);
		}
		if (participantQuestion == null)
			return new ResponseEntity<ParticipantQuestion>(HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ParticipantQuestion>(participantQuestion, HttpStatus.CREATED);
	}

	/**
	 * 
	 * @return response
	 */
	//commented the method below based on disucssion for PDR 3415
	//@RequestMapping(value = "/get/contact/update", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<String> updateCRMContactCustomField(@RequestHeader HttpHeaders headers,
			@RequestBody CRMContactUpdateRequest contactUpdateRequest) {
		String value = this.crmContactsService.updateCRMContactCustomField(contactUpdateRequest.getPatientId(),
				contactUpdateRequest.getCustomFieldName(), contactUpdateRequest.getCustomFieldValue());
		if (value.isEmpty() || value == null) {
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<String>(value, HttpStatus.OK);
	}
	
	//commented the method below based on disucssion for PDR 3415
	//@RequestMapping(value = "/get/contact/update/questionnaire/status", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<String> updateCRMContactQuestionnaireStatus(@RequestHeader HttpHeaders headers,
			@RequestBody CRMContactUpdateRequest contactUpdateRequest) {
		String value = this.crmContactsService.updateCRMContactQuestionnaireStatus(contactUpdateRequest.getPatientId(),
				contactUpdateRequest.getCustomFieldName(), contactUpdateRequest.getCustomFieldValue());
		//if (value.isEmpty() || value == null) {
		//	return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		//}
		return new ResponseEntity<String>(value, HttpStatus.OK);
	}
	
	
	
	

	
	
	
	
	
	
	

}
