package com.avigosolutions.participantservice.controllers;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.common.Constants;
import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.crm.async.service.CRMContactJobService;
import com.avigosolutions.participantservice.crm.async.service.CrmAsyncService;
import com.avigosolutions.participantservice.crm.service.CRMTasksService;
import com.avigosolutions.participantservice.dto.CountModel;
import com.avigosolutions.participantservice.dto.ParticipantStudySiteStatistics;
import com.avigosolutions.participantservice.dto.ParticipantTrialInfo;
import com.avigosolutions.participantservice.dto.ParticipantTrialsDto;
import com.avigosolutions.participantservice.dto.ParticipantUpdate;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantStatus;
import com.avigosolutions.participantservice.model.ParticipantStudySiteHistory;
import com.avigosolutions.participantservice.request.model.LocationSearch;
import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
import com.avigosolutions.participantservice.request.model.ParticipantStudySiteFilterModel;
import com.avigosolutions.participantservice.response.model.DateModel;
import com.avigosolutions.participantservice.response.model.LocationResponse;
import com.avigosolutions.participantservice.response.model.ResponseObjectModel;
import com.avigosolutions.participantservice.service.ParticipantService;
import com.avigosolutions.participantservice.service.ParticipantStudySiteService;
import com.avigosolutions.participantservice.utils.EncryptionUtils;
import com.questdiagnostics.mongo.model.ParsedQualtricsReponse;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForAdmin;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForSiteCoord;

@Controller
@RequestMapping(path = "/participant")
public class ParticipantController {

	@Autowired
	private ParticipantService participantService;

	@Autowired
	private ParticipantStudySiteService participantStudySiteService;

	@Autowired
	private CRMTasksService crmTasksService;

	@Autowired
	private ResponseObjectModel responseObjectModel;

	@Autowired
	CrmAsyncService cRMAsyncService;

	@Autowired
	CRMContactJobService cRMContactJobService;
	
	@Value("${sprintt.uuid}")
	String springUuid;
	

	@Autowired
	private MongoTemplate template;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/trials/{participantId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ParticipantTrialsDto>> getAllTrials(@RequestHeader HttpHeaders headers,
			@PathVariable("participantId") String participantId) {
		List<ParticipantTrialsDto> participantTrialsDto = this.participantService
				.findTrialsbyParticipantId(participantId);

		if (participantTrialsDto == null)
			return new ResponseEntity<List<ParticipantTrialsDto>>(participantTrialsDto, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<ParticipantTrialsDto>>(participantTrialsDto, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/batch", method = RequestMethod.GET)
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<String>> batchProcessCRMContacts(@RequestHeader HttpHeaders headers) {
		this.cRMAsyncService.batchProcess();
		List<String> lstSuccess = new ArrayList<String>();
		lstSuccess.add("Success");
		return new ResponseEntity<List<String>>(lstSuccess, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/trail/detail/{participantId}/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ParticipantTrialInfo> getTrialInfo(@RequestHeader HttpHeaders headers,
			@PathVariable("participantId") String participantId, @PathVariable("trialId") Long trialId) {
		ParticipantTrialInfo participantTrialInfo = this.participantService.findTrialdetails(participantId, trialId);

		if (participantTrialInfo == null)
			return new ResponseEntity<ParticipantTrialInfo>(participantTrialInfo, HttpStatus.NOT_FOUND);
		return new ResponseEntity<ParticipantTrialInfo>(participantTrialInfo, HttpStatus.OK);

	}

	@RequestMapping(value = "/studysites/{participantId}", method = RequestMethod.PUT)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')")
	public ResponseEntity<ParticipantUpdate> updateParticipant(@RequestHeader HttpHeaders headers,
			@PathVariable String participantId, @RequestBody ParticipantUpdate participantUpdate) {
		System.out.println("----UPDATE: " + participantId + "---" + participantUpdate.getStudyId());
		participantUpdate.setParticipantId(participantId);
		ParticipantUpdate update = participantService.participantUpdate(participantUpdate);
		if (update == null)
			return new ResponseEntity<ParticipantUpdate>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<ParticipantUpdate>(update, HttpStatus.OK);
	}

	/*
	 * Get study site list by trailId and Study site Id
	 * 1) SC-trial click
	 */
	@ResponseBody
	@RequestMapping(path = "/studysites/{trialId}/{studySiteId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseObjectModel getParticipantsByTrialIdAndStudySiteId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @PathVariable("studySiteId") Long studySiteId,
			@RequestBody ParticipantRequestFilterModel participantRequestFilter) {
		try {
			responseObjectModel = participantStudySiteService.getParticipantsbyTrialIdAndStudySiteId(trialId,
					studySiteId, participantRequestFilter);
		} catch (Exception e) {
			responseObjectModel.setStatus(400);
			responseObjectModel.setMessage("Something went wrong. Please try again later");
		}
		return responseObjectModel;
	}

	@ResponseBody
	@RequestMapping(path = "/studysiteparticipant/filter", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Participant>> getAllParticipantsByStudySiteIdAndTrialId(
			@RequestHeader HttpHeaders headers, @RequestBody ParticipantStudySiteFilterModel filterModel) {

		List<Participant> participantList = this.participantService.getParticipantsByStudySiteIdAndTrialId(filterModel);
		if (participantList == null)
			return new ResponseEntity<List<Participant>>(participantList, HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Participant>>(participantList, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/studysiteparticipant/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Participant>> getAllParticipantsByStudySiteId(@RequestHeader HttpHeaders headers,
			@PathVariable("studySiteId") Long studySiteId) {
		System.out.println("******  In participant controller");

		List<Participant> participantList = this.participantService.getParticipantsByStudySiteId(studySiteId);
		if (participantList == null)
			return new ResponseEntity<List<Participant>>(participantList, HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Participant>>(participantList, HttpStatus.OK);

	}

	@RequestMapping(value = "/participantstatus", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ParticipantStatus>> getAllParticipantStatus(@RequestHeader HttpHeaders headers) {

		List<ParticipantStatus> participantStatusList = participantService.getAllParticipantStatus();
		if (participantStatusList == null)
			return new ResponseEntity<List<ParticipantStatus>>(participantStatusList, HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<ParticipantStatus>>(participantStatusList, HttpStatus.OK);
	}

	/*
	 * @RequestMapping(value = "/update/status", method = RequestMethod.PUT)
	 * 
	 * @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','PUT')") public
	 * ResponseEntity<ParticipantStudySite> updateParticipantStatus(@RequestHeader
	 * HttpHeaders headers,
	 * 
	 * @RequestParam("participantId") String participantId, @RequestParam("trialId")
	 * Long trialId,
	 * 
	 * @RequestParam("studySiteId") Long studySiteId, @RequestParam("statusId") Long
	 * statusId) {
	 * 
	 * ParticipantStudySite update =
	 * participantService.updateParticipantStatus(participantId, trialId,
	 * studySiteId, statusId); if (update == null) return new
	 * ResponseEntity<ParticipantStudySite>(update, HttpStatus.NOT_FOUND); return
	 * new ResponseEntity<ParticipantStudySite>(update, HttpStatus.OK); }
	 */

	@ResponseBody
	@RequestMapping(path = "/studysites/count/{trialId}/{studySiteId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<CountModel>> getParticipantCountsByParticipantStatusId(
			@RequestHeader HttpHeaders headers, @PathVariable("trialId") Long trialId,
			@PathVariable("studySiteId") List<Long> studySiteId) {
		List<Long> lstStatusId = new ArrayList<Long>();
		lstStatusId.add((long) States.RANDOMIZED.getCode());// Enrollment
		lstStatusId.add((long) States.NEW.getCode());// Referred
		List<CountModel> lstCount = this.participantStudySiteService
				.countByParticipantStatusIdAndStudySiteIdAndTrialId(lstStatusId, studySiteId, trialId);

		return new ResponseEntity<List<CountModel>>(lstCount, HttpStatus.OK);

	}

	// It is used inside criteria service

	@ResponseBody
	@RequestMapping(path = "/studysites/count/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getParticipantCountsByParticipantStatusIdByTrialId(
			@RequestHeader HttpHeaders headers, @PathVariable("trialId") Long trialId) {
		List<Long> lstStatusId = new ArrayList<Long>();
		lstStatusId.add((long) States.RANDOMIZED.getCode());// Enrollment
		lstStatusId.add((long) States.NEW.getCode());// Referred
		// lstStatusId.add(2L);
		List<CountModel> lstCount = this.participantStudySiteService.countByParticipantStatusIdAndTrialId(lstStatusId,
				trialId);
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setData(lstCount);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/status/count/{trialId}/{statusId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getParticipantCountsByParticipantStatusIdByTrialIds(
			@RequestHeader HttpHeaders headers, @PathVariable("trialId") List<Long> trialId,
			@PathVariable("statusId") List<Long> statusId) {

		List<CountModel> lstCount = this.participantStudySiteService.countByParticipantStatusIdInAndTrialIdIn(statusId,
				trialId);
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setData(lstCount);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/status/count/trial", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getParticipantCountsByStatusIdByTrialIds(
			@RequestHeader HttpHeaders headers, MultiValueMap<String, List<Long>> map) {

		List<CountModel> lstCount = this.participantStudySiteService
				.countByParticipantStatusIdInAndTrialIdIn(map.get("status").get(0), map.get("trial").get(0));
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setData(lstCount);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/first_last_status/trial", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getFirstAndLastPatientDate(@RequestHeader HttpHeaders headers,
			@RequestParam("trialId") Long trialId) {

		List<DateModel> lstCount = this.participantStudySiteService.findFirstAndLastPatientDate(trialId);
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setData(lstCount);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/studysite/status/count/{trialId}/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<ParticipantStudySiteStatistics>> countByTrialIdAndStudySiteId(
			@RequestHeader HttpHeaders headers, @PathVariable("trialId") Long trialId,
			@PathVariable("studySiteId") Long studySiteId) {
		List<ParticipantStudySiteStatistics> lstCount = participantStudySiteService
				.findParticipantStudySiteCountByTrialIdAndStudySiteId(trialId, studySiteId);
		return new ResponseEntity<List<ParticipantStudySiteStatistics>>(lstCount, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/count/trial/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Long> countByTrialId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId) {
		long count = this.participantStudySiteService.countByTrialId(trialId);
		return new ResponseEntity<Long>(count, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','POST')")
	public ResponseEntity<Participant> createParticipant(@RequestHeader HttpHeaders headers,
			@RequestBody Participant participant) {
		logger.info("******  participant controller createParticipant");
		Participant pRet = this.participantService.save(participant);
		// List<Participant> participantList =
		// this.participantService.getParticipantsByStudySiteId(studySiteId);
		if (pRet == null)
			return new ResponseEntity<Participant>(HttpStatus.INTERNAL_SERVER_ERROR);

		return new ResponseEntity<Participant>(pRet, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/addAll", method = RequestMethod.POST)
	// security
	// issue@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<Participant>> createParticipants(@RequestHeader HttpHeaders headers,
			@RequestBody List<Participant> participants) {
		logger.info("******  participant controller createParticipants");
		String userId = headers.containsKey("UUID") ? headers.get("UUID").get(0) : springUuid;
		String correlationId = headers.containsKey("correlationId") ? headers.get("correlationId").get(0) : "";
		List<Participant> pRet = this.participantService.save(participants, userId, correlationId);
		if (pRet == null)
			return new ResponseEntity<List<Participant>>(HttpStatus.INTERNAL_SERVER_ERROR);

		return new ResponseEntity<List<Participant>>(pRet, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/updateCRMCategory", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<String> updateCRMCategory(@RequestHeader HttpHeaders headers,
			@RequestBody CRMCategory category) {
		logger.info("******  participant controller updateCRMCategory");
		crmTasksService.createCRMTasks(category, false);

		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/addCRMSubstitution", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<String> addCRMSubstitution(@RequestHeader HttpHeaders headers,
			@RequestParam("key") String key, @RequestParam("value") String value) {
		logger.info("******  participant controller addCRMSubstitution");
		Map<String, String> subs = new HashMap<>();
		try {
			subs.put(URLDecoder.decode(key, "UTF-8"), URLDecoder.decode(value, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			logger.error("Unsupported decoding");
		}
		crmTasksService.createCRMTasks(subs);
		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/{participantId}", method = RequestMethod.GET)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Participant> getAllCriteria(@RequestHeader HttpHeaders headers,
			@PathVariable String participantId) {
		
		Participant participant = this.participantService.findOne(EncryptionUtils.getInstance().decryptFromBase64(CommonUtil.getURLDecodeString(participantId)));
		if (participant == null)
			return new ResponseEntity<Participant>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Participant>(participant, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantstudysite/history/add", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> saveParticipantStudySiteHistory(@RequestHeader HttpHeaders headers,
			@RequestBody ParticipantStudySiteHistory participantStudySiteHistory) throws Exception {
		ResponseObjectModel response = new ResponseObjectModel();
		response = participantStudySiteService.saveHistory(participantStudySiteHistory, headers);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantstudysite/history", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getParticipantStudySiteHistory(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STUDY_SITE_ID, required = true) Long studySiteId,
			@RequestParam(value = Constants.PAGE, required = true) int page,
			@RequestParam(value = Constants.PAGESIZE, required = true) int pageSize) throws Exception {

		ResponseObjectModel response = new ResponseObjectModel();
		// String converted into encoded format
		participantId = EncryptionUtils.getInstance().decryptFromBase64(CommonUtil.getURLDecodeString(participantId));
		response = participantStudySiteService.getHistory(participantId, trialId, studySiteId, page, pageSize);
		return new ResponseEntity<ResponseObjectModel>(response, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/studysites/status/count/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> getCountByParticipantStatusId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId) {
		Map<String, Object> count = this.participantStudySiteService.getParticipantStudySiteStatistics(trialId);
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setData(count);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(path = "/batch/status/{searchName}/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<CRMContactJob>> getBySearchNameAndTrialId(@RequestHeader HttpHeaders headers,
			@PathVariable("searchName") String searchName, @PathVariable("trialId") Long trialId)
			throws UnsupportedEncodingException {
		List<CRMContactJob> lstJob = this.cRMContactJobService
				.getBySearchNameAndTrialId(URLDecoder.decode(searchName, "UTF-8"), trialId);
		return new ResponseEntity<List<CRMContactJob>>(lstJob, HttpStatus.OK);
	}

	/*
	 * Get study site states by trailId and Study site Id
	 */
	@ResponseBody
	@RequestMapping(path = "/state/{trialId}/{studySiteId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<LocationResponse> getStatesByTrialIdAndStudySiteId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @PathVariable("studySiteId") Long studySiteId,
			@RequestParam(value = "stateName") String stateName,
			@RequestParam(value = "start", required = false) Integer start,
			@RequestParam(value = "pageSize", required = false) Integer pageSize) {
		if (pageSize ==null)
			pageSize = 20;
		if(start==null) {
			start=0;
		}
		LocationResponse response = participantStudySiteService.getStatesByTrialIdAndStudySiteId(trialId, studySiteId,
				stateName, start, pageSize,headers);
		return new ResponseEntity<LocationResponse>(response, HttpStatus.OK);
	}

	/*
	 * Get study site cities by trailId and Study site Id
	 */
	@ResponseBody
	@RequestMapping(path = "/city/{trialId}/{studySiteId}", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<LocationResponse> getCitesByTrialIdAndStudySiteId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") Long trialId, @PathVariable("studySiteId") Long studySiteId,
			@RequestBody LocationSearch locationSearch) {
		LocationResponse response = participantStudySiteService.getCitesByTrialIdAndStudySiteId(trialId, studySiteId,
				locationSearch.getStateName(), locationSearch.getCityName(), locationSearch.getStart(),
				locationSearch.getPageSize());
		return new ResponseEntity<LocationResponse>(response, HttpStatus.OK);
	}
	
	/*
	 * Get study site cities by trailId and Study site Id
	 */
	@ResponseBody
	@RequestMapping(path = "/transaction/{trialId}/{participantId}", method = RequestMethod.POST)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> storeTransactionId(@RequestHeader HttpHeaders headers,
			@PathVariable("trialId") String trialId, @PathVariable("participantId") String participantId) {
		
		trialId=EncryptionUtils.getInstance().decryptFromBase64(CommonUtil.getURLDecodeString(trialId));
		if (!template.collectionExists("T_"+trialId)) {
			template.createCollection("T_"+trialId);
		}
		participantId=CommonUtil.getURLDecodeString(participantId);
		String transactionId=UUID.randomUUID().toString();
		 ParsedQualtricsReponse document = new ParsedQualtricsReponse();
		 document.set_id(transactionId);
		 document.setPid(EncryptionUtils.getInstance().decryptFromBase64(participantId));
		 document.setTrialId(trialId);
		 document.setTransactionId(transactionId);
		 
			SurveyResponseInfoForAdmin adminPortalInfo = new SurveyResponseInfoForAdmin();
			adminPortalInfo.setPid(EncryptionUtils.getInstance().decryptFromBase64(participantId));
			
			SurveyResponseInfoForSiteCoord siteCoordinatorPortalInfo = new SurveyResponseInfoForSiteCoord();
			siteCoordinatorPortalInfo.setPid(participantId);
			document.setAdminPortalInfo(adminPortalInfo);
			document.setSiteCoordinatorPortalInfo(siteCoordinatorPortalInfo);
			
	   template.insert(document,"T_"+trialId);
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setMessage(transactionId);
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(path = "/update/{transactionId}/{trialId}", method = RequestMethod.POST)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<ResponseObjectModel> updateTransactionId(@RequestHeader HttpHeaders headers,
			@PathVariable("transactionId") String transactionId,@PathVariable("trialId") String trialId) {
		if (!template.collectionExists("T_"+trialId)) {
			template.createCollection("T_"+trialId);
		}
	//	HashMap<String, String> mapValue=new HashMap<String, String>();
	//	mapValue.put("transactionId", UUID.randomUUID().toString());
	//	mapValue.put("trialId", trialId);
		
		// document
		 
		 
		HashMap<String, String> mapValue=new HashMap<String, String>();
		mapValue.put("responseId", "R_5812364");
		ResponseObjectModel responseObject = new ResponseObjectModel();
		responseObject.setMessage(springUuid);
		 Query query = new Query();
		
	        query.addCriteria(Criteria.where("_id").is(transactionId) );
	        Update update = new Update();
	       update.set("adminvalue", mapValue);
	      // update.set("admin", "Y");
	        update.set("responseObject", responseObject);
		template.upsert(query, update,"T_"+trialId);
		
	//	Query query1 = new Query();
		query.addCriteria(Criteria.where("admin").exists(true));
		
		System.out.println("count is "+template.count(query, "T_"+trialId));
		
		//template.updateFirst(query, update,"T_"+trialId);
		
		return new ResponseEntity<ResponseObjectModel>(responseObject, HttpStatus.OK);
	}
}
