/**
 * 1. As per the pen test encrypted patient id will be return from all the APIs
 * 2. Have to decrypt it while doing the other processes. 
 * 
 *  **/
package com.avigosolutions.participantservice.controllers;

import java.util.ArrayList;
import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.common.Constants;
import com.avigosolutions.participantservice.crm.service.CRMContactsService;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.exception.RecordNotFoundException;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantQuestion;
import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.PatientConsent;
import com.avigosolutions.participantservice.request.model.CRMContactUpdateRequest;
import com.avigosolutions.participantservice.response.model.PatientConsentResponse;
import com.avigosolutions.participantservice.response.model.ResponseObjectModel;
import com.avigosolutions.participantservice.service.ParticipantQuestionService;
import com.avigosolutions.participantservice.service.ParticipantQuestionnaireService;
import com.avigosolutions.participantservice.service.ParticipantService;
import com.avigosolutions.participantservice.service.ParticipantStateService;
import com.avigosolutions.participantservice.service.PatientConsentService;
import com.avigosolutions.participantservice.utils.EncryptionUtils;
import com.questdiagnostics.mongo.model.ParsedQualtricsReponse;

@Controller
@RequestMapping(path = "/participant/patient")
public class PatientPortalController {

	@Autowired
	ParticipantStateService participantStateService;

	@Autowired
	ParticipantQuestionService participantQuestionService;

	@Autowired
	private CRMContactsService crmContactsService;

	@Autowired
	ParticipantQuestionnaireService participantQuestionnaireService;
	
	@Autowired
	PatientConsentService patientConsentService;
	
	@Autowired
	private ParticipantService participantService;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private MongoTemplate template;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/statemachine/participantTrial/patientFailed", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<States> patientFailed(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		participantId=CommonUtil.getURLDecodeString(participantId);		
		statusNotes=CommonUtil.getEncodedString(statusNotes);
		States state = null;
		participantId = EncryptionUtils.getInstance().decryptFromBase64(participantId);

		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		state = participantStateService.triggerPatientFailed(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_MODIFIED);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/statemachine/participantTrial/emailCampaign", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<States> emailCampaign(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		participantId=CommonUtil.getURLDecodeString(participantId);
		statusNotes=CommonUtil.getEncodedString(statusNotes);
		States state = null;
		participantId = EncryptionUtils.getInstance().decryptFromBase64(participantId);	
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		state = participantStateService.triggerEmailCampaign(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_MODIFIED);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	// Need to check when it was called
	@ResponseBody
	@RequestMapping(path = "/statemachine/participantTrial/emailsCampaign", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<String> emailsCampaign(@RequestHeader HttpHeaders headers, @RequestBody String payload)
			throws Exception {
		if (payload == null || payload.isEmpty()) {
			logger.error("emailsCampaign states can't be empty");
			new ResponseEntity<String>("FAILURE", HttpStatus.OK);
		}
		participantStateService.triggerEmailsCampaign(payload, headers);

		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/statemachine/participantTrial/attemptQuestion", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<States> attemptQuestion(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		participantId=CommonUtil.getURLDecodeString(participantId);
		statusNotes=CommonUtil.getEncodedString(statusNotes);
		States state = null;
		participantId = EncryptionUtils.getInstance().decryptFromBase64(participantId);
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		state = participantStateService.triggerAttemptQuestion(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_MODIFIED);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/statemachine/participantTrial/selectedStudySite", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<States> selectedStudySite(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		participantId=CommonUtil.getURLDecodeString(participantId);
		statusNotes=CommonUtil.getEncodedString(statusNotes);
		States state = null;
		
		participantId = EncryptionUtils.getInstance().decryptFromBase64(participantId);
		
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		state = participantStateService.triggerSelectedStudySite(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_MODIFIED);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	// Need to check when it is called
	@RequestMapping(value = "/campaigns/get/contact/update", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<String> updateCRMContactCustomField(@RequestHeader HttpHeaders headers,
			@RequestBody CRMContactUpdateRequest contactUpdateRequest) {
		String value = this.crmContactsService.updateCRMContactCustomField(
				EncryptionUtils.getInstance().decryptFromBase64(contactUpdateRequest.getPatientId()),
				contactUpdateRequest.getCustomFieldName(), contactUpdateRequest.getCustomFieldValue());
		if (value == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_MODIFIED);
		}
		return new ResponseEntity<String>(value, HttpStatus.OK);
	}
//2nd call
	@ResponseBody
	@RequestMapping(value = "/campaigns/questionnaire", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<ParticipantQuestionnaire> getParticipantQuestionnaireByParticipantAndQuestionnaireId(
			@RequestHeader HttpHeaders headers, @RequestParam(value = "participant_id") String participantId,
			@RequestParam(value = "questionnaire_id") String questionnaireIdStr,
			@RequestParam(value = "isEncoded", defaultValue = "false") boolean isEncoded) {
		participantId=CommonUtil.getURLDecodeString(participantId);
		String encryptedPatientId=participantId;	

		participantId = EncryptionUtils.getInstance().decryptFromBase64(participantId);		
		Long questionnaireId=(long) Integer.parseInt(EncryptionUtils.getInstance().decryptFromBase64(questionnaireIdStr));
		logger.info(">>>> getParticipantQuestionnaireByParticipantAndQuestionnaireId");
		ParticipantQuestionnaire existingOne = this.participantQuestionnaireService.getParticipantQuestionnaire(
				participantId, questionnaireId, isEncoded);

		if (null != existingOne.getParticipant()) {
			existingOne.withParticipant(existingOne.getParticipant().withParticipantId(encryptedPatientId).withAddress("")
					.withState("").withCity(""));
			existingOne
					.withParticipantId(encryptedPatientId);
			if (existingOne.getParticipantQuestions() != null) {
				existingOne.getParticipantQuestions().forEach(
						f -> f.withParticipantId(encryptedPatientId));
			}
		} else {
			logger.error(">>> New Participant Entry:[" + participantId + "]");
		}
		return new ResponseEntity<ParticipantQuestionnaire>(existingOne, HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/campaigns/questionnaire/{trialId}", method = RequestMethod.POST)
	//@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<ParticipantQuestionnaire> saveParticipantQuestionnaire(@RequestHeader HttpHeaders headers,
			@RequestBody ParticipantQuestionnaire participantQuestionnaire,
			@PathVariable("trialId") String trialId) {
		String encryptedPatientId = CommonUtil.getURLDecodeString(participantQuestionnaire.getParticipantId());
		String decryptedPatientId = EncryptionUtils.getInstance()
				.decryptFromBase64(participantQuestionnaire.getParticipantId());
		if (participantQuestionnaire != null) {
			participantQuestionnaire.withParticipantId(decryptedPatientId);
			if(null!=participantQuestionnaire.getParticipant())
			participantQuestionnaire
					.withParticipant(participantQuestionnaire.getParticipant().withParticipantId(decryptedPatientId));
			else
				participantQuestionnaire
				.withParticipant(new Participant()).withParticipantId(decryptedPatientId);
				
		}
		ParticipantQuestionnaire savedParticipantQuestionnaire = participantQuestionnaireService
				.saveParticipantQuestionnaire(trialId, participantQuestionnaire);
		if (savedParticipantQuestionnaire == null)
			return new ResponseEntity<ParticipantQuestionnaire>(HttpStatus.INTERNAL_SERVER_ERROR);

		logger.info("<<< Started Encryption" + savedParticipantQuestionnaire.getParticipantId());

		savedParticipantQuestionnaire.withParticipantId(encryptedPatientId);
		if (savedParticipantQuestionnaire.getParticipant() != null) {
			savedParticipantQuestionnaire.getParticipant().withParticipantId(encryptedPatientId).withAddress("")
					.withState("").withCity("");

		} else {
			logger.info(">>> Invalid Participant Entry(decrypted):[" + decryptedPatientId + "]");
			logger.info(">>> Invalid Participant Entry(encrypted):[" + encryptedPatientId + "]");
		}
		logger.info(">>> Completed Encryption" + savedParticipantQuestionnaire.getParticipantId());
		if (savedParticipantQuestionnaire.getParticipantQuestions() != null) {
			savedParticipantQuestionnaire.getParticipantQuestions()
					.forEach(f -> f.withParticipantId(encryptedPatientId));
		}
		return new ResponseEntity<ParticipantQuestionnaire>(savedParticipantQuestionnaire, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/campaigns/question", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<ParticipantQuestion> createQuestion(@RequestHeader HttpHeaders headers,
			@RequestBody ParticipantQuestion participantQuestion) {
		participantQuestion.withParticipantId(
				EncryptionUtils.getInstance().decryptFromBase64(participantQuestion.getParticipantId()));
		ParticipantQuestion existingOne = this.participantQuestionService.findByParticipantIdAndQuestionId(
				participantQuestion.getParticipantId(), participantQuestion.getQuestionId());
		if (existingOne != null) {
			existingOne.withAnswer(participantQuestion.getAnswer());
			existingOne.withParticipantId(participantQuestion.getParticipantId());
			participantQuestion = this.participantQuestionService.save(existingOne);
		} else {
			participantQuestion = this.participantQuestionService.save(participantQuestion);
		}
		if (participantQuestion == null)
			return new ResponseEntity<ParticipantQuestion>(HttpStatus.INTERNAL_SERVER_ERROR);

		participantQuestion.withParticipantId(
				EncryptionUtils.getInstance().encryptToBase64(participantQuestion.getParticipantId()));
		if (null != participantQuestion.getParticipantQuestionnaire()
				&& null != participantQuestion.getParticipantQuestionnaire().getParticipant()) {
			participantQuestion.getParticipantQuestionnaire().getParticipant().withAddress("").withState("")
					.withCity("");
		}

		return new ResponseEntity<ParticipantQuestion>(participantQuestion, HttpStatus.CREATED);
	}

	// We are passing the patientid as it as but Zyprr has encrypted patient id,
	// then how it will sync?
	@RequestMapping(value = "/campaigns/get/contact/update/questionnaire/status", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<String> updateCRMContactQuestionnaireStatus(@RequestHeader HttpHeaders headers,
			@RequestBody CRMContactUpdateRequest contactUpdateRequest) {
		String value = this.crmContactsService.updateCRMContactQuestionnaireStatus(
				EncryptionUtils.getInstance().decryptFromBase64(contactUpdateRequest.getPatientId()),
				contactUpdateRequest.getCustomFieldName(), contactUpdateRequest.getCustomFieldValue());
		// if (value.isEmpty() || value == null) {
		// return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		// }
		return new ResponseEntity<String>(value, HttpStatus.OK);
	}

	// This is for testing
	@RequestMapping(value = "/encrypt/patientid", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<List<String>> getEncryptedPatientId(@RequestHeader HttpHeaders headers,
			@RequestParam String PatientIds) {
		/*try {
			ESAPI.validator().getValidInput("CoordinatorPortal_getEncryptedPatientId", PatientIds, "ParticipantIds", 500, true);
		} catch (Exception e) {
			logger.error(
					"ParticipantId is not in expected format and contains blacklisted characters which are allowed for this field");
			return new ResponseEntity<List<String>>(new ArrayList<String>(), HttpStatus.BAD_REQUEST);
		}*/

		List<String> lstEncodedeIds = new ArrayList<String>();
		logger.info("Plain Text Before Encryption: " + PatientIds);

		EncryptionUtils utils = EncryptionUtils.getInstance();
		for (String patientId : PatientIds.split(",")) {
			String encoded = utils.encryptToBase64(patientId);
			logger.info("Encoded - " + encoded);

			String decryptedText = utils.decryptFromBase64(encoded);
			logger.info("Decrypted Text After Decryption: " + decryptedText);
			lstEncodedeIds.add(encoded);
		}

		return new ResponseEntity<List<String>>(lstEncodedeIds, HttpStatus.OK);
	}
	
	@ResponseBody
	@RequestMapping(value = "/patientConsent", method = RequestMethod.POST)
  //  @PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','POST')")
	public ResponseEntity<PatientConsent> saveParticipantQuestionnaire(@RequestHeader HttpHeaders headers,
			@RequestBody PatientConsent patientConsent) {
		
		logger.info("Inside save patient consent");

		PatientConsent patientConsentDetails = null;

		try {
			patientConsentDetails = patientConsentService.savePatientConsent(patientConsent);

			if (patientConsentDetails == null) {
				throw new RecordNotFoundException("Invalid Trail id is null : ");
			} else {
				patientConsentDetails.setEncryptedTempPatientId(
						EncryptionUtils.getInstance().encryptToBase64(patientConsentDetails.getTempPatientId()));
				return new ResponseEntity<PatientConsent>(patientConsentDetails, HttpStatus.CREATED);
			}
		} catch (HttpClientErrorException httpClientErrorException) {
			logger.error("Error occured while getting file from container:Filedoes not exist ",
					httpClientErrorException.getMessage());
			return new ResponseEntity<PatientConsent>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@ResponseBody
	@RequestMapping(path = "/getPatientConsentForm/{source}/{foldername}/{questionnaireId}", method = RequestMethod.GET  )
	@PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<PatientConsentResponse> getPatientConsentForm(@RequestHeader HttpHeaders headers,@PathVariable String source,@PathVariable String foldername,@PathVariable Long questionnaireId) {
	
	
	 String patientConsentForm=null;
	 
	 PatientConsentResponse patientConsentResponse =new PatientConsentResponse();
		try 
		{
		  patientConsentForm =  this.patientConsentService.getPatientConsentDetails(source,foldername,questionnaireId);
		  
		  if (patientConsentForm == null || patientConsentForm.isEmpty() )
		  {
				patientConsentResponse.setStatus(HttpStatus.NOT_FOUND.value());
				patientConsentResponse.setMessage("File does not exist");
			  
			  return new ResponseEntity<PatientConsentResponse>(patientConsentResponse,HttpStatus.BAD_REQUEST);
			  
		  }
		
		  else 
		  { 
			 
			  patientConsentResponse.setStatus(HttpStatus.OK.value());
			  patientConsentResponse.setMessage("File details read succesfully");
			  patientConsentResponse.setHtmlString(patientConsentForm);
			 
			return new ResponseEntity<PatientConsentResponse>(patientConsentResponse,HttpStatus.OK);
		 }	 
		}
		catch (HttpClientErrorException httpClientErrorException) 
		{
			logger.error("Error occured while getting file from container:Filedoes not exist ", httpClientErrorException.getMessage());
			patientConsentResponse.setStatus(HttpStatus.BAD_REQUEST.value());
			patientConsentResponse.setMessage("Error occured file reading file"+httpClientErrorException.getMessage());
		
			return new ResponseEntity<PatientConsentResponse>(patientConsentResponse,HttpStatus.BAD_REQUEST);
		}
	}

   @ResponseBody
   @RequestMapping(path = "/validateAttribute", method = RequestMethod.GET)
   @Transactional 
//   @PreAuthorize("@securityUtil.hasPermission(#headers,'QUESTION','GET')")
	public ResponseEntity<PatientConsentResponse> validateQIdAndPID(@RequestHeader HttpHeaders headers, @RequestParam("qid") String qid,
			@RequestParam(required=false) String pid,@RequestParam("trialId") String trialId) throws Exception {
				
		logger.error("******  participant controller validateQIdAndPID with qid and PID " + qid );
		PatientConsentResponse validatePIDAndQid= new PatientConsentResponse();
		validatePIDAndQid.setMessage("Failed");
		validatePIDAndQid.setStatus(400);
		String participantId = null;
		
		if (!CommonUtil.isNullOrBlank(qid) ) {
			
			if(!CommonUtil.isNullOrBlank(pid) )
			 participantId = CommonUtil.getURLDecodeString(pid);
		     String questionnaireId = CommonUtil.getURLDecodeString(qid);
		    try {
		     if(!CommonUtil.isNullOrBlank(participantId))
				 participantId=EncryptionUtils.getInstance().decryptFromBase64WithException(participantId);
		   
		       trialId = EncryptionUtils.getInstance().decryptFromBase64WithException(CommonUtil.getURLDecodeString(trialId));
		    }catch(Exception e) {
		    	validatePIDAndQid.setStatus(200);
				validatePIDAndQid.setMessage("Invalid");
				return new ResponseEntity<PatientConsentResponse>(validatePIDAndQid, HttpStatus.OK);
		    }
				try {
					Query query = new Query();
					query.addCriteria(Criteria.where("pid").is(participantId).and("basicInfo").is("Y"));
					Update update = new Update();
					ParsedQualtricsReponse savedDocument = new ParsedQualtricsReponse();
					
					savedDocument = template.findOne(query, ParsedQualtricsReponse.class, "T_" + trialId);
					if (savedDocument!=null) {
						validatePIDAndQid.setStatus(200);
						validatePIDAndQid.setMessage("Already Qualified");
						return new ResponseEntity<PatientConsentResponse>(validatePIDAndQid, HttpStatus.OK);
					}else {
						logger.info("Participant not found");
					}
				} catch (Exception e) {
					
					logger.info("Exception while checking already qualified patient.");
				}
		   
			try {
				
				Participant participant = participantService.findOne(participantId);
				if(null!=participant) {
				
				String tableName="ParticipantStudySite_T_"+trialId;
				javax.persistence.Query q=entityManager.createNativeQuery("Select count(*) from "+tableName+ " where participantId= :1");
				q.setParameter(1, participantId);
		        q.getSingleResult();
		           
			
				validatePIDAndQid.setMessage("SUCCESS");
				validatePIDAndQid.setStatus(200);
				
				}
			} catch (Exception e) {
				logger.info("attributes used are not valid  participant id " + participantId  +"trial id= "+trialId);
				return new ResponseEntity<PatientConsentResponse>(validatePIDAndQid, HttpStatus.OK);
				
			}
		} else
			return new ResponseEntity<PatientConsentResponse>(validatePIDAndQid, HttpStatus.OK);
		
		return new ResponseEntity<PatientConsentResponse>(validatePIDAndQid, HttpStatus.OK);
	
	}
   
  
	@GetMapping(value = "/footerdetails")
	public ResponseEntity<ResponseObjectModel> downloadFooterContent() {
		logger.info("download footer content started");
		ResponseObjectModel responseObjectModel = null;
		try {
			responseObjectModel = patientConsentService.getFooterContent();
			if (responseObjectModel.getData() == null) {
				responseObjectModel.setMessage("No Footer Found");
				responseObjectModel.setStatus(404);
			}
			logger.info("download footer content completed");
			return new ResponseEntity<>(responseObjectModel, HttpStatus.OK);
		} catch (Exception exception) {
			logger.error("Error occured during download footer html {} ", exception);
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

}
