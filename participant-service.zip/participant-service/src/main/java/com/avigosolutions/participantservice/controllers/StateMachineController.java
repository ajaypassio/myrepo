package com.avigosolutions.participantservice.controllers;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.common.Constants;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.model.TrialStatusAudit;
import com.avigosolutions.participantservice.service.ParticipantStateService;
import com.avigosolutions.participantservice.service.ParticipantTrialService;

@Controller
@RequestMapping(path = "/statemachine")
public class StateMachineController {

	@Autowired
	ParticipantStateService participantStateService;

	@Autowired
	ParticipantTrialService participantTrialService;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@ResponseBody
	@RequestMapping(path = "/participantTrial/emailCampaign", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> emailCampaign(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerEmailCampaign(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/emailsCampaign", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<String> emailsCampaign(@RequestHeader HttpHeaders headers, @RequestBody String payload)
			throws Exception {
		logger.info("Starting StateMachineController.emailsCampaign() ==>");
		if (payload == null || payload.isEmpty()) {
			logger.error("emailsCampaign states can't be empty");
			new ResponseEntity<String>("FAILURE", HttpStatus.OK);
		}

		participantStateService.triggerEmailsCampaign(payload, headers);

		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/attemptQuestion", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> attemptQuestion(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerAttemptQuestion(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/selectedStudySite", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> selectedStudySite(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerSelectedStudySite(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/siteToContact", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> siteToContact(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerSiteToContact(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/scheduledVisit", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> scheduledVisit(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerScheduledVisit(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/visited", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> visited(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerVisited(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/patientRejectConsent", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> patientRejectConsent(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerPatientRejectConsent(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/patientAcceptConsent", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> patientAcceptConsent(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerPatientAcceptConsent(ptState,headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/patientRejected", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> patientRejected(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerPatientRejected(ptState,headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/patientFailed", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> patientFailed(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerPatientFailed(ptState,headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	/*
	 * Get all possible states for a given trial and participant
	 */
	@ResponseBody
	@RequestMapping(path = "/participantTrial/validStates", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Set<Integer>> validStates(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId) throws Exception {
		participantId = CommonUtil.getEncodedString(participantId);
		
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		Set<States> states = participantStateService.getValidStates(ptState);
		Set<Integer> intStates = null;
		if (states == null)
			return new ResponseEntity<Set<Integer>>(intStates, HttpStatus.NOT_FOUND);
		intStates = states.stream().map(x -> x.getCode()).collect(Collectors.toSet());
		return new ResponseEntity<Set<Integer>>(intStates, HttpStatus.OK);
	}


	/*
	 * Move to possible state of a participant and return value for Admin & coordinator
	 */
	@ResponseBody
	@RequestMapping(path = "/participantTrial/moveStatus", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Set<Integer>> moveStatus(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes,
			@RequestParam(value = Constants.NOTES, required = false) String notes,
			@RequestParam(value = Constants.TO_STATUS, required = true) int toStatus) throws Exception {
		
		//participantId = CommonUtil.getEncodedString(participantId);
		//notes = CommonUtil.getEncodedString(notes);
		//statusNotes = CommonUtil.getEncodedString(statusNotes)

		/*try {
			ESAPI.validator().getValidInput("Portal_moveStatus", notes, "Notes", 2000, true);
		} catch (Exception e) {
			logger.error(
					"Notes is not in expected format and contains blacklisted characters which are allowed for this field");
			return new ResponseEntity<Set<Integer>>(new HashSet<Integer>(), HttpStatus.BAD_REQUEST);
		}*/
		
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setTargetStateCode(toStatus);
		ptState.setStatusNotes(statusNotes);
		ptState.setNotes(notes);
		participantStateService.moveToStatus(ptState, headers);
		Set<Integer> intStates = new HashSet<Integer>();
		intStates.add(toStatus);
		return new ResponseEntity<Set<Integer>>(intStates, HttpStatus.OK);
	}

	/*
	 * Pen Test defect fix change moveStatus method from GET to POST DE6671
	 */
	@ResponseBody
	@RequestMapping(path = "/participantTrial/moveStatus", method = RequestMethod.POST)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<Set<Integer>> moveStatus(@RequestHeader HttpHeaders headers,
			@RequestBody ParticipantTrialState ptState) throws Exception {
		logger.info("Starting StateMachineController.moveStatus() ==>");
		participantStateService.moveToStatusNew(ptState, headers);
		Set<Integer> intStates = new HashSet<Integer>();
		intStates.add(ptState.getTargetStateCode());
		return new ResponseEntity<Set<Integer>>(intStates, HttpStatus.OK);
	}
	
	/*
	 * Move to possible state of a participant
	 */

	@ResponseBody
	@RequestMapping(path = "/participantTrial/moveToStatus", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> movedToStatus(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes,
			@RequestParam(value = Constants.NOTES, required = false) String notes,
			@RequestParam(value = Constants.TO_STATUS, required = true) int toStatus) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setTargetStateCode(toStatus);
		ptState.setStatusNotes(statusNotes);
		ptState.setNotes(notes);
		States state = participantStateService.moveToStatus(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/movedToEnrolled", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> movedToEnrolled(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerMovedToEnrolled(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/participantTrial/trialCompleted", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> trialCompleted(@RequestHeader HttpHeaders headers,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId,
			@RequestParam(value = Constants.STATUS_NOTES, required = false) String statusNotes) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		ptState.setStatusNotes(statusNotes);
		States state = participantStateService.triggerTrialCompleted(ptState, headers);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/trialStateAudit/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<TrialStatusAudit>> trialStateAudit(@RequestHeader HttpHeaders headers,
			@PathVariable(Constants.TRIAL_ID) Long trialId) throws Exception {
		List<TrialStatusAudit> audits = participantTrialService.findTrialStatusAudit(trialId);
		return new ResponseEntity<List<TrialStatusAudit>>(audits, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(path = "/trialStateAudit/all/{trialId}", method = RequestMethod.GET)
	@PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<List<TrialStatusAudit>> trialStateAuditByTrialIds(@RequestHeader HttpHeaders headers,
			@PathVariable(Constants.TRIAL_ID) List<Long> trialId) throws Exception {
		List<TrialStatusAudit> audits = participantTrialService.findTrialStatusAuditByTrialIdIn(trialId);
		if (audits == null)
			return new ResponseEntity<List<TrialStatusAudit>>(audits, HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<TrialStatusAudit>>(audits, HttpStatus.OK);

	}

	/*
	 * We will be exposing dynamic end points could be based on configuration
	 */
	// @ResponseBody
	// @RequestMapping(path = "/states/{triggerName}", method = RequestMethod.GET)
	// @PreAuthorize("@securityUtil.hasPermission(#headers,'TRIAL','GET')")
	public ResponseEntity<States> dynamicInvoke(@RequestHeader HttpHeaders headers,
			@PathVariable("triggerName") String methodName,
			@RequestParam(value = Constants.PARTICIPANT_ID, required = true) String participantId,
			@RequestParam(value = Constants.TRIAL_ID, required = true) Long trialId) throws Exception {
		ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);
		States state = invokeMethod(methodName, ptState);
		if (state == null)
			return new ResponseEntity<States>(state, HttpStatus.NOT_FOUND);
		return new ResponseEntity<States>(state, HttpStatus.OK);
	}

	private States invokeMethod(String methodName, ParticipantTrialState ptState) {
		States state = null;
		try {
			Method method = participantStateService.getClass().getMethod(methodName, ParticipantTrialState.class);
			if (method != null) {
				state = (States) method.invoke(participantStateService, ptState);
			} else {
				logger.error("No suitable method to execute- {}", methodName);
			}
		} catch (Exception e) {
			logger.error("Error in method invocation", e);
		}
		return state;
	}
}
