package com.avigosolutions.participantservice.crm;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import com.avigosolutions.participantservice.ParticipantServiceAppContext;
import com.avigosolutions.participantservice.async.service.ParticipantAsyncService;
import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.crm.async.service.CRMContactJobService;
import com.avigosolutions.participantservice.crm.constants.CRMContactConstants;
import com.avigosolutions.participantservice.crm.service.CRMCategoryService;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.ParticipantJob;
import com.avigosolutions.participantservice.repository.ParticipantJobRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CRMCategoryTask implements CRMTask {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private CRMCategory category = null;

	private String option = null;
	
	private String correlationId;

	@Autowired
	CRMContactJobService cRMContactJobService;
	
	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	CRMContactsTask contactTask;
	
	@Autowired
	ParticipantAsyncService participantAsyncService;

	public CRMCategory getCategory() {
		return category;
	}

	public CRMCategoryTask withCategory(CRMCategory category) {
		this.category = category;
		return this;
	}

	public String getOption() {
		return option;
	}

	public CRMCategoryTask withOption(String option) {
		this.option = option;
		return this;
	}
	
	public String getCorrelationId() {
		return correlationId;
	}
	
	public CRMCategoryTask withCorrelationId(String correlationId) {
		this.correlationId = correlationId;
		return this;
	}

	@Override
	public void run() {
		logger.info("CRMCategoryTask started running");
		CRMCategoryService service = ParticipantServiceAppContext.getBean(CRMCategoryService.class);
		
		if (option == null || option.equalsIgnoreCase("add")) {			
				service.createCategory(category);				
		} else if (option.equalsIgnoreCase("update")) {
			
				service.updateCategory(category);
				
		}
		if (category.getLookupCode() == null) {
			logger.error("Exception in creating CRM category for TRIALID - {}", category.getTrialId());
			
			try {
				cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(category).withJobStatus(CRMContactConstants.BatchStatus.FAILED.name()));
			} catch (JsonProcessingException e1) {
				logger.info("Exception in parsing contact json");
				logger.error("Exception in parsing contact json", e1);
			}
			return;
		}
		participantAsyncService.addParticipantJobLogForCRMCategory(category,correlationId);
		category.getCrmContacts().forEach(contact -> contact.withCrmCategory(category));
		CRMTaskExecutorService taskService = ParticipantServiceAppContext.getBean(CRMTaskExecutorService.class);
		
		contactTask.withCategory(category).withContacts(category.getCrmContacts());
		taskService.execute(contactTask.withCorrelationId(correlationId));
	}

}
