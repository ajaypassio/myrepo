package com.avigosolutions.participantservice.crm;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import com.avigosolutions.participantservice.ParticipantServiceAppContext;
import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.crm.async.service.CRMContactJobService;
import com.avigosolutions.participantservice.crm.constants.CRMContactConstants;
import com.avigosolutions.participantservice.crm.service.CRMContactsService;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.CRMContact;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CRMContactsTask implements CRMTask {

	private CRMCategory category = null;

	private List<CRMContact> contacts = new ArrayList<>();
	
	private String correlationId;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	RetryTemplate retrySendContactsTemplate;
	
	@Autowired
	CRMContactJobService cRMContactJobService;

	public CRMCategory getCategory() {
		return category;
	}
	
	public String getCorrelationId() {
		return correlationId;
	}
	
	public CRMContactsTask withCorrelationId(String correlationId) {
		this.correlationId = correlationId;
		return this;
	}

	public CRMContactsTask withCategory(CRMCategory category) {
		this.category = category;
		return this;
	}

	public List<CRMContact> getContacts() {
		return contacts;
	}

	public CRMContactsTask withContacts(List<CRMContact> contacts) {
		this.contacts = contacts;
		return this;
	}

	@Override
	public void run() {
		logger.info("CRMContactsTask started running");
		CRMContactsService service = ParticipantServiceAppContext.getBean(CRMContactsService.class);
		retrySendContactsTemplate.execute(context -> {
			context.setAttribute("crmContacts", contacts);
			service.createContacts(contacts,correlationId);
			return true;
		}, recover -> {
			cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(category).withJobStatus(CRMContactConstants.BatchStatus.FAILED.name()));
			return false;
		});

	}
}
