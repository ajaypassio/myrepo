package com.avigosolutions.participantservice.crm;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.avigosolutions.participantservice.ParticipantServiceAppContext;
import com.avigosolutions.participantservice.crm.service.CRMCategoryService;

public class CRMSubstitutesTask implements CRMTask {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private Map<String, String> substitutes = null;


	public Map<String, String> getSubstitutes() {
		return substitutes;
	}

	public CRMSubstitutesTask withSubstitutes(Map<String, String> subs) {
		this.substitutes = subs;
		return this;
	}

	@Override
	public void run() {
		logger.info("CRMSubstitutesTask started running");
		CRMCategoryService service = ParticipantServiceAppContext.getBean(CRMCategoryService.class);
		service.addSubstitution(substitutes);
	}
}
