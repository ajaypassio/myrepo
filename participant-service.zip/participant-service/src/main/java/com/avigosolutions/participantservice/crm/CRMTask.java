package com.avigosolutions.participantservice.crm;

public interface CRMTask extends Runnable {

}
