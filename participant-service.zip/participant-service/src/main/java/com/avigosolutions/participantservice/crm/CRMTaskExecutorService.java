package com.avigosolutions.participantservice.crm;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CRMTaskExecutorService {
	
	@Value("${sprintt.crm.async.processing.threadpool.size.initial}")
	private Integer corePoolSize;

	@Value("${sprintt.crm.async.processing.threadpool.size.max}")
	private Integer maxPoolSize;

	@Value("${sprintt.crm.async.processing.thread.prefix}")
	private String theadPrefixName;

	@Value("${sprintt.crm.async.processing.thread.keepalive.seconds}")
	private Integer keepAliveSeconds;
	
	@Value("${sprintt.crm.async.processing.thread.queue.capacity}")
	private Integer queueCapacity;
	
	
	private BlockingQueue<Runnable> workQueue ;//= new ArrayBlockingQueue<>(queueCapacity);
	
	private ThreadPoolExecutor executor ;//= new ThreadPoolExecutor(corePoolSize,maxPoolSize,keepAliveSeconds, TimeUnit.SECONDS, workQueue);
	
	@PostConstruct
	public void init() {
		workQueue = new ArrayBlockingQueue<>(queueCapacity);
		executor = new ThreadPoolExecutor(corePoolSize,maxPoolSize,keepAliveSeconds, TimeUnit.SECONDS, workQueue);
	}
	
	public void execute(CRMTask task) {
		if(executor.isShutdown() || executor.isTerminated()) {
			executor = new ThreadPoolExecutor(corePoolSize,maxPoolSize,keepAliveSeconds, TimeUnit.SECONDS, workQueue);
		}
		executor.execute(task);
	}
	
	@PreDestroy
	public void dispose() {
		executor.shutdown();
	}

}
