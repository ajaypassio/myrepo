package com.avigosolutions.participantservice.crm.async.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.avigosolutions.participantservice.audit.Auditable;
import com.avigosolutions.participantservice.audit.EntityListener;
import com.avigosolutions.participantservice.model.ParticipantQuestion;

@Entity
@Table(name = "CRMContactJob")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class CRMContactJob extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 2L;

	@Id
	@GeneratedValue
	@Column(name = "CRMContactJobId", nullable = false)
	private long cRMContactJobId;

	@Column(name = "TrialId")
	private long trialId;

	@Column(name = "SearchName", columnDefinition = "nvarchar")
	private String searchName;

	@Column(name = "ContactJson", columnDefinition = "nvarchar")
	private String contactJson;
	
	@Column(name = "JobStatus", columnDefinition = "nvarchar")
	private String jobStatus;
	
	@Column(name = "LastBatchId")
	private Long lastBatchId;
	
	@Column(name = "LastPartcipantId", columnDefinition = "nvarchar")
	private String lastPartcipantId;	
	
	@Column(name="InProcess")
	private boolean inProcess;
	
	@Column(name="BatchId")
	private int batchId;
	
	@Column(name="BatchSize")
	private int batchSize;
	
	@Column(name="TrialName",columnDefinition="nvarchar")
	private String trialName;

	@Column(name="FailedAttempt")
	private int failedAttempt;
	
	
	public boolean isInProcess() {
		return inProcess;
	}


	public void setInProcess(boolean inProcess) {
		this.inProcess = inProcess;
	}
	
	public CRMContactJob withInProcess(boolean inProcess) {
		this.inProcess = inProcess;
		return this;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public Long getLastBatchId() {
		return lastBatchId;
	}

	public CRMContactJob withJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
		return this;
	}

	public CRMContactJob withLastBatchId(Long lastBatchId) {
		this.lastBatchId = lastBatchId;
		return this;
	}

	public String getContactJson() {
		return contactJson;
	}

	public CRMContactJob withContactJson(String contactJson) {
		this.contactJson = contactJson;
		return this;

	}

	public long getTrialId() {
		return trialId;
	}

	public CRMContactJob withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public long getCRMContactJobId() {
		return this.cRMContactJobId;
	}

	public CRMContactJob withCRMContactJobId(long id) {
		this.cRMContactJobId = id;
		return this;
	}

	public String getSearchName() {
		return searchName;
	}

	public CRMContactJob withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public String getLastPartcipantId() {
		return lastPartcipantId;
	}

	public CRMContactJob withLastPartcipantId(String lastPartcipantId) {
		this.lastPartcipantId = lastPartcipantId;
		return this;
	}

	public int getBatchId() {
		return batchId;
	}

	public CRMContactJob setBatchId(int batchId) {
		this.batchId = batchId;
		return this;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public CRMContactJob withBatchSize(int batchSize) {
		this.batchSize = batchSize;
		return this;
	}

	public String getTrialName() {
		return trialName;
	}

	public CRMContactJob withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}

	public int getFailedAttempt() {
		return failedAttempt;
	}

	public CRMContactJob withFailedAttempt(int failedAttempt) {
		this.failedAttempt = failedAttempt;
		return this;
	}


	@Override
	public String toString() {
		return "CRMContactJob [cRMContactJobId=" + cRMContactJobId + ", trialId=" + trialId + ", searchName="
				+ searchName + ", jobStatus=" + jobStatus + ", lastBatchId="
				+ lastBatchId + ", lastPartcipantId=" + lastPartcipantId + ", inProcess=" + inProcess + ", batchId="
				+ batchId + ", batchSize=" + batchSize + ", trialName=" + trialName + ", failedAttempt=" + failedAttempt
				+ "]";
	}	
	
}
