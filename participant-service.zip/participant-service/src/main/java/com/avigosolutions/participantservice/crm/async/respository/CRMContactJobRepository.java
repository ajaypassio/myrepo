package com.avigosolutions.participantservice.crm.async.respository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;

@Repository
public interface CRMContactJobRepository
		extends JpaRepository<CRMContactJob, Long>, JpaSpecificationExecutor<CRMContactJob> {
	public CRMContactJob findBySearchNameAndTrialIdAndBatchId(String searchName, long trialId,int BatchId);
	public List<CRMContactJob> findByInProcessFalseAndJobStatusNotLike(String terminalStatus);
	public Long countBySearchNameAndTrialId(String searchName,long trialId);
	public List<CRMContactJob> findBySearchNameAndTrialId(String searchName,long trialId);
}
