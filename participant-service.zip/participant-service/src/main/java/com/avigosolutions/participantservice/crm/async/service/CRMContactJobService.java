package com.avigosolutions.participantservice.crm.async.service;

import java.util.List;

import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;

import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.CRMContact;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface CRMContactJobService {
	public CRMContactJob addJobLog(CRMContactJob crmContactJob);
	public CRMContactJob getCrmContactJob(CRMCategory category) throws JsonProcessingException;
	public CRMContactJob getCrmContactJob(List<CRMContact> contacts) throws JsonProcessingException;
	public List<CRMContactJob> getJobsNotInProcessingAndNotInCompleted();
	public List<CRMContactJob> getBySearchNameAndTrialId(String searchName,long trialId);
}
