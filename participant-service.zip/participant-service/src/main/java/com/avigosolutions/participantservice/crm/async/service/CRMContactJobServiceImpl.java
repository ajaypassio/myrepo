package com.avigosolutions.participantservice.crm.async.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.crm.async.respository.CRMContactJobRepository;
import com.avigosolutions.participantservice.crm.constants.CRMContactConstants;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.CRMContact;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CRMContactJobServiceImpl implements CRMContactJobService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	CRMContactJobRepository cRMContactJobRepository;

	@Override
	public CRMContactJob addJobLog(CRMContactJob crmContactJob) {
		if (crmContactJob.getBatchId() <= 0) {

			long count = cRMContactJobRepository.countBySearchNameAndTrialId(crmContactJob.getSearchName(),
					crmContactJob.getTrialId());
			crmContactJob.setBatchId(Integer.parseInt(String.valueOf(count + 1)));
		}
		CRMContactJob existingJob = cRMContactJobRepository.findBySearchNameAndTrialIdAndBatchId(
				crmContactJob.getSearchName(), crmContactJob.getTrialId(), crmContactJob.getBatchId());
		logger.info("Current Job Entry==>" + crmContactJob.toString());
		if (existingJob != null) {
			logger.info("Existing Job Entry==>" + existingJob.toString());
			crmContactJob.withCRMContactJobId(existingJob.getCRMContactJobId());
			if (null == crmContactJob.getJobStatus() || crmContactJob.getJobStatus().trim().isEmpty()) {
				crmContactJob.withJobStatus(existingJob.getJobStatus());
			}

			/*if ((null == crmContactJob || null == crmContactJob.getBatches() || crmContactJob.getBatches().isEmpty())
					&& null != existingJob && null != existingJob.getBatches()) {
				crmContactJob.withBatches(existingJob.getBatches());
			}*/
			if(crmContactJob.getJobStatus().equals(CRMContactConstants.BatchStatus.FAILED.name())) {
				crmContactJob.withFailedAttempt(existingJob.getFailedAttempt()+1);
			}
		}
		logger.info("Before Job Entry==>" + crmContactJob.toString());
		return cRMContactJobRepository.save(crmContactJob);
	}

	@Override
	public CRMContactJob getCrmContactJob(CRMCategory category) throws JsonProcessingException {
		String lastParticipantId="";
		if(category.getCrmContacts().size()>0) {
			lastParticipantId=category.getCrmContacts().get(category.getCrmContacts().size()-1).getParticipantId();
		}
		return new CRMContactJob().withContactJson(new ObjectMapper().writeValueAsString(category.getCrmContacts()))
				.withLastPartcipantId(lastParticipantId)
				.withSearchName(category.getSearchName())
				.withTrialId(category.getTrialId()).withTrialName(category.getTrialName())
				.withBatchSize(category.getCrmContacts().size());
	}

	@Override
	public CRMContactJob getCrmContactJob(List<CRMContact> contacts) throws JsonProcessingException {
		if (null != contacts && contacts.size() > 0) {
			String lastParticipantId="";
			if(contacts.size()>0) {
				lastParticipantId=contacts.get(contacts.size()-1).getParticipantId();
			}
			CRMCategory category = contacts.get(0).getCrmCategory();
			return new CRMContactJob().withContactJson(new ObjectMapper().writeValueAsString(category.getCrmContacts()))
					.withLastPartcipantId(lastParticipantId)
					.withSearchName(category.getSearchName())
					.withTrialId(category.getTrialId()).withBatchSize(contacts.size())
					.withTrialName(category.getTrialName());
		}
		return null;
	}

	@Override
	public List<CRMContactJob> getJobsNotInProcessingAndNotInCompleted() {
		return cRMContactJobRepository
				.findByInProcessFalseAndJobStatusNotLike(CRMContactConstants.BatchStatus.COMPLETED.name());
	}
	
	@Override
	public List<CRMContactJob> getBySearchNameAndTrialId(String searchName,long trialId){
		return cRMContactJobRepository.findBySearchNameAndTrialId(searchName, trialId);
	}
	
}
