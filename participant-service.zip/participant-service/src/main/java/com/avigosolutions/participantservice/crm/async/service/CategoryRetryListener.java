package com.avigosolutions.participantservice.crm.async.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.listener.RetryListenerSupport;
import org.springframework.stereotype.Component;

import com.avigosolutions.participantservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@Component
public class CategoryRetryListener extends RetryListenerSupport {

	@Autowired
	CRMContactJobService cRMContactJobService;

	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public <T, E extends Throwable> void close(RetryContext context, RetryCallback<T, E> callback,
			Throwable throwable) {
		logger.info("==>Retry activity is completed.");
		super.close(context, callback, throwable);
	}

	@Override
	public <T, E extends Throwable> void onError(RetryContext context, RetryCallback<T, E> callback,
			Throwable throwable) {
		logger.info("Retry attempt:" + context.getRetryCount() + " failed due to " + throwable.getMessage());
		CRMCategory crmCategory = (CRMCategory) context.getAttribute("crmCategory");
		//String userId = (String) context.getAttribute("userId");
		if(asyncConfigLoaderBean.getCategoryRetryAttempts() > context.getRetryCount()) {
			try {
				cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(crmCategory));
						
			} catch (JsonProcessingException e) {
				logger.info("==> Error convert contacts json");
				logger.error("==> Error convert contacts json",e);
			}
		}
		
		super.onError(context, callback, throwable);
	}

	@Override
	public <T, E extends Throwable> boolean open(RetryContext context, RetryCallback<T, E> callback) {
		logger.info("==>Retry activity is initiated.");
		return super.open(context, callback);
	}
}