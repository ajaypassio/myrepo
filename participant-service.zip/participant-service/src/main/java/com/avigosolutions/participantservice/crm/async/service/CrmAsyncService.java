package com.avigosolutions.participantservice.crm.async.service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.model.CRMContact;

public interface CrmAsyncService{
	
    public Future<Boolean> processContacts(List<CRMContact> contacts,CRMContactJob cJob, String correlationId,Integer batchId) throws InterruptedException;

	public Future<Void>  batchProcessCRMContacts();
	
	public void batchProcess();
	
	public void updateBatchStatusMap(String correlationId, Integer batchId,Integer jobStatus);
	
	public void checkAndUpdateContactPushStatus(String correlationId, boolean finalUpdate);
	
	public Map<String, String> getBatchStatusMap(String correlationId);
    
}