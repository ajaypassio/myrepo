package com.avigosolutions.participantservice.crm.async.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.participantservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.participantservice.async.service.ParticipantAsyncService;
import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;

import com.avigosolutions.participantservice.crm.async.respository.CRMContactJobRepository;
import com.avigosolutions.participantservice.crm.constants.CRMContactConstants;
import com.avigosolutions.participantservice.crm.service.CRMAuthService;
import com.avigosolutions.participantservice.crm.service.CRMCategoryService;
import com.avigosolutions.participantservice.crm.service.CRMCustomFieldService;
import com.avigosolutions.participantservice.crm.service.CRMTasksService;
import com.avigosolutions.participantservice.dto.CRMAuth;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.CRMContact;
import com.avigosolutions.participantservice.model.CRMCustomField;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantJob;
import com.avigosolutions.participantservice.repository.ParticipantJobRepository;
import com.avigosolutions.participantservice.service.ParticipantService;
import com.avigosolutions.participantservice.utils.CommonUtils;
import com.avigosolutions.participantservice.utils.EncryptionUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Service
public class CrmAsyncServiceImpl implements CrmAsyncService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${zyprr.baseurl}")
	private String BASE_URL;

	@Value("${zyprr.contacts.add}")
	private String CREATE_CONTACTS_URL;

	@Value("${zyprr.contacts.update}")
	private String UPDATE_CONTACT_URL;

	@Value("${zyppr.auth.consumer_key}")
	private String AUTH_CONSUMER_KEY;

	@Autowired
	CRMAuthService crmAuthService;

	@Autowired
	CRMCustomFieldService crmCustomFieldService;

	@Autowired
	ParticipantAsyncService participantAsyncService;

	@Autowired
	CRMContactJobService cRMContactJobService;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ParticipantJobRepository participantJobRepository;

	@Autowired
	CRMCategoryService cRMCategoryService;

	@Autowired
	CRMTasksService crmTasksService;

	@Autowired
	ParticipantService participantService;

	Integer CALL_NONE = 0;
	Integer CALL_PART_SAVE = 1;
	Integer CALL_CRM_CATEGORY_CREATE = 2;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	private String createContactsURL;
	private String updateContactsURL;
	private String authHeader;

	private final String PATIENT_ID = "PatientID";
	private final String AGE = "Age (years)";
	private final String TRAIL_ID = "TrialID";
	private final String GENDER = "Gender";
	private final String ENCODED_PATIENTID = "EncodedPatientID";

	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;

	@PostConstruct
	private void init() {
		createContactsURL = BASE_URL + CREATE_CONTACTS_URL;
		updateContactsURL = BASE_URL + UPDATE_CONTACT_URL;
		authHeader = "consumer_key=" + AUTH_CONSUMER_KEY;
	}

	@Async("crmThreadPoolTaskExecutor")
	public Future<Boolean> processContacts(List<CRMContact> contacts, CRMContactJob cJob, String correlationId,
			Integer batchId) throws InterruptedException {
		logger.info("###Start Processing " + contacts.size() + " contacts with Thread id: "
				+ Thread.currentThread().getId());

		logger.info("CorrelationId:" + correlationId + " BatchId:" + batchId);
		String postContactsURL = createContactsURL;
		JSONArray jcontacts = contactsJSON(contacts);
		if (jcontacts == null) {
			return new AsyncResult<>(false);
		}
		logger.info("contacts json to be added -- Thread id: " + Thread.currentThread().getId() + "==>");
		HttpEntity<String> httpEntity = crmAuthService.getHttpEntity(jcontacts.toString());
		try {
			logger.info("Calling Zyprr URL==>" + postContactsURL);
			String response = restTemplate.postForObject(postContactsURL, httpEntity, String.class);
			// Retry in case of invalid/expired token
			if (response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid==>" + response);
				logger.info("Token expired or invalid");
				crmAuthService.authenticate();
				response = restTemplate.postForObject(postContactsURL, httpEntity, String.class);
			}
			logger.info("Response from Zyprr -- Thread id: " + Thread.currentThread().getId() + "==>");
			if (!parseJSON(response)) {
				updateBatchStatusMap(correlationId, batchId, 0);
				// participantAsyncService.updateParticipantJobLog(correlationId, 0);
				cRMContactJobService.addJobLog(cJob.withInProcess(CRMContactConstants.BATCH_IN_PROCESS_FALSE)
						.withJobStatus(CRMContactConstants.BatchStatus.FAILED.name())
						.withContactJson(jcontacts.toString()));

			} else {
				updateBatchStatusMap(correlationId, batchId, 1);
				cRMContactJobService.addJobLog(cJob.withInProcess(CRMContactConstants.BATCH_IN_PROCESS_FALSE)
						.withJobStatus(CRMContactConstants.BatchStatus.COMPLETED.name())
						.withContactJson(jcontacts.toString()));

			}
		} catch (Exception e) {
			try {
				cRMContactJobService.addJobLog(cJob.withInProcess(CRMContactConstants.BATCH_IN_PROCESS_FALSE)
						.withJobStatus(CRMContactConstants.BatchStatus.FAILED.name())
						.withContactJson(jcontacts.toString()));
				updateBatchStatusMap(correlationId, batchId, 0);
			} catch (Exception e1) {
				logger.info("Exception in parsing contact json");
				logger.error("Exception in parsing contact json", e1);
			}
			logger.info("Exception in calling Zyppr add contact");
			logger.error("Exception in calling Zyppr add contact", e);
			return new AsyncResult<>(false);
		}
		checkAndUpdateContactPushStatus(correlationId, true);
		return new AsyncResult<>(true);
	}

	private boolean parseJSON(String response) {
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		try {
		String responseCode = context.read("$.responseCode", String.class);
		String errorMessage = null;
		if (responseCode.equals("200")) {
			logger.info("Zyppr parse category - Successful");
			return true;

		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr Authentication - FAILED - {}, {}", responseCode, errorMessage);
			return false;
		}
		}catch(Exception e) {
			logger.error("Error occurred during parsing zyprr API response:"+response);
			logger.error("Exception:",e);
		}
		return false;
	}

	private JSONArray contactsJSON(List<CRMContact> contactList) {
		JSONArray jcontacts = new JSONArray();
		try {
			for (CRMContact contact : contactList) {
				JSONObject jcontact = contactJSON(contact);
				jcontacts.put(jcontact);
			}
		} catch (Exception e) {
			logger.error("Error creating contacts json", e);
			return null;
		}
		return jcontacts;
	}

	private JSONObject contactJSON(CRMContact contact) throws Exception {
		JSONObject jcontact = new JSONObject();
		try {
			// Add basics fields
			jcontact.put("extId", contact.getParticipantId());
			jcontact.put("restricted", false);
			jcontact.put("emailWork1", contact.getEmail());
			jcontact.put("firstName", contact.getFirstName());
			jcontact.put("lastName", contact.getLastName());
			jcontact.put("phoneOffice", contact.getPhoneNumber());
			jcontact.put("primaryAddressOne", contact.getPrimaryAddressOne());
			jcontact.put("primaryAddressCity", contact.getCity());
			jcontact.put("primaryAddressState", contact.getState());
			jcontact.put("primaryAddressPostalCode", contact.getZipCode());
			// Add categories
			JSONArray jcategories = new JSONArray();
			jcategories.put(contact.getCrmCategory().getLookupCode());
			jcontact.put("conType", jcategories);
			// Add custom fields
			JSONArray jcustProps = new JSONArray();
			if( null != contact.getGender() ) {
				jcustProps.put(getCustomPropertyJSON(GENDER, contact.getGender()));
			}
			jcustProps.put(getCustomPropertyJSON(AGE, contact.getAge() + ""));
			jcustProps.put(getCustomPropertyJSON(TRAIL_ID, contact.getCrmCategory().getTrialId() + ""));
			if( null != contact.getParticipantId() ) {
				jcustProps.put(getCustomPropertyJSON(ENCODED_PATIENTID,
						EncryptionUtils.getInstance().encryptToBase64(contact.getParticipantId())));
			}
			
			jcontact.put("customProperties", jcustProps);
		} catch (Exception e) {
			logger.error("Error creating contact json", e);
			throw e;
		}
		return jcontact;
	}

	private JSONObject getCustomPropertyJSON(String property, String value) throws JSONException {
		JSONObject jcustProp = new JSONObject();
		jcustProp.put("value", value);
		JSONObject jmetaID = new JSONObject();
		CRMCustomField field = crmCustomFieldService.getCustomFieldByName(property);
		if (field == null) {
			return null;
		}
		jmetaID.put("id", field.getUuid());
		jmetaID.put("dataType", field.getDataType());
		jcustProp.put("meta", jmetaID);
		return jcustProp;
	}

	@Async("batchThreadPoolTaskExecutor")
	public Future<Void> batchProcessCRMContacts() {
		logger.info(">>>Initializing Batch Processing with Thread   " + Thread.currentThread().getId());
		TimerTask batchTask = new TimerTask() {
			public void run() {
				logger.info(">>> Starting the batch processing with Thread " + Thread.currentThread().getId());
				batchProcess();
			}
		};
		Timer timer = new Timer("BatchTimer");
		long delay = new Random().nextInt(asyncConfigLoaderBean.getBatchRandomDelay());
		timer.schedule(batchTask, delay);
		return new AsyncResult<Void>(null);

	}

	@Override
	public void batchProcess() {
		doJobCheck();
		/*List<CRMContactJob> contactJobList = this.cRMContactJobService.getJobsNotInProcessingAndNotInCompleted();
		logger.info("Started Batch count=[" + contactJobList.size() + "]");
		if (null != contactJobList && contactJobList.size() > 0) {
			contactJobList.forEach(contactJob -> {
				logger.info("<<<< Started BATCH PROCESSING: " + contactJob.toString());
				try {
					CRMContactJob cJob = this.cRMContactJobService
							.addJobLog(contactJob.withInProcess(CRMContactConstants.BATCH_IN_PROCESS_TRUE));
					TypeReference<List<CRMContact>> mapType = new TypeReference<List<CRMContact>>() {
					};
					CRMCategory crmCategory = new CRMCategory();
					crmCategory.withTrialId(contactJob.getTrialId()).withSearchName(contactJob.getSearchName())
							.withTrialName(contactJob.getTrialName());

					cRMCategoryService.createCategory(crmCategory);

					if (crmCategory.getLookupCode() == null) {
						logger.error("Exception in creating CRM category for TRIALID - {}", crmCategory.getTrialId());

						cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(crmCategory)
								.withJobStatus(CRMContactConstants.BatchStatus.FAILED.name()));

					} else {

						List<CRMContact> lstContacts = new ObjectMapper().readValue(contactJob.getContactJson(),
								mapType);
						lstContacts.forEach(contact -> {
							if (contact.getCrmCategory() == null)
								contact.withCrmCategory(crmCategory);
						});
						if (null != lstContacts && lstContacts.size() > 0)
							processContacts(lstContacts, cJob, null, null);
						else {
							this.cRMContactJobService
									.addJobLog(contactJob.withInProcess(CRMContactConstants.BATCH_IN_PROCESS_FALSE)
											.withJobStatus(CRMContactConstants.BatchStatus.COMPLETED.name()));
						}
					}
					logger.info(
							"<<< Completed Async Batch Processing with Thread id: " + Thread.currentThread().getId());

				} catch (Exception e) {
					this.cRMContactJobService
							.addJobLog(contactJob.withInProcess(CRMContactConstants.BATCH_IN_PROCESS_FALSE));
					logger.error("Error occurred while executing the async batch task", e);
				}
			});
		}*/
	}

	private void doJobCheck() {
		try {
			resetIdleJobs();
			List<ParticipantJob> jobList = participantJobRepository
					.findBySavedSearchNameNotLikeAndIsContactsPushedAndIsDisabled("INP_%", 0, 0);
			if (null != jobList && jobList.size() > 0) {
				jobList.forEach(job -> {
					logger.info(">>>Processing ParticipantJob for SavedSearch:" + job.getSavedSearchName()
							+ " and TrialId:" + job.getTrialId());
					if ((job.getIsSaved().equals(1) && !job.getIsContactsPushed().equals(1)) || ( null != job.getBatchStatus() && job.getBatchStatus().trim().length() > 2)) {
						logger.debug(">>>SavedSearch:" + job.getSavedSearchName() + " and TrialId:" + job.getTrialId()
								+ " is already saved in DB. SO checking for Category creation");
						incrementAttempt(job);
						crmTasksService.createCRMTasks(convertJSONtoList(job.getParticipantJson()),
								job.getCorrelationId());
					} else if (!job.getIsSaved().equals(1) && !job.getIsContactsPushed().equals(1)) {
						incrementAttempt(job);
						logger.info(">>>SavedSearch:" + job.getSavedSearchName() + " and TrialId:" + job.getTrialId()
								+ " is not saved in DB");						
						participantService.save(convertJSONtoList(job.getParticipantJson()), job.getCreatedBy(),
								job.getCorrelationId());
					} /*else if (!job.getIsSaved().equals(1)) {
						participantAsyncService.save(convertJSONtoList(job.getParticipantJson()), job.getCreatedBy(),
								job.getCorrelationId());
					}*/

					checkAndUpdateContactPushStatus(job.getCorrelationId(), false);
				});
			}
		} catch (Exception e) {
			logger.info("Failed to add the job to ParticipantJob due to" + e.getMessage());
			logger.error("Exception ocurred while adding job to ParticipantJob", e);
		}
	}

	private List<Participant> convertJSONtoList(String json) {
		List<Participant> partList = new ArrayList<>();
		try {
			JSONArray participantJsonArray = new JSONArray(json);
			if (null != participantJsonArray) {
				for (int i = 0; i < participantJsonArray.length(); i++) {

					ObjectMapper mapper = new ObjectMapper();
					Participant participant = mapper.readValue(participantJsonArray.getString(i), Participant.class);
					partList.add(participant);
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Exception ocurred during JSON to List conversion", e);
		}

		return partList;
	}

	public synchronized void updateBatchStatusMap(String correlationId, Integer batchId, Integer jobStatus) {
		ParticipantJob job = participantJobRepository.findByCorrelationIdEquals(correlationId);
		Map<String, String> batchMap = new HashMap<>();

		logger.info("==> Job matched for correlationId:" + correlationId + " is==>" + job);

		if (null != correlationId && null != batchId) {
			ObjectMapper obj = new ObjectMapper();
			if (job != null) {
				if (null == job.getBatchStatus() || job.getBatchStatus().trim().isEmpty()) {
					batchMap.put(batchId.toString(), jobStatus.toString());
					try {
						job.withBatchStatus(obj.writeValueAsString(batchMap));
					} catch (Exception e) {
						logger.error("Error while converting Map to json", e);
					}

				} else {
					try {
						batchMap = obj.readValue(job.getBatchStatus(), Map.class);
						batchMap.put(batchId.toString(), jobStatus.toString());
						job.withBatchStatus(obj.writeValueAsString(batchMap));
					} catch (Exception e) {
						logger.error("Error while converting Map to json", e);
					}
				}
				try {
					participantJobRepository.save(job.withUpdatedOn(new Date()));
				} catch (Exception e) {
					logger.error("Error occurred", e);
				}

				checkAndUpdateContactPushStatus(correlationId, false);

			}

		}

	}
	
	public void incrementAttempt( ParticipantJob job ) {		
		logger.info("Going to make to "+(job.getAttemptsMade() + 1) + " attempt for Job with Correlationid:"+job.getCorrelationId());
		try {
			String name = job.getSavedSearchName().contains(CRMContactConstants.JOB_INPROGRESS_PREFIX)?job.getSavedSearchName():CRMContactConstants.JOB_INPROGRESS_PREFIX+job.getSavedSearchName();
			participantJobRepository.save(job.withSavedSearchName(name).withAttemptsMade(job.getAttemptsMade() + 1).withUpdatedOn(new Date()));
		} catch (Exception e) {
					logger.error("Error occurred", e);
		}

	}

	public Map<String, String> getBatchStatusMap(String correlationId) {
		ParticipantJob job = participantJobRepository.findByCorrelationIdEquals(correlationId);
		Map<String, String> batchMap = new HashMap<>();

		logger.info("==> Job matched for correlationId:" + correlationId + " is==>" + job);

		if (null != correlationId) {
			ObjectMapper obj = new ObjectMapper();
			if (null != job && null != job.getBatchStatus()) {
				try {
					batchMap = obj.readValue(job.getBatchStatus(), Map.class);
				} catch (Exception e) {
					logger.error("Error while converting json to Map", e);
				}
			}

		}
		return batchMap;

	}

	public void checkAndUpdateContactPushStatus(String correlationId, boolean finalUpdate) {
		ParticipantJob job = participantJobRepository.findByCorrelationIdEquals(correlationId);
		Map<String, String> batchMap = new HashMap<>();

		logger.info("==> Job matched for correlationId:" + correlationId + " is==>" + job);

		if (null != correlationId) {
			ObjectMapper obj = new ObjectMapper();
			if (job != null && null != job.getBatchStatus()) {
				try {
					logger.info("Retrived BATCH status Json:" + job.getBatchStatus());
					batchMap = obj.readValue(job.getBatchStatus(), Map.class);
					if (!batchMap.containsValue(String.valueOf(0))
							&& batchMap.size() == job.getTotalContactBatchCount().intValue()) {
						job.withIsContactsPushed(1).withIsCategoryCreated(1);
						job.withSavedSearchName(job.getSavedSearchName().replaceAll("INP_", ""));
					} else {
						job.withIsContactsPushed(0);
					}
					job.withBatchStatus(obj.writeValueAsString(batchMap));
				} catch (Exception e) {
					logger.error("Error while converting Map to json", e);
				}

				if (finalUpdate) {
					job.withSavedSearchName(job.getSavedSearchName().replaceAll("INP_", ""));
				}
				try {
					participantJobRepository.save(job.withUpdatedOn(new Date()));
				} catch (Exception e) {
					logger.error("Error occurred", e);
				}

			}

		}

	}

	private void resetIdleJobs() {
		checkAndDoDelete();
		List<ParticipantJob> jobList = participantJobRepository.findBySavedSearchNameLike("INP_%");
		if (null != jobList && jobList.size() > 0) {
			jobList.forEach(pjob -> {
				logger.info("Checking whether Process Reset Required for: " + pjob.toString());

				try {

					logger.info("Retrived BATCH status Json:" + pjob.getBatchStatus());
					ObjectMapper obj = new ObjectMapper();
					Map<String, String> batchMap = null;
					if( null != pjob.getBatchStatus()) {
						batchMap = obj.readValue(pjob.getBatchStatus(), Map.class);
					}
					
					if ( null != batchMap && !batchMap.containsValue(String.valueOf(0))
							&& batchMap.size() == pjob.getTotalContactBatchCount().intValue()) {
						pjob.withIsContactsPushed(1).withIsCategoryCreated(1);
						pjob.withSavedSearchName(pjob.getSavedSearchName().replaceAll("INP_", ""));
					}

					Date date1 = new Date();
					Date date2 = pjob.getUpdatedOn();

					// BatchReset Interval
					if (getDiffInMinutes(date1, date2) > asyncConfigLoaderBean.getBatchResetInterval()) {
						pjob.withSavedSearchName(pjob.getSavedSearchName().replace("INP_", ""));
					}
					
					if (getDiffInMinutes(date1, date2) > asyncConfigLoaderBean.getBatchDeferredInterval() ||
							pjob.getAttemptsMade() > asyncConfigLoaderBean.getBatchMaxAttempts()) {
						pjob.withIsDisabled(1);
					}
					
					participantJobRepository.save(pjob.withUpdatedOn(new Date()));
					

				} catch (Exception e) {
					logger.error("Error occurred while Checking for Process Reset", e);
				}

			});
		}
	}
	
	private void checkAndDoDelete() {
		List<ParticipantJob> jobList = participantJobRepository.findByIsContactsPushed(0);
		if (null != jobList && jobList.size() > 0) {
			jobList.forEach(pjob -> {
				logger.info("Checking whether Soft delete Required for: " + pjob.toString());

				try {
					Date date1 = new Date();
					Date date2 = pjob.getUpdatedOn();
										
					if (getDiffInMinutes(date1, date2) > asyncConfigLoaderBean.getBatchDeferredInterval() ||
							pjob.getAttemptsMade() > asyncConfigLoaderBean.getBatchMaxAttempts()) {
						pjob.withIsDisabled(1);
					}
					
					participantJobRepository.save(pjob.withUpdatedOn(new Date()));

				} catch (Exception e) {
					logger.error("Error occurred while Checking for Soft delete", e);
				}

			});
		}
	}

	private long getDiffInMinutes(Date date1, Date date2) {
		long diff = Math.abs(date1.getTime() - date2.getTime());
		long diffMinutes = TimeUnit.MINUTES.convert(diff, TimeUnit.MILLISECONDS);
		// long diffHours = diff / (60 * 60 * 1000);
		logger.info("Diff between " + date1 + " and " + date2 + " is" + diffMinutes);
		return diffMinutes;
	}

}