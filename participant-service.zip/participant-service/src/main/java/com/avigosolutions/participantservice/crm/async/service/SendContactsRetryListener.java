package com.avigosolutions.participantservice.crm.async.service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.listener.RetryListenerSupport;
import org.springframework.stereotype.Component;

import com.avigosolutions.participantservice.async.config.AsyncConfigLoaderBean;
import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.model.CRMContact;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class SendContactsRetryListener extends RetryListenerSupport {

	@Autowired
	CRMContactJobService cRMContactJobService;

	@Autowired
	AsyncConfigLoaderBean asyncConfigLoaderBean;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public <T, E extends Throwable> void close(RetryContext context, RetryCallback<T, E> callback,
			Throwable throwable) {
		logger.info("==>Retry activity is completed.");
		super.close(context, callback, throwable);
	}

	@Override
	public <T, E extends Throwable> void onError(RetryContext context, RetryCallback<T, E> callback,
			Throwable throwable) {
		logger.info("Retry attempt:" + context.getRetryCount() + " failed due to " + throwable.getMessage());
		@SuppressWarnings("unchecked")
		List<CRMContact> contact = (List<CRMContact>) context.getAttribute("crmContacts");
		// String userId = (String) context.getAttribute("userId");
		if (asyncConfigLoaderBean.getSendContactsRetryAttempts() > context.getRetryCount()) {
			try {
				cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(contact));
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		super.onError(context, callback, throwable);
	}

	@Override
	public <T, E extends Throwable> boolean open(RetryContext context, RetryCallback<T, E> callback) {
		logger.info("==>Retry activity is initiated.");
		return super.open(context, callback);
	}
}