package com.avigosolutions.participantservice.crm.constants;

public class CRMContactConstants {

	public static enum BatchStatus {
		INITIATED, RETRY_INPROGRESS, FAILED, SAVED, COMPLETED;
	};

	public static enum USER_STATUS {
		STARTED, INPROGRESS, FAILED, SAVED;
	};

	public final static Boolean BATCH_IN_PROCESS_TRUE = true;
	public final static Boolean BATCH_IN_PROCESS_FALSE = false;
	public final static String JOB_INPROGRESS_PREFIX = "INP_";
}
