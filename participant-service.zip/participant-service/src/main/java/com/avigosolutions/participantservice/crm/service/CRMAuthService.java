package com.avigosolutions.participantservice.crm.service;

import org.springframework.http.HttpEntity;

import com.avigosolutions.participantservice.dto.CRMAuth;

public interface CRMAuthService {
	
	public CRMAuth authenticate();
	
	public CRMAuth getAuthDetails();

	public HttpEntity<String> getHttpEntity(String data);

}
