package com.avigosolutions.participantservice.crm.service;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.participantservice.dto.CRMAuth;
import com.avigosolutions.participantservice.utils.CommonUtils;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Service
public class CRMAuthServiceImpl implements CRMAuthService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${zyprr.baseurl}")
	private String BASE_URL;

	@Value("${zyprr.auth.url}")
	private String AUTH_URL;

	@Value("${zyprr.auth.username}")
	private String AUTH_USERID;

	@Value("${zyppr.auth.password}")
	private String AUTH_PASSWORD;

	@Value("${zyppr.auth.consumer_key}")
	private String AUTH_CONSUMER_KEY;

	private String authURL;

	private String authBody;

	private String authHeader;

	private CRMAuth crmAuth = null;

	@PostConstruct
	private void init() {
		authURL = BASE_URL + AUTH_URL;
		authHeader = "consumer_key=" + AUTH_CONSUMER_KEY;
		authBody = "{\"userName\":\"" + AUTH_USERID + "\",\"password\":\"" + AUTH_PASSWORD + "\"}";
	}

	@Override
	public CRMAuth authenticate() {
		logger.info("Attempting Zyppr Authentication - UserID: {}", AUTH_USERID);
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authHeader);
		HttpEntity<String> httpEntity = new HttpEntity<String>(authBody, headers);
		try {
			String response = restTemplate.postForObject(authURL, httpEntity, String.class);
			crmAuth = parseJSON(response);
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr Authentication", e);
		}
		return crmAuth;
	}

	private CRMAuth parseJSON(String response) {
		crmAuth = new CRMAuth();
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String status = context.read("$.status", String.class);
		String responseCode = context.read("$.responseCode", String.class);
		String accessToken = null;
		String errorMessage = null;
		if (responseCode.equals("200")) {
			accessToken = context.read("$.result.access_token", String.class);
			logger.info("Zyppr Authentication - Successful, received access token");
		} else if (responseCode.equals("401")) {
			logger.error("Token expired or invalid");
		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr Authentication - FAILED - {}", responseCode);
		}
		crmAuth.withStatus(status).withResponseCode(responseCode).withAuthToken(accessToken)
				.withErrorMessage(errorMessage);
		return crmAuth;
	}

	@Override
	public CRMAuth getAuthDetails() {
		if (crmAuth == null) {
			return authenticate();
		}
		return crmAuth;
	}

	@Override
	public HttpEntity<String> getHttpEntity(String data) {
		CRMAuth auth = getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		return new HttpEntity<String>(data, CommonUtils.getCRMHeaders(authHeader1));
	}
}
