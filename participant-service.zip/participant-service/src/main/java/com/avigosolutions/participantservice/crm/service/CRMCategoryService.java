package com.avigosolutions.participantservice.crm.service;

import java.util.Map;

import com.avigosolutions.participantservice.model.CRMCategory;

public interface CRMCategoryService {

	public void createCategory(CRMCategory category);
	
	public void updateCategory(CRMCategory category);
	
	public void createNamedFilter(CRMCategory category);
	
	public String getLookupCode(String displayName);

	public boolean addSubstitution(Map<String, String> map);
	
}
