package com.avigosolutions.participantservice.crm.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import javax.annotation.PostConstruct;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
import com.avigosolutions.participantservice.crm.async.service.CRMContactJobService;
import com.avigosolutions.participantservice.crm.constants.CRMContactConstants;
import com.avigosolutions.participantservice.dto.CRMAuth;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.utils.CommonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Service
public class CRMCategoryServiceImpl implements CRMCategoryService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${zyprr.baseurl}")
	private String BASE_URL;

	@Value("${zyprr.category.add}")
	private String CREATE_CATEGORY_URL;

	@Value("${zyprr.contact.meta.url}")
	private String CONTACT_META_URL;

	@Value("${zyprr.category.update}")
	private String CONTACT_UPDATE_URL;

	@Value("${zyprr.substitution.url}")
	private String CONTACT_SUBSTITUTION_URL;

	@Value("${zyppr.auth.consumer_key}")
	private String AUTH_CONSUMER_KEY;

	private String createCategoryURL;
	private String updateCategoryURL;
	private String getCategoriesURL;
	private String updateSubstitutesURL;
	private String authHeader;
	//private final String CATEGORY_DELIMITER = "-";
	private final String CATEGORY_DELIMITER = "-.-";
	// jsonArray categories location
	private final int CATEGORY_INDEX = 122;

	@Autowired
	CRMAuthService crmAuthService;

	@Autowired
	RetryTemplate retryCategoryTemplate;

	@Autowired
	CRMContactJobService cRMContactJobService;
	
	/*@Autowired
	RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
*/
	@PostConstruct
	private void init() {
		createCategoryURL = BASE_URL + CREATE_CATEGORY_URL;
		authHeader = "consumer_key=" + AUTH_CONSUMER_KEY;
		getCategoriesURL = BASE_URL + CONTACT_META_URL;
		updateCategoryURL = BASE_URL + CONTACT_UPDATE_URL;
		updateSubstitutesURL = BASE_URL + CONTACT_SUBSTITUTION_URL;
	}

	private String generateCategoryName(long trialId, String trialName, String searchName) {
		try {
			if (trialName == null) {
				return trialId + CATEGORY_DELIMITER + getEncodedToken(searchName);
			}

			if (searchName == null) {
				return getEncodedToken(trialName + CATEGORY_DELIMITER) + trialId +  CATEGORY_DELIMITER;
			}
			return getEncodedToken(trialName) + CATEGORY_DELIMITER + trialId + CATEGORY_DELIMITER + getEncodedToken(searchName);
		} catch (Exception e) {
			logger.error("Error in URL decoding", e);
		}
		return "";
	}

	private String getEncodedToken(String input) throws UnsupportedEncodingException {
		return URLEncoder.encode(input.replace(" ", "_"), "UTF-8");
	}

	@Override
	public void createCategory(CRMCategory category)  {
		retryCategoryTemplate.execute(context -> {
			context.setAttribute("crmCategory", category);
			CRMAuth auth = crmAuthService.getAuthDetails();
			String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";			
			
			logger.info("TrialId:" + category.getTrialId() + "--TrialName:" + category.getTrialName() + "--SearchName:"
					+ category.getSearchName());
			String displayName = generateCategoryName(category.getTrialId(), category.getTrialName(),
					category.getSearchName());
			String lookupCode = getLookupCode(displayName);
			if (lookupCode != null) {
				logger.info("Category already present - {} - {}", displayName, lookupCode);
				category.withLookupCode(lookupCode);
				return false;
			}
			String catURL = createCategoryURL.replace(":CATEGORY_NAME", displayName);
			HttpEntity<String> httpEntity = new HttpEntity<String>(CommonUtils.getCRMHeaders(authHeader1));

			logger.info("Http Entity Body:" + catURL);
			try {
				String response = new RestTemplate().postForObject(catURL, httpEntity, String.class);
				logger.debug("CRM response:" + response);

				// Retry in case of invalid/expired token
				if (response.contains("FAIL") && response.contains("401")) {
					logger.error("Token expired or invalid");
					crmAuthService.authenticate();
					response =  new RestTemplate().postForObject(catURL, httpEntity, String.class);
				}
				
				if(!parseJSON(response, category)) {
					try {
						cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(category).withJobStatus(CRMContactConstants.BatchStatus.FAILED.name()));
						}catch(Exception ex) {
							logger.info(">>> Exception: "+ex.getMessage());
							logger.error(">>> Exception",ex);
						}
				}
			} catch (Exception e) {
				logger.error("Exception in calling Zyppr add category", e);
				try {
					cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(category).withJobStatus(CRMContactConstants.BatchStatus.FAILED.name()));
				}catch(Exception ex) {
					logger.info(">>> Exception: "+ex.getMessage());
					logger.error(">>> Exception",ex);
				}
			}
			return false;
		}, recover -> {
			cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(category).withJobStatus(CRMContactConstants.BatchStatus.FAILED.name()));
			return true;
		});
	}

	public boolean parseJSON(String response, CRMCategory category) {
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String status = context.read("$.status", String.class);
		String responseCode = context.read("$.responseCode", String.class);
		String errorMessage = null;
		if (responseCode.equals("200")) {
			String uuid = context.read("$.result[0].id", String.class);
			String displayName = context.read("$.result[0].displayName", String.class);
			String lookupCode = context.read("$.result[0].lookupCode", String.class);
			category.withUuid(uuid).withFilterName(displayName).withLookupCode(lookupCode);
			logger.info("Zyppr parse category - Successful");
			return true;
		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr Authentication - FAILED - {}, {}", responseCode, errorMessage);
			return false;
		}
		return false;
	}

	@Override
	public void updateCategory(CRMCategory category) {
		retryCategoryTemplate.execute(context -> {
			context.setAttribute("crmCategory", category);
			if (category.getOldTrialName() == null && category.getOldSearchName() == null) {
				logger.info("No category updation required");
				return false;
			}
			if (category.getOldTrialName() != null) {
				logger.info(">>> Update trial name");
				updateTrialNameChange(category);
				logger.info("<<< Update trial name");
			} else if (category.getOldSearchName() != null) {
				logger.info(">>> Update search name");
				updateSearchNameChange(category);
				logger.info(">>> Update search name");
			}
			return true;
		}, recover -> {
			CRMContactJob contactJob = cRMContactJobService.getCrmContactJob(category);
			/*cRMContactJobService.addBatchToList(cRMContactJobService.getBatch(1, category.getCrmContacts().size(),
					CRMContactConstants.BATCH_IN_PROCESS_FALSE), contactJob.getBatches());*/
			cRMContactJobService.addJobLog(contactJob);
			return false;
		});
	}

	/*
	 * Only trial name is changed, So need to change category suffixes
	 */
	private void updateTrialNameChange(CRMCategory category) {
		String oldPrefix = generateCategoryName(category.getTrialId(), category.getOldTrialName(), null);

		Map<String, String> lookupCodeMap = getMatchedLookupCodes(oldPrefix);
		if (lookupCodeMap.size() == 0) {
			logger.info("Category lookup code map is 0");
			return;
		}
		logger.info("Category lookup code map count=["+lookupCodeMap.size()+"]");
		String newPrefix = generateCategoryName(category.getTrialId(), category.getTrialName(), null);
		logger.info("Category new prefix"+newPrefix);
		lookupCodeMap.forEach((k, v) -> {
			String newDisplayName = k.replace(oldPrefix, newPrefix);			
			updateCategoryAPI(k, newDisplayName);
		});
	}

	/*
	 * Only search name is changed, so need update category with that trail name ans
	 * search name
	 */
	private void updateSearchNameChange(CRMCategory category) {
		String oldDisplayName = generateCategoryName(category.getTrialId(), category.getTrialName(),
				category.getOldSearchName());

		Map<String, String> lookupCodeMap = getMatchedLookupCodes(oldDisplayName);
		if (lookupCodeMap.size() == 0) {
			return;
		}
		String newDisplayName = generateCategoryName(category.getTrialId(), category.getTrialName(),
				category.getSearchName());
		lookupCodeMap.forEach((k, v) -> {
			updateCategoryAPI(k, newDisplayName);
		});
	}

	private void updateCategoryAPI(String oldDisplayName, String newDisplayName) {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		if (oldDisplayName == null || newDisplayName == null) {
			logger.info("Category not present - {} - {}", newDisplayName, oldDisplayName);
			return;
		}
		String catURL = updateCategoryURL.replace(":OLD_CATEGORY_NAME", oldDisplayName);
		catURL = catURL.replace(":CATEGORY_NAME", newDisplayName);
		HttpEntity<String> httpEntity = new HttpEntity<String>(CommonUtils.getCRMHeaders(authHeader1));
		try {
			String response =  new RestTemplate().postForObject(catURL, httpEntity, String.class);
			DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
			String status = context.read("$.status", String.class);
			String responseCode = context.read("$.responseCode", String.class);
			// Retry
			if (responseCode.equals("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response =  new RestTemplate().postForObject(catURL, httpEntity, String.class);
			}
			logger.info("Category update -{} from -{} status {}, response {}", newDisplayName, oldDisplayName, status,
					responseCode);
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr add category", e);
		}
	}

	@Override
	public void createNamedFilter(CRMCategory category) {

	}

	@Override
	public String getLookupCode(String displayName) {
		return loadLookupCodes().get(displayName);
	}

	private Map<String, String> loadLookupCodes() {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authHeader1);
		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
		try {
			String response =  new RestTemplate().exchange(getCategoriesURL, HttpMethod.GET, httpEntity, String.class)
					.getBody();
			// Retry in case of invalid/expired token
			if (response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response =  new RestTemplate().exchange(getCategoriesURL, HttpMethod.GET, httpEntity, String.class).getBody();
			}
			Map<String, String> lookupMap = new HashMap<>();
			try{
				lookupMap = parseCategoriesJSON(response);
			}catch(Exception e) {
				logger.error("Error Parsing Lookup response:"+response);
				throw e;
			}
			return lookupMap;
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr Categories Lookup", e);
		}
		return new HashMap<>();
	}

	public Map<String, String> getMatchedLookupCodes(String prefix) {
		Map<String, String> allCodes = loadLookupCodes();
		Map<String, String> matchedCodes = new HashMap<>();
		allCodes.forEach((k, v) -> {
			if (prefix != null && k.startsWith(prefix)) {
				matchedCodes.put(k, v);
			}
		});
		return matchedCodes;
	}

	public Map<String, String> parseCategoriesJSON(String response) {
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String status = context.read("$.status", String.class);
		String responseCode = context.read("$.responseCode", String.class);
		String errorMessage = null;
		Map<String, String> lookupMap = new HashMap<>();
		if (responseCode.equals("200")) {
			int count = context.read("$.result.fields[" + CATEGORY_INDEX + "].possibleValues.length()", Integer.class);
			IntStream.range(0, count).forEach(x -> {
				String code = context.read("$.result.fields[" + CATEGORY_INDEX + "].possibleValues[" + x + "].code",
						String.class);
				String value = context.read("$.result.fields[" + CATEGORY_INDEX + "].possibleValues[" + x + "].value",
						String.class);
				try {
					lookupMap.put(getEncodedToken(value), code);
				} catch (UnsupportedEncodingException e) {
					logger.error("Failed during encoding of value:"+value);
				}
			});
			logger.info("Zyppr parse categories - Successful");
		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr parseCategories - FAILED - {}, {}", responseCode, errorMessage);
		}
		return lookupMap;
	}

	@Override
	public boolean addSubstitution(Map<String, String> map) {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		JSONArray jsubstitutes = substitutesJSON(map);

		HttpEntity<String> httpEntity = new HttpEntity<String>(jsubstitutes.toString(), CommonUtils.getCRMHeaders(authHeader1));
		try {
			String response =  new RestTemplate().postForObject(updateSubstitutesURL, httpEntity, String.class);
			DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
			String status = context.read("$.status", String.class);
			String responseCode = context.read("$.responseCode", String.class);
			if (responseCode.equals("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response =  new RestTemplate().postForObject(updateSubstitutesURL, httpEntity, String.class);
			}
			logger.info("Response from Zyprr for addSubstition==>" + response);
			logger.info("Substitutes updated success {} - {}", status, responseCode);
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr addSubstitution", e);
			return false;
		}
		return true;
	}

	private JSONArray substitutesJSON(Map<String, String> map) {
		JSONArray jsubstitutes = new JSONArray();

		map.forEach((k, v) -> {
			JSONObject jcontact = new JSONObject();
			try {
				jcontact.put("name", k);
				if (v == null || v.trim().equals("")) {
					jcontact.put("value", JSONObject.NULL);
				} else {
					jcontact.put("value", v);
				}
				jcontact.put("inverse", true);
				jsubstitutes.put(jcontact);
			} catch (JSONException e) {
				logger.error("Error in json creation", e);
			}
		});

		return jsubstitutes;
	}

}
