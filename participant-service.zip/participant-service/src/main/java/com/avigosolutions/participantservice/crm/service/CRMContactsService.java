package com.avigosolutions.participantservice.crm.service;

import java.util.List;

import com.avigosolutions.participantservice.model.CRMContact;

public interface CRMContactsService {

	public void createContacts(List<CRMContact> contactList, String correlationId);
	
	public void updateContacts(List<CRMContact> contactList);
	
	public void createContact(CRMContact contact);
	
	public void updateContacts(CRMContact contact);
	
	public String updateCRMContactCustomField(String patientId, String customFieldName, String customFieldValue);

	public String updateCRMContactQuestionnaireStatus(String patientId, String customFieldName,
			String customFieldValue);
	
}
