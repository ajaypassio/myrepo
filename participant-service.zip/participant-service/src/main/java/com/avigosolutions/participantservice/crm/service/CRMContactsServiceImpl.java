package com.avigosolutions.participantservice.crm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.participantservice.crm.async.service.CrmAsyncService;
import com.avigosolutions.participantservice.crm.async.service.CRMContactJobService;
import com.avigosolutions.participantservice.dto.CRMAuth;
import com.avigosolutions.participantservice.model.CRMContact;
import com.avigosolutions.participantservice.model.CRMCustomField;
import com.avigosolutions.participantservice.utils.EncryptionUtils;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Service
public class CRMContactsServiceImpl implements CRMContactsService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${zyprr.baseurl}")
	private String BASE_URL;

	@Value("${zyprr.contacts.add}")
	private String CREATE_CONTACTS_URL;

	@Value("${zyprr.contacts.update}")
	private String UPDATE_CONTACT_URL;

	@Value("${zyprr.contacts.get}")
	private String GET_CONTACT_URL;

	@Value("${zyppr.auth.consumer_key}")
	private String AUTH_CONSUMER_KEY;

	@Value("${sprintt.zyprr.contacts.async.processing.enabled:false}")
	private Boolean asyncEnabled;

	private String createContactsURL;
	private String updateContactsURL;
	private String getContactURL;
	private String authHeader;

	private final String PATIENT_ID = "PatientID";
	private final String AGE = "Age (years)";
	private final String TRAIL_ID = "TrialID";
	private final String GENDER = "Gender";
	private final String ENCODED_PATIENTID = "EncodedPatientID";

	private final int BATCH_SIZE = 100;

	@Autowired
	CRMAuthService crmAuthService;

	@Autowired
	CRMCustomFieldService crmCustomFieldService;

	@Autowired
	CrmAsyncService asyncCRMService;

	@Autowired
	RetryTemplate retrySendContactsTemplate;

	@Autowired
	CRMContactJobService cRMContactJobService;

	@PostConstruct
	private void init() {
		createContactsURL = BASE_URL + CREATE_CONTACTS_URL;
		updateContactsURL = BASE_URL + UPDATE_CONTACT_URL;
		getContactURL = BASE_URL + GET_CONTACT_URL;
		authHeader = "consumer_key=" + AUTH_CONSUMER_KEY;
	}

	@Override
	public void createContacts(List<CRMContact> contactList, String correlationId) {

		Map<Integer, List<CRMContact>> batchMap = new HashMap<Integer, List<CRMContact>>();
		Map<String,String> bMap = asyncCRMService.getBatchStatusMap(correlationId);
		final String BATCH_COMPLETED="1";

		logger.info("Started processing contacts , total to be added==>" + contactList.size());

		int batchCount = 0;
		Integer startIndex = 0;
		Integer endIndex = BATCH_SIZE;
		while (endIndex <= contactList.size()) {
			batchMap.put(batchCount++, contactList.subList(startIndex, endIndex));
			startIndex = endIndex;
			endIndex = endIndex + BATCH_SIZE;
		}

		Integer bal = contactList.size() % BATCH_SIZE;
		List<CRMContact> contactListtmpContactList = contactList.subList(contactList.size() - bal, contactList.size());
		batchMap.put(99999, contactListtmpContactList);

		batchMap.forEach((key, value) -> {
			if(null != bMap && !bMap.isEmpty() && bMap.containsKey(key.toString()) && BATCH_COMPLETED.equals(bMap.get(key.toString()))) {
				logger.info(">>>Skipping the batch:"+key+",CorrelationId:"+correlationId+" as it is already completed");
			}else {
				if (value.size() > 0) {
					logger.info("CorrelationId:"+correlationId+ " BatchId:"+key);
					logger.info("Calling AddContacts With batch [" + key + "]==>" + value.size());
					if (asyncEnabled) {
						try {
							retrySendContactsTemplate.execute(context -> {
								context.setAttribute("crmContacts", value);
								asyncCRMService.processContacts(value,cRMContactJobService.getCrmContactJob(value),correlationId,key);
								logger.info("Succeeded With batch [" + key + "]==>" + value.size());
								return true;
							}, recover -> {
								logger.info("Retry failed With batch [" + key + "]==>" + value.size()); 
								asyncCRMService.updateBatchStatusMap(correlationId, key,1);
								cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(value));
								return false;
							});
						} catch (Exception e) {
							logger.error("Error Occurred:", e);
							logger.info("Error Occurred:" + e.toString());
						}
					} else {
						retrySendContactsTemplate.execute(context -> {
							
							context.setAttribute("crmContacts", value);
							processBatchAdd(value,correlationId,key);
							logger.info("Succeeded With batch [" + key + "]==>" + value.size()); 	
							return true;
						}, recover -> {
							logger.info("Retry failed With batch [" + key + "]==>" + value.size());
							asyncCRMService.updateBatchStatusMap(correlationId, key,1);
							cRMContactJobService.addJobLog(cRMContactJobService.getCrmContactJob(value));						
							return false;
						});
					}
				}
			}

			
		});
		
		asyncCRMService.checkAndUpdateContactPushStatus(correlationId,true);

		logger.info("Finished processing contacts , total to be added==>" + contactList.size());

	}

	@Override
	public String updateCRMContactCustomField(String patientId, String customFieldName, String customFieldValue) {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authHeader1);
		String getContact = getContactURL.replace(":PATIENT_ID", String.valueOf(patientId));
		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
		try {
			String response = restTemplate.exchange(getContact, HttpMethod.GET, httpEntity, String.class).getBody();
			// Retry in case of invalid/expired token
			if (response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response = restTemplate.exchange(getContact, HttpMethod.GET, httpEntity, String.class).getBody();
			}
			return parseJSONUpdateContact(response, customFieldName, customFieldValue);
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr get contact", e);
			return null;
		}
	}

	@Override
	public String updateCRMContactQuestionnaireStatus(String patientId, String customFieldName,
			String customFieldValue) {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authHeader1);
		String getContact = getContactURL.replace(":PATIENT_ID", String.valueOf(patientId));
		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
		try {
			String response = restTemplate.exchange(getContact, HttpMethod.GET, httpEntity, String.class).getBody();
			// Retry in case of invalid/expired token
			if (response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response = restTemplate.exchange(getContact, HttpMethod.GET, httpEntity, String.class).getBody();
			}
			return parseJSONUpdateContactQuestionnaire(response, customFieldName, customFieldValue);
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr get contact", e);
			return null;
		}
	}

	private boolean processBatchAdd(List<CRMContact> contactList,String correlationId,Integer batchId) {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authHeader1);
		String catURL = createContactsURL;
		JSONArray jcontacts = contactsJSON(contactList);
		if (jcontacts == null) {
			return false;
		}
		//logger.info("contacts json to be added==>" + jcontacts.toString());
		HttpEntity<String> httpEntity = new HttpEntity<String>(jcontacts.toString(), headers);
		try {
			logger.info("Calling Zyprr URL==>" + catURL);
			String response = restTemplate.postForObject(catURL, httpEntity, String.class);
			// Retry in case of invalid/expired token
			if (response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid==>" + response);
				logger.info("Token expired or invalid");
				crmAuthService.authenticate();
				response = restTemplate.postForObject(catURL, httpEntity, String.class);
			}
			logger.info("Response from Zyprr==>");
			parseJSON(response);
			asyncCRMService.updateBatchStatusMap(correlationId, batchId,1);
		} catch (Exception e) {
			asyncCRMService.updateBatchStatusMap(correlationId, batchId,0);
			logger.info("Exception in calling Zyppr add contact");
			logger.error("Exception in calling Zyppr add contact", e);
			return false;
		}
		return true;
	}

	@Override
	public void updateContacts(List<CRMContact> contactList) {
		createContacts(contactList,null);
	}

	@Override
	public void createContact(CRMContact contact) {
		List<CRMContact> contactList = new ArrayList<>();
		contactList.add(contact);
		createContacts(contactList,null);
	}

	@Override
	public void updateContacts(CRMContact contact) {
		List<CRMContact> contactList = new ArrayList<>();
		contactList.add(contact);
		createContacts(contactList,null);
	}

	public void parseJSON(String response) {
		try{
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String status = context.read("$.status", String.class);
		String responseCode = context.read("$.responseCode", String.class);
		String errorMessage = null;
		if (responseCode.equals("200")) {
			logger.info("Zyppr parse category - Successful");

		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr Authentication - FAILED - {}, {}", responseCode, errorMessage);
		}}
		catch(Exception e){
			logger.error("Error Parsing JSON from Zyprr",e);
			logger.info("Response:"+response); throw e;
		}
	}

	private JSONArray contactsJSON(List<CRMContact> contactList) {
		JSONArray jcontacts = new JSONArray();
		try {
			for (CRMContact contact : contactList) {
				JSONObject jcontact = contactJSON(contact);
				jcontacts.put(jcontact);
			}
		} catch (Exception e) {
			logger.error("Error creating contacts json", e);
			return null;
		}
		return jcontacts;
	}

	public String parseJSONUpdateContact(String response, String customFieldName, String customFieldValue) {
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String responseCode = context.read("$.responseCode", String.class);
		JSONObject resultJson = new JSONObject();
		String errorMessage = null;
		if (responseCode.equals("200")) {
			logger.info("Zyppr parse category - Successful");
			JSONObject contact;
			try {
				contact = new JSONObject(response);
				JSONObject result = contact.getJSONObject("result");

				resultJson.put("extId", result.getString("extId"));
				resultJson.put("firstName", result.getString("firstName"));
				resultJson.put("lastName", result.getString("lastName"));
				resultJson.put("emailWork1", result.getString("emailWork1"));
				resultJson.put("conType", result.getJSONArray("conType"));
				JSONArray resultCustomProperties = new JSONArray();

				JSONArray customProperties = result.getJSONArray("customProperties");
				int count = customProperties.length();
				boolean isAlreadyFound = false;
				for (int i = 0; i < count; i++) {
					JSONObject customProperty = customProperties.getJSONObject(i).getJSONObject("meta");
					JSONObject resultCustomProperty = new JSONObject();
					JSONObject meta = new JSONObject();
					meta.put("id", customProperty.get("id"));
					meta.put("dataType", customProperty.get("dataType"));
					resultCustomProperty.put("meta", meta);
					if (customProperty.getString("name").equalsIgnoreCase(customFieldName)) {
						isAlreadyFound = true;
						resultCustomProperty.put("value", customFieldValue);
					} else {
						resultCustomProperty.put("value", customProperties.getJSONObject(i).getString("value"));
					}
					resultCustomProperties.put(resultCustomProperty);
				}
				if (!isAlreadyFound) {
					JSONObject customFields = this.crmCustomFieldService.getCustomField();
					JSONObject result1 = customFields.getJSONObject("result");
					JSONArray sections = result1.getJSONArray("sections");
					JSONObject section = sections.getJSONObject(0);
					JSONArray properties = section.getJSONArray("properties");
					int propertiesCount = properties.length();
					for (int i = 0; i < propertiesCount; i++) {
						if (properties.getJSONObject(i).getString("name").equalsIgnoreCase(customFieldName)) {
							JSONObject resultCustomProperty = new JSONObject();
							JSONObject meta = new JSONObject();
							meta.put("id", properties.getJSONObject(i).get("id"));
							meta.put("dataType", properties.getJSONObject(i).get("dataType"));
							resultCustomProperty.put("meta", meta);
							resultCustomProperty.put("value", customFieldValue);
							resultCustomProperties.put(resultCustomProperty);
						}
					}
				}
				resultJson.put("customProperties", resultCustomProperties);
				resultJson.put("restricted", result.getBoolean("restricted"));
				resultJson.put("phoneOffice", result.getString("phoneOffice"));
				resultJson.put("primaryAddressPostalCode", result.getString("primaryAddressPostalCode"));
				return updateContactInZyprr(resultJson);
			} catch (JSONException e) {
				// TODO Auto-generated catch block

			}
		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr Authentication - FAILED - {}, {}", responseCode, errorMessage);
		}
		return null;
	}

	public String parseJSONUpdateContactQuestionnaire(String response, String customFieldName,
			String customFieldValue) {
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String responseCode = context.read("$.responseCode", String.class);
		JSONObject resultJson = new JSONObject();
		String errorMessage = null;
		if (responseCode.equals("200")) {
			logger.info("Zyppr parse category - Successful");
			JSONObject contact;
			try {
				contact = new JSONObject(response);
				JSONObject result = contact.getJSONObject("result");

				resultJson.put("extId", result.getString("extId"));
				resultJson.put("firstName", result.getString("firstName"));
				resultJson.put("lastName", result.getString("lastName"));
				resultJson.put("emailWork1", result.getString("emailWork1"));
				resultJson.put("conType", result.getJSONArray("conType"));

				JSONArray resultCustomProperties = new JSONArray();

				JSONArray customProperties = result.getJSONArray("customProperties");
				int count = customProperties.length();
				String questionnaireStatus = "";
				boolean isAlreadyFound = false;
				for (int i = 0; i < count; i++) {
					JSONObject customProperty = customProperties.getJSONObject(i).getJSONObject("meta");
					JSONObject resultCustomProperty = new JSONObject();
					JSONObject meta = new JSONObject();
					meta.put("id", customProperty.get("id"));
					meta.put("dataType", customProperty.get("dataType"));
					resultCustomProperty.put("meta", meta);
					String value = customProperties.getJSONObject(i).getString("value");
					if (customProperty.getString("name").equalsIgnoreCase(customFieldName)
							&& !value.contains(customFieldValue)) {
						isAlreadyFound = true;
						questionnaireStatus = value + "," + customFieldValue;
						resultCustomProperty.put("value", questionnaireStatus);
					} else {
						resultCustomProperty.put("value", customProperties.getJSONObject(i).getString("value"));
					}
					resultCustomProperties.put(resultCustomProperty);
				}
				if (!isAlreadyFound) {
					JSONObject customFields = this.crmCustomFieldService.getCustomField();
					JSONObject result1 = customFields.getJSONObject("result");
					JSONArray sections = result1.getJSONArray("sections");
					JSONObject section = sections.getJSONObject(0);
					JSONArray properties = section.getJSONArray("properties");
					int propertiesCount = properties.length();
					for (int i = 0; i < propertiesCount; i++) {
						if (properties.getJSONObject(i).getString("name").equalsIgnoreCase(customFieldName)) {
							JSONObject resultCustomProperty = new JSONObject();
							JSONObject meta = new JSONObject();
							meta.put("id", properties.getJSONObject(i).get("id"));
							meta.put("dataType", properties.getJSONObject(i).get("dataType"));

							resultCustomProperty.put("meta", meta);
							resultCustomProperty.put("value", customFieldValue);
							resultCustomProperties.put(resultCustomProperty);
						}
					}
				}
				resultJson.put("customProperties", resultCustomProperties);
				resultJson.put("restricted", result.getBoolean("restricted"));
				resultJson.put("phoneOffice", result.getString("phoneOffice"));
				resultJson.put("primaryAddressPostalCode", result.getString("primaryAddressPostalCode"));
				return updateContactInZyprr(resultJson);
			} catch (JSONException e) {
				// TODO Auto-generated catch block

			}
		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr Authentication - FAILED - {}, {}", responseCode, errorMessage);
		}
		return null;
	}

	private String updateContactInZyprr(JSONObject updatedContact) {
		// TODO Auto-generated method stub
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authHeader1);
		String catURL = updateContactsURL;
		JSONArray jsonArray = new JSONArray();
		jsonArray.put(updatedContact);
		String response = "";
		HttpEntity<String> httpEntity = new HttpEntity<String>(jsonArray.toString(), headers);
		try {
			response = restTemplate.postForObject(catURL, httpEntity, String.class);
			if (response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response = restTemplate.postForObject(catURL, httpEntity, String.class);
			}
			parseJSON(response);
			return response;
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr add contact", e);
		}
		return null;
	}

	private JSONObject contactJSON(CRMContact contact) throws Exception {
		JSONObject jcontact = new JSONObject();
		try {
			// Add basics fields
			jcontact.put("extId", contact.getParticipantId());
			jcontact.put("restricted", false);
			jcontact.put("emailWork1", contact.getEmail());
			jcontact.put("firstName", contact.getFirstName());
			jcontact.put("lastName", contact.getLastName());
			jcontact.put("phoneOffice", contact.getPhoneNumber());
			jcontact.put("primaryAddressOne", contact.getPrimaryAddressOne());
			jcontact.put("primaryAddressCity", contact.getCity());
			jcontact.put("primaryAddressState", contact.getState());
			jcontact.put("primaryAddressPostalCode", contact.getZipCode());
			// Add categories
			JSONArray jcategories = new JSONArray();
			jcategories.put(contact.getCrmCategory().getLookupCode());
			jcontact.put("conType", jcategories);
			// Add custom fields
			JSONArray jcustProps = new JSONArray();
			if( null != contact.getGender() ) {
				jcustProps.put(getCustomPropertyJSON(GENDER, contact.getGender()));
			}
			jcustProps.put(getCustomPropertyJSON(AGE, contact.getAge() + ""));
			jcustProps.put(getCustomPropertyJSON(TRAIL_ID, contact.getCrmCategory().getTrialId() + ""));
			if( null != contact.getParticipantId() ) {
				jcustProps.put(getCustomPropertyJSON(ENCODED_PATIENTID,
						EncryptionUtils.getInstance().encryptToBase64(contact.getParticipantId())));
			}
			jcontact.put("customProperties", jcustProps);
		} catch (Exception e) {
			logger.error("Error creating contact json", e);
			throw e;
		}
		return jcontact;
	}

	private JSONObject getCustomPropertyJSON(String property, String value) throws JSONException {
		JSONObject jcustProp = new JSONObject();
		jcustProp.put("value", value);
		JSONObject jmetaID = new JSONObject();
		CRMCustomField field = crmCustomFieldService.getCustomFieldByName(property);
		if (field == null) {
			return null;
		}
		jmetaID.put("id", field.getUuid());
		jmetaID.put("dataType", field.getDataType());
		jcustProp.put("meta", jmetaID);
		return jcustProp;
	}

}
