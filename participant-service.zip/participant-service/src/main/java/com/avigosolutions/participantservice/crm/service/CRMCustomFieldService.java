package com.avigosolutions.participantservice.crm.service;

import java.util.List;

import org.json.JSONObject;

import com.avigosolutions.participantservice.model.CRMCustomField;

public interface CRMCustomFieldService {
	
	public List<CRMCustomField> loadCustomFields();
	public List<CRMCustomField> getCustomFields();
	CRMCustomField getCustomFieldByName(String name);
	JSONObject getCustomField();
}
