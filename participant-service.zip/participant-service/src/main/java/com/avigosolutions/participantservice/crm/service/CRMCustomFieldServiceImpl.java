package com.avigosolutions.participantservice.crm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import javax.annotation.PostConstruct;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.participantservice.dto.CRMAuth;
import com.avigosolutions.participantservice.model.CRMCustomField;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Service
public class CRMCustomFieldServiceImpl implements CRMCustomFieldService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${zyprr.baseurl}")
	private String BASE_URL;

	@Value("${zyprr.custfield.url}")
	private String CUST_FIELD_URL;

	@Value("${zyppr.auth.consumer_key}")
	private String AUTH_CONSUMER_KEY;

	private String customFieldURL;
	private String authHeader;

	@Autowired
	CRMAuthService crmAuthService;

	private List<CRMCustomField> customFields = null;

	private Map<String, CRMCustomField> customFieldMap = null;

	@PostConstruct
	private void init() {
		customFieldURL = BASE_URL + CUST_FIELD_URL;
		authHeader = "consumer_key=" + AUTH_CONSUMER_KEY;
	}

	@Override
	public List<CRMCustomField> loadCustomFields() {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", authHeader1);
		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
		try {
			// String response = restTemplate.getForObject(customFieldURL, String.class,
			// httpEntity);
			String response = restTemplate.exchange(customFieldURL, HttpMethod.GET, httpEntity, String.class).getBody();
			customFields = parseJSON(response);
			customFieldMap = new HashMap<>();
			if (customFields != null) {
				customFields.forEach(field -> {
					customFieldMap.put(field.getFieldName().toUpperCase(), field);
				});
			}
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr Custom fields", e);
		}
		return customFields;
	}

	public List<CRMCustomField> parseJSON(String response) {
		List<CRMCustomField> cFields = new ArrayList<>();
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		String status = context.read("$.status", String.class);
		String responseCode = context.read("$.responseCode", String.class);
		String errorMessage = null;
		if (responseCode.equals("200")) {
			int count = context.read("$.result.sections[0].properties.length()", Integer.class);
			IntStream.range(0, count).forEach(x -> {
				CRMCustomField custField = new CRMCustomField();
				String fieldName = context.read("$.result.sections[0].properties[" + x + "].name", String.class);
				String dataType = context.read("$.result.sections[0].properties[" + x + "].dataType", String.class);
				String uuid = context.read("$.result.sections[0].properties[" + x + "].id", String.class);
				custField.withFieldName(fieldName).withUuid(uuid).withDataType(dataType);
				cFields.add(custField);
			});
			logger.info("Zyppr custom fields parsing- Successful, received access token - {}", count);
		} else if (response.contains("errorMessage")) {
			errorMessage = context.read("$.errors.errorMessage", String.class);
			logger.error("Zyppr custom fields parsing - FAILED - {}, {}", responseCode, errorMessage);
		}
		return cFields;
	}

	@Override
	public List<CRMCustomField> getCustomFields() {
		if (customFields == null) {
			loadCustomFields();
		}
		return customFields;
	}

	@Override
	public CRMCustomField getCustomFieldByName(String name) {
		if (customFields == null) {
			loadCustomFields();
		}
		return customFieldMap.get(name.toUpperCase());
	}

	@Override
	public JSONObject getCustomField() {
		CRMAuth auth = crmAuthService.getAuthDetails();
		String authHeader1 = authHeader + ",access_token=\"" + auth.getAuthToken() + "\"";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", authHeader1);
		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
		String response = "";
		try {
			response = restTemplate.exchange(customFieldURL, HttpMethod.GET, httpEntity, String.class).getBody();
			//Retry in case of invalid/expired token
			if(response.contains("FAIL") && response.contains("401")) {
				logger.error("Token expired or invalid");
				crmAuthService.authenticate();
				response = restTemplate.exchange(customFieldURL, HttpMethod.GET, httpEntity, String.class).getBody();
			}
			return new JSONObject(response);
		} catch (Exception e) {
			logger.error("Exception in calling Zyppr Custom fields", e);
			return new JSONObject();
		}

	}
}
