package com.avigosolutions.participantservice.crm.service;

import java.util.List;
import java.util.Map;

import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.Participant;

public interface CRMTasksService {

	public void createCRMTasks(List<Participant> participants,String correlationId);
	
	public void createCRMTasks(CRMCategory category, boolean create);

	public void createCRMTasks(Map<String, String> substitutions);
}
