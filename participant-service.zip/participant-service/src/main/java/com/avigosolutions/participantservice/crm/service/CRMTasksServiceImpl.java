package com.avigosolutions.participantservice.crm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avigosolutions.participantservice.crm.CRMCategoryTask;
import com.avigosolutions.participantservice.crm.CRMSubstitutesTask;
import com.avigosolutions.participantservice.crm.CRMTaskExecutorService;
import com.avigosolutions.participantservice.model.CRMCategory;
import com.avigosolutions.participantservice.model.CRMContact;
import com.avigosolutions.participantservice.model.Participant;

@Service
public class CRMTasksServiceImpl implements CRMTasksService {

	@Autowired
	CRMTaskExecutorService crmTaskExecutorService;
	
	@Autowired
	CRMCategoryTask catTask;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public void createCRMTasks(List<Participant> participants,String correlationId) {
		logger.info("<<<< Started form contact Json");
		if (participants.isEmpty()) {
			return;
		}
		Participant participant = participants.get(0);
		CRMCategory crmCat = new CRMCategory();
		crmCat.withTrialId(participant.getTrialId()).withSearchName(participant.getSearchName())
				.withTrialName(participant.getTrialName());
		List<CRMContact> contactList = new ArrayList<>();
		participants.forEach(p -> {
			CRMContact contact = new CRMContact();
			contact.withEmail(p.getEmailAddress()).withFirstName(p.getFirstName()).withLastName(p.getLastName())
					.withPhoneNumber(p.getContactNumber()).withAge(p.getAge()).withParticipantId(p.getParticipantId())
					.withZipCode(p.getZipCode()).withPrimaryAddressOne(p.getAddress()).withGender(p.getGender())
					.withCity(p.getCity()).withState(p.getState()).withCrmCategory(crmCat);
			contactList.add(contact);
		});
		crmCat.withCrmContacts(contactList);
		//CRMCategoryTask catTask = new CRMCategoryTask();
		catTask.withCategory(crmCat);
		logger.info("<<< CRM Executor Service");
		crmTaskExecutorService.execute(catTask.withCorrelationId(correlationId));
		logger.info(">>> CRM Executor Service");
	}

	@Override
	public void createCRMTasks(CRMCategory category, boolean create) {
		if (category == null) {
			return;
		}
		CRMCategoryTask catTask = new CRMCategoryTask();
		catTask.withCategory(category);
		if (!create) {
			catTask.withOption("update");
		}
		crmTaskExecutorService.execute(catTask);
	}
	
	@Override
	public void createCRMTasks(Map<String, String> substitutions) {
		if (substitutions == null) {
			return;
		}
		CRMSubstitutesTask catTask = new CRMSubstitutesTask();
		catTask.withSubstitutes(substitutions);
		crmTaskExecutorService.execute(catTask);
	}
}
