package com.avigosolutions.participantservice.dto;

public class CRMAuth {
	
	private String authToken;
	private String accountId;
	private String status;
	private String responseCode;
	private String errorMessage;
	private String ownerID;
	
	public String getAuthToken() {
		return authToken;
	}
	public CRMAuth withAuthToken(String authToken) {
		this.authToken = authToken;
		return this;
	}
	public String getAccountId() {
		return accountId;
	}
	public CRMAuth withAccountId(String accountId) {
		this.accountId = accountId;
		return this;
	}
	public String getStatus() {
		return status;
	}
	public CRMAuth withStatus(String status) {
		this.status = status;
		return this;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public CRMAuth withResponseCode(String responseCode) {
		this.responseCode = responseCode;
		return this;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public CRMAuth withErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
		return this;
	}
	public String getOwnerID() {
		return ownerID;
	}
	public void setOwnerID(String ownerID) {
		this.ownerID = ownerID;
	}
	
}
