package com.avigosolutions.participantservice.dto;

import java.math.BigInteger;

public class CountModel {
	private BigInteger count;
	private BigInteger id;
	private BigInteger statusId;

	public BigInteger getCount() {
		return count;
	}

	public void setCount(BigInteger count) {
		this.count = count;
	}

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public BigInteger getStatusId() {
		return statusId;
	}

	public void setStatusId(BigInteger statusId) {
		this.statusId = statusId;
	}
}