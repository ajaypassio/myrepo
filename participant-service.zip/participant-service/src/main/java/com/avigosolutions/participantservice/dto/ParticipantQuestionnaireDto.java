package com.avigosolutions.participantservice.dto;

import java.io.Serializable;
import java.util.Date;

public class ParticipantQuestionnaireDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2167369101074503585L;

	private Long QuestionnaireId;

	private String QuestionnaireName;

	private Long CreatedBy;

	private Long UpdatedBy;

	private Boolean FutureTrialEmails;

	private Boolean QuestEmails;

	private String StudySite;

	private int TrialOptStatus;

	private Boolean RXMedStatus;

	private Boolean UserConsent;

	private boolean Interest;

	private Long LastQuestionAnswered;

	private String CreatedOn;

	private String UpdatedOn;

	private String studySiteStatus;

	private String participantId;

	private String firstName;

	private String lastName;

	private String zipCode;

	private String emailAddress;

	private String contactNumber;

	// It may be email, phone or sms
	private String preferredContactType;

	private Date dob;

	private int age;

	private String gender;

	private String address;

	private String city;

	private String state;

	private boolean sms;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean isSms() {
		return sms;
	}

	public void setSms(boolean sms) {
		this.sms = sms;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getPreferredContactType() {
		return preferredContactType;
	}

	public void setPreferredContactType(String preferredContactType) {
		this.preferredContactType = preferredContactType;
	}

	public Long getCreatedBy() {
		return CreatedBy;
	}

	public void setCreatedBy(Long createdBy) {
		CreatedBy = createdBy;
	}

	public Long getUpdatedBy() {
		return UpdatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		UpdatedBy = updatedBy;
	}

	public Boolean getFutureTrialEmails() {
		return FutureTrialEmails;
	}

	public void setFutureTrialEmails(Boolean futureTrialEmails) {
		FutureTrialEmails = futureTrialEmails;
	}

	public Boolean getQuestEmails() {
		return QuestEmails;
	}

	public void setQuestEmails(Boolean questEmails) {
		QuestEmails = questEmails;
	}

	public String getStudySite() {
		return StudySite;
	}

	public void setStudySite(String studySite) {
		StudySite = studySite;
	}

	public int getTrialOptStatus() {
		return TrialOptStatus;
	}

	public void setTrialOptStatus(int trialOptStatus) {
		TrialOptStatus = trialOptStatus;
	}

	public Boolean getRXMedStatus() {
		return RXMedStatus;
	}

	public void setRXMedStatus(Boolean rXMedStatus) {
		RXMedStatus = rXMedStatus;
	}

	public Boolean getUserConsent() {
		return UserConsent;
	}

	public void setUserConsent(Boolean userConsent) {
		UserConsent = userConsent;
	}

	public boolean isInterest() {
		return Interest;
	}

	public void setInterest(boolean interest) {
		Interest = interest;
	}

	public Long getLastQuestionAnswered() {
		return LastQuestionAnswered;
	}

	public void setLastQuestionAnswered(Long lastQuestionAnswered) {
		LastQuestionAnswered = lastQuestionAnswered;
	}

	public Long getQuestionnaireId() {
		return QuestionnaireId;
	}

	public void setQuestionnaireId(Long questionnaireId) {
		QuestionnaireId = questionnaireId;
	}

	public String getQuestionnaireName() {
		return QuestionnaireName;
	}

	public void setQuestionnaireName(String questionnaireName) {
		QuestionnaireName = questionnaireName;
	}

	public String getCreatedOn() {
		return CreatedOn;
	}

	public void setCreatedOn(String createdOn) {
		CreatedOn = createdOn;
	}

	public String getUpdatedOn() {
		return UpdatedOn;
	}

	public void setUpdatedOn(String updatedOn) {
		UpdatedOn = updatedOn;
	}

	public String getStudySiteStatus() {
		return studySiteStatus;
	}

	public void setStudySiteStatus(String studySiteStatus) {
		this.studySiteStatus = studySiteStatus;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

}
