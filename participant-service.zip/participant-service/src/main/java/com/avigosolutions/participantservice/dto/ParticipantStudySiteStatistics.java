package com.avigosolutions.participantservice.dto;

public class ParticipantStudySiteStatistics {
	private Long statusId;
	private Long count;

	public ParticipantStudySiteStatistics(Long statusId, Long count) {
		this.statusId = statusId;
		this.count = count;
	}

	public Long getStatusId() {
		return statusId;
	}

	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}
}
