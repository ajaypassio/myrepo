package com.avigosolutions.participantservice.dto;

import java.util.Date;
import java.util.List;

public class ParticipantTrialInfo {
	
     private Long id;
	
     private String trialName;
     
     private String trialStatusName;
     
     private Integer sponsorId;
     
     private String collabrators;
	
     private Date nextAppointment;
	 
	 private String latitude;
	 
	 private String longitude;
	 
	 private long trialId;
	 
	 private long studySiteId;
	 
	 public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	private List<CriteriaDto> criteria;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	public String getTrialStatusName() {
		return trialStatusName;
	}

	public void setTrialStatusName(String trialStatusName) {
		this.trialStatusName = trialStatusName;
	}

	public Integer getSponsorId() {
		return sponsorId;
	}

	public void setSponsorId(Integer sponsorId) {
		this.sponsorId = sponsorId;
	}

	public String getCollabrators() {
		return collabrators;
	}

	public void setCollabrators(String collabrators) {
		this.collabrators = collabrators;
	}

	public Date getNextAppointment() {
		return nextAppointment;
	}

	public void setNextAppointment(Date nextAppointment) {
		this.nextAppointment = nextAppointment;
	}

	/*public Long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}*/

	public List<CriteriaDto> getCriteria() {
		return criteria;
	}

	public void setCriteria(List<CriteriaDto> criteria) {
		this.criteria = criteria;
	}

	public long getTrialId() {
		return trialId;
	}

	public void setTrialId(long trialId) {
		this.trialId = trialId;
	}

	public long getStudySiteId() {
		return studySiteId;
	}

	public void setStudySiteId(long studySiteId) {
		this.studySiteId = studySiteId;
	}

}
