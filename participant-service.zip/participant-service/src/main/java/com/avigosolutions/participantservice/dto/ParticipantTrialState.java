package com.avigosolutions.participantservice.dto;

import java.io.Serializable;
import java.util.Optional;

import com.avigosolutions.participantservice.Events;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ParticipantTrialState implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("PatientID")
	private String participantId;
	private Long trialId;
	private String transactionId;
	private Events event;
	private String sourceState;
	private String targetState;
	private int sourceStateCode;
	private int targetStateCode;
	private String statusNotes;
	
	private String notes;
	
	public ParticipantTrialState() {
		
	}
	
	public ParticipantTrialState(String particpantId, Long trialId) {
		this.participantId = particpantId;
		this.trialId = trialId;
	}
	
	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String particpantId) {
		this.participantId = particpantId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Events getEvent() {
		return event;
	}

	public void setEvent(Events event) {
		this.event = event;
	}

	public String getSourceState() {
		return sourceState;
	}

	public void setSourceState(String sourceState) {
		this.sourceState = Optional.ofNullable(sourceState).orElse("IDENTIFIED").toUpperCase();
	}
	
	public String getStatusNotes() {
		return statusNotes;
	}

	public void setStatusNotes(String statusNotes) {
		this.statusNotes = statusNotes;
	}

	public int getSourceStateCode() {
		return sourceStateCode;
	}

	public void setSourceStateCode(int sourceStateCode) {
		this.sourceStateCode = sourceStateCode;
	}

	public String getTargetState() {
		return targetState;
	}

	public void setTargetState(String targetState) {
		this.targetState = targetState;
	}

	public int getTargetStateCode() {
		return targetStateCode;
	}

	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setTargetStateCode(int targetStateCode) {
		this.targetStateCode = targetStateCode;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
}