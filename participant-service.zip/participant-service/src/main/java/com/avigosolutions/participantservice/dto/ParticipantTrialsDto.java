package com.avigosolutions.participantservice.dto;

import java.util.Date;

public class ParticipantTrialsDto {
	
	private String participantId;
	
	private Boolean participantTrialStatus;
	
	private Long id;
	
	private String trialName;
	
	 protected Date createdOn;
	 
	 protected Long updatedBy;
	 
	 private String trialStatusName;
	 
	
	 

	public String getTrialStatusName() {
		return trialStatusName;
	}

	public void setTrialStatusName(String trialStatusName) {
		this.trialStatusName = trialStatusName;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public Boolean getParticipantTrialStatus() {
		return participantTrialStatus;
	}

	public void setParticipantTrialStatus(Boolean participantTrialStatus) {
		this.participantTrialStatus = participantTrialStatus;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}

}
