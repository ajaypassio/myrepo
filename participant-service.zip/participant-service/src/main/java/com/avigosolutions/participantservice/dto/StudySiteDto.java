package com.avigosolutions.participantservice.dto;

import java.util.List;

public class StudySiteDto {

	private String trialId;
	private String type;
	private List<Features> features;

	
	
	
	public List<Features> getFeatures() {
		return features;
	}

	public void setFeatures(List<Features> features) {
		this.features = features;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTrialId() {
		return trialId;
	}

	public void setTrialId(String trialId) {
		this.trialId = trialId;
	}

	@Override
	public String toString() {
		return "ClassPojo [features = " + features + ", type = " + type + ", trialId = " + trialId + "]";
	}
}
