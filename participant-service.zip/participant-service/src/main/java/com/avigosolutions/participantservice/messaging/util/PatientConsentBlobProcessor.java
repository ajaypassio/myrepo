package com.avigosolutions.participantservice.messaging.util;


import java.io.IOException;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;

@Component
public class PatientConsentBlobProcessor {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${sprintt.azure.blob.storage.connection.accountname}")
	private String azureAccountName;

	@Value("${sprintt.azure.blob.storage.connection.accountkey}")
	private String azureAccountKey;

	@Value("${sprintt.azure.blob.storage.patient.container.name}")
	String containerPatient;
	
	//@Value("${sprintt.azure.blob.storage.patient.folder.name}")
	//String folderName;

	private String colName;

	public String getColName() {
		return colName;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	public String getStorageConnectionString() {
		return "DefaultEndpointsProtocol=https;" + "AccountName=" + azureAccountName + ";AccountKey=" + azureAccountKey
				+ ";" + "EndpointSuffix=core.windows.net";
	}

	public String patientConsentBlobs(String source,String foldername, Long trialId) {
		
		logger.info("Process started ========== {} ", System.currentTimeMillis());
		return patientConsentDetails(source,foldername,trialId);
	}

	public String patientConsentDetails(String source,String foldername, Long trialId) {
		logger.info("Process started of saveDataInPatientCollection ==========");
		CloudBlobContainer container = null;
		CloudBlobClient blobClient = null;
		String contentOfPage=null;
		try {
			logger.info("getStorageConnectionString in patient collection : {} ");
			CloudStorageAccount storageAccount = CloudStorageAccount.parse(getStorageConnectionString());
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerPatient);
			if (!container.exists()) {
	            container.createIfNotExists();
			}
			
			logger.info("getting container in patient processing : {} ", containerPatient);
			contentOfPage =getConsentDetails(container,foldername,source,trialId);
			
			return contentOfPage;
		} catch (InvalidKeyException | URISyntaxException | StorageException e) {
			logger.info("Processing failed while reading message from blob container: {}", e.getMessage());
		}

		return contentOfPage;
	}

	private String getConsentDetails(CloudBlobContainer container, String folderName,String source,Long trialId) throws URISyntaxException, StorageException {
		long jobStartTS = System.currentTimeMillis();
		logger.info("Blob persistence job started for collectionName: {}");

		CloudBlobDirectory blobDirectory = container.getDirectoryReference(folderName);
		logger.info("BlobDirectory: {}", blobDirectory.getStorageUri());
		
		String blobParentContainerName =blobDirectory.getPrefix();
		
		String contentOfPage =null;
		List<String> fileNameList = new ArrayList<String>();
		
		for (ListBlobItem blobItem : blobDirectory.listBlobs()) 
		{
			CloudBlockBlob blockFileBlob = (CloudBlockBlob) blobItem;
			String blobName = blockFileBlob.getName();
			
			fileNameList.add(blobName);
		}

		if(fileNameList !=null && fileNameList.size()>0)
		{
		 if(!source.equals("default" ))
		  {
			if(trialId != null)
			 {
		      if(fileNameList.contains(blobParentContainerName+source+"_Consent_"+trialId+".html"))
		      {
		    	  logger.info("Source availble and match and Trial match: FileName :"+source+"_Consent_"+trialId+".html");
		    	  contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,source+"_Consent_"+trialId+".html");
		    	  
		    	  
		      }
		      else if(fileNameList.contains(blobParentContainerName+"Source_Consent_"+trialId+".html"))
		      {
		    	  logger.info("Source availble but does  not match Trial match : FileName :"+"Source_Consent_"+trialId+".html"); 
		    	  contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,"Source_Consent_"+trialId+".html");
		      }
		      else
		      {
		    	  logger.info("Source availble but does  not match Trial not match : FileName :"+"Source_Consent_default.html");
		    	  contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,"Source_Consent_default.html");					
		      }
			 }
			else
			{
				logger.info("Source availble but trail not available.Else executed : FileName :"+"Source_Consent_default.html");
				 contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,"Source_Consent_default.html");
			}
		  }	
		 else if(source.equals("default" ))
		 {
			 if(trialId != null)
			 {
		      if(fileNameList.contains(blobParentContainerName+"Trial_Consent_"+trialId+".html"))
		      {
		    	  logger.info("Source is default but trail  available.: FileName :"+"Trial_Consent_"+trialId+".html");
		    	  contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,"Trial_Consent_"+trialId+".html");
		      }
		      else //if(fileNameList.contains(blobParentContainerName+"Trial_Consent_default.html"))
		      {
		    	  logger.info("Source is default and else executed : FileName :"+"Trial_Consent_default.html"); 
		    	  contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,"Trial_Consent_default.html");
		      }
			 }
			else
			{
				 logger.info("Source is default and else trail not exist : FileName :"+"Trial_Consent_default.html");
			 contentOfPage = downloadBlobContent(trialId, blobDirectory, contentOfPage,"Trial_Consent_default.html");
			}	 
		 }
		}				
		return contentOfPage;
	}

	private String downloadBlobContent(Long trialId, CloudBlobDirectory blobDirectory, String contentOfPage,String fileName)
			throws URISyntaxException, StorageException {
		try {
			   CloudBlockBlob blockFileBlob = blobDirectory.getBlockBlobReference(fileName);
				contentOfPage = blockFileBlob.downloadText();
				logger.info("Content to be displayed ::   "+contentOfPage);
				
			} catch (Exception e) {
				logger.error("Errror while downloading file form container "+e.getMessage());
			}
		return contentOfPage;
	}
	
	public String fetchFooterContent() {
		logger.info("Process started of fetchFooterContent ==========");
		CloudBlobContainer container = null;
		CloudBlobClient blobClient = null;
		try {
			CloudStorageAccount storageAccount = CloudStorageAccount.parse(getStorageConnectionString());
			blobClient = storageAccount.createCloudBlobClient();
			container = blobClient.getContainerReference(containerPatient);
			container.createIfNotExists();
			return container.getBlockBlobReference("footercontent/footer.html").downloadText();

		} catch (InvalidKeyException | URISyntaxException | StorageException | IOException e) {
			logger.info("Processing failed while reading message from blob container: {}", e);
		}

		return null;
	}
}
