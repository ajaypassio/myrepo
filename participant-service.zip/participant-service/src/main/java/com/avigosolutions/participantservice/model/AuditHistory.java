package com.avigosolutions.participantservice.model;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.participantservice.audit.*;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="Audit_History")
@EntityListeners(AuditingEntityListener.class)
public class AuditHistory implements Serializable {
	
	private static final long serialVersionUID =  7237091231517057323L;
	
    @Id
    @GeneratedValue
    private Integer id;
    
    @Column(name="EntityName")
    private String name;
    
    @Column(name= "ActionPerformed")
    @Enumerated(EnumType.STRING)
    private Action action;

    @Column(name = "EntityContent",columnDefinition ="longtext")
    private String  content;

    @CreatedBy
    @Column(name = "ModifiedBy")
    private Long modifiedBy;

    @CreatedDate
    @Column(name = "ModifiedDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;

    public AuditHistory(AuditEntry entry) {
        withName(entry.getName()).withAction(entry.getAction()).withContent(entry.getContent());
    }

	public Integer getId() {
		return id;
	}

	public AuditHistory withId(Integer id) {
		this.id = id;
		return this;
	}

	public String getName() {
		return name;
	}

	public AuditHistory withName(String name) {
		this.name = name;
		return this;
	}

	public Action getAction() {
		return action;
	}

	public AuditHistory withAction(Action action) {
		this.action = action;
		return this;
	}

	public String getContent() {
		return content;
	}

	public AuditHistory withContent(String content) {
		this.content = content;
		return this;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public AuditHistory withModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
		return this;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public AuditHistory withModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
		return this;
	}

}