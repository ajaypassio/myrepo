package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class CRMCategory implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1l;

	private long id;

	private long trialId;

	private String trialName;

	private String oldSearchName;

	private String oldTrialName;

	private String searchName;

	private String filterName;

	private String uuid;

	private String lookupCode;

	@JsonIgnore
	private List<CRMContact> crmContacts = new ArrayList<>();

	public long getTrialId() {
		return trialId;
	}

	public CRMCategory withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public String getTrialName() {
		return trialName;
	}

	public CRMCategory withTrialName(String trailName) {
		this.trialName = trailName;
		return this;
	}

	public String getSearchName() {
		return searchName;
	}

	public CRMCategory withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public String getLookupCode() {
		return lookupCode;
	}

	public CRMCategory withLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
		return this;
	}

	public String getUuid() {
		return uuid;
	}

	public CRMCategory withUuid(String uuid) {
		this.uuid = uuid;
		return this;
	}

	public String getFilterName() {
		return filterName;
	}

	public CRMCategory withFilterName(String filterName) {
		this.filterName = filterName;
		return this;
	}

	public List<CRMContact> getCrmContacts() {
		return crmContacts;
	}

	public CRMCategory withCrmContacts(List<CRMContact> crmContacts) {
		this.crmContacts = crmContacts;
		return this;
	}

	public String getOldSearchName() {
		return oldSearchName;
	}

	public CRMCategory withOldSearchName(String oldSearchName) {
		this.oldSearchName = oldSearchName;
		return this;
	}

	public String getOldTrialName() {
		return oldTrialName;
	}

	public CRMCategory withOldTrialName(String oldTrailName) {
		this.oldTrialName = oldTrailName;
		return this;
	}
}
