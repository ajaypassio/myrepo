package com.avigosolutions.participantservice.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CRMContact implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1l;

	private long id;

	private String participantId;

	@JsonIgnore
	private CRMCategory crmCategory;

	private String uuid;

	private String errorCode;

	private String firstName;

	private String lastName;

	private int age;

	private String gender;

	private String email;

	private String phoneNumber;

	private String zipCode;

	private String primaryAddressOne;

	private String city;

	private String state;

	public long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public CRMContact withFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}

	public String getLastName() {
		return lastName;
	}

	public CRMContact withLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}

	public int getAge() {
		return age;
	}

	public CRMContact withAge(int age) {
		this.age = age;
		return this;
	}

	public String getEmail() {
		return email;
	}

	public CRMContact withEmail(String email) {
		this.email = email;
		return this;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public CRMContact withPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
		return this;
	}

	public CRMCategory getCrmCategory() {
		return crmCategory;
	}

	public CRMContact withCrmCategory(CRMCategory crmCategory) {
		this.crmCategory = crmCategory;
		return this;
	}

	public String getUuid() {
		return uuid;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public CRMContact withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public String getParticipantId() {
		return this.participantId;
	}

	public String getZipCode() {
		return zipCode;
	}

	public CRMContact withZipCode(String zipCode) {
		this.zipCode = zipCode;
		return this;
	}

	public String getGender() {
		return gender;
	}

	public CRMContact withGender(String gender) {
		this.gender = gender;
		return this;
	}

	public String getPrimaryAddressOne() {
		return primaryAddressOne;
	}

	public CRMContact withPrimaryAddressOne(String primaryAddressOne) {
		this.primaryAddressOne = primaryAddressOne;
		return this;
	}

	public String getCity() {
		return city;
	}

	public CRMContact withCity(String city) {
		this.city = city;
		return this;
	}

	public String getState() {
		return state;
	}

	public CRMContact withState(String state) {
		this.state = state;
		return this;
	}
}
