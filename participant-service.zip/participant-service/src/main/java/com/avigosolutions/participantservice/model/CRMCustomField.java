package com.avigosolutions.participantservice.model;

import java.io.Serializable;

public class CRMCustomField implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1l;
	
	private long id;
	
	private String fieldName;

	private String uuid;
	
	private String dataType;
	
	public long getId() {
		return id;
	}
	
	public String getFieldName() {
		return fieldName;
	}

	public CRMCustomField withFieldName(String fieldName) {
		this.fieldName = fieldName;
		return this;
	}

	public String getUuid() {
		return uuid;
	}

	public CRMCustomField withUuid(String uuid) {
		this.uuid = uuid;
		return this;
	}

	public String getDataType() {
		return dataType;
	}

	public CRMCustomField withDataType(String dataType) {
		this.dataType = dataType;
		return this;
	}

	@Override
	public String toString() {
		return "CRMCustomField [id=" + id + ", fieldName=" + fieldName + ", uuid=" + uuid + ", dataType=" + dataType
				+ "]";
	}
	
	
}
