package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.participantservice.audit.Auditable;
import com.avigosolutions.participantservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Participant")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class Participant extends Auditable<Long> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 927843385420679322L;

	@Id
	@Column(name = "ParticipantId", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z0-9_\\-=]*$")
	private String participantId;

	// @Column(name = "TrialId", nullable = false)
	// Paricipant may or may not belong to trial
	@Transient
	private long trialId;

	@Transient
	// @JsonIgnore
	// @JsonInclude(JsonInclude.Include.NON_NULL)
	private long internalId;

	@Transient
	private String trialName;

	@Transient
	private String scoreJSON;

	@Transient
	private String searchName;

	@Transient
	private int age;

	@Column(name = "FirstName", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z0-9\\s_]*$")
	private String firstName;

	@Column(name = "LastName", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z0-9\\s_]*$")
	private String lastName;

	@Column(name = "EmailAddress", nullable = true)
	//@Email
	//@Pattern(regexp="^[a-zA-Z0-9_\\+\\&\\*-]+(?:\\.[a-zA-Z0-9_\\+\\&\\*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")
	private String emailAddress;

	@Column(name = "CreatedBy")
	private Long createdBy;

	@Column(name = "CreatedOn")
	private Date createdOn;

	@Column(name = "UpdatedBy")
	private Long updatedBy;

	@Column(name = "UpdatedOn")
	private Date updatedOn;

	@Column(name = "TrialVisits", nullable = true)
	private Long trialVisits;

	@Column(name = "TrialSponsors", nullable = true)
	private String trialSponsors;

	@Column(name = "ZipCode")
	//@Pattern(regexp = "^[0-9]*$")
	private String zipCode;

	@Column(name = "ContactNumber")
	//@Pattern(regexp = "^\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})$")
	private String contactNumber;

	/*
	 * @Column(name = "PreferredContactType", nullable = true) private String
	 * preferredContactType;
	 */

	@Column(name = "DOB", nullable = true)
	private Date dob;

	@Column(name = "Gender", nullable = true)
	//@Pattern(regexp = "^(?:m|M|f|F)$")
	private String gender;

	@Column(name = "Address", nullable = true)
	private String address;

	@Column(name = "City", nullable = true)
	private String city;

	@Column(name = "State", nullable = true)
	private String state;

	@Column(name = "SMS", nullable = true)
	private boolean sms;
	
	//@Column(name = "LastName", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z0-9\\s_]*$")
	@Transient
	private String middleName;
	


	@Transient
	@OneToMany // (mappedBy = "participant",cascade = { CascadeType.ALL })
	@JoinColumn(name = "ParticipantId", referencedColumnName = "ParticipantId", insertable = false, updatable = false)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private List<ParticipantStudySite> participantStudySite;

	public String getParticipantId() {
		return this.participantId;
	}

	public Participant withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public Participant withFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}

	public String getLastName() {
		return this.lastName;
	}

	public Participant withLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public Participant withEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
		return this;
	}

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public Participant withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public Date getCreatedOn() {
		return this.createdOn;
	}

	@PrePersist
	protected void onCreate() {
		if (createdOn == null) {
			this.createdOn = new Date();
			this.updatedOn = new Date();
		}
	}

	@PreUpdate
	protected void onUpdate() {
		this.updatedOn = new Date();
	}

	public Participant withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	public Long getUpdatedBy() {
		return this.updatedBy;
	}

	public Participant withUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public Participant withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}

	public Long getTrialVisits() {
		return trialVisits;
	}

	public Participant withTrialVisits(Long trialVisits) {
		this.trialVisits = trialVisits;
		return this;
	}

	public String getTrialSponsors() {
		return trialSponsors;
	}

	public Participant withTrialSponsors(String trialSponsors) {
		this.trialSponsors = trialSponsors;
		return this;
	}

	public String getZipCode() {
		return zipCode;
	}

	public Participant withZipCode(String zipCode) {
		this.zipCode = zipCode;
		return this;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public Participant withContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
		return this;
	}

	/*
	 * public String getPreferredContactType() { return preferredContactType; }
	 * 
	 * public Participant withPreferredContactType(String preferredContactType) {
	 * this.preferredContactType = preferredContactType; return this; }
	 */

	public Date getDob() {
		return dob;
	}

	public Participant withDob(Date dob) {
		this.dob = dob;
		return this;
	}

	public String getGender() {
		return gender;
	}

	public Participant withGender(String gender) {
		this.gender = gender;
		return this;
	}

	public String getAddress() {
		return address;
	}

	public Participant withAddress(String address) {
		this.address = address;
		return this;
	}

	public String getCity() {
		return city;
	}

	public Participant withCity(String city) {
		this.city = city;
		return this;
	}

	public String getState() {
		return state;
	}

	public Participant withState(String state) {
		this.state = state;
		return this;
	}

	public boolean getSms() {
		return sms;
	}

	public Participant withSms(boolean sms) {
		this.sms = sms;
		return this;
	}

	public List<ParticipantStudySite> getParticipantStudySite() {
		return participantStudySite;
	}

	public void setParticipantStudySite(List<ParticipantStudySite> participantStudySite) {
		this.participantStudySite = participantStudySite;
	}

	@Column(name = "PhoneType", nullable = true)
	private String phoneType;

	public String getPhoneType() {
		return phoneType;
	}

	public Participant withPhoneType(String phoneType) {
		this.phoneType = phoneType;
		return this;
	}

	@Column(name = "PreferredTimeOfContact", nullable = true)
	//@Pattern(regexp = "\\b((1[0-2]|0?[1-9]):([0-5][0-9]) ([AaPp][Mm]))")
	private String preferredTimeOfContact;

	public String getPreferredTimeOfContact() {
		return preferredTimeOfContact;
	}

	public Participant withPreferredTimeOfContact(String preferredTimeOfContact) {
		this.preferredTimeOfContact = preferredTimeOfContact;
		return this;
	}

	@Column(name = "Voicemail", nullable = true)
	private Boolean voicemail;

	public Boolean getVoicemail() {
		return voicemail;
	}

	public Participant withVoicemail(Boolean voicemail) {
		this.voicemail = voicemail;
		return this;
	}

	public String getSession() {
		return session;
	}

	public Participant withSession(String session) {
		this.session = session;
		return this;
	}

	@Column(name = "Session", nullable = true)
	private String session;

	@Column(name = "IsPreferredEmail", nullable = true)
	private boolean preferredEmail;

	@Column(name = "IsPreferredPhone", nullable = true)
	private boolean preferredPhone;

	@Column(name = "IsPreferredMail", nullable = true)
	private boolean preferredMail;

	public boolean getPreferredEmail() {
		return preferredEmail;
	}

	public Participant withPreferredEmail(boolean isPreferredEmail) {
		this.preferredEmail = isPreferredEmail;
		return this;
	}

	public boolean getPreferredPhone() {
		return preferredPhone;
	}

	public Participant withPreferredPhone(boolean isPreferredPhone) {
		this.preferredPhone = isPreferredPhone;
		return this;
	}

	public boolean getPreferredMail() {
		return preferredMail;
	}

	public Participant withPreferredMail(boolean isPreferredMail) {
		this.preferredMail = isPreferredMail;
		return this;
	}

	public long getTrialId() {
		return trialId;
	}

	public Participant withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}
	
	public long getInternalId() {
		return internalId;
	}

	public Participant withInternalId(long internalId) {
		this.internalId = internalId;
		return this;
	}
	
	

	public String getScoreJSON() {
		return scoreJSON;
	}

	public Participant withScoreJSON(String scoresJSON) {
		this.scoreJSON = scoresJSON;
		return this;
	}

	public String getSearchName() {
		return searchName;
	}

	public Participant withSearchName(String searchName) {
		this.searchName = searchName;
		return this;
	}

	public int getAge() {
		return age;
	}

	public Participant setAge(int age) {
		this.age = age;
		return this;
	}

	public String getTrialName() {
		return trialName;
	}

	public Participant withTrialName(String trailName) {
		this.trialName = trailName;
		return this;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	
}
