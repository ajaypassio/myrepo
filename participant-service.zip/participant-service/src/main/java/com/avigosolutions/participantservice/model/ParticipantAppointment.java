package com.avigosolutions.participantservice.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ParticipantAppointment")
public class ParticipantAppointment {

	@Id
	@GeneratedValue
	@Column(name = "ParticipantAppointmentId", nullable = false)
	private long participantAppointmentId;

	@Column(name = "ParticipantId", nullable = false)
	private String participantId;

	public String getParticipantId() {
		return this.participantId;
	}

	public ParticipantAppointment withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public long getParticipantAppointmentId() {
		return participantAppointmentId;
	}

	public String getAppointmentStatus() {
		return appointmentStatus;
	}

	@Column(name = "TrialId")
	private long trialId;

	public ParticipantAppointment withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public long getTrialId() {
		return trialId;
	}

	/*
	 * @ManyToOne(fetch = FetchType.LAZY,optional=true)
	 * 
	 * @JoinColumn(name = "TrialId",insertable = false, updatable = false)
	 * 
	 * @JsonIgnore private ClinicalTrial clinicalTrial;
	 * 
	 * 
	 * 
	 * 
	 * public ClinicalTrial getClinicalTrial() { return clinicalTrial; }
	 */
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "ParticipantId", insertable = false, updatable = false)
	@JsonIgnore
	private Participant participant;

	public Participant getParticipant() {
		return participant;
	}

	@Column(name = "AppointmentDate")
	private Date appointmentDate;

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public ParticipantAppointment withAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
		return this;
	}

	@Column(name = "AppointmentStatus")
	private String appointmentStatus;

	public String getAppointmnetStatus() {
		return appointmentStatus;
	}

	public ParticipantAppointment withAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
		return this;
	}

}
