package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ParticipantJob")
public class ParticipantJob implements Serializable{
	

	private static final long serialVersionUID = -6097266567297283464L;
	
	@Id
	@GeneratedValue
	@Column(name = "JobId", nullable = false)
	private Long jobId;
	
	@Column(name = "SavedSearchName", nullable = false)
	private String savedSearchName;
	
	@Column(name = "TrialId", nullable = false)
	private Long trialId;
	
	@Column(name = "TrialName", nullable = false)
	private String trialName;
	
	@Column(name = "CorrelationId", nullable = false)
	private String correlationId;
	
	@Column(name = "ParticipantJson", nullable = false)
	private String participantJson;
	
	@Column(name = "IsCategoryCreated", nullable = false)
	private Integer isCategoryCreated;
	
	@Column(name = "IsSaved", nullable = false)
	private Integer isSaved;
	
	@Column(name = "IsContactsPushed", nullable = false)
	private Integer isContactsPushed;
	
	@Column(name = "TotalContactBatchCount", nullable = false)
	private Integer totalContactBatchCount;
	
	@Column(name = "BatchStatus", nullable = false)
	private String batchStatus;
	
	@Column(name = "CreatedBy", nullable = true)
    private String createdBy;
	
	@Column(name = "CreatedOn", nullable = true)
    private Date createdOn;
	
	@Column(name = "UpdatedOn", nullable = true)
    private Date updatedOn;
	
	@Column(name = "AttemptsMade", nullable = false)
	private Integer attemptsMade;
	
	@Column(name = "IsDisabled", nullable = false)
	private Integer isDisabled;

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}
	
	public ParticipantJob withJobId(Long jobId) {
		this.jobId = jobId;
		return this;
	}

	public String getSavedSearchName() {
		return savedSearchName;
	}

	public void setSavedSearchName(String savedSearchName) {
		this.savedSearchName = savedSearchName;
	}
	
	public ParticipantJob withSavedSearchName(String savedSearchName) {
		this.savedSearchName = savedSearchName;
		return this;
	}
	

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}
	
	public ParticipantJob withTrialId(Long trialId) {
		this.trialId = trialId;
		return this;
	}
	
	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}
	
	public ParticipantJob withTrialName(String trialName) {
		this.trialName = trialName;
		return this;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	
	public ParticipantJob withCorrelationId(String correlationId) {
		this.correlationId = correlationId;
		return this;
	}

	public String getParticipantJson() {
		return participantJson;
	}

	public void setParticipantJson(String participantJson) {
		this.participantJson = participantJson;
	}
	
	public ParticipantJob withParticipantJson(String participantJson) {
		this.participantJson = participantJson;
		return this;
	}
	
	public Integer getIsCategoryCreated() {
		return isCategoryCreated;
	}

	public void setIsCategoryCreated(Integer isCategoryCreated) {
		this.isCategoryCreated = isCategoryCreated;
	}
	
	public ParticipantJob withIsCategoryCreated(Integer isCategoryCreated) {
		this.isCategoryCreated = isCategoryCreated;
		return this;
	}
	
	public Integer getIsSaved() {
		return isSaved;
	}

	public void setIsSaved(Integer isSaved) {
		this.isSaved = isSaved;
	}
	
	public ParticipantJob withIsSaved(Integer isSaved) {
		this.isSaved = isSaved;
		return this;
	}

	public Integer getIsContactsPushed() {
		return isContactsPushed;
	}

	public void setIsContactsPushed(Integer isContactsPushed) {
		this.isContactsPushed = isContactsPushed;
	}
	
	public ParticipantJob withIsContactsPushed(Integer isContactsPushed) {
		this.isContactsPushed = isContactsPushed;
		return this;
	}

	public Integer getTotalContactBatchCount() {
		return totalContactBatchCount;
	}

	public void setTotalContactBatchCount(Integer totalContactBatchCount) {
		this.totalContactBatchCount = totalContactBatchCount;
	}

	public ParticipantJob withTotalContactBatchCount(Integer totalContactBatchCount) {
		this.totalContactBatchCount = totalContactBatchCount;
		return this;
	}
	
	public String getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
	}
	
	public ParticipantJob withBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
		return this;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public ParticipantJob withCreatedBy(String createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	public ParticipantJob withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}
	
	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
	public ParticipantJob withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
	
	public Integer getAttemptsMade() {
		return attemptsMade;
	}

	public void setAttemptsMade(Integer attemptsMade) {
		this.attemptsMade = attemptsMade;
	}
	
	public ParticipantJob withAttemptsMade(Integer attemptsMade) {
		this.attemptsMade = attemptsMade;
		return this;
	}

	public Integer getIsDisabled() {
		return isDisabled;
	}

	public void setIsDisabled(Integer isDisabled) {
		this.isDisabled = isDisabled;
	}
	
	public ParticipantJob withIsDisabled(Integer isDisabled) {
		this.isDisabled = isDisabled;
		return this;
	}

	@Override
	public String toString() {
		return "ParticipantJob [jobId=" + jobId + ", savedSearchName=" + savedSearchName + ", trialId=" + trialId
				+ ", trialName=" + trialName + ", correlationId=" + correlationId + ", isCategoryCreated="
				+ isCategoryCreated + ", isSaved=" + isSaved + ", isContactsPushed=" + isContactsPushed
				+ ", totalContactBatchCount=" + totalContactBatchCount + ", batchStatus=" + batchStatus + ", createdBy="
				+ createdBy + ", createdOn=" + createdOn + ", attemptsMade=" + attemptsMade + ", isDisabled="
				+ isDisabled + "]";
	}
   
}
