package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ParticipantQuestion")
public class ParticipantQuestion implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "ParticipantQuestionId", nullable = false)
	private long participantQuestionId;

	public long getParticipantQuestionId() {
		return this.participantQuestionId;
	}

	public ParticipantQuestion withParticipantQuestionId(long participantQuestionId) {
		this.participantQuestionId = participantQuestionId;
		return this;
	}

	@Column(name = "ParticipantId", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z0-9_\\-=]*$")
	private String participantId;

	public String getParticipantId() {
		return this.participantId;
	}

	@Column(name = "ParticipantQuestionnaireId", nullable = true)
	private Long participantQuestionnaireId;

	public Long getParticipantQuestionnaireId() {
		return participantQuestionnaireId;
	}

	public ParticipantQuestion withParticipantQuestionnaireId(Long id) {
		this.participantQuestionnaireId = id;
		return this;
	}

	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "ParticipantQuestionnaireId", insertable = false, updatable = false)
	@JsonIgnore
	private ParticipantQuestionnaire participantQuestionnaire;

	public ParticipantQuestion withParticipantQuestionnaire(ParticipantQuestionnaire participantQuestionnaire) {
		this.participantQuestionnaire = participantQuestionnaire;
		return this;
	}

	public ParticipantQuestionnaire getParticipantQuestionnaire() {
		return this.participantQuestionnaire;
	}

	public ParticipantQuestion withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	@Column(name = "QuestionId", nullable = false)
	private long questionId;

	public long getQuestionId() {
		return this.questionId;
	}

	public ParticipantQuestion withQuestionId(long questionId) {
		this.questionId = questionId;
		return this;
	}

	@Column(name = "Answer", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z]*$")
	private String answer;

	public String getAnswer() {
		return this.answer;
	}

	public ParticipantQuestion withAnswer(String answer) {
		this.answer = answer;
		return this;
	}

	@Column(name = "CreatedBy")
	private Long createdBy;

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public ParticipantQuestion withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	@Column(name = "CreatedOn")
	private Date createdOn;

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public ParticipantQuestion withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	@Column(name = "UpdatedBy")
	private Long updatedBy;

	public Long getUpdatedBy() {
		return this.updatedBy;
	}

	public ParticipantQuestion withUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	@Column(name = "UpdatedOn")
	private Date updatedOn;

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public ParticipantQuestion withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
}
