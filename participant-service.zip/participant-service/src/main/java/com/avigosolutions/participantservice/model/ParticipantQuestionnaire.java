package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.participantservice.audit.EntityListener;
import com.avigosolutions.participantservice.audit.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSetter;

@Entity
@Table(name = "ParticipantQuestionnaire")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class ParticipantQuestionnaire extends Auditable<Long> implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "ParticipantQuestionnaireId", nullable = false)
	private long participantQuestionnaireId;

	@Column(name = "ParticipantId", nullable = false)
	//@Pattern(regexp = "^[a-zA-Z0-9_\\-=]*$")
	private String participantId;

	@Column(name = "QuestionnaireId", nullable = false)
	private long questionnaireId;

	// @Column(name = "CreatedBy")
	// private Long createdBy;
	//
	// @Column(name = "CreatedOn")
	// private Date createdOn;
	//
	// @Column(name = "UpdatedBy")
	// private Long updatedBy;
	//
	// @Column(name = "UpdatedOn")
	// private Date updatedOn;

	@Column(name = "TrialOptStatus", nullable = true)
	private int trialOptStatus;

	@Column(name = "RXMedStatus", nullable = true)
	private Boolean rxMedStatus;

	@Column(name = "UserConsent", nullable = true)
	private Boolean userConsent;

	@Column(name = "Interest", nullable = true)
	private Boolean interest;

	@Column(name = "FutureTrialEmails", nullable = false)
	private boolean futureTrialEmails;

	@Column(name = "QuestEmails", nullable = false)
	private boolean questEmails;

	@Column(name = "StudySite", nullable = true)
	// Sindhu do we need this? 
	// @Pattern(regexp = "^[0-9]*$")
	private String studySite;

	@Column(name = "LastQuestionAnswered", nullable = false)
	private long lastQuestionAnswered;
	
	@Column(name = "IsNotifyOnSiteOpen", nullable = false)
	private boolean notifyOnSiteOpen;

	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "participantQuestionnaire", orphanRemoval = true)
	private List<ParticipantQuestion> participantQuestions;

	@Transient
	@OneToOne(cascade = { CascadeType.ALL })
	@JoinColumn(name = "ParticipantId", insertable = false, updatable = false)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private Participant participant;
	
	@Transient
	private String transactionId;

	@Transient
	private String trialName;

	
	@Transient
	private String programName;

	// constructor
	public ParticipantQuestionnaire() {

	}

	public long getParticipantQuestionnaireId() {
		return this.participantQuestionnaireId;
	}

	public long setParticipantQuestionnaireId(long participantQuestionnaireId) {
		return this.participantQuestionnaireId = participantQuestionnaireId;
	}

	@JsonSetter("participantQuestionnaireId")
	public ParticipantQuestionnaire withParticipantQuestionnaireId(long participantQuestionnaireId) {
		this.participantQuestionnaireId = participantQuestionnaireId;
		return this;
	}

	public String getParticipantId() {
		return this.participantId;
	}

	@JsonSetter("participantId")
	public ParticipantQuestionnaire withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public long getQuestionnaireId() {
		return this.questionnaireId;
	}

	@JsonSetter("questionnaireId")
	public ParticipantQuestionnaire withQuestionnaireId(long questionnaireId) {
		this.questionnaireId = questionnaireId;
		return this;
	}

	// public Long getCreatedBy() {
	// return this.createdBy;
	// }
	//
	// public ParticipantQuestionnaire withCreatedBy(Long createdBy) {
	// this.createdBy = createdBy;
	// return this;
	// }
	//
	// public Date getCreatedOn() {
	// return this.createdOn;
	// }
	//
	// public ParticipantQuestionnaire withCreatedOn(Date createdOn) {
	// this.createdOn = createdOn;
	// return this;
	// }
	//
	// public Long getUpdatedBy() {
	// return this.updatedBy;
	// }
	//
	// public ParticipantQuestionnaire withUpdatedBy(Long updatedBy) {
	// this.updatedBy = updatedBy;
	// return this;
	// }
	//
	// public Date getUpdatedOn() {
	// return this.updatedOn;
	// }
	//
	// public ParticipantQuestionnaire withUpdatedOn(Date updatedOn) {
	// this.updatedOn = updatedOn;
	// return this;
	// }

	public int getTrialOptStatus() {
		return trialOptStatus;
	}

	public ParticipantQuestionnaire withTrialOptStatus(int trialOptStatus) {
		this.trialOptStatus = trialOptStatus;
		return this;
	}

	public Boolean getRxMedStatus() {
		return rxMedStatus;
	}

	public ParticipantQuestionnaire withRxMedStatus(Boolean rxMedStatus) {
		this.rxMedStatus = rxMedStatus;
		return this;
	}

	public Boolean getUserConsent() {
		return userConsent;
	}

	public ParticipantQuestionnaire withUserConsent(Boolean userConsent) {
		this.userConsent = userConsent;
		return this;
	}

	public Boolean getInterest() {
		return interest;
	}

	public ParticipantQuestionnaire withInterest(Boolean interest) {
		this.interest = interest;
		return this;
	}

	public boolean getFutureTrialEmails() {
		return futureTrialEmails;
	}

	public ParticipantQuestionnaire withFutureTrialEmails(boolean futureTrialEmails) {
		this.futureTrialEmails = futureTrialEmails;
		return this;
	}

	public boolean getQuestEmails() {
		return questEmails;
	}

	public ParticipantQuestionnaire withQuestEmails(boolean questEmails) {
		this.questEmails = questEmails;
		return this;
	}

	public String getStudySite() {
		return studySite;
	}

	public ParticipantQuestionnaire withStudySite(String studySite) {
		this.studySite = studySite;
		return this;
	}

	public long getLastQuestionAnswered() {
		return lastQuestionAnswered;
	}
	
	

	@JsonSetter("lastQuestionAnswered")
	public ParticipantQuestionnaire withLastQuestionAnswered(Long lastQuestionAnswered) {
		this.lastQuestionAnswered = lastQuestionAnswered;
		return this;
	}

	public void setLastQuestionAnswered(long lastQuestionAnswered) {
		this.lastQuestionAnswered = lastQuestionAnswered;
	}

	public ParticipantQuestionnaire withParticipantQuestions(List<ParticipantQuestion> participantQuestions) {
		this.participantQuestions = participantQuestions;
		return this;
	}

	public List<ParticipantQuestion> getParticipantQuestions() {
		return participantQuestions;
	}

	public Participant getParticipant() {
		return participant;
	}

	public ParticipantQuestionnaire withParticipant(Participant participant) {
		this.participant = participant;
		return this;
	}
	
	public boolean getNotifyOnSiteOpen() {
		return notifyOnSiteOpen;
	}
	
	public ParticipantQuestionnaire withNotifyOnSiteOpen(boolean notifyOnSiteOpen) {
		this.notifyOnSiteOpen = notifyOnSiteOpen;
		return this;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}
	
	

}
