package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ParticipantStatus")
public class ParticipantStatus implements Serializable {

	private static final long serialVersionUID = 3L;

	@Id
	@GeneratedValue
	@Column(name = "ParticipantStatusId", nullable = false)
	private long id;

	public long getParticipantStatusId() {
		return this.id;
	}

	public ParticipantStatus withParticipantStatusId(long participantStatusId) {
		this.id = participantStatusId;
		return this;
	}

	@Column(name = "ParticipantStatusName", nullable = false)
	private String participantStatusName;

	public String getParticipantStatusName() {
		return this.participantStatusName;
	}

	public ParticipantStatus withParticipantStatusName(String participantStatusName) {
		this.participantStatusName = participantStatusName;
		return this;
	}
	
	@Column(name = "CreatedBy")
	private Long createdBy;

	public Long getCreatedBy() {
		return this.createdBy;
	}

	public ParticipantStatus withCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	@Column(name = "CreatedOn")
	private Date createdOn;

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public ParticipantStatus withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	@Column(name = "UpdatedBy")
	private Long updatedBy;

	public Long getUpdatedBy() {
		return this.updatedBy;
	}

	public ParticipantStatus withUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	@Column(name = "UpdatedOn")
	private Date updatedOn;

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public ParticipantStatus withUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
	
}
