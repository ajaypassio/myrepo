package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.participantservice.audit.Auditable;
import com.avigosolutions.participantservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "ParticipantStudySite")
@EntityListeners({ AuditingEntityListener.class, EntityListener.class })
public class ParticipantStudySite extends Auditable<Long> implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -260217898331264807L;

	@Id
	@GeneratedValue
	@Column(name = "ParticipantStudySiteId", nullable = false)
	private long participantStudySiteId;

	@Column(name = "ParticipantId", nullable = false)
	private String participantId;

	@Column(name = "TrialId")
	private long trialId;

	@Column(name = "StudySiteId", nullable = true)
	private Long studySiteId;

	@Column(name = "ParticipantStatusId")
	private long participantStatusId = 1;

	@Column(name = "StatusNotes")
	private String statusNotes;

	@Column(name = "CreatedOn")
	private Date createdOn;

	@Column(name = "UpdatedOn")
	private Date updatedOn;
	
	@Column(name = "scoreJSON")
	private String scoreJSON;
	
	@Column(name = "Notes",columnDefinition="nvarchar")
	private String notes;

	@Transient
	@ManyToOne
	@JoinColumn(name = "ParticipantId", referencedColumnName = "ParticipantId", insertable = false, updatable = false)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private Participant participant;

	@OneToOne
	@JoinColumn(name = "ParticipantStatusId", insertable = false, updatable = false)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private ParticipantStatus participantStatus;

	public long getParticipantStudySiteId() {
		return participantStudySiteId;
	}

	public ParticipantStudySite withParticipantStudySiteId(long participantStudySiteId) {
		this.participantStudySiteId = participantStudySiteId;
		return this;
	}

	public ParticipantStudySite withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public ParticipantStudySite withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public ParticipantStudySite withStudySiteId(long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

	public String getParticipantId() {
		return participantId;
	}

	public long getTrialId() {
		return trialId;
	}

	public Long getStudySiteId() {
		return studySiteId;
	}

	public ParticipantStudySite withParticipantStatusId(long participantStatusId) {
		this.participantStatusId = participantStatusId;
		return this;
	}

	public long getParticipantStatusId() {
		return participantStatusId;
	}

	public ParticipantStatus getParticipantStatus() {
		return participantStatus;
	}

	public ParticipantStudySite withParticipantStatus(ParticipantStatus participantStatus) {
		this.participantStatus = participantStatus;
		return this;
	}

	public Participant getParticipant() {
		return participant;
	}

	public ParticipantStudySite withParticipant(Participant participant) {
		this.participant = participant;
		return this;
	}

	@PrePersist
	protected void onCreate() {
		if (createdOn == null) {
			this.createdOn = new Date();
			this.updatedOn = new Date();
		}
	}

	@PreUpdate
	protected void onUpdate() {
		this.updatedOn = new Date();
	}

	public ParticipantStudySite withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public ParticipantStudySite withUpdatedOn(Date updatedOn) {
		this.updatedOn = Optional.ofNullable(updatedOn).orElse(new Date());
		return this;
	}

	public String getStatusNotes() {
		return statusNotes;
	}

	public ParticipantStudySite withStatusNotes(String statusNotes) {
		this.statusNotes = statusNotes;
		return this;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((participantId == null) ? 0 : participantId.hashCode());
		result = prime * result + (int) (trialId ^ (trialId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParticipantStudySite other = (ParticipantStudySite) obj;
		if (participantId == null) {
			if (other.participantId != null)
				return false;
		} else if (!participantId.equals(other.participantId))
			return false;
		if (trialId != other.trialId)
			return false;
		return true;
	}

	public Date getCreatedOn() {		
		return this.createdOn;
	}
	
	public String getScoreJSON() {
		return scoreJSON;
	}

	public ParticipantStudySite withScoreJSON(String scoresJSON) {
		this.scoreJSON = scoresJSON;
		return this;
	}

	public String getNotes() {
		return notes;
	}
	
	public ParticipantStudySite withNotes(String notes) {
		this.notes = notes;
		return this;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}
	
	
}
