package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.avigosolutions.participantservice.audit.Auditable;
import com.avigosolutions.participantservice.audit.EntityListener;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "ParticipantStudySiteHistory")
public class ParticipantStudySiteHistory implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -260217898331264807L;

	@Id
	@GeneratedValue
	@Column(name = "ParticipantStudySiteHistoryId", nullable = false)
	private long participantStudySiteHistoryId;

	@Column(name = "ParticipantId", nullable = false)
	private String participantId;

	@Column(name = "TrialId")
	private long trialId;

	@Column(name = "StudySiteId", nullable = true)
	private Long studySiteId;

	@Column(name = "ParticipantStatusId")
	private long participantStatusId;

	@Column(name = "StatusNotes")
	private String statusNotes;

	@Column(name = "Notes",columnDefinition="nvarchar")
	private String notes;
	
	@Column(name = "CreatedOn")
	private Date createdOn;

	@Column(name = "UpdatedOn")
	private Date updatedOn;
	
	@Column(name = "CreatedBy")
	private Long createdBy;

	@Column(name = "UpdatedBy")
	private Long updatedBy;

	@ManyToOne
	@JoinColumn(name = "ParticipantId", referencedColumnName = "ParticipantId", insertable = false, updatable = false)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private Participant participant;

	@OneToOne
	@JoinColumn(name = "ParticipantStatusId", insertable = false, updatable = false)
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private ParticipantStatus participantStatus;

	public long getParticipantStudySiteHistoryId() {
		return participantStudySiteHistoryId;
	}

	public ParticipantStudySiteHistory withParticipantStudySiteHistoryId(long participantStudySiteHistoryId) {
		this.participantStudySiteHistoryId = participantStudySiteHistoryId;
		return this;
	}

	public ParticipantStudySiteHistory withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public ParticipantStudySiteHistory withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public ParticipantStudySiteHistory withStudySiteId(long studySiteId) {
		this.studySiteId = studySiteId;
		return this;
	}

	public String getParticipantId() {
		return participantId;
	}

	public long getTrialId() {
		return trialId;
	}

	public long getStudySiteId() {
		return studySiteId;
	}

	public ParticipantStudySiteHistory withParticipantStatusId(long participantStatusId) {
		this.participantStatusId = participantStatusId;
		return this;
	}

	public long getParticipantStatusId() {
		return participantStatusId;
	}

	public ParticipantStatus getParticipantStatus() {
		return participantStatus;
	}

	public ParticipantStudySiteHistory withParticipantStatus(ParticipantStatus participantStatus) {
		this.participantStatus = participantStatus;
		return this;
	}

	public Participant getParticipant() {
		return participant;
	}

	public ParticipantStudySiteHistory withParticipant(Participant participant) {
		this.participant = participant;
		return this;
	}

	@PrePersist
	protected void onCreate() {
		if (createdOn == null) {
			this.createdOn = new Date();
			this.updatedOn = new Date();
		}
	}

	@PreUpdate
	protected void onUpdate() {
		this.updatedOn = new Date();
	}

	public ParticipantStudySiteHistory withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public ParticipantStudySiteHistory withUpdatedOn(Date updatedOn) {
		this.updatedOn = Optional.ofNullable(updatedOn).orElse(new Date());
		return this;
	}

	public String getStatusNotes() {
		return statusNotes;
	}

	public ParticipantStudySiteHistory withStatusNotes(String statusNotes) {
		this.statusNotes = statusNotes;
		return this;
	}

	public String getNotes() {
		return notes;
	}

	public ParticipantStudySiteHistory withNotes(String notes) {
		this.notes = notes;
		return this;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((participantId == null) ? 0 : participantId.hashCode());
		result = prime * result + (int) (trialId ^ (trialId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ParticipantStudySiteHistory other = (ParticipantStudySiteHistory) obj;
		if (participantId == null) {
			if (other.participantId != null)
				return false;
		} else if (!participantId.equals(other.participantId))
			return false;
		if (trialId != other.trialId)
			return false;
		return true;
	}

	public Date getCreatedOn() {		
		return this.createdOn;
	}
	
	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Long updatedBy) {
		this.updatedBy = updatedBy;
	}
}
