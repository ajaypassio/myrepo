package com.avigosolutions.participantservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="ParticipantTrial")
public class ParticipantTrial {
		
	@Id
	@GeneratedValue
	@Column(name = "ParticipantTrialId", nullable = false)
	private long participantTrialId;
	
	@Column(name = "ParticipantId", nullable = false)
	private String participantId;

	public String getParticipantId() {
		return this.participantId;
	}

	public ParticipantTrial withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}
	
	@Column(name = "TrialId")
	private long trialId;
	
	public ParticipantTrial withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}
	
	public long getTrialId() {
		return trialId;
	}
	
	@Column(name = "ParticipantTrialStatus")
	private Boolean participantTrialStatus;
	
	public ParticipantTrial withParticipantTrialStatus(Boolean participantTrialStatus) {
		this.participantTrialStatus = participantTrialStatus;
		return this;
	}
	
	public Boolean getparticipantTrialStatus() {
		return participantTrialStatus;
	}
}
