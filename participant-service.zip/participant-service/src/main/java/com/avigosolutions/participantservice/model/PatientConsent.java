package com.avigosolutions.participantservice.model;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "PatientConsent" )
public class PatientConsent  implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 5676038671407448757L;

  @Id @GeneratedValue(generator="uuid2")
  @GenericGenerator(name="uuid2",
  strategy = "uuid2") 
	@Column(name = "TempPatientId", nullable = false)
	private String tempPatientId;

	@Column(name = "FirstName", nullable = false)
	private String firstName;	

	@Column(name = "MiddleName", nullable = true)
	private String middleName;	
	
	@Column(name = "LastName", nullable = false)
	private String lastName;
	
	@Column(name = "EmailAddress", nullable = true)
	private String emailAddress;
	
	@Column(name = "PatientId", nullable = true)
	private String patientId;
	
	@Column(name = "ParticipantId", nullable = true)
	private String participantId;
	
	@Column(name = "QuestionnaireId", nullable = false)
	private String questionnaireId;
	
	@Column(name = "TrialId", nullable = false)
	private Long trialId;
	
	@Column(name = "ConsentOn", nullable = true)
	private Date consentOn;
	
	@Column(name = "CreatedBy", nullable = true)
	private String createdBy;
	
	@Column(name = "CreatedOn", nullable = true)
	private Date createdOn;
	
	@Column(name = "UpdatedBy", nullable = true)
	private String updatedBy;
	
	@Column(name = "UpdatedOn", nullable = true)
	private Date updatedOn;
	
	@Column(name = "TokenRequest", nullable = true)
	private boolean tokenRequest;

	@Transient
	private String encryptedTempPatientId;
	
	


	public String getTempPatientId() {
		return tempPatientId;
	}

	public void setTempPatientId(String tempPatientId) {
		this.tempPatientId = tempPatientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getParticipantId() {
		return participantId;
	}

	public void setParticipantId(String participantId) {
		this.participantId = participantId;
	}

	public String getQuestionnaireId() {
		return questionnaireId;
	}

	public void setQuestionnaireId(String questionnaireId) {
		this.questionnaireId = questionnaireId;
	}

	public Long getTrialId() {
		return trialId;
	}

	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	public Date getConsentOn() {
		return consentOn;
	}

	public void setConsentOn(Date consentOn) {
		this.consentOn = consentOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
	

	public String getEncryptedTempPatientId() {
		return encryptedTempPatientId;
	}

	public void setEncryptedTempPatientId(String encryptedTempPatientId) {
		this.encryptedTempPatientId = encryptedTempPatientId;
	}
	
	public boolean isTokenRequest() {
		return tokenRequest;
	}

	public void setTokenRequest(boolean tokenRequest) {
		this.tokenRequest = tokenRequest;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	@Override
	public String toString() {
		return "PatientConsent [tempPatientId=" + tempPatientId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailAddress=" + emailAddress + ", patientId=" + patientId + ", participantId=" + participantId
				+ ", questionnaireId=" + questionnaireId + ", trialId=" + trialId + ", consentOn=" + consentOn
				+ ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedBy=" + updatedBy + ", updatedOn="
				+ updatedOn + ", encryptedTempPatientId=" + encryptedTempPatientId + "]";
	}

	

	
	
}
