package com.avigosolutions.participantservice.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "TrialParticipantStatusAudit")
public class TrialParticipantStatusAudit {

	@Id
	@GeneratedValue
	@Column(name = "auditId", nullable = false)
	private long auditId;

	@Column(name = "ParticipantId", nullable = false)
	private String participantId;

	@Column(name = "TrialId")
	private long trialId;

	@Column(name = "fromStatusId")
	private long fromStatusId;

	@Column(name = "toStatusId")
	private long toStatusId;

	@Column(name = "CreatedOn")
	private Date createdOn;

	@PrePersist
	protected void onCreate() {
		if (createdOn == null) {
			createdOn = new Date();
		}
	}

	public TrialParticipantStatusAudit withParticipantId(String participantId) {
		this.participantId = participantId;
		return this;
	}

	public TrialParticipantStatusAudit withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public String getParticipantId() {
		return participantId;
	}

	public long getTrialId() {
		return trialId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public TrialParticipantStatusAudit withCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
		return this;
	}

	public long getFromStatusId() {
		return fromStatusId;
	}

	public TrialParticipantStatusAudit withFromStatusId(long fromStatusId) {
		this.fromStatusId = fromStatusId;
		return this;
	}

	public long getToStatusId() {
		return toStatusId;
	}

	public TrialParticipantStatusAudit withToStatusId(long toStatusId) {
		this.toStatusId = toStatusId;
		return this;
	}
	
	public long getAuditId() {
		return this.auditId;
	}
}
