package com.avigosolutions.participantservice.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "TrialStatusAudit")
public class TrialStatusAudit {

	@Id
	@GeneratedValue
	@Column(name = "auditId", nullable = false)
	private long auditId;

	@Column(name = "TrialId")
	private long trialId;

	@Column(name = "fromStatusId")
	private long fromStatusId;
	
	@Transient
	private String fromStatus;

	@Column(name = "toStatusId")
	private long toStatusId;
	
	@Transient
	private String toStatus;

	@Column(name = "minTime")
	private long minTime;
	@Column(name = "maxtime")
	private long maxtime;
	@Column(name = "totalTime")
	private long totalTime;
	@Column(name = "participantCount")
	private long participantCount;

	@Column(name = "UpdatedOn")
	private Date updatedOn;

	@PrePersist
	protected void onCreate() {
		if (updatedOn == null) {
			updatedOn = new Date();
		}
	}

	@PreUpdate
	protected void onUpdate() {
		updatedOn = new Date();
	}

	public TrialStatusAudit withTrialId(long trialId) {
		this.trialId = trialId;
		return this;
	}

	public long getTrialId() {
		return trialId;
	}

	public long getFromStatusId() {
		return fromStatusId;
	}

	public TrialStatusAudit withFromStatusId(long fromStatusId) {
		this.fromStatusId = fromStatusId;
		return this;
	}

	public long getToStatusId() {
		return toStatusId;
	}

	public TrialStatusAudit withToStatusId(long toStatusId) {
		this.toStatusId = toStatusId;
		return this;
	}

	public long getMinTime() {
		return minTime;
	}

	public TrialStatusAudit withMinTime(long minTime) {
		this.minTime = minTime;
		return this;
	}

	public long getMaxtime() {
		return maxtime;
	}

	public TrialStatusAudit withMaxtime(long maxtime) {
		this.maxtime = maxtime;
		return this;
	}

	public long getTotalTime() {
		return totalTime;
	}

	public TrialStatusAudit withTotalTime(long totalTime) {
		this.totalTime = totalTime;
		return this;
	}

	public long getParticipantCount() {
		return participantCount;
	}

	public TrialStatusAudit withParticipantCount(long participantCount) {
		this.participantCount = participantCount;
		return this;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public TrialStatusAudit setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
		return this;
	}
	
	public String getFromStatus() {
		return fromStatus;
	}

	public TrialStatusAudit withFromStatus(String fromStatus) {
		this.fromStatus = fromStatus;
		return this;
	}

	public String getToStatus() {
		return toStatus;
	}

	public TrialStatusAudit setToStatus(String toStatus) {
		this.toStatus = toStatus;
		return this;
	}
	
	public long getAuditId() {
		return this.auditId;
	}
}
