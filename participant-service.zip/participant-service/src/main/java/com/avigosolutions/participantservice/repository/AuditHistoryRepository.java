package com.avigosolutions.participantservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.AuditHistory;

@Repository
public interface AuditHistoryRepository extends JpaRepository<AuditHistory, Integer> {
	
	
}