package com.avigosolutions.participantservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantAppointment;

@Repository
public interface ParticipantAppointmentRepository extends JpaRepository<ParticipantAppointment,Long>{
	
	public ParticipantAppointment findByParticipantIdAndTrialId(String participantId, Long trialId);

}
