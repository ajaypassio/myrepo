package com.avigosolutions.participantservice.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
import com.avigosolutions.participantservice.request.model.SearchCriteria;

@Repository
public class ParticipantCustomRepository {
	
	  @PersistenceContext
	  private EntityManager em;
	  
	  public List<Participant> crietiaSearch(Long trialId, Long studySiteId, ParticipantRequestFilterModel participantRequest) {
		  
		  List<Participant> participantList = null;
		  
		  CriteriaBuilder cb = em.getCriteriaBuilder();
		  
		  CriteriaQuery<Participant> query = cb.createQuery(Participant.class);
		  Root<ParticipantStudySite> participantService = query.from(ParticipantStudySite.class);
		  Join<ParticipantStudySite, Participant> participant = participantService.join("Participant",JoinType.LEFT);
		  
		  query.select(participant).where(cb.equal(participantService.get("TrialId"), "4"));
		  query.select(participant).where(cb.equal(participantService.get("StudySiteId"), "4"));
		  
		  //Root root = query.from(Participant.class);
		  // Predicate predicate = builder.conjunction();
		  
		  /*for (SearchCriteria param : params) {
			  
			  if (param.getOperation().equalsIgnoreCase("in")) {
	            	String[] tmpArr =  param.getKey().split("\\.");
	            	if(tmpArr.length > 1) {
	            		Path<Integer> addressId = root.get(tmpArr[0]).get(tmpArr[1]);
	                	In<Integer> inIds = entityManager.getCriteriaBuilder().in(addressId);	
	                	for (int id : (List<Integer>)param.getValue()) {
	                	    inIds.value(id);
	                	}
	                	predicate = builder.and(predicate,inIds);
	            	}
	            } else if (param.getOperation().equalsIgnoreCase("=")) {
	                predicate = builder.and(predicate, 
	                  builder.equal(root.get(param.getKey()), 
	                  param.getValue().toString()));
	            } 
		  }
		  query.where(predicate);
		  
		  participantList = entityManager.createQuery(query).getResultList();*/
		  
		  participantList = em.createQuery(query).getResultList();
		  return participantList;
		  
	  }

}
