package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantJob;

@Repository
public interface ParticipantJobRepository extends JpaRepository<ParticipantJob, Long>, JpaSpecificationExecutor<ParticipantJob>{

	public ParticipantJob findByCorrelationIdEquals(String correlationId);
	public ParticipantJob findByCorrelationIdEqualsAndIsContactsPushed(String correlationId,Integer isContactsPushed);
	public List<ParticipantJob> findByIsCategoryCreatedAndSavedSearchNameAndTrialId(Integer isCategoryCreated,String savedSearchName,Long trialId);
	public ParticipantJob findByCorrelationIdAndSavedSearchNameAndTrialId(String correlationId , String savedSearchName,Long trialId);
	public List<ParticipantJob> findByIsCategoryCreated(Integer isCategoryCreated);
	public List<ParticipantJob> findByIsContactsPushed(Integer isContactsPushed);
	public List<ParticipantJob> findByIsCategoryCreatedOrIsContactsPushed(Integer isCategoryCreated,Integer isContactsPushed);
	public List<ParticipantJob> findBySavedSearchNameNotLikeAndIsContactsPushed(String savedSearchNamePrefix,Integer isContactsPushed);
	public List<ParticipantJob> findBySavedSearchNameLike(String savedSearchNamePrefix);
	public List<ParticipantJob> findBySavedSearchNameNotLikeAndIsContactsPushedAndIsDisabled(String savedSearchNamePrefix,Integer isContactsPushed, Integer isDisabled);

}
