package com.avigosolutions.participantservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantQuestion;

@Repository
public interface ParticipantQuestionRepository extends JpaRepository<ParticipantQuestion,Long> {
	public ParticipantQuestion findByParticipantIdAndQuestionId(String participantId, long questionId);
	
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE ParticipantQuestion participantQ SET participantQ.participantId=:newParticipantid  WHERE participantQ.participantId=:oldParticipantId")
	public void updateParticipantId(@Param("oldParticipantId") String oldParticipantId,@Param("newParticipantid") String newParticipantid);
	
}
