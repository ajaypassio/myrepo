package com.avigosolutions.participantservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
@Repository
public interface ParticipantQuestionnaireRepository extends JpaRepository<ParticipantQuestionnaire,Long>{
	@Query("select p from ParticipantQuestionnaire p where p.participantId =:participantId and p.questionnaireId=:questionnaireId")
	public  ParticipantQuestionnaire findTop1ByparticipantIdByquestionnaireId(@Param("participantId")String participantId, @Param("questionnaireId")long questionnaireId);
	
	@Query("select p from ParticipantQuestionnaire p where p.participantId =:participantId and p.questionnaireId=:questionnaireId")
	public  Optional<ParticipantQuestionnaire> findTop1ByparticipantIdByquestionnaireIdWithOptional(@Param("participantId")String participantId, @Param("questionnaireId")long questionnaireId);
	
	
	public List<ParticipantQuestionnaire> findByparticipantId(String participantId);
	
	@Query("SELECT p FROM ParticipantQuestionnaire p,ParticipantStudySite ps WHERE p.participantId = ps.participantId AND ps.trialId =:trialId AND ps.studySiteId =:studySiteId and (p.studySite<>'' or p.studySite is not null)")
	public List<ParticipantQuestionnaire> findParticipantsByTrialIdAndStudySiteId(@Param("trialId")Long trialId, @Param("studySiteId") Long studySiteId);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE ParticipantQuestionnaire participantQ SET participantQ.participantId=:newParticipantid  WHERE participantQ.participantId=:oldParticipantId")
	public void updateParticipantId(@Param("oldParticipantId") String oldParticipantId,@Param("newParticipantid") String newParticipantid);

}
