package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantStudySite;

@Repository
public interface ParticipantRepository extends JpaRepository<Participant, Long>,JpaSpecificationExecutor<Participant> {

	Participant findByParticipantId(String participantId);

	@Query(value = "select p.* from participant p,participantstudysite ps where p.participantid = ps.participantid " 
			+ "and ps.trialid =:trialId and ps.studysiteid =:studySiteId and "
			+ "((p.firstname = :participantName or :participantName is null or :participantName = '') "
			+ "or (p.lastname = :participantName or :participantName is null or :participantName = '')) "
			+ "limit :start, :pageSize", nativeQuery = true)
	public List<Participant> findParticipantsByTrialIdAndStudySiteId(@Param("trialId") Long trialId, 
			@Param("studySiteId") Long studySiteId, @Param("participantName") String participantName,
			@Param("start") int start, @Param("pageSize") int pageSize);
	
	@Query(value = "select p.* from participant p,participantstudysite ps where p.participantid = ps.participantid " 
			+ "and ps.trialid =:trialId and ps.studysiteid =:studySiteId  "
			+ "limit :start, :pageSize", nativeQuery = true)
	public List<Participant> findParticipantsByTrialIdAndStudySiteId(@Param("trialId") Long trialId, 
			@Param("studySiteId") Long studySiteId,@Param("start") int start, @Param("pageSize") int pageSize);
	@Query(value = "select p.* from participant p,participantstudysite ps where p.participantid = ps.participantid "
			+ "and ps.trialid =:trialId and ps.studysiteid =:studySiteId and "
			+ "((p.firstname = :participantName or :participantName is null or :participantName = '') "
			+ "or (p.lastname = :participantName or :participantName is null or :participantName = '') "
			+ "ps.participantstatusid in (:statusIds)) limit :start, :pageSize", nativeQuery = true)
	public List<Participant> findParticipantsByTrialIdAndStudySiteIdWithStatusFilter(@Param("trialId") Long trialId, 
			@Param("studySiteId") Long studySiteId, @Param("participantName") String participantName,
			@Param("statusIds") List<Integer> statusIds, @Param("start") int start, @Param("pageSize") int pageSize);

	@Query(value = "select p.* from participant p,participantstudysite ps where p.participantid = ps.participantid "
			+ "and ps.trialid =:trialId and ps.studysiteid =:studySiteId and "
			+ "((p.firstname = :participantName or :participantName is null or :participantName = '') "
			+ "or (p.lastname = :participantName or :participantName is null or :participantName = '') "
			+ "p.gender in (:gender)) limit :start, :pageSize", nativeQuery = true)
	public List<Participant> findParticipantsByTrialIdAndStudySiteIdWithGenderFilter(@Param("trialId") Long trialId, 
			@Param("studySiteId") Long studySiteId, @Param("participantName") String participantName,
			@Param("gender") List<String> gender, @Param("start") int start, @Param("pageSize") int pageSize);

	
}
