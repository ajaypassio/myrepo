package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantStatus;

@Repository
public interface ParticipantStatusRepository extends JpaRepository<ParticipantStatus,Long>{
	
	public List<ParticipantStatus> findAll();
	
	public ParticipantStatus findById(Long ParticipantStatusId);
	
	public ParticipantStatus findByParticipantStatusName(String participantStatusName);
	

}
