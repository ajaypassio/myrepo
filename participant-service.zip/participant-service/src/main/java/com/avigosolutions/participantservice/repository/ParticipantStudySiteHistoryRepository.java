package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantStudySiteHistory;

@Repository
public interface ParticipantStudySiteHistoryRepository extends JpaRepository<ParticipantStudySiteHistory, Long> {

	public Page<ParticipantStudySiteHistory> findByParticipantIdAndTrialIdAndStudySiteId(String participantId, Long trialId,
			Long studySiteId,Pageable page);
	
	@Query(value = "select min(createdon) as first_date, max(updatedon) as last_date ,participantstatusid from participantstudysitehistory where trialId =:trialId and participantstatusid in(select participantstatusid from participantstatus where ParticipantStatusName in('Interested','Enrolled')) group by participantstatusid", nativeQuery = true)
	public List<Object[]> findFirstAndLastPatientDate(@Param("trialId") Long trialId);
}