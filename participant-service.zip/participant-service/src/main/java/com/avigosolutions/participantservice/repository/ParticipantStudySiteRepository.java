package com.avigosolutions.participantservice.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.dto.CountModel;
import com.avigosolutions.participantservice.dto.ParticipantStudySiteStatistics;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.response.model.DateModel;

@Repository
//@PersistenceContext
public interface ParticipantStudySiteRepository
		extends JpaRepository<ParticipantStudySite, Long>, JpaSpecificationExecutor<ParticipantStudySite> {
	   //Injected by the entity manager to perform persistence operations
	
	  //  EntityManager entityManager;
	  
	public ParticipantStudySite findByParticipantStudySiteId(Long participantStudySiteId);

	public ParticipantStudySite findByParticipantId(String participantId);

	
	public ParticipantStudySite findByParticipantIdAndTrialId(String participantId, Long trialId);

	public ParticipantStudySite findByParticipantIdAndTrialIdAndStudySiteId(String participantId, Long trialId,
			Long studySiteId);

	public List<ParticipantStudySite> findByParticipantIdInAndTrialIdAndStudySiteId(List<String> participantId,
			Long trialId, Long studySiteId);

	public List<ParticipantStudySite> findParticipantByStudySiteId(Long studySiteId);

	public Long countByTrialId(long trialId);

	@Query(value = "select count(*) as count,studysiteid,ParticipantStatusId as id from participantstudysite where studysiteid in(:studySiteId) and trialid=:trialId  and ParticipantStatusId in(:participantStatusId) group by studysiteid, participantstatusid", nativeQuery = true)
	public List<Object[]> countByParticipantStatusIdAndStudySiteIdInAndTrialId(
			@Param("participantStatusId") List<Long> participantStatusId, @Param("studySiteId") List<Long> studySiteId,
			@Param("trialId") Long trialId);

	@Query(value = "select count(*) as count,studysiteid,ParticipantStatusId as id from participantstudysite where  trialid=:trialId  and ParticipantStatusId in(:participantStatusId) group by studysiteid, participantstatusid", nativeQuery = true)
	public List<Object[]> countByParticipantStatusIdAndTrialId(
			@Param("participantStatusId") List<Long> participantStatusId, @Param("trialId") Long trialId);

	@Query(value = "select count(*) as count,studySiteId,participantStatusId from ParticipantStudySite pss "
			+ "where  pss.trialId=:trialId  and pss.participantStatusId in(:participantStatusId) and pss.studySiteId is not null "
			+ "group by pss.studySiteId, participantStatusId")
	public List<Object[]> participantCountByParticipantStatusIdAndTrialIdAndNotNullStudySite(
			@Param("participantStatusId") List<Long> participantStatusId, @Param("trialId") Long trialId);

	@Query(value = "select count(*) as count,trialid,ParticipantStatusId as id from participantstudysite where  trialid in(:trialId)  and ParticipantStatusId in(:participantStatusId) group by trialid, participantstatusid", nativeQuery = true)
	public List<Object[]> countByTrialIdParticipantStatusId(
			@Param("participantStatusId") List<Long> participantStatusId, @Param("trialId") List<Long> trialId);

//	public List<ParticipantStudySite> findByParticipantFirstName(String firstName);

	// By study site id and trail id
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteId(Long trialId, Long studySiteId, Pageable page);

	// By study site id and trail id gender
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantGenderIn(Long trialId, Long studySiteId,
			List<String> gender, Pageable page);

	// By study site id and trail id and participant name
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantFirstNameContainingOrParticipantLastNameContaining(
			Long trialId, Long studySiteId, String firstName, String lastName, Pageable page);

	// by study site id and trail id and cities
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantCityIn(Long trialId, Long studySiteId,
			List<String> cities, Pageable page);

	// by study site id and trail id and states
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantStateIn(Long trialId, Long studySiteId,
			List<String> states, Pageable page);

	// by study site id and trail id and zip code
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantZipCode(Long trialId, Long studySiteId,
			String zipcode, Pageable page);

	// by study site id and trail id and participantIds
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantIdIn(Long trialId, Long studySiteId,
			List<String> participantIds, Pageable page);

	// by study site id and trail id and statusIds
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantStatusIdIn(Long trialId,
			Long studySiteId, List<Long> statusIds, Pageable page);

	// by study site id and trail id and statusIds
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStatusIdIn(Long trialId, Long studySiteId,
			List<Long> statusIds, Pageable page);

	// by all required conditions - AND
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantStateInAndParticipantCityInAndParticipantFirstNameContainingOrParticipantLastNameContaining(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			Pageable page);

	// by all required conditions - OR
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantZipCodeOrParticipantStatusIdInOrParticipantIdIn(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			List<String> gender, String zipcode, List<Long> statusIds, List<String> participantIds, Pageable page);

	// by all required conditions - OR with age filter
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantZipCodeOrParticipantStatusIdInOrParticipantIdInOrParticipantDobBetween(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			List<String> gender, String zipcode, List<Long> statusIds, List<String> participantIds, Date ageStart,
			Date ageEnd, Pageable page);

	// by all required conditions - no zipcode
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantStatusIdInOrParticipantIdIn(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			List<String> gender, List<Long> statusIds, List<String> participantIds, Pageable page);

	// by all required conditions - no zipcode with age filter
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantStatusIdInOrParticipantIdInOrParticipantDobBetween(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			List<String> gender, List<Long> statusIds, List<String> participantIds, Date ageStart, Date ageEnd,
			Pageable page);

	// by all required conditions - no zipcode, no statusIds
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantIdIn(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			List<String> gender, List<String> participantIds, Pageable page);

	// by all required conditions - no zipcode, no statusIds, no participantIds
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderIn(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			List<String> gender, Pageable page);

	// by all required conditions - no zipcode, no statusIds, no participantIds, no
	// gender
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContaining(
			Long trialId, Long studySiteId, List<String> states, List<String> cities, String firstName, String lastName,
			Pageable page);

	public Page<ParticipantStudySite> findByParticipantCityAndParticipantState(String city, String state,
			Pageable page);

	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantCityAndParticipantState(Long trialId,
			Long studySiteId, List<String> city, List<String> state, Pageable page);

	public Page<ParticipantStudySite> findByParticipantDobBetween(Date date1, Date date2, Pageable page);

	@Query(value = "select min(createdon) as first_date, max(updatedon) as last_date ,participantstatusid from participantstudysite where trialId =:trialId and participantstatusid in(select participantstatusid from participantstatus where ParticipantStatusName in('Interested','Enrolled')) group by participantstatusid", nativeQuery = true)
	public List<Object[]> findFirstAndLastPatientDate(@Param("trialId") Long trialId);

	public long countByTrialIdAndParticipantStatusId(Long trialId, Long participantStatusId);

	@Query(value = "SELECT "
			+ "    new com.avigosolutions.participantservice.dto.ParticipantStudySiteStatistics(v.participantStatusId, count(v)) "
			+ "FROM " + "    ParticipantStudySite v WHERE v.studySiteId =:studySiteId AND v.trialId =:trialId "
			+ " GROUP BY " + "    v.participantStatusId")
	public List<ParticipantStudySiteStatistics> findParticipantStudySiteCountByTrialIdAndStudySiteId(
			@Param("trialId") Long trialId, @Param("studySiteId") Long studySiteId);

	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantStateAndParticipantStateNotNull(Long trialId, Long studySiteId,
			String state, Pageable page);

	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantStateAndParticipantCity(Long trialId,
			Long studySiteId, String state, String city, Pageable page);
	public Page<ParticipantStudySite> findByTrialIdAndStudySiteIdAndParticipantStateInAndParticipantCityAndParticipantCityNotNull(Long trialId,
			Long studySiteId, List<String> states, String city, Pageable page);
	
	@Query("select p from ParticipantStudySite p where p.participantId =:participantId")
	public Optional<ParticipantStudySite> findByTempParticipantId(String participantId);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE ParticipantStudySite participantQ SET participantQ.participantId=:newParticipantid  WHERE participantQ.participantId=:oldParticipantId")
	public void updateParticipantId(@Param("oldParticipantId") String oldParticipantId,@Param("newParticipantid") String newParticipantid);
	
	/*
	 * public ParticipantStudySite findByParticipantId(String participantId, Long
	 * trialId){ String
	 * sql="select * from ParticipantStudySite_T_"+trialId.toString()+
	 * "where participantId = :participantId and trialId = :trialId";
	 * javax.persistence.Query query = entityManager.createNativeQuery(sql);
	 * query.setParameter(1, participantId); ParticipantStudySite
	 * participantStudySite = (ParticipantStudySite) query.getSingleResult(); return
	 * participantStudySite; }
	 */

}
