package com.avigosolutions.participantservice.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.dto.CountModel;
import com.avigosolutions.participantservice.dto.ParticipantStudySiteStatistics;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.ParticipantStudySiteForSiteCordinator;
import com.avigosolutions.participantservice.response.model.DateModel;

@Repository
public interface ParticipantStudySiteRepositoryForSiteCordinator
		extends JpaRepository<ParticipantStudySiteForSiteCordinator, Long>, JpaSpecificationExecutor<ParticipantStudySiteForSiteCordinator> {}
