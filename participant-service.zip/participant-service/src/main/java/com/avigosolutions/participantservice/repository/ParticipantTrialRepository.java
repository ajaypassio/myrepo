package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.ParticipantTrial;


@Repository
public interface ParticipantTrialRepository extends JpaRepository<ParticipantTrial,Long>{
	
	public List<ParticipantTrial> findByParticipantId(String participantId);
	
	public ParticipantTrial findByParticipantIdAndTrialId(String participantId, Long trialId);


}
