package com.avigosolutions.participantservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.PatientConsent;

@Repository
public interface PatientConsentRepository extends JpaRepository<PatientConsent, Long>{

	PatientConsent findByTempPatientId(String participantId);

}
