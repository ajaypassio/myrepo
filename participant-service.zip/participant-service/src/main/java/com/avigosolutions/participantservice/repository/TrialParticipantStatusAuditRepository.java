package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.TrialParticipantStatusAudit;

@Repository
public interface TrialParticipantStatusAuditRepository extends JpaRepository<TrialParticipantStatusAudit, Long> {

	public List<TrialParticipantStatusAudit> findByParticipantIdAndTrialId(String participantId, Long trialId);

	public List<TrialParticipantStatusAudit> findByParticipantIdAndTrialIdAndFromStatusIdAndToStatusId(String participantId,
			Long trialId, long fromStatusId, long toStatusId);

}
