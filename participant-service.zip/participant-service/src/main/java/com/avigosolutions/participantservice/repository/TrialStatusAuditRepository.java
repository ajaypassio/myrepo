package com.avigosolutions.participantservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.participantservice.model.TrialStatusAudit;

@Repository
public interface TrialStatusAuditRepository extends JpaRepository<TrialStatusAudit, Long> {

	public List<TrialStatusAudit> findByTrialId(long trialId);
	
	public List<TrialStatusAudit> findByTrialIdIn(List<Long> trialId);

	public TrialStatusAudit findByTrialIdAndFromStatusIdAndToStatusId(long trialId, long fromStatusId, long toStatusId);

	/*
	 * Handle concurrency issues we are doing Query based update.
	 */
	@Modifying(clearAutomatically = true)
	@Query("update TrialStatusAudit trialStatusAudit set trialStatusAudit.minTime =:minTime, trialStatusAudit.maxtime =:maxtime, "
			+ "trialStatusAudit.totalTime = trialStatusAudit.totalTime + :curTime, trialStatusAudit.participantCount = trialStatusAudit.participantCount + 1 where trialStatusAudit.auditId =:auditId")
	public void updateTrialStatusAudit(@Param("auditId") Long auditId, @Param("minTime") long minTime,
			@Param("maxtime") long maxtime, @Param("curTime") long curTime);

}
