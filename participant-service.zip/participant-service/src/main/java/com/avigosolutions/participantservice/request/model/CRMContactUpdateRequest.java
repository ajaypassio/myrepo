package com.avigosolutions.participantservice.request.model;

import javax.validation.constraints.Pattern;

public class CRMContactUpdateRequest {
	
	@Pattern(regexp = "^[a-zA-Z0-9_\\-=]*$")
	private String patientId;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s_]*$")
	private String customFieldName;
	
	@Pattern(regexp = "^[a-zA-Z0-9\\s_\\-=]*$")
	private String customFieldValue;

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getCustomFieldName() {
		return customFieldName;
	}

	public void setCustomFieldName(String customFieldName) {
		this.customFieldName = customFieldName;
	}

	public String getCustomFieldValue() {
		return customFieldValue;
	}

	public void setCustomFieldValue(String customFieldValue) {
		this.customFieldValue = customFieldValue;
	}

	@Override
	public String toString() {
		return "CRMContactUpdateRequest [patientId=" + patientId + ", customFieldName=" + customFieldName
				+ ", customFieldValue=" + customFieldValue + "]";
	}

}
