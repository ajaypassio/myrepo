package com.avigosolutions.participantservice.request.model;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Pattern;

import com.avigosolutions.participantservice.validation.StringList;

public class ParticipantRequestFilterModel {

	private int start;
	
	private int pageSize;
		
	@Pattern(regexp="^[a-zA-Z0-9\\s_.,]*$")
	private String participantName;
	
	@StringList(regexp="^[a-zA-Z0-9.\\s]*$")
	private List<String> cities;
	
	@StringList(regexp="^[a-zA-Z0-9.\\s]*$")
	private List<String> states;
	
	@StringList(regexp="^[a-zA-Z0-9.\\s]*$")
	private List<String> gender;
	
	@StringList(regexp="^[a-zA-Z0-9.\\s]*$")
	private List<String> participantIds;
	
	private int ageStart;
	
	private int ageEnd;
	
	private Date fromDate;
	
	private Date toDate;
	
	private List<Long> statusIds;
	@Pattern(regexp = "^[0-9]*$")
	private String zipcode;
	
	@Pattern(regexp="^[a-zA-Z0-9\\s_]*$")
	private String columnToSort;
	
	@Pattern(regexp="^[a-zA-Z]*$")
	private String sortType;
	
	public String getParticipantName() {
		return participantName;
	}

	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}

	public List<String> getCities() {
		return cities;
	}

	public void setCities(List<String> cities) {
		this.cities = cities;
	}

	public List<String> getStates() {
		return states;
	}

	public void setStates(List<String> states) {
		this.states = states;
	}

	public List<String> getGender() {
		return gender;
	}

	public void setGender(List<String> gender) {
		this.gender = gender;
	}


	public List<Long> getStatusIds() {
		return statusIds;
	}

	public void setStatusIds(List<Long> statusIds) {
		this.statusIds = statusIds;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getPageSize() {
		return pageSize;
	}

	public String getColumnToSort() {
		return columnToSort;
	}

	public void setColumnToSort(String columnToSort) {
		this.columnToSort = columnToSort;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public List<String> getParticipantIds() {
		return participantIds;
	}

	public void setParticipantIds(List<String> participantIds) {
		this.participantIds = participantIds;
	}

	public int getAgeStart() {
		return ageStart;
	}

	public void setAgeStart(int ageStart) {
		this.ageStart = ageStart;
	}

	public int getAgeEnd() {
		return ageEnd;
	}

	public void setAgeEnd(int ageEnd) {
		this.ageEnd = ageEnd;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	
	
}
