package com.avigosolutions.participantservice.request.model;

public class ParticipantStudySiteFilterModel {

	private int start;
	
	private int pageSize;
		
	private Long trialId;
	
	private Long studySiteId;
	
	private String columnToSort;
	
	private String sortType;
	
	
	/**
	 * @return the trialId
	 */
	public Long getTrialId() {
		return trialId;
	}

	/**
	 * @param trialId the trialId to set
	 */
	public void setTrialId(Long trialId) {
		this.trialId = trialId;
	}

	/**
	 * @return the studySiteId
	 */
	public Long getStudySiteId() {
		return studySiteId;
	}

	/**
	 * @param studySiteId the studySiteId to set
	 */
	public void setStudySiteId(Long studySiteId) {
		this.studySiteId = studySiteId;
	}



	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getPageSize() {
		return pageSize;
	}

	public String getColumnToSort() {
		return columnToSort;
	}

	public void setColumnToSort(String columnToSort) {
		this.columnToSort = columnToSort;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
