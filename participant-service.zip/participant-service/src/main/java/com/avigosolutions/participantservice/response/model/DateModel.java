package com.avigosolutions.participantservice.response.model;

import java.math.BigInteger;
import java.util.Date;

public class DateModel {
	private Date firstDate;
	private Date lastDate;
	private BigInteger statusId;

	public Date getFirstDate() {
		return firstDate;
	}

	public DateModel withFirstDate(Date firstDate) {
		this.firstDate = firstDate;
		return this;
	}

	public Date getLastDate() {
		return lastDate;
	}

	public DateModel withLastDate(Date lastDate) {
		this.lastDate = lastDate;
		return this;
	}

	public BigInteger getStatusId() {
		return statusId;
	}

	public DateModel withStatusId(BigInteger statusId) {
		this.statusId = statusId;
		return this;
	}

}
