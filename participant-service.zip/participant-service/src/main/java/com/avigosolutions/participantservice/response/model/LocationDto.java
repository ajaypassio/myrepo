package com.avigosolutions.participantservice.response.model;

public class LocationDto {
	private String name;
	private String value;

	public String getValue() {
		return value;
	}

	public LocationDto withValue(String value) {
		this.value = value;
		return this;
	}

	public String getName() {
		return name;
	}

	public LocationDto withName(String name) {
		this.name = name;
		return this;
	}

}
