package com.avigosolutions.participantservice.response.model;

import java.util.List;

public class LocationResponse {
	private long total;
	private List<LocationDto> locationList;

	public long getTotal() {
		return total;
	}

	public LocationResponse withTotal(long total) {
		this.total = total;
		return this;
	}

	public List<LocationDto> getLocationList() {
		return locationList;
	}

	public LocationResponse withLocationList(List<LocationDto> locationList) {
		this.locationList = locationList;
		return this;
	}

}
