package com.avigosolutions.participantservice.response.model;

import org.springframework.stereotype.Component;

@Component
public class PatientConsentResponse {
	private int status;

	private String message;

	private String htmlString;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getHtmlString() {
		return htmlString;
	}

	public void setHtmlString(String htmlString) {
		this.htmlString = htmlString;
	}
	
	


}
