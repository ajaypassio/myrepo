package com.avigosolutions.participantservice.response.model;

import org.springframework.stereotype.Component;

@Component
public class ResponseObjectModel {
	private int status;

	private String message;

	private String authToken;

	private Object data;

	private long total;

	public int getStatus() {
		return status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public String getAuthToken() {
		return authToken;
	}

	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}

}
