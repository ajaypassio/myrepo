package com.avigosolutions.participantservice.response.model;

public class StateDto {

	private Long id;

	private String stateName;
	
	private String abbrev;
	
	private Long countryId;

	public Long getId() {
		return id;
	}

	public StateDto withId(Long id) {
		this.id = id;
		return this;
	}

	public String getStateName() {
		return stateName;
	}

	public StateDto withStateName(String stateName) {
		this.stateName = stateName;
		return this;
	}

	public String getAbbrev() {
		return abbrev;
	}

	public StateDto withAbbrev(String abbrev) {
		this.abbrev = abbrev;
		return this;
	}

	public Long getCountryId() {
		return countryId;
	}

	public StateDto withCountryId(Long countryId) {
		this.countryId = countryId;
		return this;
	}

}
