package com.avigosolutions.participantservice.service;

import java.util.List;

import com.avigosolutions.participantservice.model.ParticipantQuestion;

public interface ParticipantQuestionService {
	public ParticipantQuestion save(ParticipantQuestion participantQuestionPersited);

	public ParticipantQuestion getParticipantQuestion(Long participantQuestionId);

	ParticipantQuestion findByParticipantIdAndQuestionId(String participantId, long questionId);
}
