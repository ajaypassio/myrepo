package com.avigosolutions.participantservice.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.model.ParticipantQuestion;
import com.avigosolutions.participantservice.repository.ParticipantQuestionRepository;
@Service
@Transactional(propagation=Propagation.SUPPORTS)
public class ParticipantQuestionServiceImpl implements ParticipantQuestionService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ParticipantQuestionRepository participantQuestionRepository;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ParticipantQuestion save(ParticipantQuestion participantQuestionPersited) {
		return persist(participantQuestionPersited, false);
	}
	

	@Override
	public ParticipantQuestion getParticipantQuestion(Long participantQuestionId) {
		 return participantQuestionRepository.findOne(participantQuestionId);
	} 

	@Override
	public ParticipantQuestion findByParticipantIdAndQuestionId(String participantId, long questionId) {
		return participantQuestionRepository.findByParticipantIdAndQuestionId(participantId, questionId);
	}
	
	private ParticipantQuestion persist(ParticipantQuestion participantQuestionToBePersisted, boolean isUpdate) {
		// check
		if (participantQuestionToBePersisted != null) {

			long id = participantQuestionToBePersisted.getParticipantQuestionId();
			// if update check if it has id or if the Criteria to be updated doesn't exist
			if (isUpdate && ((participantQuestionRepository.findOne(id) == null))) {
				logger.error("Update called with null or invalid Question: " + participantQuestionToBePersisted.toString());
				return null;
			}

			return participantQuestionRepository.save(participantQuestionToBePersisted);
		}
		return null;
	}

}
