package com.avigosolutions.participantservice.service;

import java.util.List;

import com.avigosolutions.participantservice.dto.ParticipantQuestionnaireDto;
import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;

public interface ParticipantQuestionnaireService {
	
	/**
	 * Save ParicipantQuestionnaire
	 * @param participantQuestionnairePersited
	 * @return
	 */
	public ParticipantQuestionnaire save(ParticipantQuestionnaire participantQuestionnairePersited);
	
	/**
	 * Get Questionnaire by id
	 * @param participantQuestionnaireId
	 * @return
	 */
	public ParticipantQuestionnaire getParticipantQuestionnaire(Long participantQuestionnaireId);
	
	/**
	 * get participantquestionnaire by pariticipantid and id
	 * @param participantId
	 * @param QuestionnaireId
	 * @return
	 */
	public ParticipantQuestionnaire getParticipantQuestionnaireByParticipantQuestionnaireId(String participantId,long QuestionnaireId);
	
	/**
	 * Get Questionnaires by participantid
	 * @param participantId
	 * @return
	 */
	public List<ParticipantQuestionnaireDto> getParticipantQuestionnaires(String participantId);
	
	/**
	 * Get questionnaire by participantid
	 * @param participantId
	 * @return
	 */
	public List<ParticipantQuestionnaire> getParticipantQuestionnairebyParticipantId(String participantId);
	
	/**
	 * Get participants by trialid and studysiteid
	 * @param trialId
	 * @param studySiteId
	 * @return
	 */
	public List<ParticipantQuestionnaireDto> getParticipantsbyTrialIdAndStudySiteId(Long trialId, Long studySiteId);
	
	/**
	 * Create/Update ParticipantQuestionnaire
	 * @param trialId
	 * @param participantQuestionnaire
	 * @return
	 */
	public ParticipantQuestionnaire saveParticipantQuestionnaire(String trialId, ParticipantQuestionnaire participantQuestionnaire);
	
	/**
	 * Get participant Question based on participantid and questionnaireId
	 * @param participantId
	 * @param questionnaireId
	 * @return
	 */
	ParticipantQuestionnaire getParticipantQuestionnaire(String participantId, long questionnaireId, boolean isEncoded);
}