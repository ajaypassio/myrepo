package com.avigosolutions.participantservice.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.dto.ParticipantQuestionnaireDto;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantQuestion;
import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.questdiagnostics.mongo.model.ParsedQualtricsReponse;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForAdmin;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForSiteCoord;
import com.avigosolutions.participantservice.repository.ParticipantQuestionnaireRepository;
import com.avigosolutions.participantservice.repository.ParticipantStudySiteRepository;
import com.avigosolutions.participantservice.utils.EncryptionUtils;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ParticipantQuestionnaireServiceImpl implements ParticipantQuestionnaireService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private ParticipantQuestionnaireRepository participantQuestionnaireRepository;

	@Autowired
	private ParticipantStudySiteRepository participantStudySiteRepository;

	@Autowired
	private ParticipantStudySiteService participantStudySiteService;

	@Autowired
	private ParticipantService participantService;

	@Autowired
	private ParticipantStateService participantStateService;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private MongoTemplate template;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ParticipantQuestionnaire save(ParticipantQuestionnaire participantQuestionnairePersited) {
		return persist(participantQuestionnairePersited, false);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ParticipantQuestionnaire saveParticipantQuestionnaire(String trialId,
			ParticipantQuestionnaire participantQuestionnaire) {
		//participantQuestionnaire.withParticipantId(EncryptionUtils.getInstance().decryptFromBase64(participantQuestionnaire.getParticipantId()));
		trialId=EncryptionUtils.getInstance().decryptFromBase64(trialId);
		
		Participant participantRequest = participantQuestionnaire.getParticipant();
		ParticipantQuestionnaire savedParticipantQuestionnaire = new ParticipantQuestionnaire();
		Participant participant = participantService.findOne(participantQuestionnaire.getParticipantId());
		if (null != participant) {

			if (null != participantQuestionnaire.getStudySite() || !participantQuestionnaire.getStudySite().isEmpty()) {
				String tableName = "ParticipantStudySite_T_" + trialId;
				javax.persistence.Query q1 = entityManager.createNativeQuery("update  " + tableName
						+ " set StudySiteId = :1 , participantStatusId = :2 where participantId= :3 and trialId = :4");
				q1.setParameter(1, participantQuestionnaire.getStudySite());
				q1.setParameter(2, 3);
				q1.setParameter(3, participantQuestionnaire.getParticipantId());
				q1.setParameter(4, trialId);
				q1.executeUpdate();

				participant.withContactNumber(participantRequest.getContactNumber());
				participant.withEmailAddress(participantRequest.getEmailAddress());

				participant.withPreferredEmail(participantRequest.getPreferredEmail());
				participant.withPreferredMail(participantRequest.getPreferredMail());
				participant.withPreferredPhone(participantRequest.getPreferredPhone());
				participant.withVoicemail(participantRequest.getVoicemail());
				participant.withPreferredTimeOfContact(participantRequest.getPreferredTimeOfContact());

				participant.withSms(participantRequest.getSms());
				participant.withVoicemail(participantRequest.getVoicemail());
				participant.withPhoneType(participantRequest.getPhoneType());
				participant.withUpdatedOn(new Date());
				participantService.save(participant);

				Query query = new Query();
				query.addCriteria(Criteria.where("_id").is(participantQuestionnaire.getTransactionId()));
				Update update = new Update();
				ParsedQualtricsReponse savedDocument = new ParsedQualtricsReponse();
				if(null != participantQuestionnaire.getTransactionId()){
					savedDocument = template.findById(participantQuestionnaire.getTransactionId(), ParsedQualtricsReponse.class, "T_" + trialId);
				}
				//savedDocument.setSiteId(Integer.valueOf(participantQuestionnaire.getStudySite()));
				SurveyResponseInfoForAdmin surveyResponseInfoForAdmin = savedDocument.getAdminPortalInfo();

				surveyResponseInfoForAdmin.setPid(participant.getParticipantId());
				surveyResponseInfoForAdmin.setProgramName(participantQuestionnaire.getProgramName());
				surveyResponseInfoForAdmin.setTrialName(participantQuestionnaire.getTrialName());
				SurveyResponseInfoForSiteCoord surveyResponseInfoForSiteCoord = savedDocument.getSiteCoordinatorPortalInfo();
				surveyResponseInfoForSiteCoord.setEmailAddress(participant.getEmailAddress());
				surveyResponseInfoForSiteCoord.setFirstName(participant.getFirstName());
				surveyResponseInfoForSiteCoord.setLastName(participant.getLastName());
				surveyResponseInfoForSiteCoord.setMiddleName("");
				surveyResponseInfoForSiteCoord.setCity(participant.getCity());
				if (participant.getDob() != null)
					surveyResponseInfoForSiteCoord.setDOB(participant.getDob().toString());
				else
					surveyResponseInfoForSiteCoord.setDOB("");
				surveyResponseInfoForSiteCoord.setAddress(participant.getAddress());
				surveyResponseInfoForSiteCoord.setState(participant.getState());
				
				surveyResponseInfoForSiteCoord.setParticipantStatus("New");
				surveyResponseInfoForSiteCoord.setParticipantStatusId("3");
				surveyResponseInfoForSiteCoord.setTrialName(participantQuestionnaire.getTrialName());
			
				

			  surveyResponseInfoForSiteCoord.setPreferredModeOfTime(participantRequest.getPreferredTimeOfContact());
				surveyResponseInfoForSiteCoord.setPhoneNumber(participantRequest.getContactNumber());
				
				surveyResponseInfoForSiteCoord.setPreferredModeOfContact(null);
				
				if(participantRequest.getPreferredEmail()) 
				surveyResponseInfoForSiteCoord.setPreferredModeOfContact("Email");
				
				
				
				surveyResponseInfoForSiteCoord.setGender(participantRequest.getGender());
				
				if(participantRequest.getPreferredPhone() )
					surveyResponseInfoForSiteCoord.setPreferredModeOfContact(null==surveyResponseInfoForSiteCoord.getPreferredModeOfContact()?"Phone":surveyResponseInfoForSiteCoord.getPreferredModeOfContact()+" | "+"Phone");
				
				if(participantRequest.getPreferredMail() && null==surveyResponseInfoForSiteCoord.getPreferredModeOfContact())
					surveyResponseInfoForSiteCoord.setPreferredModeOfContact(null==surveyResponseInfoForSiteCoord.getPreferredModeOfContact()?"Mail":surveyResponseInfoForSiteCoord.getPreferredModeOfContact()+" | "+"Mail");
				
				
				
				surveyResponseInfoForSiteCoord.setPid(EncryptionUtils.getInstance().encryptToBase64(participantQuestionnaire.getParticipantId()));
				update.set("basicInfo", "Y");
				update.set("siteId",participantQuestionnaire.getStudySite());
				update.set("adminPortalInfo", surveyResponseInfoForAdmin);
				update.set("siteCoordinatorPortalInfo", surveyResponseInfoForSiteCoord);
				update.set("createdOn",new Date());
				update.set("updatedOn",new Date());
				template.updateFirst(query, update, "T_" + trialId);

			}

			return savedParticipantQuestionnaire;
		}
		return savedParticipantQuestionnaire;

	}

	private ParticipantStudySite saveParticipantStudySite(String participantId, Long trialId, boolean isEmailCampaign) {
		ParticipantStudySite participantStudySite = participantStudySiteService
				.findByParticipantIdAndTrialId(participantId, trialId);
		if (participantStudySite == null)
			participantStudySiteService.save(new ParticipantStudySite().withParticipantId(participantId)
					.withTrialId(trialId).withParticipantStatusId(States.IDENTIFIED.getCode()));
		if (isEmailCampaign)
			participantStateService.triggerEmailCampaign(new ParticipantTrialState(participantId, trialId), null);
		return participantStudySite;
	}

	private ParticipantQuestionnaire persist(ParticipantQuestionnaire questionToBePersisted, boolean isUpdate) {
		// check
		if (questionToBePersisted != null) {

			long id = questionToBePersisted.getParticipantQuestionnaireId();

			// if update check if it has id or if the Criteria to be updated doesn't exist
			if (isUpdate && ((participantQuestionnaireRepository.findOne(id) == null))) {
				logger.error("Update called with null or invalid Question: " + questionToBePersisted.toString());
				return null;
			}

			ParticipantQuestionnaire response = participantQuestionnaireRepository.save(questionToBePersisted);
			if (null != response && null != response.getParticipant()) {
				response.getParticipant().withInternalId(0L);
			}
			return response;
		}
		return null;
	}

	@Override
	public ParticipantQuestionnaire getParticipantQuestionnaire(Long participantQuestionnaireId) {
		ParticipantQuestionnaire result = participantQuestionnaireRepository.findOne(participantQuestionnaireId);
		if (null != result && null != result.getParticipant()) {
			result.getParticipant().withInternalId(0L);
		}
		return result;
	}

	@Override
	public ParticipantQuestionnaire getParticipantQuestionnaireByParticipantQuestionnaireId(String participantId,
			long questionnaireId) {
		// Need to work on this.
		// return null;
		ParticipantQuestionnaire result = participantQuestionnaireRepository
				.findTop1ByparticipantIdByquestionnaireId(participantId, questionnaireId);
		if (null != result && null != result.getParticipant()) {
			result.getParticipant().withInternalId(0L);
		}
		return result;
	}

	@Override
	public ParticipantQuestionnaire getParticipantQuestionnaire(String participantId, long questionnaireId,
			boolean isEncoded) {

		if (isEncoded) {
			participantId = EncryptionUtils.getInstance().decryptFromBase64(participantId);
		}
		ParticipantQuestionnaire existingOne = this
				.getParticipantQuestionnaireByParticipantQuestionnaireId(participantId, questionnaireId);

		existingOne = Optional.ofNullable(existingOne).orElse(
				new ParticipantQuestionnaire().withParticipantId(participantId).withQuestionnaireId(questionnaireId));
		existingOne = existingOne.withParticipant(Optional.ofNullable(existingOne.getParticipant())
				.orElse(this.participantService.findOne(participantId)));
		// Due to trialid not available
		// saveParticipantStudySite(participantId, trialId, false);
		if (null != participantId && !participantId.trim().isEmpty() && null != existingOne
				&& null != existingOne.getParticipant()) {
			participantQuestionnaireRepository.save(existingOne);
		}

		/*
		 * if(null != existingOne.getParticipant()) {
		 * existingOne.withParticipant(existingOne.getParticipant().withParticipantId(
		 * participantId)); } existingOne.withParticipantId(participantId);
		 */
		if (null != existingOne && null != existingOne.getParticipant()) {
			existingOne.getParticipant().withInternalId(0L);
		}

		if (null != existingOne.getParticipantQuestions()) {
			existingOne.getParticipantQuestions()
					.sort(Comparator.comparing(ParticipantQuestion::getQuestionId, Comparator.naturalOrder()));
		}

		return existingOne;
	}

	@Override
	public List<ParticipantQuestionnaireDto> getParticipantQuestionnaires(String participantId) {
		// TODO Auto-generated method stub

		List<ParticipantQuestionnaire> participantQuestionnaires = participantQuestionnaireRepository
				.findByparticipantId(participantId);
		return buildQuestionnaireDto(participantQuestionnaires);
	}

	private List<ParticipantQuestionnaireDto> buildQuestionnaireDto(
			List<ParticipantQuestionnaire> participantQuestionnaires) {

		List<ParticipantQuestionnaireDto> participantQuestionnaireDtos = new ArrayList<>();
		for (ParticipantQuestionnaire participantQuestionnaire : participantQuestionnaires) {

			ParticipantQuestionnaireDto participantQuestionnaireDto = new ParticipantQuestionnaireDto();
			participantQuestionnaireDto.setFutureTrialEmails(participantQuestionnaire.getFutureTrialEmails());
			if (participantQuestionnaire.getInterest() != null)
				participantQuestionnaireDto.setInterest(participantQuestionnaire.getInterest());
			participantQuestionnaireDto.setLastQuestionAnswered(participantQuestionnaire.getLastQuestionAnswered());
			participantQuestionnaireDto.setParticipantId(participantQuestionnaire.getParticipantId());
			participantQuestionnaireDto.setQuestEmails(participantQuestionnaire.getQuestEmails());
			participantQuestionnaireDto.setQuestionnaireId(participantQuestionnaire.getQuestionnaireId());
			participantQuestionnaireDto.setRXMedStatus(participantQuestionnaire.getRxMedStatus());
			participantQuestionnaireDto.setTrialOptStatus(participantQuestionnaire.getTrialOptStatus());
			participantQuestionnaireDto.setUserConsent(participantQuestionnaire.getUserConsent());
			participantQuestionnaireDto.setQuestionnaireId(participantQuestionnaire.getQuestionnaireId());
			participantQuestionnaireDto.setCreatedBy(participantQuestionnaire.getCreatedBy());
			if (participantQuestionnaire.getParticipant() != null) {
				participantQuestionnaireDto.setFirstName(participantQuestionnaire.getParticipant().getFirstName());
				participantQuestionnaireDto.setLastName(participantQuestionnaire.getParticipant().getLastName());
				participantQuestionnaireDto
						.setEmailAddress(participantQuestionnaire.getParticipant().getEmailAddress());
				participantQuestionnaireDto
						.setContactNumber(participantQuestionnaire.getParticipant().getContactNumber());
				participantQuestionnaireDto.setZipCode(participantQuestionnaire.getParticipant().getZipCode());

				/*
				 * participantQuestionnaireDto.setIsPerferredEmail(participantQuestionnaire.
				 * getParticipant().isIsPerferredEmail());
				 * participantQuestionnaireDto.setIsPerferredMail(participantQuestionnaire.
				 * getParticipant().isIsPerferredMail());
				 * participantQuestionnaireDto.setIsPerferredPhone(participantQuestionnaire.
				 * getParticipant().isIsPerferredPhone());
				 * participantQuestionnaireDto.setVoicemail(participantQuestionnaire.
				 * getParticipant().getVoicemail());
				 * participantQuestionnaireDto.setPreferredTimeOfContact(
				 * participantQuestionnaire.getParticipant().getPreferredTimeOfContact());
				 * participantQuestionnaireDto.withSession(participantQuestionnaire.
				 * getParticipant().getSession());
				 */
			}
			if (participantQuestionnaire.getCreatedOn() != null) {
				participantQuestionnaireDto
						.setCreatedOn(CommonUtil.convertDate(participantQuestionnaire.getCreatedOn()));
			}
			if (participantQuestionnaire.getUpdatedOn() != null) {
				participantQuestionnaireDto
						.setUpdatedOn(CommonUtil.convertDate(participantQuestionnaire.getUpdatedOn()));
			}
			if (participantQuestionnaire.getParticipant() != null) {
				participantQuestionnaireDto.setDob(participantQuestionnaire.getParticipant().getDob());
				if (participantQuestionnaire.getParticipant().getDob() != null)
					participantQuestionnaireDto.setAge(
							CommonUtil.getDiffYears(participantQuestionnaire.getParticipant().getDob(), new Date()));
				participantQuestionnaireDto.setAddress(participantQuestionnaire.getParticipant().getAddress());

				participantQuestionnaireDto.setCity(participantQuestionnaire.getParticipant().getCity());
				participantQuestionnaireDto.setState(participantQuestionnaire.getParticipant().getState());
				participantQuestionnaireDto.setGender(participantQuestionnaire.getParticipant().getGender());
				participantQuestionnaireDto.setSms(participantQuestionnaire.getParticipant().getSms());
			}
			participantQuestionnaireDtos.add(participantQuestionnaireDto);
		}

		return participantQuestionnaireDtos;
	}

	@Override
	public List<ParticipantQuestionnaire> getParticipantQuestionnairebyParticipantId(String participantId) {

		List<ParticipantQuestionnaire> pqList = participantQuestionnaireRepository.findByparticipantId(participantId);
		pqList.forEach(pq -> {
			if (null != pq.getParticipant()) {
				pq.getParticipant().withInternalId(0L);
			}
		});

		return pqList;
	}

	@Override
	public List<ParticipantQuestionnaireDto> getParticipantsbyTrialIdAndStudySiteId(Long trialId, Long studySiteId) {

		List<ParticipantQuestionnaire> participantQuestionnaireList = participantQuestionnaireRepository
				.findParticipantsByTrialIdAndStudySiteId(trialId, studySiteId);
		List<ParticipantQuestionnaireDto> participantQuestionnaireDtoList = buildQuestionnaireDto(
				participantQuestionnaireList);
		// List<Long> lstIds = lstStudySite.stream().map(f ->
		// f.getId()).collect(Collectors.toList());
		List<String> lstPariticipantIds = participantQuestionnaireList.stream().map(f -> f.getParticipantId())
				.collect(Collectors.toList());
		List<ParticipantStudySite> lstParticipantStudySite = participantStudySiteRepository
				.findByParticipantIdInAndTrialIdAndStudySiteId(lstPariticipantIds, trialId, studySiteId);
		if (null != lstParticipantStudySite && lstParticipantStudySite.size() > 0) {
			participantQuestionnaireDtoList.forEach(questionnaire -> {
				lstParticipantStudySite.forEach(studysite -> {
					if (studysite.getParticipantId().equals(questionnaire.getParticipantId())) {
						questionnaire.setStudySiteStatus(String.valueOf(studysite.getParticipantStatusId()));
					}
				});
			});
		}
		return participantQuestionnaireDtoList;
	}

	/*
	 * private String decodeParticipantId(String inputParticipantId) { String
	 * decodedParticipantId =
	 * EncryptionUtils.getInstance().decryptFromBase64(inputParticipantId);
	 * decodedParticipantId = decodedParticipantId.trim().length()>0 ?
	 * decodedParticipantId:inputParticipantId; return decodedParticipantId; }
	 * 
	 * private String encodeParticipantId(String inputParticipantId) { String
	 * encodedParticipantId =
	 * EncryptionUtils.getInstance().encryptToBase64(inputParticipantId); return
	 * encodedParticipantId; }
	 */

}
