package com.avigosolutions.participantservice.service;

import java.util.List;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.dto.ParticipantTrialInfo;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.dto.ParticipantTrialsDto;
import com.avigosolutions.participantservice.dto.ParticipantUpdate;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantStatus;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.ParticipantTrial;
import com.avigosolutions.participantservice.request.model.ParticipantStudySiteFilterModel;

public interface ParticipantService {
	public List<ParticipantTrial> findAll();

	public ParticipantTrial findone(String participantId, Long trialId);

	public List<ParticipantTrialsDto> findTrialsbyParticipantId(String participantId);

	public ParticipantTrialInfo findTrialdetails(String participantId, Long trialId);

	public ParticipantUpdate participantUpdate(ParticipantUpdate participantUpdate);

	public List<ParticipantStatus> getAllParticipantStatus();

	// public ParticipantStudySite updateParticipantStatus(String participantId,
	// Long trialId, Long studySiteId, Long statusId);

	public Participant findOne(String participantId);

	public Participant save(Participant participant);

	public List<Participant> save(List<Participant> participantList,String userId, String correlationId);

	public List<Participant> getParticipantsByStudySiteId(Long studySiteId);

	public List<Participant> getParticipantsByStudySiteIdAndTrialId(ParticipantStudySiteFilterModel filterModel);

}
