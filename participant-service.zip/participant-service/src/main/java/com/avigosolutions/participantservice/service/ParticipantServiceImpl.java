package com.avigosolutions.participantservice.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.async.service.ParticipantAsyncService;
import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.crm.service.CRMTasksService;
import com.avigosolutions.participantservice.dto.CriteriaDto;
import com.avigosolutions.participantservice.dto.ParticipantDto;
import com.avigosolutions.participantservice.dto.ParticipantTrialInfo;
import com.avigosolutions.participantservice.dto.ParticipantTrialsDto;
import com.avigosolutions.participantservice.dto.ParticipantUpdate;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantAppointment;
import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
import com.avigosolutions.participantservice.model.ParticipantStatus;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.ParticipantTrial;
import com.avigosolutions.participantservice.repository.ParticipantAppointmentRepository;
import com.avigosolutions.participantservice.repository.ParticipantCustomRepository;
import com.avigosolutions.participantservice.repository.ParticipantQuestionnaireRepository;
import com.avigosolutions.participantservice.repository.ParticipantRepository;
import com.avigosolutions.participantservice.repository.ParticipantStatusRepository;
import com.avigosolutions.participantservice.repository.ParticipantStudySiteRepository;
import com.avigosolutions.participantservice.repository.ParticipantTrialRepository;
import com.avigosolutions.participantservice.request.model.ParticipantStudySiteFilterModel;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ParticipantServiceImpl implements ParticipantService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ParticipantTrialRepository participantTrialRepository;

	@Autowired
	private ParticipantAppointmentRepository participantAppointmentRepository;

	@Autowired
	private ParticipantStudySiteRepository participantStudySiteRepository;

	@Autowired
	ParticipantQuestionnaireRepository participantQuestionnaireRepository;

	@Autowired
	ParticipantStatusRepository participantStatusRepository;

	@Autowired
	ParticipantRepository participantRepository;

	@Autowired
	ParticipantCustomRepository participantCustomRepository;

	@Autowired
	ParticipantStudySiteService participantStudySiteService;

	@Autowired
	ParticipantTrialService participantTrialService;

	@Autowired
	ParticipantStateService participantStateService;

	@Autowired
	CRMTasksService crmTasksService;

	@Autowired
	ParticipantAsyncService participantAsyncService;

	@Override
	public Participant findOne(String participantId) {
		return participantRepository.findByParticipantId(participantId);
	}

	@Override
	public Participant save(Participant participant) {
		Participant prtcpt = participantRepository.save(participant);
		ParticipantStudySite pstudysite = new ParticipantStudySite();
		if (prtcpt.getTrialId() > 0) {
			pstudysite.withParticipantId(prtcpt.getParticipantId()).withTrialId(prtcpt.getTrialId())
					.withParticipantStatusId(States.IDENTIFIED.getCode());
			participantStudySiteService.save(pstudysite);
		}
		return prtcpt;
	}

	@Override
	public List<Participant> save(List<Participant> participantList,String userId, String correlationId) {
		try {
			logger.info("<<<< Started Participant Save Async");
			participantAsyncService.CheckAndUpdateJob(correlationId, userId, participantList);
			participantAsyncService.save(participantList,userId, correlationId).get();
			//logger.info(">>>> Completed Participant Save");
		} catch (Exception e) {
			logger.error("Error occurred:", e);
			logger.info("Error ocurred while invoking async participant save:" + e.getMessage());
		}
		try {
			logger.info("<<<< Scheduled CRM task");
			crmTasksService.createCRMTasks(participantList,correlationId);
			logger.info(">>>> Scheduled Started for the CRM task");
		} catch (Exception e) {
			logger.error("Error occurred:", e);
			logger.info("Error ocurred while invoking async crm contact save:" + e.getMessage());
		}
		return participantList;
	}

	@Override
	public List<ParticipantTrial> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ParticipantTrial findone(String participantId, Long trialId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ParticipantTrialsDto> findTrialsbyParticipantId(String participantId) {
		List<ParticipantTrial> participantTrial = participantTrialRepository.findByParticipantId(participantId);
		List<ParticipantTrialsDto> participantTrialsDtos = convertParticpantTrail(participantTrial);
		return participantTrialsDtos;
	}

	private List<ParticipantTrialsDto> convertParticpantTrail(List<ParticipantTrial> participantTrialList) {

		List<ParticipantTrialsDto> participantTrialsDtos = new ArrayList<>();
		for (ParticipantTrial participantTrial : participantTrialList) {
			ParticipantTrialsDto participantTrialsDto = new ParticipantTrialsDto();

			// participantTrialsDto.setCreatedOn(participantTrial.getClinicalTrial().getCreatedOn());
			participantTrialsDto.setId(participantTrial.getTrialId());
			participantTrialsDto.setParticipantId(participantTrial.getParticipantId());
			participantTrialsDto.setParticipantTrialStatus(participantTrial.getparticipantTrialStatus());

			participantTrialsDtos.add(participantTrialsDto);
		}
		return participantTrialsDtos;
	}

	@Override
	public ParticipantTrialInfo findTrialdetails(String participantId, Long trialId) {
		ParticipantTrial participantTrial = participantTrialRepository.findByParticipantIdAndTrialId(participantId,
				trialId);
		ParticipantAppointment participantAppointment = participantAppointmentRepository
				.findByParticipantIdAndTrialId(participantId, trialId);

		List<ParticipantQuestionnaire> participantQuestionnaire = participantQuestionnaireRepository
				.findByparticipantId(participantId);
		long studySideId = 0;
		if (participantQuestionnaire != null && participantQuestionnaire.size() > 0) {
			logger.info("eneter to get");
			if (participantQuestionnaire.get(0).getStudySite() != null)
				studySideId = Long.parseLong(participantQuestionnaire.get(0).getStudySite());
			logger.debug("studySideId:" + studySideId);
		}
		ParticipantTrialInfo participantTrialInfo = buildParticipantTrail(participantTrial, participantAppointment,
				participantId, trialId);
		participantTrialInfo.setStudySiteId(studySideId);
		return participantTrialInfo;
	}

	private ParticipantTrialInfo buildParticipantTrail(ParticipantTrial participantTrial,
			ParticipantAppointment participantAppointment, String participantId, Long trialId) {

		ParticipantTrialInfo participantTrialInfo = new ParticipantTrialInfo();
		participantTrialInfo.setTrialId(trialId);
		List<CriteriaDto> criteriaDtos = new ArrayList<>();
		participantTrialInfo.setCriteria(criteriaDtos);
		if (participantAppointment != null) {
			participantTrialInfo.setId(participantAppointment.getParticipantAppointmentId());
			if (participantAppointment.getAppointmentDate() != null)
				participantTrialInfo.setNextAppointment(participantAppointment.getAppointmentDate());
		}
		return participantTrialInfo;
	}

	@Override
	public ParticipantUpdate participantUpdate(ParticipantUpdate participantUpdate) {

		ParticipantStudySite participant = participantStudySiteRepository
				.findByParticipantId(participantUpdate.getParticipantId());
		if (participant == null) {
			logger.info("Update called on an nonextistent patient id: " + participantUpdate.toString());
			participantUpdate.setStaus(false);
		} else {

			participant.withStudySiteId(participantUpdate.getStudyId());
			participantStudySiteRepository.save(participant);
			participantUpdate.setStaus(true);
			return participantUpdate;
		}
		return participantUpdate;

	}

	@Override
	public List<ParticipantStatus> getAllParticipantStatus() {

		List<ParticipantStatus> participantStatusList = participantStatusRepository.findAll();

		return participantStatusList;
	}

	/*
	 * @Override public ParticipantStudySite updateParticipantStatus(String
	 * participantId, Long trialId, Long studySiteId, Long statusId) {
	 * ParticipantStudySite participantStudySite = participantStudySiteRepository
	 * .findByParticipantIdAndTrialIdAndStudySiteId(participantId, trialId,
	 * studySiteId); if (participantStudySite != null) {
	 * participantStateService.triggerMovedToEnrolled(new
	 * ParticipantTrialState(participantId, trialId)); } return
	 * participantStudySite; }
	 */

	private List<ParticipantDto> buildParticipantDto(List<Participant> participantQuestionnaires) {

		List<ParticipantDto> participantQuestionnaireDtos = new ArrayList<>();
		for (Participant participant : participantQuestionnaires) {

			ParticipantDto participantDto = new ParticipantDto();
			participantDto.setCreatedBy(participant.getCreatedBy());
			participantDto.setParticipantId(participant.getParticipantId());
			participantDto.setFirstName(participant.getFirstName());
			participantDto.setLastName(participant.getLastName());
			participantDto.setEmailAddress(participant.getEmailAddress());
			participantDto.setContactNumber(participant.getContactNumber());
			participantDto.setZipCode(participant.getZipCode());
			// participantDto.setPreferredContactType(participant.getPreferredContactType());

			participantDto.setPreferredEmail(participant.getPreferredEmail());
			participantDto.setPreferredMail(participant.getPreferredMail());
			participantDto.setPreferredPhone(participant.getPreferredPhone());
			participantDto.setVoicemail(participant.getVoicemail());
			participantDto.setPreferredTimeOfContact(participant.getPreferredTimeOfContact());
			participantDto.setSession(participant.getSession());

			if (participant.getCreatedOn() != null) {
				participantDto.setCreatedOn(CommonUtil.convertDate(participant.getCreatedOn()));
			}
			if (participant.getUpdatedOn() != null) {
				participantDto.setUpdatedOn(CommonUtil.convertDate(participant.getUpdatedOn()));
			}
			participantDto.setDob(participant.getDob());
			if (participant.getDob() != null)
				participantDto.setAge(CommonUtil.getDiffYears(participant.getDob(), new Date()));
			participantDto.setAddress(participant.getAddress());
			participantDto.setCity(participant.getCity());
			participantDto.setState(participant.getState());
			participantDto.setGender(participant.getGender());
			participantDto.setSms(participant.getSms());
			participantQuestionnaireDtos.add(participantDto);
		}

		return participantQuestionnaireDtos;
	}

	@Override
	public List<Participant> getParticipantsByStudySiteId(Long studySiteId) {
		List<ParticipantStudySite> participantStudySites = participantStudySiteRepository
				.findParticipantByStudySiteId(studySiteId);
		logger.debug("********" + participantStudySites.size());
		List<Participant> participant = new ArrayList<>();
		for (ParticipantStudySite partcipantStudySite : participantStudySites) {
			String partId = partcipantStudySite.getParticipantId();

			Participant p = participantRepository.findByParticipantId(partId);
			/*
			 * partdto.setFirstName(p.getFirstName()); partdto.setLastName(p.getLastName());
			 */
			participant.add(p);

		}

		if (participant.size() > 0) {
			participant.forEach(part -> {
				Long id = participantStudySiteRepository.findParticipantByStudySiteId(studySiteId).stream()
						.filter(p -> p.getParticipantId().equals(part.getParticipantId())).findFirst().get()
						.getParticipantStudySiteId();
				part.withInternalId(id);
			});
		}

		return participant;
	}

	@Override
	public List<Participant> getParticipantsByStudySiteIdAndTrialId(ParticipantStudySiteFilterModel filterModel) {
		PageRequest pageRequest = CommonUtil.getPageRequest(filterModel.getStart(), filterModel.getPageSize());
		Page<Participant> p = participantRepository.findAll(filterParticipant(filterModel), pageRequest);
		List<Participant> participantList = p.getContent();
		if (null != participantList && participantList.size() > 0) {
			participantList.forEach(part -> {
				Long id = participantStudySiteRepository
						.findByParticipantIdAndTrialIdAndStudySiteId(part.getParticipantId(), filterModel.getTrialId(),
								filterModel.getStudySiteId())
						.getParticipantStudySiteId();
				part.withInternalId(id);
			});
		}

		return participantList;
	}

	private Specification<Participant> filterParticipant(ParticipantStudySiteFilterModel filterModel) {
		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			Root<ParticipantStudySite> pssRoot = query.from(ParticipantStudySite.class);

			predicates.add(cb.equal(root.get("participantId"), pssRoot.get("participantId")));

			if (null != filterModel.getTrialId() && filterModel.getTrialId() > 0) {
				predicates.add(cb.equal(pssRoot.get("trialId"), filterModel.getTrialId()));
			}
			if (null != filterModel.getStudySiteId() && filterModel.getStudySiteId() > 0) {
				predicates.add(cb.equal(pssRoot.get("studySiteId"), filterModel.getStudySiteId()));
			}
			query.orderBy(getParticipantOrder(filterModel.getColumnToSort(), filterModel.getSortType(), cb, root));
			query.distinct(true);
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private Order getParticipantOrder(String column, String sortType, CriteriaBuilder cb, Root<Participant> pRoot) {

		if ("dob".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.desc(pRoot.get("dob"));
			} else {
				return cb.asc(pRoot.get("dob"));

			}
		} else if (null != column && !column.trim().isEmpty()) {
			if (sortType.equals("asc")) {
				return cb.asc(pRoot.get(column));
			} else {
				return cb.desc(pRoot.get(column));

			}
		}

		return (cb.asc(pRoot.get("createdOn")));

	}

}