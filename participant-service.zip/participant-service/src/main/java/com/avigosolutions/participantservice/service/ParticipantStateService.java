package com.avigosolutions.participantservice.service;

import java.util.List;
import java.util.Set;

import org.springframework.http.HttpHeaders;

import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.model.ParticipantStatus;

public interface ParticipantStateService {

	States triggerEmailCampaign(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerMovedToEnrolled(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerSelectedStudySite(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerAttemptQuestion(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerSiteToContact(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerScheduledVisit(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerVisited(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerPatientRejectConsent(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerPatientAcceptConsent(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerPatientRejected(ParticipantTrialState ptState,HttpHeaders headers);

	States triggerPatientFailed(ParticipantTrialState ptState,HttpHeaders headers);

	States moveToStatus(ParticipantTrialState ptState,HttpHeaders headers);

	Set<States> getValidStates(ParticipantTrialState ptState);

	States triggerTrialCompleted(ParticipantTrialState ptState,HttpHeaders headers);

	void triggerEmailsCampaign(List<ParticipantTrialState> ptStates,HttpHeaders headers);

	void triggerEmailsCampaign(String payload,HttpHeaders headers);
	
	ParticipantStatus moveToStatusNew(ParticipantTrialState ptState,HttpHeaders headers);
}