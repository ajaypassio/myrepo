package com.avigosolutions.participantservice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.IntStream;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.Events;
import com.avigosolutions.participantservice.ParticipantStateChangeListener;
import com.avigosolutions.participantservice.ParticipantStateHandler;
import com.avigosolutions.participantservice.States;
import com.avigosolutions.participantservice.common.Constants;
import com.avigosolutions.participantservice.dto.ParticipantTrialState;
import com.avigosolutions.participantservice.model.ParticipantStatus;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.ParticipantStudySiteHistory;
import com.avigosolutions.participantservice.repository.ParticipantStatusRepository;
import com.questdiagnostics.mongo.model.ParsedQualtricsReponse;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForAdmin;
import com.questdiagnostics.mongo.model.SurveyResponseInfoForSiteCoord;
import com.avigosolutions.participantservice.utils.EncryptionUtils;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ParticipantStateServiceImpl implements ParticipantStateService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private final String CATEGORY_DELIMITER_REGEX = "-[/.]-";
	private final String CATEGORY_DELIMITER = "-.-";

	@Autowired
	private ParticipantStateHandler particpantStateHandler;

	@Autowired
	private ParticipantStateChangeListener listener;

	@Autowired
	private ParticipantStudySiteService participantStudySiteService;
	
	@Autowired
	private MongoTemplate template;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	ParticipantStatusRepository participantStatusRepository;

	@PostConstruct
	public void init() {
		particpantStateHandler.registerListener(listener);
	}

	/*
	 * Trial Campaign Starts (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerEmailCampaign(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerEmailCampaign(ParticipantTrialState ptState, HttpHeaders headers) {
		logger.info("Triggering PatientCampaign Event for Patient:"+ptState.getParticipantId().substring(0,2)+"XXXXXXXX and TrialId:"+ptState.getTrialId());
		ptState.setEvent(Events.PatientCampaign);
		return triggerStateChange(ptState, headers);
	}

	@Override
	public void triggerEmailsCampaign(String payload, HttpHeaders header) {
		logger.info("Entering ParticipantStateServiceImpl.triggerEmailsCampaign(string)");
		List<ParticipantTrialState> participantStatues = parseJSON(payload);
		triggerEmailsCampaign(participantStatues, header);
		logger.info("Exiting ParticipantStateServiceImpl.triggerEmailsCampaign(string)");
	}

	public List<ParticipantTrialState> parseJSON(String response) {
		logger.info("Parsing the JSON payload for Email Campaign");
		//logger.info("JSON Payload:" + response);
		List<ParticipantTrialState> participants = new ArrayList<>();
		DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(response);
		int count = context.read("$.recipients.length()", Integer.class);
		List<String> categoryNameList = Arrays.asList(context.read("$.campaignCategories", String.class).split(","));
		logger.info("Campaign Categories :"+categoryNameList);
		IntStream.range(0, count).forEach(x -> {
			String patientID = context.read("$.recipients[" + x + "].extId", String.class);			
			String trailID = context.read("$.recipients[" + x + "].vars.TrialID", String.class);
			categoryNameList.forEach(c->{
				ParticipantTrialState state = new ParticipantTrialState();
				state.setParticipantId(patientID);
				Long finalTrialId = new Long(0);
				try {
					finalTrialId = c.contains(CATEGORY_DELIMITER) ? getTrialIdFromCategory(c) : Long.parseLong(trailID);					
				} catch (Exception e) {
					logger.error("Error parse long", e);
				}
				
				logger.info(">>Parsing data for PatientID:"+patientID.substring(0,2)+"XXXXXXX and TrialId:"+finalTrialId);
				state.setTrialId(finalTrialId);				
				participants.add(state);
			});
			
		});
		return participants;
	}
	
	private Long getTrialIdFromCategory(String categoryName) {
		String tokens[] = categoryName.split(CATEGORY_DELIMITER_REGEX);
		return Long.parseLong(tokens[1]);
	}

	@Override
	public void triggerEmailsCampaign(List<ParticipantTrialState> ptStates, HttpHeaders header) {
		for (ParticipantTrialState ptState : ptStates) {
			ptState.setStatusNotes("EMAIL");
			triggerEmailCampaign(ptState, header);
		}
	}

	/*
	 * Attempted Questionnaire (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerAttemptQuestion(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerAttemptQuestion(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.AttemptQuestionnaire);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Selected Studysite (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerSelectedStudySite(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerSelectedStudySite(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.SelectedStudySite);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Site has contacted patient (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerSiteToContact(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerSiteToContact(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.SiteToContact);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient agreed to Visit Site (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerScheduledVisit(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerScheduledVisit(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.ScheduledVisit);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient Visited Site (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerVisited(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerVisited(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.SiteVisited);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient Rejected Consent (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerPatientRejectConsent(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerPatientRejectConsent(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.PatientRejectConsent);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient Accept Consent (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerPatientAcceptConsent(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerPatientAcceptConsent(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.PatientAcceptConsent);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient Rejected Trial (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerPatientRejected(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerPatientRejected(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.PatientRejected);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient Failed (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerPatientFailed(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerPatientFailed(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.PatientFailed);
		return triggerStateChange(ptState, header);
	}

	/*
	 * Patient Through (non-Javadoc)
	 * 
	 * @see com.avigosolutions.participantservice.service.ParticipantStateService#
	 * triggerMovedToEnrolled(com.avigosolutions.participantservice.dto.
	 * ParticipantTrialState)
	 */
	@Override
	public States triggerMovedToEnrolled(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.PatientThrough);
		return triggerStateChange(ptState, header);
	}

	@Override
	public States triggerTrialCompleted(ParticipantTrialState ptState, HttpHeaders header) {
		ptState.setEvent(Events.TrialCompleted);
		return triggerStateChange(ptState, header);
	}

	@Override
	@Transactional
	public States moveToStatus(ParticipantTrialState ptState, HttpHeaders headers) {
		
		try {
			ptState.setParticipantId(EncryptionUtils.getInstance().decryptFromBase64WithException(ptState.getParticipantId()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		 * ParticipantStudySite participantStudySite = participantStudySiteService
		 * .findByParticipantIdAndTrialId(ptState.getParticipantId(),
		 * ptState.getTrialId()); long sourceStateId =
		 * Optional.ofNullable(participantStudySite).orElse(new ParticipantStudySite())
		 * .getParticipantStatusId(); States sState = States.getStateByCode((int)
		 * sourceStateId); States tState =
		 * States.getStateByCode(ptState.getTargetStateCode());
		 * logger.info("inside move To Status service method{}{}", tState.getCode(),
		 * sState.getCode()); if (tState == null || sState == null) { return null; }
		 * Optional<Events> eventToFire =
		 * particpantStateHandler.getMatchingEvent(sState, tState); if
		 * (!eventToFire.isPresent()) {
		 * logger.info("inside move To Status No machingevnet found"); return null; }
		 */
	
		//ptState.setEvent(eventToFire.get());
		return triggerStateChange(ptState, new ParticipantStudySite(), headers);
	}

	@Override
	public Set<States> getValidStates(ParticipantTrialState ptState) {
		ParticipantStudySite ptrial = participantStudySiteService
				.findByParticipantIdAndTrialId(ptState.getParticipantId(), ptState.getTrialId());
		long sourceStateId = Optional.ofNullable(ptrial).orElse(new ParticipantStudySite()).getParticipantStatusId();
		return particpantStateHandler.getAllPossibleStates(States.getStateByCode((int) sourceStateId));
	}

	private States triggerStateChange(ParticipantTrialState ptState, HttpHeaders header) {
		return triggerStateChange(ptState, null, null);
	}

	@Transactional
	private States triggerStateChange(ParticipantTrialState ptState, ParticipantStudySite participantStudySite,
			HttpHeaders header) {
		/*
		 * try {
		 * 
		 * ptState.setParticipantId(EncryptionUtils.getInstance().
		 * decryptFromBase64WithException(ptState.getParticipantId())); } catch
		 * (Exception e1) { // TODO Auto-generated catch block e1.printStackTrace(); }
		 */
		// Pull existing status of participant trial 
		String tableName="ParticipantStudySite_T_"+ ptState.getTrialId(); 
		long sourceStateId=3 ;
		if (participantStudySite == null) {
			
			/*
			 * javax.persistence.Query q=entityManager.
			 * createNativeQuery("Select top 1 participantId,trialId,studySiteId,participantStatusId,participantStudySiteId from "
			 * +tableName+ " where participantId= :1 and trialId=:2"); q.setParameter(1,
			 * ptState.getParticipantId()); q.setParameter(2, ptState.getTrialId());
			 * participantStudySite = (ParticipantStudySite) q.getSingleResult();
			 */
	
			
			javax.persistence.Query q1=entityManager.createNativeQuery("Select top 1 ParticipantStatusId from "+tableName+ " where participantId= :1 and trialId=:2");
			q1.setParameter(1, ptState.getParticipantId());
			q1.setParameter(2, ptState.getTrialId());
		//	participantStudySite= (ParticipantStudySite) q1.getSingleResult();
	        ptState.setSourceState(q1.getSingleResult().toString());
	     //   sourceStateId=Long.parseLong(q.getSingleResult().toString());
		//	participantStudySite = participantStudySiteService.findByParticipantIdAndTrialId(ptState.getParticipantId(),ptState.getTrialId());
		}
		
		String sourceState = Optional.ofNullable(States.getStateByCode((int) sourceStateId)).orElse(States.IDENTIFIED).toString();
	logger.info("triggerStateChange START - {}, {}, {}", sourceStateId, sourceState, ptState.getTrialId());
		ptState.setSourceState(sourceState);

		States sState = States.valueOf(ptState.getSourceState());
		ptState.setSourceStateCode(sState.getCode());
		Map<String, Object> headers = new HashMap<>();
		headers.put(Constants.PARTICIPANT_TRIAL, ptState);

	//	Message<Events> message = MessageBuilder.createMessage(ptState.getEvent(), new MessageHeaders(headers));
	/*
	 * try { particpantStateHandler.handleEvent(message, sState); } catch (Exception
	 * e) { logger.error("Exception in stateHandler", e); }
	 */
	//	States resultState = listener.retrieveState(ptState.getParticipantId(), ptState.getTrialId());
		
		javax.persistence.Query q1 = entityManager.createNativeQuery("update  " + tableName
				+ " set participantStatusId = :1 where participantId= :2 and trialId=:3");
		q1.setParameter(1, String.valueOf( ptState.getTargetStateCode()));
		//q1.setParameter(2, 3);
		q1.setParameter(2, ptState.getParticipantId());
		q1.setParameter(3, ptState.getTrialId());
		q1.executeUpdate();
		
		javax.persistence.Query q=entityManager.createNativeQuery("Select top 1 ParticipantStatusId from "+tableName+ " where participantId= :1 and trialId=:2");
		q.setParameter(1, ptState.getParticipantId());
		q.setParameter(2, ptState.getTrialId());
      //  q.getSingleResult();
        States resultState = States.getStateByCode((Integer.valueOf(q.getSingleResult().toString())));
		
		logger.info("triggerStateChange END - {}, {}, {}", sourceState, ptState.getTrialId(), resultState);
		// if (resultState != null)
		try {
			if (resultState != null) {
				//
				Query query = new Query();
				query.addCriteria(Criteria.where("_id").is(ptState.getTransactionId()));
				Update update = new Update();
				  ParsedQualtricsReponse savedDocument = new ParsedQualtricsReponse();
					if(null != ptState.getTransactionId()){
						savedDocument = template.findById(ptState.getTransactionId(), ParsedQualtricsReponse.class, "T_" + ptState.getTrialId());
					}
				SurveyResponseInfoForSiteCoord siteCoordinatorPortalInfo = savedDocument.getSiteCoordinatorPortalInfo();
				siteCoordinatorPortalInfo.setParticipantStatus(resultState.toString());
				siteCoordinatorPortalInfo.setParticipantStatusId( String.valueOf(resultState.getCode()) );
				siteCoordinatorPortalInfo.setNotes(ptState.getNotes());
				siteCoordinatorPortalInfo.setStatusNotes(ptState.getStatusNotes());
				
				//template.fin
				//System.out.println(template.findOne(query,  ,"T_" + ptState.getTrialId()));
				//update.addToSet("name", "Ankit");
				//HashMap<String, String> map = new HashMap<String, String>();
				//map.put("participantStatus", resultState.toString());
				//map.put("participantStatusId", String.valueOf(resultState.getCode()));
				update.set("siteCoordinatorPortalInfo", siteCoordinatorPortalInfo);
				update.set("updatedOn",new Date());
				if(template.exists(query, "T_" + ptState.getTrialId()))
				template.upsert(query, update, "T_" + ptState.getTrialId());
				
				participantStudySite.setParticipantId(savedDocument.getPid());
				participantStudySite.withTrialId(Integer.valueOf(savedDocument.getTrialId()));
				participantStudySite.withNotes(ptState.getNotes());
				participantStudySite.withStatusNotes(ptState.getStatusNotes());
				participantStudySite.withStudySiteId(savedDocument.getSiteId());
				updateStatusHistory(participantStudySite, resultState.getCode(), header);
			}
		} catch (Exception ex) {
			logger.error("error", ex);
		}

		return resultState;
	}

	private void updateStatusHistory(ParticipantStudySite participantStudySite, int changedStateCode,
			HttpHeaders headers) {
		ParticipantStudySiteHistory participantStudySiteHistory = new ParticipantStudySiteHistory()
				.withParticipantId(participantStudySite.getParticipantId())
				.withTrialId(participantStudySite.getTrialId()).withParticipantStatusId(changedStateCode);

		if (participantStudySite.getNotes() != null) {
			participantStudySiteHistory.withNotes(participantStudySite.getNotes());
		}
		if (participantStudySite.getStatusNotes() != null) {
			participantStudySiteHistory.withStatusNotes(participantStudySite.getStatusNotes());
		}

		if (participantStudySite.getStudySiteId() != null) {
			participantStudySiteHistory.withStudySiteId(participantStudySite.getStudySiteId());
		}
		participantStudySiteService.saveHistory(participantStudySiteHistory, headers);
	}

	@Override
	@Transactional
	public ParticipantStatus moveToStatusNew(ParticipantTrialState ptState, HttpHeaders headers) {
		try {
			ptState.setParticipantId(EncryptionUtils.getInstance().decryptFromBase64WithException(ptState.getParticipantId()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return triggerStateChangeNew(ptState, new ParticipantStudySite(), headers);
	}
	
	@Transactional
	private ParticipantStatus triggerStateChangeNew(ParticipantTrialState ptState, ParticipantStudySite participantStudySite,
			HttpHeaders header) {
		/*
		 * try {
		 * 
		 * ptState.setParticipantId(EncryptionUtils.getInstance().
		 * decryptFromBase64WithException(ptState.getParticipantId())); } catch
		 * (Exception e1) { // TODO Auto-generated catch block e1.printStackTrace(); }
		 */
		// Pull existing status of participant trial 
		String tableName="ParticipantStudySite_T_"+ ptState.getTrialId(); 
		long sourceStateId=3 ;
		if (participantStudySite == null) {
			
			/*
			 * javax.persistence.Query q=entityManager.
			 * createNativeQuery("Select top 1 participantId,trialId,studySiteId,participantStatusId,participantStudySiteId from "
			 * +tableName+ " where participantId= :1 and trialId=:2"); q.setParameter(1,
			 * ptState.getParticipantId()); q.setParameter(2, ptState.getTrialId());
			 * participantStudySite = (ParticipantStudySite) q.getSingleResult();
			 */
	
			
			javax.persistence.Query q1=entityManager.createNativeQuery("Select top 1 ParticipantStatusId from "+tableName+ " where participantId= :1 and trialId=:2");
			q1.setParameter(1, ptState.getParticipantId());
			q1.setParameter(2, ptState.getTrialId());
		//	participantStudySite= (ParticipantStudySite) q1.getSingleResult();
	        ptState.setSourceState(q1.getSingleResult().toString());
	     //   sourceStateId=Long.parseLong(q.getSingleResult().toString());
		//	participantStudySite = participantStudySiteService.findByParticipantIdAndTrialId(ptState.getParticipantId(),ptState.getTrialId());
		}
		
		//String sourceState = Optional.ofNullable(States.getStateByCode((int) sourceStateId)).orElse(States.IDENTIFIED).toString();
		ParticipantStatus participantStatus = participantStatusRepository.findById(sourceStateId);
		String sourceState = participantStatus!=null ? participantStatus.getParticipantStatusName():States.IDENTIFIED.toString();
		logger.info("triggerStateChange START - {}, {}, {}", sourceStateId, sourceState, ptState.getTrialId());
		ptState.setSourceState(sourceState);

		//States sState = States.valueOf(ptState.getSourceState());
		ParticipantStatus pStatus = participantStatusRepository.findByParticipantStatusName(ptState.getSourceState());
		//ptState.setSourceStateCode(sState.getCode());
		ptState.setSourceStateCode((int)pStatus.getParticipantStatusId());
		Map<String, Object> headers = new HashMap<>();
		headers.put(Constants.PARTICIPANT_TRIAL, ptState);

	//	Message<Events> message = MessageBuilder.createMessage(ptState.getEvent(), new MessageHeaders(headers));
	/*
	 * try { particpantStateHandler.handleEvent(message, sState); } catch (Exception
	 * e) { logger.error("Exception in stateHandler", e); }
	 */
	//	States resultState = listener.retrieveState(ptState.getParticipantId(), ptState.getTrialId());
		
		javax.persistence.Query q1 = entityManager.createNativeQuery("update  " + tableName
				+ " set participantStatusId = :1 where participantId= :2 and trialId=:3");
		q1.setParameter(1, String.valueOf( ptState.getTargetStateCode()));
		//q1.setParameter(2, 3);
		q1.setParameter(2, ptState.getParticipantId());
		q1.setParameter(3, ptState.getTrialId());
		q1.executeUpdate();
		
		javax.persistence.Query q=entityManager.createNativeQuery("Select top 1 ParticipantStatusId from "+tableName+ " where participantId= :1 and trialId=:2");
		q.setParameter(1, ptState.getParticipantId());
		q.setParameter(2, ptState.getTrialId());
      //  q.getSingleResult();
        //States resultState = States.getStateByCode((Integer.valueOf(q.getSingleResult().toString())));
        ParticipantStatus resultState = participantStatusRepository.findById((Long.valueOf(q.getSingleResult().toString())));
		logger.info("triggerStateChange END - {}, {}, {}", sourceState, ptState.getTrialId(), resultState);
		// if (resultState != null)
		try {
			if (resultState != null) {
				//
				Query query = new Query();
				query.addCriteria(Criteria.where("_id").is(ptState.getTransactionId()));
				Update update = new Update();
				  ParsedQualtricsReponse savedDocument = new ParsedQualtricsReponse();
					if(null != ptState.getTransactionId()){
						savedDocument = template.findById(ptState.getTransactionId(), ParsedQualtricsReponse.class, "T_" + ptState.getTrialId());
					}
				SurveyResponseInfoForSiteCoord siteCoordinatorPortalInfo = savedDocument.getSiteCoordinatorPortalInfo();
				siteCoordinatorPortalInfo.setParticipantStatus(resultState.getParticipantStatusName());
				siteCoordinatorPortalInfo.setParticipantStatusId( String.valueOf(resultState.getParticipantStatusId()) );
				siteCoordinatorPortalInfo.setNotes(ptState.getNotes());
				siteCoordinatorPortalInfo.setStatusNotes(ptState.getStatusNotes());
				
				//template.fin
				//System.out.println(template.findOne(query,  ,"T_" + ptState.getTrialId()));
				//update.addToSet("name", "Ankit");
				//HashMap<String, String> map = new HashMap<String, String>();
				//map.put("participantStatus", resultState.toString());
				//map.put("participantStatusId", String.valueOf(resultState.getCode()));
				update.set("siteCoordinatorPortalInfo", siteCoordinatorPortalInfo);
				update.set("updatedOn",new Date());
				if(template.exists(query, "T_" + ptState.getTrialId()))
				template.upsert(query, update, "T_" + ptState.getTrialId());
				
				participantStudySite.setParticipantId(savedDocument.getPid());
				participantStudySite.withTrialId(Integer.valueOf(savedDocument.getTrialId()));
				participantStudySite.withNotes(ptState.getNotes());
				participantStudySite.withStatusNotes(ptState.getStatusNotes());
				participantStudySite.withStudySiteId(savedDocument.getSiteId());
				updateStatusHistory(participantStudySite, (int)resultState.getParticipantStatusId(), header);
			}
		} catch (Exception ex) {
			logger.error("error", ex);
		}

		return resultState;
	}
}