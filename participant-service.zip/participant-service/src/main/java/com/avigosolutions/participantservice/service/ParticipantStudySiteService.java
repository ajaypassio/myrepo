package com.avigosolutions.participantservice.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;

import com.avigosolutions.participantservice.dto.CountModel;
import com.avigosolutions.participantservice.dto.ParticipantStudySiteStatistics;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.ParticipantStudySiteHistory;
import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
import com.avigosolutions.participantservice.response.model.DateModel;
import com.avigosolutions.participantservice.response.model.ResponseObjectModel;
import com.avigosolutions.participantservice.response.model.LocationResponse;

public interface ParticipantStudySiteService {
	public ResponseObjectModel getHistory(String participantId,long trialId, long studySiteId,int page, int pageSize);
	
	public ResponseObjectModel saveHistory(ParticipantStudySiteHistory history,HttpHeaders headers);

	public ParticipantStudySite save(ParticipantStudySite participantStudySite);

	public ParticipantStudySite findByParticipantIdAndTrialId(String participantId, Long trialId);

	List<CountModel> countByParticipantStatusIdAndStudySiteIdAndTrialId(List<Long> participantStatusId,
			List<Long> studySiteId, Long trialId);

	public ResponseObjectModel getParticipantsbyTrialIdAndStudySiteId(Long trialId, Long studySiteId,
			ParticipantRequestFilterModel participantRequestFilterModel);

	List<CountModel> countByParticipantStatusIdAndTrialId(List<Long> participantStatusId, Long trialId);

	List<CountModel> countByParticipantStatusIdInAndTrialIdIn(List<Long> participantStatusId, List<Long> trialId);

	List<DateModel> findFirstAndLastPatientDate(Long trialId);

	long countByTrialIdAndParticipantStatusId(Long trialId, Long participantStatusId);

	List<ParticipantStudySiteStatistics> findParticipantStudySiteCountByTrialIdAndStudySiteId(Long trialId,
			Long studySiteId);

	long countByTrialId(Long trialId);

	List<ParticipantStudySite> save(List<ParticipantStudySite> participantStudySite);
	
	public Map<String,Object> getParticipantStudySiteStatistics(Long trialId);
	
	LocationResponse getCitesByTrialIdAndStudySiteId(Long trialId, Long studySiteId, List<String> stateNames,
			String cityName, int start, int pageSize);

	LocationResponse getStatesByTrialIdAndStudySiteId(Long trialId, Long studySiteId, String stateName, int start,
			int pageSize, HttpHeaders headers);
	
}
