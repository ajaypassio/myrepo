package com.avigosolutions.participantservice.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.participantservice.SecurityUtil;
import com.avigosolutions.participantservice.common.CommonUtil;
import com.avigosolutions.participantservice.dto.CountModel;
import com.avigosolutions.participantservice.dto.ParticipantStudySiteStatistics;
import com.avigosolutions.participantservice.model.Participant;
import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.ParticipantStudySiteForSiteCordinator;
import com.avigosolutions.participantservice.model.ParticipantStudySiteHistory;
import com.avigosolutions.participantservice.repository.ParticipantStatusRepository;
import com.avigosolutions.participantservice.repository.ParticipantStudySiteHistoryRepository;
import com.avigosolutions.participantservice.repository.ParticipantStudySiteRepository;
import com.avigosolutions.participantservice.repository.ParticipantStudySiteRepositoryForSiteCordinator;
import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
import com.avigosolutions.participantservice.response.model.DateModel;
import com.avigosolutions.participantservice.response.model.ResponseObjectModel;
import com.avigosolutions.participantservice.response.model.StateDto;
import com.avigosolutions.participantservice.response.model.LocationDto;
import com.avigosolutions.participantservice.response.model.LocationResponse;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ParticipantStudySiteServiceImpl implements ParticipantStudySiteService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private static final long STATUS_NEW = 3L;

	@Autowired
	ParticipantStudySiteRepository participantStudySiteRepository;
	
	@Autowired
	ParticipantStudySiteRepositoryForSiteCordinator participantStudySiteRepositoryForSiteCordinator;

	@Autowired
	ParticipantStudySiteHistoryRepository participantStudySiteHistoryRepository;

	@Autowired
	ParticipantStatusRepository participantStatusRepository;

	@Autowired
	SecurityUtil securityUtil;

	@Value("${sprintt.criteria.service.lookup.states.url}")
	private String stateURL;

	@Override
	public ParticipantStudySite save(ParticipantStudySite participantStudySite) {
		participantStudySiteRepository.save(participantStudySite);
		return participantStudySite;
	}

	@Override
	public List<ParticipantStudySite> save(List<ParticipantStudySite> participantStudySite) {
		participantStudySiteRepository.save(participantStudySite);
		return participantStudySite;
	}

	@Override
	public ResponseObjectModel saveHistory(ParticipantStudySiteHistory history, HttpHeaders headers) {
		ResponseObjectModel response = new ResponseObjectModel();
		if (headers != null) {
			Long roleId = securityUtil.getRoleId(headers);
			history.setCreatedBy(roleId);
			history.setUpdatedBy(roleId);
		}
		response.setData(participantStudySiteHistoryRepository.save(history));
		response.setStatus(200);
		return response;
	}

	@Override
	public ResponseObjectModel getHistory(String participantId, long trialId, long studySiteId, int page,
			int pageSize) {
		ResponseObjectModel response = new ResponseObjectModel();
		Page<ParticipantStudySiteHistory> pageList = participantStudySiteHistoryRepository
				.findByParticipantIdAndTrialIdAndStudySiteId(participantId, trialId, studySiteId,
						CommonUtil.getPageRequest(page, pageSize, "CreatedOn", "DESC"));
		List<ParticipantStudySiteHistory> pshList = pageList.getContent();
		System.out.println("reached here"+pshList.size());
		
		pshList.forEach(psh -> {
			//ParticipantStudySiteHistory
			Long id = psh.getParticipantStatusId();
			
				psh.getParticipant().withInternalId(id);
			
		});
		response.setData(pageList.getContent());
		response.setTotal(pageList.getTotalElements());
		response.setStatus(200);
		return response;
	}

	@Autowired
	private ResponseObjectModel responseObjectModel;

	@Override
	public ParticipantStudySite findByParticipantIdAndTrialId(String participantId, Long trialId) {
		ParticipantStudySite pss = participantStudySiteRepository.findByParticipantIdAndTrialId(participantId, trialId);
		if (null != pss && null != pss.getParticipant()) {
			pss.getParticipant().withInternalId(pss.getParticipantStudySiteId());
		}
		return participantStudySiteRepository.findByParticipantIdAndTrialId(participantId, trialId);
	}

	// sql server bigint is not working
	@Override
	public List<CountModel> countByParticipantStatusIdAndStudySiteIdAndTrialId(List<Long> participantStatusId,
			List<Long> studySiteId, Long trialId) {
		List<Object[]> lstObject = participantStudySiteRepository
				.countByParticipantStatusIdAndStudySiteIdInAndTrialId(participantStatusId, studySiteId, trialId);
		List<CountModel> lstCount = new ArrayList<CountModel>();
		for (Object[] obj : lstObject) {
			CountModel countModel = new CountModel();
			if (obj[0] instanceof Integer)
				countModel.setCount(BigInteger.valueOf((Integer) obj[0]));
			else
				countModel.setCount((BigInteger) obj[0]);
			if (obj[1] instanceof Integer)
				countModel.setId(BigInteger.valueOf((Integer) obj[1]));
			else
				countModel.setId((BigInteger) obj[1]);
			if (obj[2] instanceof Integer)
				countModel.setStatusId(BigInteger.valueOf((Integer) obj[2]));
			else
				countModel.setStatusId((BigInteger) obj[2]);
			lstCount.add(countModel);
		}
		return lstCount;
	}

	/*
	 * @Override public ResponseObjectModel
	 * getParticipantsbyTrialIdAndStudySiteId(Long trialId, Long studySiteId,
	 * ParticipantRequestFilterModel participantFilterRequest) {
	 * 
	 * int page = participantFilterRequest.getStart(); int size =
	 * participantFilterRequest.getPageSize(); String columnToSort =
	 * participantFilterRequest.getColumnToSort(); String sortType =
	 * participantFilterRequest.getSortType(); String participantName =
	 * participantFilterRequest.getParticipantName(); List<String> cities =
	 * participantFilterRequest.getCities(); List<String> states =
	 * participantFilterRequest.getStates(); List<String> gender =
	 * participantFilterRequest.getGender(); List<String> participantIds =
	 * participantFilterRequest.getParticipantIds(); List<Long> statusIds =
	 * participantFilterRequest.getStatusIds(); String zipcode =
	 * participantFilterRequest.getZipcode();
	 * 
	 * // Generate page request object which is required for JPA pagination
	 * PageRequest pageRequest = CommonUtil.getPageRequest(page, size, columnToSort,
	 * sortType);
	 * 
	 * Boolean participantNameFlag = (null != participantName &&
	 * !participantName.equalsIgnoreCase("")) ? true : false; Boolean citiesFlag =
	 * (null != cities && cities.size() > 0) ? true : false; Boolean statesFlag =
	 * (null != states && states.size() > 0) ? true : false; Boolean genderFlag =
	 * (null != gender && gender.size() > 0) ? true : false; Boolean
	 * participantIdsFlag = (null != participantIds && participantIds.size() > 0) ?
	 * true : false; Boolean statusIdsFlag = (null != statusIds && statusIds.size()
	 * > 0) ? true : false; Boolean zipcodeFlag = (null != zipcode &&
	 * !zipcode.equalsIgnoreCase("")) ? true : false;
	 * 
	 * //DOB Filter Boolean ageFlag = false; Date dt1=new Date(); Date dt2=new
	 * Date(); if(participantFilterRequest.getAgeStart()>=0 &&
	 * participantFilterRequest.getAgeEnd()>0) { ageFlag = true;
	 * dt1.setYear(dt2.getYear()-participantFilterRequest.getStart());
	 * dt2.setYear(dt2.getYear()-participantFilterRequest.getAgeEnd());
	 * logger.info("Date 1:"+dt1); logger.info("Date 2:"+dt2); }
	 * 
	 * Page<ParticipantStudySite> pageParticipantStudySite=null;
	 * 
	 * // Get data based on filters if( participantNameFlag && citiesFlag &&
	 * statesFlag && genderFlag && participantIdsFlag && statusIdsFlag &&
	 * zipcodeFlag ) { pageParticipantStudySite =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantZipCodeOrParticipantStatusIdInOrParticipantIdIn
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * gender, zipcode, statusIds, participantIds, pageRequest)); }
	 * 
	 * else if( participantNameFlag && citiesFlag && statesFlag && genderFlag &&
	 * participantIdsFlag && statusIdsFlag && zipcodeFlag && ageFlag ) {
	 * pageParticipantStudySite =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantZipCodeOrParticipantStatusIdInOrParticipantIdInOrParticipantDobBetween
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * gender, zipcode, statusIds, participantIds, dt2, dt1, pageRequest)); }
	 * 
	 * else if (participantNameFlag && citiesFlag && statesFlag && genderFlag &&
	 * participantIdsFlag && statusIdsFlag && ageFlag){ pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantStatusIdInOrParticipantIdInOrParticipantDobBetween
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * gender, statusIds, participantIds, dt2, dt1, pageRequest)); }
	 * 
	 * else if (participantNameFlag && citiesFlag && statesFlag && genderFlag &&
	 * participantIdsFlag && statusIdsFlag ){ pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantStatusIdInOrParticipantIdIn
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * gender, statusIds, participantIds, pageRequest)); }
	 * 
	 * else if (participantNameFlag && citiesFlag && statesFlag && genderFlag &&
	 * participantIdsFlag){ pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantIdIn
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * gender, participantIds, pageRequest)); }
	 * 
	 * else if (participantNameFlag && citiesFlag && statesFlag && genderFlag){
	 * pageParticipantStudySite =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderIn
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * gender, pageRequest)); }
	 * 
	 * else if (participantNameFlag && citiesFlag && statesFlag){
	 * pageParticipantStudySite =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContaining
	 * (trialId, studySiteId, states, cities, participantName, participantName,
	 * pageRequest)); }
	 * 
	 * else if(participantNameFlag) { pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantFirstNameContainingOrParticipantLastNameContaining
	 * (trialId, studySiteId, participantName, participantName, pageRequest)); }
	 * 
	 * else if (citiesFlag){ pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantCityIn(trialId, studySiteId, cities,
	 * pageRequest)); }
	 * 
	 * else if (statesFlag){ pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantStateIn(trialId, studySiteId,
	 * states, pageRequest)); }
	 * 
	 * else if(genderFlag) { pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantGenderIn(trialId, studySiteId,
	 * gender, pageRequest)); }
	 * 
	 * else if(participantIdsFlag) { pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantIdIn(trialId, studySiteId,
	 * participantIds, pageRequest)); }
	 * 
	 * else if(statusIdsFlag) { pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantStatusIdIn(trialId, studySiteId,
	 * statusIds, pageRequest)); }
	 * 
	 * else if(zipcodeFlag) { pageParticipantStudySite
	 * =(participantStudySiteRepository.
	 * findByTrialIdAndStudySiteIdAndParticipantZipCode(trialId, studySiteId,
	 * zipcode, pageRequest)); }
	 * 
	 * else if(ageFlag) { pageParticipantStudySite =
	 * participantStudySiteRepository.findByParticipantDobBetween(dt2, dt1,
	 * pageRequest); }
	 * 
	 * else { pageParticipantStudySite
	 * =(participantStudySiteRepository.findByTrialIdAndStudySiteId(trialId,
	 * studySiteId, pageRequest)); }
	 * responseObjectModel.setTotal(pageParticipantStudySite.getTotalElements());
	 * List<ParticipantStudySite> e = pageParticipantStudySite.getContent();
	 * responseObjectModel.setData(e); responseObjectModel.setStatus(200);
	 * responseObjectModel.setMessage("Data retrived successfully"); return
	 * responseObjectModel; }
	 */

	@Override
	public ResponseObjectModel getParticipantsbyTrialIdAndStudySiteId(Long trialId, Long studySiteId,
			ParticipantRequestFilterModel participantFilterRequest) {

		int page = participantFilterRequest.getStart();
		int size = participantFilterRequest.getPageSize();

		// Generate page request object which is required for JPA pagination
		Sort sort = null;
		if (!CommonUtil.isNullOrBlank(participantFilterRequest.getColumnToSort())) {
			if (CommonUtil.isNullOrBlank(participantFilterRequest.getSortType())) {
				sort = new Sort(Direction.ASC, participantFilterRequest.getColumnToSort());
			} else if (participantFilterRequest.getSortType().toLowerCase().equals("asc")) {
				sort = new Sort(Direction.ASC, participantFilterRequest.getColumnToSort());
			} else if (participantFilterRequest.getSortType().toLowerCase().equals("desc")) {
				sort = new Sort(Direction.DESC, participantFilterRequest.getColumnToSort());
			} else {
				sort = new Sort(Direction.ASC, participantFilterRequest.getColumnToSort());
			}
		} else {
			sort = new Sort(Direction.ASC, "participantStatusId").and(new Sort(Direction.ASC, "updatedOn"));
		}
		Page<ParticipantStudySiteForSiteCordinator> pageParticipantStudySite = participantStudySiteRepositoryForSiteCordinator.findAll(
				filterParticipant(participantFilterRequest, trialId, studySiteId), new PageRequest(page, size, sort));
		responseObjectModel.setTotal(pageParticipantStudySite.getTotalElements());
		List<ParticipantStudySiteForSiteCordinator> e = pageParticipantStudySite.getContent();

		e.forEach(pss -> {
			if (null != pss.getParticipant()) {
				pss.getParticipant().withInternalId(pss.getParticipantStudySiteId());
			}

		});
		responseObjectModel.setData(e);
		responseObjectModel.setStatus(200);
		responseObjectModel.setMessage("Data retrived successfully");
		return responseObjectModel;
	}

	@Override
	public List<CountModel> countByParticipantStatusIdAndTrialId(List<Long> participantStatusId, Long trialId) {
		List<Object[]> lstObject = participantStudySiteRepository
				.countByParticipantStatusIdAndTrialId(participantStatusId, trialId);
		List<CountModel> lstCount = new ArrayList<CountModel>();
		for (Object[] obj : lstObject) {
			CountModel countModel = new CountModel();
			countModel.setCount((BigInteger) obj[0]);
			countModel.setId((BigInteger) obj[1]);
			countModel.setStatusId((BigInteger) obj[2]);
			lstCount.add(countModel);
		}
		return lstCount;
	}

	@Override
	public List<CountModel> countByParticipantStatusIdInAndTrialIdIn(List<Long> participantStatusId,
			List<Long> trialId) {
		List<Object[]> lstObject = participantStudySiteRepository.countByTrialIdParticipantStatusId(participantStatusId,
				trialId);
		List<CountModel> lstCount = new ArrayList<CountModel>();
		for (Object[] obj : lstObject) {
			CountModel countModel = new CountModel();
			countModel.setCount((BigInteger) obj[0]);
			countModel.setId((BigInteger) obj[1]);
			countModel.setStatusId((BigInteger) obj[2]);
			lstCount.add(countModel);
		}
		return lstCount;
	}

	@Override
	public List<DateModel> findFirstAndLastPatientDate(Long trialId) {
		List<Object[]> lstObject = participantStudySiteHistoryRepository.findFirstAndLastPatientDate(trialId);
		List<DateModel> lstCount = new ArrayList<DateModel>();
		for (Object[] obj : lstObject) {
			DateModel countModel = new DateModel();
			countModel.withFirstDate((Date) obj[0]);
			countModel.withLastDate((Date) obj[1]);
			countModel.withStatusId((BigInteger) obj[2]);
			lstCount.add(countModel);
		}
		return lstCount;
	}

	@Override
	public long countByTrialIdAndParticipantStatusId(Long trialId, Long participantStatusId) {
		return participantStudySiteRepository.countByTrialIdAndParticipantStatusId(trialId, participantStatusId);

	}

	@Override
	public List<ParticipantStudySiteStatistics> findParticipantStudySiteCountByTrialIdAndStudySiteId(Long trialId,
			Long studySiteId) {
		return participantStudySiteRepository.findParticipantStudySiteCountByTrialIdAndStudySiteId(trialId,
				studySiteId);
	}

	@Override
	public long countByTrialId(Long trialId) {
		// TODO Auto-generated method stub
		return participantStudySiteRepository.countByTrialId(trialId);
	}

	@Override
	public Map<String, Object> getParticipantStudySiteStatistics(Long trialId) {
		Map<String, Object> statisticsMap = new HashMap<>();

		try {
			List<Long> statusIdList = participantStatusRepository.findAll().stream()
					.map(status -> status.getParticipantStatusId()).collect(Collectors.toList());

			Map<Long, Object> trialData = new HashMap<>();
			Map<Long, Object> siteData = new HashMap<>();
			if (null != trialId && trialId.longValue() > 0) {
				statusIdList.forEach(statusId -> {
					List<Long> participantStatusId = new ArrayList<>();
					participantStatusId.add(statusId);
					List<Object[]> resObjList = participantStudySiteRepository
							.participantCountByParticipantStatusIdAndTrialIdAndNotNullStudySite(participantStatusId,
									trialId);
					if (null != resObjList && resObjList.size() > 0) {
						for (Object[] obj : resObjList) {
							Long pCount = (Long) obj[0];
							Long studySiteId = (Long) obj[1];
							Long pStatusId = (Long) obj[2];

							Map<Long, Long> statusData = null != siteData.get(studySiteId)
									? (Map<Long, Long>) siteData.get(studySiteId)
									: new HashMap<>();
							statusData.put(pStatusId, pCount);
							siteData.put(studySiteId, getPrePopulatedStatusMap(statusData));
						}
					}
				});
				trialData.put(trialId, siteData);
			}

			Map<Long, Long> statusCount = new HashMap<>();
			statusCount = getStatusCountStudySiteMap(statusIdList, false); // this needs to have count of all
																			// ParticipantStudySite records even with
																			// not null studySite

			Map<Long, Long> fullPatientCountMap = new HashMap<>();
			fullPatientCountMap = getStatusCountStudySiteMap(statusIdList, true);// this needs to have count of all
																					// ParticipantStudySite records even
																					// with null studySite

			statisticsMap.put("countByStatus", statusCount);
			statisticsMap.put("countFullPatientByStatus", fullPatientCountMap);
			statisticsMap.put("reportData", trialData); // have the participant count for each studysite under each
														// trial
		} catch (Exception ex) {
			logger.info(ex.getMessage());
			logger.error(ex.toString());
		}
		return statisticsMap;
	}

	private Map<Long, Long> getPrePopulatedStatusMap(Map<Long, Long> statusData) {
		for (Long i = 1L; i <= 12L; i++) {
			if (!statusData.containsKey(i)) {
				statusData.put(i, 0L);
			}
		}

		return statusData;

	}

	private Map<Long, Long> getStatusCountStudySiteMap(List<Long> statusIdList, boolean needStudySiteNullData) {
		Map<Long, Long> statusMap = new HashMap<>();
		statusIdList.forEach(id -> {
			if (!needStudySiteNullData) {
				statusMap.put(id, participantStudySiteRepository
						.count(getByParticipantStatusAndStudySiteNotNullSpecification(id)));
			} else {
				statusMap.put(id, participantStudySiteRepository.count(getByParticipantStatusSpecification(id)));
			}

		});
		return statusMap;
	}

	private Specification<ParticipantStudySite> getStudySiteNotNullSpecification() {
		return (root, query, cb) -> {
			query.distinct(true);
			return cb.and(cb.isNotNull(root.get("studySiteId")));
		};
	}

	private Specification<ParticipantStudySiteForSiteCordinator> filterParticipant(ParticipantRequestFilterModel filterModel,
			Long trialId, Long studySiteId) {
		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			Root<Participant> pRoot = query.from(Participant.class);

			// DOB Filter
			Boolean ageFlag = false;
			Date dt1 = new Date();
			Date dt2 = new Date();
			if (filterModel.getAgeStart() >= 0 && filterModel.getAgeEnd() > 0) {
				ageFlag = true;
				dt1.setYear(dt2.getYear() - filterModel.getStart());
				dt2.setYear(dt2.getYear() - filterModel.getAgeEnd());
				logger.info("Date 1:" + dt1);
				logger.info("Date 2:" + dt2);
			}

			predicates.add(cb.equal(root.get("participantId"), pRoot.get("participantId")));
			predicates.add(cb.greaterThanOrEqualTo(root.get("participantStatusId"), STATUS_NEW));
			
			if (null != trialId) {
				predicates.add(cb.equal(root.get("trialId"), trialId));
			}
			if (null != studySiteId) {
				predicates.add(cb.equal(root.get("studySiteId"), studySiteId));
			}

			if (!CommonUtil.IsNullOrEmpty(filterModel.getGender())) {
				predicates.add(cb.isTrue(pRoot.get("gender").in(filterModel.getGender())));
			}

			if (!CommonUtil.IsNullOrEmpty(filterModel.getStates())) {
				predicates.add(cb.isTrue(pRoot.get("state").in(filterModel.getStates())));
			}

			if (!CommonUtil.IsNullOrEmpty(filterModel.getCities())) {
				predicates.add(cb.isTrue(pRoot.get("city").in(filterModel.getCities())));
			}

			if (!CommonUtil.isNullOrBlank(filterModel.getParticipantName())) {
				predicates.add(cb.or(
						cb.like(cb.lower(root.join("participant").get("firstName")),
								"%" + filterModel.getParticipantName().toLowerCase() + "%"),
						cb.like(cb.lower(root.join("participant").get("lastName")),
								"%" + filterModel.getParticipantName().toLowerCase() + "%")));
			}

			if (!CommonUtil.isNullOrBlank(filterModel.getZipcode())) {
				predicates.add(cb.like(root.join("participant").get("zipCode"),
						"%" + filterModel.getParticipantName().toLowerCase() + "%"));
			}

			if (!CommonUtil.IsNullOrEmpty(filterModel.getStatusIds())) {
				predicates.add(cb.isTrue(root.get("participantStatusId").in(filterModel.getStatusIds())));
			}

			if (!CommonUtil.isNullOrEmpty(filterModel.getFromDate())
					&& !CommonUtil.isNullOrEmpty(filterModel.getToDate())) {
				predicates.add(
						cb.or(cb.between(root.get("createdOn"), filterModel.getFromDate(), filterModel.getToDate()),
								cb.between(root.get("updatedOn"), filterModel.getFromDate(), filterModel.getToDate())));
			}
			if (!CommonUtil.isNullOrEmpty(filterModel.getFromDate())) {
				predicates.add(cb.or(cb.greaterThanOrEqualTo(root.get("createdOn"), filterModel.getFromDate()),
						cb.greaterThanOrEqualTo(root.get("updatedOn"), filterModel.getFromDate())));
			}

			if (!CommonUtil.isNullOrEmpty(filterModel.getToDate())) {
				predicates.add(cb.or(cb.lessThanOrEqualTo(root.get("createdOn"), filterModel.getToDate()),
						cb.lessThanOrEqualTo(root.get("updatedOn"), filterModel.getToDate())));
			}

			if (ageFlag == true) {
				predicates.add(cb.between(root.join("participant").get("dob"), dt2, dt1));
			}
			query.orderBy(getParticipantOrder(filterModel.getColumnToSort(), filterModel.getSortType(), cb, root),
					cb.asc(pRoot.get("updatedOn")));
			// Ordering is not working if we set distinct
			// query.distinct(true);
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private Order getParticipantOrder(String column, String sortType, CriteriaBuilder cb,
			Root<ParticipantStudySiteForSiteCordinator> pRoot) {

		if ("ParticipantId".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(pRoot.get("participantId"));
			} else {
				return cb.desc(pRoot.get("participantId"));
			}
		} else if ("ParticipantStatus".equals(column)) {
			if (sortType.equals("asc")) {
				return cb.asc(pRoot.join("participantStatus").get("id"));
			} else {
				return cb.desc(pRoot.join("participantStatus").get("id"));
			}
		} else if ("Score".equals(column)) {

		} else {
			return cb.asc(pRoot.join("participantStatus").get("id"));
		}
		return (cb.asc(pRoot.get("createdOn")));

	}

	private Specification<ParticipantStudySite> getParticipantStudySite_StudySiteNotNullWithTrialId_StatusId_SiteIdSpecification(
			Long trialId, Long statusId, Long studySiteId) {

		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(cb.isNotNull(root.get("studySiteId")));

			if (null != trialId) {
				predicates.add(cb.equal(root.get("trialId"), trialId));
			}

			if (null != statusId) {
				predicates.add(cb.equal(root.get("participantStatusId"), statusId));
			}

			if (null != studySiteId) {
				predicates.add(cb.equal(root.get("studySiteId"), studySiteId));
			}

			query.distinct(true);
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private Specification<ParticipantStudySite> getByParticipantStatusAndStudySiteNotNullSpecification(Long id) {

		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();
			predicates.add(cb.isNotNull(root.get("studySiteId")));

			if (null != id) {
				predicates.add(cb.equal(root.get("participantStatusId"), id));
			}

			query.distinct(true);
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	private Specification<ParticipantStudySite> getByParticipantStatusSpecification(Long id) {

		return (root, query, cb) -> {
			List<Predicate> predicates = new ArrayList<>();

			if (null != id) {
				predicates.add(cb.equal(root.get("participantStatusId"), id));
			}

			query.distinct(true);
			return cb.and(predicates.toArray(new Predicate[predicates.size()]));
		};
	}

	@Override
	public LocationResponse getStatesByTrialIdAndStudySiteId(Long trialId, Long studySiteId, String stateName,
			int start, int pageSize, HttpHeaders headers) {
		Page<ParticipantStudySite> pgStudysite = null;
		LocationResponse response = new LocationResponse();
		List<LocationDto> lstStates = null;
		if (stateName.isEmpty()) {
			pgStudysite = participantStudySiteRepository.findByTrialIdAndStudySiteId(trialId, studySiteId,
					CommonUtil.getPageRequest(start, pageSize));

		} else {
			pgStudysite = participantStudySiteRepository
					.findByTrialIdAndStudySiteIdAndParticipantStateAndParticipantStateNotNull(trialId, studySiteId,
							stateName, CommonUtil.getPageRequest(start, pageSize));
		}
		lstStates = pgStudysite.getContent().stream().map(
				f -> new LocationDto().withValue(f.getParticipant().getState()).withName(f.getParticipant().getState()))
				.collect(Collectors.toList());
		if (null != lstStates && lstStates.size() > 0) {
			RestTemplate restTemplate = new RestTemplate();
			logger.info("Get State URL : " + stateURL);
			String getStateURL = stateURL.replace("{stateName}", "").replace("{start}", String.valueOf(start))
					.replace("{pageSize}", String.valueOf(pageSize));
			HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
			logger.info("Get State URL : " + getStateURL);
			@SuppressWarnings("unchecked")
			StateDto[] stateReponse = restTemplate.exchange(getStateURL, HttpMethod.GET, httpEntity, StateDto[].class)
					.getBody();
			lstStates.stream().filter(distinctByKey(p -> p.getName())).collect(Collectors.toList());

			List<LocationDto> lstLocationDto = lstStates;
			HashSet<LocationDto> piSet = new HashSet<>(lstLocationDto);
			lstLocationDto.clear();

			// set active status based on trialstudysite entry.
			piSet.forEach(state -> {
				Optional<StateDto> optTrialStudySite = Arrays.asList(stateReponse).stream()
						.filter(lpi -> lpi.getAbbrev().equalsIgnoreCase(state.getValue())).findFirst();
				if (optTrialStudySite.isPresent()) {
					state.withName(
							optTrialStudySite.get().getStateName() + "(" + optTrialStudySite.get().getAbbrev() + ")");
				}
				if (!state.getName().isEmpty())
					lstLocationDto.add(state);
			});

			response.withLocationList(
					lstLocationDto.stream().filter(distinctByKey(p -> p.getName())).collect(Collectors.toList()));
			response.withTotal(pgStudysite.getTotalElements());
		}
		return response;
	}

	@Override
	public LocationResponse getCitesByTrialIdAndStudySiteId(Long trialId, Long studySiteId, List<String> stateNames,
			String cityName, int start, int pageSize) {
		if (pageSize <= 0) {
			pageSize = 20;
		}
		Page<ParticipantStudySite> pgStudysite = null;
		LocationResponse response = new LocationResponse();
		List<LocationDto> lstCities = null;
		if (cityName.isEmpty() && stateNames.isEmpty()) {
			pgStudysite = participantStudySiteRepository.findByTrialIdAndStudySiteId(trialId, studySiteId,
					CommonUtil.getPageRequest(start, pageSize));

		} else if (stateNames.size() > 0 && cityName.isEmpty()) {
			pgStudysite = participantStudySiteRepository.findByTrialIdAndStudySiteIdAndParticipantStateIn(trialId,
					studySiteId, stateNames, CommonUtil.getPageRequest(start, pageSize));
		} else if (stateNames.size() > 0 && !cityName.isEmpty()) {
			pgStudysite = participantStudySiteRepository
					.findByTrialIdAndStudySiteIdAndParticipantStateInAndParticipantCityAndParticipantCityNotNull(
							trialId, studySiteId, stateNames, cityName, CommonUtil.getPageRequest(start, pageSize));
		}
		lstCities = pgStudysite.getContent().stream().filter(f -> !f.getParticipant().getCity().isEmpty())
				.map(f -> new LocationDto().withValue(f.getParticipant().getCity())
						.withName(f.getParticipant().getCity() + "(" + f.getParticipant().getState() + ")"))
				.collect(Collectors.toList());

		response.withLocationList(
				lstCities.stream().filter(distinctByKey(p -> p.getName())).collect(Collectors.toList()));
		response.withTotal(pgStudysite.getTotalElements());
		return response;
	}

	public static <T> java.util.function.Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
		Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}
}
