package com.avigosolutions.participantservice.service;

import java.util.List;

import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.TrialParticipantStatusAudit;
import com.avigosolutions.participantservice.model.TrialStatusAudit;

public interface ParticipantTrialService {

	public TrialParticipantStatusAudit save(TrialParticipantStatusAudit participantStudySite);

	public TrialStatusAudit save(TrialStatusAudit trialStatusAudit);

	public List<TrialParticipantStatusAudit> findTrialParticipantStatusAudit(String participantId, Long trialId);

	public List<TrialParticipantStatusAudit> findTrialParticipantStatusAudit(String participantId, Long trialId,
			long fromStatus, long toStatus);

	List<TrialStatusAudit> findTrialStatusAudit(Long trialId);
	
	List<TrialStatusAudit> findTrialStatusAuditByTrialIdIn(List<Long> trialIds);

	TrialStatusAudit findTrialStatusAudit(Long trialId, long fromStatus, long toStatus);

	public void storeAuditSummary(ParticipantStudySite participantStudySite, int fromStateId, int toStateId);
}