package com.avigosolutions.participantservice.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.model.ParticipantStudySite;
import com.avigosolutions.participantservice.model.TrialParticipantStatusAudit;
import com.avigosolutions.participantservice.model.TrialStatusAudit;
import com.avigosolutions.participantservice.repository.TrialParticipantStatusAuditRepository;
import com.avigosolutions.participantservice.repository.TrialStatusAuditRepository;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ParticipantTrialServiceImpl implements ParticipantTrialService {

	@Autowired
	TrialParticipantStatusAuditRepository participantTrialRepository;

	@Autowired
	TrialStatusAuditRepository trialStatusAuditRepository;

	@Override
	public TrialParticipantStatusAudit save(TrialParticipantStatusAudit participantStudySite) {
		participantStudySite = participantTrialRepository.saveAndFlush(participantStudySite);
		return participantStudySite;
	}

	@Override
	public List<TrialParticipantStatusAudit> findTrialParticipantStatusAudit(String participantId, Long trialId) {

		return participantTrialRepository.findByParticipantIdAndTrialId(participantId, trialId);
	}

	@Override
	public List<TrialParticipantStatusAudit> findTrialParticipantStatusAudit(String participantId, Long trialId,
			long fromStatus, long toStatus) {

		return participantTrialRepository.findByParticipantIdAndTrialIdAndFromStatusIdAndToStatusId(participantId,
				trialId, fromStatus, toStatus);
	}

	@Override
	public List<TrialStatusAudit> findTrialStatusAudit(Long trialId) {

		return trialStatusAuditRepository.findByTrialId(trialId);
	}

	@Override
	public TrialStatusAudit findTrialStatusAudit(Long trialId, long fromStatus, long toStatus) {

		return trialStatusAuditRepository.findByTrialIdAndFromStatusIdAndToStatusId(trialId, fromStatus, toStatus);
	}

	@Override
	public TrialStatusAudit save(TrialStatusAudit trialStatusAudit) {
		// TODO Auto-generated method stub
		return trialStatusAuditRepository.saveAndFlush(trialStatusAudit);
	}

	public void storeAuditSummary(ParticipantStudySite participantStudySite, int fromStateId, int toStateId) {
		// Persist Audit Detail
		TrialParticipantStatusAudit audit = new TrialParticipantStatusAudit();
		audit.withParticipantId(participantStudySite.getParticipantId()).withTrialId(participantStudySite.getTrialId())
				.withFromStatusId(fromStateId).withToStatusId(toStateId);
		save(audit);

		TrialStatusAudit trialStatusAudit = findTrialStatusAudit(participantStudySite.getTrialId(), fromStateId,
				toStateId);
		if (trialStatusAudit == null) {
			trialStatusAudit = new TrialStatusAudit();
			trialStatusAudit.withTrialId(participantStudySite.getTrialId()).withFromStatusId(fromStateId)
					.withToStatusId(toStateId);
			trialStatusAudit = save(trialStatusAudit);
		}
		// Persist Audit Summary
		List<TrialParticipantStatusAudit> audits = findTrialParticipantStatusAudit(
				participantStudySite.getParticipantId(), participantStudySite.getTrialId());
		Date prevDate = new Date();

		Optional<TrialParticipantStatusAudit> lastAudit = audits.stream()
				.filter(xaudit -> xaudit.getToStatusId() == fromStateId).findFirst();
		if (lastAudit.isPresent())
			prevDate = lastAudit.get().getCreatedOn();
		else
			prevDate = participantStudySite.getCreatedOn();

		long seconds = (new Date().getTime() - prevDate.getTime()) / 1000;
		if (seconds < trialStatusAudit.getMinTime()) {
			trialStatusAudit.withMinTime(seconds);
		}
		if (seconds > trialStatusAudit.getMaxtime()) {
			trialStatusAudit.withMaxtime(seconds);
		}
		trialStatusAuditRepository.updateTrialStatusAudit(trialStatusAudit.getAuditId(), trialStatusAudit.getMinTime(),
				trialStatusAudit.getMaxtime(), seconds);
	}

	@Override
	public List<TrialStatusAudit> findTrialStatusAuditByTrialIdIn(List<Long> trialIds) {
		return trialStatusAuditRepository.findByTrialIdIn(trialIds);
	}
}