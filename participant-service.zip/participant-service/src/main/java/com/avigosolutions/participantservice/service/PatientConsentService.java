package com.avigosolutions.participantservice.service;

import com.avigosolutions.participantservice.model.PatientConsent;
import com.avigosolutions.participantservice.response.model.ResponseObjectModel;

public interface PatientConsentService {

	public PatientConsent savePatientConsent(PatientConsent patientConsent);
	public String getPatientConsentDetails(String source,String foldername, Long questionnaireId)  ;
	public ResponseObjectModel getFooterContent();
}