package com.avigosolutions.participantservice.service;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.participantservice.messaging.util.PatientConsentBlobProcessor;
import com.avigosolutions.participantservice.model.PatientConsent;
import com.avigosolutions.participantservice.repository.PatientConsentRepository;
import com.avigosolutions.participantservice.response.model.ResponseObjectModel;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class PatientConsentServiceImpl implements PatientConsentService 
{
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private PatientConsentRepository patientConsentRepository;

	
	@Autowired
	private PatientConsentBlobProcessor patientBlobProcessor;
	
	@Value("${sprintt.criteria.service.fetch.trialid.url}")
	String getTrialByQuestionIdUrl;
	

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public PatientConsent savePatientConsent(PatientConsent patientConsent) {
		PatientConsent patientConsentObject = null;
		try {
			if (patientConsent.getTrialId() == null) {
				logger.error("Error occured Trial id does not exist or null " + patientConsent.getTrialId());
			} else {
				if (patientConsent != null) {
					try {
					if(Integer.valueOf(patientConsent.getParticipantId())==0)
						patientConsent.setTokenRequest(true);
					}catch(Exception e) {
						logger.info("not integer value");
					}
					
					patientConsentObject = patientConsentRepository.save(patientConsent);
					logger.info("Patient details saved for trial id" + patientConsent.getTrialId());
				}
			}
		} catch (Exception e) // ResourceNotFoundException
		{
			logger.error("Error occured while saving the Patient consent details " + e);
		}

		return patientConsentObject;
	}
	
	@Override
	public String getPatientConsentDetails(String source,String foldername, Long questionnaireId)  
	{
		 String patientConsentDetails=null;     
	 try
	   {
		 if(questionnaireId !=null)
		 {
	      patientConsentDetails =  patientBlobProcessor.patientConsentBlobs(source,foldername,questionnaireId);
		 }
	    }
		catch(Exception e)
		{
			logger.error("Error while getting the trail id based on  Question id");
			patientConsentDetails = patientBlobProcessor.patientConsentBlobs(source,foldername,null);	
		}
		return patientConsentDetails;
	}

	@Override
	public ResponseObjectModel getFooterContent() {
		ResponseObjectModel responseObjectModel=new ResponseObjectModel();
		responseObjectModel.setData(patientBlobProcessor.fetchFooterContent());
		responseObjectModel.setMessage("Footer content found");
		responseObjectModel.setStatus(200);
		return responseObjectModel;
	}

}
