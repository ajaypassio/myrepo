package com.avigosolutions.participantservice.utils;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

import org.springframework.http.HttpHeaders;

public class CommonUtils {

	public static String DEFAULT_CHAR_ENCODING = "UTF-8";

	public static String getBase64Encoded(String msg) {
		byte[] encodedBytes = null;
		try {
			encodedBytes = Base64.getUrlEncoder().encode(msg.getBytes(DEFAULT_CHAR_ENCODING));
			return encodedBytes.toString();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getBase64Encoded(byte msg[]) throws UnsupportedEncodingException {
		byte[] encodedBytes = Base64.getUrlEncoder().encode(msg);
		return new String(encodedBytes, DEFAULT_CHAR_ENCODING);
	}

	public static String getBase64Decoded(String msg) {
		byte[] decodedBytes = null;
		try {
			decodedBytes = Base64.getUrlDecoder().decode(msg.getBytes(DEFAULT_CHAR_ENCODING));
			return decodedBytes.toString();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] getBase64DecodedBytes(String msg) {
		byte[] decodedBytes = Base64.getUrlDecoder().decode(msg.getBytes());
		return decodedBytes;
	}

	public static void sleepThread(int num, TimeUnit unit) {
		try {
			Thread.sleep(unit.toMillis(num));
		} catch (Exception e) {
			// Ignore
		}
	}
	
	public static HttpHeaders getCRMHeaders(String authorization) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Authorization", authorization);
		return headers;
	}
}
