package com.avigosolutions.participantservice.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.annotation.PostConstruct;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class EncryptionUtils {
	private static Cipher cipher = null;
	private static SecretKey secretKey = null;
	//private String SECRET = "secret1234";

	@Value("${participant.id.cipher}")
	private String SECRET="secret1234";
	
	@Value("${questionnnaire.id.cipher}")
	private String QUESTIONNAIRE_SECRET ="secret1234";

	private static EncryptionUtils utils = new EncryptionUtils();
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	    @PostConstruct
	    public void init() {

	        byte[] key = new byte[16];
			try {
				key = fixSecret("secret1234", 16);
			} catch (UnsupportedEncodingException e) {
				logger.error("UnsupportedEncodingException", e);
			}
			secretKey = new SecretKeySpec(key, "AES");
			try {
				cipher = Cipher.getInstance("AES");
			} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
				logger.error("UnsupportedEncodingException", e);
			}
	    }

	public EncryptionUtils() {
	    byte[] key = new byte[16];
				try {
					key = fixSecret("secret1234", 16);
				} catch (UnsupportedEncodingException e) {
					logger.error("UnsupportedEncodingException", e);
				}
				secretKey = new SecretKeySpec(key, "AES");
				try {
					cipher = Cipher.getInstance("AES");
				} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
					logger.error("UnsupportedEncodingException", e);
				}
	}

	public static EncryptionUtils getInstance() {
		return utils;
	}

	private byte[] fixSecret(String s, int length) throws UnsupportedEncodingException {
		if (s.length() < length) {
			int missingLength = length - s.length();
			for (int i = 0; i < missingLength; i++) {
				s += " ";
			}
		}
		return s.substring(0, length).getBytes("UTF-8");
	}

	public synchronized byte[] encrypt(byte[] plainTextByte) throws Exception {
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedBytes = cipher.doFinal(plainTextByte);
		return encryptedBytes;
	}

	public synchronized byte[] encrypt(String plainText) throws Exception {
		byte[] plainTextByte = plainText.getBytes(CommonUtils.DEFAULT_CHAR_ENCODING);
		byte[] encryptedBytes = encrypt(plainTextByte);
		return encryptedBytes;
	}

	public synchronized byte[] decrypt(byte[] encryptedBytes) throws Exception {
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
		return decryptedBytes;
	}

	public synchronized String encryptToBase64(String plainText) {
		byte encryptedByte[] = null;
		try {
			encryptedByte = encrypt(plainText);
			return CommonUtils.getBase64Encoded(encryptedByte);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	public synchronized String decryptFromBase64(String encoded) {
		byte decryptedBytes[] = null;
		try {
			@SuppressWarnings("deprecation")
			byte decoded[] = CommonUtils.getBase64DecodedBytes(URLDecoder.decode(encoded));
			decryptedBytes = utils.decrypt(decoded);
			return new String(decryptedBytes, CommonUtils.DEFAULT_CHAR_ENCODING);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	public static void main(String[] args) throws Exception {
		String plainText = "1101594849";
		System.out.println("Plain Text Before Encryption: " + plainText);

		EncryptionUtils utils = EncryptionUtils.getInstance();

		String encoded = utils.encryptToBase64(plainText);
		System.out.println("Encoded - " + encoded);

		String decryptedText = utils.decryptFromBase64("iUKrqD2jfT2kLH2--QiEdQ==");
		System.out.println("Decrypted Text After Decryption: " + decryptedText);
	}

	public synchronized String decryptFromBase64WithException(String encoded) throws Exception {
		byte decryptedBytes[] = null;
		try {

			@SuppressWarnings("deprecation")
			byte decoded[] = CommonUtils.getBase64DecodedBytes(URLDecoder.decode(encoded));
			decryptedBytes = utils.decrypt(decoded);
			return new String(decryptedBytes, CommonUtils.DEFAULT_CHAR_ENCODING);

		} catch (Exception e) {
			throw e;
		}
	//	return "";
	}
}