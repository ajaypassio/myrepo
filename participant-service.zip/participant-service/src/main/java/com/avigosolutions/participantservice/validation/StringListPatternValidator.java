package com.avigosolutions.participantservice.validation;

import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class StringListPatternValidator implements ConstraintValidator<StringList, List<String>>{

	String regexp;
	
	@Override
    public void initialize(StringList stringList) {
		this.regexp = stringList.regexp();
    }

    @Override
    public boolean isValid(List<String> objects, ConstraintValidatorContext context) {
        if(null == objects || objects.size()==0) {
			return true;
        }else{
			return objects.stream().allMatch(obj -> obj.matches(regexp));
		}
    }

}
