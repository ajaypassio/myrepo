package com.questdiagnostics.mongo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ParsedQualtricsReponse {
	
	@JsonProperty("_id")
	public String _id;
	
	@JsonProperty("pid")
    public String pid;
	
	@JsonProperty("siteId")
    public int siteId;
	
	@JsonProperty("qualificationStatus")
    public String qualificationStatus;
	
	@JsonProperty("basicInfo")
    public String basicInfo;
	
	@JsonProperty("qualtricsResponse")
    public String qualtricsResponse;
	
	 public String trialId;
	 
	 public String transactionId;
	
 //   public List<SubmittedRespons> submittedResponses;
    public SurveyResponseInfoForAdmin adminPortalInfo;
    @JsonProperty("siteCoordinatorPortalInfo")
    public SurveyResponseInfoForSiteCoord siteCoordinatorPortalInfo;
    
    @JsonProperty("_class")
    public String _class;
	public String get_id() {
		return _id;
	}
	public String getPid() {
		return pid;
	}
	public int getSiteId() {
		return siteId;
	}
	public String getQualificationStatus() {
		return qualificationStatus;
	}
	public String getBasicInfo() {
		return basicInfo;
	}
	public String getQualtricsResponse() {
		return qualtricsResponse;
	}

	/*
	 * public List<SubmittedRespons> getSubmittedResponses() { return
	 * submittedResponses; } public AdminPortalInfo getAdminPortalInfo() { return
	 * adminPortalInfo; }
	 */
	
	public String get_class() {
		return _class;
	}
	public SurveyResponseInfoForAdmin getAdminPortalInfo() {
		return adminPortalInfo;
	}
	public void setAdminPortalInfo(SurveyResponseInfoForAdmin adminPortalInfo) {
		this.adminPortalInfo = adminPortalInfo;
	}
	public SurveyResponseInfoForSiteCoord getSiteCoordinatorPortalInfo() {
		return siteCoordinatorPortalInfo;
	}
	public void setSiteCoordinatorPortalInfo(SurveyResponseInfoForSiteCoord siteCoordinatorPortalInfo) {
		this.siteCoordinatorPortalInfo = siteCoordinatorPortalInfo;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}
	public void setQualificationStatus(String qualificationStatus) {
		this.qualificationStatus = qualificationStatus;
	}
	public void setBasicInfo(String basicInfo) {
		this.basicInfo = basicInfo;
	}
	public void setQualtricsResponse(String qualtricsResponse) {
		this.qualtricsResponse = qualtricsResponse;
	}

	public void set_class(String _class) {
		this._class = _class;
	}
	
	
	public String getTrialId() {
		return trialId;
	}
	public void setTrialId(String trialId) {
		this.trialId = trialId;
	}
	
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	@Override
	public String toString() {
		return "ParsedQualtricsReponse [_id=" + _id + ", pid=" + pid + ", siteId=" + siteId + ", qualificationStatus="
				+ qualificationStatus + ", basicInfo=" + basicInfo + ", qualtricsResponse=" + qualtricsResponse
				+ ", submittedResponses=" + ", adminPortalInfo=" + adminPortalInfo
				+ ", siteCoordinatorPortalInfo=" + siteCoordinatorPortalInfo + ", _class=" + _class + "]";
	}
	
}
