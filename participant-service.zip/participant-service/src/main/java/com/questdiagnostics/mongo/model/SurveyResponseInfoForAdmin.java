package com.questdiagnostics.mongo.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ankit Thakur
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class SurveyResponseInfoForAdmin implements Serializable {

	private static final long serialVersionUID = 5352452409863290733L;
	
	private String pid;
	private String responseId;
	private String emailAddress;
	private String surveyName;
	private String surveyVersion;
	private String qualificationStatus;
	private String programName;
	private String trialName;
	private String patientName;
	private String referralId;
	private String trialsRecommended;
	
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getResponseId() {
		return responseId;
	}
	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public String getSurveyVersion() {
		return surveyVersion;
	}
	public void setSurveyVersion(String surveyVersion) {
		this.surveyVersion = surveyVersion;
	}
	public String getQualificationStatus() {
		return qualificationStatus;
	}
	public void setQualificationStatus(String qualificationStatus) {
		this.qualificationStatus = qualificationStatus;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getTrialName() {
		return trialName;
	}
	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getReferralId() {
		return referralId;
	}
	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}
	public String getTrialsRecommended() {
		return trialsRecommended;
	}
	public void setTrialsRecommended(String trialsRecommended) {
		this.trialsRecommended = trialsRecommended;
	}
	
	
	
	

	
	

}