package com.questdiagnostics.mongo.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ankit Thakur
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class SurveyResponseInfoForSiteCoord implements Serializable {

	private static final long serialVersionUID = 5352452409863290733L;


	private String referralId;
	private String emailAddress;
	private String qualificationStatus;
	private String firstName;
	
	private String lastName;
	private String middleName;
	private String phoneNumber;
	private String patientName;
	private String preferredModeOfContact;
	private String preferredModeOfTime;
	
	private String DOB;
	private String gender;
	private String address;
	
	private String trialName;
	private String participantStatus;
	private String participantStatusId;
	
	private String city;
	private String state;
	private String pid;
	//private String createdOn;
	//private String participantStatusId;
	private String surveyName;
	
	private String statusNotes;
	
	private String notes;


	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	
	public String getQualificationStatus() {
		return qualificationStatus;
	}
	public void setQualificationStatus(String qualificationStatus) {
		this.qualificationStatus = qualificationStatus;
	}
	
	
	
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getReferralId() {
		return referralId;
	}
	public void setReferralId(String referralId) {
		this.referralId = referralId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPreferredModeOfContact() {
		return preferredModeOfContact;
	}
	public void setPreferredModeOfContact(String preferredModeOfContact) {
		this.preferredModeOfContact = preferredModeOfContact;
	}
	public String getPreferredModeOfTime() {
		return preferredModeOfTime;
	}
	public void setPreferredModeOfTime(String preferredModeOfTime) {
		this.preferredModeOfTime = preferredModeOfTime;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTrialName() {
		return trialName;
	}
	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}
	public String getParticipantStatus() {
		return participantStatus;
	}
	public void setParticipantStatus(String participantStatus) {
		this.participantStatus = participantStatus;
	}
	public String getParticipantStatusId() {
		return participantStatusId;
	}
	public void setParticipantStatusId(String participantStatusId) {
		this.participantStatusId = participantStatusId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public String getStatusNotes() {
		return statusNotes;
	}
	public void setStatusNotes(String statusNotes) {
		this.statusNotes = statusNotes;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	
	
	

	
	

}