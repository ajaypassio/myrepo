-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pdr_participant
-- ------------------------------------------------------
-- Server version	5.7.21-log


--
-- Table structure for table `audit_history`
--

DROP TABLE IF EXISTS `audit_history`;


CREATE TABLE `audit_history` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EntityName` varchar(255) DEFAULT NULL,
  `ActionPerformed` varchar(255) DEFAULT NULL,
  `EntityContent` longtext,
  `ModifiedBy` bigint(20) DEFAULT NULL,
  `ModifiedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `crmcategory`
--

DROP TABLE IF EXISTS `crmcategory`;


CREATE TABLE `crmcategory` (
  `categoryID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TrialID` bigint(20) NOT NULL,
  `TrialName` varchar(255) DEFAULT NULL,
  `SearchName` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `lookupCode` varchar(255) DEFAULT NULL,
  `namedFilterID` varchar(255) DEFAULT NULL,
  `filterName` varchar(255) DEFAULT NULL,
  `errorCode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`categoryID`),
  KEY `CRMCategory_TrialID` (`TrialID`),
  KEY `CRMContact_CategoryID` (`categoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `crmcontact`
--

DROP TABLE IF EXISTS `crmcontact`;


CREATE TABLE `crmcontact` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantId` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `CategoryID` bigint(20) DEFAULT NULL,
  `errorCode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `participant`
--

DROP TABLE IF EXISTS `participant`;


CREATE TABLE `participant` (
  `ParticipantId` varchar(10) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `EmailAddress` varchar(312) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `TrialVisits` bigint(10) DEFAULT NULL,
  `TrialSponsors` varchar(2000) DEFAULT NULL,
  `ZipCode` varchar(20) DEFAULT NULL,
  `ContactNumber` varchar(20) DEFAULT '0',
  `DOB` datetime DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Address` varchar(256) DEFAULT NULL,
  `City` varchar(512) DEFAULT NULL,
  `State` varchar(512) DEFAULT NULL,
  `SMS` bit(1) DEFAULT b'0',
  `PhoneType` varchar(20) DEFAULT NULL,
  `Voicemail` bit(1) DEFAULT NULL,
  `PreferredTimeOfContact` varchar(45) DEFAULT NULL,
  `Session` varchar(10) DEFAULT NULL,
  `IsPreferredEmail` bit(1) DEFAULT b'0',
  `IsPreferredPhone` bit(1) DEFAULT b'0',
  `IsPreferredMail` bit(1) DEFAULT b'0',
  PRIMARY KEY (`ParticipantId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `participantappointment`
--

DROP TABLE IF EXISTS `participantappointment`;


CREATE TABLE `participantappointment` (
  `ParticipantAppointmentId` bigint(20) NOT NULL,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  `AppointmentDate` datetime DEFAULT NULL,
  `AppointmentStatus` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ParticipantAppointmentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `participantquestion`
--

DROP TABLE IF EXISTS `participantquestion`;


CREATE TABLE `participantquestion` (
  `ParticipantQuestionId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `QuestionId` bigint(20) DEFAULT NULL,
  `Answer` varchar(255) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `ParticipantQuestionnaireId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ParticipantQuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;


--
-- Table structure for table `participantquestionnaire`
--

DROP TABLE IF EXISTS `participantquestionnaire`;


CREATE TABLE `participantquestionnaire` (
  `ParticipantQuestionnaireId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `QuestionnaireId` bigint(20) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `FutureTrialEmails` bit(1) DEFAULT b'0',
  `QuestEmails` bit(1) DEFAULT b'0',
  `StudySite` varchar(5) DEFAULT NULL,
  `TrialOptStatus` int(11) DEFAULT '0',
  `RXMedStatus` tinyint(1) DEFAULT NULL,
  `UserConsent` tinyint(1) DEFAULT NULL,
  `Interest` tinyint(1) DEFAULT NULL,
  `LastQuestionAnswered` bigint(20) DEFAULT '0',
  `IsNotifyOnSiteOpen` bit(1) DEFAULT b'0',
  PRIMARY KEY (`ParticipantQuestionnaireId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


--
-- Table structure for table `participantstatus`
--

DROP TABLE IF EXISTS `participantstatus`;


CREATE TABLE `participantstatus` (
  `ParticipantStatusId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantStatusName` varchar(250) NOT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  PRIMARY KEY (`ParticipantStatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;


--
-- Table structure for table `participantstudysite`
--

DROP TABLE IF EXISTS `participantstudysite`;


CREATE TABLE `participantstudysite` (
  `ParticipantStudySiteId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  `StudySiteId` bigint(20) DEFAULT NULL,
  `ParticipantStatusId` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `StatusNotes` varchar(255) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `scoreJSON` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ParticipantStudySiteId`),
  UNIQUE KEY `Participant_STUDYSITE_TRIAL` (`TrialId`,`ParticipantId`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8;


--
-- Table structure for table `participantstudysitehistory`
--

DROP TABLE IF EXISTS `participantstudysitehistory`;


CREATE TABLE `participantstudysitehistory` (
  `ParticipantStudySiteHistoryId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  `StudySiteId` bigint(20) DEFAULT NULL,
  `ParticipantStatusId` bigint(20) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `StatusNotes` varchar(255) DEFAULT NULL,
  `CreatedBy` bigint(20) DEFAULT NULL,
  `UpdatedBy` bigint(20) DEFAULT NULL,
  `Notes` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ParticipantStudySiteHistoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


--
-- Table structure for table `participanttrial`
--

DROP TABLE IF EXISTS `participanttrial`;


CREATE TABLE `participanttrial` (
  `ParticipantTrialId` bigint(20) NOT NULL,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  `ParticipantTrialStatus` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ParticipantTrialId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Table structure for table `trialparticipantstatusaudit`
--

DROP TABLE IF EXISTS `trialparticipantstatusaudit`;


CREATE TABLE `trialparticipantstatusaudit` (
  `auditId` bigint(20) NOT NULL AUTO_INCREMENT,
  `ParticipantId` varchar(10) DEFAULT NULL,
  `TrialId` bigint(20) DEFAULT NULL,
  `fromStatusId` bigint(5) DEFAULT NULL,
  `toStatusId` bigint(5) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`auditId`),
  KEY `TrialParticipantStatusAudit_TRIAL` (`TrialId`,`ParticipantId`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;


--
-- Table structure for table `trialstatusaudit`
--

DROP TABLE IF EXISTS `trialstatusaudit`;


CREATE TABLE `trialstatusaudit` (
  `auditId` bigint(20) NOT NULL AUTO_INCREMENT,
  `TrialId` bigint(20) DEFAULT NULL,
  `fromStatusId` bigint(5) DEFAULT NULL,
  `toStatusId` bigint(5) DEFAULT NULL,
  `minTime` bigint(20) DEFAULT NULL,
  `maxTime` bigint(20) DEFAULT NULL,
  `totalTime` bigint(20) DEFAULT NULL,
  `participantCount` bigint(20) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`auditId`),
  KEY `TrialStatusAudit_TRIAL` (`TrialId`,`fromStatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;


-- Dump completed on 2018-06-07 15:10:53
