-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: pdr_participant
-- ------------------------------------------------------
-- Server version	5.7.21-log


--
-- Dumping data for table `participantappointment`
--

LOCK TABLES `participantappointment` WRITE;
INSERT INTO `participantappointment` VALUES (1,'1',4,'2018-03-20 00:00:00','pending'),(2,'2',4,'2018-03-20 00:00:00','pending');
UNLOCK TABLES;


--
-- Dumping data for table `participantstatus`
--

LOCK TABLES `participantstatus` WRITE;
INSERT INTO `participantstatus` VALUES (1,'Identified',NULL,'2018-03-19 20:11:16',NULL,'2018-03-19 20:11:16'),(2,'Screening',NULL,'2018-03-19 20:11:16',NULL,'2018-03-19 20:11:16'),(3,'Referred',NULL,'2018-03-19 20:11:16',NULL,'2018-03-19 20:11:16'),(4,'Enrolled',NULL,'2018-03-19 20:11:16',NULL,'2018-03-19 20:11:16'),(5,'Outreached',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(6,'Site Contacting',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(7,'Visit Scheduled',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(8,'Visited',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(9,'Consented',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(10,'Not Qualified',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(11,'Not Interested',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33'),(12,'Completed',NULL,'2018-06-07 15:06:33',NULL,'2018-06-07 15:06:33');
UNLOCK TABLES;


-- Dump completed on 2018-06-07 15:11:09
