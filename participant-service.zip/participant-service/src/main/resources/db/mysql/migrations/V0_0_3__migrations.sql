Update participantstatus set participantstatusName='Interested' where participantstatusid=3;
