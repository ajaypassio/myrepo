CREATE TABLE `crmcontactjob` (
  `CRMContactJobId` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `TrialId` BIGINT(20) NOT NULL,
  `SearchName` NVARCHAR(512) NOT NULL,
  `ContactJson` VARCHAR(8000) NOT NULL,
  `CreatedBy` BIGINT(20) NULL,
  `UpdatedBy` BIGINT(20) NULL,
  `CreatedOn` DATETIME NULL,
  `UpdatedOn` DATETIME NULL,
  PRIMARY KEY (`CRMContactJobId`));