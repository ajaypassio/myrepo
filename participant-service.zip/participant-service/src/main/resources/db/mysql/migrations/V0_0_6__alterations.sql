Alter table CRMContactJob add lastPartcipantId bigint default null;
Alter table CRMContactJob add JobStatus nvarchar(50);
Alter table CRMContactJob add LastBatchId bigint default null;
Alter table CRMContactJob add FailedBatches nvarchar(512) default null;