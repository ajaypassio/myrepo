drop table CRMContactJobBatch;
drop table CRMContactJob;

CREATE TABLE `CRMContactJob` (
  `CRMContactJobId` BIGINT NOT NULL AUTO_INCREMENT,
  `TrialId` BIGINT NULL,
  `SearchName` NVARCHAR(512) NULL,
  `ContactJson` NVARCHAR(8000) NULL,
  `CreatedBy` BIGINT NULL,
  `CreatedOn` DATETIME NULL,
  `UpdatedBy` BIGINT NULL,
  `UpdatedOn` DATETIME NULL,
  `lastPartcipantId` BIGINT NULL,
  `JobStatus` NVARCHAR(50) NULL,
  `LastBatchId` BIGINT NULL,
  `InProcess` BIT NULL,
  PRIMARY KEY (`CRMContactJobId`));

CREATE TABLE `CRMContactJobBatch` (
  `CRMContactJobBatchId` BIGINT NOT NULL AUTO_INCREMENT,
  `CRMContactJobId` BIGINT NULL,
  `IsBatchCompleted` BIT NULL,
  `BatchId` INT NULL,
  `batchSize` INT NULL,
  `CreatedBy` BIGINT NULL,
  `UpdatedBy` BIGINT NULL,
  `CreatedOn` DATETIME NULL,
  `UpdatedOn` DATETIME NULL,
  PRIMARY KEY (`CRMContactJobBatchId`));
