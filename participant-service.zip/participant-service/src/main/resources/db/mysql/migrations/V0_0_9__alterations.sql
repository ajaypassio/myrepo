alter table CRMContactJob add BatchId int default 0;
alter table CRMContactJob add BatchSize int default 0;
alter table CRMContactJob add TrialName nvarchar(8000);

Alter table CRMContactJob change column LastPartcipantId LastPartcipantId nvarchar(1000);

alter table CRMContactJob add FailedAttempt int default 0;

drop table CRMContactJobBatch;