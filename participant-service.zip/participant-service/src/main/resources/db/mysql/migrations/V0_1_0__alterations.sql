CREATE TABLE `participantjob` (
  `JobId` BIGINT NOT NULL AUTO_INCREMENT,
  `SavedSearchName` VARCHAR(512) NULL,
  `TrialId` BIGINT NULL,
  `TrialName` VARCHAR(512) NULL,
  `CorrelationId` VARCHAR(512) NULL,
  `ParticipantJson` VARCHAR(8000) NULL,
  `IsCategoryCreated` INT NULL,
  `IsSaved` INT NULL,
  `IsContactsPushed` INT NULL,
  `totalContactBatchCount` INT NULL,
  `CreatedBy` BIGINT NULL,
  `CreatedOn` DATETIME NULL,
  PRIMARY KEY (`JobId`));
