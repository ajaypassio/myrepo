alter TABLE ParticipantJob
add IsDisabled INT DEFAULT 0;

alter TABLE ParticipantJob
add AttemptsMade INT DEFAULT 0;

alter TABLE ParticipantJob
add UpdatedOn DATETIME NULL;

update ParticipantJob
set IsDisabled=0

update ParticipantJob
set AttemptsMade=0

update ParticipantJob
set UpdatedOn = NOW();