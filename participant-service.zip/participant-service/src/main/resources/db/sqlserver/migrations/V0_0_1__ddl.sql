CREATE TABLE [dbo].[Audit_History](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityName] [varchar](255) NULL,
	[ActionPerformed] [varchar](255) NULL,
	[EntityContent] [varchar](4000) NULL,
	[ModifiedBy] [bigint] NULL,
	[ModifiedDate] [datetime2](0) NULL,
PRIMARY KEY ([Id])
);

CREATE TABLE [dbo].[CRMCategory](
	[categoryID] [bigint] IDENTITY(1,1) NOT NULL,
	[TrialID] [bigint] NOT NULL,
	[TrialName] [varchar](255) NULL,
	[SearchName] [varchar](255) NULL,
	[uuid] [varchar](255) NULL,
	[lookupCode] [varchar](255) NULL,
	[namedFilterID] [varchar](255) NULL,
	[filterName] [varchar](255) NULL,
	[errorCode] [varchar](255) NULL,
PRIMARY KEY ([categoryID])
);


CREATE TABLE [dbo].[CRMContact](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](255) NULL,
	[uuid] [varchar](255) NULL,
	[CategoryID] [bigint] NULL,
	[errorCode] [varchar](255) NULL,
PRIMARY KEY ([ID])
);


CREATE TABLE [dbo].[Participant](
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[EmailAddress] [varchar](312) NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[TrialVisits] [bigint] NULL,
	[TrialSponsors] [varchar](2000) NULL,
	[ParticipantId] [varchar](10) NOT NULL,
	[ZipCode] [varchar](20) NULL,
	[ContactNumber] [varchar](20) NULL,
	[DOB] [datetime] NULL,
	[Gender] [varchar](10) NULL,
	[Address] [varchar](256) NULL,
	[SMS] [bit] NULL,
	[City] [varchar](512) NULL,
	[State] [varchar](512) NULL,
	[PhoneType] [varchar](20) NULL,
	[Voicemail] [bit] NULL,
	[PreferredTimeOfContact] [varchar](45) NULL,
	[Session] [varchar](10) NULL,
	[IsPreferredEmail] [bit] NULL,
	[IsPreferredPhone] [bit] NULL,
	[IsPreferredMail] [bit] NULL,
 CONSTRAINT [pk_participant] PRIMARY KEY ([ParticipantId])
 );

CREATE TABLE [dbo].[ParticipantAppointment](
	[ParticipantAppointmentId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](10) NULL,
	[TrialId] [bigint] NULL,
	[AppointmentDate] [datetime] NULL,
	[AppointmentStatus] [varchar](200) NULL,
PRIMARY KEY ([ParticipantAppointmentId])
);


CREATE TABLE [dbo].[ParticipantQuestion](
	[ParticipantQuestionId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](10) NULL,
	[QuestionId] [bigint] NULL,
	[Answer] [varchar](255) NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[ParticipantQuestionnaireId] [bigint] NULL,
	PRIMARY KEY ([ParticipantQuestionId] )
);


CREATE TABLE [dbo].[ParticipantQuestionnaire](
	[ParticipantQuestionnaireId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](10) NULL,
	[QuestionnaireId] [bigint] NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[FutureTrialEmails] [bit] NULL,
	[QuestEmails] [bit] NULL,
	[StudySite] [varchar](5) NULL,
	[TrialOptStatus] [int] NULL,
	[RXMedStatus] [bit] NULL,
	[UserConsent] [bit] NULL,
	[Interest] [bit] NULL,
	[LastQuestionAnswered] [bigint] NULL,
	[IsNotifyOnSiteOpen] [bit] NULL,
	PRIMARY KEY ([ParticipantQuestionnaireId])
);


CREATE TABLE [dbo].[ParticipantStatus](
	[ParticipantStatusId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantStatusName] [varchar](250) NOT NULL,
	[CreatedBy] [bigint] NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [bigint] NULL,
	[UpdatedOn] [datetime2](0) NULL,
	PRIMARY KEY ([ParticipantStatusId] )
);


CREATE TABLE [dbo].[ParticipantStudySite](
	[ParticipantId] [varchar](10) NULL,
	[TrialId] [bigint] NULL,
	[StudySiteId] [bigint] NULL,
	[ParticipantStatusId] [bigint] NULL,
	[ParticipantStudySiteId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[StatusNotes] [varchar](255) NULL,
	[scoreJSON] [varchar](4000) NULL,
	[Createdby] [bigint] NULL,
	[Updatedby] [bigint] NULL
);


CREATE TABLE [dbo].[ParticipantStudySiteHistory](
	[ParticipantStudySiteHistoryId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](10) NULL,
	[TrialId] [bigint] NULL,
	[StudySiteId] [bigint] NULL,
	[ParticipantStatusId] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[StatusNotes] [varchar](255) NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[Notes] [varchar](4000) NULL,
	CONSTRAINT [pk_participantstudysitehistoryid] PRIMARY KEY ([ParticipantStudySiteHistoryId])
);

CREATE TABLE [dbo].[ParticipantTrial](
	[ParticipantTrialId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](10) NULL,
	[TrialId] [bigint] NULL,
	[ParticipantTrialStatus] [bit] NULL,
	PRIMARY KEY ([ParticipantTrialId])
);

CREATE TABLE [dbo].[TrialParticipantStatusAudit](
	[auditId] [bigint] IDENTITY(1,1) NOT NULL,
	[ParticipantId] [varchar](10) NULL,
	[TrialId] [bigint] NULL,
	[fromStatusId] [bigint] NULL,
	[toStatusId] [bigint] NULL,
	[CreatedOn] [datetime2](0) NULL,
	PRIMARY KEY ([auditId])
);


CREATE TABLE [dbo].[TrialStatusAudit](
	[auditId] [bigint] IDENTITY(1,1) NOT NULL,
	[TrialId] [bigint] NULL,
	[fromStatusId] [bigint] NULL,
	[toStatusId] [bigint] NULL,
	[minTime] [bigint] NULL,
	[maxTime] [bigint] NULL,
	[totalTime] [bigint] NULL,
	[participantCount] [bigint] NULL,
	[UpdatedOn] [datetime2](0) NULL,
	PRIMARY KEY ([auditId])
);


CREATE INDEX [CRMCategory_TrialID] ON [dbo].[CRMCategory]  ([TrialID]);

CREATE INDEX [CRMContact_CategoryID] ON [dbo].[CRMCategory]([categoryID]);

CREATE INDEX [TrialParticipantStatusAudit_TRIAL] ON [dbo].[TrialParticipantStatusAudit]([TrialId],[ParticipantId] );

CREATE INDEX [TrialStatusAudit_TRIAL] ON [dbo].[TrialStatusAudit]([TrialId],[fromStatusId]);

ALTER TABLE [dbo].[Audit_History] ADD  DEFAULT (NULL) FOR [EntityName];

ALTER TABLE [dbo].[Audit_History] ADD  DEFAULT (NULL) FOR [ActionPerformed];

ALTER TABLE [dbo].[Audit_History] ADD  DEFAULT (NULL) FOR [EntityContent];

ALTER TABLE [dbo].[Audit_History] ADD  DEFAULT (NULL) FOR [ModifiedBy];

ALTER TABLE [dbo].[Audit_History] ADD  DEFAULT (NULL) FOR [ModifiedDate];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [TrialName];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [SearchName];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [uuid];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [lookupCode];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [namedFilterID];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [filterName];

ALTER TABLE [dbo].[CRMCategory] ADD  DEFAULT (NULL) FOR [errorCode];

ALTER TABLE [dbo].[CRMContact] ADD  DEFAULT (NULL) FOR [ParticipantId];

ALTER TABLE [dbo].[CRMContact] ADD  DEFAULT (NULL) FOR [uuid];

ALTER TABLE [dbo].[CRMContact] ADD  DEFAULT (NULL) FOR [CategoryID];

ALTER TABLE [dbo].[CRMContact] ADD  DEFAULT (NULL) FOR [errorCode];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [FirstName];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [LastName];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [CreatedBy];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [UpdatedBy];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [TrialVisits];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [TrialSponsors];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT ('0') FOR [ContactNumber];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [DOB];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [Gender];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [Address];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT ('0') FOR [SMS];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [PhoneType];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [Voicemail];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [PreferredTimeOfContact];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT (NULL) FOR [Session];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT ((0)) FOR [IsPreferredEmail];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT ((0)) FOR [IsPreferredPhone];

ALTER TABLE [dbo].[Participant] ADD  DEFAULT ((0)) FOR [IsPreferredMail];

ALTER TABLE [dbo].[ParticipantAppointment] ADD  DEFAULT (NULL) FOR [TrialId];

ALTER TABLE [dbo].[ParticipantAppointment] ADD  DEFAULT (NULL) FOR [AppointmentStatus];

ALTER TABLE [dbo].[ParticipantQuestion] ADD  DEFAULT (NULL) FOR [QuestionId];

ALTER TABLE [dbo].[ParticipantQuestion] ADD  DEFAULT (NULL) FOR [Answer];

ALTER TABLE [dbo].[ParticipantQuestion] ADD  DEFAULT (NULL) FOR [CreatedBy];

ALTER TABLE [dbo].[ParticipantQuestion] ADD  DEFAULT (NULL) FOR [UpdatedBy];

ALTER TABLE [dbo].[ParticipantQuestion] ADD  DEFAULT (NULL) FOR [ParticipantQuestionnaireId];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT (NULL) FOR [QuestionnaireId];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT (NULL) FOR [CreatedBy];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT (NULL) FOR [UpdatedBy];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT (NULL) FOR [CreatedOn];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT (NULL) FOR [UpdatedOn];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT ((0)) FOR [FutureTrialEmails];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT ((0)) FOR [QuestEmails];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT (NULL) FOR [StudySite];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT ((0)) FOR [TrialOptStatus];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  CONSTRAINT [df_RXMedStatus]  DEFAULT ((0)) FOR [RXMedStatus];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  CONSTRAINT [df_UserConsent]  DEFAULT ((0)) FOR [UserConsent];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  CONSTRAINT [df_Interest]  DEFAULT ((0)) FOR [Interest];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT ((0)) FOR [LastQuestionAnswered];

ALTER TABLE [dbo].[ParticipantQuestionnaire] ADD  DEFAULT ((0)) FOR [IsNotifyOnSiteOpen];

ALTER TABLE [dbo].[ParticipantStatus] ADD  DEFAULT (NULL) FOR [CreatedBy];

ALTER TABLE [dbo].[ParticipantStatus] ADD  DEFAULT (NULL) FOR [CreatedOn];

ALTER TABLE [dbo].[ParticipantStatus] ADD  DEFAULT (NULL) FOR [UpdatedBy];

ALTER TABLE [dbo].[ParticipantStatus] ADD  DEFAULT (NULL) FOR [UpdatedOn];

ALTER TABLE [dbo].[ParticipantStudySite] ADD  DEFAULT (NULL) FOR [TrialId];

ALTER TABLE [dbo].[ParticipantStudySite] ADD  DEFAULT (NULL) FOR [StudySiteId];

ALTER TABLE [dbo].[ParticipantStudySite] ADD  CONSTRAINT [df_ParticipantStudySite_CreatedBy]  DEFAULT (NULL) FOR [Createdby];

ALTER TABLE [dbo].[ParticipantStudySite] ADD  CONSTRAINT [df_ParticipantStudySite_UpdatedBy]  DEFAULT (NULL) FOR [Updatedby];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [ParticipantId];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [TrialId];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [StudySiteId];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [ParticipantStatusId];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [CreatedOn];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [UpdatedOn];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [StatusNotes];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [CreatedBy];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [UpdatedBy];

ALTER TABLE [dbo].[ParticipantStudySiteHistory] ADD  DEFAULT (NULL) FOR [Notes];

ALTER TABLE [dbo].[ParticipantTrial] ADD  DEFAULT (NULL) FOR [TrialId];

ALTER TABLE [dbo].[ParticipantTrial] ADD  CONSTRAINT [df_ParticipantTrial_ParticipantTrialStatus]  DEFAULT (NULL) FOR [ParticipantTrialStatus];

ALTER TABLE [dbo].[TrialParticipantStatusAudit] ADD  DEFAULT (getdate()) FOR [CreatedOn];

ALTER TABLE [dbo].[TrialStatusAudit] ADD  DEFAULT (getdate()) FOR [UpdatedOn];