
SET IDENTITY_INSERT participantappointment ON;

INSERT INTO participantappointment(ParticipantAppointmentId,ParticipantId,TrialId,AppointmentDate,AppointmentStatus) VALUES (1,'1',4,getdate(),'pending');
INSERT INTO participantappointment(ParticipantAppointmentId,ParticipantId,TrialId,AppointmentDate,AppointmentStatus) VALUES (2,'2',4,getdate(),'pending');

SET IDENTITY_INSERT participantappointment OFF;

SET IDENTITY_INSERT participantstatus ON;

INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (1,'Identified',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (2,'Screening',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (3,'Referred',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (4,'Enrolled',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (5,'Outreached',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (6,'Site Contacting',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (7,'Visit Scheduled',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (8,'Visited',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (9,'Consented',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (10,'Not Qualified',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (11,'Not Interested',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (12,'Completed',NULL,getdate(),NULL,getdate());

SET IDENTITY_INSERT participantstatus OFF;
