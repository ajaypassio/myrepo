CREATE TABLE [dbo].[CRMContactJob](
	[CRMContactJobId] [bigint] NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[SearchName] [nvarchar](512) NOT NULL,
	[ContactJson] [nvarchar](MAX) NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_CRMContactJob] PRIMARY KEY CLUSTERED 
(
	[CRMContactJobId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF_CRMContactJob_CreatedBy]  DEFAULT (NULL) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF_CRMContactJob_UpdatedBy]  DEFAULT (NULL) FOR [UpdatedBy]
GO