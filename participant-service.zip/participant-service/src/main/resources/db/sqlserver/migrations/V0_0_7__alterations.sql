Alter table CRMContactJob add InProcess bit default 0;

declare @constriantName nvarchar(512),@tableName nvarchar(512),@columnName nvarchar(512);
set @tableName='crmcontactjob';
set @columnName='FailedBatches';
SELECT 
    @constriantName=default_constraints.name
FROM 
    sys.all_columns

        INNER JOIN
    sys.tables
        ON all_columns.object_id = tables.object_id

        INNER JOIN 
    sys.schemas
        ON tables.schema_id = schemas.schema_id

        INNER JOIN
    sys.default_constraints
        ON all_columns.default_object_id = default_constraints.object_id

WHERE 
        schemas.name = 'dbo'
    AND tables.name = @tableName
    AND all_columns.name = @columnName;
print @constriantName;
if(@constriantName !='')
begin
	exec('alter table '+@tableName+' drop constraint '+@constriantName);
end;

Alter table CRMContactJob drop column FailedBatches;

CREATE TABLE [dbo].[CRMContactJobBatch](
	[CRMContactJobBatchId] [bigint] NOT NULL,
	[CRMContactJobId] [bigint] NOT NULL,
	[IsBatchCompleted] [bit] NOT NULL,
	[BatchId] [int] NOT NULL default 1,
 CONSTRAINT [PK_CRMContactJobBatch] PRIMARY KEY CLUSTERED 
(
	[CRMContactJobBatchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  CONSTRAINT [DF_CRMContactJobBatch_IsBatchCompleted]  DEFAULT ((0)) FOR [IsBatchCompleted]
GO

ALTER TABLE [dbo].[CRMContactJobBatch]  WITH CHECK ADD  CONSTRAINT [FK_CRMContactJobBatch_CRMContactJobBatch] FOREIGN KEY([CRMContactJobId])
REFERENCES [dbo].[CRMContactJob] ([CRMContactJobId])
GO

ALTER TABLE [dbo].[CRMContactJobBatch] CHECK CONSTRAINT [FK_CRMContactJobBatch_CRMContactJobBatch]
GO

alter table crmcontactjobbatch add batchSize int default null;
alter table crmcontactjobbatch add CreatedBy bigint default null;
alter table crmcontactjobbatch add UpdatedBy bigint default null;

alter table crmcontactjobbatch add CreatedOn datetime default null;
alter table crmcontactjobbatch add UpdatedOn datetime default null;