
drop table CRMContactJobBatch;
drop table CRMContactJob;

CREATE TABLE [dbo].[CRMContactJob](
	[CRMContactJobId] [bigint] IDENTITY(1,1) NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[SearchName] [nvarchar](512) NOT NULL,
	[ContactJson] [nvarchar](max) NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[lastPartcipantId] [bigint] NULL,
	[JobStatus] [nvarchar](50) NULL,
	[LastBatchId] [bigint] NULL,
	[InProcess] [bit] NULL,
 CONSTRAINT [PK_CRMContactJob] PRIMARY KEY CLUSTERED 
(
	[CRMContactJobId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF_CRMContactJob_CreatedBy]  DEFAULT (NULL) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF_CRMContactJob_UpdatedBy]  DEFAULT (NULL) FOR [UpdatedBy]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF__CRMContac__lastP]  DEFAULT (NULL) FOR [lastPartcipantId]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF__CRMContac__LastB]  DEFAULT (NULL) FOR [LastBatchId]
GO

ALTER TABLE [dbo].[CRMContactJob] ADD  CONSTRAINT [DF__CRMContac__InPro]  DEFAULT ((0)) FOR [InProcess]
GO



CREATE TABLE [dbo].[CRMContactJobBatch](
	[CRMContactJobBatchId] [bigint] IDENTITY(1,1)  NOT NULL,
	[CRMContactJobId] [bigint] NOT NULL,
	[IsBatchCompleted] [bit] NOT NULL,
	[BatchId] [int] NOT NULL,
	[batchSize] [int] NULL,
	[CreatedBy] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK_CRMContactJobBatch] PRIMARY KEY CLUSTERED 
(
	[CRMContactJobBatchId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  CONSTRAINT [DF_CRMContactJobBatch_IsBatchCompleted]  DEFAULT ((0)) FOR [IsBatchCompleted]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  DEFAULT ((1)) FOR [BatchId]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  DEFAULT (NULL) FOR [batchSize]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  DEFAULT (NULL) FOR [CreatedBy]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  DEFAULT (NULL) FOR [UpdatedBy]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  DEFAULT (NULL) FOR [CreatedOn]
GO

ALTER TABLE [dbo].[CRMContactJobBatch] ADD  DEFAULT (NULL) FOR [UpdatedOn]
GO

ALTER TABLE [dbo].[CRMContactJobBatch]  WITH CHECK ADD  CONSTRAINT [FK_CRMContactJobBatch_CRMContactJobBatch] FOREIGN KEY([CRMContactJobId])
REFERENCES [dbo].[CRMContactJob] ([CRMContactJobId])
GO

ALTER TABLE [dbo].[CRMContactJobBatch] CHECK CONSTRAINT [FK_CRMContactJobBatch_CRMContactJobBatch]
GO



