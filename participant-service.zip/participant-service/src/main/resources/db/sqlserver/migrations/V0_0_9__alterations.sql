alter table CRMContactJob add BatchId int default 0;
alter table CRMContactJob add BatchSize int default 0;
alter table CRMContactJob add TrialName nvarchar(MAX);


declare @constriantName nvarchar(512),@tableName nvarchar(512),@columnName nvarchar(512);
set @tableName='crmcontactjob';
set @columnName='LastPartcipantId';
SELECT 
    @constriantName=default_constraints.name
FROM 
    sys.all_columns

        INNER JOIN
    sys.tables
        ON all_columns.object_id = tables.object_id

        INNER JOIN 
    sys.schemas
        ON tables.schema_id = schemas.schema_id

        INNER JOIN
    sys.default_constraints
        ON all_columns.default_object_id = default_constraints.object_id

WHERE 
        schemas.name = 'dbo'
    AND tables.name = @tableName
    AND all_columns.name = @columnName;
print @constriantName;
if(@constriantName !='')
begin
	exec('alter table '+@tableName+' drop constraint '+@constriantName);
end;

Alter table CRMContactJob alter column LastPartcipantId nvarchar(Max);

alter table CRMContactJob add FailedAttempt int default 0;

drop table CRMContactJobBatch;