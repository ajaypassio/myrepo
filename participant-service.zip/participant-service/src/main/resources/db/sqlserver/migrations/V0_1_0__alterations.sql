SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ParticipantJob](
	[JobId] [bigint] IDENTITY(1,1) NOT NULL,
	[SavedSearchName] [varchar](512)  NOT NULL,
	[TrialId] [bigint] NOT NULL,
	[TrialName] [varchar](512) NOT NULL,
	[CorrelationId] varchar(128) DEFAULT NULL,
	[ParticipantJson] varchar(max) DEFAULT NULL,
	[IsCategoryCreated] int DEFAULT 0,
	[IsSaved] int DEFAULT 0,
	[IsContactsPushed] int DEFAULT 0,
	[totalContactBatchCount] int DEFAULT 0,
	[CreatedBy] varchar(128) NULL,
	[CreatedOn] [datetime] NULL
PRIMARY KEY CLUSTERED 
(
	[JobId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO