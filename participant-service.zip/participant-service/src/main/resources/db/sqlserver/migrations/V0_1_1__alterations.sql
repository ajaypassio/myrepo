alter TABLE [ParticipantJob]
add [BatchStatus] varchar(512) default '';