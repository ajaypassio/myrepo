DECLARE @ConstraintName nvarchar(2000);
SELECT @ConstraintName = Name FROM SYS.DEFAULT_CONSTRAINTS WHERE PARENT_OBJECT_ID = OBJECT_ID('ParticipantStudySite')
 AND PARENT_COLUMN_ID = (SELECT column_id FROM sys.columns WHERE NAME = N'Notes' AND object_id = OBJECT_ID(N'ParticipantStudySite'));
 print @ConstraintName;
IF @ConstraintName IS NOT NULL
EXEC('ALTER TABLE ParticipantStudySite DROP CONSTRAINT ' + @ConstraintName);

alter table ParticipantStudySite alter column Notes nvarchar(MAX);


SELECT @ConstraintName = Name FROM SYS.DEFAULT_CONSTRAINTS WHERE PARENT_OBJECT_ID = OBJECT_ID('ParticipantStudySiteHistory')
 AND PARENT_COLUMN_ID = (SELECT column_id FROM sys.columns WHERE NAME = N'Notes' AND object_id = OBJECT_ID(N'ParticipantStudySiteHistory'));
 print @ConstraintName;
IF @ConstraintName IS NOT NULL
EXEC('ALTER TABLE ParticipantStudySiteHistory DROP CONSTRAINT ' + @ConstraintName);

alter table ParticipantStudySiteHistory alter column Notes nvarchar(MAX);