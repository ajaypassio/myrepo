alter TABLE [ParticipantJob]
add [IsDisabled] int DEFAULT 0;

alter TABLE [ParticipantJob]
add [AttemptsMade] int DEFAULT 0;

alter TABLE [ParticipantJob]
add [UpdatedOn] [datetime] NULL;
GO

update [ParticipantJob]
set [IsDisabled]='0'

update [ParticipantJob]
set [AttemptsMade]='0'

update [ParticipantJob]
set [UpdatedOn]= GETDATE();