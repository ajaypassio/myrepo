/*
 Pre-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be executed before the build script.	
 Use SQLCMD syntax to include a file in the pre-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the pre-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
ALTER TABLE PARTICIPANTSTUDYSITE ADD SearchName VARCHAR(250);

CREATE INDEX Idx_PARTICIPANTID_TRIALID ON PARTICIPANTSTUDYSITE (ParticipantId, TrialId);

--FOLLOWING SCRIPTS UPDATE PARTICIPANT TABLE
ALTER TABLE [dbo].[Participant] DROP CONSTRAINT [pk_participant];

ALTER TABLE PARTICIPANT ALTER COLUMN EmailAddress VARCHAR(250) NOT NULL;

ALTER TABLE PARTICIPANT ALTER COLUMN ParticipantId VARCHAR(50) NOT NULL;

ALTER TABLE [dbo].[Participant] ADD  CONSTRAINT [pk_participant] PRIMARY KEY CLUSTERED 
(
	[ParticipantId] ASC
);

/*
DESCRIPTION
--------------------------------------------------------------------------------------
This Table Value (type) is used to bulk load participants.
--------------------------------------------------------------------------------------

AUTHOR & CHANGE LOG
--------------------------------------------------------------------------------------
author: bruce.a.boucard@questdiagnotics
date: 3-APR-2019

changes:
date/author: 3-APR-2019 bruce.a.boucard@questdiagnostics.com 
description: Initial

--------------------------------------------------------------------------------------
*/
CREATE TYPE [dbo].[ParticipantTVP] AS TABLE(
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[EmailAddress] [varchar](250) NULL,
	[ParticipantId] [varchar](50) NOT NULL,
	[ZipCode] [varchar](20) NULL,
	[ContactNumber] [varchar](20) NULL,
	[DOB] [datetime] NULL,
	[Gender] [varchar](10) NULL,
	[Address] [varchar](256) NULL,
	[City] [varchar](512) NULL,
	[State] [varchar](512) NULL,
	[TrialId] [int] NOT NULL,
	[SearchName] [varchar](250) NULL,
	[ScoreJson] [varchar](Max) NULL
);


/*
DESCRIPTION
--------------------------------------------------------------------------------------
This Table Value (type) is used to bulk load of Participant study site mapping.
--------------------------------------------------------------------------------------

AUTHOR & CHANGE LOG
--------------------------------------------------------------------------------------
author: bruce.a.boucard@questdiagnotics
date: 3-APR-2019

changes:
date/author: 3-APR-2019 bruce.a.boucard@questdiagnostics.com 
description: Initial

--------------------------------------------------------------------------------------
*/
CREATE TYPE [dbo].[ParticipantStudySiteTVP] AS TABLE 
(
	[ParticipantId] [varchar](50) NULL,
	[TrialId] INT NULL ,
	[StudySiteId] INT NULL,
	[ParticipantStatusId] INT NULL,
	[ParticipantStudySiteId] [bigint] NULL,
	[StatusNotes] [varchar](255) NULL,
	[scoreJSON] [varchar](max) NULL,	
	[CreatedOn] [datetime] NULL,
	[UpdatedOn] [datetime] NULL,
	[Createdby] [bigint] NULL ,
	[Updatedby] [bigint] NULL ,
	[Notes] [nvarchar](max) NULL,
	[SearchName] [varchar](250) NULL
);



/*
DESCRIPTION
--------------------------------------------------------------------------------------
This stored procedure defines logic to add/update participant records and map those participants to study site 
based on trial id
--------------------------------------------------------------------------------------

AUTHOR & CHANGE LOG
--------------------------------------------------------------------------------------
author: bruce.a.boucard@questdiagnotics
date: 3-APR-2019

changes:
date/author: 3-APR-2019 bruce.a.boucard@questdiagnostics.com 
description: Initial

--------------------------------------------------------------------------------------
*/

IF OBJECT_ID('[dbo].[usp_AddMapParticipantsToSites]', 'P') IS NOT NULL
    DROP PROCEDURE [dbo].[usp_AddMapParticipantsToSites];  
GO
CREATE PROCEDURE [dbo].[usp_AddMapParticipantsToSites] @p_participantType AS [dbo].[ParticipantTVP] READONLY
AS
     SET NOCOUNT ON;

/***
DECLARE LOCAL VARIABLE
***/

     DECLARE @lv_participantType AS ParticipantTVP, @lv_retryCount INT, @lv_success BIT, @lv_auditmsg VARCHAR(250)= NULL,@lv_action VARCHAR(50), @lv_username VARCHAR(50)= NULL, @lv_errorNumber INT, @lv_errorMsg VARCHAR(2000)= NULL, @lv_participantStudySiteTvp AS PARTICIPANTSTUDYSITETVP, @lv_totalProcessed INT, @lv_participantDefaultStatus INT;
     SELECT @lv_retryCount = 1, 
            @lv_success = 0;
     SELECT @lv_participantDefaultStatus = [ParticipantStatusId]
     FROM [dbo].[ParticipantStatus]
     WHERE [ParticipantStatusName] = 'Identified';

/**
 INPUT RECORD FOR MERGE STATEMENT MUST BE UNIQUE. THE FOLLOWING SNIPPET OF CODE DE-DUPES THE RECORD FOR PARTICIPANT INSERT/UPDATE
*/

     INSERT INTO @lv_participantType
     ([ParticipantId], 
      [FirstName], 
      [LastName], 
      [EmailAddress], 
      [ZipCode], 
      [ContactNumber], 
      [DOB], 
      [Gender], 
      [Address], 
      [City], 
      [State], 
      [TrialId], 
      [SearchName], 
      [ScoreJson]
     )
            SELECT [ParticipantId], 
                   [FirstName], 
                   [LastName], 
                   [EmailAddress], 
                   [ZipCode], 
                   [ContactNumber], 
                   [DOB], 
                   [Gender], 
                   [Address], 
                   [City], 
                   [State], 
                   [TrialId], 
                   [SearchName], 
                   [ScoreJson]
            FROM
            (
                SELECT ROW_NUMBER() OVER(PARTITION BY [ParticipantId]
                       ORDER BY [ParticipantId]) num, 
                       p.*
                FROM @p_participantType p
            ) r
            WHERE r.num = 1;

			SELECT @lv_totalProcessed = COUNT(1) FROM @lv_participantType;
			SELECT TOP 1 @lv_auditmsg = 'PROCESSED ' + CAST(@lv_totalProcessed as varchar(10)) + ' FOR ' + CONCAT([TrialId],'-',[SearchName]) FROM @lv_participantType
			SET @lv_action	  = 'BULKINSERT'

/** 
		Run transaction in Retry Block
	**/

     WHILE @lv_retryCount <= 3
           AND @lv_success = 0
         BEGIN
             BEGIN TRANSACTION;
             BEGIN TRY

/**
				Update Partipant table
			 **/

                 MERGE [dbo].[Participant] AS TARGET
                 USING @lv_participantType AS SOURCE
                 ON TARGET.participantId = SOURCE.participantId
                     WHEN MATCHED
                     THEN UPDATE SET 
                                     TARGET.[FirstName] = SOURCE.[FirstName], 
                                     TARGET.[LastName] = SOURCE.[LastName], 
                                     TARGET.[EmailAddress] = SOURCE.[EmailAddress], 
                                     TARGET.[ZipCode] = SOURCE.[ZipCode], 
                                     TARGET.[ContactNumber] = SOURCE.[ContactNumber], 
                                     TARGET.[DOB] = SOURCE.[DOB], 
                                     TARGET.[Gender] = SOURCE.[Gender], 
                                     TARGET.[Address] = SOURCE.[Address], 
                                     TARGET.[City] = SOURCE.[City], 
                                     TARGET.[State] = SOURCE.[State], 
                                     TARGET.[UpdatedOn] = GETDATE(), 
                                     TARGET.[UpdatedBy] = 0 --TODO update to reflect user Id

                     WHEN NOT MATCHED BY TARGET
                     THEN
                       INSERT([ParticipantId], 
                              [FirstName], 
                              [LastName], 
                              [EmailAddress], 
                              [ZipCode], 
                              [ContactNumber], 
                              [DOB], 
                              [Gender], 
                              [Address], 
                              [City], 
                              [State], 
                              [CreatedOn], 
                              [CreatedBy], 
                              [UpdatedOn], 
                              [UpdatedBy])
                       VALUES
                 (SOURCE.[ParticipantId], 
                  SOURCE.[FirstName], 
                  SOURCE.[LastName], 
                  SOURCE.[EmailAddress], 
                  SOURCE.[ZipCode], 
                  SOURCE.[ContactNumber], 
                  SOURCE.[DOB], 
                  SOURCE.[Gender], 
                  SOURCE.[Address], 
                  SOURCE.[City], 
                  SOURCE.[State], 
                  GETDATE(), 
                  0, --@lv_username,
                  GETDATE(), 
                  0 --@lv_username
                 );

/**
				Participant Study Site
			 **/

                 INSERT INTO @lv_participantStudySiteTvp
                 ([ParticipantId], 
                  [TrialId], 
                  [StudySiteId], 
                  [ParticipantStatusId], 
                  [scoreJSON], 
                  [SearchName]
                 )
                        SELECT [ParticipantId], 
                               [TrialId], 
                               NULL, 
                               @lv_participantDefaultStatus, 
                               [ScoreJson], 
                               [SearchName]
                        FROM
                        (
                            SELECT ROW_NUMBER() OVER(PARTITION BY [ParticipantId], 
                                                                  [TrialId]
                                   ORDER BY [ParticipantId]) num, 
                                   p.*
                            FROM @p_participantType p
                        ) r
                        WHERE r.num = 1;
                 MERGE [dbo].[ParticipantStudySite] AS TARGET
                 USING @lv_participantStudySiteTvp AS SOURCE
                 ON TARGET.participantId = SOURCE.participantId
                    AND TARGET.TrialId = SOURCE.TrialId
                     WHEN MATCHED
                     THEN UPDATE SET 
                                     TARGET.[ScoreJSON] = SOURCE.[ScoreJSON], 
                                     TARGET.[SearchName] = SOURCE.[SearchName], 
                                     TARGET.[UpdatedOn] = GETDATE(), 
                                     TARGET.[UpdatedBy] = 0 --TODO update to reflect user Id
                     WHEN NOT MATCHED BY TARGET
                     THEN
                       INSERT([ParticipantId], 
                              [TrialId], 
                              [ParticipantStatusId], 
                              [scoreJSON], 
							  [SearchName],
                              [CreatedOn], 
                              [CreatedBy], 
                              [UpdatedOn], 
                              [UpdatedBy])
                       VALUES
                 (SOURCE.[ParticipantId], 
                  SOURCE.[TrialId], 
                  SOURCE.[ParticipantStatusId], 
                  SOURCE.[scoreJSON], 
				  SOURCE.[SearchName],
                  GETDATE(), 
                  0, --@lv_username,
                  GETDATE(), 
                  0 --@lv_username
                 );

				 --Insert audit record
				 INSERT INTO audit_history (ENTITYNAME, ENTITYCONTENT,ACTIONPERFORMED, MODIFIEDBY, MODIFIEDDATE) VALUES ('Participant',@lv_auditmsg,@lv_action,0,GETDATE());

                 COMMIT TRANSACTION;
                 SET @lv_success = 1;
             END TRY
             BEGIN CATCH
                 ROLLBACK TRANSACTION;
                 SELECT @lv_errorNumber = ERROR_NUMBER(), 
                        @lv_errorMsg = ERROR_MESSAGE();
                 IF ERROR_NUMBER() IN(1204, -- SqlOutOfLocks
                 1205, -- SqlDeadlockVictim
                 1222 -- SqlLockRequestTimeout
                 )
                     BEGIN
                         SET @lv_retryCount = @lv_retryCount + 1;
                 END;
                     ELSE
                     BEGIN
                         THROW;
                 END;
             END CATCH;
         END;
     IF @lv_errorNumber > 0
         BEGIN
             RETURN @lv_errorNumber;
     END;
         ELSE
         RETURN 0;
