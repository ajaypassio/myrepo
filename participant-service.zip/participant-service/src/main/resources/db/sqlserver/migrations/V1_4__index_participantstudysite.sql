DROP INDEX IF EXISTS [udx_partstudysite_siteid_partid] ON [dbo].[participantstudysite]
GO
CREATE NONCLUSTERED INDEX udx_partstudysite_siteid_partid on participantstudysite (studySiteId,participantStatusId);

DROP INDEX IF EXISTS [udx_partstudysite_trialid_partid] ON [dbo].[participantstudysite]
GO
CREATE NONCLUSTERED INDEX udx_partstudysite_trialid_partid on participantstudysite (trialid,ParticipantStatusId);

DROP INDEX IF EXISTS [udx_partstudysite_trialid_pid] ON [dbo].[participantstudysite]
GO
CREATE NONCLUSTERED INDEX udx_partstudysite_trialid_pid on participantstudysite (trialid,ParticipantId);

IF OBJECT_ID('udc_primarykey', 'PK') IS NOT NULL 
    ALTER TABLE participantstudysite DROP CONSTRAINT udc_primarykey

GO		
ALTER TABLE participantstudysite ADD CONSTRAINT udc_primarykey PRIMARY KEY ([ParticipantStudySiteId]); 