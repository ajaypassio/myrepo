
--CRMCategory
DROP INDEX IF EXISTS [udx_CRMCategory_sName_lCode] ON [dbo].[CRMCategory]
GO
CREATE NONCLUSTERED INDEX udx_CRMCategory_sName_lCode on CRMCategory (SearchName,lookupCode);

DROP INDEX IF EXISTS [udx_CRMCategory_tId_tName] ON [dbo].[CRMCategory]
GO
CREATE NONCLUSTERED INDEX udx_CRMCategory_tId_tName on CRMCategory (TrialID,TrialName);

DROP INDEX IF EXISTS [CRMContact_CategoryID] ON [dbo].[CRMCategory]
GO
DROP INDEX IF EXISTS [CRMCategory_TrialID] ON [dbo].[CRMCategory]
GO

--CRMContact
DROP INDEX IF EXISTS [udx_CRMContact_pId_cId] ON [dbo].[CRMContact]
GO
CREATE NONCLUSTERED INDEX udx_CRMContact_pId_cId on CRMContact (ParticipantId,CategoryID);

--Participant : TrialID Does not exist
DROP INDEX IF EXISTS [udx_Participant_email] ON [dbo].[Participant]
GO
CREATE NONCLUSTERED INDEX udx_Participant_email on Participant  (EmailAddress);

DROP INDEX IF EXISTS [udx_Participant_lName_fName] ON [dbo].[Participant]
GO
CREATE NONCLUSTERED INDEX udx_Participant_lName_fName on Participant  (LastName,FirstName);

--ParticipantAppointment
DROP INDEX IF EXISTS [udx_ParticipantAppointment_pId_tId] ON [dbo].[ParticipantAppointment]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantAppointment_pId_tId on ParticipantAppointment  (ParticipantId,TrialID);

--ParticipantQuestion
DROP INDEX IF EXISTS [udx_ParticipantQuestion_pId_qId] ON [dbo].[ParticipantQuestion]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantQuestion_pId_qId on ParticipantQuestion  (ParticipantId,QuestionId);

--ParticipantQuestionnaire :
DROP INDEX IF EXISTS [udx_ParticipantQuestionnaire_qId_pId] ON [dbo].[ParticipantQuestionnaire]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantQuestionnaire_qId_pId on ParticipantQuestionnaire  (QuestionnaireId,ParticipantId);

DROP INDEX IF EXISTS [udx_ParticipantQuestionnaire_pId] ON [dbo].[ParticipantQuestionnaire]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantQuestionnaire_pId on ParticipantQuestionnaire  (ParticipantId);


--ParticipantStudySiteHistory  :
DROP INDEX IF EXISTS [udx_ParticipantStudySiteHistory_pId_tId_ssId] ON [dbo].[ParticipantStudySiteHistory]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantStudySiteHistory_pId_tId_ssId on ParticipantStudySiteHistory (ParticipantId,TrialId,StudySiteId);

DROP INDEX IF EXISTS [udx_ParticipantStudySiteHistory_tId] ON [dbo].[ParticipantStudySiteHistory]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantStudySiteHistory_tId on ParticipantStudySiteHistory (TrialId);

--ParticipantTrial  :
DROP INDEX IF EXISTS [udx_ParticipantTrial_tId_pId] ON [dbo].[ParticipantTrial]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantTrial_tId_pId on ParticipantTrial (TrialId,ParticipantId);

--TrialParticipantStatusAudit 
DROP INDEX IF EXISTS [udx_TrialParticipantStatusAudit_pId_tId_fsId_tsId] ON [dbo].[TrialParticipantStatusAudit]
GO
CREATE NONCLUSTERED INDEX udx_TrialParticipantStatusAudit_pId_tId_fsId_tsId on TrialParticipantStatusAudit (ParticipantId,TrialId,fromStatusId,toStatusId);

--TrialStatusAudit 
DROP INDEX IF EXISTS [udx_TrialStatusAudit_tId] ON [dbo].[TrialStatusAudit]
GO
CREATE NONCLUSTERED INDEX udx_TrialStatusAudit_tId on TrialStatusAudit (TrialId);

DROP INDEX IF EXISTS [udx_TrialStatusAudit_tId__fsId_tsId] ON [dbo].[TrialStatusAudit]
GO
CREATE NONCLUSTERED INDEX udx_TrialStatusAudit_tId__fsId_tsId on TrialStatusAudit (TrialId,fromStatusId,toStatusId);

--ParticipantStatus
DROP INDEX IF EXISTS [udx_ParticipantStatus_psName] ON [dbo].[ParticipantStatus]
GO
CREATE NONCLUSTERED INDEX udx_ParticipantStatus_psName on ParticipantStatus (ParticipantStatusName);



















