Update participantstatus set participantstatusName='New' where participantstatusid=3;
