
delete from participantstatus where Participantstatusname = 'Outreached';
delete from dbo.participantstatus where Participantstatusname = 'Screening';

SET IDENTITY_INSERT participantstatus ON;

INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (2,'Outreached',NULL,getdate(),NULL,getdate());
INSERT INTO participantstatus(participantstatusid,participantstatusname,createdby,createdon,updatedby,updatedon) VALUES (5,'Screening',NULL,getdate(),NULL,getdate());

SET IDENTITY_INSERT participantstatus OFF;