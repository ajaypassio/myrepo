alter table CampaignMaster drop column ReminderId;
alter table Reminder add SprinttCampaignId bigint;

