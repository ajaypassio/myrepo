alter table CampaignMaster add LastAction Varchar(100);
alter table CampaignMaster add NextAction Varchar(100);
