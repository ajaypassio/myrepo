alter table Participant add ContactId varchar(50) NULL;
alter table Participant alter column  EmailAddress varchar(250) NULL;