alter table CampaignMaster
Alter column CreatedOn Varchar(50)