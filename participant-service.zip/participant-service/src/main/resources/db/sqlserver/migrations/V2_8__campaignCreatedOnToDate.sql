alter table CampaignMaster drop column CreatedOn;
alter table CampaignMaster add CreatedOn [datetime2](0);
