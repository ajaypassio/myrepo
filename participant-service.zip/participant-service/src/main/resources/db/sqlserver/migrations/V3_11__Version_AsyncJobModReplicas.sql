ALTER TABLE AsyncJobModReplicas DROP CONSTRAINT DF_AsyncJobModReplicas_ForceMod;
ALTER TABLE AsyncJobModReplicas DROP COLUMN ForceMod;