alter table [CampaignAsyncJob] add JobType [tinyint] not null DEFAULT ((0));
	
