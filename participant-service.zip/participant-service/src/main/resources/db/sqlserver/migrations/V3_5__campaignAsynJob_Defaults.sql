ALTER TABLE [dbo].[CampaignAsyncJobBatch] ADD  CONSTRAINT [DF_CampaignAsyncJobBatch_BatchStatus]  DEFAULT ((0)) FOR [BatchStatus]
GO

ALTER TABLE [dbo].[CampaignAsyncJobBatch] ADD  CONSTRAINT [DF_CampaignAsyncJobBatch_BatchSize]  DEFAULT ((0)) FOR [BatchSize]
GO