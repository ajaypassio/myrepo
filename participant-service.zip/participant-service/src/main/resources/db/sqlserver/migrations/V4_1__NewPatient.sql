ALTER TABLE PatientConsent add  [TokenRequest] BIT;

ALTER TABLE ParticipantQuestionnaire ALTER COLUMN ParticipantId VARCHAR (255) ;

ALTER TABLE ParticipantQuestion ALTER COLUMN ParticipantId VARCHAR (255) ;

ALTER TABLE ParticipantStudySite ALTER COLUMN ParticipantId VARCHAR (255) ;

--ALTER TABLE Participant ALTER COLUMN ParticipantId VARCHAR (255) ;

ALTER TABLE ParticipantStudySiteHistory ALTER COLUMN ParticipantId VARCHAR (255) ;