ALTER TABLE ConsentEmailTransaction ADD EmpiId varchar(100);
ALTER TABLE ConsentEmailTransaction ADD SprintthipaaUuid varchar(100);
ALTER TABLE ConsentEmailTransaction ADD RevocationToken bigint; 