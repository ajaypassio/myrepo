Alter table Participant  add MiddleName varchar(50) NULL;
Alter table Participant add  AddressLine2 varchar(250) NULL;