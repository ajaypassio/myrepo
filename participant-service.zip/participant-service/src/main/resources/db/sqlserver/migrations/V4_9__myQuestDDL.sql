SELECT * INTO dbo.CampaignMaster_Backup from dbo.CampaignMaster; 
DROP TABLE dbo.CampaignMaster;

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
CREATE TABLE [dbo].[CampaignMaster](
	[SprinttCampaignId] [bigint] NOT NULL,
	[CampaignId] [varchar](512) NULL,
	[CampaignName] [varchar](512) NULL,
	[SegmentId] [bigint] NULL,
	[TrialId] [bigint] NOT NULL,
	[ScheduleId] [bigint] NULL,
	[EmailTemplateId] [bigint] NULL,
	[Channel] [tinyint] NULL,
	[CampaignStatusId] [int] NULL,
	[EloCampgnStatusId] [int] NULL,
	[CampaignJobStatusId] [int] NULL,
	[QuestionnaireId] [int] NULL,
	[InclusionCriteria] [text] NULL,
	[ExclusionCriteria] [text] NULL,
	[PortalLink] [text] NULL,
	[CreatedBy] [varchar](255) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	[LastAction] [varchar](100) NULL,
	[NextAction] [varchar](100) NULL,
	[Remarks] [nvarchar](max) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[ReminderJobStatusId] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[SprinttCampaignId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[CampaignMaster] ADD  DEFAULT ((0)) FOR [ReminderJobStatusId]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE TABLE [dbo].[CampaignMasterMyQuest](
                [SprinttCampaignId] [bigint] NOT NULL, 
                [CampaignName] [varchar](512) NULL,  
                [TrialId] [bigint] NOT NULL,
                [StudyInfoId] [bigint] NULL,
				[Channel] [tinyint] NULL,
                [ScheduleId] [bigint] NULL,          
                [CampaignStatusId] [int] NULL,  
                [CampaignJobStatusId] [int] NULL,           
                [InclusionCriteria] [text] NULL,
                [ExclusionCriteria] [text] NULL,  
                [CreatedBy] [varchar](255) NULL,
                [UpdatedBy] [varchar](255) NULL,
                [UpdatedOn] [datetime2](0) NULL,
                [LastAction] [varchar](100) NULL,
                [NextAction] [varchar](100) NULL,
                [Remarks] [nvarchar](max) NULL,
                [CreatedOn] [datetime2](0) NULL,
                [RetryCount] int NOT NULL default(0),
                [isDifference] tinyint default(0),			
PRIMARY KEY CLUSTERED 
(
                [SprinttCampaignId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StudyInfo](
                [StudyInfoId] [bigint] IDENTITY(1,1) NOT NULL,
                [PatientHeadline] [varchar](512) NULL,
                [StudyMessage] [varchar](512) NULL,                          
                [StudyImageName] [varchar](100) NULL,
                [CreatedBy] [varchar](255) NULL,
                [CreatedOn] [datetime2](0) NULL,
                [UpdatedBy] [varchar](255) NULL,
                [UpdatedOn] [datetime2](0) NULL,
				[ExternalStudyLink] varchar(500),
PRIMARY KEY CLUSTERED 
(
                [StudyInfoId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE SEQUENCE [dbo].[SprinttCampaignIdSequence] AS BIGINT START WITH 1000 INCREMENT BY 1; 
CREATE TABLE [dbo].[MyQuestTransactionOutBox](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[SprinttCampaignId] [bigint] NOT NULL,
	[AuditQueue] [bit] NOT NULL,
	[RetryCount] [int] NOT NULL,	
	[SendToMyQuest] [bit] NOT NULL,
	[Status] [varchar](30) NOT NULL,
	[AuditStatus] [varchar](30) NOT NULL,
	[CreatedBy] [varchar](255) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	[CreatedOn] [datetime2](0) NULL
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] 

GO

/****** Object:  Table [dbo].[FeedFailedTransaction]    Script Date: 2/8/2021 7:43:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FeedFailedTransaction](
       [FeedId] [bigint] IDENTITY(1,1) NOT NULL,
       [TrialId] [bigint] NOT NULL,
       [CampaignId] [bigint] NOT NULL,
       [StartPos] [bigint] NOT NULL,
       [EndPos] [bigint] NOT NULL,
       [BatchSize] [int] NOT NULL,
       [CreatedOn] [datetime2](7) NOT NULL,
       [UpdatedOn] [datetime2](7) NULL,
       [CreatedBy] [varchar](50) NULL,
       [UpdatedBy] [varchar](50) NULL,
       [NoOfRetries] [tinyint] NOT NULL,
	   [Status] [int] NULL,
	   [FileSequence] [int] NULL,
CONSTRAINT [PK_FeedFailedTransaction] PRIMARY KEY CLUSTERED 
(
       [FeedId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
