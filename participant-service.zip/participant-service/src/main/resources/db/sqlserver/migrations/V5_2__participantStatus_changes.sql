USE [pdr_participant_prod]

Delete from ParticipantStatus;

SET IDENTITY_INSERT [dbo].[ParticipantStatus] ON 

INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (1,'New', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (2,'Contacted Patient', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (3,'Patient is Not Interested', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (4,'Not Qualified, determined prior to screening', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (5,'Visit Scheduled', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (6,'In Screening', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (7,'Screen Fail', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (8,'Consented', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (9,'Randomized', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))
INSERT [dbo].[ParticipantStatus] ([ParticipantStatusId], [ParticipantStatusName], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn]) VALUES (10,'Enrolled', NULL,CAST(N'2021-06-28T16:21:15.0000000' AS DateTime2),NULL, CAST(N'2021-06-28T16:21:15.2766667' AS DateTime2))


SET IDENTITY_INSERT [dbo].[ParticipantStatus] OFF

