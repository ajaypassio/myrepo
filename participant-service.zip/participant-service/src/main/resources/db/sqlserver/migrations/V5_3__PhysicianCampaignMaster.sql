SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PhysicianCampaignMaster](
	[SprinttCampaignId] [bigint] IDENTITY NOT NULL,
	[CampaignName] [varchar](512) NULL,	
	[UserName] [varchar] (100) NOT NULL,
	[Specs] [text] NULL,
	[CampaignStatusId] [int] NULL,  	
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,	
	[Remarks] [nvarchar](max) NULL,
	[CreatedOn] [datetime2](0) NULL,
PRIMARY KEY CLUSTERED 
(
	[SprinttCampaignId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO