SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PhysicianEmailOutreach](
    [SprinttCampaignId] [bigint] NOT NULL,
	[EmailOutreachId] [bigint]  NOT NULL,
	[EloquaCampaignId] [varchar](512) NULL,
	[SegmentId] [bigint] NULL,
	[ScheduleId] [bigint] NULL,
	[EmailTemplateId] [bigint] NULL,
	[CampaignJobStatusId] [int] NULL,
	[EloCampgnStatusId] [int] NULL,	
	[CreatedBy] [varchar](255) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,	
	[CreatedOn] [datetime2](0) NULL,
	PRIMARY KEY CLUSTERED 
(
	[EmailOutreachId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] 
GO

