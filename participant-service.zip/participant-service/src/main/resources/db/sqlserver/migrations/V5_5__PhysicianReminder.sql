USE [pdr_participant_prod]
GO

CREATE TABLE [dbo].[PhysicianReminder](
	[ReminderId] [bigint] IDENTITY(1,1) NOT NULL,
	[TrialId] [bigint] NULL,
	[DefaultReminder] [int] NOT NULL,
	[RemindTo] [varchar](100) NULL,
	[RemindOnDateTime] [datetimeoffset](7) NULL,
	[ReminderTimeZone] [varchar](255) NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	[EmailOutreachId] [bigint] NULL,
	[IsReminderSent] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ReminderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PhysicianReminder] ADD  DEFAULT ((0)) FOR [IsReminderSent]
GO

