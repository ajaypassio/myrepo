USE [pdr_participant_prod]
GO

alter table PhysicianEmailOutreach drop column CampaignJobStatusId;
alter table PhysicianEmailOutreach add ContactListId int default NULL;
