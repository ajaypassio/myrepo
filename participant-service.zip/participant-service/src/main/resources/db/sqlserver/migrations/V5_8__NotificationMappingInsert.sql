USE [pdr_participant_prod]
GO

INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Patient List-Start','STARTED: Patient List for <placeholder>','Patient list generation started for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Patient List-Failure','FAILURE: Patient List for <placeholder>','Patient list generation failed for: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Patient List-Success','SUCCESS: Patient List for <placeholder>','Patient list generation completed successfully for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled Eloqua Patient Campaign-Start','STARTED: Scheduled Eloqua Patient Campaign <placeholder>','Eloqua patient campaign scheduling started for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled Eloqua Patient Campaign-Failure','FAILURE: Scheduled Eloqua Patient Campaign <placeholder>','Failed to schedule Eloqua Patient Campaign: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled Eloqua Patient Campaign-Success','SUCCESS: Scheduled Eloqua Patient Campaign <placeholder>','This Eloqua patient campaign was successfully scheduled: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled MyQuest Patient Campaign-Start','STARTED: Scheduled MyQuest Patient Campaign <placeholder>','MyQuest patient campaign scheduling started for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled MyQuest Patient Campaign-Failure','FAILURE: Scheduled MyQuest Patient Campaign <placeholder>','Failed to schedule MyQuest Patient Campaign: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled MyQuest Patient Campaign-Success','SUCCESS: Scheduled MyQuest Patient Campaign <placeholder>','This MyQuest patient campaign was successfully scheduled: <placeholder>.',sysdatetime(),'Admin');     
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search Counts-Start','STARTED: Physician Search Counts for <placeholder>','Physician search counts generation started for: <placeholder>.',sysdatetime(),'Admin'); 
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search Counts-Failure','FAILURE: Physician Search Counts for <placeholder>','Physician search counts generation failed for <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search Counts-Success','SUCCESS: Physician Search Counts for <placeholder>','Physician search counts generation completed successfully for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search Results-Start','STARTED: Physician Search Results for <placeholder>','Physician search results generation started for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search Results-Failure','FAILURE: Physician Search Results for <placeholder>','Physician search results generation failed for: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search Results-Success','SUCCESS: Physician Search Results for <placeholder>','Physician search results generation completed successfully for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician List-Start','STARTED: Physician List for <placeholder>','Physician list generation started for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician List-Failure','FAILURE: Physician List for <placeholder>','Physician list generation failed for: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician List-Success','SUCCESS: Physician List for <placeholder>','Physician list generation completed successfully for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled Eloqua Physician Campaign-Start','STARTED: Scheduled Eloqua Physician Campaign <placeholder>','Eloqua physician campaign scheduling started for: <placeholder>.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled Eloqua Physician Campaign-Failure','FAILURE: Scheduled Eloqua Physician Campaign <placeholder>','Failed to schedule Eloqua Physician Campaign: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Scheduled Eloqua Physician Campaign-Success','SUCCESS: Scheduled Eloqua Physician Campaign <placeholder>','This Eloqua physician campaign was successfully scheduled: <placeholder>.',sysdatetime(),'Admin');
	