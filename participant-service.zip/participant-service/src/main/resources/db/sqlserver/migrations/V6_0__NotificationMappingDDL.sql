USE [pdr_participant_prod]
GO

delete from NotificationMapping where Id in(22,23)

INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Patient List Snowflake-Failure','FAILURE: Patient List Snowflake <placeholder>','Failed Patient List Snowflake: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');
INSERT INTO [dbo].[NotificationMapping]([EventName],[EmailSubject],[EmailBody],[CreatedOn],[CreatedBy])
     VALUES ( 'Physician Search SnowFlake-Failure','FAILURE: Physician Search Snowflake <placeholder>','Failed Physician Search Snowflake: <placeholder>.Please email sprinttsupport@questdiagnostics.com for assistance.',sysdatetime(),'Admin');