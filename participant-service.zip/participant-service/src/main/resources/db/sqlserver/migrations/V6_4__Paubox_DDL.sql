GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PauboxCampaignMaster](
[SprinttCampaignId] [bigint] NOT NULL,
[CampaignId] [varchar](512) NULL,
[CampaignName] [varchar](512) NULL,
[TrialId] [bigint] NOT NULL,
[ScheduleId] [bigint] NULL,
[ReminderId] [bigint] NULL,
[Channel] [tinyint] NULL,
[CampaignStatusId] [int] NULL,
[PauboxCampgnStatusId] [int] NULL,
[CampaignJobStatusId] [int] NULL,
[InclusionCriteria] [text] NULL,
[ExclusionCriteria] [text] NULL,
[CreatedBy] [varchar](255) NULL,
[UpdatedBy] [varchar](255) NULL,
[UpdatedOn] [datetime2](0) NULL,
[CreatedOn] [datetime2](0) NULL,
PRIMARY KEY CLUSTERED
(
[SprinttCampaignId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
