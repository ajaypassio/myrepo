USE [pdr_participant_prod]
GO

/****** Object:  Table [dbo].[PauboxReminder]    Script Date: 12/30/2021 12:39:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PauboxReminder](
	[ReminderId] [bigint] IDENTITY(1,1) NOT NULL,
	[TrialId] [bigint] NOT NULL,	
	[RemindOnDateTime] [datetimeoffset](7) NULL,
	[ReminderTimeZone] [varchar](255) NULL,
	[CreatedBy] [varchar](255) NULL,
	[CreatedOn] [datetime2](0) NULL,
	[UpdatedBy] [varchar](255) NULL,
	[UpdatedOn] [datetime2](0) NULL,
	[SprinttCampaignId] [bigint] NULL,
	PRIMARY KEY CLUSTERED 
(
	[ReminderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
