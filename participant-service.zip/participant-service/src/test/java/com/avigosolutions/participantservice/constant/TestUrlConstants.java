package com.avigosolutions.participantservice.constant;

public class TestUrlConstants {
	public static String CAMPAIGN_QUESTIONNAIRE = "/campaigns/questionnaire";
	public static String CAMPAIGN_QUESTION ="/campaigns/question";
	public static String CAMPAIGN_TRAIL_QUESTIONNAIRE ="/campaigns/questionnaire/%s";
	public static String CAMPAIGN_LAST_QUESTIONNAIRE ="/campaigns/last_questionnaire/%s";
	public static String CAMPAIGN_PARTICIPANT_QUESTIONNAIRE_QUESTION="/campaigns/participantQuestionnairesAndQuestions/%s";
	public static String CAMPAIGN_PARTICIPANT_QUESTIONNAIRE="/campaigns/participantQuestionnaires/%s";
	public static String CAMPAIGN_QUESTIONNAIRE_PARTCIPANT_QUESTION="/campaigns/questionnaire/participantQuestions/%s";
	public static String CAMPAIGN_QUESTIINNAIRE="/campaigns/questionnaire/%s";
	public static String CAMPAIGN_PARTCIPANT_BY_QUESTIONNAIRE="/campaigns/questionnaire?participant_id=%s&questionnaire_id=%s";
	
		
	public static String PARTICIPANT_TRIAL="/participant/trials/%s";
	public static String PARTICIPANT_PARTICIPANT_TRIAL="/participant/trail/detail/%s/%s"; 
	public static String PARTICIPANT_UPDATE_STUDY_SITE="/participant/studysites/%s";
	public static String PARTICIPANT_TRIALS_BY_STUDYSITE="/participant/studysites/%s/%s";
	public static String PARTICIPANT_PARTICIPANTSTATUS="/participant/participantstatus";
	public static String PARTICIPANT_UPDATE_STUDYSITE_STATUS="/partcipant/update/status?trialId=%s&participantId=%s&statusId=1&studySiteId=%s";
	
	public static String PARTICIPANT_TRIAL_VALIDSTATES="/statemachine/participantTrial/validStates?trialId=%s&participantId=%s";

}
