// package com.avigosolutions.participantservice.controllers;

// import java.io.IOException;

// import org.junit.runner.RunWith;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.test.context.web.WebAppConfiguration;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;
// import org.springframework.web.context.WebApplicationContext;

// import com.avigosolutions.participantservice.controllers.CampaignController;
// import com.fasterxml.jackson.core.JsonParseException;
// import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.DeserializationFeature;
// import com.fasterxml.jackson.databind.JsonMappingException;
// import com.fasterxml.jackson.databind.ObjectMapper;

// import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
// import org.springframework.http.HttpHeaders;

// @RunWith(SpringRunner.class)
// @SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
// //@WebAppConfiguration
// public abstract class AbstractControllerTest {
// 	// protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
// 	// @Autowired
// 	// protected WebApplicationContext webApplicationContext;
	
// 	// protected MockMvc mockMvc;

// 	// protected void setUp() {
// 	// 	mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
// 	// }

	
// 	// protected void setUp(CampaignController controller) {
// 	// 	mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
// 	// }
	
// 	// protected String mapToJson(Object obj) throws JsonProcessingException {
// 	// 	ObjectMapper mapper = new ObjectMapper();
// 	// 	return mapper.writeValueAsString(obj);
// 	// }
	
// 	// protected <T> T mapFromJson (String json, Class<T> clazz)
// 	// throws JsonParseException, JsonMappingException, IOException {
// 	// 	ObjectMapper mapper = new ObjectMapper();
// 	// 	// https://stackoverflow.com/questions/4486787/jackson-with-json-unrecognized-field-not-marked-as-ignorable
// 	// 	mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
// 	// 	return mapper.readValue(json, clazz);
// 	// }
	
	
// 	// protected HttpHeaders getRequestHeaders() {
// 	// 	HttpHeaders headers = new HttpHeaders();
// 	// 	headers.add("Authorization", "Basic c2VydmljZWFwcDphcHAxMDA=");
// 	// 	headers.add("uuid", "11");
// 	// 	headers.add("Accept", "application/json");
// 	// 	return headers;
// 	// }
	
// }
