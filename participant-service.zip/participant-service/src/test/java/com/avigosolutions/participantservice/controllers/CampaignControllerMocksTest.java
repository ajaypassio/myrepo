// /**
//  * 
//  */
// package com.avigosolutions.participantservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.Date;
// import java.util.List;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
// import org.springframework.http.MediaType;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.avigosolutions.participantservice.constant.TestUrlConstants;
// import com.avigosolutions.participantservice.model.Participant;
// import com.avigosolutions.participantservice.model.ParticipantQuestion;
// import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
// import com.avigosolutions.participantservice.service.ParticipantQuestionService;
// import com.avigosolutions.participantservice.service.ParticipantQuestionnaireService;

// /**
//  * @author CapeStart
//  *
//  */


// @RunWith(SpringRunner.class)
// @SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
// public class CampaignControllerMocksTest extends AbstractControllerTest {


// 	// private String stubbedParticipantId = "1";
// 	// @Mock
// 	// private ParticipantQuestionnaireService participantQuestionnaireService;

// 	// @Mock
// 	// private ParticipantQuestionService participantQuestionService;

// 	// @InjectMocks
// 	// private CampaignController campaignController;

// 	// @Before
// 	// public void setUp() {
// 	// 	MockitoAnnotations.initMocks(this);
// 	// 	// mockMvc=setUp(campaignController);
// 	// 	mockMvc = MockMvcBuilders.standaloneSetup(campaignController).build();
// 	// }

// 	// //@Test
// 	// public void testCreateQuestionnaire() throws Exception {
// 	// 	String uri = TestUrlConstants.CAMPAIGN_QUESTIONNAIRE +"/4";

// 	// 	ParticipantQuestionnaire questionnaire = getParticipantQuestionnaireStubData();
// 	// 	//questionnaire = participantQuestionnaireService.save(questionnaire);
// 	// 	when(participantQuestionnaireService.save((ParticipantQuestionnaire) any(ParticipantQuestionnaire.class)))
// 	// 			.thenReturn(questionnaire);

// 	// 	String jsonStr = mapToJson(questionnaire);

// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON)
// 	// 			.accept(MediaType.APPLICATION_JSON).content(jsonStr)).andReturn();

// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();

// 	// 	ParticipantQuestionnaire savedQuestionnaire = super.mapFromJson(content, ParticipantQuestionnaire.class);

// 	// 	System.out.println("status: " + status + " response: " + content);

// 	// 	// verify(participantQuestionnaireService, times(1))
// 	// 	// .save((ParticipantQuestionnaire) any(ParticipantQuestionnaire.class));
// 	// 	System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 	Assert.assertEquals("failure - expected 201", 201, status);
// 	// 	Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 	Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 			savedQuestionnaire.getParticipantId());
// 	// }

// 	// @Test
// 	// public void testGetQuestionnairesByTrial() throws Exception {
// 	// 	MvcResult result = mockMvc
// 	// 			.perform(MockMvcRequestBuilders.get(String.format(TestUrlConstants.CAMPAIGN_TRAIL_QUESTIONNAIRE, 4))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire.class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 201", 201, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire.getParticipantId());
// 	// 	}
// 	// }

// 	// @Test
// 	// public void testGetParticipantQuestionnaireByParticipantAndQuestionnaireId() throws Exception {
// 	// 	ParticipantQuestionnaire pquestionair = new ParticipantQuestionnaire();
// 	// 	Participant participant = new Participant();
// 	// 	pquestionair.withParticipantId("1").withQuestionnaireId(24l).withParticipant(participant);
		
// 	// 	when(participantQuestionnaireService.save(any(ParticipantQuestionnaire.class))).thenReturn(pquestionair);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.get(String.format(TestUrlConstants.CAMPAIGN_PARTCIPANT_BY_QUESTIONNAIRE,  1, 24))
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire.class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 201", 201, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire.getParticipantId());
// 	// 	}
// 	// }

// 	// @Test
// 	// public void testGetParticpantQuestionnaire() throws Exception {
// 	// 	int participantQuestionnaireId = 1;
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.get(String.format(TestUrlConstants.CAMPAIGN_QUESTIINNAIRE, participantQuestionnaireId))
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire.class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 201", 201, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire.getParticipantId());
// 	// 	}
// 	// }

// 	// @Test
// 	// public void testGetParticpantAnsweredQuestions() throws Exception {
// 	// 	int participantQuestionnaireId = 1;
// 	// 	MvcResult result = mockMvc
// 	// 			.perform(MockMvcRequestBuilders
// 	// 					.get(String.format(TestUrlConstants.CAMPAIGN_QUESTIONNAIRE_PARTCIPANT_QUESTION,
// 	// 							participantQuestionnaireId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire.class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 201", 201, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire.getParticipantId());
// 	// 	}
// 	// }

// 	// @Test
// 	// public void testGetParticipantQuestionnaires() throws Exception {
// 	// 	ParticipantQuestionnaire pquestionair = new ParticipantQuestionnaire();
// 	// 	Participant participant = new Participant();
// 	// 	pquestionair.withParticipantId("1").withQuestionnaireId(24l).withParticipant(participant);
		
// 	// 	when(participantQuestionnaireService.save(any(ParticipantQuestionnaire.class))).thenReturn(pquestionair);
		
// 	// 	MvcResult result = mockMvc.perform(
// 	// 			MockMvcRequestBuilders.get(String.format(TestUrlConstants.CAMPAIGN_PARTCIPANT_BY_QUESTIONNAIRE, 1, 24))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire.class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 201", 201, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire.getParticipantId());
// 	// 	}
// 	// }
	
// 	// @Test
// 	// public void testGetParticipantQuestionnairesAndQuestions() throws Exception {
		
// 	// 	ParticipantQuestionnaire pquestionaire = new ParticipantQuestionnaire();
// 	// 	Participant participant = new Participant();
// 	// 	pquestionaire.withParticipantId(stubbedParticipantId).withQuestionnaireId(24l).withParticipant(participant);
// 	// 	List<ParticipantQuestionnaire> questionaireList = new ArrayList<>(); 
// 	// 	questionaireList.add(pquestionaire);
		
// 	// 	when(participantQuestionnaireService.getParticipantQuestionnairebyParticipantId(any(String.class))).thenReturn(questionaireList);
		
		
// 	// 	MvcResult result = mockMvc.perform(
// 	// 			MockMvcRequestBuilders.get(String.format(TestUrlConstants.CAMPAIGN_PARTICIPANT_QUESTIONNAIRE_QUESTION, 1))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire[] savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire[].class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 200", 200, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire[0].getParticipantId());
// 	// 	}
// 	// }

// 	// @Test
// 	// public void testGetLastAnsweredQuestion() throws Exception {
// 	// 	int participantQuestionnaireId = 1;
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.get(String.format(TestUrlConstants.CAMPAIGN_LAST_QUESTIONNAIRE, participantQuestionnaireId))
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	if (null != content && !content.isEmpty()) {
// 	// 		ParticipantQuestionnaire savedQuestionnaire = mapFromJson(content, ParticipantQuestionnaire.class);
// 	// 		System.out.println("status: " + status + " response: " + content);
// 	// 		System.out.println("toString: " + savedQuestionnaire.toString());
// 	// 		Assert.assertEquals("failure - expected 201", 201, status);
// 	// 		Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 		Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 				savedQuestionnaire.getParticipantId());
// 	// 	}
// 	// }

// 	// @Test
// 	// public void testCreateQuestion() throws Exception {
// 	// 	String uri = TestUrlConstants.CAMPAIGN_QUESTION;

// 	// 	ParticipantQuestion participantQuestion = getParticipantQuestionStubData();

// 	// 	when(participantQuestionService.save(participantQuestion)).thenReturn(participantQuestion);
// 	// 	when(participantQuestionService.findByParticipantIdAndQuestionId(participantQuestion.getParticipantId(),
// 	// 			participantQuestion.getQuestionId())).thenReturn(participantQuestion);
// 	// 	// participantQuestion=participantQuestionService.save(participantQuestion);

// 	// 	String jsonStr = mapToJson(participantQuestion);

// 	// 	MvcResult result = mockMvc
// 	// 			.perform(MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(jsonStr))
// 	// 			.andReturn();

// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();

// 	// 	ParticipantQuestion savedQuestion = super.mapFromJson(content, ParticipantQuestion.class);

// 	// 	System.out.println("status: " + status + " response: " + content);

// 	// 	// verify(participantQuestionService, times(1)).save((ParticipantQuestion)
// 	// 	// any(ParticipantQuestion.class));
// 	// 	System.out.println("toString: " + savedQuestion.toString());
// 	// 	Assert.assertEquals("failure - expected 201", 201, status);
// 	// 	Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 	Assert.assertEquals("failure - expected participant id of 2", stubbedParticipantId,
// 	// 			savedQuestion.getParticipantId());

// 	// }

// 	// private ParticipantQuestionnaire getParticipantQuestionnaireStubData() {
// 	// 	return new ParticipantQuestionnaire().withParticipantId(stubbedParticipantId).withTrialOptStatus(1);
// 	// }

// 	// private ParticipantQuestion getParticipantQuestionStubData() {
// 	// 	return new ParticipantQuestion().withParticipantId(stubbedParticipantId).withAnswer("no")
// 	// 			.withParticipantQuestionnaireId(1L).withQuestionId(1L).withCreatedOn(new Date());

// 	// }
// }
