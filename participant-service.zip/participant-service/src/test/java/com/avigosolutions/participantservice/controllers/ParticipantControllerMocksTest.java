// package com.avigosolutions.participantservice.controllers;

// import static org.junit.Assert.*;
// import static org.mockito.Matchers.any;
// import static org.mockito.Matchers.anyLong;
// import static org.mockito.Matchers.anyString;
// import static org.mockito.Mockito.when;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
// import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

// import java.util.ArrayList;
// import java.util.List;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.MediaType;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.avigosolutions.participantservice.constant.TestUrlConstants;
// import com.avigosolutions.participantservice.dto.ParticipantQuestionnaireDto;
// import com.avigosolutions.participantservice.dto.ParticipantTrialInfo;
// import com.avigosolutions.participantservice.dto.ParticipantTrialsDto;
// import com.avigosolutions.participantservice.dto.ParticipantUpdate;
// import com.avigosolutions.participantservice.model.Participant;
// import com.avigosolutions.participantservice.model.ParticipantQuestion;
// import com.avigosolutions.participantservice.model.ParticipantStatus;
// import com.avigosolutions.participantservice.model.ParticipantStudySite;
// import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
// import com.avigosolutions.participantservice.response.model.ResponseObjectModel;
// import com.avigosolutions.participantservice.service.ParticipantQuestionnaireService;
// import com.avigosolutions.participantservice.service.ParticipantService;
// import com.avigosolutions.participantservice.service.ParticipantStudySiteService;
// public class ParticipantControllerMocksTest extends AbstractControllerTest {

// 	// String participantId = "1";
// 	// Long trialId = 1L;
// 	// static Long studySiteId = 2L;
// 	// List<Participant> participantList;
// 	// Long statusId = 10L;
	
// 	// protected MockMvc mockMvc;
	
// 	// @InjectMocks
// 	// private ParticipantController participantController;
	
// 	// @Mock
// 	// private ParticipantService participantService;
	
// 	// @Mock
// 	// private ParticipantStudySiteService participantStudySiteService;

// 	// @Mock
// 	// private ParticipantQuestionnaireService participantQuestionnaireService;
	
	
// 	// private ResponseObjectModel responseObjectModel;
	
// 	// private ParticipantRequestFilterModel participantRequestFilterModel;

// 	// @Before
// 	// public void setUp() {
// 	// 	MockitoAnnotations.initMocks(this); 
// 	// 	mockMvc = MockMvcBuilders.standaloneSetup(participantController).build();
		
// 	// 	participantRequestFilterModel = new ParticipantRequestFilterModel();
// 	// 	participantRequestFilterModel.setStart(0);
// 	// 	participantRequestFilterModel.setPageSize(10);
// 	// 	participantRequestFilterModel.setParticipantName("");
// 	// 	participantRequestFilterModel.setAgeStart(0);
// 	// 	participantRequestFilterModel.setAgeEnd(0);
// 	// 	participantRequestFilterModel.setZipcode("");
// 	// 	participantRequestFilterModel.setColumnToSort("");
// 	// 	participantRequestFilterModel.setSortType("");
// 	// 	responseObjectModel = new ResponseObjectModel();
// 	// 	responseObjectModel.setStatus(200);
// 	// 	participantList = new ArrayList<Participant>();
// 	// } 
// 	// /*
// 	//  * getAllTrials() test success response
// 	//  */
// 	// @Test
// 	// public void testGetAllTrials() throws Exception {
// 	// 	List<ParticipantTrialsDto> lstParticipantTrialsDto= new ArrayList<ParticipantTrialsDto>();

// 	// 	ParticipantTrialsDto participantTrialsDto = new ParticipantTrialsDto();
// 	// 	lstParticipantTrialsDto.add(participantTrialsDto);
		
// 	// 	when(participantService.findTrialsbyParticipantId(participantId)).thenReturn(lstParticipantTrialsDto);
// 	// 	MvcResult result = mockMvc
// 	// 			.perform(MockMvcRequestBuilders.get(String.format(TestUrlConstants.PARTICIPANT_TRIAL, participantId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
//  	// 	System.out.println("status: " + status + " response: " + content);  
// 	// 	Assert.assertEquals("Success - expected 200", 200, status);
// 	// }
	
	
// 	// /*
// 	//  * getAllTrials() test null 
// 	//  */
// 	// @Test
// 	// public void testGetAllTrialsNull() throws Exception {
		
// 	// 	when(participantService.findTrialsbyParticipantId(participantId)).thenReturn(null);
// 	// 	MvcResult result = mockMvc
// 	// 			.perform(MockMvcRequestBuilders.get(String.format(TestUrlConstants.PARTICIPANT_TRIAL, participantId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString(); 
// 	// 	int status = result.getResponse().getStatus();
//  	// 	System.out.println("status: " + status + " response: " + content);  
// 	// 	Assert.assertEquals("failure - expected 404", 404, status); ;
// 	// }

// 	// /*
// 	//  * getTrialInfo() test success scenario
// 	//  */
// 	// @Test
// 	// public void testGetTrialInfo() throws Exception {
// 	// 	ParticipantTrialInfo participantTrialInfo = new ParticipantTrialInfo();
// 	// 	participantTrialInfo.setTrialId(2L);
// 	// 	when(participantService.findTrialdetails(participantId, trialId)).thenReturn(participantTrialInfo);
// 	// 	MvcResult result = mockMvc.perform(
// 	// 			MockMvcRequestBuilders.get(String.format(TestUrlConstants.PARTICIPANT_PARTICIPANT_TRIAL, participantId, trialId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
//  	// 	System.out.println("status: " + status + " response: " + content);
// 	// 	Assert.assertEquals("Success - expected 200", 200, status);
// 	// 	ParticipantTrialInfo response = super.mapFromJson(content, ParticipantTrialInfo.class);
// 	// 	Assert.assertEquals("Success - expected StudySite id of 2", 2, response.getTrialId());
// 	// }
	
	
// 	// /*
// 	//  * getTrialInfo() test null Data
// 	//  */
// 	// @Test
// 	// public void testGetTrialInfoNull() throws Exception { 
// 	// 	when(participantService.findTrialdetails(participantId, trialId)).thenReturn(null);
// 	// 	MvcResult result = mockMvc.perform(
// 	// 			MockMvcRequestBuilders.get(String.format(TestUrlConstants.PARTICIPANT_PARTICIPANT_TRIAL, participantId, trialId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();

// 	// 	System.out.println("status: " + status + " response: " + content);
// 	// 	Assert.assertEquals("failure - expected 404", 404, status);
// 	// }
	
	
// 	// /*
// 	//  * updateParticipant() success scenario
// 	//  */
// 	// @Test
// 	// public void updateParticipantTest() throws Exception {
// 	// 	ParticipantUpdate participantUpdate = new ParticipantUpdate();
// 	// 	participantUpdate.setParticipantId("1");
// 	// 	when(participantService.participantUpdate(any(ParticipantUpdate.class))).thenReturn(participantUpdate);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put(String.format("/participant/studysites/1")) 
// 	// 			.headers(getRequestHeaders())
// 	// 			.contentType(MediaType.APPLICATION_JSON)
// 	// 			.content(mapToJson(participantUpdate))).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();

// 	// 	ParticipantUpdate participantUpdateResponse = super.mapFromJson(content, ParticipantUpdate.class);

// 	// 	System.out.println("status: " + status + " response: " + content); 
// 	// 	Assert.assertEquals("failure - expected 200", 200, status);
// 	// 	Assert.assertTrue("failure expected return string len should be 0", content.trim().length() > 0);
// 	// 	Assert.assertEquals("Success - expected StudySite id of 1", "1", participantUpdateResponse.getParticipantId());
// 	// }
	
	
// 	// /*
// 	//  * updateParticipant() null scenario
// 	//  */
// 	// @Test
// 	// public void updateParticipantNullTest() throws Exception {
// 	// 	ParticipantUpdate participantUpdate = new ParticipantUpdate();
// 	// 	participantUpdate.setParticipantId("1");
// 	// 	when(participantService.participantUpdate(any(ParticipantUpdate.class))).thenReturn(null);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put(String.format("/participant/studysites/1")) 
// 	// 			.headers(getRequestHeaders())
// 	// 			.contentType(MediaType.APPLICATION_JSON)
// 	// 			.content(mapToJson(participantUpdate))).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus(); 
// 	// 	System.out.println("status: " + status + " response: " + content); 
// 	// 	Assert.assertEquals("failure - expected 404", 404, status); 
// 	// }
	
	
// 	// /*
// 	//  * getParticipantsByTrialIdAndStudySiteId() success response test
// 	//  */
// 	// @Test
// 	// public void getParticipantsByTrialIdAndStudySiteIdTest() throws Exception {
		
// 	// 	String uri = "/participant/studysites/4/4"; ///studysites/{trialId}/{studySiteId} 
// 	// 	when(participantStudySiteService.getParticipantsbyTrialIdAndStudySiteId(anyLong(), anyLong(), any(ParticipantRequestFilterModel.class))).thenReturn(responseObjectModel);
// 	// 	MvcResult result  =  mockMvc.perform(post(uri)
// 	// 						.headers(getRequestHeaders())
// 	// 						.contentType(MediaType.APPLICATION_JSON)
// 	// 						.content(mapToJson(participantRequestFilterModel))).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	System.out.println(content);
// 	// 	ResponseObjectModel response = mapFromJson(content, ResponseObjectModel.class);
// 	// 	System.out.println("Send package status: " + response.getStatus() + " response: " + content);
// 	// 	Assert.assertEquals("Success - expected 200", 200, response.getStatus());
// 	// }
	
// 	// /*
// 	//  * getParticipantsByTrialIdAndStudySiteId() exception handling test 
// 	//  */
// 	// @Test
// 	// public void getParticipantsByTrialIdAndStudySiteIdExceptionTest() throws Exception {
		
// 	// 	String uri = "/participant/studysites/4/4";  
// 	// 	when(participantStudySiteService.getParticipantsbyTrialIdAndStudySiteId(anyLong(), anyLong(), any(ParticipantRequestFilterModel.class))).thenThrow(new NullPointerException());
// 	// 	MvcResult result  =  mockMvc.perform(post(uri)
// 	// 						.headers(getRequestHeaders())
// 	// 						.contentType(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	Assert.assertEquals("Success - expected 400", 400, status);
// 	// }
	
	
// 	// /*
// 	//  * getAllParticipantsByStudySiteId() test success scenario
// 	//  */
// 	// @Test
// 	// public void getAllParticipantsByStudySiteIdTest() throws Exception { 
// 	// 	when(participantService.getParticipantsByStudySiteId(studySiteId)).thenReturn(participantList);
// 	// 	MvcResult result = mockMvc.perform(
// 	// 			MockMvcRequestBuilders.get(String.format("/participant/studysiteparticipant/%s", studySiteId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	System.out.println("status: " + status + " response: " + content); 
// 	// 	Assert.assertEquals("Sucess - expected 200", 200, status); 
// 	// }
	
	
	
// 	// /*
// 	//  * getAllParticipantsByStudySiteId() test null data
// 	//  */
// 	// @Test
// 	// public void getAllParticipantsByStudySiteIdTestNull() throws Exception { 
// 	// 	when(participantService.getParticipantsByStudySiteId(anyLong())).thenReturn(null);
// 	// 	MvcResult result = mockMvc.perform(
// 	// 			MockMvcRequestBuilders.get(String.format("/participant/studysiteparticipant/%s", studySiteId))
// 	// 					.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON))
// 	// 			.andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	System.out.println("status: " + status + " response: " + content); 
// 	// 	Assert.assertEquals("failure - expected 404", 404, status); 
// 	// }
	
	
// 	// /*
// 	//  * getAllParticipantStatus() test possitive scenario
// 	//  */
// 	// @Test
// 	// public void testGetAllParticipantStatus() throws Exception {
// 	// 	List<ParticipantStatus> participantStatusList= new ArrayList<ParticipantStatus>();
// 	// 	when(participantService.getAllParticipantStatus()).thenReturn(participantStatusList);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.get(String.format(TestUrlConstants.PARTICIPANT_PARTICIPANTSTATUS))
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
 

// 	// 	System.out.println("status: " + status + " response: " + content); 
// 	// 	Assert.assertEquals("Success - expected 200", 200, status); 
// 	// }
	
// 	// /*
// 	//  * getAllParticipantStatus() null Data
// 	//  */
// 	// @Test
// 	// public void testGetAllParticipantStatusNull() throws Exception { 
// 	// 	when(participantService.getAllParticipantStatus()).thenReturn(null);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.get(String.format(TestUrlConstants.PARTICIPANT_PARTICIPANTSTATUS))
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	int status = result.getResponse().getStatus(); 
// 	// 	Assert.assertEquals("failure - expected 404", 404, status); 
// 	// }
	
	
// 	// /*
// 	//  * updateParticipantStatus() test success 
// 	//  */
// 	// /*@Test
// 	// public void updateParticipantStatusTest() throws Exception { 
// 	// 	ParticipantStudySite participantStudySite = new ParticipantStudySite(); 
// 	// 	when(participantService.updateParticipantStatus(anyString(), anyLong(), anyLong(),
// 	// 			anyLong())).thenReturn(participantStudySite);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.put(String.format("/participant/update/status"))
// 	// 			.param("participantId", "1")
// 	// 			.param("trialId", "1")
// 	// 			.param("studySiteId", "1")
// 	// 			.param("statusId", "2")
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus(); 
// 	// 	System.out.println("status: " + status + " response: " + content); 
// 	// 	Assert.assertEquals("failure - expected 200", 200, status); 
// 	// }*/
		
// 	// /*
// 	//  * getParticipantCountsByParticipantStatusId() success response test
// 	//  */
// 	// @Test
// 	// public void getParticipantCountsByParticipantStatusIdTest() throws Exception {
		 
// 	// 	when(participantStudySiteService.countByParticipantStatusIdAndStudySiteIdAndTrialId(any(List.class), any(List.class), anyLong())).thenReturn(null);
// 	// 	MvcResult result  =  mockMvc.perform(post("/participant/studysites/count/2/2")
// 	// 						.headers(getRequestHeaders())
// 	// 						.contentType(MediaType.APPLICATION_JSON)
// 	// 						.content(mapToJson(participantRequestFilterModel))).andReturn();
// 	// 	String content = result.getResponse().getContentAsString(); 
// 	// 	System.out.println("Send package status: " + result.getResponse().getStatus() + " response: " + content);
// 	// 	Assert.assertEquals("Success - expected 200", 200, result.getResponse().getStatus());
// 	// }
	

// 	// /*
// 	//  * getParticipantCountsByParticipantStatusIdByTrialId() success response test
// 	//  */
// 	// @Test
// 	// public void getParticipantCountsByParticipantStatusIdByTrialIdTest() throws Exception {
		 
// 	// 	when(participantStudySiteService.countByParticipantStatusIdAndStudySiteIdAndTrialId(any(List.class), any(List.class), anyLong())).thenReturn(null);
// 	// 	MvcResult result  =  mockMvc.perform(get("/participant/studysites/count/1" )
// 	// 						.headers(getRequestHeaders())
// 	// 						.contentType(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	System.out.println(content); 
// 	// 	System.out.println("Send package status: " + result.getResponse().getStatus() + " response: " + content);
// 	// 	Assert.assertEquals("Success - expected 200", 200, result.getResponse().getStatus());
// 	// }
	
// }