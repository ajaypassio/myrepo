// package com.avigosolutions.participantservice.controllers;

// import static org.mockito.Matchers.any;
// import static org.mockito.Mockito.when;

// import java.util.ArrayList;
// import java.util.HashSet;
// import java.util.List;
// import java.util.Set;

// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.http.MediaType;
// import org.springframework.test.web.servlet.MockMvc;
// import org.springframework.test.web.servlet.MvcResult;
// import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
// import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// import com.avigosolutions.participantservice.States;
// import com.avigosolutions.participantservice.constant.TestUrlConstants;
// import com.avigosolutions.participantservice.dto.ParticipantTrialState;
// import com.avigosolutions.participantservice.model.Participant;
// import com.avigosolutions.participantservice.service.ParticipantStateService;

// public class ParticipantStateControllerMockTest extends AbstractControllerTest {

// 	// String participantId = "1";
// 	// Long trialId = 1L;
// 	// static Long studySiteId = 2L;
// 	// List<Participant> participantList;
// 	// Long statusId = 10L;

// 	// protected MockMvc mockMvc;

// 	// @InjectMocks
// 	// private StateMachineController stateMachineController;

// 	// @Mock
// 	// private ParticipantStateService participantStateService;

// 	// @Before
// 	// public void setUp() {
// 	// 	MockitoAnnotations.initMocks(this);
// 	// 	mockMvc = MockMvcBuilders.standaloneSetup(stateMachineController).build();

// 	// 	participantList = new ArrayList<Participant>();
// 	// }

// 	// /*
// 	//  * getAllTrials() test success response
// 	//  */
// 	// @Test
// 	// public void testGetAllValidStates() throws Exception {
// 	// 	Set<States> states = new HashSet<States>();
// 	// 	states.add(States.OUTREACHED);
// 	// 	states.add(States.SCREENING);
// 	// 	//ParticipantTrialState ptState = new ParticipantTrialState(participantId, trialId);

// 	// 	when(participantStateService.getValidStates(any(ParticipantTrialState.class))).thenReturn(states);
// 	// 	MvcResult result = mockMvc.perform(MockMvcRequestBuilders
// 	// 			.get(String.format(TestUrlConstants.PARTICIPANT_TRIAL_VALIDSTATES, participantId, trialId))
// 	// 			.headers(getRequestHeaders()).accept(MediaType.APPLICATION_JSON)).andReturn();
// 	// 	String content = result.getResponse().getContentAsString();
// 	// 	int status = result.getResponse().getStatus();
// 	// 	System.out.println("status: " + status + " response: " + content);
// 	// 	Assert.assertEquals("Success - expected 200", 200, status);
// 	// }
// }