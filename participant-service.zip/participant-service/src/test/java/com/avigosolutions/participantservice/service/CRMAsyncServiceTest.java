// package com.avigosolutions.participantservice.service;

// import org.junit.Test;
// import org.mockito.Mock;

// import com.avigosolutions.participantservice.crm.async.model.CRMContactJob;
// import com.avigosolutions.participantservice.crm.async.service.CrmAsyncService;

// public class CRMAsyncServiceTest {
	
// 	@Mock
// 	CrmAsyncService cRMAsyncService;
	
// 	// private CRMContactJob getCRMContactJob() {
// 	// 	// CRMContactJob cJob=new CRMContactJob().withBatchSize(10).setBatchId(1).withContactJson("[]");
// 	// 	// return cJob;
// 	// }
// 	// @Test
// 	// public void testBulkProcess() {
// 	// 	//CRMContactJob cJob=getCRMContactJob();
// 	// 	//cRMAsyncService.batchProcess();
// 	// }
// }
