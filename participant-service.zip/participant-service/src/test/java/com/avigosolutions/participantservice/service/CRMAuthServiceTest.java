// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertNull;

// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;

// import com.avigosolutions.participantservice.crm.service.CRMAuthService;
// import com.avigosolutions.participantservice.dto.CRMAuth;
// import com.jayway.jsonpath.Configuration;
// import com.jayway.jsonpath.DocumentContext;
// import com.jayway.jsonpath.JsonPath;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// public class CRMAuthServiceTest {

// 	@Autowired
// 	CRMAuthService crmAuthService;

// 	@Before
// 	public void setup() {

// 	}

// 	@After
// 	public void tearDown() {

// 	}

// 	//@Test
// 	public void testAuthenticateCRM() {
// 		// CRMAuth auth = crmAuthService.authenticate();
// 		// assertNotNull(auth.getStatus());
// 	}
	
// 	// @Test
// 	// public void testJSONPathForAuth() {
// 	// 	DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(getJSONAuthResponse());
// 	// 	String status = context.read("$.status", String.class);
// 	// 	String responseCode = context.read("$.responseCode", String.class);
// 	// 	String accessToken = null;
// 	// 	String errorMessage = null;
// 	// 	if (responseCode.equals("200")) {
// 	// 		accessToken = context.read("$.result.access_token", String.class);
// 	// 	} else if (getJSONAuthResponse().contains("errorMessage")) {
// 	// 		errorMessage = context.read("$.errors.errorMessage", String.class);
// 	// 	}
		
// 	// 	assertNotNull(status);
// 	// 	assertNotNull(accessToken);
// 	// 	assertNotNull(responseCode);
// 	// 	assertNull(errorMessage);
// 	// }
	
// 	// @Test
// 	// public void testJSONPathForAuthFailed() {
// 	// 	DocumentContext context = JsonPath.using(Configuration.defaultConfiguration()).parse(getFailedJSONAuthResponse());
// 	// 	String status = context.read("$.status", String.class);
// 	// 	String responseCode = context.read("$.responseCode", String.class);
// 	// 	String accessToken = null;
// 	// 	String errorMessage = null;
// 	// 	if (responseCode.equals("200")) {
// 	// 		accessToken = context.read("$.result.access_token", String.class);
// 	// 	} else if (getFailedJSONAuthResponse().contains("errorMessage")) {
// 	// 		errorMessage = context.read("$.errors[0].errorMessage", String.class);
// 	// 	}
		
// 	// 	assertNotNull(status);
// 	// 	assertNull(accessToken);
// 	// 	assertNotNull(responseCode);
// 	// 	assertNotNull(errorMessage);
// 	// }

// 	// private String getJSONAuthResponse() {
// 	// 	return "{\"status\":\"SUCCESS\",\"result\":{\"moduleAccess\":[{\"code\":\"contact\",\"name\":\"Contact\",\"pluralName\":\"Contacts\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\"],\"searchLabel\":\"Contact\",\"accessible\":true},{\"code\":\"account\",\"name\":\"Account\",\"pluralName\":\"Accounts\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Account\",\"accessible\":true},{\"code\":\"notification\",\"name\":\"Email\",\"pluralName\":\"Emails\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Email\",\"accessible\":true},{\"code\":\"targetList\",\"name\":\"Target List\",\"pluralName\":\"Target Lists\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Target List\",\"accessible\":true},{\"code\":\"kb\",\"name\":\"Knowledge Base\",\"pluralName\":\"Knowledge Base\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Knowledge Base\",\"accessible\":true},{\"code\":\"document\",\"name\":\"Z-Drive\",\"pluralName\":\"Z-Drive\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Z-Drive\",\"accessible\":true},{\"code\":\"estate\",\"name\":\"Property\",\"pluralName\":\"Properties\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Property\",\"accessible\":true},{\"code\":\"reopp\",\"name\":\"Buyers\\t\",\"pluralName\":\"Opportunities\",\"enabled\":true,\"allowedWorks\":[\"READ\",\"ADD\",\"UPDATE\",\"DELETE\",\"FILLER_11\"],\"searchLabel\":\"Buyers\",\"accessible\":true}],\"settings\":{\"id\":\"9a504a17-3302-44b0-9719-f0b07f80a0c7\",\"version\":0,\"createdOn\":\"12/24/2017\",\"updatedOn\":\"12/24/2017\",\"createdTime\":\"12/24/2017 06:31:21\",\"updatedTime\":\"12/24/2017 06:31:21\",\"startOfFY\":\"0\",\"timezone\":\"America/New_York\",\"dateFormat\":\"MM/dd/yyyy\",\"timeFormat\":\"HH:mm:ss\",\"currencyCode\":\"USD\",\"thSeparator\":\",\",\"deciSeparator\":\",\",\"domain\":\"ziprr.net\",\"suppressSelfActivityEmail\":false,\"leadRouting\":false},\"subdomain\":\"testaccount.zipperagent.com\",\"role\":\"accown\",\"login\":\"test_account\",\"access_token\":\"1tvqKswtV59A374g4jrKCx47lwmBWqLGYWznT9EPH/Tp59JYc39N+jjy16brQo89+4Va6dU7ch0Lk2FBLMf3vJGoVvrM9NileV6Qlki4biHxa8mJRIXxE1PSsdcYPaU8MI5LCcA1Vzd9qlloZXwMlD/JukKKr+oV8vCbnE4Jsvxp0s/74AXjlHJLyOZ76TSf73z1GlxM/3R+oQNkcffo41DgMFzktgyv3edRR6qt2rc=\"},\"responseCode\":200,\"editable\":false,\"deletable\":false,\"forbidden\":false,\"returnedCount\":0}";
// 	// }
	
// 	// private String getFailedJSONAuthResponse() {
// 	// 	return "{\r\n" + 
// 	// 			"    \"status\": \"FAIL\",\r\n" + 
// 	// 			"    \"result\": {\r\n" + 
// 	// 			"        \"userName\": \"test.account@zyprr.com\",\r\n" + 
// 	// 			"        \"rememberMe\": false,\r\n" + 
// 	// 			"        \"tenant\": false\r\n" + 
// 	// 			"    },\r\n" + 
// 	// 			"    \"responseCode\": 401,\r\n" + 
// 	// 			"    \"editable\": false,\r\n" + 
// 	// 			"    \"deletable\": false,\r\n" + 
// 	// 			"    \"forbidden\": false,\r\n" + 
// 	// 			"    \"errors\": [\r\n" + 
// 	// 			"        {\r\n" + 
// 	// 			"            \"errorMessage\": \"Invalid   username or password, invalid login attempt on testaccount.zipperagent.com with id test.account@zyprr.com\"\r\n" + 
// 	// 			"        }\r\n" + 
// 	// 			"    ],\r\n" + 
// 	// 			"    \"returnedCount\": 0}";
// 	// }
// }
