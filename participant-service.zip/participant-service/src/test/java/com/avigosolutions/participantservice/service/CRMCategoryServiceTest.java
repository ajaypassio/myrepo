// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertNotEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertTrue;

// import java.util.HashMap;
// import java.util.Map;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.Future;

// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;

// import com.avigosolutions.participantservice.crm.service.CRMCategoryService;
// import com.avigosolutions.participantservice.crm.service.CRMCategoryServiceImpl;
// import com.avigosolutions.participantservice.model.CRMCategory;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// public class CRMCategoryServiceTest {

// 	// @Autowired
// 	// CRMCategoryService crmCategoryService;

// 	// @Before
// 	// public void setup() {

// 	// }

// 	// @After
// 	// public void tearDown() {

// 	// }

// 	// //@Test
// 	// public void testCreateCategory() {
// 	// 	CRMCategory category = getTestCategory();
// 	// 	crmCategoryService.createCategory(category);
// 	// 	assertNotNull(category.getLookupCode());
// 	// }
	
// 	// @Test
// 	// public void testCreateSubstitution() {
// 	// 	Map<String, String> subs = getTestSubstitution();
// 	// 	boolean status = crmCategoryService.addSubstitution(subs);
// 	// 	assertTrue(status);
// 	// }
	
// 	// @Test
// 	// public void testUpdateSubstitution() {
// 	// 	Map<String, String> subs = getTestSubstitution();
// 	// 	subs.put("123", "Throat Cancer Questionnaire Modified");
// 	// 	boolean status = crmCategoryService.addSubstitution(subs);
// 	// 	assertTrue(status);
// 	// }
	
// 	// @Test
// 	// public void testRemoveSubstitution() {
// 	// 	Map<String, String> subs = getTestSubstitution();
// 	// 	subs.put("123", null);
// 	// 	boolean status = crmCategoryService.addSubstitution(subs);
// 	// 	assertTrue(status);
// 	// }

// 	// @Test
// 	// public void testUpdateCategory() {
// 	// 	CRMCategory category = getTestCategory();
// 	// 	category.withOldTrialName(category.getTrialName());
// 	// 	category.withTrialName(category.getTrialName() + "Upd");
// 	// 	crmCategoryService.updateCategory(category);
// 	// }

// 	// //@Test
// 	// public void testGetCategory() {
// 	// 	String code = crmCategoryService.getLookupCode("NO_CATEGORY");
// 	// 	assertNotNull(code);
// 	// }

// 	// @Test
// 	// public void testJSONPathCreateCategory() {
// 	// 	CRMCategoryServiceImpl service = new CRMCategoryServiceImpl();
// 	// 	CRMCategory category = new CRMCategory();
// 	// 	service.parseJSON(getJSONAuthResponse(), category);
// 	// 	assertNotNull(category.getLookupCode());
// 	// }

// 	// /*
// 	//  * @Test public void testJSONPathParseCategories() { CRMCategoryServiceImpl
// 	//  * service = new CRMCategoryServiceImpl(); Map<String, String> map =
// 	//  * service.parseCategoriesJSON(getMetaCategoriesJSON()); assertTrue(map.size() >
// 	//  * 0); }
// 	//  */

// 	// private CRMCategory getTestCategory() {
// 	// 	CRMCategory category = new CRMCategory();
// 	// 	category.withTrialName("New_trail").withSearchName("Test2");
// 	// 	return category;
// 	// }
	
// 	// private Map<String, String> getTestSubstitution() {
// 	// 	Map<String, String> subs = new HashMap<>();
// 	// 	subs.put("123", "Throat Cancer Questionnaire");
// 	// 	return subs;
// 	// }

// 	// private String getJSONAuthResponse() {
// 	// 	return "{\r\n" + "    \"status\": \"SUCCESS\",\r\n" + "    \"result\": [{\r\n"
// 	// 			+ "        \"id\": \"b4a599ea-36fa-433c-aa3e-0d6b0def57fc\",\r\n" + "        \"version\": 0,\r\n"
// 	// 			+ "        \"createdOn\": \"20/04/2018\",\r\n" + "        \"updatedOn\": \"20/04/2018\",\r\n"
// 	// 			+ "        \"createdTime\": \"20/04/2018 15:35:03\",\r\n"
// 	// 			+ "        \"updatedTime\": \"20/04/2018 15:35:03\",\r\n" + "        \"fieldName\": \"conType\",\r\n"
// 	// 			+ "        \"lookupCode\": \"C_RLT_1\",\r\n" + "        \"locale\": \"en_US\",\r\n"
// 	// 			+ "        \"displayName\": \"Realtor\",\r\n" + "        \"displayOrder\": 27\r\n" + "    }],\r\n"
// 	// 			+ "    \"responseCode\": 200,\r\n" + "    \"editable\": false,\r\n" + "    \"deletable\": false,\r\n"
// 	// 			+ "    \"forbidden\": false,\r\n" + "    \"returnedCount\": 0\r\n" + "}";
// 	// }
	
// 	// @Test
// 	// public void setup_asyncSaveCategory() throws InterruptedException, ExecutionException {
// 	// 	crmCategoryService.createCategory(getTestCategory());
// 	// }

// }
