// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertNotEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertTrue;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.concurrent.ExecutionException;
// import java.util.concurrent.Future;

// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;

// import com.avigosolutions.participantservice.crm.async.service.CrmAsyncService;
// import com.avigosolutions.participantservice.crm.service.CRMContactsService;
// import com.avigosolutions.participantservice.model.CRMCategory;
// import com.avigosolutions.participantservice.model.CRMContact;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// public class CRMContactServiceTest {

// 	// @Autowired
// 	// CRMContactsService crmContactsService;
	
// 	// @Autowired
// 	// CrmAsyncService asyncCRMService;

// 	// @Before
// 	// public void setup() {

// 	// }

// 	// @After
// 	// public void tearDown() {

// 	// }

// 	// @Test
// 	// public void testCreateContacts() {
// 	// 	List<CRMContact> contacts = getTestContacts();
// 	// 	crmContactsService.createContacts(contacts,"1234");
// 	// }

// 	// private List<CRMContact> getTestContacts() {
// 	// 	List<CRMContact> contacts = new ArrayList<>();
// 	// 	CRMCategory category = new CRMCategory();
// 	// 	category.withTrialId(3l).withTrialName("trail1").withSearchName("search1").withLookupCode("C_ABC");
// 	// 	CRMContact contact1 = new CRMContact();
// 	// 	contact1.withCrmCategory(category).withAge(10).withEmail("s@gmail.com").withFirstName("sun").withLastName("kak")
// 	// 			.withParticipantId("12344322").withZipCode("3322");
// 	// 	contacts.add(contact1);
// 	// 	return contacts;
// 	// }
	
// 	// @Test
// 	// public void setup_asyncSaveContact() throws InterruptedException, ExecutionException {
// 	// 	 Future<Boolean> bResult=asyncCRMService.processContacts(getTestContacts(),null,null,null);
// 	// 	 assertNotEquals(false,bResult.get());
// 	// 	 assertTrue(bResult.get());
// 	// }
	
// }
