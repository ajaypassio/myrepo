// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.mockito.Mockito.when;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;

// import com.avigosolutions.participantservice.model.ParticipantQuestion;
// import com.avigosolutions.participantservice.repository.ParticipantQuestionRepository;

// public class ParticipantQuestionServiceImplMocksTest {

	
// 	// @InjectMocks
// 	// ParticipantQuestionServiceImpl questionServiceImpl;
	
// 	// @Mock
// 	// ParticipantQuestionRepository participantQuestionRepository;
	
// 	// ParticipantQuestion participantQuestion;
	
// 	// @Before
// 	// public void setUp(){
// 	// 	MockitoAnnotations.initMocks(this);
// 	// 	participantQuestion = new ParticipantQuestion();
// 	// 	participantQuestion.withAnswer("Test Answer");
		
// 	// }
	
// 	// /*
// 	//  * Test save() function
// 	//  */
// 	// @Test
// 	// public void saveTest() throws Exception {
// 	// 	participantQuestion.withParticipantId("1");
// 	// 	when(participantQuestionRepository.save(participantQuestion)).thenReturn(participantQuestion);
// 	// 	ParticipantQuestion persisted = questionServiceImpl.save(participantQuestion);
// 	// 	assertEquals("Expected value 1 :", "1", persisted.getParticipantId());
// 	// }
	
// }
