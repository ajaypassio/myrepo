// package com.avigosolutions.participantservice.service;

// // import static org.junit.Assert.assertEquals;
// // import static org.junit.Assert.assertNotNull;
// // import static org.mockito.Matchers.*;
// // import static org.mockito.Mockito.doNothing;
// // import static org.mockito.Mockito.when;

// // import java.math.BigInteger;
// // import java.text.ParseException;
// // import java.text.SimpleDateFormat;
// // import java.util.ArrayList;
// // import java.util.Arrays;
// // import java.util.Date;
// // import java.util.List;
// // import java.util.stream.Collectors;

// // import org.junit.Before;
// // import org.junit.Test;
// // import org.mockito.InjectMocks;
// // import org.mockito.Mock;
// // import org.mockito.MockitoAnnotations;
// // import org.springframework.beans.factory.annotation.Autowired;
// // import org.springframework.data.domain.Page;
// // import org.springframework.data.domain.PageImpl;
// // import org.springframework.data.domain.PageRequest;
// // import org.springframework.test.util.ReflectionTestUtils;

// // import com.avigosolutions.participantservice.dto.CountModel;
// // import com.avigosolutions.participantservice.dto.ParticipantQuestionnaireDto;
// // import com.avigosolutions.participantservice.dto.ParticipantTrialState;
// // import com.avigosolutions.participantservice.model.Participant;
// // import com.avigosolutions.participantservice.model.ParticipantQuestionnaire;
// // import com.avigosolutions.participantservice.model.ParticipantStudySite;
// // import com.avigosolutions.participantservice.model.TrialParticipantStatusAudit;
// // import com.avigosolutions.participantservice.model.TrialStatusAudit;
// // import com.avigosolutions.participantservice.repository.ParticipantQuestionnaireRepository;
// // import com.avigosolutions.participantservice.repository.ParticipantStudySiteRepository;
// // import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
// // import com.avigosolutions.participantservice.response.model.DateModel;
// // import com.avigosolutions.participantservice.response.model.ResponseObjectModel;

// public class ParticipantQuestionnaireServiceImplTest {
	
// 	// @Mock
// 	// ParticipantStudySiteRepository participantStudySiteRepository;
	
// 	// @Mock
// 	// ParticipantQuestionnaireRepository participantQuestionnaireRepository;


// 	// @Mock
// 	// ParticipantStudySiteService participantStudySiteService;

// 	// @Mock
// 	// ParticipantService participantService;
	
	
// 	// @InjectMocks
// 	// ParticipantQuestionnaireServiceImpl participantQuestionnaireServiceImpl;
	
// 	// protected Participant participant;
// 	// protected List<ParticipantQuestionnaire> participantQuestionnaireList;
// 	// protected ParticipantStudySite participantStudySite;
// 	// protected List<CountModel> lstCount;
// 	// protected ParticipantQuestionnaire participantQuestionnaire;
// 	// protected List<Object[]> lstObject1,lstObject2;
// 	// protected List<ParticipantStudySite> participantStudySiteList;
// 	// protected ParticipantRequestFilterModel participantFilterRequest;
// 	// private Page<ParticipantQuestionnaire> pageParticipantQuestionnaire;
// 	// protected PageRequest pageRequest;
// 	// private ResponseObjectModel responseObjectModel;
	
// 	// @Before
// 	// public void init() throws ParseException {
// 	// 	MockitoAnnotations.initMocks(this);
// 	// 	responseObjectModel = new ResponseObjectModel();
// 	// 	//ReflectionTestUtils.setField(participantQuestionnaireServiceImpl,"responseObjectModel",responseObjectModel);
// 	// 	participantStudySiteList = new ArrayList<>();
// 	// 	participant = new Participant();
// 	// 	participant.withDob(new SimpleDateFormat("yyyy-mm-dd").parse("2018-03-26")).withContactNumber("9999999999").withFirstName("first").withLastName("last");
// 	// 	participant.setUpdatedBy(1L);
		
		
// 	// 	participantQuestionnaireList = new ArrayList<>();
// 	// 	lstObject1 = new ArrayList<>();
// 	// 	lstObject2 = new ArrayList<>();
// 	// 	lstCount = new ArrayList<CountModel>();
		
		
// 	// 	participantQuestionnaire = new ParticipantQuestionnaire();
// 	// 	participantQuestionnaire.setParticipantQuestionnaireId(1L);
// 	// 	participantQuestionnaire.withParticipant(participant);
// 	// 	participantQuestionnaire.withInterest(true);
// 	// 	participantQuestionnaire.setCreatedOn(new SimpleDateFormat("yyyy-mm-dd").parse("2018-03-23"));
// 	// 	participantQuestionnaireList.add(participantQuestionnaire);
		
// 	// 	participantStudySite = new ParticipantStudySite();
// 	// 	participantStudySite.withStudySiteId(1L);
// 	// 	participantStudySite.withParticipantId("1L");
// 	// 	participantStudySite.withParticipantStatusId(1L);
// 	// 	participantStudySite.withTrialId(1L);
// 	// 	participantStudySite.withCreatedOn(new SimpleDateFormat("yyyy-mm-dd").parse("2018-03-23"));
// 	// 	participantStudySiteList.add(participantStudySite);
		
// 	// 	CountModel countModel=new CountModel();
// 	// 	countModel.setCount(new BigInteger("2"));
// 	// 	countModel.setId(new BigInteger("1"));
// 	// 	countModel.setStatusId(new BigInteger("1"));
// 	// 	lstCount.add(countModel);
		
// 	// 	BigInteger[] data1 = {new BigInteger("1"),new BigInteger("2"),new BigInteger("1")};
// 	// 	lstObject1.add(data1);
// 	// 	lstObject1.add(data1);
		
// 	// 	Object[] data2 = {new Date(),new Date(),new BigInteger("1")};
// 	// 	lstObject2.add(data2);
// 	// 	lstObject2.add(data2);
		
// 	// 	participantFilterRequest = new ParticipantRequestFilterModel();
// 	// 	participantFilterRequest.setStart(00);
// 	// 	participantFilterRequest.setPageSize(10);
// 	// 	participantFilterRequest.setColumnToSort("");		
		
		
// 	// 	pageParticipantQuestionnaire = new PageImpl<>(participantQuestionnaireList,pageRequest,participantQuestionnaireList.size());
// 	// }
	
// 	// @Test
// 	// public void saveTest() {
// 	// 	when(participantQuestionnaireRepository.save(any(ParticipantQuestionnaire.class))).thenReturn(participantQuestionnaire);
// 	// 	ParticipantQuestionnaire response = participantQuestionnaireServiceImpl.save(participantQuestionnaire);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(participantQuestionnaire.getParticipantId(),response.getParticipantId());
// 	// }
	
// 	// // @Test
// 	// public void saveParticipantQuestionnaireTest() {
// 	// 	when(participantQuestionnaireRepository.save(any(ParticipantQuestionnaire.class))).thenReturn(participantQuestionnaire);
// 	// 	when(participantQuestionnaireRepository.findTop1ByparticipantIdByquestionnaireId(anyString(),anyLong())).thenReturn(participantQuestionnaire);
// 	// 	//doNothing().when(participantService).triggerSelectedStudySite(any(ParticipantTrialState.class));
// 	// 	ParticipantQuestionnaire response = participantQuestionnaireServiceImpl.saveParticipantQuestionnaire(1L,participantQuestionnaire);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.getParticipantId(),participantQuestionnaire.getParticipantId());
// 	// }
	
	
// 	// @Test
// 	// public void getParticipantQuestionnaireTest() {
// 	// 	when(participantQuestionnaireRepository.findOne(anyLong())).thenReturn(participantQuestionnaire);
// 	// 	ParticipantQuestionnaire response = participantQuestionnaireServiceImpl.getParticipantQuestionnaire(1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.getParticipantId(),participantQuestionnaire.getParticipantId());
// 	// }
	
	
// 	// @Test
// 	// public void getParticipantQuestionnaireByParticipantQuestionnaireIdTest() {
// 	// 	when(participantQuestionnaireRepository.findTop1ByparticipantIdByquestionnaireId(anyString(),anyLong())).thenReturn(participantQuestionnaire);
// 	// 	ParticipantQuestionnaire response = participantQuestionnaireServiceImpl.getParticipantQuestionnaireByParticipantQuestionnaireId("1L",1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.getParticipantId(),participantQuestionnaire.getParticipantId());
// 	// }
	
	
// 	// @Test
// 	// public void getParticipantQuestionnaireTest_1() {
// 	// 	when(participantQuestionnaireRepository.findTop1ByparticipantIdByquestionnaireId(anyString(),anyLong())).thenReturn(participantQuestionnaire);
// 	// 	//when(participantRepository.findByParticipantId(anyLong())).thenReturn(participantQuestionnaire);
		
// 	// 	ParticipantQuestionnaire response = participantQuestionnaireServiceImpl.getParticipantQuestionnaire("1L",1L,true);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.getParticipantId(),participantQuestionnaire.getParticipantId());
// 	// }
	

// 	// @Test
// 	// public void getParticipantQuestionnairesTest() {
		
// 	// 	when(participantQuestionnaireRepository
// 	// 			.findByparticipantId(anyString())).thenReturn(participantQuestionnaireList);
// 	// 	//when(participantRepository.findByParticipantId(anyLong())).thenReturn(participantQuestionnaire);
		
// 	// 	List<ParticipantQuestionnaireDto> response = participantQuestionnaireServiceImpl.getParticipantQuestionnaires("1L");
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.size(),participantQuestionnaireList.size());
// 	// }
	
// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest() {
		
// 	// 	when(participantQuestionnaireRepository
// 	// 			.findParticipantsByTrialIdAndStudySiteId(anyLong(),anyLong())).thenReturn(participantQuestionnaireList);
// 	// 	when(participantStudySiteRepository
// 	// 			.findByParticipantIdInAndTrialIdAndStudySiteId(anyListOf(String.class),anyLong(),anyLong())).thenReturn(participantStudySiteList);
// 	// 	List<ParticipantQuestionnaireDto> response = participantQuestionnaireServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L,2L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.size(),participantQuestionnaireList.size());
// 	// }
	
// 	// @Test
// 	// public void getParticipantQuestionnairebyParticipantIdTest() {
		
// 	// 	when(participantQuestionnaireRepository.findByparticipantId(anyString())).thenReturn(participantQuestionnaireList);
		
// 	// 	List<ParticipantQuestionnaire> response = participantQuestionnaireServiceImpl.getParticipantQuestionnairebyParticipantId("1L");
// 	// 	assertNotNull(response);
// 	// 	assertEquals(response.size(),participantQuestionnaireList.size());
// 	// }
	
	
	
// }
