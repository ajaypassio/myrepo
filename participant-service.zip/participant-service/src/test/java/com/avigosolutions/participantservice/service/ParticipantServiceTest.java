// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertNull;
// import static org.junit.Assert.assertTrue;

// import java.util.Optional;
// import java.util.Set;

// import org.junit.After;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.participantservice.Events;
// import com.avigosolutions.participantservice.ParticipantStateHandler;
// import com.avigosolutions.participantservice.States;
// import com.avigosolutions.participantservice.dto.ParticipantTrialState;
// import com.avigosolutions.participantservice.model.Participant;

// import junit.framework.Assert;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class ParticipantServiceTest {

// // 	@Autowired
// // 	ParticipantServiceImpl participantService;

// // 	@Before
// // 	public void setup() {

// // 	}

// // 	@After
// // 	public void tearDown() {

// // 	}
// // 	@Test
// // 	public void testParticipantFind() {
// // 		String participantId = "1";
// // 		Participant p = participantService.findOne(participantId);
// // 		assertNotNull("participant found with id: " + participantId, p);
// // 	}


// // 	@Test
// // 	@Rollback
// // 	public void testSaveParticipant() {
// // 		String participantId = "1000";
// // 		Participant p = new Participant()
// // 								.withParticipantId(participantId)
// // 								.withAddress("1256 main st., boston, ma 03030")
// // 								.withCity("Boston")
							
// // 								;
// // 		Participant pRet = participantService.save(p);
// // 		assertNotNull("participant could not be saved with id: " + participantId, pRet);
		
// // //		Participant p2 = participantService.findOne(participantId);
// // //		assertNotNull("participant not found with id: " + participantId, p2);
		
// // 	}

	
// }
