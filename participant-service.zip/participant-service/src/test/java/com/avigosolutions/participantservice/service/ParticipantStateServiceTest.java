// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.junit.Assert.assertTrue;

// import java.util.List;
// import java.util.Optional;
// import java.util.Set;

// import org.junit.After;
// import org.junit.Assert;
// import org.junit.Before;
// import org.junit.Test;
// import org.junit.runner.RunWith;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.boot.test.context.SpringBootTest;
// import org.springframework.test.annotation.Rollback;
// import org.springframework.test.context.ActiveProfiles;
// import org.springframework.test.context.junit4.SpringRunner;
// import org.springframework.transaction.annotation.Transactional;

// import com.avigosolutions.participantservice.Events;
// import com.avigosolutions.participantservice.ParticipantStateHandler;
// import com.avigosolutions.participantservice.States;
// import com.avigosolutions.participantservice.dto.ParticipantTrialState;

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
// public class ParticipantStateServiceTest {

// 	@Autowired
// 	ParticipantStateService participantService;

// 	@Autowired
// 	ParticipantStateHandler participantStateHandler;
	
// 	private static long TRAIL_ID= 1l;
// 	private static String PARTICIPANT_ID = "1";
	
// 	private static String webhookRequest1 = "{\"campaignId\":\"5e1adec8-6a12-49f7-9554-2fcecbef344a\",\"trailId\":\"45c390fb-7429-4fd7-b834-63c4059164f2\",\"campaignCategories\":\"smt-.-10-.-saved\",\"recipients\":[{\"id\":\"b383d236-9da8-4b94-b7b9-994b8e50f491\",\"extId\":\"181571862\",\"name\":\"Sindhu KUMAR\",\"email\":\"test.TEST@gmailTEST.com\",\"vars\":{\"TrialID\":\"84\",\"Last Name\":\"KUMAR\",\"First Name\":\"Sindhu\"}}]}";
	
// 	private static String webhookRequest2 = "{\"campaignId\":\"5e1adec8-6a12-49f7-9554-2fcecbef344a\",\"trailId\":\"45c390fb-7429-4fd7-b834-63c4059164f2\",\"campaignCategories\":\"smt-saved\",\"recipients\":[{\"id\":\"b383d236-9da8-4b94-b7b9-994b8e50f491\",\"extId\":\"181571862\",\"name\":\"Sindhu KUMAR\",\"email\":\"test.TEST@gmailTEST.com\",\"vars\":{\"TrialID\":\"84\",\"Last Name\":\"KUMAR\",\"First Name\":\"Sindhu\"}}]}";

// 	@Before
// 	public void setup() {

// 	}

// 	@After
// 	public void tearDown() {

// 	}
	
// 	@Test
// 	public void testParseJson_UsingTrialIdFromCategory() {
// 		List<ParticipantTrialState>  partTrial = new ParticipantStateServiceImpl().parseJSON(webhookRequest1);
// 		assertNotNull(partTrial);
// 		assertEquals(new Long(10),partTrial.get(0).getTrialId());
// 	}
	
// 	@Test
// 	public void testParseJson_UsingTrialIdFromTrialId() {
// 		List<ParticipantTrialState>  partTrial = new ParticipantStateServiceImpl().parseJSON(webhookRequest2);
// 		assertNotNull(partTrial);
// 		assertEquals(new Long(84),partTrial.get(0).getTrialId());
// 	}

// 	@Test
// 	public void testStatesEventsCompatability() {
// 		Set<Events> events = participantStateHandler.getAllPossibleEvents(States.OUTREACHED);
// 		assertTrue(events.size() > 0);
// 		System.out.println("Possible Events: " + events);

// 		Set<States> states = participantStateHandler.getAllPossibleStates(States.OUTREACHED);
// 		assertTrue(states.size() > 0);
// 		System.out.println("Possible states: " + states);

// 		states = participantStateHandler.getAllPossibleStates(States.SITE_CONTACTING);
// 		assertTrue(states.size() > 0);
// 		System.out.println("Possible states: " + states);

// 		states = participantStateHandler.getAllPossibleStates(States.VISIT_SCHEDUCLED);
// 		assertTrue(states.size() > 0);
// 		System.out.println("Possible states: " + states);

// 		Events event = participantStateHandler.getMatchingEvent(States.OUTREACHED, States.SCREENING).get();
// 		System.out.println("Possible Event: " + event);

// 		event = participantStateHandler.getMatchingEvent(States.SITE_CONTACTING, States.VISIT_SCHEDUCLED).get();
// 		System.out.println("Possible Event: " + event);

// 		event = participantStateHandler.getMatchingEvent(States.SITE_CONTACTING, States.SITE_CONTACTING).get();
// 		System.out.println("Possible Event: " + event);

// 		Optional<Events> event2 = participantStateHandler.getMatchingEvent(States.SITE_CONTACTING, States.SCREENING);
// 		assertTrue(!event2.isPresent());
// 		System.out.println("Possible Event: " + event);
// 	}

// 	@Test
// 	@Rollback
// 	public void testValidParticipantStates() {
// 		ParticipantTrialState ptState = getStubParticipantTrialState(PARTICIPANT_ID, TRAIL_ID);
// 		Set<States> states = participantService.getValidStates(ptState);
// 		assertTrue(states.size() > 0);
// 	}

// 	@Test
// 	@Rollback
// 	public void testMoveToParticipantStates() {
// 		ParticipantTrialState ptState = getStubParticipantTrialState(PARTICIPANT_ID, TRAIL_ID);
// 		ptState.setTargetStateCode(States.SITE_CONTACTING.getCode());
// 		States state = participantService.moveToStatus(ptState,null);
// 		assertTrue(state == null);
// 	}

// 	@Test
// 	@Rollback
// 	public void testPatientTrialStateTransition() throws InterruptedException {
// 		ParticipantTrialState[] ptStates = new ParticipantTrialState[1];
// 		ptStates[0] = getStubParticipantTrialState(PARTICIPANT_ID, TRAIL_ID);
// 		for (ParticipantTrialState ptState : ptStates) {
// 			States state = participantService.triggerEmailCampaign(ptState,null);
// 			assertEquals(state, States.OUTREACHED);
// 			Thread.sleep(2 * 1000l);
// 			state = participantService.triggerEmailCampaign(ptState,null);
// 			assertEquals(state, States.OUTREACHED);
// 			Thread.sleep(2 * 1000l);
// 			state = participantService.triggerAttemptQuestion(ptState,null);
// 			assertEquals(state, States.SCREENING);
// 		}
// 	}

// 	private ParticipantTrialState getStubParticipantTrialState(String participantId, long trialId) {
// 		ParticipantTrialState pstate = new ParticipantTrialState(participantId, trialId);
// 		pstate.setStatusNotes("EMAIL");
// 		return pstate;
// 	}
// }
