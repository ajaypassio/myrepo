// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.mockito.Matchers.*;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.math.BigInteger;
// import java.text.ParseException;
// import java.text.SimpleDateFormat;
// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Date;
// import java.util.List;
// import java.util.stream.Collectors;

// import org.junit.Before;
// import org.junit.Ignore;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.PageImpl;
// import org.springframework.data.domain.PageRequest;
// import org.springframework.statemachine.config.configurers.StateConfigurer.History;
// import org.springframework.test.util.ReflectionTestUtils;

// import com.avigosolutions.participantservice.common.CommonUtil;
// import com.avigosolutions.participantservice.dto.CountModel;
// import com.avigosolutions.participantservice.model.ParticipantStudySite;
// import com.avigosolutions.participantservice.model.ParticipantStudySiteHistory;
// import com.avigosolutions.participantservice.model.TrialParticipantStatusAudit;
// import com.avigosolutions.participantservice.model.TrialStatusAudit;
// import com.avigosolutions.participantservice.repository.ParticipantStudySiteHistoryRepository;
// import com.avigosolutions.participantservice.repository.ParticipantStudySiteRepository;
// import com.avigosolutions.participantservice.request.model.ParticipantRequestFilterModel;
// import com.avigosolutions.participantservice.response.model.DateModel;
// import com.avigosolutions.participantservice.response.model.ResponseObjectModel;
// @Ignore
// public class ParticipantStudySiteServiceImplTest {

// 	// @Mock
// 	// ParticipantStudySiteRepository participantStudySiteRepository;

// 	// @Mock
// 	// ParticipantStudySiteHistoryRepository participantStudySiteHistoryRepository;

// 	// @InjectMocks
// 	// ParticipantStudySiteServiceImpl participantStudySiteServiceImpl;

// 	// protected TrialParticipantStatusAudit statusAuditObj;
// 	// protected TrialStatusAudit trialAuditObj;
// 	// protected List<TrialParticipantStatusAudit> statusAuditObjList;
// 	// protected List<TrialStatusAudit> trialAuditObjList;
// 	// protected List<ParticipantStudySite> participantStudySiteList;
// 	// protected List<CountModel> lstCount;
// 	// protected ParticipantStudySite participantStudySite;
// 	// protected List<Object[]> lstObject1, lstObject2;
// 	// protected ParticipantRequestFilterModel participantFilterRequest;
// 	// private Page<ParticipantStudySite> pageParticipantStudySite;
// 	// protected PageRequest pageRequest;
// 	// private ResponseObjectModel responseObjectModel;

// 	// protected ParticipantStudySiteHistory history;
	
// 	// private Page<ParticipantStudySiteHistory> pageParticipantStudySiteHistory;
	
// 	// protected List<ParticipantStudySiteHistory> participantStudySiteHistoryList;

// 	// @Before
// 	// public void init() throws ParseException {
// 	// 	MockitoAnnotations.initMocks(this);
// 	// 	responseObjectModel = new ResponseObjectModel();
// 	// 	history = new ParticipantStudySiteHistory();
// 	// 	ReflectionTestUtils.setField(participantStudySiteServiceImpl, "responseObjectModel", responseObjectModel);
// 	// 	statusAuditObjList = new ArrayList<>();
// 	// 	trialAuditObjList = new ArrayList<>();
// 	// 	participantStudySiteList = new ArrayList<>();
// 	// 	lstObject1 = new ArrayList<>();
// 	// 	lstObject2 = new ArrayList<>();
// 	// 	lstCount = new ArrayList<CountModel>();
// 	// 	statusAuditObj = new TrialParticipantStatusAudit();
// 	// 	statusAuditObj.withFromStatusId(1L);
// 	// 	statusAuditObj.withParticipantId("1L");
// 	// 	statusAuditObj.withTrialId(1L);
// 	// 	statusAuditObjList.add(statusAuditObj);

// 	// 	trialAuditObj = new TrialStatusAudit();
// 	// 	trialAuditObj.withParticipantCount(1);
// 	// 	trialAuditObj.withTrialId(1L);
// 	// 	trialAuditObjList.add(trialAuditObj);

// 	// 	participantStudySite = new ParticipantStudySite();
// 	// 	participantStudySite.withStudySiteId(1L);
// 	// 	participantStudySite.withParticipantId("1L");
// 	// 	participantStudySite.withParticipantStatusId(1L);
// 	// 	participantStudySite.withTrialId(1L);
// 	// 	participantStudySite.withCreatedOn(new SimpleDateFormat("yyyy-mm-dd").parse("2018-03-23"));
// 	// 	participantStudySiteList.add(participantStudySite);

// 	// 	CountModel countModel = new CountModel();
// 	// 	countModel.setCount(new BigInteger("2"));
// 	// 	countModel.setId(new BigInteger("1"));
// 	// 	countModel.setStatusId(new BigInteger("1"));
// 	// 	lstCount.add(countModel);

// 	// 	BigInteger[] data1 = { new BigInteger("1"), new BigInteger("2"), new BigInteger("1") };
// 	// 	lstObject1.add(data1);
// 	// 	lstObject1.add(data1);

// 	// 	Object[] data2 = { new Date(), new Date(), new BigInteger("1") };
// 	// 	lstObject2.add(data2);
// 	// 	lstObject2.add(data2);

// 	// 	participantFilterRequest = new ParticipantRequestFilterModel();
// 	// 	participantFilterRequest.setStart(00);
// 	// 	participantFilterRequest.setPageSize(10);
// 	// 	participantFilterRequest.setColumnToSort("");

// 	// 	pageParticipantStudySite = new PageImpl<>(participantStudySiteList, pageRequest,
// 	// 			participantStudySiteList.size());
		
// 	// 	pageParticipantStudySiteHistory = new PageImpl<>(participantStudySiteHistoryList, pageRequest,
// 	// 			participantStudySiteList.size());
// 	// }

// 	// @Test
// 	// public void saveTest() {
// 	// 	when(participantStudySiteRepository.saveAndFlush(any(ParticipantStudySite.class)))
// 	// 			.thenReturn(participantStudySite);
// 	// 	ParticipantStudySite response = participantStudySiteServiceImpl.save(participantStudySite);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(statusAuditObj.getParticipantId(), response.getParticipantId());
// 	// }

// 	// @Test
// 	// public void findByParticipantIdAndTrialIdTest() {
// 	// 	when(participantStudySiteRepository.findByParticipantIdAndTrialId(anyString(), anyLong()))
// 	// 			.thenReturn(participantStudySite);
// 	// 	ParticipantStudySite response = participantStudySiteServiceImpl.findByParticipantIdAndTrialId("1L", 1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(statusAuditObj.getParticipantId(), response.getParticipantId());
// 	// }

// 	// @Test
// 	// public void countByParticipantStatusIdAndStudySiteIdAndTrialIdTest() {
// 	// 	when(participantStudySiteRepository.countByParticipantStatusIdAndStudySiteIdInAndTrialId(anyListOf(Long.class),
// 	// 			anyListOf(Long.class), anyLong())).thenReturn(lstObject1);
// 	// 	List<CountModel> response = participantStudySiteServiceImpl.countByParticipantStatusIdAndStudySiteIdAndTrialId(
// 	// 			participantStudySiteList.stream().map(ParticipantStudySite::getParticipantStatusId)
// 	// 					.collect(Collectors.toList()),
// 	// 			participantStudySiteList.stream().map(ParticipantStudySite::getStudySiteId)
// 	// 					.collect(Collectors.toList()),
// 	// 			1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(lstObject1.size(), response.size());
// 	// }

// 	// @Test
// 	// public void countByTrialIdAndParticipantStatusIdTest() {
// 	// 	when(participantStudySiteRepository.countByTrialIdAndParticipantStatusId(anyLong(), anyLong())).thenReturn(2L);
// 	// 	Long response = participantStudySiteServiceImpl.countByTrialIdAndParticipantStatusId(1L, 1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(2L, response.longValue());
// 	// }

// 	// @Test
// 	// public void findFirstAndLastPatientDateTest() {
// 	// 	when(participantStudySiteRepository.findFirstAndLastPatientDate(anyLong())).thenReturn(lstObject2);
// 	// 	List<DateModel> response = participantStudySiteServiceImpl.findFirstAndLastPatientDate(1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(lstObject2.size(), response.size());
// 	// }

// 	// @Test
// 	// public void countByParticipantStatusIdInAndTrialIdInTest() {
// 	// 	when(participantStudySiteRepository.countByTrialIdParticipantStatusId(anyListOf(Long.class),
// 	// 			anyListOf(Long.class))).thenReturn(lstObject1);
// 	// 	List<CountModel> response = participantStudySiteServiceImpl.countByParticipantStatusIdInAndTrialIdIn(
// 	// 			participantStudySiteList.stream().map(ParticipantStudySite::getParticipantStatusId)
// 	// 					.collect(Collectors.toList()),
// 	// 			participantStudySiteList.stream().map(ParticipantStudySite::getTrialId).collect(Collectors.toList()));
// 	// 	assertNotNull(response);
// 	// 	assertEquals(lstObject1.size(), response.size());
// 	// }

// 	// @Test
// 	// public void countByParticipantStatusIdAndTrialIdTest() {
// 	// 	when(participantStudySiteRepository.countByParticipantStatusIdAndTrialId(anyListOf(Long.class), anyLong()))
// 	// 			.thenReturn(lstObject1);
// 	// 	List<CountModel> response = participantStudySiteServiceImpl
// 	// 			.countByParticipantStatusIdAndTrialId(participantStudySiteList.stream()
// 	// 					.map(ParticipantStudySite::getParticipantStatusId).collect(Collectors.toList()), 1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(lstObject1.size(), response.size());
// 	// }

// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest() {
// 	// 	participantFilterRequest.setParticipantName("Name");
// 	// 	participantFilterRequest.setStates(Arrays.asList("FLorida", "Albama"));
// 	// 	participantFilterRequest.setCities(Arrays.asList("Newyork", "Los Angeles"));

// 	// 	when(participantStudySiteRepository
// 	// 			.findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContaining(
// 	// 					anyLong(), anyLong(), anyListOf(String.class), anyListOf(String.class), anyString(),
// 	// 					anyString(), any(PageRequest.class))).thenReturn(pageParticipantStudySite);
// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L, 1L,
// 	// 			participantFilterRequest);

// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest_1() {

// 	// 	participantFilterRequest.setCities(Arrays.asList("Newyork", "Los Angeles"));

// 	// 	when(participantStudySiteRepository
// 	// 			.findByTrialIdAndStudySiteIdAndParticipantFirstNameContainingOrParticipantLastNameContaining(anyLong(),
// 	// 					anyLong(), anyString(), anyString(), any(PageRequest.class)))
// 	// 							.thenReturn(pageParticipantStudySite);
// 	// 	when(participantStudySiteRepository.findByTrialIdAndStudySiteIdAndParticipantCityIn(anyLong(), anyLong(),
// 	// 			anyListOf(String.class), any(PageRequest.class))).thenReturn(pageParticipantStudySite);
// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L, 1L,
// 	// 			participantFilterRequest);

// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest_2() {
// 	// 	participantFilterRequest.setStates(Arrays.asList("FLorida", "Albama"));
// 	// 	when(participantStudySiteRepository
// 	// 			.findByTrialIdAndStudySiteIdAndParticipantFirstNameContainingOrParticipantLastNameContaining(anyLong(),
// 	// 					anyLong(), anyString(), anyString(), any(PageRequest.class)))
// 	// 							.thenReturn(pageParticipantStudySite);
// 	// 	when(participantStudySiteRepository.findByTrialIdAndStudySiteIdAndParticipantStateIn(anyLong(), anyLong(),
// 	// 			anyListOf(String.class), any(PageRequest.class))).thenReturn(pageParticipantStudySite);
// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L, 1L,
// 	// 			participantFilterRequest);

// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest_4() {
// 	// 	participantFilterRequest.setAgeEnd(35);
// 	// 	participantFilterRequest.setAgeStart(25);
// 	// 	when(participantStudySiteRepository.findByParticipantDobBetween(any(Date.class), any(Date.class),
// 	// 			any(PageRequest.class))).thenReturn(pageParticipantStudySite);

// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L, 1L,
// 	// 			participantFilterRequest);

// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest_5() {
// 	// 	when(participantStudySiteRepository.findByTrialIdAndStudySiteId(anyLong(), anyLong(), any(PageRequest.class)))
// 	// 			.thenReturn(pageParticipantStudySite);

// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L, 1L,
// 	// 			participantFilterRequest);

// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void getParticipantsbyTrialIdAndStudySiteIdTest_6() {
// 	// 	participantFilterRequest.setParticipantName("Name");
// 	// 	participantFilterRequest.setStates(Arrays.asList("FLorida", "Albama"));
// 	// 	participantFilterRequest.setCities(Arrays.asList("Newyork", "Los Angeles"));
// 	// 	participantFilterRequest.setParticipantIds(Arrays.asList("1L", "2L"));
// 	// 	participantFilterRequest.setGender(Arrays.asList("M", "F"));
// 	// 	participantFilterRequest.setAgeEnd(35);
// 	// 	participantFilterRequest.setAgeStart(25);

// 	// 	when(participantStudySiteRepository
// 	// 			.findByTrialIdAndStudySiteIdOrParticipantStateInOrParticipantCityInOrParticipantFirstNameContainingOrParticipantLastNameContainingOrParticipantGenderInOrParticipantIdIn(
// 	// 					anyLong(), anyLong(), anyListOf(String.class), anyListOf(String.class), anyString(),
// 	// 					anyString(), anyListOf(String.class), anyListOf(String.class), any(PageRequest.class)))
// 	// 							.thenReturn(pageParticipantStudySite);

// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getParticipantsbyTrialIdAndStudySiteId(1L, 1L,
// 	// 			participantFilterRequest);

// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void testSaveHistory() {

// 	// 	history.withParticipantId("123456").withTrialId(4L).withStudySiteId(10L).withNotes("Contacted the patient.")
// 	// 			.withStatusNotes("Email");
// 	// 	when(participantStudySiteHistoryRepository.save(any(ParticipantStudySiteHistory.class))).thenReturn(history);
// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.saveHistory(history,null);
// 	// 	assertNotNull(res.getData());
// 	// }

// 	// @Test
// 	// public void testGetHistory() {
// 	// 	when(participantStudySiteHistoryRepository.findByParticipantIdAndTrialIdAndStudySiteId(anyString(),anyLong(),anyLong(),any(PageRequest.class))).thenReturn(pageParticipantStudySiteHistory);
// 	// 	ResponseObjectModel res = participantStudySiteServiceImpl.getHistory("", 4L, 10L, 10, 10);
// 	// 	assertNotNull(res.getData());
// 	// }
// }
