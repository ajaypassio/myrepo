// package com.avigosolutions.participantservice.service;

// import static org.junit.Assert.assertEquals;
// import static org.junit.Assert.assertNotNull;
// import static org.mockito.Matchers.*;
// import static org.mockito.Mockito.doNothing;
// import static org.mockito.Mockito.when;

// import java.text.ParseException;
// import java.text.SimpleDateFormat;
// import java.util.ArrayList;
// import java.util.Date;
// import java.util.List;
// import java.util.stream.Collectors;

// import org.junit.Before;
// import org.junit.Test;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.MockitoAnnotations;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.data.domain.PageRequest;
// import org.springframework.test.util.ReflectionTestUtils;

// import com.avigosolutions.participantservice.model.ParticipantStudySite;
// import com.avigosolutions.participantservice.model.TrialParticipantStatusAudit;
// import com.avigosolutions.participantservice.model.TrialStatusAudit;
// import com.avigosolutions.participantservice.repository.TrialParticipantStatusAuditRepository;
// import com.avigosolutions.participantservice.repository.TrialStatusAuditRepository;

// public class ParticipantTrialServiceImplTest {

	
// 	// @Mock
// 	// TrialParticipantStatusAuditRepository participantTrialRepository;

// 	// @Mock
// 	// TrialStatusAuditRepository trialStatusAuditRepository;
	
// 	// @InjectMocks
// 	// ParticipantTrialServiceImpl participantTrialServiceImpl;
	
// 	// protected TrialParticipantStatusAudit statusAuditObj;
// 	// protected TrialStatusAudit trialAuditObj;
// 	// protected List<TrialParticipantStatusAudit> statusAuditObjList;
// 	// protected List<TrialStatusAudit> trialAuditObjList;
// 	// protected ParticipantStudySite participantStudySite;
	
// 	// @Before
// 	// public void init() throws ParseException {
// 	// 	MockitoAnnotations.initMocks(this);
// 	// 	statusAuditObjList = new ArrayList<>();
// 	// 	trialAuditObjList = new ArrayList<>();
		
// 	// 	statusAuditObj = new TrialParticipantStatusAudit();
// 	// 	statusAuditObj.withFromStatusId(1L);
// 	// 	statusAuditObj.withParticipantId("1L");
// 	// 	statusAuditObj.withTrialId(1L);		
// 	// 	statusAuditObjList.add(statusAuditObj);
		
// 	// 	trialAuditObj = new TrialStatusAudit();
// 	// 	trialAuditObj.withParticipantCount(1);
// 	// 	trialAuditObj.withTrialId(1L);
// 	// 	trialAuditObjList.add(trialAuditObj);
		
// 	// 	participantStudySite = new ParticipantStudySite();
// 	// 	participantStudySite.withStudySiteId(1L);
// 	// 	participantStudySite.withParticipantId("1L");
// 	// 	participantStudySite.withTrialId(1L);
// 	// 	participantStudySite.withCreatedOn(new SimpleDateFormat("yyyy-mm-dd").parse("2018-03-23"));
// 	// }
	
// 	// @Test
// 	// public void saveTest() {
// 	// 	when(participantTrialRepository.saveAndFlush(any(TrialParticipantStatusAudit.class))).thenReturn(statusAuditObj);
// 	// 	TrialParticipantStatusAudit response = participantTrialServiceImpl.save(statusAuditObj);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(statusAuditObj.getParticipantId(),response.getParticipantId());
// 	// }
	
// 	// @Test
// 	// public void findTrialParticipantStatusAuditTest() {
// 	// 	when(participantTrialRepository.findByParticipantIdAndTrialId(anyString(),anyLong())).thenReturn(statusAuditObjList);
// 	// 	List<TrialParticipantStatusAudit> response = participantTrialServiceImpl.findTrialParticipantStatusAudit("1L",1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(statusAuditObjList.size(),response.size());
// 	// }
	
// 	// @Test
// 	// public void findTrialParticipantStatusAuditWithStatusTest() {
// 	// 	when(participantTrialRepository.findByParticipantIdAndTrialIdAndFromStatusIdAndToStatusId(anyString(),anyLong(),anyLong(),anyLong())).thenReturn(statusAuditObjList);
// 	// 	List<TrialParticipantStatusAudit> response = participantTrialServiceImpl.findTrialParticipantStatusAudit("1L",1L,1L,2L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(statusAuditObjList.size(),response.size());
// 	// }
	
// 	// @Test
// 	// public void findTrialStatusAuditTest() {
// 	// 	when(trialStatusAuditRepository.findByTrialId(anyLong())).thenReturn(trialAuditObjList);
// 	// 	List<TrialStatusAudit> response = participantTrialServiceImpl.findTrialStatusAudit(1L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(trialAuditObjList.size(),response.size());
// 	// }
	
// 	// @Test
// 	// public void findTrialStatusAuditWithStatusTest() {
// 	// 	when(trialStatusAuditRepository.findByTrialIdAndFromStatusIdAndToStatusId(anyLong(),anyLong(),anyLong())).thenReturn(trialAuditObj);
// 	// 	TrialStatusAudit response = participantTrialServiceImpl.findTrialStatusAudit(1L,1L,2L);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(trialAuditObj.getTrialId(),response.getTrialId());
// 	// }
	
// 	// @Test
// 	// public void saveTrialStatusAuditTest() {		
// 	// 	when(trialStatusAuditRepository.saveAndFlush(any(TrialStatusAudit.class))).thenReturn(trialAuditObj);
// 	// 	TrialStatusAudit response = participantTrialServiceImpl.save(trialAuditObj);
// 	// 	assertNotNull(response);
// 	// 	assertEquals(trialAuditObj.getTrialId(),response.getTrialId());
// 	// }
	
// 	// @Test
// 	// public void storeAuditSummaryTest() {
// 	// 	when(participantTrialRepository.saveAndFlush(any(TrialParticipantStatusAudit.class))).thenReturn(statusAuditObj);
// 	// 	when(participantTrialRepository.findByParticipantIdAndTrialId(anyString(),anyLong())).thenReturn(statusAuditObjList);
// 	// 	when(participantTrialRepository.findByParticipantIdAndTrialIdAndFromStatusIdAndToStatusId(anyString(),anyLong(),anyLong(),anyLong())).thenReturn(statusAuditObjList);
// 	// 	when(trialStatusAuditRepository.findByTrialId(anyLong())).thenReturn(trialAuditObjList);
// 	// 	when(trialStatusAuditRepository.findByTrialIdAndFromStatusIdAndToStatusId(anyLong(),anyLong(),anyLong())).thenReturn(trialAuditObj);
// 	// 	when(trialStatusAuditRepository.saveAndFlush(any(TrialStatusAudit.class))).thenReturn(trialAuditObj);
// 	// 	doNothing().when(trialStatusAuditRepository).updateTrialStatusAudit(anyLong(),anyLong(),anyLong(),anyLong());
		
// 	// 	participantTrialServiceImpl.storeAuditSummary(participantStudySite,1,2);
		
// 	// }
	
// 	// @Test
// 	// public void storeAuditSummaryTest_2() {
// 	// 	when(participantTrialRepository.saveAndFlush(any(TrialParticipantStatusAudit.class))).thenReturn(statusAuditObj);
// 	// 	when(participantTrialRepository.findByParticipantIdAndTrialId(anyString(),anyLong())).thenReturn(statusAuditObjList);
// 	// 	when(participantTrialRepository.findByParticipantIdAndTrialIdAndFromStatusIdAndToStatusId(anyString(),anyLong(),anyLong(),anyLong())).thenReturn(statusAuditObjList);
// 	// 	when(trialStatusAuditRepository.findByTrialId(anyLong())).thenReturn(trialAuditObjList);
// 	// 	when(trialStatusAuditRepository.findByTrialIdAndFromStatusIdAndToStatusId(anyLong(),anyLong(),anyLong())).thenReturn(null);
// 	// 	when(trialStatusAuditRepository.saveAndFlush(any(TrialStatusAudit.class))).thenReturn(trialAuditObj);
// 	// 	doNothing().when(trialStatusAuditRepository).updateTrialStatusAudit(anyLong(),anyLong(),anyLong(),anyLong());
		
// 	// 	participantTrialServiceImpl.storeAuditSummary(participantStudySite,1,2);
		
// 	// }
	
	
// }
