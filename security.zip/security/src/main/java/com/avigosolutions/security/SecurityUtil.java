package com.avigosolutions.security;

import java.util.List;
import java.util.Optional;

import javax.persistence.Convert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.security.dto.UserPermissionDto;
import com.avigosolutions.security.model.AppUser;
import com.avigosolutions.security.service.AppUserService;

@Service("securityUtil")
@Transactional(readOnly = true)
public class SecurityUtil {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private AppUserService appUserService;
	
		
	public boolean hasPermission( HttpHeaders headers, String entityName, String methodType){
		String uniqueIdValue = getUniqueIdValue(headers);
		return appUserService.hasPermission(uniqueIdValue,entityName,methodType);		
	}
	
	public boolean validateHeaderRequestUId(HttpHeaders headers, String requestUId)
	{
		boolean isMatching = true;
		String uniqueIdValue = getUniqueIdValue(headers);
		if(requestUId.isEmpty() || !uniqueIdValue.equals(requestUId))
		{
			logger.info("Param Unique Id -- {} and header Unique Id -- {} not matching", requestUId , uniqueIdValue);
			isMatching = false;
			return isMatching;
		}
		return isMatching;
	}
	
	public String getUniqueIdValue(HttpHeaders headers){
		String uniqueId = "";
		if(headers != null && ! headers.isEmpty()){
			List<String> uniqueValue = headers.get("UUID");			
			if(!uniqueValue.isEmpty()){
				uniqueId =  uniqueValue.get(0).trim();
			}
		}
		return uniqueId;
	}

}
