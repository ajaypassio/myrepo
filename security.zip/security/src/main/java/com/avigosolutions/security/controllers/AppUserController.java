package com.avigosolutions.security.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.avigosolutions.security.dto.UserPermissionDto;
import com.avigosolutions.security.model.AppUser;
import com.avigosolutions.security.model.ResponseAppUserList;
import com.avigosolutions.security.service.AppUserService;

@Controller
@RequestMapping(path="/api/v1")
public class AppUserController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private AppUserService appUserService;
	
	@ResponseBody
	@RequestMapping(path = "/appusers/{id}", method = RequestMethod.GET)
	public ResponseEntity<AppUser> getAppUserById(@PathVariable Long id) {
		Optional<AppUser> optionalAppUserById = this.appUserService.findOne(id);
		ResponseEntity<AppUser> resAppUser = 
				optionalAppUserById.map(aulist -> new ResponseEntity<AppUser> (aulist, HttpStatus.OK ))
											.orElse(new ResponseEntity<AppUser> (HttpStatus.NOT_FOUND));
		return resAppUser;
	}
	
	
	
	@ResponseBody
	@RequestMapping(path = "/appusers", method = RequestMethod.GET)
	public ResponseAppUserList getAllUsers(@RequestHeader HttpHeaders headers) {	

		Optional<List<AppUser>> optionalAppUserList = this.appUserService.findAll();				
		/*ResponseEntity<List<AppUser>> resAppUsers = 
				optionalAppUserList.map(appUsersList -> new ResponseEntity<List<AppUser>> (appUsersList, HttpStatus.OK ))
											.orElse(new ResponseEntity<List<AppUser>> (HttpStatus.NOT_FOUND));*/
		ResponseAppUserList responseAppUserList = new ResponseAppUserList();
		responseAppUserList.setAppUserList(optionalAppUserList.get());
		return responseAppUserList;
	}
	
	@ResponseBody
	@RequestMapping(path = "/appusers/coordinators", method = RequestMethod.GET)
	public ResponseEntity<List<AppUser>> getCoordinatorUsers() {
		
		Optional<List<AppUser>> coordinatorList = this.appUserService.findCoordinators();	
		ResponseEntity<List<AppUser>> resCoordinators = 
				coordinatorList.map(coordinatorUserList -> new ResponseEntity<List<AppUser>> (coordinatorUserList, HttpStatus.OK ))
											.orElse(new ResponseEntity<List<AppUser>> (HttpStatus.NOT_FOUND));
		return resCoordinators;
	}
}




	