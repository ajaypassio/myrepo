

package com.avigosolutions.security.controllers;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.avigosolutions.security.SecurityUtil;
import com.avigosolutions.security.dto.UserPermissionDto;
import com.avigosolutions.security.model.AppRole;
import com.avigosolutions.security.model.AppUser;
import com.avigosolutions.security.repository.AppUserRepository;
import com.avigosolutions.security.service.AppUserService;
import com.avigosolutions.security.service.PermissionMappingService;
import com.avigosolutions.security.service.UserRoleService;

@Controller
@RequestMapping(path="/api/v1")
public class AuthorizationController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private SecurityUtil securityUtil;
	
	@Autowired
	private AppUserService appUserService;
	
	@Autowired
	private AppUserRepository appUserRepository;
	
	@Autowired
	private PermissionMappingService permissionMappingService;
	@Autowired
	private UserRoleService userRoleService;
	
	@ResponseBody
	@RequestMapping(path = "/authz/{uId:.+}/{entityName}/{methodType}", method = RequestMethod.GET)
	public boolean getEntityPermission(@RequestHeader HttpHeaders headers, @PathVariable String uId,@PathVariable String entityName, @PathVariable String methodType) {
		String uniqueId = uId.trim();
		/*if(!securityUtil.validateHeaderRequestUId(headers,uniqueId))
		{
			return false;
		}*/
		logger.info("Get Entity Permission with UId -- {}, EntityName -- {} , MethodType -- {}",uniqueId, entityName, methodType);
		return this.appUserService.hasPermission(uniqueId, entityName, methodType );
	}
	
	// PDRTEST-20 If a uId has a "." characters after the last dot gets truncated. For ex: "stacy.d.whaley" will be converted to "stacy.d"
	// Solution: Change "/authz/user/permission/{uId}" to "/authz/user/permission/{uId:.+}"
	// See: https://www.mkyong.com/spring-mvc/spring-mvc-pathvariable-dot-get-truncated/ and
	// https://stackoverflow.com/questions/16332092/spring-mvc-pathvariable-with-dot-is-getting-truncated
	@ResponseBody
	@RequestMapping(path = "/authz/user/permission/{uId:.+}", method = RequestMethod.GET)
	public ResponseEntity<List<UserPermissionDto>> getLoggedInUserPermission(@RequestHeader HttpHeaders headers, @PathVariable String uId) {
		String uniqueId = uId.trim();
		//fix for 3260 pen-test
		if(!securityUtil.validateHeaderRequestUId(headers,uniqueId))
		{
			return new ResponseEntity<List<UserPermissionDto>>(HttpStatus.UNAUTHORIZED);
		}
		logger.info("Get LoggedInUser Permission with UId -- {}",uniqueId);
		Optional<List<UserPermissionDto>> optinalUserpermList = permissionMappingService.getUserPermissionById(uniqueId);
		return optinalUserpermList.map(userPermsList -> new ResponseEntity<List<UserPermissionDto>> (userPermsList, HttpStatus.OK ))
				.orElse(new ResponseEntity<List<UserPermissionDto>> (HttpStatus.NOT_FOUND));
	}
	
	@ResponseBody
	@RequestMapping(path = "/authz/user/role/{uName:.+}", method = RequestMethod.GET)
	public ResponseEntity<Long> getRole(@RequestHeader HttpHeaders headers, @PathVariable String uName){
		String uniqueId = uName.trim();
		/*if(!securityUtil.validateHeaderRequestUId(headers,uniqueId))
				{
					return new ResponseEntity<Long> (HttpStatus.UNAUTHORIZED);
		}*/
		logger.info("Get Role with UId -- {}",uniqueId);
		Optional<AppRole> optionalAppRole = userRoleService.getRole(uniqueId);
		//return optionalAppRole.map(appRole -> new ResponseEntity<Long>(appRole.getId(),HttpStatus.OK))
		//		.orElse(new ResponseEntity<Long> (HttpStatus.NOT_FOUND));
		
		Optional<AppUser> appUser=appUserRepository.findByUserName(uniqueId);
		return appUser.map(user -> new ResponseEntity<Long>(user.getId(),HttpStatus.OK))
				.orElse(new ResponseEntity<Long> (HttpStatus.NOT_FOUND));
	}
	
}
	