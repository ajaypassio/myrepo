package com.avigosolutions.security.dto;

import java.util.List;

public class UserPermissionDto {
		
	private String entityName;

	public String getEntityName() {
		return this.entityName;
	}

	public UserPermissionDto withEntityName(String entityName) {
		this.entityName = entityName;
		return this;
	}
	

	private String appPermission;

	public String getAppPermission() {
		return this.appPermission;
	}

	public UserPermissionDto withAppPermission(String appPermission) {
		this.appPermission = appPermission;
		return this;
	}
	
	private String appRole;

	public String getAppRole() {
		return this.appRole;
	}

	public UserPermissionDto withAppRole(String appRole) {
		this.appRole = appRole;
		return this;
	}


}
