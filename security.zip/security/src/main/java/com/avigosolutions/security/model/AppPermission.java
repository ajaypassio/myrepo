package com.avigosolutions.security.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="AppPermission")
public class AppPermission implements Serializable {

	private static final long serialVersionUID = 3L;
	
	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;

	public Long getId() {
		return this.id;
	}

	public AppPermission withId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "PermissionName")	
	private String permissionName;

	public String getPermissionName() {
		return this.permissionName;
	}

	public AppPermission withPermissionName(String permissionName) {
		this.permissionName = permissionName;
		return this;
	}
	
	@Column(name = "PermissionValue")	
	private Long permissionValue;

	public Long getPermissionValue() {
		return this.permissionValue;
	}

	public AppPermission withPermissionValue(Long permissionValue) {
		this.permissionValue = permissionValue;
		return this;
	}
		
}


