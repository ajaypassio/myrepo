package com.avigosolutions.security.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="AppRole")
public class AppRole implements Serializable {

	private static final long serialVersionUID = 3L;
	
	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;

	public Long getId() {
		return this.id;
	}

	public AppRole withId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "RoleName")	
	private String roleName;

	public String getRoleName() {
		return this.roleName;
	}

	public AppRole withRoleName(String roleName) {
		this.description = roleName;
		return this;
	}
	
	@Column(name = "Description")	
	private String description;

	public String getDescription() {
		return this.description;
	}

	public AppRole withDescription(String description) {
		this.description = description;
		return this;
	}
		
}


