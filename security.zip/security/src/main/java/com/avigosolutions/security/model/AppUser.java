package com.avigosolutions.security.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="AppUser")
public class AppUser implements Serializable {

	private static final long serialVersionUID = 3L;
	
	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;

	public Long getId() {
		return this.id;
	}

	public AppUser withId(Long id) {
		this.id = id;
		return this;
	}
	
	
	@Column(name = "UniqueId")
	private Long uniqueId;

	public Long getUniqueId() {
		return this.uniqueId;
	}

	public AppUser withUniqueId(Long uniqueId) {
		this.uniqueId = uniqueId;
		return this;
	}
	
	@Column(name = "FirstName")	
	private String firstName;

	public String getFirstName() {
		return this.firstName;
	}

	public AppUser withFirstName(String firstName) {
		this.firstName = firstName;
		return this;
	}
	
	@Column(name = "LastName")	
	private String lastName;

	public String getLastName() {
		return this.lastName;
	}

	public AppUser withLastName(String lastName) {
		this.lastName = lastName;
		return this;
	}
	
	@Column(name = "UserName")	
	private String userName;

	public String getUserName() {
		return this.userName;
	}

	public AppUser withUserName(String userName) {
		this.userName = userName;
		return this;
	}
	
	@Column(name = "Email")	
	private String email;

	public String getEmail() {
		return this.email;
	}

	public AppUser withEmail(String email) {
		this.email = email;
		return this;
	}
	
	@Column(name = "Password")	
	private String password;

	public String getPassword() {
		return this.password;
	}

	public AppUser withPassword(String password) {
		this.password = password;
		return this;
	}
	
	@Column(name = "Enabled")	
	private boolean enabled;

	public boolean getEnabled() {
		return this.enabled;
	}

	public AppUser withEnabled(boolean enabled) {
		this.enabled = enabled;
		return this;
	}
}


