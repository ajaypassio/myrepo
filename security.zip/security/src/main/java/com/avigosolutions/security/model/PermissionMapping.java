package com.avigosolutions.security.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="PermissionMapping")
public class PermissionMapping implements Serializable {

	private static final long serialVersionUID = 3L;
	
	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;

	public Long getId() {
		return this.id;
	}

	public PermissionMapping withId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "EntityName")	
	private String entityName;

	public String getEntityName() {
		return this.entityName;
	}

	public PermissionMapping withEntityName(String entityName) {
		this.entityName = entityName;
		return this;
	}
	
	@Column(name = "RoleId")
	private Long roleId;

	public Long getRoleId() {
		return this.roleId;
	}

	public PermissionMapping withRoleId(Long roleId) {
		this.roleId = roleId;
		return this;
	}
	
	@Column(name = "AppPermission")
	private Long appPermission;

	public Long getAppPermission() {
		return this.appPermission;
	}

	public PermissionMapping withAppPermission(Long appPermission) {
		this.appPermission = appPermission;
		return this;
	}
		
}


