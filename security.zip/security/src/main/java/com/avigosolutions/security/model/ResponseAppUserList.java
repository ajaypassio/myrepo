package com.avigosolutions.security.model;

import java.io.Serializable;
import java.util.List;

public class ResponseAppUserList implements Serializable {
	
	private static final long serialVersionUID = 1L;
	List<AppUser> appUserList;


	public List<AppUser> getAppUserList() {
		return appUserList;
	}

	public void setAppUserList(List<AppUser> appUserList) {
		this.appUserList = appUserList;
	}
	
	

}
