package com.avigosolutions.security.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="UserRole")
public class UserRole implements Serializable {

	private static final long serialVersionUID = 3L;
	
	@Id
	@GeneratedValue
	@Column(name = "Id", nullable = false)
	private Long id;

	public Long getId() {
		return this.id;
	}

	public UserRole withId(Long id) {
		this.id = id;
		return this;
	}
	
	@Column(name = "RoleId")
	private Long roleId;

	public Long getRoleId() {
		return this.roleId;
	}

	public UserRole withRoleId(Long roleId) {
		this.roleId = roleId;
		return this;
	}
	
	@Column(name = "UserId")
	private Long userId;

	public Long getUserId() {
		return this.userId;
	}

	public UserRole withUserId(Long userId) {
		this.userId = userId;
		return this;
	}	
		
}
