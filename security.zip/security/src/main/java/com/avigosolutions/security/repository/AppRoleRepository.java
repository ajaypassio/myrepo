package com.avigosolutions.security.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.avigosolutions.security.model.AppRole;



@Repository
public interface AppRoleRepository extends JpaRepository<AppRole, Long> {
	
	 @Query(	 
	 "SELECT b FROM AppUser a, AppRole b, UserRole c" +
	 " WHERE a.id = c.userId  AND" +
	 " b.id = c.roleId AND" +
	 " a.userName = :uId" ) 	
	 AppRole findRoleByUserName(@Param("uId") String uId );	 
	
}