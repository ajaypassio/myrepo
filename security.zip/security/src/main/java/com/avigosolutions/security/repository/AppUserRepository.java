
package com.avigosolutions.security.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.security.model.AppUser;



@Repository
public interface AppUserRepository extends JpaRepository<AppUser, Long> {
	
	 @Query(	 
	 "SELECT a FROM AppUser a, UserRole b, PermissionMapping c" +
	 " WHERE a.id = b.userId AND" +
	 " b.roleId = c.roleId AND" +
	 " a.userName = :uId AND" +
	 " c.entityName =  :entityName  AND" +
	 " c.appPermission >= :permissionValue")	 	
	 List<AppUser> findByEntityPermission(@Param("uId") String uId, @Param("permissionValue") Long permissionValue, @Param("entityName") String entityName );	 
	 
	 @Query(	 
	 "SELECT a FROM AppUser a, UserRole b" +
	 " WHERE a.id = b.userId AND" +
	 " b.roleId = 4" )	 	
	 List<AppUser> findCoordinators();
	 
	 Optional<AppUser> findByUserName(String user);
	 
}