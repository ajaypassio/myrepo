package com.avigosolutions.security.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.avigosolutions.security.model.AppUser;
import com.avigosolutions.security.model.PermissionMapping;



@Repository
public interface PermissionMappingRepository extends JpaRepository<PermissionMapping, Long> {
	
	 @Query(	 
	 "SELECT a FROM PermissionMapping a, AppUser b, UserRole c" +
	 " WHERE b.id = c.userId  AND" +
	 " a.roleId = c.roleId AND" +
	 " b.userName = :uId" ) 	
	 List<PermissionMapping> findByUserName(@Param("uId") String uId );	 
			 	
}