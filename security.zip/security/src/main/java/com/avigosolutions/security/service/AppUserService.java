package com.avigosolutions.security.service;

import java.security.Principal;
import java.util.List;
import java.util.Optional;
import com.avigosolutions.security.model.AppUser;

public interface AppUserService {

	/**
	 * finds all the AppUser in the system
	 * @return
	 */
	public Optional<List<AppUser>> findAll();
	
	/**
	 * finds the AppUser that matches the id
	 * @param id
	 * @return a AppUser or null if not found
	 */
	public Optional<AppUser> findOne(Long id);
	
		
	public  boolean hasPermission( String uId, String entityName, String methodType);
	
	public Optional<List<AppUser>> findCoordinators();
	
}


