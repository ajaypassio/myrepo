package com.avigosolutions.security.service;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Propagation;

import com.avigosolutions.security.model.AppUser;
import  com.avigosolutions.security.repository.AppUserRepository;

@Service
@Transactional(propagation=Propagation.SUPPORTS, readOnly = true)
public class AppUserServiceImpl implements AppUserService {

	@Autowired
	private AppUserRepository appUserRepository;
	
	@Override
	public Optional<List<AppUser>> findAll() {
		return Optional.ofNullable(appUserRepository.findAll());
	}

	@Override
	public Optional<AppUser> findOne(Long id) {
		return Optional.ofNullable(appUserRepository.findOne(id));
	}
	
	@Override
	public Optional<List<AppUser>> findCoordinators() {
		return Optional.ofNullable(appUserRepository.findCoordinators());
	}
		
	@Override
	public boolean hasPermission( String uId, String entityName, String methodType){	
		List<AppUser> appUsers = appUserRepository.findByEntityPermission(uId, methodTypeToPermissionValue(methodType), entityName);
		return !appUsers.isEmpty();
	}
	

	//TO do remove this method and join with apppermission table 
	private Long methodTypeToPermissionValue(String methodType) {
		
		Long permissionValue = 0L;
		
		 switch (methodType) {
         case "DELETE":  permissionValue = 8L;
                  break;
         case "POST":  permissionValue = 4L;
                  break;
         case "PUT":  permissionValue = 4L;
         		  break;
         case "GET":  permissionValue = 2L;
                  break;
         default: permissionValue = 0L;
                  break;
		 }
		return permissionValue;
	}
	
	private int getUniqueId(List<String> uniqueValue){
		
		int uniqueId = 0;
		if(!uniqueValue.isEmpty()){
			uniqueId = Integer.parseInt( uniqueValue.get(0));
		}
		
		return uniqueId;
	}
}


