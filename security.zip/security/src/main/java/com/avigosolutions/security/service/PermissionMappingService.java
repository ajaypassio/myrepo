package com.avigosolutions.security.service;

import java.util.List;
import java.util.Optional;

import com.avigosolutions.security.dto.UserPermissionDto;

public interface PermissionMappingService {
	
	public Optional<List<UserPermissionDto>> getUserPermissionById(String uId);

}
