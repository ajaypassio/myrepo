package com.avigosolutions.security.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.security.dto.UserPermissionDto;
import com.avigosolutions.security.model.PermissionMapping;
import com.avigosolutions.security.model.AppPermission;
import com.avigosolutions.security.model.AppRole;
import com.avigosolutions.security.repository.AppPermissionRepository;
import com.avigosolutions.security.repository.AppRoleRepository;
import com.avigosolutions.security.repository.PermissionMappingRepository;

@Service
@Transactional(propagation=Propagation.SUPPORTS, readOnly = true)
public class PermissionMappingServiceImpl implements PermissionMappingService {

	
	@Autowired
	private PermissionMappingRepository permissionMappingRepository;
	
	@Autowired
	private AppPermissionRepository appPermissionRepository;
	
	@Autowired
	private AppRoleRepository appRoleRepository;
	
	@Override
	public Optional<List<UserPermissionDto>> getUserPermissionById(String uId) {
		 
		List<PermissionMapping> permissionMappings = permissionMappingRepository.findByUserName(uId);
		List<UserPermissionDto> permissionDtos = new ArrayList<>();
		if(null != permissionMappings && ! permissionMappings.isEmpty()){
			AppRole appRole = appRoleRepository.findRoleByUserName(uId);
			permissionDtos= buildPermissionDto(permissionMappings, appRole);
		}
		
		return Optional.ofNullable( permissionDtos);
	}

	private List<UserPermissionDto> buildPermissionDto(List<PermissionMapping> permissionMappings, AppRole appRole) {
		
		List<UserPermissionDto> userPermDtos =  new ArrayList<>();
		List<AppPermission> appPermissions =	appPermissionRepository.findAll();
			for (PermissionMapping permMapping : permissionMappings) {
				
				 List<AppPermission> matchingAppPermission = appPermissions.stream()
					 											.filter(ap -> permMapping.getAppPermission()
					 													.equals( ap.getPermissionValue()))
					 											.collect(Collectors.toList());
				 UserPermissionDto userPermDto = new UserPermissionDto()
												.withAppPermission(matchingAppPermission.get(0).getPermissionName())
												.withEntityName(permMapping.getEntityName())
												.withAppRole(appRole.getRoleName());
				 userPermDtos.add(userPermDto);
			}
			
		return userPermDtos;
	}

}
