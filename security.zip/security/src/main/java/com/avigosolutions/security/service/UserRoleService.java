package com.avigosolutions.security.service;

import java.util.Optional;

import com.avigosolutions.security.model.AppRole;

public interface UserRoleService {
	Optional<AppRole> getRole(String userName);
}
