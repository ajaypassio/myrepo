UPDATE `permissionmapping` SET `AppPermission`='8' WHERE `Id`='1';
INSERT INTO `permissionmapping` (`Id`, `EntityName`, `RoleId`, `AppPermission`) VALUES ('3', 'TRIAL', '1', '8');