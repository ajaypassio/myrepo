INSERT INTO `approle` (`Id`, `RoleName`, `Description`) VALUES ('4', 'ROLE_SITE_COORDINATOR', 'Site Coordinator Role');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) VALUES ('4', '44', 'Suriya', 'Bagavat', 'bagavats', 'bsuriyakani@avigosolutions.com', 'app100', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('4', '4', '4');
INSERT INTO `permissionmapping` (`Id`, `EntityName`, `RoleId`, `AppPermission`) VALUES ('13', 'TRIAL', '4', '2');
INSERT INTO `permissionmapping` (`Id`, `EntityName`, `RoleId`, `AppPermission`) VALUES ('14', 'QUESTIONNAIRE', '4', '8');
