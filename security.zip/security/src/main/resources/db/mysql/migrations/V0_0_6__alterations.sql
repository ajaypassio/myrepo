UPDATE `permissionmapping` SET `AppPermission`='4' WHERE `Id`='1';
UPDATE `permissionmapping` SET `AppPermission`='4' WHERE `Id`='10';
UPDATE `permissionmapping` SET `AppPermission`='4' WHERE `Id`='11';
UPDATE `permissionmapping` SET `AppPermission`='4' WHERE `Id`='12';

