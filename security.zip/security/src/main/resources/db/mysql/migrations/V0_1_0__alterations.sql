INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) VALUES ('7', '77', 'Bernadette', 'Tosti', 'bernadette.g.tosti', 'Bernadette.G.Tosti@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('7', '3', '7');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) VALUES ('8', '88', 'Therese', 'Mccurren', 'therese.j.mccurren', 'therese.j.mccurren@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('8', '3', '8');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) VALUES ('9', '99', 'Stacy', 'Whaley', 'stacy.d.whaley', 'stacy.d.whaley@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('9', '4', '9');