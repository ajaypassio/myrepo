INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('10', '77', 'Shipra', 'Kataria', 'shipra.x.kataria', 'Shipra.X.Kataria@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('7', '3', '7');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('11', '88', 'Shipra', 'Kataria', 'shipra.x.kataria2', 'Shipra.X.Kataria@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('8', '3', '8');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('12', '99', 'Therese', 'McCurren', 'therese.j.mccurren', 'Therese.J.McCurren@QuestDiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('9', '3', '9');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('13', '101', 'Therese', 'McCurren', 'therese.j.mccurren2', 'Therese.J.McCurren@QuestDiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('10', '3', '10');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('14', '121', 'bernadette', 'tosti', 'bernadette.g.tosti', 'Bernadette.G.Tosti@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('11', '3', '11');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('15', '132', 'stacy', 'whaley', 'stacy.d.whaley', 'stacy.d.whaley@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('12', '3', '12');
INSERT INTO `appuser` (`Id`, `UniqueId`, `FirstName`, `LastName`, `UserName`, `Email`, `Password`, `Enabled`) 
	VALUES ('16', '143', 'Steven', 'Schlachter', 'demosteve23', 'Steven.C.Schlachter@questdiagnostics.com', '', 1);
INSERT INTO `userrole` (`Id`, `RoleId`, `UserId`) VALUES ('13', '3', '13');