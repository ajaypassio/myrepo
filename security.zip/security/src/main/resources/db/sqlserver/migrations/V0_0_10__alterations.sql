SET IDENTITY_INSERT [dbo].[permissionmapping] ON;
insert into permissionmapping(id,entityname,roleid,apppermission) values(15,'QUESTIONNAIRE',4,2);
SET IDENTITY_INSERT [dbo].[permissionmapping] OFF;