UPDATE appuser SET UserName='sprintt01' WHERE Id=1;
UPDATE appuser SET UserName='mohanp' WHERE Id=2;