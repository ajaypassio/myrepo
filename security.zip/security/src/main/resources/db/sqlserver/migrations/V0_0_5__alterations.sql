INSERT INTO approle (RoleName, Description) VALUES (  'ROLE_SITE_COORDINATOR', 'Site Coordinator Role');
INSERT INTO appuser (UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) VALUES (  '44', 'Suriya', 'Bagavat', 'bagavats', 'bsuriyakani@avigosolutions.com', 'app100', 1);
INSERT INTO userrole (RoleId, UserId) VALUES ( '4', '4');
INSERT INTO permissionmapping ( EntityName, RoleId, AppPermission) VALUES ('TRIAL', '4', '2');
INSERT INTO permissionmapping ( EntityName, RoleId, AppPermission) VALUES ('QUESTIONNAIRE', '4', '8');
