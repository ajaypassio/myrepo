INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) VALUES (  '77', 'Bernadette', 'Tosti', 'bernadette.g.tosti', 'Bernadette.G.Tosti@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '7');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) VALUES (  '88', 'Therese', 'Mccurren', 'therese.j.mccurren', 'therese.j.mccurren@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '8');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) VALUES (  '99', 'Stacy', 'Whaley', 'stacy.d.whaley', 'stacy.d.whaley@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '4', '9');