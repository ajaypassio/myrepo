INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '101', 'Shipra', 'Kataria', 'shipra.x.kataria', 'Shipra.X.Kataria@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '10');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '102', 'Shipra', 'Kataria', 'shipra.x.kataria2', 'Shipra.X.Kataria@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '4', '11');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '103', 'Therese', 'McCurren', 'therese.j.mccurren', 'Therese.J.McCurren@QuestDiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '12');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '104', 'Therese', 'McCurren', 'therese.j.mccurren2', 'Therese.J.McCurren@QuestDiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '4', '13');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '105', 'bernadette', 'tosti', 'bernadette.g.tosti', 'Bernadette.G.Tosti@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '14');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '107', 'Steven', 'Schlachter', 'demosteve23', 'Steven.C.Schlachter@questdiagnostics.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '15');