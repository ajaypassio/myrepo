INSERT INTO approle (  Description, RoleName) VALUES (  'Patient user Role', 'ROLE_PATIENT_USER');
INSERT INTO permissionmapping (EntityName, RoleId, AppPermission) VALUES ('QUESTION', '5', '4');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '108', 'Patient', 'User', 'patient01', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '5', '16');
