INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '145', 'Test', 'Admin2', 'testtrialadmin2', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '17');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '146', 'Test', 'Coord1', 'testcoord1', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '4', '18');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '147', 'Test', 'Coord2', 'testcoord2', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '4', '19');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '148', 'Pentest', 'User1', 'pentest1', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '2', '20');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '149', 'Pentest', 'User2', 'pentest2', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '2', '21');
INSERT INTO appuser ( UniqueId, FirstName, LastName, UserName, Email, Password, Enabled) 
	VALUES (  '150', 'Test', 'Admin1', 'testtrialadmin1', 'mkuppan@avigosolutions.com', '', 1);
INSERT INTO userrole ( RoleId, UserId) VALUES ( '3', '22');