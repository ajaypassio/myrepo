package com.avigosolutions.security.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.security.model.AppUser;

//TODO Fix tests

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
public class AppUserServiceTest {
	//@Autowired
	private AppUserService appUserService;
	
	private static final Long DEFAULT_ID=1L;
	private static final String DEFAULT_ENTITY="TRIAL";
	private static final String ADMIN_USER_UID="sivaj";
	private static final String SERVICE_USER_UID="sprintt01";
	private static final String DEFAULT_METHODTYPE="POST";
	@Before
	public void setup() {
		
	}
	
	@After
	public void tearDown() {
		
	}
	
	// @Test
	// public void testFindAllUsers() {
	// 	Optional<List<AppUser>> findAllUsers = appUserService.findAll();
	// 	assertTrue(findAllUsers.isPresent());
	// }
	
	// @Test
	// public void testFindOneUser() {
	// 	Optional<AppUser> findOneUser = appUserService.findOne(DEFAULT_ID);
	// 	assertTrue(findOneUser.isPresent());
	// }
	
	// @Test
	// public void testHasPermissionAdmin() {
	// 	boolean hasPermission = appUserService.hasPermission(ADMIN_USER_UID, DEFAULT_ENTITY, DEFAULT_METHODTYPE);
	// 	assertTrue(hasPermission);
	// }
	
	// @Test
	// public void testHasPermissionService() {
	// 	boolean hasPermission = appUserService.hasPermission(SERVICE_USER_UID, DEFAULT_ENTITY, DEFAULT_METHODTYPE);
	// 	assertFalse(hasPermission);
	// }
	
	// @Test
	// public void testFindCoordinators() {
	// 	Optional<List<AppUser>> coordinatorUsers = appUserService.findCoordinators();
	// 	assertTrue(coordinatorUsers.isPresent());
	// }
	
}
