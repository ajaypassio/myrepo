package com.avigosolutions.security.service;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.avigosolutions.security.dto.UserPermissionDto;

//TODO fix tests

// @RunWith(SpringRunner.class)
// @SpringBootTest
// @ActiveProfiles("test")
// @Transactional
public class PermissionMappingServiceTest {
	//@Autowired
	private PermissionMappingService permissionMappingService;
	
	private static final String SERVICE_USER_UID="sprintt01";
	@Before
	public void setup() {
		
	}
	
	@After
	public void tearDown() {
		
	}
	
	
	// @Test
	// public void testUserPermissionById() {
	// 	Optional<List<UserPermissionDto>> userPermissions = permissionMappingService.getUserPermissionById(SERVICE_USER_UID);
	// 	assertTrue(userPermissions.isPresent());
	// }

}
