# Content Management Service 
The Content Management sub-domain federates all GLP capabilities around content, such as the definition of learning models, the provisioning of content, and product building. Consumers are abstracted from the underlying implementation complexity, ignoring which microservice handles each request.
In GLP, the Product Materials are provisioned as Learning Content of different Asset Type. This sub-domain provides an API designed to enable consumer applications to interact with concrete interfaces made for each of those types, such as Aggregates, Instructions, Assessment, Content Resources, amongst others. The scope of such API is bounded to Content Management. It is not made for Content Delivery, and therefore has no dependency on the Engagement domain. The Master Record for those Learning Content remains in the Publishing domain.


### Documentation
   Technical documentation for this microservice can be found at (https://one-confluence.pearson.com/display/GLPOCCC/Content+Management)

### Prerequisites
  * Software: glp-content-management
  * JDK 1.8
  * Spring Boot
  * Spring Reactive
  * Netty as Embedded Server
  * slf4j is used for logging
  * Gradle 4.10 is used to build project
  * For Static Code Analysis, we  use  Sonar for generating reports
  * For Code Coverage Analysis, we use Jacoco.

### Installation and Build

  * Move to the base of microservice folder i.e. ${PROJECT_CHECKOUT_FOLDER}\glp-content-management.
  * Add proot id,password in gradle.properties.  
  * Run "gradle clean spotlessApply build" to build the project with unit test cases. It applies spotless formatting as well.
  * Run "gradle clean spotlessApply build -x test" to build all the project without unit test cases.
  * Import  the project to the IDE.  
  

##### Database 
  
  Add/edit database related information like bucketName,cluster username,cluster password
  at ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\src\main\resources\application.properties .To enable auto indexing, couchbase auto-index is
  set to true.
   

##### Configs

  ###### Application configuration
  Add/edit application level properties at ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\src\main\resource\application.properties.Edit config.home path in application.properties to the one mentioned in dockerfile.
   
  ###### Database configuration
  Add/edit database related properties at ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\source\ [main / test]\application.properties
  
  ###### Sonar configuration
  Add/edit sonar properties at ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\config\sonar.properties  
  
  ###### Dockerfile
  Location of executable jar,config path of the service are specified at ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\Dockerfile  
  
  
### Running the MicroService
   * Move to the ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\build\libs
   * Execute command: java -jar cms-0.0.1-SNAPSHOT-exec.jar

### Coding style tests 
   * Code is fully reactive, no blocking code has been implemented.
   * This project use Spotless Java to test coding styles.
   * Code and branch coverage of the project is maintained greater than or equal to 80 percent.

### Deployment

##### PR build Job 

   Jenkins job url for PR build is available at (https://jenkins.gl-poc.com/blue/organizations/jenkins/PR-build-revel-cms/activity/)

##### Master build job

   Jenkins job url for master build is available at (https://jenkins.gl-poc.com/view/Revel-Gradle-Build-Jobs/job/GLP-Revel-Gradle-Builder-cms/)

### Versioning
  *	Application configuration
   Add/edit application level properties at ${PROJECT_CHECKOUT_FOLDER}\glp-content-management\source\ [main / test]\application.properties

  * API versioning is followed.

### License
PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 Copyright (c) 2017 Pearson Education, Inc.
 All Rights Reserved. 

*** Disclaimer, copyright & licensing:
(c) Pearson 
NOTICE: All information contained herein is, and remains the property of Pearson Education, Inc. The intellectual and technical concepts contained 
 herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 and Foreign Patents, patent applications, and are protected by trade secret 
 or copyright law. Dissemination of this information, reproduction of this  
 material, and copying or distribution of this software is strictly forbidden   
 unless prior written permission is obtained from Pearson Education, Inc.
