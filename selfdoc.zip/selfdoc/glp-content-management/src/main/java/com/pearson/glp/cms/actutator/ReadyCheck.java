/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.actutator;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.core.actutaor.AbstractReadyCheck;

/**
 * The Class ReadyCheck.
 * 
 * @author anuj.verma
 */
@Component
public class ReadyCheck extends AbstractReadyCheck {

  /** The lpb base url. */
  @Value("${base.url.lpb}")
  protected String lpbBaseUrl;

  /** The lap base url. */
  @Value("${base.url.lap}")
  protected String lapBaseUrl;

  /** The lad base url. */
  @Value("${base.url.lad}")
  protected String ladBaseUrl;

  /** The lae base url. */
  @Value("${base.url.lae}")
  private String laeBaseUrl;

  /** The lee base url. */
  @Value("${base.url.lee}")
  private String leeBaseUrl;

  /**
   * Instantiates a new ready check.
   */
  public ReadyCheck() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.pearson.glp.core.actutaor.AbstractReadyCheck#dependentComponents()
   */
  public Map<String, String> dependentComponents() {
    Map<String, String> dependentComponents = new HashMap<>();
    dependentComponents.put("LAD", ladBaseUrl + UriEnum.URI_HEALTH);
    dependentComponents.put("LPB", lpbBaseUrl + UriEnum.URI_HEALTH);
    dependentComponents.put("LAP", lapBaseUrl + UriEnum.URI_HEALTH);
    dependentComponents.put("LAE", laeBaseUrl + UriEnum.URI_HEALTH);
    dependentComponents.put("LEE", leeBaseUrl + UriEnum.URI_HEALTH);
    return dependentComponents;
  }
}
