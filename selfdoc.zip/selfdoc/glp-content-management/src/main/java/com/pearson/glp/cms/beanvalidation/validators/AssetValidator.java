/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.pearson.glp.cms.beanvalidation.annotations.AssetConstraint;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.dto.common.AssetGraph;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.learningasset.request.AssetPayload;
import com.pearson.glp.cms.utils.ValidationUtils;

/**
 * The Class AssetValidator.
 *
 * @author bharat.aggarwal
 */
public class AssetValidator implements ConstraintValidator<AssetConstraint, AssetPayload> {

  /**
   * Instantiates a new asset validator.
   */
  public AssetValidator() {
    super();
  }

  @Override
  public boolean isValid(AssetPayload assetPayload, ConstraintValidatorContext context) {
    Set<String> resourceNodes = assetPayload.getResources().keySet();
    List<AssetGraph> assetGraphNodes = assetPayload.getAssetGraph();
    boolean isAssetGraphValid = true;
    if (!assetGraphNodes.isEmpty()) {
      isAssetGraphValid = validateAssetGraph(resourceNodes, assetGraphNodes, context);
    }
    List<ResourcePlan> resourcePlan = assetPayload.getResourcePlan();
    boolean isResourcePlanValid = true;
    if (!resourcePlan.isEmpty()) {
      isResourcePlanValid = validateResourcePlan(resourceNodes, resourcePlan, context);
    }
    return isAssetGraphValid && isResourcePlanValid;

  }

  /**
   * Validate resource plan.
   *
   * @param resourceNodes
   *          the resource nodes with self
   * @param resourcePlan
   *          the resource plan
   * @param context
   *          the context
   * @return true, if successful
   */
  private boolean validateResourcePlan(Set<String> resourceNodes, List<ResourcePlan> resourcePlan,
      ConstraintValidatorContext context) {
    boolean invalidNodePresent = resourcePlan.stream()
        .anyMatch(node -> !resourceNodes.contains(node.getResourceRef()));
    if (invalidNodePresent) {
      ValidationUtils.buildConstraintViolation(context, ValidationMessages.INVALID_NODES,
          Optional.of(CmsConstants.RESOURCE_PLAN));
    }
    return !invalidNodePresent;
  }

  /**
   * Validate asset graph.
   *
   * @param resourceNodes
   *          the resource nodes with self
   * @param assetGraphNodes
   *          the asset graph nodes
   * @param context
   *          the context
   * @return true, if successful
   */
  private boolean validateAssetGraph(Set<String> resourceNodes, List<AssetGraph> assetGraphNodes,
      ConstraintValidatorContext context) {
    boolean isValid = false;
    Set<String> resourceNodesWithSelf = new HashSet<>(resourceNodes);
    resourceNodesWithSelf.add(CmsConstants.SELF_NODE);
    if (assetGraphNodes.size() <= resourceNodesWithSelf.size()) {
      for (AssetGraph assetGraphNode : assetGraphNodes) {
        Optional<String> startNode = Optional.ofNullable(assetGraphNode.getStartNode());
        Optional<String> endNode = Optional.ofNullable(assetGraphNode.getEndNode());
        isValid = startNode.isPresent() && endNode.isPresent() && !startNode.equals(endNode)
            && resourceNodesWithSelf.containsAll(Arrays.asList(startNode.get(), endNode.get()));
        if (!isValid) {
          ValidationUtils.buildConstraintViolation(context, ValidationMessages.INVALID_NODES,
              Optional.of(CmsConstants.ASSET_GRAPH));
          break;
        }
      }
    } else {
      ValidationUtils.buildConstraintViolation(context, ValidationMessages.IS_INVALID,
          Optional.of(CmsConstants.ASSET_GRAPH));
    }
    return isValid;
  }

}
