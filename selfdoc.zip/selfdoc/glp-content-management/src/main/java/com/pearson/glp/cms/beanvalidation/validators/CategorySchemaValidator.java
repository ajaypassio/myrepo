/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.pearson.glp.cms.beanvalidation.annotations.CategorySchemaConstraint;
import com.pearson.glp.cms.dto.learningmodel.CategorySchema;
import com.pearson.glp.cms.utils.ValidationUtils;

/**
 * The Class CategorySchemaValidator.
 */
public class CategorySchemaValidator
    implements ConstraintValidator<CategorySchemaConstraint, CategorySchema> {

  /**
   * Instantiates a new category schema validator.
   */
  public CategorySchemaValidator() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.validation.ConstraintValidator#isValid(java.lang.Object,
   * javax.validation.ConstraintValidatorContext)
   */
  @Override
  public boolean isValid(CategorySchema categorySchema, ConstraintValidatorContext context) {
    int maxProp = 0;
    int minProp = 0;
    try {
      maxProp = (categorySchema.getMaxProperties() != null)
          ? Integer.parseInt(categorySchema.getMaxProperties())
          : Integer.MAX_VALUE;
      minProp = (categorySchema.getMinProperties() != null)
          ? Integer.parseInt(categorySchema.getMinProperties())
          : minProp;
    } catch (NumberFormatException ex) {
      ValidationUtils.buildConstraintViolation(context, "invalid datatype of min/max properties",
          Optional.empty());
      return false;
    }
    if (maxProp < minProp || minProp < 0) {
      ValidationUtils.buildConstraintViolation(context, "invalid min/max Properties",
          Optional.empty());
      return false;
    }
    return true;
  }
}
