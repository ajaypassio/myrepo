/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.groups.Default;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetPayload;
import com.pearson.glp.cms.dto.learningasset.request.AssetsRequest;
import com.pearson.glp.cms.dto.learningasset.request.ProductPayload;
import com.pearson.glp.cms.dto.learningmodel.request.AssetModelPayload;
import com.pearson.glp.cms.dto.resource.ValidationResult;
import com.pearson.glp.cms.dto.resource.request.ResourcePayload;
import com.pearson.glp.cms.dto.resource.request.ResourcesRequest;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.cms.utils.ErrorUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;

import reactor.core.publisher.Mono;

/**
 * The Class CmsRequestValidator.
 */
@Component
public class CmsRequestValidator {

  /** The validator. */
  @Autowired
  private Validator validator;

  /**
   * Instantiates a new cms request validator.
   */
  public CmsRequestValidator() {
    super();
  }

  /**
   * Validate bulk post request body.
   *
   * @param <T>
   *          the generic type
   * @param <Y>
   *          the generic type
   * @param func
   *          the func
   * @param request
   *          the request
   * @param bodyClass
   *          the body class
   * @param optionalGroup
   *          the optional group
   * @return the mono
   */
  public <T> Mono<ServerResponse> validatePostRequest(Function<Mono<T>, Mono<ServerResponse>> func,
      ServerRequest request, Class<T> bodyClass, Optional<Class<?>> optionalGroup) {
    return request.bodyToMono(bodyClass).flatMap(reqBody -> {
      if (!validator.validate(reqBody).isEmpty()) {
        return Mono.error(new CmsException(HttpStatus.BAD_REQUEST.value(),
            createValidationResult(validator.validate(reqBody)).getReason().toString()));
      }
      if (reqBody instanceof ResourcesRequest) {
        Stream<ResourcePayload> resourceStream = ((ResourcesRequest) reqBody).getResources()
            .stream();
        ((ResourcesRequest) reqBody)
            .setResources(this.getValidatedResources(resourceStream, optionalGroup));
      } else if (reqBody instanceof AssetsRequest) {
        Stream<AssetPayload> assetStream = ((AssetsRequest) reqBody).getAssets().stream();
        ((AssetsRequest) reqBody).setAssets(this.getValidatedResources(assetStream, optionalGroup));
      }
      return func.apply(Mono.just(reqBody));
    }).switchIfEmpty(Mono.error(
        new CmsException(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_REQUEST_PAYLOAD)))
        .onErrorResume(ErrorUtils::handleServerResponseError);
  }

  /**
   * Validate post version request body.
   *
   * @param <T>
   *          the generic type
   * @param <Y>
   *          the generic type
   * @param func
   *          the func
   * @param request
   *          the request
   * @param bodyClass
   *          the body class
   * @param assetType
   *          the asset type
   * @param optionalGroup
   *          the optional group
   * @return the mono
   */

  public <T> Mono<ServiceHandlerResponse> validateRequest(

      Function<Mono<T>, Mono<ServiceHandlerResponse>> func, ServiceHandlerContext request,
      Class<T> bodyClass, Optional<String> assetType, Optional<Class<?>> optionalGroup) {
    return request.getPayload(bodyClass).flatMap(reqBody -> {
      Set<ConstraintViolation<T>> allViolations = (optionalGroup.isPresent())
          ? validator.validate(reqBody, optionalGroup.get(), Default.class)
          : validator.validate(reqBody);
      if (allViolations.isEmpty()) {
        if (assetType.isPresent()) {
          ((AssetModelPayload) reqBody).setAssetType(assetType.get());
        }
        if (reqBody instanceof ProductPayload) {
          ProductPayload productPayload = (ProductPayload) reqBody;
          productPayload.updateProduct();
        }
        return func.apply(Mono.just(reqBody));
      } else {
        String failureReason = this.createValidationResult(allViolations).getReason().toString();
        return Mono.error(new CmsException(HttpStatus.BAD_REQUEST.value(), failureReason));
      }
    }).switchIfEmpty(Mono.error(
        new CmsException(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_REQUEST_PAYLOAD)))
        .onErrorResume(ErrorUtils::handleCmsError);
  }

  /**
   * Gets the validated resources.
   *
   * @param <T>
   *          the generic type
   * @param <R>
   *          the generic type
   * @param resourceStream
   *          the resource stream
   * @param optionalGroup
   *          the optional group
   * @return the validated resources
   */
  private <R> List<R> getValidatedResources(Stream<R> resourceStream,
      Optional<Class<?>> optionalGroup) {
    return resourceStream.map(resource -> {
      Set<ConstraintViolation<R>> allViolations = (optionalGroup.isPresent())
          ? validator.validate(resource, optionalGroup.get(), Default.class)
          : validator.validate(resource);
      if (resource instanceof ResourcePayload) {
        ((ResourcePayload) resource).setValidationResult(createValidationResult(allViolations));
      } else if (resource instanceof AssetPayload) {
        AssetPayload assetPayload = (AssetPayload) resource;
        assetPayload.setValidationResult(createValidationResult(allViolations));
        assetPayload.copyLabelIfAssetClassEmpty();
      }
      return resource;
    }).collect(Collectors.toList());
  }

  /**
   * Creates the validation result.
   *
   * @param <T>
   *          the generic type
   * @param allViolations
   *          the all violations
   * @return the validation result
   */
  private <T> ValidationResult createValidationResult(Set<ConstraintViolation<T>> allViolations) {
    HashMap<String, String> violationsMap = new HashMap<>();
    for (ConstraintViolation<T> violation : allViolations) {
      String failedProperty = CommonUtils
          .getJsonPropertyPath(violation.getPropertyPath().toString(), violation.getLeafBean());
      String failureReason = violation.getMessage();
      violationsMap.put(failedProperty, failureReason);
    }
    if (!allViolations.isEmpty()) {
      ValidationResult result = new ValidationResult();
      result.setFailureFlag(Boolean.TRUE);
      result.setReason(violationsMap);
      return result;
    }
    return new ValidationResult();
  }
}
