/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.pearson.glp.cms.beanvalidation.annotations.ConfigurationConstraint;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.utils.ValidationUtils;

/**
 * The Class ConfigurationValidator.
 */
public class ConfigurationValidator
    implements ConstraintValidator<ConfigurationConstraint, Configuration> {

  /**
   * Instantiates a new configuration validator.
   */
  public ConfigurationValidator() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.validation.ConstraintValidator#isValid(java.lang.Object,
   * javax.validation.ConstraintValidatorContext)
   */
  @SuppressWarnings("unchecked")
  @Override
  public boolean isValid(Configuration configuration, ConstraintValidatorContext context) {
    boolean isValid = validateRequired(configuration, context);
    if (isValid) {
      Object policyGroups = configuration.get(CmsConstants.POLICY_GROUPS);
      if (policyGroups != null
          && !((policyGroups instanceof List) && isListOfString((List<Object>) policyGroups))) {
        ValidationUtils.buildConstraintViolation(context, ValidationMessages.INVALID_TYPE,
            Optional.of(CmsConstants.POLICY_GROUPS));
        isValid = false;
      }
    }
    return isValid;
  }

  /**
   * Checks if is an array of string.
   *
   * @param list
   *          the list
   * @return true, if is an array of string
   */
  private boolean isListOfString(List<Object> list) {
    boolean isValid = true;
    for (Object obj : list) {
      if (!(obj instanceof String)) {
        isValid = false;
        break;
      }
    }
    return isValid;
  }

  /**
   * Validate required.
   *
   * @param configuration
   *          the configuration
   * @param context
   *          the context
   * @return true, if successful
   */
  private boolean validateRequired(Configuration configuration,
      ConstraintValidatorContext context) {
    if (configuration == null) {
      ValidationUtils.buildConstraintViolation(context, ValidationMessages.IS_REQUIRED,
          Optional.of(CmsConstants.CONFIGURATION));
      return false;
    }
    return true;
  }

}
