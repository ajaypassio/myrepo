/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.pearson.glp.cms.beanvalidation.annotations.CategoryConstraint;
import com.pearson.glp.cms.enums.CategoryEnum;

/**
 * The Class ContentCategoryValidator.
 *
 * @author bharat.aggarwal
 */
public class ContentCategoryValidator implements ConstraintValidator<CategoryConstraint, String> {

  /**
   * Instantiates a new content category validator.
   */
  public ContentCategoryValidator() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.validation.ConstraintValidator#isValid(java.lang.Object,
   * javax.validation.ConstraintValidatorContext)
   */
  @Override
  public boolean isValid(String category, ConstraintValidatorContext arg1) {
    return CategoryEnum.getNarrativeResourceEnumValues().stream()
        .anyMatch(cat -> cat.equals(category));
  }
}
