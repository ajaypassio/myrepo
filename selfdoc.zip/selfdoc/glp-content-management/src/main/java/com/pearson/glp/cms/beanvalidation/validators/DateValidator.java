/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.joda.time.Instant;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pearson.glp.cms.beanvalidation.annotations.DateConstraint;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.utils.ValidationUtils;

/**
 * The Class DateValidator.
 *
 * @author bharat.aggarwal
 */
public class DateValidator implements ConstraintValidator<DateConstraint, String> {

  /**
   * Instantiates a new date validator.
   */
  public DateValidator() {
    super();
  }

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(DateValidator.class);

  /** The primary format. */
  private static final String PRIMARY_FORMAT = "yyyy-MM-dd'T'HH:mm:ss+HH:mm";
  /** The secondary format. */
  private static final String SECONDARY_FORMAT = "yyyy-MM-dd'T'HH:mm:ss-HH:mm";

  /*
   * (non-Javadoc)
   * 
   * @see javax.validation.ConstraintValidator#isValid(java.lang.Object,
   * javax.validation.ConstraintValidatorContext)
   */
  @Override
  public boolean isValid(String expiresOn, ConstraintValidatorContext context) {
    boolean isValidFlag = true;
    if (expiresOn != null) {
      try {
        validateSupportedFormat(expiresOn);
        isValidFlag = validateFutureDate(expiresOn, context);
      } catch (IllegalArgumentException ex) {
        isValidFlag = false;
      }
    }
    return isValidFlag;
  }

  /**
   * Validate supported format.
   *
   * @param expiresOn
   *          the expires on
   * @param context
   *          the context
   * @return true, if successful
   */
  private void validateSupportedFormat(String expiresOn) {
    DateTimeFormatter formatter1 = DateTimeFormat.forPattern(PRIMARY_FORMAT);
    DateTimeFormatter formatter2 = DateTimeFormat.forPattern(SECONDARY_FORMAT);
    Instant myInstant;
    try {
      myInstant = Instant.parse(expiresOn, formatter1);
    } catch (IllegalArgumentException ex) {
      myInstant = Instant.parse(expiresOn, formatter2);
    }
    LOGGER.debug(LoggingConstants.FORMATTED_DATE_AND_TIME, myInstant);
  }

  /**
   * @param expiresOn
   * @param context
   * @return
   */
  private boolean validateFutureDate(String expiresOn, ConstraintValidatorContext context) {
    boolean isValidFlag = true;
    if (Instant.parse(expiresOn).compareTo(Instant.now()) <= 0) {
      ValidationUtils.buildConstraintViolation(context,
          ValidationMessages.EXPIRES_ON_SHOULD_BE_FUTURE_DATE, Optional.empty());
      isValidFlag = false;
    }
    return isValidFlag;
  }
}
