/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.beanvalidation.validators;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.pearson.glp.cms.beanvalidation.annotations.ExtensionsConstraint;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.dto.common.Extensions;
import com.pearson.glp.cms.utils.ValidationUtils;

/**
 * The Class ExtensionsValidator.
 *
 * @author bharat.aggarwal
 */
public class ExtensionsValidator implements ConstraintValidator<ExtensionsConstraint, Extensions> {

  /**
   * Instantiates a new extensions validator.
   */
  public ExtensionsValidator() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see javax.validation.ConstraintValidator#isValid(java.lang.Object,
   * javax.validation.ConstraintValidatorContext)
   */
  @Override
  public boolean isValid(Extensions extensions, ConstraintValidatorContext context) {
    boolean isValid = false;
    if (extensions != null) {
      Object name = extensions.get(CmsConstants.NAME);
      if (name instanceof Map) {
        isValid = true;
        Object taxType = extensions.get(CmsConstants.TAXONOMIC_TYPE);
        if (taxType != null) {
          isValid = (taxType instanceof List);
        }
      } else {
        ValidationUtils.buildConstraintViolation(context, ValidationMessages.IS_REQUIRED,
            Optional.of(CmsConstants.NAME));
      }
    }
    return isValid;
  }

}
