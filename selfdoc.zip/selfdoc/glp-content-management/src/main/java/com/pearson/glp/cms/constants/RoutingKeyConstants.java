/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.constants;

/**
 * The Class RoutingKeyConstants.
 */
public final class RoutingKeyConstants {

  // Resource Handler Routing Keys
  /** The Constant HANDLER_CREATE_RESOURCE_KEY. */
  public static final String HANDLER_CREATE_RESOURCE_KEY = "createResources";
  /** The Constant HANDLER_GET_RESOURCE_KEY. */
  public static final String HANDLER_GET_RESOURCE_KEY = "getResources";
  /** The Constant HANDLER_ADD_RESOURCES_VERSIONS_KEY. */
  public static final String HANDLER_ADD_RESOURCES_VERSIONS_KEY = "addResourcesVersions";
  /** The Constant HANDLER_GET_RESOURCES_BY_ID_AND_VERSION_KEY. */
  public static final String HANDLER_GET_RESOURCES_BY_ID_AND_VERSION_KEY = "getResourcesByIdAndVersion";
  /** The Constant HANDLER_GET_ALL_RESOURCE_VERSIONS_KEY. */
  public static final String HANDLER_GET_ALL_RESOURCE_VERSIONS_KEY = "getAllResourceVersions";
  /** The Constant HANDLER_GET_RESOURCE_BY_ID_KEY. */
  public static final String HANDLER_GET_RESOURCE_BY_ID_KEY = "getResourceById";
  /** The Constant ADD_ASSESS_RESOURCES_KEY. */
  public static final String POST_ASSESS_RESOURCES_KEY = "addAssessResources";
  /** The Constant GET_ASSESS_RESOURCE_BY_ID_KEY. */
  public static final String GET_ASSESS_RESOURCE_BY_ID_KEY = "getAssessResourcesById";
  /** The Constant GET_SPECIFIC_VERSION_ASSESS_RESOURCE_KEY. */
  public static final String GET_SPECIFIC_VERSION_ASSESS_RESOURCE_KEY = "getAssessResourcesByIdAndVersion";
  /** The Constant GET_SPECIFIC_VERSION_LEARNINGAPP_RESOURCE_KEY. */
  public static final String GET_SPECIFIC_VERSION_LEARNINGAPP_RESOURCE_KEY = "getLearningAppResourcesByIdAndVersion";
  /** The Constant GET_LEARNINGAPP_RESOURCE_BY_ID. */
  public static final String GET_LEARNINGAPP_RESOURCE_BY_ID = "getLearningAppResourcesById";

  // Primitive Asset Handler Routing Keys
  /** The Constant HANDLER_GET_ALL_NARRATIVES_VERSIONS_KEY. */
  public static final String HANDLER_GET_ALL_NARRATIVES_VERSIONS_KEY = "getAllNarrativesVersions";
  /** The Constant HANDLER_ADD_NARRATIVES_VERSIONS_KEY. */
  public static final String HANDLER_ADD_NARRATIVES_VERSIONS_KEY = "addNarrativesVersions";
  /** The Constant HANDLER_GET_NARRATIVE_BY_ID_KEY. */
  public static final String HANDLER_GET_NARRATIVE_BY_ID_KEY = "getNarrativeById";
  /** The Constant HANDLER_GET_SPECIFIC_NARRATIVE_BY_ID_AND_VERSION_KEY. */
  public static final String HANDLER_GET_SPECIFIC_NARRATIVE_BY_ID_AND_VERSION_KEY = "getSpecificNarrativeByIdAndVersion";
  /** The Constant HANDLER_GET_BULK_NARRATIVES_KEY. */
  public static final String HANDLER_GET_BULK_NARRATIVES_KEY = "getNarratives";
  /** The Constant HANDLER_ADD_BULK_NARRATIVES_KEY. */
  public static final String HANDLER_ADD_BULK_NARRATIVES_KEY = "addNarratives";
  /** The Constant GET_PRODUCT_LEARNING_AIDS. */
  public static final String GET_PRODUCT_LEARNING_AIDS = "getProductLearningAids";
  /** The Constant GET_PRODUCT_MODEL_LEARNING_AIDS. */
  public static final String GET_PRODUCT_MODEL_LEARNING_AIDS = "getProductModelLearningAids";
  /**
   * The Constant HANDLER_GET_SPECIFIC_ASSESSMENT_ITEM_BY_ID_AND_VERSION_KEY.
   */
  public static final String HANDLER_GET_ASSESSMENT_ITEM_BY_ID_AND_VERSION_KEY = "getAssessmentItemByIdAndVersion";
  /** The Constant HANDLER_GET_ASSESSMENT_ITEM_BY_ID_KEY. */
  public static final String HANDLER_GET_ASSESSMENT_ITEM_BY_ID_KEY = "getAssessmentItemById";
  /** The Constant HANDLER_GET_ASSESSMENT_ITEMS. */
  public static final String HANDLER_GET_ASSESSMENT_ITEMS = "getAssessmentItems";
  /** The Constant HANDLER_GET_LEARNING_APP_ITEM_BY_ID_KEY. */
  public static final String HANDLER_GET_LEARNING_APP_ITEM_BY_ID_KEY = "getLearningApItemsById";
  /** The Constant HANDLER_GET_LEARNING_APP_ITEM_BY_ID_AND_VERSION_KEY. */
  public static final String HANDLER_GET_LEARNING_APP_ITEM_BY_ID_AND_VERSION_KEY = "getLearningApItemsByIdAndVersion";
  // NonPrimitive Asset Handler Routing Keys
  /** The Constant HANDLER_GET_INSTRUCTIONS_KEY. */
  public static final String HANDLER_GET_INSTRUCTIONS_KEY = "getInstructionNonPrimitiveAssets";
  /** The Constant HANDLER_GET_AGGREGATES_KEY. */
  public static final String HANDLER_GET_AGGREGATES_KEY = "getAggregateNonPrimitiveAssets";
  /** The Constant HANDLER_GET_INSTRUCTIONS_BY_ID_KEY. */
  public static final String HANDLER_GET_INSTRUCTIONS_BY_ID_KEY = "getInstructionById";
  /** The Constant HANDLER_GET_ASSESSMENTS_BY_ID_KEY. */
  public static final String HANDLER_GET_ASSESSMENTS_BY_ID_KEY = "getAssessmentsById";
  /** The Constant HANDLER_GET_AGGREGATES_BY_ID_KEY. */
  public static final String HANDLER_GET_AGGREGATES_BY_ID_KEY = "getAggregateById";
  /** The Constant HANDLER_GET_ALL_INSTRUCTIONS_VERSIONS_KEY. */
  public static final String HANDLER_GET_ALL_INSTRUCTIONS_VERSIONS_KEY = "getAllInstructionsVersions";
  /** The Constant HANDLER_GET_ALL_AGGREGATES_VERSIONS_KEY. */
  public static final String HANDLER_GET_ALL_AGGREGATES_VERSIONS_KEY = "getAllAggregatesVersions";
  /** The Constant HANDLER_GET_SPECIFIC_VERSION_OF_INSTRUCTION_KEY. */
  public static final String HANDLER_GET_SPECIFIC_VERSION_OF_INSTRUCTION_KEY = "getSpecificVersionOfInstruction";
  /** The Constant HANDLER_GET_SPECIFIC_VERSION_OF_AGGREGATE_KEY. */
  public static final String HANDLER_GET_SPECIFIC_VERSION_OF_AGGREGATE_KEY = "getSpecificVersionOfAggregate";
  /** The Constant HANDLER_GET_ASSESSMENT_BY_ID_AND_VERSION_KEY. */
  public static final String HANDLER_GET_ASSESSMENT_BY_ID_AND_VERSION_KEY = "getAssessmentByIdAndVersion";
  /** The Constant HANDLER_POST_NEW_VERSION_OF_INSTRUCTION_KEY. */
  public static final String HANDLER_POST_NEW_VERSION_OF_INSTRUCTION_KEY = "createInstructionVersion";
  /** The Constant HANDLER_POST_NEW_VERSION_OF_AGGREGATE_KEY. */
  public static final String HANDLER_POST_NEW_VERSION_OF_AGGREGATE_KEY = "createAggregateVersion";

  // Product Handler Routing Keys
  /** The Constant GET_PRODUCT. */
  public static final String GET_PRODUCT = "getProducts";
  /** The Constant PRODUCT_BY_VER. */
  public static final String PRODUCT_BY_VER = "getProductsByVer";
  /** The Constant HANDLER_PRODUCT_ROUT. */
  public static final String HANDLER_PRODUCT_ROUT = "getProduct";
  /** The Constant PRODUCTS_BY_ID. */
  public static final String PRODUCTS_BY_ID = "getProductById";
  /** The Constant PRODUCTS_ASSET_TYPES. */
  public static final String PRODUCTS_ASSET_TYPES = "getProductAssetTypes";

  /** The Constant GET_PRODUCTS_VERSIONS_HANDLER_KEY. */
  public static final String GET_PRODUCTS_VERSIONS_HANDLER_KEY = "getProductsVersions";
  /** The Constant GET_PRODUCT_STATE_TRANSITION_HANDLER_KEY. */
  public static final String GET_PRODUCT_STATE_TRANSITION_HANDLER_KEY = "getProductStateTransition";
  /** The Constant GET_PRODUCT_ASSESSMENT_TYPES_KEY. */
  public static final String GET_PRODUCT_ASSESSMENT_TYPES_KEY = "getProductAssessmentTypes";
  /** The Constant GET_PRODUCT_STATUS_KEY. */
  public static final String GET_PRODUCT_STATUS_KEY = "getProductStatusbyIdandVersion";
  /** The Constant POST_PRODUCT_ROUTE_KEY. */
  public static final String POST_PRODUCT_ROUTE_KEY = "postProduct";
  /** The Constant PRODUCT_NEW_VERSION_HANDLER_KEY. */
  public static final String POST_PRODUCT_VERSION_ROUTE_KEY = "postProductVersions";
  /** The Constant POST_PRODUCT_STATE_TRANSITION_KEY. */
  public static final String POST_PRODUCT_STATE_TRANSITION_KEY = "postProductStateTransition";
  /** The Constant POST_PRODUCT_MAP_ASSESSMENT_TYPE_KEY. */
  public static final String POST_PRODUCT_MAP_ASSESSMENT_TYPE_KEY = "postProductMapAssessmentType";
  /** The Constant PUT_PRODUCT_STATUS_KEY. */
  public static final String PUT_PRODUCT_STATUS_KEY = "putProductStatusKey";
  /** The Constant POST_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_KEY. */
  public static final String POST_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_KEY = "postProductAssessmentRuntimeSettingsKey";
  /** The Constant GET_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_KEY. */
  public static final String GET_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_KEY = "getProductAssessmentRuntimeSettingsKey";
  /** The Constant POST_PRODUCT_CATEGORY_WEIGHTS_KEY. */
  public static final String POST_PRODUCT_CATEGORY_WEIGHTS_KEY = "postProductCategoryWeightsKey";

  // AssetModel and ProductModel Handler Routing Keys
  /** The Constant HANDLER_GET_ASSET_MODELS_KEY. */
  public static final String HANDLER_GET_ASSET_MODELS_KEY = "getAllAssetModels";
  /** The Constant HANDLER_GET_ASSET_MODELS_BY_ID_KEY. */
  public static final String HANDLER_GET_ASSET_MODELS_BY_ID_KEY = "getAssetModelById";
  /** The Constant HANDLER_GET_ASSET_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_GET_ASSET_MODELS_VERSIONS_KEY = "getAllAssetModelVersions";
  /** The Constant HANDLER_GET_ASSET_MODELS_BY_VERISON_ID_KEY. */
  public static final String HANDLER_GET_ASSET_MODELS_BY_VERISON_ID_KEY = "getAssetModelsByVersionId";
  /** The Constant HANDLER_GET_INSTRUCTION_MODELS_KEY. */
  public static final String HANDLER_GET_INSTRUCTION_MODELS_KEY = "getAllInstructionModels";
  /** The Constant HANDLER_GET_ASSESSMENT_MODELS_KEY. */
  public static final String HANDLER_GET_ASSESSMENT_MODELS_KEY = "getAllAssessmentModels";
  /** The Constant HANDLER_GET_AGGREGATE_MODELS_KEY. */
  public static final String HANDLER_GET_AGGREGATE_MODELS_KEY = "getAllAggregateModels";
  /** The Constant HANDLER_CREATE_ASSESSMENT_MODELS_KEY. */
  public static final String HANDLER_CREATE_ASSESSMENT_MODELS_KEY = "createAssessmentModels";
  /** The Constant HANDLER_CREATE_INSTRUCTION_MODELS_KEY. */
  public static final String HANDLER_CREATE_INSTRUCTION_MODELS_KEY = "createInstructionModels";
  /** The Constant HANDLER_CREATE_NARRATIVE_MODELS_KEY. */
  public static final String HANDLER_CREATE_NARRATIVE_MODELS_KEY = "createNarrativeModels";
  /** The Constant HANDLER_CREATE_AGGREGATE_MODELS_KEY. */
  public static final String HANDLER_CREATE_AGGREGATE_MODELS_KEY = "createAggregateModels";
  /** The Constant HANDLER_GET_INSTRUCTION_MODELS_BY_ID_KEY. */
  public static final String HANDLER_GET_INSTRUCTION_MODELS_BY_ID_KEY = "getInstructionModelById";
  /** The Constant HANDLER_GET_ASSESSMENT_MODELS_BY_ID_KEY. */
  public static final String HANDLER_GET_ASSESSMENT_MODELS_BY_ID_KEY = "getAssessmentModelById";
  /** The Constant HANDLER_GET_AGGREGATE_MODELS_BY_ID_KEY. */
  public static final String HANDLER_GET_AGGREGATE_MODELS_BY_ID_KEY = "getAggregateModelById";
  /** The Constant HANDLER_GET_INSTRUCTION_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_GET_INSTRUCTION_MODELS_VERSIONS_KEY = "getAllInstructionModelsVersions";
  /** The Constant HANDLER_GET_ASSESSMENT_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_GET_ASSESSMENT_MODELS_VERSIONS_KEY = "getAllAssessmentModelsVersions";
  /** The Constant HANDLER_GET_AGGREGATE_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_GET_AGGREGATE_MODELS_VERSIONS_KEY = "getAllAggregateModelsVersions";
  /** The Constant HANDLER_CREATE_INSTRUCTION_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_CREATE_INSTRUCTION_MODELS_VERSIONS_KEY = "createInstructionModelsVersions";
  /** The Constant HANDLER_CREATE_NARRATIVE_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_CREATE_NARRATIVE_MODELS_VERSIONS_KEY = "createNarrativeModelsVersions";
  /** The Constant HANDLER_CREATE_ASSESSMENT_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_CREATE_ASSESSMENT_MODELS_VERSIONS_KEY = "createAssessmentModelsVersions";
  /** The Constant HANDLER_CREATE_AGGREGATE_MODELS_VERSIONS_KEY. */
  public static final String HANDLER_CREATE_AGGREGATE_MODELS_VERSIONS_KEY = "createAggregateModelsVersions";
  /** The Constant HANDLER_GET_INSTRUCTION_MODELS_BY_VERISON_ID_KEY. */
  public static final String HANDLER_GET_INSTRUCTION_MODELS_BY_VERISON_ID_KEY = "getInstructionModelsByVersionId";
  /** The Constant HANDLER_GET_ASSESSMENT_MODELS_BY_VERISON_ID_KEY. */
  public static final String HANDLER_GET_ASSESSMENT_MODELS_BY_VERISON_ID_KEY = "getAssessmentModelByVersionId";
  /** The Constant HANDLER_GET_AGGREGATE_MODELS_BY_VERISON_ID_KEY. */
  public static final String HANDLER_GET_AGGREGATE_MODELS_BY_VERISON_ID_KEY = "getAggregateModelByVersionId";
  /** The Constant PRODUCT_MODEL_GET. */
  public static final String PRODUCT_MODEL_GET = "getProductModel";
  /** The Constant PRODUCT_MODEL_POST. */
  public static final String PRODUCT_MODEL_POST = "postProductModel";
  /** The Constant PRODUCT_MODEL_VERSIONS_GET. */
  public static final String PRODUCT_MODEL_VERSIONS_GET = "getProductModelsVersions";
  /** The Constant PRODUCT_MODEL_VERSIONS_POST. */
  public static final String PRODUCT_MODEL_VERSIONS_POST = "postProductModelsVersions";
  /** The Constant PRODUCT_MODEL_ID_GET. */
  public static final String PRODUCT_MODEL_ID_GET = "getProductModelById";
  /** The Constant PRODUCT_MODEL_BY_VERSION_ID. */
  public static final String GET_PRODUCT_MODEL_BY_VERSION_ID = "getProductModelByVersionId";
  /** The Constant POST_PRODUCT_HANDLER_KEY. */
  public static final String POST_PRODUCT_HANDLER_KEY = "postProduct";
  /** The Constant HANDLER_CREATE_ASSESSMENT_ITEM_MODELS_KEY. */
  public static final String HANDLER_CREATE_ASSESSMENT_ITEM_MODELS_KEY = "createAssessmentItemModels";
  /** The Constant GET_SPECIFIC_VERSION_OF_LEARNING_APP_KEY. */
  public static final String GET_SPECIFIC_VERSION_OF_LEARNING_APP_KEY = "getSpecificVersionOfLearningApp";
  /** The Constant POST_LEARNINGAPP_MODEL_KEY. */
  public static final String POST_LEARNINGAPP_MODELS_KEY = "postLearningAppModels";
  /** The Constant POST_LEARNINGAPPITEM_MODELS_KEY. */
  public static final String POST_LEARNINGAPPITEM_MODELS_KEY = "postLearningAppItemModels";
  /** The Constant HANDLER_LEARNING_APP_BY_ID_KEY. */
  public static final String HANDLER_LEARNING_APP_BY_ID_KEY = "getLearningAppById";
  /** The Constant POST_LEARNINGAIDS_KEY. */
  public static final String POST_LEARNING_AIDS = "renameLearningAids";
  /** The Constant HANDLER_GET_SPECIFIC_VERSION_OF_LEARNINGAPPS. */
  public static final String HANDLER_GET_SPECIFIC_VERSION_OF_LEARNINGAPPS = "getSpecificVersionOfLearningApp";
  /** The Constant HANDLER_GET_PRODUCT_ASSESSMENT_TYPES_BY_ID_AND_VERSION. */
  public static final String HANDLER_GET_PRODUCT_ASSESSMENT_TYPES_BY_ID_AND_VERSION = "getProductAssessmentTypeByIdAndVersion";
  /** The Constant GET_ASSESSMENT. */
  public static final String GET_ASSESSMENT = "getAllAssessment";
  /** The Constant PRODUCT_MODEL_BY_VERSION_ID. */
  public static final String POST_PRODUCT_MODEL_BY_VERSION_ID_LEARNINGAIDS = "postProdductModelLearningAids";
  /** The Constant POST_PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_KEY. */
  public static final String POST_PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_KEY = "postProductModelAssessmentRuntimeSettingsKey";
  /** The Constant POST_PRODUCT_MODEL_CATEGORY_WEIGHTS. */
  public static final String POST_PRODUCT_MODEL_CATEGORY_WEIGHTS = "postProdductModelCategoryWeights";
  /** The Constant GET_PRODUCT_MODEL_CATEGORY_WEIGHTS. */
  public static final String GET_PRODUCT_MODEL_CATEGORY_WEIGHTS = "getProdductModelCategoryWeights";
  /** The Constant POST_PRODUCT_SCORING_POLICY. */
  public static final String POST_PRODUCT_SCORING_POLICY = "postProductScoringPolicy";
  /** The Constant POST_PRODUCT_MODEL_SCORING_POLICY. */
  public static final String POST_PRODUCT_MODEL_SCORING_POLICY = "postProductModelScoringPolicy";
  /** The Constant POST_PRODUCT_MODEL_CATEGORY_WEIGHT. */
  public static final String POST_PRODUCT_MODEL_CATEGORY_WEIGHT = "postProductModelCategoryWeight";
  /** The Constant GET_CATEGORY_WEIGHT. */
  public static final String GET_PRODUCT_CATEGORY_WEIGHT = "getProductCategoryWeight";
  /** The Constant GET_PRODUCT_SCORING_POLICY_KEY. */
  public static final String GET_PRODUCT_SCORING_POLICY = "getProductScoringPolicy";
  /** The Constant POST_CONFIG_STATUS. */
  public static final String POST_CONFIG_STATUS = "postConfigStatus";
  /** The Constant GET_PRODUCT_MODEL_SCORING_POLICY. */
  public static final String GET_PRODUCT_MODEL_SCORING_POLICY = "getProductModelScoringPolicy";
  /** The Constant GET_PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_KEY. */
  public static final String GET_PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_KEY = "getProductModelAssessmentRuntimeSettingsKey";
  /** The Constant POST_NARRATIVES_KEY. */
  public static final String POST_NARRATIVES_KEY = "postBulkNarratives";
  /** The Constant POST_ASSESSMENT_ITEMS_KEY. */
  public static final String POST_ASSESSMENT_ITEMS_KEY = "postAssessmentItems";
  /** The Constant POST_LEARNING_APP_ITEMS_KEY. */
  public static final String POST_LEARNING_APP_ITEMS_KEY = "postLearningAppItems";

  /**
   * Instantiates a new routing key constants.
   */
  private RoutingKeyConstants() {
    super();
  }
}
