/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.deserializer;

import java.io.IOException;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.google.gson.Gson;
import com.pearson.glp.crosscutting.isc.client.async.model.EventMessage;

/**
 * The Class EventMessageDeserializer is a custom deserializer for EventMessage
 * that is received as payload for Kafka Events. The fields in EventMessage have
 * String as data type, which should not be deserialized by XSSProtection Class,
 * therefore the deserialization here used gson instead of jackson.
 *
 * @author srishti.singh
 */
@JsonComponent
public class EventMessageDeserializer extends JsonDeserializer<EventMessage> {

  /**
   * Instantiates a new event message deserializer.
   */
  public EventMessageDeserializer() {
    super();
  }

  /*
   * @see
   * com.fasterxml.jackson.databind.JsonDeserializer#deserialize(com.fasterxml.
   * jackson.core.JsonParser,
   * com.fasterxml.jackson.databind.DeserializationContext)
   */
  @Override
  public EventMessage deserialize(JsonParser jsonParser,
      DeserializationContext deserializationContext) throws IOException {
    String value = jsonParser.readValueAsTree().toString();
    Gson gson = new Gson();
    return gson.fromJson(value, EventMessage.class);
  }
}
