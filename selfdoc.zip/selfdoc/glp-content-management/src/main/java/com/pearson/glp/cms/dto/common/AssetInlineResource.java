/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.common;

import java.io.Serializable;
import java.util.Map;

import com.couchbase.client.deps.com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// TODO: Auto-generated Javadoc
/**
 * The Class AssetInlineResource.
 * 
 * @author anuj.verma
 */

/**
 * Gets the data.
 *
 * @return the data
 */
@Getter

/**
 * Sets the data.
 *
 * @param data
 *          the data
 */
@Setter

/**
 * Instantiates a new asset inline resource.
 */
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetInlineResource implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -1196617142365647118L;

  /** The _resourceType. */
  @SerializedName("_resourceType")
  @JsonProperty("_resourceType")
  private String resourceType;

  /** The category. */
  private String category;

  /** The model. */
  private String model;

  /** The data. */
  private Map<String, Object> data;

  /**
   * Instantiates a new asset inline resource.
   *
   * @param resource
   *          the resource
   */
  public AssetInlineResource(AssetInlineResource resource) {
    this.data = resource.getData();
  }
}