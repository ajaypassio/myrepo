/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.common;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.beanvalidation.annotations.AssetTypeConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.DocTypeConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.ResourceTypeConstraint;
import com.pearson.glp.cms.beanvalidation.groups.GroupAssessments;
import com.pearson.glp.cms.beanvalidation.groups.GroupNonPrimitiveLA;
import com.pearson.glp.cms.constants.ValidationMessages;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Resources.
 * 
 * @author pankaj.mishra2
 */
@Getter
@Setter
@NoArgsConstructor
public class AssetResources implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -1196617142365647118L;

  /** The id. */
  @SerializedName("_id")
  @JsonProperty("_id")
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  private String id;

  /** The bss ver. */
  @SerializedName("_bssVer")
  @JsonProperty("_bssVer")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Integer bssVer;

  /** The ver. */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  private String ver;

  /** The _resourceType. */
  @SerializedName("_resourceType")
  @JsonProperty("_resourceType")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  @ResourceTypeConstraint
  private String resourceType;

  /** The _docType. */
  @SerializedName("_docType")
  @JsonProperty("_docType")
  @NotBlank(groups = { GroupNonPrimitiveLA.class,
      GroupAssessments.class }, message = ValidationMessages.IS_REQUIRED)
  @DocTypeConstraint(groups = { GroupNonPrimitiveLA.class, GroupAssessments.class })
  private String docType;

  /** The _assetType. */
  @SerializedName("_assetType")
  @JsonProperty("_assetType")
  @AssetTypeConstraint(groups = { GroupNonPrimitiveLA.class, GroupAssessments.class })
  @NotBlank(groups = { GroupNonPrimitiveLA.class,
      GroupAssessments.class }, message = ValidationMessages.IS_REQUIRED)
  private String assetType;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  private Links links;

  /** The label. */
  private String label;

  /** The extensions. */
  private Extensions extensions;

  /** The asset class. */
  private String assetClass;
}