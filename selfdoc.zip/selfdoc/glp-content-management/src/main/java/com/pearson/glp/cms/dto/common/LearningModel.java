/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.common;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.beanvalidation.annotations.AssetTypeConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.ResourceTypeConstraint;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class LearningModel.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "_id", "_bssVer", "_ver", "_resourceType", "_docType", "_assetType",
    "_links" })
public class LearningModel implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -1196617142365647118L;

  /** (Required). */
  @JsonProperty("_resourceType")
  @SerializedName("_resourceType")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  @ResourceTypeConstraint
  private String resourceType;

  /** (Required). */
  @JsonProperty("_docType")
  @SerializedName("_docType")
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  @Pattern(regexp = CmsConstants.LEARNINGMODEL, message = ValidationMessages.LEARNINGMODEL_IS_ALLOWED)
  private String docType;

  /** (Required). */
  @JsonProperty("_assetType")
  @SerializedName("_assetType")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  @AssetTypeConstraint
  private String assetType;

  /** (Required). */
  @JsonProperty("_id")
  @SerializedName("_id")
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  private String id;

  /** (Required). */
  @JsonProperty("_bssVer")
  @SerializedName("_bssVer")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Integer bssVer;

  /** (Required). */
  @JsonProperty("_ver")
  @SerializedName("_ver")
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  private String ver;

  /** (Required). */
  @JsonProperty("_links")
  @SerializedName("_links")
  private Links links;

}
