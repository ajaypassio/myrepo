/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningasset.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.validation.GroupSequence;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.beanvalidation.annotations.AssessmentExtensionsConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.AssetConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.DateConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.ExtensionsConstraint;
import com.pearson.glp.cms.beanvalidation.groups.ClassLevelCheck;
import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.beanvalidation.groups.GroupAssessments;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.dto.common.AssetGraph;
import com.pearson.glp.cms.dto.common.AssetResources;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.dto.common.Extends;
import com.pearson.glp.cms.dto.common.Extensions;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.common.LearningModel;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.common.Scope;
import com.pearson.glp.cms.dto.resource.ContentMetadata;
import com.pearson.glp.cms.dto.resource.ValidationResult;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class AssetPostModel.
 */
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@AssetConstraint(groups = ClassLevelCheck.class)
@GroupSequence({ AssetPayload.class, ClassLevelCheck.class })
public class AssetPayload implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 5248990584909425556L;

  /** The validation result. */
  @JsonProperty("_validationResult")
  @SerializedName("_validationResult")
  private ValidationResult validationResult;

  /** The content meta data. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ContentMetadata contentMetadata;

  /** The created. */
  @SerializedName("_created")
  @JsonProperty("_created")
  private String created;

  /** The created by. */
  @SerializedName("_createdBy")
  @JsonProperty("_createdBy")
  private String createdBy = CmsConstants.CMS;

  /** The expires on. */
  @DateConstraint
  private String expiresOn;

  /** The label. */
  private String label;

  /** The tags. */
  private String tags;

  /** The language. */
  @Pattern(regexp = "^[a-z]{2}-[A-Z]{2}$", message = ValidationMessages.INCORRECT_LANG)
  private String language = CmsConstants.DEFAULT_LANG;

  /** The asset class. */
  private String assetClass;

  /** The objectives. */
  private String objectives;

  /** The groups. */
  private Groups groups;

  /** The learning model. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private LearningModel learningModel;

  /** The resources. */
  @Valid
  @NotEmpty(message = ValidationMessages.IS_REQUIRED)
  private LinkedHashMap<String, AssetResources> resources;

  /** The asset graph. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ArrayList<AssetGraph> assetGraph;

  /** The resource plan. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ArrayList<ResourcePlan> resourcePlan;

  /** The configuration. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Configuration configuration;

  /** The constraints. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ArrayList<String> constraints;

  /** The extends. */
  @SerializedName("extends")
  @JsonProperty("extends")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Extends extend;

  /** The extensions. */
  @AssessmentExtensionsConstraint(groups = GroupAssessments.class)
  @ExtensionsConstraint(groups = GroupAssessmentItemResource.class)
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Extensions extensions;

  /** The scope. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Scope scope;

  /**
   * Sets the created by.
   *
   * @param createdBy
   *          the new created by
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = CmsConstants.CMS;
  }

  /**
   * Copy label if asset class empty.
   */
  public void copyLabelIfAssetClassEmpty() {
    if (!StringUtils.isEmpty(getLabel()) && StringUtils.isEmpty(getAssetClass())) {
      this.assetClass = getLabel();
    } else if (StringUtils.isEmpty(getAssetClass())) {
      this.assetClass = CmsConstants.EMPTY;
    }
  }
}
