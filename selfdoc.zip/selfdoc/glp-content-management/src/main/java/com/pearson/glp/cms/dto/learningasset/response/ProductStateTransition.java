/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningasset.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.dto.common.Links;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The class ProductStateTransition.
 * 
 * @author devanshi.agarwal
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductStateTransition implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 851299958581019303L;

  /** The productId. */
  @SerializedName("_id")
  @JsonProperty("_id")
  private String productId;

  /** The status. */
  @SerializedName("_status")
  @JsonProperty("_status")
  private String status;

  /** The version. */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  private String ver;

  /** The created. */
  @SerializedName("_created")
  @JsonProperty("_created")
  private String created;

  /** The last modified. */
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  private String lastModified;

  /** The previous state. */
  private String previousState;

  /** The transition state. */
  private String transitionState;

  /** The reason. */
  private String reason;

  /** The reason code. */
  private String reasonCode;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  private Links links;

}
