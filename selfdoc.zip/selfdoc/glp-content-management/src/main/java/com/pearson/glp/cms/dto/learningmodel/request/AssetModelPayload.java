/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningmodel.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.beanvalidation.annotations.ConfigurationConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.DateConstraint;
import com.pearson.glp.cms.beanvalidation.groups.GroupProductModel;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.dto.common.AssetGraph;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.dto.common.Extends;
import com.pearson.glp.cms.dto.common.Extensions;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.common.Scope;
import com.pearson.glp.cms.dto.learningmodel.ResourceObject;
import com.pearson.glp.cms.dto.resource.ValidationResult;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class AssetModelPayload.
 * 
 * @author srishti.singh
 */
@Setter
@Getter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssetModelPayload implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -4960342928059095715L;

  /** The validation result. */
  @JsonProperty("_validationResult")
  @SerializedName("_validationResult")
  private ValidationResult validationResult;

  /** The id. */
  @JsonProperty("_id")
  @SerializedName("_id")
  private String id;

  /** The ver. */
  @JsonProperty("_ver")
  @SerializedName("_ver")
  private String ver;

  /** The asset type. */
  @JsonProperty("_assetType")
  @SerializedName("_assetType")
  protected String assetType;

  /** The expires on. */
  @DateConstraint
  protected String expiresOn;

  /** The label. */
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  protected String label;

  /** The tags. */
  protected String tags;

  /** The language. */
  @Pattern(regexp = "en-US", message = "language should be en-US")
  protected String language;

  /** The created by. */
  @JsonProperty("_createdBy")
  @SerializedName("_createdBy")
  private String createdBy = CmsConstants.CMS;

  /** The asset class. */
  protected String assetClass;

  /** The objectives. */
  protected String objectives;

  /** The groups. */
  protected Groups groups;

  /** The resources. */
  @Valid
  @NotEmpty(message = ValidationMessages.IS_REQUIRED)
  protected LinkedHashMap<String, ResourceObject> resources;

  /** The asset graph. */
  @Valid
  @NotEmpty(message = ValidationMessages.IS_REQUIRED)
  protected ArrayList<AssetGraph> assetGraph;

  /** The resource plan. */
  @Valid
  @NotEmpty(message = ValidationMessages.IS_REQUIRED)
  protected ArrayList<ResourcePlan> resourcePlan;

  /** The configuration. */
  @ConfigurationConstraint(groups = GroupProductModel.class)
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  protected Configuration configuration;

  /** The constraints. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  protected ArrayList<Object> constraints;

  /** The extend. */
  @SerializedName("extends")
  @JsonProperty("extends")
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  protected Extends extend;

  /** The extensions. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  protected Extensions extensions;

  /** The scope. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  protected Scope scope;

  /**
   * Sets the created by.
   *
   * @param createdBy
   *          the new created by
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = CmsConstants.CMS;
  }
}