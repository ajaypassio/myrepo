/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningpolicy.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class AssessmentType.
 * 
 * @author shubham.bansal
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssessmentType implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 233517980186954349L;

  /** The assessment type. */
  private String assessmentType;

  /** The runtime enabled. */
  private String runtimeEnabled;

  /** The runtime settings. */
  private RuntimeSettings runtimeSettings;

  /**
   * Instantiates a new assessment type.
   *
   * @param payload
   *          the payload
   * @param continuousSettingskeys
   *          the continuous settingskeys
   * @param discreetSettingskeys
   *          the discreet settingskeys
   */
  public AssessmentType(AssessmentType payload, List<String> continuousSettingskeys,
      List<String> discreetSettingskeys) {
    this.assessmentType = payload.getAssessmentType();
    this.runtimeEnabled = payload.getRuntimeEnabled();
    this.runtimeSettings = new RuntimeSettings(payload, continuousSettingskeys,
        discreetSettingskeys);

  }
}
