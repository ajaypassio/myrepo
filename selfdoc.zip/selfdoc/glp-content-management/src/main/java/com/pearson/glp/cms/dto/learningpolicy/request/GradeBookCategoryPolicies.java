/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningpolicy.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.pearson.glp.cms.constants.ValidationMessages;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The class GradeBookCategoryPolicies.
 * 
 * @author sourabh.aggarwal
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GradeBookCategoryPolicies implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 2427507250135267614L;

  /** The assessment type. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private String assessmentType;

  /** The gradebook category. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private String gradebookCategory;

  /** The gradebook label. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private String gradebookLabel;

  /** The weight. */
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Integer weight;

}
