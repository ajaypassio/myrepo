/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningpolicy.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.common.Extends;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.common.LearningModel;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class PolicyPayload.
 * 
 * @author shubham.bansal
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyPayload extends PolicyVersionPayload {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 5248990584909425556L;

  /** The expires on. */
  private String expiresOn;

  /** The label. */
  private String label;

  /** The objectives. */
  private String objectives;

  /** The tags. */
  private String tags;

  /** The language. */
  private String language = CmsConstants.DEFAULT_LANG;

  /** The asset class. */
  private String assetClass;

  /** The extend. */
  @SerializedName("extends")
  @JsonProperty("extends")
  private Extends extend = new Extends();

  /** The groups. */
  private Groups groups;

  /** The learning model. */
  private LearningModel learningModel;

  /** The status. */
  private String status;
}
