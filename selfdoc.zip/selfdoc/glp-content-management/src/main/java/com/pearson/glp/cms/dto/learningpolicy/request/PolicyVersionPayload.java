/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningpolicy.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.pearson.glp.cms.dto.common.AssetGraph;
import com.pearson.glp.cms.dto.common.AssetInlineResource;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.dto.common.Extensions;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.common.Scope;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class PolicyPayloadVersion.
 * 
 * @author sourabh.aggarwal
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyVersionPayload implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 6091946149494048122L;

  /** The resources. */
  private LinkedHashMap<String, AssetInlineResource> resources;

  /** The resource plan. */
  private List<ResourcePlan> resourcePlan = new ArrayList<>();

  /** The asset graph. */
  private List<AssetGraph> assetGraph = new ArrayList<>();

  /** The configuration. */
  private Configuration configuration = new Configuration();

  /** The constraints. */
  private List<String> constraints = new ArrayList<>();

  /** The extensions. */
  private Extensions extensions = new Extensions();

  /** The scope. */
  private Scope scope = new Scope();

}
