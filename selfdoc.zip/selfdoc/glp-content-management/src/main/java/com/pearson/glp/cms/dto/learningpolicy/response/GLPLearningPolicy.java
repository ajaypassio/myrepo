/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningpolicy.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.dto.common.AssetGraph;
import com.pearson.glp.cms.dto.common.AssetInlineResource;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.dto.common.Extends;
import com.pearson.glp.cms.dto.common.Extensions;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.common.LearningModel;
import com.pearson.glp.cms.dto.common.Links;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.common.Scope;
import com.pearson.glp.cms.exception.CustomErrorMessage;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class GLPLearningPolicy.
 */
@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString(of = { "id", "ver", "bssVer", "docType", "assetType" })
public class GLPLearningPolicy implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 1157034154938700841L;

  /**
   * Instantiates a new GLP learning policy.
   *
   * @param errorPayload
   *          the error payload
   */
  public GLPLearningPolicy(CustomErrorMessage errorPayload) {
    this.errors = errorPayload;
  }

  /** (Required). */
  @SerializedName("_id")
  @JsonProperty("_id")
  private String id;

  /** (Required). */
  @SerializedName("_ver")
  @JsonProperty("_ver")
  private String ver;

  /** (Required). */
  @SerializedName("_bssVer")
  @JsonProperty("_bssVer")
  private Integer bssVer;

  /** (Required). */
  @SerializedName("_docType")
  @JsonProperty("_docType")
  private String docType;

  /** (Required). */
  @SerializedName("_assetType")
  @JsonProperty("_assetType")
  private String assetType;

  /** The expires on. */
  private String expiresOn;

  /** The label. */
  private String label;

  /** The tags. */
  private String tags;

  /** The language. */
  private String language;

  /** The asset class. */
  private String assetClass;

  /** The objectives. */
  private String objectives;

  /** The groups. */
  private Groups groups;

  /** The learning model. */
  private LearningModel learningModel;

  /** The resources. */
  private LinkedHashMap<String, AssetInlineResource> resources;

  /** The asset graph. */
  private ArrayList<AssetGraph> assetGraph;

  /** The resource plan. */
  private ArrayList<ResourcePlan> resourcePlan;

  /** The configuration. */
  private Configuration configuration;

  /** The constraints. */
  private ArrayList<String> constraints;

  /** The extends. */
  @SerializedName("extends")
  @JsonProperty("extends")
  private Extends extend;

  /** The extensions. */
  private Extensions extensions;

  /** The scope. */
  private Scope scope;

  /** The links. */
  @SerializedName("_links")
  @JsonProperty("_links")
  private Links links;

  /** The CustomErrorMessage. */
  private CustomErrorMessage errors;

  /** The status. */
  private String status;

}
