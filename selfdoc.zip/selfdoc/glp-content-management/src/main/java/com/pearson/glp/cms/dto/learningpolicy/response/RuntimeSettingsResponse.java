/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.learningpolicy.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class RuntimeSettingsResponse.
 * 
 * @author srishti.singh
 */
@Setter
@Getter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RuntimeSettingsResponse implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 5681336377358522577L;

  /** The created. */
  @SerializedName("_created")
  @JsonProperty("_created")
  private String created;

  /** The last modified. */
  @SerializedName("_lastModified")
  @JsonProperty("_lastModified")
  private String lastModified;

  /** The delivery policy. */
  private GLPLearningPolicy deliveryPolicy;

  /** The engagement policy. */
  private GLPLearningPolicy engagementPolicy;

  /** The evaluation policy. */
  private GLPLearningPolicy evaluationPolicy;

}
