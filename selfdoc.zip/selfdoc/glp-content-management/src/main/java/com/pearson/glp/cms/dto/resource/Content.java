/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.resource;

import static com.pearson.glp.cms.constants.CmsConstants.ASSESSMENT_ITEM_RESOURCE;
import static com.pearson.glp.cms.constants.CmsConstants.ASSESSMENT_LEARNING_APPS_RESOURCE;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.pearson.glp.cms.beanvalidation.annotations.CategoryConstraint;
import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.beanvalidation.groups.GroupLearningAppResources;
import com.pearson.glp.cms.beanvalidation.groups.GroupNarrativeResources;
import com.pearson.glp.cms.constants.ValidationMessages;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Content.
 * 
 * @author pankaj.mishra2
 */
@Getter
@Setter
@NoArgsConstructor
public class Content implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = 9134126788522884098L;

  /** The category. */
  @CategoryConstraint(groups = GroupNarrativeResources.class)
  @Pattern(regexp = ASSESSMENT_ITEM_RESOURCE, groups = GroupAssessmentItemResource.class)
  @Pattern(regexp = ASSESSMENT_LEARNING_APPS_RESOURCE, groups = GroupLearningAppResources.class)
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private String category;

  /** The model. */
  private String model;

  /** The service. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ContentLookUpMechanism service;
}
