/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.resource;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.beanvalidation.groups.GroupLearningAppResources;
import com.pearson.glp.cms.beanvalidation.groups.GroupNarrativeResources;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ContentLookUPMechanism.
 * 
 * @author pankaj.mishra2
 */
@Getter
@Setter
@NoArgsConstructor
public class ContentLookUpMechanism implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -5815418073575200040L;

  /** The style. */
  @NotBlank(message = ValidationMessages.IS_REQUIRED)
  @Pattern(regexp = CmsConstants.REST, message = ValidationMessages.REST_IS_ALLOWED, groups = {
      GroupNarrativeResources.class, GroupAssessmentItemResource.class })
  @Pattern(regexp = CmsConstants.EMBEDDED, message = ValidationMessages.EMBEDDED_IS_ALLOWED, groups = GroupLearningAppResources.class)
  private String style;

  /** The urn. */
  @NotBlank(message = ValidationMessages.IS_REQUIRED, groups = { GroupAssessmentItemResource.class,
      GroupNarrativeResources.class })
  private String urn;

  /** The url. */
  @NotEmpty(message = ValidationMessages.IS_REQUIRED, groups = { GroupAssessmentItemResource.class,
      GroupNarrativeResources.class })
  private String url;

  /** The method. */
  @NotNull(message = ValidationMessages.IS_REQUIRED, groups = { GroupAssessmentItemResource.class,
      GroupNarrativeResources.class })
  @Pattern(regexp = "GET", message = ValidationMessages.INCORRECT_METHOD)
  private String method;

  /** The validate content. */
  @NotNull(message = ValidationMessages.IS_REQUIRED, groups = GroupAssessmentItemResource.class)
  @Pattern(regexp = "^(true|false)$", message = ValidationMessages.INCORRECT_BOOLEAN)
  private String validateContent;

  /** The LearningAppTemplateInfo. */
  @NotNull(message = ValidationMessages.IS_REQUIRED, groups = GroupLearningAppResources.class)
  @Valid
  private LearningAppTemplateInfo data;
}
