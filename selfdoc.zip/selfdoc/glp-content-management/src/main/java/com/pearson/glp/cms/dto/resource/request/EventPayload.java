/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.resource.request;

import java.util.List;

import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;

import lombok.Data;

/**
 * Instantiates a new event payload.
 * 
 * @author ajay.kumar8
 */
@Data
public class EventPayload {

  /** The root node. */
  @SerializedName("rootNode")
  @JsonProperty("rootNode")
  @Field("rootNode")
  private String rootNode;

  /** The learning asset. */
  @SerializedName("learningAsset")
  @JsonProperty("learningAsset")
  @Field("learningAsset")
  private GLPLearningAsset learningAsset;

  /** The resources. */
  @SerializedName("resources")
  @JsonProperty("resources")
  @Field("resources")
  private List<ResourcePayload> resources;

}
