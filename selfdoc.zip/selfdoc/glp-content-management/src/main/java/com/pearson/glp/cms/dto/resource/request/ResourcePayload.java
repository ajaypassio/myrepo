/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.dto.resource.request;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import com.pearson.glp.cms.beanvalidation.annotations.DateConstraint;
import com.pearson.glp.cms.beanvalidation.annotations.ExtensionsConstraint;
import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ValidationMessages;
import com.pearson.glp.cms.dto.common.Extensions;
import com.pearson.glp.cms.dto.resource.Content;
import com.pearson.glp.cms.dto.resource.ContentMetadata;
import com.pearson.glp.cms.dto.resource.ContentSecurityMechanism;
import com.pearson.glp.cms.dto.resource.ResourceScope;
import com.pearson.glp.cms.dto.resource.ValidationResult;
import com.pearson.glp.cms.enums.ResourceType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ResourcePostModel.
 *
 */
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResourcePayload implements Serializable {

  /** The Constant serialVersionUID. */
  private static final long serialVersionUID = -5314217788573523127L;

  /** The validation result. */
  @JsonProperty("_validationResult")
  @SerializedName("_validationResult")
  private ValidationResult validationResult;

  /** The content meta data. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ContentMetadata contentMetadata;

  /** The created by. */
  @JsonProperty("_createdBy")
  @SerializedName("_createdBy")
  private String createdBy = CmsConstants.CMS;

  /** The resource type. */
  @JsonProperty("_resourceType")
  @SerializedName("_resourceType")
  private String resourceType = ResourceType.CONTENT.toString();

  /** The expires on. */
  @DateConstraint
  private String expiresOn;

  /** The label. */
  private String label;

  /** The tags. */
  private String tags;

  /** The language. */
  @Pattern(regexp = "^[a-z]{2}-[A-Z]{2}$", message = ValidationMessages.INCORRECT_LANG)
  private String language = CmsConstants.DEFAULT_LANG;

  /** The content. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Content content;

  /** The security. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ContentSecurityMechanism security;

  /** The scope. */
  @Valid
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private ResourceScope scope;

  /** The extensions. */
  @ExtensionsConstraint(groups = GroupAssessmentItemResource.class)
  @NotNull(message = ValidationMessages.IS_REQUIRED)
  private Extensions extensions;

  /**
   * Sets the created by.
   *
   * @param createdBy
   *          the new created by
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = CmsConstants.CMS;
  }

  /**
   * Sets the resource type.
   *
   * @param resourceType
   *          the new resource type
   */
  public void setResourceType(String resourceType) {
    this.resourceType = ResourceType.CONTENT.toString();
  }
}
