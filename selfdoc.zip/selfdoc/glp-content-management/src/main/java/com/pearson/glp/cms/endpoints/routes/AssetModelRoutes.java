/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.AssetType;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.AssetModelHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class AssetModelProvisioningRoutes.
 */
@Configuration
public class AssetModelRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(AssetModelRoutes.class);

  /** The asset model handler. */
  @Autowired
  private AssetModelHandler assetModelHandler;

  /** The handler manager. */
  @Autowired
  private ServiceHandlerManager handlerManager;

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new asset model routes.
   */
  public AssetModelRoutes() {
    super();
  }

  /**
   * Asset model routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   * @throws RuntimeException
   *           the runtime exception
   */
  @Bean
  public RouterFunction<ServerResponse> assetModelProvisioningRouter() throws ServiceException {

    try {

      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.POST(UriEnum.URI_POST_INSTRUCTION_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_INSTRUCTION_MODELS_KEY,
                          assetModelHandler::createInstructionModel))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_POST_INSTRUCTION_MODEL_VERSIONS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_INSTRUCTION_MODELS_VERSIONS_KEY,
                          assetModelHandler::createInstructionModelsVersions))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_POST_ASSESSMENT_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_ASSESSMENT_MODELS_KEY,
                          assetModelHandler::createAssessmentModel))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_POST_ASSESSMENT_ITEM_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_ASSESSMENT_ITEM_MODELS_KEY,
                          assetModelHandler::createAssessmentItemModel))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_POST_ASSESSMENT_MODEL_VERSIONS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_ASSESSMENT_MODELS_VERSIONS_KEY,
                          assetModelHandler::createAssessmentModelsVersions))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_POST_AGGREGATE_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_AGGREGATE_MODELS_KEY,
                          assetModelHandler::createAggregateModel))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_POST_AGGREGATE_MODEL_VERSIONS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_AGGREGATE_MODELS_VERSIONS_KEY,
                          assetModelHandler::createAggregateModelsVersions))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_ASSET_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ASSET_MODELS_KEY,
                          assetModelHandler::getAssetModels))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_ASSET_MODEL_BY_ID.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ASSET_MODELS_BY_ID_KEY,
                          assetModelHandler::getAssetModelById))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_ASSET_MODEL_VERSIONS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ASSET_MODELS_VERSIONS_KEY,
                          assetModelHandler::getAssetModelsVersions))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_ASSET_MODEL_SPECIFIC_VERSION.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ASSET_MODELS_BY_VERISON_ID_KEY,
                          assetModelHandler::getAssetModelByVersionId))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_POST_NARRATIVE_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_NARRATIVE_MODELS_KEY,
                          assetModelHandler::createNarrativeModel))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_POST_NARRATIVE_MODEL_VERSIONS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_CREATE_NARRATIVE_MODELS_VERSIONS_KEY,
                          assetModelHandler::createNarrativeModelsVersions))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_POST_LEARNINGAPP_MODELS.value()),
                      handlerManager.getRestHandler(RoutingKeyConstants.POST_LEARNINGAPP_MODELS_KEY,
                          context -> assetModelHandler.createAssetModel(context,
                              AssetType.LEARNINGAPP.value())))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_POST_LEARNINGAPP_ITEM_MODELS.value()),
                      handlerManager.getRestHandler(
                          RoutingKeyConstants.POST_LEARNINGAPPITEM_MODELS_KEY,
                          context -> assetModelHandler.createAssetModel(context,
                              AssetType.LEARNINGAPP_ITEM.value()))))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error("Error occurred while registering Asset Model Provisioning Routes : {} ", e);
      throw new ServiceException(
          "Error occurred while registering Asset Model Provisioning Routes : " + e.getMessage());
    }
  }

}
