/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;

/**
 * The Class ErrorRoutes.
 */
@Configuration
public class ErrorRoutes {

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new error routes.
   */
  public ErrorRoutes() {
    super();
  }

  /**
   * Error provisioning router.
   *
   * @return the router function
   */
  @Bean
  public RouterFunction<ServerResponse> errorProvisioningRouter() {
    return RouterFunctions
        .nest(RequestPredicates.path(contextPath),
            RouterFunctions
                .route(RequestPredicates.PUT(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null)
                .andRoute(RequestPredicates.HEAD(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null)
                .andRoute(RequestPredicates.DELETE(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null)
                .andRoute(RequestPredicates.OPTIONS(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null)
                .andRoute(RequestPredicates.PATCH(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null)
                .andRoute(RequestPredicates.POST(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null)
                .andRoute(RequestPredicates.GET(CmsConstants.URI_ANY_ROUTE)
                    .and(RequestPredicates.accept(MediaType.TEXT_PLAIN)), context -> null))
        .filter(new BaseHandlerFilterFunction());
  }
}
