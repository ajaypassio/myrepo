/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.NonPrimitiveAssetHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class NonPrimitiveAssetProvisioningRoutes.
 *
 * @author anuj.verma
 */
@Configuration
public class NonPrimitiveRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(NonPrimitiveRoutes.class);

  /** The nonPrimitiveAssetHandler service. */
  @Autowired
  private NonPrimitiveAssetHandler nonPrimitiveAssetHandler;

  /** The service handler manager. */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new non primitive routes.
   */
  public NonPrimitiveRoutes() {
    super();
  }

  /**
   * The instructionsProvisioningRouter.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> instructionsProvisioningRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.GET(UriEnum.URI_INSTRUCTIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_INSTRUCTIONS_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssets(context,
                              UriEnum.URI_INSTRUCTIONS)))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_INSTRUCTIONS.value()),
                      request -> nonPrimitiveAssetHandler.createNonPrimitiveAssets(request,
                          UriEnum.URI_INSTRUCTIONS))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_INSTRUCTION_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ALL_INSTRUCTIONS_VERSIONS_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetVersions(context,
                              UriEnum.URI_INSTRUCTION_VERSIONS)))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_INSTRUCTION_BY_ID.value()),
                      serviceHandlerManager
                          .getRestHandler(RoutingKeyConstants.HANDLER_GET_INSTRUCTIONS_BY_ID_KEY,
                              context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetById(context,
                                  UriEnum.URI_GET_INSTRUCTION_BY_ID)))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_INSTRUCTION_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_SPECIFIC_VERSION_OF_INSTRUCTION_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetByIdAndVersion(
                              context, UriEnum.URI_GET_INSTRUCTION_SPECIFIC_VERSION)))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_INSTRUCTION_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_POST_NEW_VERSION_OF_INSTRUCTION_KEY,
                          context -> nonPrimitiveAssetHandler.createNonPrimitiveAssetVersion(
                              context, UriEnum.URI_INSTRUCTION_VERSIONS))))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_NON_PRIMITIVE_ASSET_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_NON_PRIMITIVE_ASSET_ROUTES + e.getMessage());
    }
  }

  /**
   * The aggregatesProvisioningRouter.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> aggregatesProvisioningRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.GET(UriEnum.URI_AGGREGATES.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_AGGREGATES_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssets(context,
                              UriEnum.URI_AGGREGATES)))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_AGGREGATES.value()),
                      request -> nonPrimitiveAssetHandler.createNonPrimitiveAssets(request,
                          UriEnum.URI_AGGREGATES))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_AGGREGATE_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ALL_AGGREGATES_VERSIONS_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetVersions(context,
                              UriEnum.URI_AGGREGATE_VERSIONS)))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_AGGREGATE_BY_ID.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_AGGREGATES_BY_ID_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetById(context,
                              UriEnum.URI_GET_AGGREGATE_BY_ID)))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_AGGREGATE_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_SPECIFIC_VERSION_OF_AGGREGATE_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetByIdAndVersion(
                              context, UriEnum.URI_GET_AGGREGATE_SPECIFIC_VERSION)))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_AGGREGATE_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_POST_NEW_VERSION_OF_AGGREGATE_KEY,
                          context -> nonPrimitiveAssetHandler.createNonPrimitiveAssetVersion(
                              context, UriEnum.URI_AGGREGATE_VERSIONS))))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_NON_PRIMITIVE_ASSET_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_NON_PRIMITIVE_ASSET_ROUTES + e.getMessage());
    }
  }

  /**
   * Assessments provisioning router.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> assessmentsProvisioningRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.GET(UriEnum.URI_GET_ASSESSMENT_BY_ID.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ASSESSMENTS_BY_ID_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetById(context,
                              UriEnum.URI_GET_ASSESSMENT_BY_ID)))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_ASSESSMENT_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ASSESSMENT_BY_ID_AND_VERSION_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetByIdAndVersion(
                              context, UriEnum.URI_GET_ASSESSMENT_SPECIFIC_VERSION)))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_ASSESSMENTS.value()),
                      request -> nonPrimitiveAssetHandler.createNonPrimitiveAssets(request,
                          UriEnum.URI_ASSESSMENTS))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_ASSESSMENTS.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.GET_ASSESSMENT,
                          nonPrimitiveAssetHandler::getAllAssessment)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_NON_PRIMITIVE_ASSET_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_NON_PRIMITIVE_ASSET_ROUTES + e.getMessage());
    }
  }

  /**
   * Learning apps provisioning router.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> learningAppsProvisioningRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.POST(UriEnum.URI_LEARNING_APPS.value()),
                      request -> nonPrimitiveAssetHandler.createNonPrimitiveAssets(request,
                          UriEnum.URI_LEARNING_APPS))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_LEARNING_APP_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_SPECIFIC_VERSION_OF_LEARNING_APP_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetByIdAndVersion(
                              context, UriEnum.URI_GET_LEARNING_APP_SPECIFIC_VERSION)))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_LEARNING_APPS_BY_ID.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_LEARNING_APP_BY_ID_KEY,
                          context -> nonPrimitiveAssetHandler.getNonPrimitiveAssetById(context,
                              UriEnum.URI_GET_LEARNING_APPS_BY_ID))))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_LEARNING_APPS_ROUTES, e);
      throw new ServiceException(LoggingConstants.ERROR_LEARNING_APPS_ROUTES + e.getMessage());
    }
  }

  /**
   * Embedded assets provisioning router.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> embeddedAssetsProvisioningRouter() throws ServiceException {
    try {
      return RouterFunctions.nest(RequestPredicates.path(contextPath),
          RouterFunctions.route(RequestPredicates.POST(UriEnum.URI_EMBEDDED_ASSETS.value()),
              request -> nonPrimitiveAssetHandler.createNonPrimitiveAssets(request,
                  UriEnum.URI_EMBEDDED_ASSETS)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_LEARNING_APPS_ROUTES, e);
      throw new ServiceException(LoggingConstants.ERROR_LEARNING_APPS_ROUTES + e.getMessage());
    }
  }
}
