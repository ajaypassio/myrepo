/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.beanvalidation.groups.GroupProductModelCategoryWeight;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.PolicyHandler;
import com.pearson.glp.cms.handler.ProductHandler;
import com.pearson.glp.cms.handler.ProductModelHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class Policy Routes.
 *
 * @author ajay.kumar8
 */

@Configuration
public class PolicyRoutes {

  /**
   * The LOGGER.
   */
  private static final Logger logger = LoggerFactory.getLogger(PolicyRoutes.class);

  /**
   * The Product model Handler.
   */
  @Autowired
  private ProductModelHandler productModelHandler;

  /**
   * The Product Handler.
   */
  @Autowired
  private ProductHandler productHandler;

  /**
   * The policy handler.
   */
  @Autowired
  private PolicyHandler policyHandler;

  /**
   * The service handler manager.
   */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /**
   * The context path.
   */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new policy routes.
   */
  public PolicyRoutes() {
    super();
  }

  /**
   * Product model policy routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> productModelPolicyRoutes() throws ServiceException {

    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath), RouterFunctions
              .route(
                  RequestPredicates
                      .POST(UriEnum.URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.POST_PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_KEY,
                      policyHandler::postPolicyForProductModelAssessmentRuntimeSettings))
              .andRoute(
                  RequestPredicates.POST(UriEnum.URI_RENAME_PRODUCT_MODELS_LEARNING_AIDS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.POST_PRODUCT_MODEL_BY_VERSION_ID_LEARNINGAIDS,
                      policyHandler::createProductModelLearningAids))
              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_MODEL_LEARNING_AIDS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.GET_PRODUCT_MODEL_LEARNING_AIDS,
                      context -> policyHandler.getProductModelLearningAids(context)))
              .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS.value()),
                  serviceHandlerManager
                      .getRestHandler(RoutingKeyConstants.GET_PRODUCT_MODEL_CATEGORY_WEIGHTS,
                          context -> productModelHandler.getResolvedPolicies(context,
                              AssetClass.GRADE_BOOK_CATEGORY_POLICY.value())))
              .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.POST_PRODUCT_MODEL_CATEGORY_WEIGHT,
                      context -> productModelHandler.postProductModelCategoryWeights(context,
                          Optional.of(GroupProductModelCategoryWeight.class))))
              .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_MODEL_SCORING_POLICY.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.GET_PRODUCT_MODEL_SCORING_POLICY,
                      policyHandler::getProductModelScoringPolicy))
              .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCT_MODEL_SCORING_POLICY.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.POST_PRODUCT_MODEL_SCORING_POLICY,
                      policyHandler::postProductModelScoringPolicy))
              .andRoute(
                  RequestPredicates
                      .GET(UriEnum.URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.GET_PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_KEY,
                      policyHandler::getProductModelAssessmentRunTimeSettings)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      logger.error(LoggingConstants.ERROR_REGISTERING_POLICY_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_REGISTERING_POLICY_ROUTES + CmsConstants.COLON + e.getMessage());
    }
  }

  /**
   * Product policy routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> productPolicyRoutes() throws ServiceException {

    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(
                      RequestPredicates.POST(UriEnum.URI_PRODUCT_MAP_ASSESSMENT_TYPES.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_MAP_ASSESSMENT_TYPE_KEY,
                          productHandler::mapProductAssessmentTypes))
                  .andRoute(
                      RequestPredicates
                          .POST(UriEnum.URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_KEY,
                          policyHandler::postPolicyForProductAssessmentRuntimeSettings))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_RENAME_LEARNING_AIDS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_LEARNING_AIDS,
                          policyHandler::createProductLearningAids))
                  .andRoute(
                      RequestPredicates
                          .GET(UriEnum.URI_GET_PRODUCT_ASSESSMENT_TYPES_POLICY.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_PRODUCT_ASSESSMENT_TYPES_BY_ID_AND_VERSION,
                          productHandler::getProductAssessmentTypesPolicy))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_CATEGORY_WEIGHTS_KEY,
                          productHandler::postProductCategoryWeights))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_LEARNING_AIDS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_LEARNING_AIDS,
                          context -> policyHandler.getProductLearningAids(context)))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS.value()),
                      serviceHandlerManager
                          .getRestHandler(RoutingKeyConstants.GET_PRODUCT_CATEGORY_WEIGHT,
                              context -> policyHandler.getResolvedPolicies(context,
                                  AssetClass.GRADE_BOOK_CATEGORY_POLICY.value())))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_SCORING_POLICY.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_SCORING_POLICY,
                          policyHandler::getProductScoringPolicy))
                  .andRoute(
                      RequestPredicates.POST(UriEnum.URI_PRODUCT_SCORING_POLICY.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_SCORING_POLICY,
                          policyHandler::postProductScoringPolicy))
                  .andRoute(
                      RequestPredicates
                          .GET(UriEnum.URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_KEY,
                          policyHandler::getProductAssessmentRunTimeSettings)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      logger.error(LoggingConstants.ERROR_REGISTERING_POLICY_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_REGISTERING_POLICY_ROUTES + CmsConstants.COLON + e.getMessage());
    }
  }
}
