/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import com.pearson.glp.cms.constants.LoggingConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.PrimitiveAssetHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class NarrativesProvisioningRoutes.
 */
@Configuration
public class PrimitiveRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(PrimitiveRoutes.class);

  /** The service handler manager. */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /** The resource service. */
  @Autowired
  private PrimitiveAssetHandler primitiveAssetHandler;

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new primitive routes.
   */
  public PrimitiveRoutes() {
    super();
  }

  /**
   * Narrative routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   * @throws RuntimeException
   *           the runtime exception
   */
  @Bean
  RouterFunction<ServerResponse> narrativeProvisioningRouter() throws ServiceException {

    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.GET(UriEnum.URI_NARRATIVE_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_ALL_NARRATIVES_VERSIONS_KEY,
                          primitiveAssetHandler::getNarrativesVersions))

                  .andRoute(RequestPredicates.POST(UriEnum.URI_NARRATIVE_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_ADD_NARRATIVES_VERSIONS_KEY,
                          primitiveAssetHandler::addNarrativesVersions))

                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_NARRATIVE_BY_ID.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_NARRATIVE_BY_ID_KEY,
                          primitiveAssetHandler::getNarrativeById))

                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_NARRATIVE_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_SPECIFIC_NARRATIVE_BY_ID_AND_VERSION_KEY,
                          primitiveAssetHandler::getNarrativesByIdAndVersion))

                  .andRoute(RequestPredicates.GET(UriEnum.URI_NARRATIVES.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.HANDLER_GET_BULK_NARRATIVES_KEY,
                          primitiveAssetHandler::getNarratives))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_NARRATIVES.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.POST_NARRATIVES_KEY,
                          primitiveAssetHandler::addNarratives)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_OCCURRED_REGISTERING_CMS_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_OCCURRED_REGISTERING_NARRATIVE_ROUTER_ROUTES + e.getMessage());
    }
  }

  /**
   * Assessment item router.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> assessmentItemRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath), RouterFunctions
              .route(
                  RequestPredicates.GET(UriEnum.URI_GET_ASSESSMENT_ITEM_SPECIFIC_VERSION.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_ASSESSMENT_ITEM_BY_ID_AND_VERSION_KEY,
                      primitiveAssetHandler::getAssessmentItemByIdAndVersion))
              .andRoute(RequestPredicates.GET(UriEnum.URI_ASSESSMENT_ITEMS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_ASSESSMENT_ITEMS,
                      primitiveAssetHandler::getAssessmentItems))
              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_ASSESSMENT_ITEM_BY_ID.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_ASSESSMENT_ITEM_BY_ID_KEY,
                      primitiveAssetHandler::getAssessmentItemById))
              .andRoute(RequestPredicates.POST(UriEnum.URI_ASSESSMENT_ITEMS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.POST_ASSESSMENT_ITEMS_KEY,
                      primitiveAssetHandler::addAssessmentItems)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_OCCURRED_REGISTERING_CMS_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_OCCURRED_REGISTERING_ASSESSMENT_ITEMS_ROUTER_ROUTES
              + e.getMessage());
    }
  }

  /**
   * Learning app items router.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  RouterFunction<ServerResponse> learningAppItemsRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath), RouterFunctions
              .route(
                  RequestPredicates.GET(UriEnum.URI_GET_LEARNING_APP_ITEM_SPECIFIC_VERSION.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_LEARNING_APP_ITEM_BY_ID_AND_VERSION_KEY,
                      primitiveAssetHandler::getLearningAppItemsByIdAndVersion))
              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_LEARNING_APP_ITEM_BY_ID.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_LEARNING_APP_ITEM_BY_ID_KEY,
                      primitiveAssetHandler::getLearningAppItemsById))
              .andRoute(RequestPredicates.POST(UriEnum.URI_LEARNING_APP_ITEMS.value()),
                  serviceHandlerManager.getRestHandler(
                      RoutingKeyConstants.POST_LEARNING_APP_ITEMS_KEY,
                      primitiveAssetHandler::addLearningAppItems)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error(LoggingConstants.ERROR_OCCURRED_REGISTERING_CMS_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_OCCURRED_REGISTERING_LEARNING_APP_ITEMS_ROUTER_ROUTES
              + e.getMessage());
    }
  }
}
