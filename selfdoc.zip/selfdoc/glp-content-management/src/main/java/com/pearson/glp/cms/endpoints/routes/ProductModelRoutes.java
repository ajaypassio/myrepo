/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.ProductModelHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class ProductModelRoutes.
 */
@Configuration
public class ProductModelRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductModelRoutes.class);

  /** The Product model handler. */
  @Autowired
  private ProductModelHandler productModelHandler;

  /** The handler manager. */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new product model routes.
   */
  public ProductModelRoutes() {
    super();
  }

  /**
   * Product model routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   * @throws RuntimeException
   *           the runtime exception
   */
  @Bean
  public RouterFunction<ServerResponse> productModelProvisioningRouter() throws ServiceException {

    try {

      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.GET(UriEnum.URI_PRODUCT_MODELS.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.PRODUCT_MODEL_GET,
                          productModelHandler::getProductModels))

                  .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCT_MODELS.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.PRODUCT_MODEL_POST,
                          productModelHandler::createProductModel))

                  .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_MODEL_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.PRODUCT_MODEL_VERSIONS_GET,
                          productModelHandler::getProductModelsVersions))

                  .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCT_MODEL_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.PRODUCT_MODEL_VERSIONS_POST,
                          productModelHandler::createProductModelsVersions))

                  .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_MODEL_BY_ID.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.PRODUCT_MODEL_ID_GET,
                          productModelHandler::getProductModelById))

                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_MODEL_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_MODEL_BY_VERSION_ID,
                          productModelHandler::getProductModelByVersionId)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error("Error occurred while registering Product Model Provisioning Routes : {} ", e);
      throw new ServiceException(
          "Error occurred while registering Product Model Provisioning Routes : " + e.getMessage());
    }
  }

}
