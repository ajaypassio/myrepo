/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.ProductHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class Product Routes.
 *
 * @author kavya.jain
 */

@Configuration
public class ProductRoutes {

  /**
   * The LOGGER.
   */
  private static final Logger logger = LoggerFactory.getLogger(ProductRoutes.class);

  /**
   * The Product Handler.
   */
  @Autowired
  private ProductHandler productHandler;

  /**
   * The service handler manager.
   */
  @Autowired
  private ServiceHandlerManager serviceHandlerManager;

  /**
   * The context path.
   */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new product routes.
   */
  public ProductRoutes() {
    super();
  }

  /**
   * Product routes.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> productsRoutes() throws ServiceException {

    try {

      return RouterFunctions
          .nest(RequestPredicates.path(contextPath),
              RouterFunctions
                  .route(RequestPredicates.GET(UriEnum.URI_PRODUCTS.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.HANDLER_PRODUCT_ROUT,
                          productHandler::getProduct))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_BY_ID.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.PRODUCTS_BY_ID,
                          productHandler::getProductById))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCTS_VERSIONS_HANDLER_KEY,
                          productHandler::getProductVersions))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.PRODUCT_BY_VER,
                          productHandler::getProductByIdAndVersion))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_STATE_TRANSITION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_STATE_TRANSITION_HANDLER_KEY,
                          productHandler::getProductStateTransition))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_ASSESSMENT_TYPES.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_ASSESSMENT_TYPES_KEY,
                          productHandler::getProductAssessmentTypes))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCTS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_ROUTE_KEY, productHandler::postProduct))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCT_VERSIONS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_VERSION_ROUTE_KEY,
                          productHandler::postProductVersions))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_PRODUCT_STATE_TRANSITION.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.POST_PRODUCT_STATE_TRANSITION_KEY,
                          productHandler::postProductStateTransition))
                  .andRoute(
                      RequestPredicates.GET(UriEnum.URI_GET_PRODUCT_ASSET_TYPES.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.PRODUCTS_ASSET_TYPES,
                          productHandler::getProductAssetTypes))
                  .andRoute(RequestPredicates.GET(UriEnum.URI_PRODUCT_STATUS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.GET_PRODUCT_STATUS_KEY,
                          productHandler::getProductStatus))
                  .andRoute(RequestPredicates.PUT(UriEnum.URI_PRODUCT_STATUS.value()),
                      serviceHandlerManager.getRestHandler(
                          RoutingKeyConstants.PUT_PRODUCT_STATUS_KEY,
                          productHandler::putProductStatus))
                  .andRoute(RequestPredicates.POST(UriEnum.URI_POST_CONFIG_STATUS.value()),
                      serviceHandlerManager.getRestHandler(RoutingKeyConstants.POST_CONFIG_STATUS,
                          productHandler::postProductConfigStatus)))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      logger.error(LoggingConstants.ERROR_REGISTERING_PRODUCT_ROUTES, e);
      throw new ServiceException(
          LoggingConstants.ERROR_REGISTERING_PRODUCT_ROUTES + CmsConstants.COLON + e.getMessage());
    }
  }
}
