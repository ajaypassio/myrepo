/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.beanvalidation.groups.GroupLearningAppResources;
import com.pearson.glp.cms.beanvalidation.groups.GroupNarrativeResources;
import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.enums.CategoryEnum;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.filter.BaseHandlerFilterFunction;
import com.pearson.glp.cms.handler.ResourceHandler;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;

/**
 * The Class ResourceRoutes.
 */
@Configuration
public class ResourceRoutes {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ResourceRoutes.class);

  /** The resource handler. */
  @Autowired
  private ResourceHandler resourceHandler;

  /** The handler manager. */
  @Autowired
  private ServiceHandlerManager handlerManager;

  /** The context path. */
  @Value("${server.contextPath}")
  private String contextPath;

  /**
   * Instantiates a new resource routes.
   */
  public ResourceRoutes() {
    super();
  }

  /**
   * Resource provisioning router.
   *
   * @return the router function
   * @throws ServiceException
   *           the service exception
   */
  @Bean
  public RouterFunction<ServerResponse> resourceProvisioningRouter() throws ServiceException {
    try {
      return RouterFunctions
          .nest(RequestPredicates.path(contextPath), RouterFunctions
              .route(RequestPredicates.POST(UriEnum.URI_RESOURCES.value()),
                  context -> resourceHandler.createResources(context,
                      Optional.of(GroupNarrativeResources.class)))

              .andRoute(RequestPredicates.GET(UriEnum.URI_RESOURCES.value()),
                  handlerManager.getRestHandler(RoutingKeyConstants.HANDLER_GET_RESOURCE_KEY,
                      resourceHandler::getResources))

              .andRoute(RequestPredicates.POST(UriEnum.URI_RESOURCE_VERSIONS.value()),
                  handlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_ADD_RESOURCES_VERSIONS_KEY,
                      resourceHandler::postResourceVersion))

              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_RESOURCE_SPECIFIC_VERSION.value()),
                  handlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_RESOURCES_BY_ID_AND_VERSION_KEY,
                      context -> resourceHandler.getSpecificVersionOfResource(context,
                          CategoryEnum.NARRATIVE.getVal())))

              .andRoute(RequestPredicates.GET(UriEnum.URI_RESOURCE_VERSIONS.value()),
                  handlerManager.getRestHandler(
                      RoutingKeyConstants.HANDLER_GET_ALL_RESOURCE_VERSIONS_KEY,
                      resourceHandler::getAllVersionOfResource))

              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_RESOURCE_BY_ID.value()),
                  handlerManager.getRestHandler(RoutingKeyConstants.HANDLER_GET_RESOURCE_BY_ID_KEY,
                      context -> resourceHandler.getResourceById(context,
                          CategoryEnum.NARRATIVE.getVal())))

              .andRoute(RequestPredicates.POST(UriEnum.URI_ASSESS_RESOURCES.value()),
                  context -> resourceHandler.createResources(context,
                      Optional.of(GroupAssessmentItemResource.class)))

              .andRoute(
                  RequestPredicates.GET(UriEnum.URI_GET_ASSESS_RESOURCE_SPECIFIC_VERSION.value()),
                  handlerManager
                      .getRestHandler(RoutingKeyConstants.GET_SPECIFIC_VERSION_ASSESS_RESOURCE_KEY,
                          context -> resourceHandler.getSpecificVersionOfResource(context,
                              CategoryEnum.ASSESSMENT_ITEM.getVal())))

              .andRoute(
                  RequestPredicates
                      .GET(UriEnum.URI_GET_LEARNINGAPP_RESOURCE_SPECIFIC_VERSION.value()),
                  handlerManager.getRestHandler(
                      RoutingKeyConstants.GET_SPECIFIC_VERSION_LEARNINGAPP_RESOURCE_KEY,
                      context -> resourceHandler.getSpecificVersionOfResource(context,
                          CategoryEnum.ASSESSMENT_LEARNING_APPS.getVal())))

              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_LEARNINGAPP_RESOURCE_BY_ID.value()),
                  handlerManager.getRestHandler(RoutingKeyConstants.GET_LEARNINGAPP_RESOURCE_BY_ID,
                      context -> resourceHandler.getResourceById(context,
                          CategoryEnum.ASSESSMENT_LEARNING_APPS.getVal())))

              .andRoute(RequestPredicates.GET(UriEnum.URI_GET_ASSESS_RESOURCE_BY_ID.value()),
                  handlerManager.getRestHandler(RoutingKeyConstants.GET_ASSESS_RESOURCE_BY_ID_KEY,
                      context -> resourceHandler.getResourceById(context,
                          CategoryEnum.ASSESSMENT_ITEM.getVal())))

              .andRoute(RequestPredicates.POST(UriEnum.URI_LEARNING_APP_RESOURCES.value()),
                  context -> resourceHandler.createResources(context,
                      Optional.of(GroupLearningAppResources.class))))
          .filter(new BaseHandlerFilterFunction());
    } catch (ServiceException e) {
      LOGGER.error("Error occurred while registering Resource Provisioning Routes : {}", e);
      throw new ServiceException(
          "Error occurred while registering Resource Provisioning Routes : " + e.getMessage());
    }
  }
}
