/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * The Enum AssetClass.
 * 
 * @author shubham.bansal
 */
public enum AssetClass {

  /** The evaluation runtime settings. */
  EVALUATION_RUNTIME_SETTINGS("ASSESSMENTRUNTIMESETTINGS-POLICY-EVALUATION"),

  /** The engagement runtime settings. */
  ENGAGEMENT_RUNTIME_SETTINGS("ASSESSMENTRUNTIMESETTINGS-POLICY-ENGAGEMENT"),

  /** The delivery runtime settings. */
  DELIVERY_RUNTIME_SETTINGS("ASSESSMENTRUNTIMESETTINGS-POLICY-DELIVERY"),

  /** The delivery map assessments. */
  DELIVERY_MAP_ASSESSMENTS("ASSESSMENTTYPE-LIST-POLICY"),

  /** The learning aidlist policy. */
  LEARNING_AIDLIST_POLICY("LEARNINGAIDLIST-POLICY"),

  /** The assessment scoring policy. */
  ASSESSMENT_SCORING_POLICY("ASSESSMENTSCORINGPOLICY"),
  
  /** The grade book category policy **/
  GRADE_BOOK_CATEGORY_POLICY("GRADEBOOKCATEGORYPOLICY");

  /** The value. */
  private final String value;

  /**
   * Instantiates a new resource type.
   *
   * @param value
   *          the value
   */
  private AssetClass(String value) {
    this.value = value;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.value;
  }

  /**
   * Value.
   *
   * @return the string
   */
  @JsonValue
  public String value() {
    return this.value;
  }
}