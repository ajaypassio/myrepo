/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * The Enum AssetType.
 *
 * @author sanket.gupta
 */
public enum AssetType {

  /** The narrative. */
  NARRATIVE("NARRATIVE"),
  /** The assessment item. */
  ASSESSMENT_ITEM("ASSESSMENT-ITEM"),
  /** The instruction. */
  INSTRUCTION("INSTRUCTION"),
  /** The assessment. */
  ASSESSMENT("ASSESSMENT"),
  /** The tool. */
  TOOL("TOOL"),
  /** The aggregate. */
  AGGREGATE("AGGREGATE"),
  /** The product. */
  PRODUCT("PRODUCT"),
  /** The learningexperience. */
  LEARNINGEXPERIENCE("LEARNINGEXPERIENCE"),
  /** The engagementplan. */
  ENGAGEMENTPLAN("ENGAGEMENTPLAN"),
  /** The userengagement. */
  USERENGAGEMENT("USERENGAGEMENT"),	
  /** The learningpolicy. */
  LEARNINGPOLICY("LEARNINGPOLICY"),
  /** The deliveryplan. */
  DELIVERYPLAN("DELIVERYPLAN"),
  /** The mastergraph. */
  MASTERGRAPH("MASTERGRAPH"),
  /** The learneroutcome. */
  LEARNEROUTCOME("LEARNEROUTCOME"),
  /** The evaluationplan. */
  EVALUATIONPLAN("EVALUATIONPLAN"),
  /** The userevaluation. */
  USEREVALUATION("USEREVALUATION"),
  /** The learningapp. */
  LEARNINGAPP("LEARNINGAPP"),
  /** The learningapp item. */
  LEARNINGAPP_ITEM("LEARNINGAPP-ITEM");

  /** The value. */
  private final String value;
  
  /**
   * Instantiates a new asset type.
   *
   * @param value          the value
   * @param url the url
   */
  private AssetType(String value) {
    this.value = value;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.value;
  }

  /**
   * Value.
   *
   * @return the string
   */
  @JsonValue
  public String value() {
    return this.value;
  }

}
