/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.enums;

import static com.pearson.glp.cms.constants.CmsConstants.ASSESSMENT_ITEM_RESOURCE;
import static com.pearson.glp.cms.constants.CmsConstants.ASSESSMENT_LEARNING_APPS_RESOURCE;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The Enum CategoryEnum.
 *
 * @author bharat.aggarwal
 */
public enum CategoryEnum {
	
	/** The image. */
	IMAGE("image"),
	
	/** The narrative. */
	NARRATIVE("narrative"),
	
	/** The audio. */
	AUDIO("audio"),
	
	/** The video. */
	VIDEO("video"),
	
	/** The model. */
	MODEL("model"),
	
	/** The configuraion. */
	CONFIGURAION("configuration"),
	
	/** The abstract. */
	ABSTRACT("abstract"),
	
	/** The evidence. */
	EVIDENCE("evidence"),
	
	/** The assessment item. */
	ASSESSMENT_ITEM(ASSESSMENT_ITEM_RESOURCE),
	
	/** The assessment learning apps. */
	ASSESSMENT_LEARNING_APPS(ASSESSMENT_LEARNING_APPS_RESOURCE);
	
	/** The value. */
	private final String value;
	
	/**
	 * Instantiates a new category enum.
	 *
	 * @param value the value
	 */
	private CategoryEnum(String value) {
		this.value=value;
	}
	
	 /**
   * Gets the value.
   *
   * @return the value
   */
  public String getVal() {
    return this.value;
  }
  
	/**
	 * Gets the narrative resource enum values.
	 *
	 * @return the narrative resource enum values
	 */
	public static List<String> getNarrativeResourceEnumValues() {
		return Arrays.stream(CategoryEnum.values())
		.filter(category -> !(category==ASSESSMENT_ITEM || category==ASSESSMENT_LEARNING_APPS))
		.map(category->category.toString()).collect(Collectors.toList());
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return this.value;
	}
}
