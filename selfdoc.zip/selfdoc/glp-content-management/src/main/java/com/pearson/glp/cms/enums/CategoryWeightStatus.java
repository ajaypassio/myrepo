/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The Enum CategoryWeightStatus.
 * 
 * @author sourabh.aggarwal
 */
public enum CategoryWeightStatus {
  
  /** The active. */
  ACTIVE("ACTIVE"),
  
  /** The inactive. */
  INACTIVE("INACTIVE");
  
  /** The value. */
  private final String value;

  /**
   * Instantiates a new category weight status.
   *
   * @param value the value
   */
  private CategoryWeightStatus(String value) {
    this.value = value;
  }
  
  /**
   * Gets the val.
   *
   * @return the val
   */
  public String getVal() {
    return this.value;
  }
  
  /* (non-Javadoc)
   * @see java.lang.Enum#toString()
   */
  @Override
  public String toString() {
    return this.value;
  }

  /**
   * Gets the enum values.
   *
   * @return the enum values
   */
  public static List<String> getEnumValues() {
    return Arrays.stream(CategoryWeightStatus.values()).map(status -> status.toString()).collect(Collectors.toList());
  }
}
