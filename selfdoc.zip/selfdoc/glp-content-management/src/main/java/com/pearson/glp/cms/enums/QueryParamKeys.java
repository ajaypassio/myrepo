/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * The Enum ProductQueryParam.
 *
 * @author bharat.aggarwal
 */
public enum QueryParamKeys {
	
	ID("_id"),
	CONTENTMETADATA_ID("extensions.contentMetadata.id"),
	TAGS("tags");
	
	/**
	 * Instantiates a new product query param.
	 *
	 * @param value the value
	 */
	QueryParamKeys(String value) {
		this.value = value;
	}
	
	/** The value. */
	private final String value;
	
	@Override
	  public String toString() {
	    return this.value;
	  }

	  /**
	   * Value.
	   *
	   * @return the string
	   */
	  @JsonValue
	  public String value() {
	    return this.value;
	  }

}
