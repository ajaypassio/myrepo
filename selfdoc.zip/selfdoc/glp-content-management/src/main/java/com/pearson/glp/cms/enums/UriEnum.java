/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.enums;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The Class UriEnum.
 */
public enum UriEnum {

    // Resource Provisioning URIs
    URI_RESOURCES("/v2/resources"),
    URI_ASSESS_RESOURCES("/v2/assessmentItemResources"),
    URI_LEARNING_APP_RESOURCES("/v2/learningAppResources"),

    URI_RESOURCE_VERSIONS("/v2/resources/{id}/versions"),

    URI_GET_RESOURCE_SPECIFIC_VERSION("/v2/resources/{id}/versions/{ver}"),
    URI_GET_ASSESS_RESOURCE_SPECIFIC_VERSION("/v2/assessmentItemResources/{id}/versions/{ver}"),
    URI_GET_LEARNINGAPP_RESOURCE_SPECIFIC_VERSION("/v2/learningAppResources/{id}/versions/{ver}"),

    URI_GET_RESOURCE_BY_ID("/v2/resources/{id}"),
    URI_GET_ASSESS_RESOURCE_BY_ID("/v2/assessmentItemResources/{id}"),
    URI_GET_LEARNINGAPP_RESOURCE_BY_ID("/v2/learningAppResources/{id}"),

    // Asset Model Provisioning URIs
    URI_ASSET_MODELS("/v2/assetModels"),
    URI_POST_ASSESSMENT_ITEM_MODELS("/v2/assessmentItemModels"),
    URI_POST_INSTRUCTION_MODELS("/v2/instructionModels"),
    URI_POST_ASSESSMENT_MODELS("/v2/assessmentModels"),
    URI_POST_NARRATIVE_MODELS("/v2/narrativeModels"),
    URI_POST_AGGREGATE_MODELS("/v2/aggregateModels"),
    URI_PRODUCT_MODELS("/v2/productModels"),
    URI_POST_LEARNINGAPP_MODELS("/v2/learningAppModels"),
    URI_POST_LEARNINGAPP_ITEM_MODELS("/v2/learningAppItemModels"),

    URI_GET_ASSET_MODEL_BY_ID("/v2/assetModels/{id}"),
    URI_PRODUCT_MODEL_BY_ID("/v2/productModels/{id}"),

    URI_ASSET_MODEL_VERSIONS("/v2/assetModels/{id}/versions"),
    URI_PRODUCT_MODEL_VERSIONS("/v2/productModels/{id}/versions"),
    URI_POST_INSTRUCTION_MODEL_VERSIONS("/v2/instructionModels/{id}/versions"),
    URI_POST_ASSESSMENT_MODEL_VERSIONS("/v2/assessmentModels/{id}/versions"),
    URI_POST_AGGREGATE_MODEL_VERSIONS("/v2/aggregateModels/{id}/versions"),
    URI_POST_NARRATIVE_MODEL_VERSIONS("/v2/narrativeModels/{id}/versions"),

    URI_GET_ASSET_MODEL_SPECIFIC_VERSION("/v2/assetModels/{id}/versions/{ver}"),
    URI_GET_PRODUCT_MODEL_SPECIFIC_VERSION("/v2/productModels/{id}/versions/{ver}"),
    URI_RENAME_PRODUCT_MODELS_LEARNING_AIDS("/v2/productModels/{id}/versions/{ver}/mapLearningAids"),

    // Asset Provisioning URIs
    URI_PRODUCTS("/v2/products"),
    URI_NARRATIVES("/v2/narratives"),
    URI_INSTRUCTIONS("/v2/instructions"),
    URI_AGGREGATES("/v2/aggregates"),
    URI_ASSESSMENTS("/v2/assessments"),
    URI_ASSESSMENT_ITEMS("/v2/assessmentItems"),
    URI_LEARNING_APP_ITEMS("/v2/learningAppItems"),
    URI_LEARNING_APPS("/v2/learningApps"),

    URI_GET_PRODUCT_SPECIFIC_VERSION("/v2/products/{id}/versions/{ver}"),
    URI_GET_NARRATIVE_SPECIFIC_VERSION("/v2/narratives/{id}/versions/{ver}"),
    URI_GET_ASSESSMENT_ITEM_SPECIFIC_VERSION("/v2/assessmentItems/{id}/versions/{ver}"),
    URI_GET_LEARNING_APP_ITEM_SPECIFIC_VERSION("/v2/learningAppItems/{id}/versions/{ver}"),
    URI_GET_INSTRUCTION_SPECIFIC_VERSION("/v2/instructions/{id}/versions/{ver}"),
    URI_GET_AGGREGATE_SPECIFIC_VERSION("/v2/aggregates/{id}/versions/{ver}"),
    URI_GET_ASSESSMENT_SPECIFIC_VERSION("/v2/assessments/{id}/versions/{ver}"),
    URI_GET_LEARNING_APP_SPECIFIC_VERSION("/v2/learningApps/{id}/versions/{ver}"),

    URI_GET_PRODUCT_BY_ID("/v2/products/{id}"),
    URI_GET_NARRATIVE_BY_ID("/v2/narratives/{id}"),
    URI_GET_INSTRUCTION_BY_ID("/v2/instructions/{id}"),
    URI_GET_AGGREGATE_BY_ID("/v2/aggregates/{id}"),
    URI_GET_ASSESSMENT_BY_ID("/v2/assessments/{id}"),
    URI_GET_ASSESSMENT_ITEM_BY_ID("/v2/assessmentItems/{id}"),
    URI_GET_LEARNING_APP_ITEM_BY_ID("/v2/learningAppItems/{id}"),
    URI_GET_LEARNING_APPS_BY_ID("/v2/learningApps/{id}"),

    URI_PRODUCT_VERSIONS("/v2/products/{id}/versions"),
    URI_NARRATIVE_VERSIONS("/v2/narratives/{id}/versions"),
    URI_INSTRUCTION_VERSIONS("/v2/instructions/{id}/versions"),
    URI_AGGREGATE_VERSIONS("/v2/aggregates/{id}/versions"),


    //State Transition URIs

    URI_PRODUCT_STATE_TRANSITION("/v2/products/{id}/versions/{ver}/stateTransitions"),
    URI_PRODUCT_STATUS("/v2/products/{id}/versions/{ver}/status"),
    URI_GET_PRODUCT_ASSESSMENT_TYPES("/v2/products/{id}/assessmentTypes"),

    // Product Asset Types
    URI_GET_PRODUCT_ASSET_TYPES("/v2/products/{id}/versions/{ver}/assetTypes"),
    URI_PRODUCT_MAP_ASSESSMENT_TYPES("/v2/products/{id}/versions/{ver}/mapAssessmentTypes"),
    // Product Assessment Runtime Settings
    URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS("/v2/products/{id}/versions/{ver}/assessmentRuntimeSettings"),
    // Renaming Learning Aids
    URI_RENAME_LEARNING_AIDS("/v2/products/{id}/versions/{ver}/mapLearningAids"),
    URI_DELIVERY_POLICY("/v2/policies"),
    URI_GET_PRODUCT_ASSESSMENT_TYPES_POLICY("/v2/products/{id}/versions/{ver}/assessmentTypes"),
    // Get Product Learning Aids
    URI_GET_PRODUCT_LEARNING_AIDS("/v2/products/{id}/versions/{ver}/learningAids"),
    //Get Product Model Learning Aids
    URI_GET_PRODUCT_MODEL_LEARNING_AIDS("/v2/productModels/{id}/versions/{ver}/learningAids"),
    // Fetch Renaming Product Configuration
    URI_GET_PRODUCT_SPECIFIC_VERSION_CONFIGURATION("/v2/products/{id}/versions/{ver}?fields=configuration"),
    //Product Category Weights
    URI_PRODUCT_CATEGORY_WEIGHTS("/v2/products/{id}/versions/{ver}/categoryWeights"),

    URI_POST_POLICIES("/v2/policies"),
    URI_POST_POLICIE_VERSIONS("/v2/policies/{id}/versions"),
    URI_HEALTH("/health"),
    /**
     * The uri embedded assets.
     */
    URI_EMBEDDED_ASSETS("/v2/embeddedAssets"),

    URI_GET_RESOLVED_POLICIES("/v2/resolvedPolicies"),
    URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS("/v2/productModels/{id}/versions/{ver}/assessmentRuntimeSettings"),
    URI_PRODUCT_MODELS_CATEGORY_WEIGHTS("/v2/productModels/{id}/versions/{ver}/categoryWeights"),
    URI_POST_CONFIG_STATUS("/v2/products/{id}/versions/{ver}/configStatus"),
    URI_PRODUCT_SCORING_POLICY("/v2/products/{id}/versions/{ver}/scoringPolicy"),
    URI_PRODUCT_MODEL_SCORING_POLICY("/v2/productModels/{id}/versions/{ver}/scoringPolicy"),
    URI_LAE_GET_GRADEBOOK_POLICY_PRODUCT("/v2/resolvedPolicies?group=TITLE_8883c099-1762-43fe-9ad8-4c9aaa6eafa2::200a3768-17af-4f2f-9d4c-b07c6cdfc456&assetClass=GRADEBOOKCATEGORYPOLICY"),
    URI_LAE_GET_POLICIES_INVALID("/v2/resolvedPolicies?group=Invalid&assetClass=GRADEBOOKCATEGORYPOLICY");

    /**
     * Instantiates a new uri constants.
     *
     * @param value the value
     */
    UriEnum(String value) {
        this.value = value;
    }

    /**
     * The value.
     */
    private final String value;

    /**
     * The Constant allUrls.
     */
    public static final List<String> allUrls = Collections.unmodifiableList(Arrays.stream(UriEnum.values())
            .map(uri -> uri.value())
            .collect(Collectors.toList()));

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return this.value;
    }

    /**
     * Value.
     *
     * @return the string
     */
    public String value() {
        return this.value;
    }
}