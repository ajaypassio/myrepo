/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.event.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.common.LearningModel;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.dto.resource.request.EventPayload;
import com.pearson.glp.cms.event.Events;
import com.pearson.glp.cms.helper.EngagementPolicyHelper;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerManager;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerContext;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerVoidResponse;
import com.pearson.glp.crosscutting.isc.client.async.model.EventMessage;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * This class is used to listen product ready for configuration events and
 * initiate the processing of assessment run time setting as per generated
 * scanned document of product.
 * 
 * @author ajay.kumar8
 */
@Component
@DependsOn("serviceHandlerManager")
@EnableBinding(Events.class)
public class ProductEventListener {

  /** The LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductEventListener.class);

  /**
   * Instantiates a new product event listener.
   */
  public ProductEventListener() {
    super();
  }

  /** The handlers manager. */
  @Autowired
  private ServiceHandlerManager handlerManager;

  /** The engagement policy helper. */
  @Autowired
  private EngagementPolicyHelper policyHelper;

  /**
   * Input handler.
   *
   * @param incomingEvent
   *          the incoming event
   */
  @StreamListener
  public void productReadyForConfigurtionInputHandler(
      @Input(Events.PRODUCT_PROMOTED_TO_CONFIGURATION) Flux<EventMessage> incomingEvent) {
    LOGGER.debug(LoggingConstants.PRODUCT_RFC_RECEIVING_EVENT_MESSAGE
        + Events.PRODUCT_PROMOTED_TO_CONFIGURATION);
    handlerManager.registerIscHandlers(Events.PRODUCT_PROMOTED_TO_CONFIGURATION, incomingEvent,
        this::productReadyForConfigurationHandler, null, null);
  }

  /**
   * Event Service Handler.
   *
   * @param context
   *          the context
   * @return the mono
   */

  public Mono<IscServiceHandlerVoidResponse> productReadyForConfigurationHandler(
      IscServiceHandlerContext context) {

    Mono<EventPayload> eventMessage = context.getPayload(EventPayload.class);
    return eventMessage.flatMap(event -> {
      LOGGER.debug(LoggingConstants.PRODUCT_RFC_RECEIVING_EVENT_MESSAGE);
      String id = event.getLearningAsset().getId();
      String version = event.getLearningAsset().getVer();
      /* Fetch policy group of product model */
      LearningModel learningModel = event.getLearningAsset().getLearningModel();
      Mono<String> modelPolicyGroups = policyHelper
          .getPolicyGroupFromProductModelConfig(learningModel.getId(), learningModel.getVer());
      /* Fetch policy group of product */
      String productPolicyGroup = CommonUtils
          .getPolicyGroups(event.getLearningAsset().getConfiguration());
      /* Fetch assessmentType of scanned product */
      Mono<ProductAssetTypes> productAssetTypes = policyHelper.fetchProductAssessmentType(id,
          version);

      policyHelper.applyDefaultProductRuntimePolicy(modelPolicyGroups, productPolicyGroup,
          productAssetTypes);

      policyHelper.applyDefaultProductScoringPolicy(modelPolicyGroups, productPolicyGroup,
          productAssetTypes);

      return IscServiceHandlerVoidResponse.ok().build();
    }).onErrorResume(this::handleProductRFCMessageExceptionOccured)
        .switchIfEmpty(this.handleproductRFCNotAvailableMessage());
  }

  /**
   * Product ready for configuration message not available
   * 
   * @return
   */
  private Mono<IscServiceHandlerVoidResponse> handleproductRFCNotAvailableMessage() {
    LOGGER.debug(LoggingConstants.PRODUCT_RFC_MESSAGE_NOT_AVAILABLE);
    return IscServiceHandlerVoidResponse.error().build();
  }

  /**
   * Product ready for configuration exception
   * 
   * @return
   */
  private Mono<IscServiceHandlerVoidResponse> handleProductRFCMessageExceptionOccured(
      Throwable ex) {
    LOGGER.error(LoggingConstants.ERROR_RECEIVING_EVENT_MESSAGE, ex.getMessage());
    return IscServiceHandlerVoidResponse.error().build();
  }

}