/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.exception;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.InvalidMediaTypeException;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.util.UriTemplate;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.enums.UriEnum;

import reactor.core.publisher.Mono;

/**
 * The Class ErrorHandler.
 *
 * @author sanket.gupta
 */
@Component
@Order(-2)
public class ErrorHandler extends AbstractErrorWebExceptionHandler {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandler.class);

  /**
   * Instantiates a new error handler.
   *
   * @param applicationContext
   *          the application context
   * @param serverCodecConfigurer
   *          the server codec configurer
   */
  public ErrorHandler(ApplicationContext applicationContext,
      ServerCodecConfigurer serverCodecConfigurer) {
    super(new DefaultErrorAttributes(), new ResourceProperties(), applicationContext);
    super.setMessageWriters(serverCodecConfigurer.getWriters());
    super.setMessageReaders(serverCodecConfigurer.getReaders());
  }

  /*
   * (non-Javadoc)
   *
   * @see org.springframework.boot.autoconfigure.web.reactive.error.
   * AbstractErrorWebExceptionHandler#getRoutingFunction(org.springframework.
   * boot.web.reactive.error.ErrorAttributes)
   */
  @Override
  protected RouterFunction<ServerResponse> getRoutingFunction(
      final ErrorAttributes errorAttributes) {
    LOGGER.debug("Error handling");
    return RouterFunctions.route(RequestPredicates.all(), this::renderErrorResponse);
  }

  /**
   * Render the Error Response.
   *
   * @param request
   *          the request
   * @return the mono
   */
  private Mono<ServerResponse> renderErrorResponse(final ServerRequest request) {
    Map<String, Object> errorPropertiesMap = getErrorAttributes(request, false);
    HttpStatus statusCode = HttpStatus
        .valueOf((Integer) errorPropertiesMap.get(CmsConstants.STATUS));
    String message = (String) errorPropertiesMap.get("message");

    if (!isValidMediaType(request)) {
      statusCode = HttpStatus.NOT_ACCEPTABLE;
    } else if (statusCode == HttpStatus.NOT_FOUND && isValidUri(request.path())) {
      statusCode = HttpStatus.METHOD_NOT_ALLOWED;
    }
    return createServerResponse(statusCode, message);
  }

  /**
   * Invalid media type.
   *
   * @param request
   *          the request
   * @return true, if successful
   */
  private boolean isValidMediaType(final ServerRequest request) {
    boolean isValidMediaType = true;
    try {
      request.headers().accept();
    } catch (InvalidMediaTypeException ex) {
      isValidMediaType = false;
    }
    return isValidMediaType;
  }

  /**
   * Create the error response.
   *
   * @param httpStatus
   *          the http status
   * @return the mono
   */
  private Mono<ServerResponse> createServerResponse(HttpStatus httpStatus, String message) {
    CustomErrorMessage errorPayload = (message != null)
        ? new CustomErrorMessage(httpStatus.value(), message)
        : new CustomErrorMessage(httpStatus.value());
    return ServerResponse.status(httpStatus).contentType(MediaType.APPLICATION_JSON_UTF8)
        .syncBody(errorPayload);
  }

  /**
   * Validate the URI.
   *
   * @param uri
   *          the uri
   * @return true, if successful
   */
  private boolean isValidUri(String uri) {
    return UriEnum.allUrls.stream().anyMatch(route -> {
      UriTemplate uriTemplate = new UriTemplate(CmsConstants.CMS_CONTEXT + route);
      if (uriTemplate.matches(uri)) {
        return isValidPathParams(uriTemplate.match(uri));
      }
      return false;
    });
  }

  /**
   * Checks if is valid path params.
   *
   * @param pathVariables
   *          the path variables
   * @return true, if is valid path params
   */
  private boolean isValidPathParams(Map<String, String> pathVariables) {
    if (pathVariables.isEmpty()) {
      return true;
    } else {
      boolean isValid;
      String idParam = pathVariables.get(CmsConstants.ID);
      String verParam = pathVariables.get(CmsConstants.VER);
      isValid = !idParam.isEmpty();
      if (isValid && verParam != null) {
        isValid = !(verParam.isEmpty());
      }
      return isValid;
    }
  }
}
