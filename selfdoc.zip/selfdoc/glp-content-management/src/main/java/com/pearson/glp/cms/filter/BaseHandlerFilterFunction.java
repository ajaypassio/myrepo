/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.filter;

import java.util.UUID;

import javax.ws.rs.core.HttpHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.HandlerFilterFunction;
import org.springframework.web.reactive.function.server.HandlerFunction;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.exception.CustomErrorMessage;

import reactor.core.publisher.Mono;

/**
 * The Class BaseHandlerFilterFunction.
 */
public class BaseHandlerFilterFunction
    implements HandlerFilterFunction<ServerResponse, ServerResponse> {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(BaseHandlerFilterFunction.class);

  /** The Constant APPLICATION_JSON_UTF. */
  private static final String APPLICATION_JSON_UTF = "application/json; charset=UTF-8";

  /** The Constant APPLICATION_JSON. */
  private static final String APPLICATION_JSON = "application/json";

  /**
   * Instantiates a new base handler filter function.
   */
  public BaseHandlerFilterFunction() {
    super();
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * org.springframework.web.reactive.function.server.HandlerFilterFunction#
   * filter(org.springframework.web.reactive.function.server.ServerRequest,
   * org.springframework.web.reactive.function.server.HandlerFunction)
   */
  @Override
  public Mono<ServerResponse> filter(ServerRequest serverRequest,
      HandlerFunction<ServerResponse> handlerFunction) {
    Mono<ServerResponse> serverResponse = null;
    if (isNotValidUrl(serverRequest)) {
      LOGGER.debug(LoggingConstants.FILTER_INVALID_URL, serverRequest.method(),
          serverRequest.uri());
      serverResponse = getErrorResponseByHttpStatus(HttpStatus.BAD_REQUEST);
    } else if (!isValidAcceptHeaderPresent(serverRequest)) {
      LOGGER.debug(LoggingConstants.FILTER_INVALID_ACCEPT_HEADER, serverRequest.method(),
          serverRequest.uri());
      serverResponse = getErrorResponseByHttpStatus(HttpStatus.NOT_ACCEPTABLE);
    } else if (isAllowedMethod(serverRequest.method()) && !isJsonContentTypeHeader(serverRequest)) {
      LOGGER.debug(LoggingConstants.FILTER_INVALID_CONTENT_TYPE_HEADER, serverRequest.method(),
          serverRequest.uri());
      serverResponse = getErrorResponseByHttpStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    } else {
      serverResponse = handlerFunction.handle(serverRequest);
    }
    return serverResponse;
  }

  /**
   * Checks if is valid url.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is valid url
   */
  private boolean isNotValidUrl(ServerRequest serverRequest) {
    return serverRequest.pathVariables().values().stream().anyMatch(s -> !isUuid(s));
  }

  /**
   * Are required headers present.
   *
   * @param serverRequest
   *          the server request
   * @return true, if successful
   */
  private boolean isValidAcceptHeaderPresent(ServerRequest serverRequest) {
    return isJsonAcceptHeader(serverRequest) || (serverRequest.method() == HttpMethod.POST
        && isJsonStreamAcceptHeaderApplicable(serverRequest)
        && isJsonStreamAcceptHeader(serverRequest));
  }

  /**
   * Checks if is json accept header.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is json accept header
   */
  private boolean isJsonAcceptHeader(ServerRequest serverRequest) {
    return serverRequest.headers().header(HttpHeaders.ACCEPT)
        .contains(MediaType.APPLICATION_JSON_VALUE);
  }

  /**
   * Checks if is json content type header.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is json content type header
   */
  private boolean isJsonContentTypeHeader(ServerRequest serverRequest) {
    return serverRequest.headers().header(HttpHeaders.CONTENT_TYPE).contains(APPLICATION_JSON)
        || serverRequest.headers().header(HttpHeaders.CONTENT_TYPE).contains(APPLICATION_JSON_UTF);
  }

  /**
   * Checks if is json stream content type header.
   *
   * @param serverRequest
   *          the server request
   * @return true, if is json stream content type header
   */
  private boolean isJsonStreamAcceptHeader(ServerRequest serverRequest) {
    return serverRequest.headers().header(HttpHeaders.ACCEPT)
        .contains(MediaType.APPLICATION_STREAM_JSON_VALUE);
  }

  /**
   * Gets the error response by http status.
   *
   * @param httpStatus
   *          the http status
   * @return the error response by http status
   */
  private Mono<ServerResponse> getErrorResponseByHttpStatus(HttpStatus httpStatus) {
    return ServerResponse.status(httpStatus.value())
        .syncBody(new CustomErrorMessage(httpStatus.value()));
  }

  /**
   * Checks if is Uuid.
   *
   * @param string
   *          the string
   * @return true, if is Uuid
   */
  private boolean isUuid(String string) {
    try {
      UUID.fromString(string);
      return true;
    } catch (IllegalArgumentException ex) {
      return false;
    }
  }

  /**
   * Checks if is json stream accept header applicable.
   *
   * @param request
   *          the request
   * @return true, if is json stream accept header applicable
   */
  private boolean isJsonStreamAcceptHeaderApplicable(ServerRequest request) {
    return request.pathVariables().values().isEmpty();
  }

  /**
   * Checks if is allowed method.
   *
   * @param httpMethod
   *          the http method
   * @return true, if is allowed method
   */
  private boolean isAllowedMethod(HttpMethod httpMethod) {
    return (httpMethod == HttpMethod.POST || httpMethod == HttpMethod.PUT);
  }

}
