/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.learningmodel.request.AssetModelPayload;
import com.pearson.glp.cms.dto.learningmodel.response.BulkLearningModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.enums.AssetType;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;

import static com.pearson.glp.cms.constants.CmsConstants.ASSESSMENT_ITEM_RESOURCE;

import reactor.core.publisher.Mono;

/**
 * The Class AssetModelHandler.
 */
@Component
public class AssetModelHandler extends BaseHandler {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(AssetModelHandler.class);

  /**
   * Instantiates a new asset model handler.
   */
  public AssetModelHandler() {
    super();
  }

  /**
   * Gets the asset models.
   *
   * @param context
   *          the context
   * @return the asset models
   */
  public Mono<ServiceHandlerResponse> getAssetModels(ServiceHandlerContext context) {
    LOGGER.debug("getAssetModels Calling ");
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_ASSET_MODELS);
    LOGGER.debug("getAssetModels calling url {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        BulkLearningModels.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Creates the narrative model.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createNarrativeModel(ServiceHandlerContext context) {
    LOGGER.debug("createNarrativeModel for {}", CmsConstants.NARRATIVE);
    return createAssetModel(context, CmsConstants.NARRATIVE);
  }

  /**
   * Creates the instruction model.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createInstructionModel(ServiceHandlerContext context) {
    LOGGER.debug("createInstructionModel for {}", CmsConstants.INSTRUCTION);
    return createAssetModel(context, CmsConstants.INSTRUCTION);
  }

  /**
   * Creates the aggregate model.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAggregateModel(ServiceHandlerContext context) {
    LOGGER.debug("createAggregateModel for {}", CmsConstants.AGGREGATE);
    return createAssetModel(context, CmsConstants.AGGREGATE);
  }

  /**
   * Creates the assessment model.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAssessmentModel(ServiceHandlerContext context) {
    LOGGER.debug("createAssessmentModel for {}", CmsConstants.ASSESSMENT);
    return createAssetModel(context, CmsConstants.ASSESSMENT);
  }

  /**
   * Creates the assessment item model.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAssessmentItemModel(ServiceHandlerContext context) {
    LOGGER.debug(LoggingConstants.POST_ASSESSMENT_ITEM_MODEL_LOG_MESSAGE, ASSESSMENT_ITEM_RESOURCE);
    return createAssetModel(context, AssetType.ASSESSMENT_ITEM.toString());
  }

  /**
   * Creates the asset model.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAssetModel(ServiceHandlerContext context,
      String assetType) {
    LOGGER.debug("createAssetModel Calling");
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_ASSET_MODELS);
    LOGGER.debug("Calling url {}", serviceUrl);
    return validator.validateRequest(
        reqBodyMono -> reqBodyMono.flatMap(requestBody -> setJsonResponse(
            iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                GLPAssetModel.class, IscSyncResponseFormat.RAW),
            HttpStatus.CREATED)),
        context, AssetModelPayload.class, Optional.of(assetType), Optional.empty());
  }

  /**
   * Gets the asset model by id.
   *
   * @param context
   *          the context
   * @return the asset model by id
   */
  public Mono<ServiceHandlerResponse> getAssetModelById(ServiceHandlerContext context) {
    String assetModelId = context.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_ASSET_MODEL_BY_ID, assetModelId);
    LOGGER.debug("getAssetModelById Calling url {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        GLPAssetModel.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the asset models versions.
   *
   * @param context
   *          the context
   * @return the asset models versions
   */
  public Mono<ServiceHandlerResponse> getAssetModelsVersions(ServiceHandlerContext context) {
    LOGGER.debug("getAssetModelsVersions Calling {} ", UriEnum.URI_ASSET_MODEL_VERSIONS);
    String assetModelId = context.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_ASSET_MODEL_VERSIONS, assetModelId);
    LOGGER.debug("Calling url {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        BulkLearningModels.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Creates the narrative models versions.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createNarrativeModelsVersions(ServiceHandlerContext context) {
    LOGGER.debug("createNarrativeModelsVersions for {}", CmsConstants.NARRATIVE);
    return createAssetModelsVersions(context, CmsConstants.NARRATIVE);
  }

  /**
   * Creates the instruction models versions.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createInstructionModelsVersions(
      ServiceHandlerContext context) {
    LOGGER.debug("createInstructionModelsVersions for {}", CmsConstants.INSTRUCTION);
    return createAssetModelsVersions(context, CmsConstants.INSTRUCTION);
  }

  /**
   * Creates the aggregate models versions.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAggregateModelsVersions(ServiceHandlerContext context) {
    LOGGER.debug("createAggregateModelsVersions for {}", CmsConstants.AGGREGATE);
    return createAssetModelsVersions(context, CmsConstants.AGGREGATE);
  }

  /**
   * Creates the assessment models versions.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAssessmentModelsVersions(
      ServiceHandlerContext context) {
    LOGGER.debug("createAssessmentModelsVersions for {}", CmsConstants.ASSESSMENT);
    return createAssetModelsVersions(context, CmsConstants.ASSESSMENT);
  }

  /**
   * Creates the asset models versions.
   *
   * @param context
   *          the context
   * @param assetType
   *          the asset type
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createAssetModelsVersions(ServiceHandlerContext context,
      String assetType) {
    LOGGER.debug("createAssetModelsVersions Calling {}", UriEnum.URI_ASSET_MODEL_VERSIONS);
    String assetModelId = context.getParameter(CmsConstants.ID);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_ASSET_MODEL_VERSIONS,
        assetModelId);
    LOGGER.debug("createAssetModelsVersions  calling url {}", serviceUrl);
    return validator.validateRequest(
        reqBodyMono -> reqBodyMono.flatMap(requestBody -> setJsonResponse(
            iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                GLPAssetModel.class, IscSyncResponseFormat.RAW),
            HttpStatus.CREATED)),
        context, AssetModelPayload.class, Optional.of(assetType), Optional.empty());
  }

  /**
   * Gets the asset model by version id.
   *
   * @param context
   *          the context
   * @return the asset model by version id
   */
  public Mono<ServiceHandlerResponse> getAssetModelByVersionId(ServiceHandlerContext context) {

    String assetModelId = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_ASSET_MODEL_SPECIFIC_VERSION,
        assetModelId, version);
    LOGGER.debug("getAssetModelByVersionId Calling {} with id{} and version {}",
        UriEnum.URI_ASSET_MODEL_VERSIONS, assetModelId, version);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        GLPAssetModel.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

}
