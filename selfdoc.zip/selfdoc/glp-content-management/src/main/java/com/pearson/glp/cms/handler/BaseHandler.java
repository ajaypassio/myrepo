/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.beanvalidation.validators.CmsRequestValidator;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetPayload;
import com.pearson.glp.cms.dto.resource.ValidationResult;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.isc.IscReactiveClient;
import com.pearson.glp.cms.utils.ErrorUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

/**
 * The Class BaseHandler.
 * 
 * @author anuj.verma
 */
@Component
public class BaseHandler {

  /** The lpb base url. */
  @Value("${base.url.lpb}")
  protected String lpbBaseUrl;

  /** The lap base url. */
  @Value("${base.url.lap}")
  protected String lapBaseUrl;

  /** The lad base url. */
  @Value("${base.url.lad}")
  protected String ladBaseUrl;

  /** The lae base url. */
  @Value("${base.url.lae}")
  protected String laeBaseUrl;

  /** The lee base url. */
  @Value("${base.url.lee}")
  protected String leeBaseUrl;

  /** The learning model details for runtimeSettings policy LEE. */
  @Value("${schema.policylearningmodel.lee.runtimesettings}")
  protected String runtimeSettingsLmLee;

  /** The learning model details for runtimeSettings policy LAE. */
  @Value("${schema.policylearningmodel.lae.runtimesettings}")
  protected String runtimeSettingsLmLae;

  /** The learning model details for runtimeSettings policy LAD. */
  @Value("${schema.policylearningmodel.lad.runtimesettings}")
  protected String runtimeSettingsLmLad;

  /** The category weights lm lae. */
  @Value("${schema.policylearningmodel.lae.categoryweights}")
  protected String categoryWeightsLmLae;

  /** The learning model details for scoring policy LAE. */
  @Value("${schema.policylearningmodel.lae.scoring}")
  protected String scoringPolicyLmLae;

  /** The learning model for Learning Aids policy. */
  @Value("${schema.policylearningmodel.lad.learningAids}")
  protected String learningAidsLmLad;

  /** The learning model for Assessment Types policy. */
  @Value("${schema.policylearningmodel.lad.assessmentTypes}")
  protected String assessmentTypeLmLad;

  /** The lad continuous setting keys. */
  @Value("${lad.continuous.settings.keys}")
  protected String ladContinuousSettingKeys;

  /** The lad discreet setting keys. */
  @Value("${lad.discreet.settings.keys}")
  protected String ladDiscreetSettingKeys;

  /** The lee continuous setting keys. */
  @Value("${lee.continuous.settings.keys}")
  protected String leeContinuousSettingKeys;

  /** The lee discreet setting keys. */
  @Value("${lee.discreet.settings.keys}")
  protected String leeDiscreetSettingKeys;

  /** The lae continuous setting keys. */
  @Value("${lae.continuous.settings.keys}")
  protected String laeContinuousSettingKeys;

  /** The lae discreet setting keys. */
  @Value("${lae.discreet.settings.keys}")
  protected String laeDiscreetSettingKeys;

  /** The validator. */
  @Autowired
  protected CmsRequestValidator validator;

  /** The isc sync client. */
  @Autowired
  protected IscSyncClient iscSyncClient;

  /** The isc flux client. */
  @Autowired
  protected IscReactiveClient iscFluxClient;

  /**
   * Instantiates a new base handler.
   */
  public BaseHandler() {
    super();
  }

  /**
   * Prepare headers.
   *
   * @param context
   *          the context
   * @return the map
   */
  protected Map<String, String> prepareHeaders(ServiceHandlerContext context) {
    Map<String, String> cmsHeaders = context.getAllHeaders();
    cmsHeaders.put("trusted-source", Boolean.TRUE.toString());
    cmsHeaders.put("source", CmsConstants.CMS);
    return cmsHeaders;
  }

  /**
   * Marshall asset payload with error.
   *
   * @param assetWithErrors
   *          the asset with errors
   * @return the asset payload
   */
  protected AssetPayload marshallAssetPayloadWithError(
      Tuple2<AssetPayload, List<String>> assetWithErrors) {
    List<String> errors = assetWithErrors.getT2();
    AssetPayload asset = assetWithErrors.getT1();
    if (!errors.isEmpty()) {
      ValidationResult validationResult = new ValidationResult(true, errors);
      asset.setValidationResult(validationResult);
    }
    return asset;
  }

  /**
   * Sets the json response.
   *
   * @param <T>
   *          the generic type
   * @param objMono
   *          the obj mono
   * @param httpStatus
   *          the http status
   * @return the mono
   */
  protected <T> Mono<ServiceHandlerResponse> setJsonResponse(Mono<T> objMono,
      HttpStatus httpStatus) {
    return objMono.flatMap(response -> JsonPayloadServiceResponse.withStatus(httpStatus)
        .setHeader(CmsConstants.CONTENT_TYPE, CmsConstants.CONTENT_TYPE_HAL).setPayload(response))
        .switchIfEmpty(Mono.error(
            new CmsException(HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorConstants.NO_RESPONSE)))
        .onErrorResume(ErrorUtils::handleCmsError);
  }

  /**
   * Sets the json flux response.
   *
   * @param <T>
   *          the generic type
   * @param responseFlux
   *          the response flux
   * @param httpStatus
   *          the http status
   * @param contentType
   *          the content type
   * @return the mono
   */
  protected <T> Mono<ServiceHandlerResponse> setJsonFluxResponse(Flux<T> responseFlux,
      HttpStatus httpStatus, String contentType) {
    return JsonPayloadServiceResponse.withStatus(httpStatus).setContentType(contentType)
        .setFluxPayload(responseFlux)
        .switchIfEmpty(Mono.error(
            new CmsException(HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorConstants.NO_RESPONSE)))
        .onErrorResume(ErrorUtils::handleCmsError);
  }

  /**
   * Check streaming flag and return.
   *
   * @param <R>
   *          the generic type
   * @param flux
   *          the flux
   * @param classType
   *          the class type
   * @param serverRequest
   *          the server request
   * @return the mono
   */
  protected <R> Mono<ServerResponse> checkStreamResponse(Flux<R> flux, Class<R> classType,
      ServerRequest serverRequest) {
    Boolean streamJsonFlag = serverRequest.headers().accept().stream()
        .anyMatch(medType -> medType.equals(MediaType.APPLICATION_STREAM_JSON));
    if (streamJsonFlag) {
      return streamOfEntities(flux, classType);
    }
    return listOfEntities(flux);
  }

  /**
   * List of entities.
   *
   * @param <T>
   *          the generic type
   * @param flux
   *          the flux
   * @return the mono
   */
  public <T> Mono<ServerResponse> listOfEntities(Flux<T> flux) {
    return flux.collectList()
        .flatMap(list -> ServerResponse.status(HttpStatus.MULTI_STATUS.value())
            .header(CmsConstants.CONTENT_TYPE, CmsConstants.CONTENT_TYPE_HAL)
            .body(BodyInserters.fromObject(list)))
        .switchIfEmpty(ServerResponse.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .body(BodyInserters.fromObject(new CustomErrorMessage())))
        .onErrorResume(ErrorUtils::handleServerResponseError);
  }

  /**
   * Stream of entities.
   *
   * @param <T>
   *          the generic type
   * @param flux
   *          the flux
   * @param clazz
   *          the clazz
   * @return the mono
   */
  public <T> Mono<ServerResponse> streamOfEntities(Flux<T> flux, Class<T> clazz) {
    return ServerResponse.status(HttpStatus.MULTI_STATUS.value())
        .contentType(MediaType.APPLICATION_STREAM_JSON)
        .body(BodyInserters.fromPublisher(flux, clazz))
        .switchIfEmpty(ServerResponse.status(HttpStatus.INTERNAL_SERVER_ERROR.value())
            .body(BodyInserters.fromObject(new CustomErrorMessage())))
        .onErrorResume(ErrorUtils::handleServerResponseError);
  }

}
