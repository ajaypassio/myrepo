/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.beanvalidation.groups.GroupAssessments;
import com.pearson.glp.cms.beanvalidation.groups.GroupNonPrimitiveLA;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetVersionRequest;
import com.pearson.glp.cms.dto.learningasset.request.AssetsRequest;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The NonPrimitiveAssetHandler.
 *
 * @author sanket.gupta
 */
@Component
public class NonPrimitiveAssetHandler extends BaseHandler {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(NonPrimitiveAssetHandler.class);

  /**
   * Instantiates a new non primitive asset handler.
   */
  public NonPrimitiveAssetHandler() {
    super();
  }

  /**
   * getNonPrimitiveAssets method.
   *
   * @param actionContext
   *          the action context
   * @param uri
   *          the asset type
   * @return the non primitive assets
   */
  public Mono<ServiceHandlerResponse> getNonPrimitiveAssets(ServiceHandlerContext actionContext,
      UriEnum uri) {
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, uri);
    LOGGER.debug(LoggingConstants.GET_NON_PRIMITIVE_ASSETS_LOG_MESSAGE, serviceUrl);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(actionContext),
        BulkAssets.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * createNonPrimitiveAssets method.
   *
   * @param serverRequest
   *          the server request
   * @param uri
   *          the asset type
   * @return the mono
   */
  public Mono<ServerResponse> createNonPrimitiveAssets(ServerRequest serverRequest, UriEnum uri) {
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, uri);
    LOGGER.debug(LoggingConstants.CREATE_NON_PRIMITIVE_ASSETS_LOG_MESSAGE, serviceUrl);
    Optional<Class<?>> validationGroup = (uri == (UriEnum.URI_ASSESSMENTS))
        ? Optional.of(GroupAssessments.class)
        : Optional.of(GroupNonPrimitiveLA.class);
    return validator.validatePostRequest(requestBodyMono -> {
      Flux<AssetWithStatus> assetResponseFlux = iscFluxClient.postObjects(serviceUrl,
          requestBodyMono, AssetsRequest.class, AssetWithStatus.class);
      return checkStreamResponse(assetResponseFlux, AssetWithStatus.class, serverRequest);
    }, serverRequest, AssetsRequest.class, validationGroup);
  }

  /**
   * createNonPrimitiveAssetVersion method.
   *
   * @param actionContext
   *          the action context
   * @param uri
   *          the asset type
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createNonPrimitiveAssetVersion(
      ServiceHandlerContext actionContext, UriEnum uri) {
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, uri,
        actionContext.getParameter(CmsConstants.ID));
    LOGGER.debug(LoggingConstants.CREATE_NON_PRIMITIVE_ASSET_VERSION_LOG_MESSAGE, serviceUrl);
    return validator
        .validateRequest(
            requestBodyMono -> requestBodyMono
                .flatMap(
                    requestBody -> setJsonResponse(
                        iscSyncClient.postObject(serviceUrl, prepareHeaders(actionContext),
                            requestBody, AssetWithStatus.class, IscSyncResponseFormat.RAW),
                        HttpStatus.CREATED)),
            actionContext, AssetVersionRequest.class, Optional.empty(),
            Optional.of(GroupNonPrimitiveLA.class));
  }

  /**
   * getNonPrimitiveAssetById method.
   *
   * @param actionContext
   *          the action context
   * @param uri
   *          the asset type
   * @return the non primitive asset by id
   */
  public Mono<ServiceHandlerResponse> getNonPrimitiveAssetById(ServiceHandlerContext actionContext,
      UriEnum uri) {
    String assetId = actionContext.getParameter(CmsConstants.ID);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, uri, assetId);
    LOGGER.debug(LoggingConstants.GET_NON_PRIMITIVE_ASSET_BY_ID_LOG_MESSAGE, serviceUrl, assetId);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * getNonPrimitiveAssetVersions method.
   *
   * @param actionContext
   *          the action context
   * @param uri
   *          the asset type
   * @return the non primitive asset versions
   */
  public Mono<ServiceHandlerResponse> getNonPrimitiveAssetVersions(
      ServiceHandlerContext actionContext, UriEnum uri) {
    String assetId = actionContext.getParameter(CmsConstants.ID);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, uri, assetId);
    LOGGER.debug(LoggingConstants.GET_NON_PRIMITIVE_ASSET_VERSIONS_LOG_MESSAGE, serviceUrl,
        assetId);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(actionContext),
        LearningAssetVersions.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * getNonPrimitiveAssetByIdAndVersion method.
   * 
   * @param actionContext
   *          the action context
   * @param uri
   *          the asset type
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> getNonPrimitiveAssetByIdAndVersion(
      ServiceHandlerContext actionContext, UriEnum uri) {
    String assetId = actionContext.getParameter(CmsConstants.ID);
    String version = actionContext.getParameter(CmsConstants.VER);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, uri, assetId, version);
    LOGGER.debug(LoggingConstants.GET_NON_PRIMITIVE_ASSET_BY_VERSION_ID_LOG_MESSAGE, serviceUrl,
        assetId, version);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the all assessment.
   *
   * @param context
   *          the context
   * @return the all assessment
   */
  public Mono<ServiceHandlerResponse> getAllAssessment(ServiceHandlerContext context) {

    LOGGER.debug(LoggingConstants.GET_ALL_ASSESSMENT);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_ASSESSMENTS);
    Mono<String> queryParam = CommonUtils.getQueryParameter(context, serviceUrl);
    return setJsonResponse(queryParam.flatMap(url -> iscSyncClient.getObject(url,
        prepareHeaders(context), BulkAssets.class, IscSyncResponseFormat.RAW)), HttpStatus.OK);
  }

}
