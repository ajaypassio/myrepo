/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.common.AssetInlineResource;
import com.pearson.glp.cms.dto.learningpolicy.request.AssessmentTypePayload;
import com.pearson.glp.cms.dto.learningpolicy.request.CategoryWeightsPayload;
import com.pearson.glp.cms.dto.learningpolicy.request.Data;
import com.pearson.glp.cms.dto.learningpolicy.request.GradeBookCategoryPolicy;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.learningpolicy.response.RuntimeSettingsResponse;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.helper.EngagementPolicyHelper;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;

import reactor.core.publisher.Mono;

/**
 * The Class Policy Handlers.
 *
 * @author ajay.kumar8
 *
 */
@Component
public class PolicyHandler extends BaseHandler {

  /**
   * The logger.
   */
  private Logger logger = LoggerFactory.getLogger(PolicyHandler.class);

  /**
   * The policy helper.
   */
  @Autowired
  private EngagementPolicyHelper policyHelper;

  /**
   * Instantiates a new policy handler.
   */
  public PolicyHandler() {
    super();
  }

  /**
   * Gets the resolved policies.
   *
   * @param context
   *          the context
   * @param assetClass
   *          the asset class
   * @return the resolved policies
   */
  public Mono<ServiceHandlerResponse> getResolvedPolicies(ServiceHandlerContext context,
      String assetClass) {
    logger.debug(LoggingConstants.GET_POLICIES_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.GET_PRODUCT_POLICIES, productId, productVersion);
    /* Fetching product policy group for specific product id and version */
    Mono<String> policyGroupString = policyHelper.getPolicyGroupFromConfig(productId,
        productVersion);
    if (AssetClass.GRADE_BOOK_CATEGORY_POLICY.value().equals(assetClass)) {
      Mono<CategoryWeightsPayload> mapMono = policyGroupString.flatMap(policyGroup -> policyHelper
          .getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES, assetClass, policyGroup)
          .map(this::translateToGetCategoryWeightsResponse));
      return setJsonResponse(mapMono, HttpStatus.OK);
    } else {
      /* Get delivery product resolved policy */
      Mono<GLPLearningPolicy> policyResponse = policyGroupString.flatMap(policyGroup -> policyHelper
          .getPolicy(ladBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES, assetClass, policyGroup));
      return setJsonResponse(policyResponse, HttpStatus.OK);
    }

  }

  /**
   * Gets the product scoring policy.
   *
   * @param context
   *          the context
   * @return the product scoring policy
   */
  public Mono<ServiceHandlerResponse> getProductScoringPolicy(ServiceHandlerContext context) {

    logger.debug(LoggingConstants.GET_PRODUCT_MODEL_SCORING_POLICY_LOG);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.ID, id);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.VERSION, version);

    /* Get scoring policy */
    return fetchPolicies(policyHelper.getPolicyGroupFromConfig(id, version), laeBaseUrl,
        AssetClass.ASSESSMENT_SCORING_POLICY.value(), CmsConstants.SCORING_POLICY);
  }

  /**
   * Gets the product model scoring policy.
   *
   * @param context
   *          the context
   * @return the product model scoring policy
   */
  public Mono<ServiceHandlerResponse> getProductModelScoringPolicy(ServiceHandlerContext context) {

    logger.debug(LoggingConstants.GET_PRODUCT_MODEL_SCORING_POLICY_LOG);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.ID, id);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.VERSION, version);

    /* Get scoring policy */
    return fetchPolicies(policyHelper.getPolicyGroupFromProductModelConfig(id, version), laeBaseUrl,
        AssetClass.ASSESSMENT_SCORING_POLICY.value(), CmsConstants.SCORING_POLICY);
  }

  /**
   * Post the product scoring policy.
   *
   * @param context
   *          the context
   * @return the product scoring policy
   */
  public Mono<ServiceHandlerResponse> postProductScoringPolicy(ServiceHandlerContext context) {

    logger.debug(LoggingConstants.POST_PRODUCT_SCORING_POLICY_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.ID, productId);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.VERSION, productVersion);

    /* Fetching product policy group for specific product id and version */
    Mono<String> productPolicyGroup = policyHelper.getPolicyGroupFromConfig(productId,
        productVersion);

    return postScoringPolicy(productPolicyGroup, context);
  }

  /**
   * Post the product model scoring policy.
   *
   * @param context
   *          the context
   * @return the product scoring policy
   */
  public Mono<ServiceHandlerResponse> postProductModelScoringPolicy(ServiceHandlerContext context) {

    logger.debug(LoggingConstants.POST_PRODUCT_MODEL_SCORING_POLICY_LOG);
    String productModelId = context.getParameter(CmsConstants.ID);
    String productModelVersion = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.ID, productModelId);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.VERSION, productModelVersion);

    /*
     * Fetching product policy group for specific product model id and version
     */
    Mono<String> productModelPolicyGroup = policyHelper
        .getPolicyGroupFromProductModelConfig(productModelId, productModelVersion);

    return postScoringPolicy(productModelPolicyGroup, context);
  }

  /**
   * Post Product Scoring Policy.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postScoringPolicy(Mono<String> policyGroupString,
      ServiceHandlerContext context) {
    logger.debug(LoggingConstants.POST_PRODUCT_SCORING_POLICY);

    Mono<GLPLearningPolicy> policyVersionResponse = policyGroupString.flatMap(policy -> context
        .getPayload(Map.class).flatMap(payload -> policyHelper.postProductScoringPolicy(payload,
            policy, AssetClass.ASSESSMENT_SCORING_POLICY.value())));

    return setJsonResponse(policyVersionResponse, HttpStatus.CREATED);
  }

  /**
   * Construct policy response.
   *
   * @param policy
   *          the policy
   * @param policyType
   *          the policy type
   * @return the map
   */
  private Map<String, AssetInlineResource> constructPolicyResponse(GLPLearningPolicy policy,
      String policyType) {
    logger.debug(LoggingConstants.TRANSFORMING_GET_POLICY_RESPONSE);
    AssetInlineResource resource = new AssetInlineResource(policy.getResources().get(policyType));
    Map<String, AssetInlineResource> responseMap = new HashMap<>();
    responseMap.put(policyType, resource);
    return responseMap;
  }

  /**
   * Translate to get category weights response.
   *
   * @param policy
   *          the policy
   * @return the category weights response
   */
  private CategoryWeightsPayload translateToGetCategoryWeightsResponse(GLPLearningPolicy policy) {
    GradeBookCategoryPolicy gradeBookCategoryPolicy = new GradeBookCategoryPolicy();
    Data data = CommonUtils.OBJECT_MAPPER.convertValue(
        policy.getResources().get(CmsConstants.GRADEBOOKCATEGORYPOLICY).getData(), Data.class);
    gradeBookCategoryPolicy.setData(data);
    CategoryWeightsPayload categoryWeightsPayload = new CategoryWeightsPayload();
    categoryWeightsPayload.setGradebookCategoryPolicy(gradeBookCategoryPolicy);
    categoryWeightsPayload.setStatus(policy.getStatus());
    return categoryWeightsPayload;
  }

  /**
   * Post policy for product assessment run time settings.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postPolicyForProductAssessmentRuntimeSettings(
      ServiceHandlerContext context) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_POST_POLICY_FOR_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.ID, id);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.VERSION, version);
    String selfLink = CommonUtils.getUrl(null, UriEnum.URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS, id,
        version);
    return postAssessmentRuntimeSettings(context,
        policyHelper.getPolicyGroupFromConfig(id, version), selfLink);
  }

  /**
   * Post policy for product model assessment runtime settings.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postPolicyForProductModelAssessmentRuntimeSettings(
      ServiceHandlerContext context) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_POST_POLICY_FOR_PRODUCT_MODEL_ASSESSMENT_RUNTIMESETTINGS);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.ID, id);
    logger.debug(LoggingConstants.PARAMETER, CmsConstants.VERSION, version);
    String selfLink = CommonUtils.getUrl(null,
        UriEnum.URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS, id, version);
    return postAssessmentRuntimeSettings(context,
        policyHelper.getPolicyGroupFromProductModelConfig(id, version), selfLink);
  }

  /**
   * Post assessment runtime settings.
   *
   * @param context
   *          the context
   * @param policyGroups
   *          the policy groups
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> postAssessmentRuntimeSettings(ServiceHandlerContext context,
      Mono<String> policyGroups, String selfLink) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.METHOD_POST_ASSESSMENT_RUNTIMESETTINGS);
    Mono<RuntimeSettingsResponse> runtimeSettingResponse = policyGroups.flatMap(
        group -> context.getPayload(AssessmentTypePayload.class).flatMap(payload -> policyHelper
            .createAssessmentRuntimePolicyResponse(payload, group, selfLink)));
    return setJsonResponse(runtimeSettingResponse, HttpStatus.CREATED);
  }

  /**
   * Get Product Model Assessment Runtime Settings.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> getProductModelAssessmentRunTimeSettings(
      ServiceHandlerContext context) {
    logger.debug(LoggingConstants.METHOD_GET_PRODUCT_MODEL_ASSESSMENT_RUNTIMESETTINGS);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    Mono<String> policyGroups = policyHelper.getPolicyGroupFromProductModelConfig(productId,
        productVersion);

    Mono<AssessmentTypePayload> runtimeSettings = policyGroups.flatMap(
        policyGroupString -> policyHelper.getAssessmentRuntimeSettingsResponse(policyGroupString));

    return setJsonResponse(runtimeSettings, HttpStatus.OK);
  }

  /**
   * Get Product Assessment RunTime Settings.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> getProductAssessmentRunTimeSettings(
      ServiceHandlerContext context) {
    logger.debug(LoggingConstants.GET_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    Mono<String> policyGroups = policyHelper.getPolicyGroupFromConfig(productId, productVersion);

    Mono<AssessmentTypePayload> runtimeSettings = policyGroups.flatMap(
        policyGroupString -> policyHelper.getAssessmentRuntimeSettingsResponse(policyGroupString));

    return setJsonResponse(runtimeSettings, HttpStatus.OK);
  }

  /**
   * Creates the product model learning aids.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createProductModelLearningAids(
      ServiceHandlerContext context) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.CREATE_PRODUCT_MODEL_LEARNING_AIDS);
    String id = context.getParameter(CmsConstants.ID);
    logger.debug(LoggingConstants.FETCHING_REQUEST_PARAM, CmsConstants.ID, id);
    String version = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.FETCHING_REQUEST_PARAM, CmsConstants.VERSION, version);
    return postLearningAids(policyHelper.getPolicyGroupFromProductModelConfig(id, version),
        context);
  }

  /**
   * Creates the product learning aids.
   *
   * @param context
   *          the context
   * @return mono
   */
  public Mono<ServiceHandlerResponse> createProductLearningAids(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.RENAME_LEARNING_AIDS_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    return postLearningAids(policyHelper.getPolicyGroupFromConfig(productId, productVersion),
        context);
  }

  /**
   * Gets the resolved policies.
   *
   * @param context
   *          the context
   * @return the resolved policies
   */
  public Mono<ServiceHandlerResponse> getProductLearningAids(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.GET_POLICIES_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.GET_PRODUCT_POLICIES, productId, productVersion);

    /* Get learning Aids */
    return fetchPolicies(policyHelper.getPolicyGroupFromConfig(productId, productVersion),
        ladBaseUrl, AssetClass.LEARNING_AIDLIST_POLICY.value(), CmsConstants.LEARNING_AIDS_TYPES);
  }

  /**
   * Gets the product model learning Aids.
   *
   * @param context
   *          the context
   * @return the product model learning Aids
   */
  public Mono<ServiceHandlerResponse> getProductModelLearningAids(ServiceHandlerContext context) {

    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    logger.debug(LoggingConstants.GET_PRODUCT_LEARNING_AIDS, productId, productVersion);

    /* Get learning Aids */
    return fetchPolicies(
        policyHelper.getPolicyGroupFromProductModelConfig(productId, productVersion), ladBaseUrl,
        AssetClass.LEARNING_AIDLIST_POLICY.value(), CmsConstants.LEARNING_AIDS_TYPES);
  }

  /**
   * Fetch policies.
   * 
   * @param policyGroupString
   * @param serviceUrl
   * @param assetClass
   * @param policyType
   * @return
   */
  private Mono<ServiceHandlerResponse> fetchPolicies(Mono<String> policyGroupString,
      String serviceUrl, String assetClass, String policyType) {
    Mono<Map<String, AssetInlineResource>> policyResponse = policyGroupString
        .flatMap(policyGroup -> policyHelper.getPolicy(serviceUrl,
            UriEnum.URI_GET_RESOLVED_POLICIES, assetClass, policyGroup))
        .map(policy -> constructPolicyResponse(policy, policyType));
    return setJsonResponse(policyResponse, HttpStatus.OK);
  }

  /**
   * Post learning Aids.
   * 
   * @param policyGroups
   * @param context
   * @return mono
   */
  @SuppressWarnings("unchecked")
  private Mono<ServiceHandlerResponse> postLearningAids(Mono<String> policyGroups,
      ServiceHandlerContext context) {
    Mono<GLPLearningPolicy> policyResponse = policyGroups
        .flatMap(group -> context.getPayload(Map.class)
            .flatMap(payload -> policyHelper.postLearningAids(payload, learningAidsLmLad, group)));
    return setJsonResponse(policyResponse, HttpStatus.CREATED);
  }
}
