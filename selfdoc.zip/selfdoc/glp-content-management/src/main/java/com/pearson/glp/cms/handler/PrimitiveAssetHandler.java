/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import javax.validation.groups.Default;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetPayload;
import com.pearson.glp.cms.dto.learningasset.request.AssetVersionRequest;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class PrimitiveAssetHandler.
 */
@Component
public class PrimitiveAssetHandler extends BaseHandler {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(PrimitiveAssetHandler.class);

  /**
   * Instantiates a new primitive asset handler.
   */
  public PrimitiveAssetHandler() {
    super();
  }

  /**
   * Gets the narratives versions.
   *
   * @param actionContext
   *          the action context
   * @return the narratives versions
   */
  public Mono<ServiceHandlerResponse> getNarrativesVersions(ServiceHandlerContext actionContext) {
    LOGGER.debug("getNarrativesVersions Calling {}", UriEnum.URI_NARRATIVE_VERSIONS);
    String narrativeId = actionContext.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_NARRATIVE_VERSIONS, narrativeId);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(actionContext),
        LearningAssetVersions.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Adds the narratives versions.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> addNarrativesVersions(ServiceHandlerContext context) {
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_NARRATIVE_VERSIONS,
        context.getParameter("id"));
    LOGGER.debug("addNarrativesVersions Calling {}", serviceUrl);
    Mono<AssetWithStatus> responseMono = context.getPayload(AssetVersionRequest.class)
        .flatMap(requestBody -> iscSyncClient.postObject(serviceUrl, prepareHeaders(context),
            requestBody, AssetWithStatus.class, IscSyncResponseFormat.RAW));
    return setJsonResponse(responseMono, HttpStatus.CREATED);
  }

  /**
   * Gets the narrative by id.
   *
   * @param context
   *          the context
   * @return the narrative by id
   */
  public Mono<ServiceHandlerResponse> getNarrativeById(ServiceHandlerContext context) {
    String id = context.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_NARRATIVE_BY_ID, id);
    LOGGER.debug(LoggingConstants.GET_NARRATIVE_BYID_LOG, url, id);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the narrative by id and version.
   *
   * @param actionContext
   *          the action context
   * @return the narratives versions
   */
  public Mono<ServiceHandlerResponse> getNarrativesByIdAndVersion(
      ServiceHandlerContext actionContext) {
    String id = actionContext.getParameter(CmsConstants.ID);
    String version = actionContext.getParameter(CmsConstants.VER);
    LOGGER.debug("getSpecificNarrativesByVersion Calling {}",
        UriEnum.URI_GET_NARRATIVE_SPECIFIC_VERSION);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_NARRATIVE_SPECIFIC_VERSION, id,
        version);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Get narratives.
   *
   * @param context
   *          the context
   * @return the narratives
   */
  public Mono<ServiceHandlerResponse> getNarratives(ServiceHandlerContext context) {
    LOGGER.debug("getNarratives Calling {}", UriEnum.URI_NARRATIVES);
    return setJsonResponse(
        iscSyncClient.getObject(CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_NARRATIVES),
            prepareHeaders(context), BulkAssets.class, IscSyncResponseFormat.RAW),
        HttpStatus.OK);
  }

  /**
   * Adds the narratives.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> addNarratives(ServiceHandlerContext context) {
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_NARRATIVES);
    LOGGER.debug("Calling addNarratives {}", UriEnum.URI_NARRATIVES);
    Flux<AssetPayload> requestFlux = context.getFluxPayloadCustom(AssetPayload.class)
        .map(this::marshallAssetPayloadWithError);
    Flux<AssetWithStatus> responseFlux = Flux.from(iscSyncClient.postObjects(serviceUrl,
        prepareHeaders(context), requestFlux, AssetPayload.class, AssetWithStatus.class));
    String contentType = CommonUtils.getContentType(context);
    return setJsonFluxResponse(responseFlux, HttpStatus.MULTI_STATUS, contentType);
  }

  /**
   * Gets the assessment items.
   *
   * @param actionContext
   *          the action context
   * @return the assessment items.
   */
  public Mono<ServiceHandlerResponse> getAssessmentItems(ServiceHandlerContext actionContext) {
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_ASSESSMENT_ITEMS);
    Mono<String> queryParam = CommonUtils.getQueryParameter(actionContext, serviceUrl);
    return setJsonResponse(queryParam.flatMap(url -> iscSyncClient.getObject(url,
        prepareHeaders(actionContext), BulkAssets.class, IscSyncResponseFormat.RAW)),
        HttpStatus.OK);
  }

  /**
   * Gets the assessment item by id.
   *
   * @param actionContext
   *          the action context
   * @return the assessment item by id
   */
  public Mono<ServiceHandlerResponse> getAssessmentItemById(ServiceHandlerContext actionContext) {

    String id = actionContext.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_ASSESSMENT_ITEM_BY_ID, id);
    LOGGER.debug(LoggingConstants.GET_ASSESSMENT_BYID_LOG, url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the assessment Item By Id And Version.
   *
   * @param actionContext
   *          the action context
   * @return assessment Item By Id And Version
   */
  public Mono<ServiceHandlerResponse> getAssessmentItemByIdAndVersion(
      ServiceHandlerContext actionContext) {

    String id = actionContext.getParameter(CmsConstants.ID);
    String version = actionContext.getParameter(CmsConstants.VER);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_ASSESSMENT_ITEM_SPECIFIC_VERSION,
        id, version);
    LOGGER.debug("getSpecificAssessmentItemByVersion Calling {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Adds the assessment items.
   *
   * @param context
   *          the server request
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> addAssessmentItems(ServiceHandlerContext context) {
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_ASSESSMENT_ITEMS);
    LOGGER.debug(LoggingConstants.ADD_ASSESSMENT_ITEM_LOG_MESSAGE, UriEnum.URI_ASSESSMENT_ITEMS);
    Flux<AssetPayload> requestFlux = context.getFluxPayloadWithGroupSupport(AssetPayload.class,
        GroupAssessmentItemResource.class, Default.class).map(this::marshallAssetPayloadWithError);
    Flux<AssetWithStatus> responseFlux = Flux.from(iscSyncClient.postObjects(serviceUrl,
        prepareHeaders(context), requestFlux, AssetPayload.class, AssetWithStatus.class));
    String contentType = CommonUtils.getContentType(context);
    return setJsonFluxResponse(responseFlux, HttpStatus.MULTI_STATUS, contentType);
  }

  /**
   * Adds the learning app items.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> addLearningAppItems(ServiceHandlerContext context) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION, LoggingConstants.ADD_LEARNING_APP_ITEMS);
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_LEARNING_APP_ITEMS);
    LOGGER.debug(LoggingConstants.ADD_LEARNING_APP_ITEM_LOG_MESSAGE, serviceUrl);
    Flux<AssetPayload> requestFlux = context.getFluxPayloadCustom(AssetPayload.class)
        .map(this::marshallAssetPayloadWithError);
    Flux<AssetWithStatus> responseFlux = Flux.from(iscSyncClient.postObjects(serviceUrl,
        prepareHeaders(context), requestFlux, AssetPayload.class, AssetWithStatus.class));
    String contentType = CommonUtils.getContentType(context);
    return setJsonFluxResponse(responseFlux, HttpStatus.MULTI_STATUS, contentType);
  }

  /**
   * Gets the learning app items by id.
   *
   * @param actionContext
   *          the action context
   * @return the learning app items by id
   */
  public Mono<ServiceHandlerResponse> getLearningAppItemsById(ServiceHandlerContext actionContext) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION, LoggingConstants.GET_LEARNING_APP_ITEMS_BY_ID);
    String id = actionContext.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_LEARNING_APP_ITEM_BY_ID, id);
    LOGGER.debug(LoggingConstants.GET_LEARNINGAPP_BYID_LOG, url);
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.GET_LEARNING_APP_ITEMS_BY_ID);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the learning app items by id and version.
   *
   * @param actionContext
   *          the action context
   * @return the learning app items by id and version
   */
  public Mono<ServiceHandlerResponse> getLearningAppItemsByIdAndVersion(
      ServiceHandlerContext actionContext) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.GET_LEARNING_APP_ITEMS_BY_ID_AND_VERSION);
    String id = actionContext.getParameter(CmsConstants.ID);
    String version = actionContext.getParameter(CmsConstants.VER);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_LEARNING_APP_ITEM_SPECIFIC_VERSION,
        id, version);
    LOGGER.debug(LoggingConstants.GET_LEARNING_APP_BY_ID_AND_VERSION, url);
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.GET_LEARNING_APP_ITEMS_BY_ID_AND_VERSION);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(actionContext),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }
}