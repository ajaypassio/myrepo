/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.beanvalidation.groups.GroupNonPrimitiveLA;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.constants.RoutingKeyConstants;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.learningasset.request.ProductPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductStateTransitionPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductStatusPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductVersionRequest;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.dto.learningasset.response.ProductStateTransition;
import com.pearson.glp.cms.dto.learningpolicy.request.CategoryWeightsPayload;
import com.pearson.glp.cms.dto.learningpolicy.request.PolicyPayload;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.products.ConfigurationCompleteEventDetails;
import com.pearson.glp.cms.dto.products.ConfigurationCompleteStatus;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.enums.QueryParamKeys;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.helper.EngagementPolicyHelper;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;

import reactor.core.publisher.Mono;

/**
 * The Class Product Handlers.
 *
 * @author dinesh.kumar1
 *
 */
@Component
public class ProductHandler extends BaseHandler {

  /** The logger. */
  private Logger logger = LoggerFactory.getLogger(ProductHandler.class);

  /** The policy helper. */
  @Autowired
  private EngagementPolicyHelper policyHelper;

  /**
   * Instantiates a new product handler.
   */
  public ProductHandler() {
    super();
  }

  /**
   * Gets the product.
   *
   * @param context
   *          the context
   * @return the Product
   * 
   */
  public Mono<ServiceHandlerResponse> getProduct(ServiceHandlerContext context) {

    logger.debug("Calling getProduct {}", RoutingKeyConstants.GET_PRODUCT);
    Mono<String> serviceUrl = Mono.just(CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCTS));
    if (!context.getAllParameters().isEmpty()) {
      serviceUrl = serviceUrl.flatMap(url -> getProductsUrlWithQuery(context, url));
    }
    return setJsonResponse(serviceUrl.flatMap(url -> iscSyncClient.getObject(url,
        prepareHeaders(context), BulkAssets.class, IscSyncResponseFormat.RAW)), HttpStatus.OK);
  }

  /**
   * Gets the products url with query.
   *
   * @param context
   *          the context
   * @param serviceUrl
   *          the service url
   * @return the products url with query
   */
  private Mono<String> getProductsUrlWithQuery(ServiceHandlerContext context, String serviceUrl) {
    Optional<String> id = context.getOptionalParameter(QueryParamKeys.ID.value());
    Optional<String> contentMetadataId = context
        .getOptionalParameter(QueryParamKeys.CONTENTMETADATA_ID.value());
    Optional<String> tags = context.getOptionalParameter(QueryParamKeys.TAGS.value());
    if (id.isPresent()) {
      serviceUrl = CommonUtils.addQueryParams(serviceUrl, QueryParamKeys.ID.value(), id.get());
    } else if (contentMetadataId.isPresent()) {
      serviceUrl = CommonUtils.addQueryParams(serviceUrl, QueryParamKeys.CONTENTMETADATA_ID.value(),
          contentMetadataId.get());
    } else if (tags.isPresent()) {
      serviceUrl = CommonUtils.addQueryParams(serviceUrl, QueryParamKeys.TAGS.value(), tags.get());
    } else {
      return Mono
          .error(new CmsException(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_QUERY));
    }
    return Mono.just(serviceUrl);
  }

  /**
   * Gets the product by id and version.
   *
   * @param context
   *          the context
   * @return the product by id and version
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductByIdAndVersion(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.FETCHING_PRODUCT_BY_VERSION);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION, id,
        version);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(context),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the product assessment type list.
   *
   * @param context
   *          the context
   * @return the product assessment type list
   */
  public Mono<ServiceHandlerResponse> getProductAssessmentTypes(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.FETCHING_PRODUCT_ASSESSMENT_TYPES);
    GLPLearningAsset getAsssessmentTypes = CommonUtils.convertJsonStringToObject(
        CmsConstants.GET_PRODUCT_ASSESSMENT_TYPES_RESPONSE, GLPLearningAsset.class);
    return JsonPayloadServiceResponse.ok().setPayload(getAsssessmentTypes);

  }

  /**
   * Gets the product state transition.
   *
   * @param context
   *          the context
   * @return the product state transition
   */
  public Mono<ServiceHandlerResponse> getProductStateTransition(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.FETCHING_PRODUCT_STATE_TRANSITION);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_STATE_TRANSITION, id,
        version);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(context),
        ProductStateTransition.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the products by id.
   *
   * @param context
   *          the context
   * @return the products by id
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductById(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.FETCHING_PRODUCT_BY_ID);
    String id = context.getParameter(CmsConstants.ID);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_PRODUCT_BY_ID, id);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(context),
        GLPLearningAsset.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the product versions.
   *
   * @param context
   *          the context
   * @return the product versions
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductVersions(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.GETTING_PRODUCT_VERSIONS);
    String id = context.getParameter("id");
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_VERSIONS, id);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(context),
        LearningAssetVersions.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the product status by Id and Version.
   *
   * @param context
   *          the context
   * @return the product status
   * @throws ServiceException
   *           the service exception
   */

  public Mono<ServiceHandlerResponse> getProductStatus(ServiceHandlerContext context) {
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    logger.debug(LoggingConstants.GETTING_PRODUCT_STATUS, id, version);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_STATUS, id, version);
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(context),
        ProductStateTransition.class, IscSyncResponseFormat.RAW), HttpStatus.OK);

  }

  /**
   * Post product.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProduct(ServiceHandlerContext context) {
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCTS);
    logger.debug(LoggingConstants.CREATE_PRODUCT_LOG_MESSAGE, serviceUrl);
    return validator
        .validateRequest(
            reqBodyMono -> reqBodyMono
                .flatMap(
                    requestBody -> setJsonResponse(
                        iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                            GLPLearningAsset.class, IscSyncResponseFormat.RAW),
                        HttpStatus.CREATED)),
            context, ProductPayload.class, Optional.empty(),
            Optional.of(GroupNonPrimitiveLA.class));
  }

  /**
   * Post product versions.
   *
   * @param context
   *          the context
   * @return the mono
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> postProductVersions(ServiceHandlerContext context) {
    String assetId = context.getParameter(CmsConstants.ID);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_VERSIONS, assetId);
    logger.debug(LoggingConstants.CREATE_PRODUCT_VERSION_LOG_MESSAGE, serviceUrl);
    return validator
        .validateRequest(
            reqBodyMono -> reqBodyMono
                .flatMap(
                    requestBody -> setJsonResponse(
                        iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                            GLPLearningAsset.class, IscSyncResponseFormat.RAW),
                        HttpStatus.CREATED)),
            context, ProductVersionRequest.class, Optional.empty(),
            Optional.of(GroupNonPrimitiveLA.class));
  }

  /**
   * Post product state transition.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProductStateTransition(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.POST_PRODUCT_STATE_TRANSITION_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VER);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_STATE_TRANSITION,
        productId, productVersion);
    logger.debug(LoggingConstants.CALLING_URL, serviceUrl);
    return this.validator
        .validateRequest(
            requestBodyMono -> requestBodyMono
                .flatMap(requestBody -> setJsonResponse(
                    iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                        ProductStateTransition.class, IscSyncResponseFormat.RAW),
                    HttpStatus.CREATED)),
            context, ProductStateTransitionPayload.class, Optional.empty(), Optional.empty());
  }

  /**
   * Post product map assessment type.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> mapProductAssessmentTypes(ServiceHandlerContext context) {

    logger.debug(LoggingConstants.POST_MAP_ASSESSMENT_TYPE_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    Mono<Groups> policyGroups = policyHelper.getPolicyGroupFromConfig(productId, productVersion)
        .map(Groups::new);

    Mono<GLPLearningPolicy> policyResponse = policyGroups
        .flatMap(group -> context.getPayload(PolicyPayload.class)
            .flatMap(payload -> policyHelper.createDeliveryPolicy(payload,
                AssetClass.DELIVERY_MAP_ASSESSMENTS, assessmentTypeLmLad, "ASSESSMENTTYPELIST",
                group)));
    return setJsonResponse(policyResponse, HttpStatus.CREATED);
  }

  /**
   * Put product status.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> putProductStatus(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.PUT_PRODUCT_STATUS_LOG);
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VER);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_STATUS, productId,
        productVersion);
    logger.debug(LoggingConstants.CALLING_URL, serviceUrl);
    return this.validator
        .validateRequest(
            requestBodyMono -> requestBodyMono
                .flatMap(
                    requestBody -> setJsonResponse(
                        iscSyncClient.putObject(serviceUrl, prepareHeaders(context), requestBody,
                            ProductStateTransition.class, IscSyncResponseFormat.RAW),
                        HttpStatus.OK)),
            context, ProductStatusPayload.class, Optional.empty(), Optional.empty());
  }

  /**
   * Gets the product asset types.
   *
   * @param context
   *          the context
   * @return the product asset types
   */
  public Mono<ServiceHandlerResponse> getProductAssetTypes(ServiceHandlerContext context) {
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_PRODUCT_ASSET_TYPES,
        productId, productVersion);
    logger.debug(LoggingConstants.GET_PRODUCT_ASSET_TYPES_LOG, serviceUrl);
    Optional<String> assetType = context.getOptionalParameter(CmsConstants.ASSET_TYPE);
    if (context.getAllParameters().size() > 2) {
      if (assetType.isPresent()) {
        serviceUrl = CommonUtils.addQueryParams(serviceUrl, CmsConstants.ASSET_TYPE,
            assetType.get());
      } else {
        return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST).setPayload(
            new CustomErrorMessage(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_QUERY));
      }
    }
    return setJsonResponse(iscSyncClient.getObject(serviceUrl, prepareHeaders(context),
        ProductAssetTypes.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the product assessment type by id and version.
   *
   * @param context
   *          the context
   * @return the product assessment type by id and version
   * @throws ServiceException
   *           the service exception
   */
  public Mono<ServiceHandlerResponse> getProductAssessmentTypesPolicy(
      ServiceHandlerContext context) {
    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VER);
    logger.debug(LoggingConstants.GET_PRODUCT_ASSESSMENT_TYPE_BY_ID_AND_VERSION, productId,
        productVersion);

    /* Fetching product policy group for specific product id and version */
    Mono<String> policyGroupString = policyHelper.getPolicyGroupFromConfig(productId,
        productVersion);

    /* Get delivery renameAssessmentTypes policy */
    Mono<GLPLearningPolicy> policyResponse = policyGroupString.flatMap(
        policyGroup -> policyHelper.getPolicy(ladBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
            AssetClass.DELIVERY_MAP_ASSESSMENTS.value(), policyGroup));
    return setJsonResponse(policyResponse, HttpStatus.OK);
  }

  /**
   * Post product category weights.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProductCategoryWeights(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.POST_PRODUCT_CATEGORY_WEIGHTS_LOG);
    return validator.validateRequest(
        requestBodyMono -> requestBodyMono
            .flatMap(requestBody -> postPolicyGroups(context.getParameter(CmsConstants.ID),
                context.getParameter(CmsConstants.VERSION), requestBody)),
        context, CategoryWeightsPayload.class, Optional.empty(), Optional.empty());
  }

  /**
   * Post policy groups.
   *
   * @param productId
   *          the product id
   * @param productVersion
   *          the product version
   * @param weightsPayload
   *          the weights payload
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> postPolicyGroups(String productId, String productVersion,
      CategoryWeightsPayload weightsPayload) {
    // Check that category weights is equal to 100 or not
    if (policyHelper.validateCategoryWeights(weightsPayload)) {
      // Get policy group from the Product
      Mono<String> policyGroups = policyHelper.getPolicyGroupFromConfig(productId, productVersion);
      // Get resolved policy at product level
      Mono<GLPLearningPolicy> resolvedPolicyResponse = policyGroups
          .flatMap(policyGroupString -> policyHelper.getResolvedPolicyResponse(policyGroupString));
      // post product policy group
      Mono<GLPLearningPolicy> policyResponse = resolvedPolicyResponse
          .flatMap(resolvedPolicy -> policyHelper.createExperienceEvaluationPolicy(resolvedPolicy,
              policyGroups, weightsPayload))
          .flatMap(policy -> {
            policy.getLinks().get(CmsConstants.SELF_NODE).setHref(CommonUtils
                .modifiedSelfLink(productId, productVersion, UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS));
            return Mono.just(policy);
          });
      return setJsonResponse(policyResponse, HttpStatus.CREATED);
    } else {
      return Mono.error(new CmsException(HttpStatus.BAD_REQUEST.value(),
          ErrorConstants.INCORRECT_CATEGORY_WEIGHTAGE));
    }
  }

  /**
   * Post config status.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProductConfigStatus(ServiceHandlerContext context) {
    logger.debug(LoggingConstants.POST_PRODUCT_CONFIG_STATUS_LOG);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_POST_CONFIG_STATUS, id, version);
    logger.debug(LoggingConstants.POST_CONFIG_STATUS_URL, serviceUrl);
    Mono<ConfigurationCompleteStatus> runTimeSetting = context
        .getPayload(ConfigurationCompleteStatus.class);
    Mono<ConfigurationCompleteEventDetails> response = runTimeSetting
        .flatMap(payload -> iscSyncClient.postObject(serviceUrl, prepareHeaders(context), payload,
            ConfigurationCompleteEventDetails.class, IscSyncResponseFormat.RAW));
    return setJsonResponse(response, HttpStatus.CREATED);
  }

}
