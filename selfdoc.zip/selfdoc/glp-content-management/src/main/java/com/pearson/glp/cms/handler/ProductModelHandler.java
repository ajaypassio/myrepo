/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.pearson.glp.cms.beanvalidation.groups.GroupProductModel;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.learningmodel.request.AssetModelPayload;
import com.pearson.glp.cms.dto.learningmodel.response.BulkProductModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.dto.learningpolicy.request.CategoryWeightsPayload;
import com.pearson.glp.cms.dto.learningpolicy.response.CategoryWeightsResponse;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.learningpolicy.response.GradeBookCategoryPolicy;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.enums.ProductModelCollectionDetails;
import com.pearson.glp.cms.enums.ProductModelQueryParameter;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.helper.EngagementPolicyHelper;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;

import reactor.core.publisher.Mono;

/**
 * The Class ProductModelHandler.
 */
@Component
public class ProductModelHandler extends BaseHandler {

  /**
   * The logger.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(ProductModelHandler.class);

  /**
   * The policy helper.
   */
  @Autowired
  private EngagementPolicyHelper policyHelper;

  /**
   * Instantiates a new product model handler.
   */
  public ProductModelHandler() {
    super();
  }

  /**
   * Gets the product models.
   *
   * @param context
   *          the action context
   * @return the product models
   */
  public Mono<ServiceHandlerResponse> getProductModels(ServiceHandlerContext context) {
    LOGGER.debug("getProductModels Calling {}", UriEnum.URI_PRODUCT_MODELS);
    MultiValueMap<String, String> parameters = context.getAllParameters();
    List<String> params = ProductModelQueryParameter.getEnumValues();
    if (parameters.keySet().stream().anyMatch(param -> !params.contains(param))) {
      LOGGER.error(LoggingConstants.INVALID_QUERY_PARAM, parameters.keySet().toString());
      return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST).setPayload(
          new CustomErrorMessage(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_QUERY));
    }
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_MODELS);
    String collectionDetails = parameters.getFirst(CmsConstants.COLLECTION_DETAILS);
    LOGGER.debug("fetching query param {}={}", CmsConstants.COLLECTION_DETAILS, collectionDetails);
    if (null != collectionDetails) {
      if (ProductModelCollectionDetails.getEnumValues().contains(collectionDetails)) {
        url = CommonUtils.addQueryParams(url, CmsConstants.COLLECTION_DETAILS, collectionDetails);
      } else {
        LOGGER.error(LoggingConstants.INVALID_QUERY_PARAM, collectionDetails);
        return JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST).setPayload(
            new CustomErrorMessage(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_QUERY));
      }
    }
    LOGGER.debug("Calling url for getProductModels {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        BulkProductModels.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Creates the product model.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createProductModel(ServiceHandlerContext context) {
    LOGGER.debug("createProductModel Calling {}", UriEnum.URI_PRODUCT_MODELS);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_MODELS);
    LOGGER.debug("Calling url for createProductModel {}", serviceUrl);
    return validator.validateRequest(
        reqBodyMono -> reqBodyMono.flatMap(requestBody -> setJsonResponse(
            iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                GLPAssetModel.class, IscSyncResponseFormat.RAW),
            HttpStatus.CREATED)),
        context, AssetModelPayload.class, Optional.of(CmsConstants.PRODUCT),
        Optional.of(GroupProductModel.class));
  }

  /**
   * Create the productModels versions.
   *
   * @param context
   *          the action context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> createProductModelsVersions(ServiceHandlerContext context) {
    String id = context.getParameter(CmsConstants.ID);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_MODEL_VERSIONS, id);

    LOGGER.debug("createProductModelsVersions Calling {}", serviceUrl);
    return validator.validateRequest(
        reqBodyMono -> reqBodyMono.flatMap(requestBody -> setJsonResponse(
            iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                GLPAssetModel.class, IscSyncResponseFormat.RAW),
            HttpStatus.CREATED)),
        context, AssetModelPayload.class, Optional.of(CmsConstants.PRODUCT),
        Optional.of(GroupProductModel.class));
  }

  /**
   * Gets the productModel versions.
   *
   * @param context
   *          the action context
   * @return the productModels versions
   */

  public Mono<ServiceHandlerResponse> getProductModelsVersions(ServiceHandlerContext context) {

    LOGGER.debug("getProductModelsVersions Calling {}", UriEnum.URI_PRODUCT_MODEL_VERSIONS);
    String id = context.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_MODEL_VERSIONS, id);
    LOGGER.debug("Calling url for getProductModelsVersions {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        BulkProductModels.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the ProductModel by id.
   *
   * @param context
   *          the context
   * @return the ProductModel by id
   */
  public Mono<ServiceHandlerResponse> getProductModelById(ServiceHandlerContext context) {
    String id = context.getParameter(CmsConstants.ID);
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_PRODUCT_MODEL_BY_ID, id);

    LOGGER.debug("getProductModelById calling {} with id {}", url, id);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        GLPAssetModel.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the specific ProductModel by version.
   *
   * @param context
   *          the action context
   * @return the ProductModel by versions
   */
  public Mono<ServiceHandlerResponse> getProductModelByVersionId(ServiceHandlerContext context) {
    LOGGER.debug("getProductModelByVersionId Calling {}",
        UriEnum.URI_GET_PRODUCT_MODEL_SPECIFIC_VERSION);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    String url = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_PRODUCT_MODEL_SPECIFIC_VERSION, id,
        version);
    LOGGER.debug("Calling url for getProductModelByVersionId {}", url);
    return setJsonResponse(iscSyncClient.getObject(url, prepareHeaders(context),
        GLPAssetModel.class, IscSyncResponseFormat.RAW), HttpStatus.OK);
  }

  /**
   * Gets the resolved policies.
   *
   * @param context
   *          the context
   * @param assetClass
   *          the asset class
   * @return the resolved policies
   */
  public Mono<ServiceHandlerResponse> getResolvedPolicies(ServiceHandlerContext context,
      String assetClass) {

    String productId = context.getParameter(CmsConstants.ID);
    String productVersion = context.getParameter(CmsConstants.VERSION);
    LOGGER.debug(LoggingConstants.GET_PRODUCT_LEARNING_AIDS, productId, productVersion);
    /*
     * Fetching product policy group for specific product model id and version
     */
    Mono<String> policyGroupString = policyHelper.getPolicyGroupFromProductModelConfig(productId,
        productVersion);
    if (AssetClass.GRADE_BOOK_CATEGORY_POLICY.value().equals(assetClass)) {
      return setJsonResponse(policyGroupString.flatMap(policyGroup -> policyHelper
          .getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES, assetClass, policyGroup)
          .map(this::translateToGetCategoryWeightsResponse)), HttpStatus.OK);

    } else {
      return setJsonResponse(policyGroupString.flatMap(policyGroup -> policyHelper
          .getPolicy(ladBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES, assetClass, policyGroup)),
          HttpStatus.OK);
    }
  }

  /**
   * Translate to get category weights response.
   *
   * @param policy
   *          the policy
   * @return the category weights response
   */
  private CategoryWeightsResponse translateToGetCategoryWeightsResponse(GLPLearningPolicy policy) {
    GradeBookCategoryPolicy gradeBookCategoryPolicyData = new GradeBookCategoryPolicy();
    gradeBookCategoryPolicyData
        .setData(policy.getResources().get(CmsConstants.GRADEBOOKCATEGORYPOLICY).getData());
    CategoryWeightsResponse categories = new CategoryWeightsResponse();
    categories.setGradebookCategoryPolicy(gradeBookCategoryPolicyData);
    categories.setStatus(policy.getStatus());
    return categories;
  }

  /**
   * Post product model category weights.
   *
   * @param context
   *          the context
   * @param optionalGroup
   *          the optional group
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postProductModelCategoryWeights(ServiceHandlerContext context,
      Optional<Class<?>> optionalGroup) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.Post_ProductModel_Category_Weights);
    return validator.validateRequest(
        requestBodyMono -> requestBodyMono
            .flatMap(requestBody -> postPolicyGroups(context.getParameter(CmsConstants.ID),
                context.getParameter(CmsConstants.VER), requestBody)),
        context, CategoryWeightsPayload.class, Optional.empty(), optionalGroup);
  }

  /**
   * Post policy groups.
   *
   * @param productId
   *          the product id
   * @param productVersion
   *          the product version
   * @param categoryWeightsPayload
   *          the category weights payload
   * @return the mono
   */
  private Mono<ServiceHandlerResponse> postPolicyGroups(String productId, String productVersion,
      CategoryWeightsPayload categoryWeightsPayload) {
    Mono<String> policyGroup = policyHelper.getPolicyGroupFromProductModelConfig(productId,
        productVersion);
    Mono<GLPLearningPolicy> resolvedPolicyResponse = policyGroup
        .flatMap(policyGroupString -> policyHelper.getResolvedPolicyResponse(policyGroupString));
    Mono<GLPLearningPolicy> policyResponse = resolvedPolicyResponse
        .flatMap(resolvedPolicy -> policyHelper.createExperienceEvaluationPolicy(resolvedPolicy,
            policyGroup, categoryWeightsPayload))
        .flatMap(policy -> {
          policy.getLinks().get(CmsConstants.SELF_NODE).setHref(CommonUtils.modifiedSelfLink(
              productId, productVersion, UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS));
          return Mono.just(policy);
        });
    return setJsonResponse(policyResponse, HttpStatus.CREATED);
  }

}
