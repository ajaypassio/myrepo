/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.beanvalidation.groups.GroupNarrativeResources;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.resource.request.ResourceVersionRequest;
import com.pearson.glp.cms.dto.resource.request.ResourcesRequest;
import com.pearson.glp.cms.dto.resource.response.BulkResources;
import com.pearson.glp.cms.dto.resource.response.GLPResource;
import com.pearson.glp.cms.dto.resource.response.ResourceVersions;
import com.pearson.glp.cms.dto.resource.response.ResourceWithStatus;
import com.pearson.glp.cms.enums.CategoryEnum;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class ResourceHandler.
 */
@Component
public class ResourceHandler extends BaseHandler {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ResourceHandler.class);

  /**
   * Instantiates a new resource handler.
   */
  public ResourceHandler() {
    super();
  }

  /**
   * Creates the resources.
   *
   * @param <T>
   *          the generic type
   * @param serverRequest
   *          the server request
   * @param optionalGroupClass
   *          the optional group class
   * @return the mono
   */
  public Mono<ServerResponse> createResources(ServerRequest serverRequest,
      Optional<Class<?>> optionalGroupClass) {
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_RESOURCES);
    LOGGER.debug("Calling createResources {}", UriEnum.URI_RESOURCES);
    return validator.validatePostRequest(requestBodyMono -> {
      Flux<ResourceWithStatus> resourcesFlux = iscFluxClient.postObjects(serviceUrl,
          requestBodyMono, ResourcesRequest.class, ResourceWithStatus.class);
      return checkStreamResponse(resourcesFlux, ResourceWithStatus.class, serverRequest);
    }, serverRequest, ResourcesRequest.class, optionalGroupClass);
  }

  /**
   * Gets the resources.
   *
   * @param context
   *          the context
   * @return the resources
   */
  public Mono<ServiceHandlerResponse> getResources(ServiceHandlerContext context) {
    LOGGER.debug("Calling getResources {}", UriEnum.URI_RESOURCES);
    return setJsonResponse(
        iscSyncClient.getObject(CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_RESOURCES),
            prepareHeaders(context), BulkResources.class, IscSyncResponseFormat.RAW),
        HttpStatus.OK);
  }

  /**
   * Post resource version.
   *
   * @param context
   *          the context
   * @return the mono
   */
  public Mono<ServiceHandlerResponse> postResourceVersion(ServiceHandlerContext context) {
    String serviceUrl = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_RESOURCE_VERSIONS,
        context.getParameter("id"));
    LOGGER.debug("postResourceNewVersion Calling {}", serviceUrl);
    return validator
        .validateRequest(
            requestBodyMono -> requestBodyMono
                .flatMap(
                    requestBody -> setJsonResponse(
                        iscSyncClient.postObject(serviceUrl, prepareHeaders(context), requestBody,
                            ResourceWithStatus.class, IscSyncResponseFormat.RAW),
                        HttpStatus.CREATED)),
            context, ResourceVersionRequest.class, Optional.empty(),
            Optional.of(GroupNarrativeResources.class));
  }

  /**
   * Gets the Specific version of resource.
   *
   * @param context
   *          the action context
   * @param requestedApi
   *          the is assessment API
   * @return the resources
   */
  public Mono<ServiceHandlerResponse> getSpecificVersionOfResource(ServiceHandlerContext context,
      String requestedApi) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.GET_SPECIFIC_VERSION_RESOURCE_METHOD);
    String id = context.getParameter(CmsConstants.ID);
    String version = context.getParameter(CmsConstants.VER);
    String url = CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_RESOURCE_SPECIFIC_VERSION, id,
        version);
    LOGGER.debug(LoggingConstants.RESOURCE_ID_AND_VERSION_LOGS, url, id, version);
    Mono<GLPResource> responseMono = iscSyncClient.getObject(url, prepareHeaders(context),
        GLPResource.class, IscSyncResponseFormat.RAW);
    LOGGER.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.GET_SPECIFIC_VERSION_RESOURCE_METHOD);
    return this.setJsonResponse(validateResourceCategory(responseMono, requestedApi),
        HttpStatus.OK);
  }

  /**
   * Gets the all version of resource.
   *
   * @param context
   *          the action context
   * @return the all version of resource
   */
  public Mono<ServiceHandlerResponse> getAllVersionOfResource(ServiceHandlerContext context) {
    String resourceId = context.getParameter(CmsConstants.ID);
    LOGGER.debug("getAllVersionOfResource Calling with resourceId : {} ", resourceId);
    return setJsonResponse(
        iscSyncClient.getObject(
            CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_RESOURCE_VERSIONS, resourceId),
            prepareHeaders(context), ResourceVersions.class, IscSyncResponseFormat.RAW),
        HttpStatus.OK);
  }

  /**
   * Gets the resource by id.
   *
   * @param context
   *          the context
   * @param requestedApi
   *          the is assessment API
   * @return the resource by id
   */
  public Mono<ServiceHandlerResponse> getResourceById(ServiceHandlerContext context,
      String requestedApi) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION, LoggingConstants.GET_RESOURCE_BY_ID_METHOD);
    String resourceId = context.getParameter(CmsConstants.ID);
    LOGGER.debug(LoggingConstants.RESOURCE_BY_ID_LOG, resourceId);
    Mono<GLPResource> responseMono = iscSyncClient.getObject(
        CommonUtils.getUrl(lapBaseUrl, UriEnum.URI_GET_RESOURCE_BY_ID, resourceId),
        prepareHeaders(context), GLPResource.class, IscSyncResponseFormat.RAW);
    return this.setJsonResponse(validateResourceCategory(responseMono, requestedApi),
        HttpStatus.OK);
  }

  /**
   * Check for not found response.
   *
   * @param responseMono
   *          the response mono
   * @param isAssessmentAPI
   *          the is assessment API
   * @return the mono
   */
  private Mono<GLPResource> validateResourceCategory(Mono<GLPResource> responseMono,
      String requestedApi) {
    LOGGER.debug(LoggingConstants.METHOD_INVOCATION, LoggingConstants.VALIDATE_RESOURCE_CATEGORY);
    return responseMono.flatMap(resource -> {
      String contentCategory = resource.getContent().getCategory();
      if ((requestedApi.matches(contentCategory))
          || (requestedApi.matches(CategoryEnum.NARRATIVE.getVal())
              && CategoryEnum.getNarrativeResourceEnumValues().contains(contentCategory))) {
        return Mono.just(resource);
      } else {
        return Mono.error(
            new CmsException(HttpStatus.NOT_FOUND.value(), ErrorConstants.MESSAGE_NOT_FOUND));
      }
    });
  }

}
