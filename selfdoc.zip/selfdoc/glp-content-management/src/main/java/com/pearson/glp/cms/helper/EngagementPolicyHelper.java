/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.helper;

import static com.pearson.glp.cms.constants.LoggingConstants.CREATING_DEFAULT_PRODUCT_POLICY_PAYLOAD;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_PRODUCT_MODEL_POLICY_FETCHED;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_PRODUCT_RUNTIME_POLICY_DELIVERY_ERROR;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_PRODUCT_RUNTIME_POLICY_EVALUATION_ERROR;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_PRODUCT_RUNTIME_POLICY_EXPERIENCE_ERROR;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_RUNTIME_POLICY_DELIVERY_SUCCESS;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_RUNTIME_POLICY_EVALUATION_SUCCESS;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_RUNTIME_POLICY_EXPERIENCE_SUCCESS;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_SCORING_POLICY_ERROR;
import static com.pearson.glp.cms.constants.LoggingConstants.DEFAULT_SCORING_POLICY_FETCHED;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.common.AssetInlineResource;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningpolicy.request.AssessmentType;
import com.pearson.glp.cms.dto.learningpolicy.request.AssessmentTypePayload;
import com.pearson.glp.cms.dto.learningpolicy.request.CategoryWeightsPayload;
import com.pearson.glp.cms.dto.learningpolicy.request.GradeBookCategoryPolicies;
import com.pearson.glp.cms.dto.learningpolicy.request.PolicyPayload;
import com.pearson.glp.cms.dto.learningpolicy.request.PolicyVersionPayload;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.learningpolicy.response.RuntimeSettingsResponse;
import com.pearson.glp.cms.dto.products.AssetClassType;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.enums.AssetType;
import com.pearson.glp.cms.enums.CategoryWeightStatus;
import com.pearson.glp.cms.enums.ResourceModel;
import com.pearson.glp.cms.enums.ResourceType;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.handler.BaseHandler;
import com.pearson.glp.cms.learningpolicy.predicate.LearningPolicyPredicates;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.cms.utils.ErrorUtils;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;

import reactor.core.publisher.Mono;
import reactor.util.function.Tuple3;

/**
 * The Class EngagementPolicyHelper.
 *
 * @author ajay.kumar8
 */
@Component
public class EngagementPolicyHelper extends BaseHandler {

  /** The logger. */
  private Logger logger = LoggerFactory.getLogger(EngagementPolicyHelper.class);

  /**
   * Instantiates a new EngagementPolicyHelper.
   */
  public EngagementPolicyHelper() {
    super();
  }

  @Autowired
  private PolicyTransformFactory scoringFactory;

  /**
   * Populate policy payload.
   * 
   * @param group
   *          the group
   * @param learningModel
   *          the learning model
   * @param assetClass
   *          the asset class
   * @param tags
   *          the tags
   * @param payload
   *          the payload
   *
   * @return the policy payload
   */
  public PolicyPayload populatePolicyPayload(Groups group, String learningModel, String assetClass,
      String tags, PolicyPayload payload) {
    logger.debug(LoggingConstants.POLICY_PAYLOAD_CREATION_LOG);
    payload.setAssetClass(assetClass);
    payload.setLearningModel(CommonUtils.createLearningModel(learningModel));
    payload.setGroups(group);
    payload.setTags(tags);
    return payload;
  }

  /**
   * Populate policy payload.
   *
   * @param group
   *          the group
   * @param learningModel
   *          the learning model
   * @param assetClass
   *          the asset class
   * @param runtimeSettings
   *          the runtime settings
   * @param resourceModel
   *          the resource model
   * @param resourceRef
   *          the resource ref
   * @param tag
   *          the tag
   * @return the policy payload
   */
  public PolicyPayload populatePolicyPayload(Groups group, String learningModel, String assetClass,
      Map<String, Object> runtimeSettings, String resourceModel, String resourceRef, String tag) {
    logger.debug(LoggingConstants.POLICY_PAYLOAD_CREATION_LOG);
    PolicyPayload payload = new PolicyPayload();
    LinkedHashMap<String, AssetInlineResource> resources = new LinkedHashMap<>();
    resources.put(resourceRef, createInlinedResource(runtimeSettings, resourceModel));
    payload.setResources(resources);
    payload.setResourcePlan(createRuntimeResourcePlan(resourceRef));
    return populatePolicyPayload(group, learningModel, assetClass, tag, payload);
  }

  /**
   * Gets the product configuration.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the product configuration
   */
  private Mono<Configuration> getProductConfiguration(String id, String version) {
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION, id,
        version);
    serviceUrl = CommonUtils.addQueryParams(serviceUrl, CmsConstants.FIELD_QUERY_PARAM_KEY,
        CmsConstants.FIELD_QUERY_PARAM_VALUE);
    logger.debug(LoggingConstants.CALLING_FOR_POLICY, serviceUrl);
    Map<String, String> headers = new HashMap<>();
    headers.put("accept", CmsConstants.APPLICATION_JSON);
    return iscSyncClient
        .getObject(serviceUrl, headers, GLPLearningAsset.class, IscSyncResponseFormat.RAW)
        .map(GLPLearningAsset::getConfiguration)
        .doOnSuccess(succ -> logger.debug("policyGroup fetched successfully."))
        .switchIfEmpty(Mono.error(new CmsException(HttpStatus.NOT_FOUND.value(),
            ErrorConstants.PRODUCT_CONF_FETCH_ERROR)))
        .onErrorResume(ex -> {
          logger.error(LoggingConstants.PRODUCT_CONF_FETCH_ERROR, id, version, ex.getMessage());
          return Mono.error(ex);
        }).elapsed().map(tuple -> {
          logger.debug("Time taken by LPB to get product configuration: {} ", tuple.getT1());
          return tuple.getT2();
        });

  }

  /**
   * Gets the product config and policy group.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the product config and policy group
   */
  public Mono<String> getPolicyGroupFromConfig(String id, String version) {
    Mono<Configuration> productConfig = getProductConfiguration(id, version);
    return productConfig.flatMap(config -> {
      String policyGroupString = CommonUtils.getPolicyGroups(config);
      if (policyGroupString != null) {
        return Mono.just(policyGroupString);
      } else {
        logger.error(LoggingConstants.PRODUCT_CONFIGURATION_NOT_FOUND_LOG, id, version);
        String noPolicyAvailableMessage = String.format(ErrorConstants.NO_POLICY_AVAILABLE, id,
            version);
        return Mono.error(new CmsException(HttpStatus.NOT_FOUND.value(), noPolicyAvailableMessage));
      }
    });
  }

  /**
   * Post policy.
   *
   * @param serviceUrl
   *          the service url
   * @param policyPayload
   *          the policy payload
   * @return the mono
   */
  private Mono<GLPLearningPolicy> postPolicy(String serviceUrl, PolicyPayload policyPayload) {
    Map<String, String> headers = new HashMap<>();
    headers.put(CmsConstants.CONTENT_TYPE_LOWER, CmsConstants.APPLICATION_JSON);
    logger.debug(LoggingConstants.CALLING_TO_POST_POLICY_GROUPS, serviceUrl);
    return iscSyncClient
        .postObject(serviceUrl, headers, Arrays.asList(policyPayload), GLPLearningPolicy[].class,
            IscSyncResponseFormat.RAW)
        .map(responseList -> responseList[CmsConstants.ZERO])
        .doOnError(ex -> logger.error("Create policy for {} engagement failed {}", serviceUrl, ex))
        .elapsed().map(tuple -> {
          logger.debug(LoggingConstants.TIME_TAKEN_TO_CREATE_POLICY, serviceUrl, tuple.getT1());
          return tuple.getT2();
        });
  }

  /**
   * Creates the delivery policy.
   *
   * @param requestPayload
   *          the request payload
   * @param assetClass
   *          the asset class
   * @param learningModel
   *          the learning model
   * @param tags
   *          the tags
   * @param group
   *          the group
   * @return the mono
   */
  public Mono<GLPLearningPolicy> createDeliveryPolicy(PolicyPayload requestPayload,
      AssetClass assetClass, String learningModel, String tags, Groups group) {
    String serviceUrl = CommonUtils.getUrl(ladBaseUrl, UriEnum.URI_POST_POLICIES);
    return postPolicy(serviceUrl,
        populatePolicyPayload(group, learningModel, assetClass.value(), tags, requestPayload));
  }

  /**
   * Gets the policy with inline error.
   *
   * @param policyMono
   *          the policy mono
   * @return the policy with inline error
   */
  private Mono<GLPLearningPolicy> getPolicyWithInlineError(Mono<GLPLearningPolicy> policyMono) {
    return policyMono.onErrorMap(IscSyncRuntimeException.class, iscErr -> {
      if (iscErr.getHttpStatusCode() == HttpStatus.NOT_FOUND.value()) {
        return new CmsException(HttpStatus.NOT_FOUND.value(), ErrorConstants.POLICY_NOT_FOUND);
      } else {
        return iscErr;
      }
    }).onErrorResume(ex -> Mono.just(new GLPLearningPolicy(new CustomErrorMessage(ex))));
  }

  /**
   * Creates the runtime resource plan.
   *
   * @param resourceRef
   *          the resource ref
   * @return the array list
   */
  private ArrayList<ResourcePlan> createRuntimeResourcePlan(String resourceRef) {
    ResourcePlan resourcePlan = new ResourcePlan();
    resourcePlan.setLabel(CmsConstants.EMPTY);
    resourcePlan.setResourceElements(new ArrayList<>());
    resourcePlan.setResourceElementType(CmsConstants.EMPTY);
    resourcePlan.setResourceRef(resourceRef);
    ArrayList<ResourcePlan> resourcePlanList = new ArrayList<>();
    resourcePlanList.add(resourcePlan);
    return resourcePlanList;
  }

  /**
   * Creates the inlined resource.
   *
   * @param runtimeSettings
   *          the runtime settings
   * @param resourceModel
   *          the resource model
   * @return the asset inlined resource
   */
  private AssetInlineResource createInlinedResource(Map<String, Object> runtimeSettings,
      String resourceModel) {
    AssetInlineResource inlinedResource = new AssetInlineResource();
    inlinedResource.setModel(resourceModel);
    inlinedResource.setCategory(CmsConstants.CONFIGURATION);
    inlinedResource.setResourceType(ResourceType.INLINED.value());
    inlinedResource.setData(runtimeSettings);
    return inlinedResource;
  }

  /**
   * Gets the runtime policy response.
   *
   * @param policyGroup
   *          the policy group
   * @return the runtime policy response
   */
  public Mono<AssessmentTypePayload> getAssessmentRuntimeSettingsResponse(String policyGroup) {

    Mono<GLPLearningPolicy> deliveryPolicyResponse = getPolicyWithInlineError(
        getPolicy(ladBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
            AssetClass.DELIVERY_RUNTIME_SETTINGS.value(), policyGroup));
    Mono<GLPLearningPolicy> engagementPolicyResponse = getPolicyWithInlineError(
        getPolicy(leeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
            AssetClass.ENGAGEMENT_RUNTIME_SETTINGS.value(), policyGroup));
    Mono<GLPLearningPolicy> evaluationPolicyResponse = getPolicyWithInlineError(
        getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
            AssetClass.EVALUATION_RUNTIME_SETTINGS.value(), policyGroup));

    return Mono.zip(deliveryPolicyResponse, engagementPolicyResponse, evaluationPolicyResponse)
        .map(this::transformResponsetoAssessmentPayload);

  }

  /**
   * Transform Response into AssessMentTypePayload.
   *
   * @param tuple
   *          the GLPLearningPolicy
   * @return AssessmentTypePayload response
   * 
   */
  @SuppressWarnings("unchecked")
  private AssessmentTypePayload transformResponsetoAssessmentPayload(
      Tuple3<GLPLearningPolicy, GLPLearningPolicy, GLPLearningPolicy> tuple) {

    List<LinkedHashMap<String, Object>> deliveryResponse = (List<LinkedHashMap<String, Object>>) tuple
        .getT1().getResources().get(CmsConstants.ASSESSMENT_RUNTIME_SETTINGS).getData()
        .get(CmsConstants.ASSESSMENT_TYPES);
    List<LinkedHashMap<String, Object>> engagementResponse = (List<LinkedHashMap<String, Object>>) tuple
        .getT2().getResources().get(CmsConstants.ASSESSMENT_RUNTIME_SETTINGS).getData()
        .get(CmsConstants.ASSESSMENT_TYPES);
    List<LinkedHashMap<String, Object>> evaluationResponse = (List<LinkedHashMap<String, Object>>) tuple
        .getT3().getResources().get(CmsConstants.ASSESSMENT_RUNTIME_SETTINGS).getData()
        .get(CmsConstants.ASSESSMENT_TYPES);

    AssessmentTypePayload response = new AssessmentTypePayload();
    List<AssessmentType> listOfAssessments = new ArrayList<>();
    Map<String, AssessmentType> mapOfAssessments = new HashMap<>();

    deliveryResponse.forEach(entry1 -> {
      updateRuntimeSettings(mapOfAssessments, entry1);
    });

    engagementResponse.forEach(entry1 -> {
      updateRuntimeSettings(mapOfAssessments, entry1);
    });

    evaluationResponse.forEach(entry1 -> {
      updateRuntimeSettings(mapOfAssessments, entry1);
    });

    mapOfAssessments.entrySet().stream()
        .forEach(assessment -> listOfAssessments.add(assessment.getValue()));
    response.setAssessmentTypes(listOfAssessments);
    return response;
  }

  /**
   * updates runtimeSettings and store them in a map.
   *
   * @param mapOfAssessments
   *          the Map
   * @param entry
   *          the LinkedHashMap
   * 
   */
  private void updateRuntimeSettings(Map<String, AssessmentType> mapOfAssessments,
      LinkedHashMap<String, Object> entry) {

    AssessmentType assessment = CommonUtils.OBJECT_MAPPER.convertValue(entry, AssessmentType.class);
    // check if map contains assessmentType key
    if (mapOfAssessments.containsKey(assessment.getAssessmentType())) {

      // if key exists,fetch the value of assessment from the map
      AssessmentType assessmentType = mapOfAssessments.get(assessment.getAssessmentType());

      // fetch the continousSettings & discreetSettings of assessment
      HashMap<String, Object> continousSettings = assessmentType.getRuntimeSettings()
          .getContinuousSettings();
      HashMap<String, Object> discreetSettings = assessmentType.getRuntimeSettings()
          .getDiscreetSettings();

      // update the continousSettings & discreetSettings of assessments
      continousSettings.putAll(assessment.getRuntimeSettings().getContinuousSettings());
      discreetSettings.putAll(assessment.getRuntimeSettings().getDiscreetSettings());

      // setting the updated runtime settings
      assessment.getRuntimeSettings().setContinuousSettings(continousSettings);
      assessment.getRuntimeSettings().setDiscreetSettings(discreetSettings);
    }
    mapOfAssessments.put(assessment.getAssessmentType(), assessment);

  }

  /**
   * Apply default product runtime policy.
   *
   * @param modelGroupMono
   *          the model group mono
   * @param productGroupMono
   *          the product group
   * @param productAssetTypeMono
   *          the product asset type mono
   */
  public void applyDefaultProductRuntimePolicy(Mono<String> modelGroupMono, String productGroupMono,
      Mono<ProductAssetTypes> productAssetTypeMono) {

    modelGroupMono
        .flatMap(modelGroup -> getPolicyWithInlineError(
            getPolicy(ladBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
                AssetClass.DELIVERY_RUNTIME_SETTINGS.value(), modelGroup)))
        .flatMap(policy -> filterPolicyList(productAssetTypeMono, policy,
            CmsConstants.ASSESSMENT_RUNTIME_SETTINGS))
        .flatMap(response -> createPayloadFromPolicy(response, productGroupMono,
            CmsConstants.ASSESSMENT_RUNTIME_SETTINGS, runtimeSettingsLmLad, ladBaseUrl))
        .subscribe(value -> logger.info(DEFAULT_RUNTIME_POLICY_DELIVERY_SUCCESS, value),
            error -> logger.error(DEFAULT_PRODUCT_RUNTIME_POLICY_DELIVERY_ERROR,
                error.getMessage()));

    modelGroupMono
        .flatMap(modelGroup -> getPolicyWithInlineError(
            getPolicy(leeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
                AssetClass.ENGAGEMENT_RUNTIME_SETTINGS.value(), modelGroup)))
        .flatMap(policy -> filterPolicyList(productAssetTypeMono, policy,
            CmsConstants.ASSESSMENT_RUNTIME_SETTINGS))
        .flatMap(response -> createPayloadFromPolicy(response, productGroupMono,
            CmsConstants.ASSESSMENT_RUNTIME_SETTINGS, runtimeSettingsLmLee, leeBaseUrl))
        .subscribe(value -> logger.info(DEFAULT_RUNTIME_POLICY_EXPERIENCE_SUCCESS, value),
            error -> logger.error(DEFAULT_PRODUCT_RUNTIME_POLICY_EXPERIENCE_ERROR,
                error.getMessage()));

    modelGroupMono
        .flatMap(modelGroup -> getPolicyWithInlineError(
            getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
                AssetClass.EVALUATION_RUNTIME_SETTINGS.value(), modelGroup)))
        .flatMap(policy -> filterPolicyList(productAssetTypeMono, policy,
            CmsConstants.ASSESSMENT_RUNTIME_SETTINGS))
        .flatMap(response -> createPayloadFromPolicy(response, productGroupMono,
            CmsConstants.ASSESSMENT_RUNTIME_SETTINGS, runtimeSettingsLmLae, laeBaseUrl))
        .subscribe(value -> logger.info(DEFAULT_RUNTIME_POLICY_EVALUATION_SUCCESS, value),
            error -> logger.error(DEFAULT_PRODUCT_RUNTIME_POLICY_EVALUATION_ERROR,
                error.getMessage()));

  }

  /**
   * Apply default scoring policy.
   *
   * @param modelGroupMono
   *          the model group mono
   * @param productGroupMono
   *          the product group mono
   * @param productAssetTypeMono
   *          the product asset type mono
   */
  public void applyDefaultProductScoringPolicy(Mono<String> modelGroupMono, String productGroupMono,
      Mono<ProductAssetTypes> productAssetTypeMono) {

    modelGroupMono
        .flatMap(modelGroup -> getPolicyWithInlineError(
            getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
                AssetClass.ASSESSMENT_SCORING_POLICY.value(), modelGroup)))
        .flatMap(
            policy -> filterPolicyList(productAssetTypeMono, policy, CmsConstants.SCORING_POLICY))
        .flatMap(response -> createPayloadFromPolicy(response, productGroupMono,
            CmsConstants.SCORING_POLICY, scoringPolicyLmLae, laeBaseUrl))
        .subscribe(value -> logger.info(DEFAULT_SCORING_POLICY_FETCHED, value),
            error -> logger.error(DEFAULT_SCORING_POLICY_ERROR, error.getMessage()));
  }

  /**
   * Creates the product policy payload from product model policy.
   *
   * @param modelPolicy
   *          the model policy
   * @param productGroup
   *          the product group
   * @param resourceRef
   *          the resource ref
   * @param learningModel
   *          the learning model
   * @param baseUrl
   *          the base url
   * @return the mono
   */
  private Mono<GLPLearningPolicy> createPayloadFromPolicy(GLPLearningPolicy modelPolicy,
      String productGroup, String resourceRef, String learningModel, String baseUrl) {
    if (modelPolicy.getErrors() != null) {
      return Mono.error(
          new CmsException(HttpStatus.BAD_REQUEST.value(), modelPolicy.getErrors().getMessage()));
    }
    String assetClass = modelPolicy.getAssetClass();
    logger.debug(CREATING_DEFAULT_PRODUCT_POLICY_PAYLOAD, assetClass);
    PolicyPayload policyPayload;
    if (AssetClass.ASSESSMENT_SCORING_POLICY.value().equals(assetClass)) {
      policyPayload = scoringFactory.populatePolicyPayload(
          AssetClass.ASSESSMENT_SCORING_POLICY.value(), CmsConstants.SCORING_POLICY, productGroup,
          scoringPolicyLmLae, modelPolicy.getResources());
    } else {
      String resourceModel = modelPolicy.getResources().get(resourceRef).getModel();
      Map<String, Object> data = modelPolicy.getResources().get(resourceRef).getData();
      policyPayload = populatePolicyPayload(new Groups(productGroup), learningModel, assetClass,
          data, resourceModel, resourceRef, CmsConstants.ASSESSMENT_RUNTIME_SETTINGS_TAG);
    }
    return postPolicy(CommonUtils.getUrl(baseUrl, UriEnum.URI_POST_POLICIES), policyPayload);
  }

  /**
   * Filter policy list.
   *
   * @param productAssetTypeMono
   *          the product asset type mono
   * @param modelPolicy
   *          the model policy
   * @return the mono
   */
  private Mono<GLPLearningPolicy> filterPolicyList(Mono<ProductAssetTypes> productAssetTypeMono,
      GLPLearningPolicy modelPolicy, String policyType) {

    return productAssetTypeMono.map(productAssetType -> {
      logger.debug("Filter policy list start");
      List<AssetClassType> assetClassType = productAssetType.getContent().getData()
          .getAssetClassTypes();
      List<String> assessmentTypes = Arrays.asList(assetClassType.get(CmsConstants.ZERO)
          .getAssetClass().toUpperCase().split(CmsConstants.COMMA));
      if (modelPolicy.getErrors() == null) {
        logger.debug(DEFAULT_PRODUCT_MODEL_POLICY_FETCHED, modelPolicy.getAssetClass());
        Map<String, Object> data = modelPolicy.getResources().get(policyType).getData();

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> assessmentTypeList = CommonUtils.OBJECT_MAPPER
            .convertValue(data.get(CmsConstants.ASSESSMENT_TYPES), List.class);
        assessmentTypeList = assessmentTypeList.stream()
            .filter(assessmentType -> assessmentTypes
                .contains(assessmentType.get(CmsConstants.ASSESSMENT_TYPE)))
            .collect(Collectors.toList());
        data.put(CmsConstants.ASSESSMENT_TYPES, assessmentTypeList);
      }
      return modelPolicy;
    });

  }

  /**
   * Gets the engagement policy response.
   *
   * @param baseUrl
   *          the base url
   * @param uri
   *          the uri
   * @param assetClass
   *          the asset class
   * @param policyGroup
   *          the group
   * @return the engagement policy response
   */
  public Mono<GLPLearningPolicy> getPolicy(String baseUrl, UriEnum uri, String assetClass,
      String policyGroup) {

    String serviceUrl = createPolicyUrlWithQueryParams(baseUrl, uri, policyGroup, assetClass);
    return iscSyncClient
        .getObject(serviceUrl, Collections.emptyMap(), GLPLearningPolicy[].class,
            IscSyncResponseFormat.RAW)
        .doOnError(ex -> logger.error("Get policy for {} engagement failed {}", serviceUrl, ex))
        .elapsed().map(tuple -> {
          logger.debug("Time taken by {} to Get policy: {} ", serviceUrl, tuple.getT1());
          return LearningPolicyPredicates.filterLearningPolicy(Arrays.asList(tuple.getT2()),
              LearningPolicyPredicates.isAssetClassMatched(assetClass));
        });
  }

  /**
   * Creates the policy url with query params.
   *
   * @param baseUrl
   *          the base url
   * @param uri
   *          the uri
   * @param policyGroup
   *          the policy group
   * @param assetClass
   *          the asset class
   * @return the string
   */
  private String createPolicyUrlWithQueryParams(String baseUrl, UriEnum uri, String policyGroup,
      String assetClass) {
    MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
    queryParams.add(CmsConstants.GROUP_KEY, policyGroup);
    queryParams.add(CmsConstants.ASSET_CLASS, assetClass);
    return CommonUtils.addQueryParams(CommonUtils.getUrl(baseUrl, uri), queryParams);
  }

  /**
   * Gets the policy group from product model config.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the policy group from product model config
   */
  public Mono<String> getPolicyGroupFromProductModelConfig(String id, String version) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.GET_POLICY_GROUPS_PRODUCT_MODEL_CONFIG);
    Mono<Configuration> productModelConfig = getProductModelConfiguration(id, version);
    logger.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.GET_POLICY_GROUPS_PRODUCT_MODEL_CONFIG);
    return productModelConfig.flatMap(config -> {
      String policyGroupString = getProductModelPolicyGroups(config);
      if (!ObjectUtils.isEmpty(policyGroupString)) {
        return Mono.just(policyGroupString);
      }
      logger.error(LoggingConstants.PRODUCT_MODEL_CONFIGURATION_NOT_FOUND_LOG, id, version);
      return Mono.error(new CmsException(HttpStatus.NOT_FOUND.value(),
          String.format(ErrorConstants.NO_PRODUCT_MODEL_POLICY_AVAILABLE, id, version)));
    });
  }

  /**
   * Gets the product model policy groups.
   *
   * @param config
   *          the config
   * @return the product model policy groups
   */
  private String getProductModelPolicyGroups(Configuration config) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.GET_PRODUCT_MODEL_POLICY_GROUPS);
    @SuppressWarnings("unchecked")
    List<String> policyGroup = (List<String>) config.get(CmsConstants.POLICY_GROUPS);
    logger.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.GET_PRODUCT_MODEL_POLICY_GROUPS);
    if (!ObjectUtils.isEmpty(policyGroup)) {
      return policyGroup.stream().filter(policy -> policy.endsWith(CmsConstants.REGEX_DEFAULT))
          .findFirst().orElse(null);
    }
    return null;

  }

  /**
   * Gets the product model configuration.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return the product model configuration
   */
  public Mono<Configuration> getProductModelConfiguration(String id, String version) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.GET_PRODUCT_MODEL_CONFIGURATION);
    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl,
        UriEnum.URI_GET_PRODUCT_MODEL_SPECIFIC_VERSION, id, version);
    serviceUrl = CommonUtils.addQueryParams(serviceUrl, CmsConstants.FIELD_QUERY_PARAM_KEY,
        CmsConstants.FIELD_QUERY_PARAM_VALUE);
    logger.debug(LoggingConstants.CALLING_FOR_POLICY, serviceUrl);
    Map<String, String> headers = new HashMap<>();
    headers.put(CmsConstants.ACCEPT, CmsConstants.APPLICATION_JSON);
    logger.debug(LoggingConstants.METHOD_TERMINATION,
        LoggingConstants.GET_PRODUCT_MODEL_CONFIGURATION);
    return iscSyncClient
        .getObject(serviceUrl, headers, GLPLearningAsset.class, IscSyncResponseFormat.RAW)
        .map(GLPLearningAsset::getConfiguration)
        .doOnSuccess(succ -> logger.debug(LoggingConstants.POLICY_FETCHED_SUCCESS))
        .switchIfEmpty(Mono.error(new CmsException(HttpStatus.NOT_FOUND.value(),
            ErrorConstants.PRODUCT_MODEL_CONF_FETCH_ERROR)))
        .onErrorResume(ex -> {
          logger.error(LoggingConstants.PRODUCT_MODEL_CONF_FETCH_ERROR, id, version,
              ex.getMessage());
          return Mono.error(ex);
        }).elapsed().map(tuple -> {
          logger.debug(LoggingConstants.TIME_TAKEN_TO_FETCH_POLICY, tuple.getT1());
          return tuple.getT2();
        });
  }

  /**
   * Fetch assessment type of product scanned document.
   *
   * @param id
   *          the id
   * @param version
   *          the version
   * @return ProductAssetTypes
   */
  public Mono<ProductAssetTypes> fetchProductAssessmentType(String id, String version) {

    String serviceUrl = CommonUtils.getUrl(lpbBaseUrl, UriEnum.URI_GET_PRODUCT_ASSET_TYPES, id,
        version);
    serviceUrl = CommonUtils.addQueryParams(serviceUrl, CmsConstants.ASSET_TYPE,
        AssetType.ASSESSMENT.value());
    logger.debug(LoggingConstants.GET_PRODUCT_ASSET_TYPES_LOG, serviceUrl);

    Map<String, String> headers = new HashMap<>();
    headers.put("accept", CmsConstants.APPLICATION_JSON);
    return iscSyncClient
        .getObject(serviceUrl, headers, ProductAssetTypes.class, IscSyncResponseFormat.RAW)
        .doOnSuccess(succ -> logger.debug(LoggingConstants.GET_PRODUCT_ASSESSMENT_TYPE_MESSAGE))
        .doOnError(ex -> logger.error(ErrorConstants.ERROR_PRODUCT_ASSESSMENT_TYPE_FETCH,
            ex.getMessage()));
  }

  /**
   * Gets the resolved policy response.
   *
   * @param policyGroup
   *          the policy group
   * @return the resolved policy response
   */
  public Mono<GLPLearningPolicy> getResolvedPolicyResponse(String policyGroup) {
    return getPolicyWithInlineError(getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES,
        AssetClass.GRADE_BOOK_CATEGORY_POLICY.value(), policyGroup));
  }

  /**
   * Creates the experience evaluation policy.
   *
   * @param resolvedPolicy
   *          the resolved policy
   * @param policyGroups
   *          the policy groups
   * @param weightsPayload
   *          the weights payload
   * @return the mono
   */
  public Mono<GLPLearningPolicy> createExperienceEvaluationPolicy(GLPLearningPolicy resolvedPolicy,
      Mono<String> policyGroups, CategoryWeightsPayload weightsPayload) {
    Mono<GLPLearningPolicy> policyResponse;
    if (resolvedPolicy.getErrors() != null
        && resolvedPolicy.getErrors().getStatus() == HttpStatus.NOT_FOUND.value()) {
      // create experience evaluation policy
      String serviceUrl = CommonUtils.getUrl(laeBaseUrl, UriEnum.URI_POST_POLICIES);
      policyResponse = policyGroups.map(Groups::new)
          .flatMap(group -> postPolicy(serviceUrl,
              populatePolicyPayload(group, categoryWeightsLmLae,
                  AssetClass.GRADE_BOOK_CATEGORY_POLICY.value(), CmsConstants.CATEGORY_WEIGHTS_TAG,
                  createPolicyPayload(weightsPayload))));
    } else {
      // create experience evaluation policy version
      String serviceUrl = CommonUtils.getUrl(laeBaseUrl, UriEnum.URI_POST_POLICIE_VERSIONS,
          resolvedPolicy.getId());
      policyResponse = policyGroups.map(Groups::new).flatMap(group -> postPolicyVersion(serviceUrl,
          populatePolicyVersionPayload(createPolicyPayload(weightsPayload))));
    }
    return policyResponse;
  }

  /**
   * Creates the policy payload.
   *
   * @param weightsPayload
   *          the weights payload
   * @return the policy payload
   */
  private PolicyPayload createPolicyPayload(CategoryWeightsPayload weightsPayload) {
    PolicyPayload policyPayload = new PolicyPayload();
    LinkedHashMap<String, AssetInlineResource> resources = new LinkedHashMap<>();
    Map<String, Object> data = new HashMap<>();
    data.put(CmsConstants.GRADEBOOK_CATEGORY_POLICIES,
        weightsPayload.getGradebookCategoryPolicy().getData().getGradebookCategoryPolicies());
    resources.put(CmsConstants.GRADEBOOK_CATEGORY_POLICY,
        createInlinedResource(data, ResourceModel.CATEGORY_WEIGHTS.value()));
    policyPayload.setResources(resources);
    policyPayload.setStatus(weightsPayload.getStatus());
    return policyPayload;
  }

  /**
   * Populate policy version payload.
   *
   * @param payload
   *          the payload
   * @return the policy version payload
   */
  private PolicyVersionPayload populatePolicyVersionPayload(PolicyPayload payload) {
    PolicyVersionPayload policyVersionPayload = new PolicyVersionPayload();
    BeanUtils.copyProperties(payload, policyVersionPayload);
    return policyVersionPayload;
  }

  /**
   * Post policy version.
   *
   * @param serviceUrl
   *          the service url
   * @param policyPayload
   *          the policy payload
   * @return the mono
   */
  private Mono<GLPLearningPolicy> postPolicyVersion(String serviceUrl,
      PolicyVersionPayload policyPayload) {
    Map<String, String> headers = new HashMap<>();
    headers.put(CmsConstants.CONTENT_TYPE_LOWER, CmsConstants.APPLICATION_JSON);
    logger.debug(LoggingConstants.CALLING_TO_POST_POLICY_GROUPS_VERSION, serviceUrl);
    return iscSyncClient
        .postObject(serviceUrl, headers, policyPayload, GLPLearningPolicy.class,
            IscSyncResponseFormat.RAW)
        .doOnError(
            ex -> logger.error("Create policy version for {} engagement failed {}", serviceUrl, ex))
        .elapsed().map(tuple -> {
          logger.debug("Time taken by {} to create policy version: {} ", serviceUrl, tuple.getT1());
          return tuple.getT2();
        });
  }

  /**
   * Validate category weights.
   *
   * @param weightsPayload
   *          the weights payload
   * @return true, if successful
   */
  public boolean validateCategoryWeights(CategoryWeightsPayload weightsPayload) {
    if (CategoryWeightStatus.ACTIVE.getVal().equals(weightsPayload.getStatus())) {
      List<GradeBookCategoryPolicies> gradeBookCategoryPoliciesList = weightsPayload
          .getGradebookCategoryPolicy().getData().getGradebookCategoryPolicies();
      int sum = gradeBookCategoryPoliciesList.stream()
          .mapToInt(GradeBookCategoryPolicies::getWeight).sum();
      if (sum != 100) {
        return false;
      }
    }
    return true;
  }

  /**
   * Creates the assessment runtime policy response.
   *
   * @param payload
   *          the payload
   * @param group
   *          the group
   * @return the mono
   */
  public Mono<RuntimeSettingsResponse> createAssessmentRuntimePolicyResponse(
      AssessmentTypePayload payload, String group, String selfLink) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.CREATE_ASSESSMENT_RUNTIME_POLICY_RESPONSE);

    Mono<GLPLearningPolicy> deliveryPolicy = postAssessmentRuntimeSettingsPolicy(ladBaseUrl,
        UriEnum.URI_GET_RESOLVED_POLICIES, group,
        createPolicyData(payload, ladContinuousSettingKeys, ladDiscreetSettingKeys),
        runtimeSettingsLmLad, AssetClass.DELIVERY_RUNTIME_SETTINGS,
        ResourceModel.DELIVERY_RUNTIME_SETTINGS);

    Mono<GLPLearningPolicy> engagementPolicy = postAssessmentRuntimeSettingsPolicy(leeBaseUrl,
        UriEnum.URI_GET_RESOLVED_POLICIES, group,
        createPolicyData(payload, leeContinuousSettingKeys, leeDiscreetSettingKeys),
        runtimeSettingsLmLee, AssetClass.ENGAGEMENT_RUNTIME_SETTINGS,
        ResourceModel.ENGAGEMENT_RUNTIME_SETTINGS);

    Mono<GLPLearningPolicy> evaluationPolicy = postAssessmentRuntimeSettingsPolicy(laeBaseUrl,
        UriEnum.URI_GET_RESOLVED_POLICIES, group,
        createPolicyData(payload, laeContinuousSettingKeys, laeDiscreetSettingKeys),
        runtimeSettingsLmLae, AssetClass.EVALUATION_RUNTIME_SETTINGS,
        ResourceModel.EVALUATION_RUNTIME_SETTINGS);

    return Mono.zip(deliveryPolicy, engagementPolicy, evaluationPolicy).map(tuple -> {
      RuntimeSettingsResponse response = new RuntimeSettingsResponse();
      response.setDeliveryPolicy(updateSelfLink(tuple.getT1(), selfLink));
      response.setEngagementPolicy(updateSelfLink(tuple.getT2(), selfLink));
      response.setEvaluationPolicy(updateSelfLink(tuple.getT3(), selfLink));
      return response;
    });
  }

  /**
   * Creates the policy data.
   *
   * @param assessmentTypePayload
   *          the assessment type payload
   * @param continuousSettings
   *          the continuous settings
   * @param discreetSettings
   *          the discreet settings
   * @return the map
   */
  private Map<String, Object> createPolicyData(AssessmentTypePayload assessmentTypePayload,
      String continuousSettings, String discreetSettings) {
    logger.debug(LoggingConstants.METHOD_INVOCATION, LoggingConstants.CREATE_POLICY_DATA);
    Map<String, Object> runtimeSettings = new HashMap<>();
    runtimeSettings.put(CmsConstants.ASSESSMENT_TYPES,
        new AssessmentTypePayload(assessmentTypePayload, continuousSettings, discreetSettings)
            .getAssessmentTypes());
    return runtimeSettings;
  }

  /**
   * Post assessment runtime settings policy.
   *
   * @param baseUrl
   *          the base url
   * @param getEngagementPolicyUri
   *          the get engagement policy uri
   * @param group
   *          the group
   * @param runtimeSettings
   *          the runtime settings
   * @param runtimeSettingsLM
   *          the runtime settings LM
   * @param assetClass
   *          the asset class
   * @param resourceModel
   *          the resource model
   * @return the mono
   */
  private Mono<GLPLearningPolicy> postAssessmentRuntimeSettingsPolicy(String baseUrl,
      UriEnum getEngagementPolicyUri, String group, Map<String, Object> runtimeSettings,
      String runtimeSettingsLM, AssetClass assetClass, ResourceModel resourceModel) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.POST_ASSESSMENT_RUNTIME_SETTINGS_POLICY);
    PolicyPayload policyPayload = populatePolicyPayload(new Groups(group), runtimeSettingsLM,
        assetClass.value(), runtimeSettings, resourceModel.value(),
        CmsConstants.ASSESSMENT_RUNTIME_SETTINGS, CmsConstants.ASSESSMENT_RUNTIME_SETTINGS_TAG);
    return getPolicyWithInlineError(
        getPolicy(baseUrl, getEngagementPolicyUri, assetClass.value(), group)
            .flatMap(response -> postPolicyVersion(
                CommonUtils.getUrl(baseUrl, UriEnum.URI_POST_POLICIE_VERSIONS, response.getId()),
                populatePolicyVersionPayload(policyPayload)))
            .onErrorResume(
                error -> (ErrorUtils.getErrorModelFromException(error)
                    .getStatus() == HttpStatus.NOT_FOUND.value())
                        ? postPolicy(CommonUtils.getUrl(baseUrl, UriEnum.URI_POST_POLICIES),
                            policyPayload)
                        : Mono.error(error)));
  }

  /**
   * Post the product scoring policy.
   *
   * @param PolicyPayload
   *          the payload
   * @param String
   *          the policy
   * @param String
   *          the assetClass
   * @return the GLPLearningPolicy
   */
  public Mono<GLPLearningPolicy> postProductScoringPolicy(Map<String, Object> payload,
      String policy, String assetClass) {
    LinkedHashMap<String, AssetInlineResource> scoringResource = scoringFactory
        .preparePolicyResource(ResourceModel.SCORING_POLICY.value(), CmsConstants.SCORING_POLICY,
            payload);
    return getPolicy(laeBaseUrl, UriEnum.URI_GET_RESOLVED_POLICIES, assetClass, policy)
        .flatMap(
            learningPolicy -> postProductScoringPolicyVersion(laeBaseUrl, learningPolicy.getId(),
                scoringFactory.populateScoringPolicyPayloadVersion(scoringResource)))
        .onErrorResume(err -> {
          logger.error(LoggingConstants.POLICY_ENGAGEMENT_ERROR, laeBaseUrl, err);
          if (err.getMessage().contains(ErrorConstants.ERROR_404))
            return postPolicy(CommonUtils.getUrl(laeBaseUrl, UriEnum.URI_POST_POLICIES),
                scoringFactory.populatePolicyPayload(AssetClass.ASSESSMENT_SCORING_POLICY.value(),
                    CmsConstants.SCORING_POLICY, policy, scoringPolicyLmLae,
                    scoringFactory.preparePolicyResource(ResourceModel.SCORING_POLICY.value(),
                        CmsConstants.SCORING_POLICY, payload)));
          else {
            return Mono.empty();
          }
        }).switchIfEmpty(Mono.error(
            new CmsException(HttpStatus.BAD_REQUEST.value(), ErrorConstants.MESSAGE_BAD_REQUEST)));

  }

  /**
   * Post Learning Aids
   * 
   * @param requestPayload
   * @param learningModel
   * @param group
   * @return the mono
   */
  public Mono<GLPLearningPolicy> postLearningAids(Map<String, Object> requestPayload,
      String learningModel, String group) {
    String serviceUrl = CommonUtils.getUrl(ladBaseUrl, UriEnum.URI_POST_POLICIES);
    logger.debug(LoggingConstants.RENAME_LEARNING_AIDS_LOG, serviceUrl);
    LinkedHashMap<String, AssetInlineResource> scoringResource = scoringFactory
        .preparePolicyResource(ResourceModel.LEARNING_AIDS.value(),
            CmsConstants.LEARNING_AIDS_TYPES, requestPayload);
    return postPolicy(serviceUrl,
        scoringFactory.populatePolicyPayload(AssetClass.LEARNING_AIDLIST_POLICY.value(),
            CmsConstants.LEARNING_AIDS_TYPES, group, learningModel, scoringResource));
  }

  /**
   * Post the product scoring policy version.
   *
   * @param String
   *          the url
   * @param String
   *          the policyId
   * @param PolicyPayload
   *          the payload
   * @return the GLPLearningPolicy
   */

  private Mono<GLPLearningPolicy> postProductScoringPolicyVersion(String url, String policyId,
      PolicyPayload payload) {
    String serviceUrl = CommonUtils.getUrl(url, UriEnum.URI_POST_POLICIE_VERSIONS, policyId);
    Map<String, String> headers = new HashMap<>();
    headers.put(CmsConstants.CONTENT_TYPE_LOWER, CmsConstants.APPLICATION_JSON);
    return iscSyncClient
        .postObject(serviceUrl, headers, payload, GLPLearningPolicy.class,
            IscSyncResponseFormat.RAW)
        .doOnError(ex -> logger.error(LoggingConstants.SCORING_POLICY_VERSION_FOR_PRODUCT_ERROR,
            serviceUrl, ex))
        .elapsed().map(tuple -> {
          logger.debug(LoggingConstants.TIME_TAKEN_TO_CREATE_POLICY, serviceUrl, tuple.getT1());
          return tuple.getT2();
        });
  }

  /**
   * Update self link.
   *
   * @param policy
   *          the policy
   * @param selfLink
   *          the self link
   * @return the GLP learning policy
   */
  private GLPLearningPolicy updateSelfLink(GLPLearningPolicy policy, String selfLink) {
    logger.debug(LoggingConstants.METHOD_INVOCATION, LoggingConstants.UPDATE_SELF_LINK);
    if (!ObjectUtils.isEmpty(policy.getLinks())) {
      policy.getLinks().get(CmsConstants.SELF_NODE).setHref(selfLink);
    }
    return policy;
  }

}
