/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.helper;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.common.AssetInlineResource;
import com.pearson.glp.cms.dto.common.Groups;
import com.pearson.glp.cms.dto.common.ResourcePlan;
import com.pearson.glp.cms.dto.learningpolicy.request.PolicyPayload;
import com.pearson.glp.cms.enums.ResourceModel;
import com.pearson.glp.cms.enums.ResourceType;
import com.pearson.glp.cms.utils.CommonUtils;

/**
 * The Class PolicyTransformFactory.
 *
 * @author ishan.jogi
 */
@Component
public class PolicyTransformFactory {

  /** The logger. */
  private Logger logger = LoggerFactory.getLogger(PolicyTransformFactory.class);

  /**
   * Instantiates a new PolicyTransformFactory.
   */
  public PolicyTransformFactory() {
    super();
  }

  /**
   * prepare payload for scoring policy new version.
   *
   * @param LinkedHashMap
   *          the payload
   * @return the PolicyPayload
   */
  public PolicyPayload populateScoringPolicyPayloadVersion(
      LinkedHashMap<String, AssetInlineResource> resource) {
    PolicyPayload newPayload = new PolicyPayload();
    newPayload.setResources(resource);
    newPayload.setLanguage(null);
    newPayload.setExtend(null);
    return newPayload;

  }

  /**
   * Creates the resource plan.
   *
   * @return the array list
   */
  private ArrayList<ResourcePlan> createResourcePlan(String ref) {
    ResourcePlan resourcePlan = new ResourcePlan();
    resourcePlan.setLabel(CmsConstants.EMPTY);
    resourcePlan.setResourceElements(new ArrayList<ResourcePlan>());
    resourcePlan.setResourceElementType(CmsConstants.INLINED);
    resourcePlan.setResourceRef(ref);
    ArrayList<ResourcePlan> resourcePlanList = new ArrayList<>();
    resourcePlanList.add(resourcePlan);
    return resourcePlanList;
  }

  /**
   * prepare resource.
   *
   * @param Map
   *          the payload
   * @return the LinkedHashMap
   */
  public LinkedHashMap<String, AssetInlineResource> prepareScoringPolicyResource(
      Map<String, Object> payload) {
    LinkedHashMap<String, AssetInlineResource> resources = new LinkedHashMap<>();
    logger.debug(LoggingConstants.CALLING_SCORING_POLICY_RESOURCE);
    AssetInlineResource inlineResource = new AssetInlineResource();
    inlineResource.setResourceType(ResourceType.INLINED.value());
    inlineResource.setCategory(CmsConstants.CONFIGURATION);
    inlineResource.setModel(ResourceModel.SCORING_POLICY.value());
    Map<String, Object> scoringPolicy = (Map<String, Object>) payload
        .get(CmsConstants.SCORING_POLICY);
    inlineResource.setData((Map<String, Object>) scoringPolicy.get(CmsConstants.DATA));
    resources.put(CmsConstants.SCORING_POLICY, inlineResource);
    return resources;

  }

  /**
   * prepare policy resource.
   *
   * @param Map
   *          the payload
   * @return the LinkedHashMap
   */
  public LinkedHashMap<String, AssetInlineResource> preparePolicyResource(String resourceModel,
      String policyType, Map<String, Object> payload) {
    LinkedHashMap<String, AssetInlineResource> resources = new LinkedHashMap<>();
    logger.debug(LoggingConstants.CALLING_POLICY_RESOURCE);
    AssetInlineResource inlineResource = new AssetInlineResource();
    inlineResource.setResourceType(ResourceType.INLINED.value());
    inlineResource.setCategory(CmsConstants.CONFIGURATION);
    inlineResource.setModel(resourceModel);
    Map<String, Object> scoringPolicy = (Map<String, Object>) payload.get(policyType);
    inlineResource.setData((Map<String, Object>) scoringPolicy.get(CmsConstants.DATA));
    resources.put(policyType, inlineResource);
    return resources;

  }

  /**
   * Populate policy payload.
   * 
   * @param group
   *          the group
   * @param learningModel
   *          the learning model
   * @param assetClass
   *          the asset class
   * @param tags
   *          the tags
   * @param payload
   *          the payload
   *
   * @return the policy payload
   */
  public PolicyPayload populatePolicyPayload(String assetClass, String policyType, String policy,
      String learningModel, LinkedHashMap<String, AssetInlineResource> resource) {
    logger.debug(LoggingConstants.POLICY_PAYLOAD_CREATION_LOG);
    PolicyPayload payload = new PolicyPayload();
    payload.setAssetClass(assetClass);
    payload.setLearningModel(CommonUtils.createLearningModel(learningModel));
    payload.setResourcePlan(createResourcePlan(policyType));
    payload.setGroups(new Groups(policy));
    payload.setResources(resource);
    payload.setAssetGraph(new ArrayList<>());
    return payload;

  }
}
