/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.isc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.exception.CmsException;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class IscReactiveClient.
 *
 * @author bharat.aggarwal
 */
@Component
public class IscReactiveClient {

  /** The web client. */
  @Autowired
  protected WebClient webClient;

  /**
   * Instantiates a new isc reactive client.
   */
  public IscReactiveClient() {
    super();
  }

  /**
   * External service post call.
   *
   * @param <T>
   *          the generic type
   * @param <R>
   *          the generic type
   * @param serviceUrl
   *          the service url
   * @param requestBody
   *          the all headers
   * @param requestClassType
   *          the request class type
   * @param responseClassType
   *          the response class type
   * @return the Flux
   */
  public <T, R> Flux<R> postObjects(String serviceUrl, Mono<T> requestBody,
      Class<T> requestClassType, Class<R> responseClassType) {
    return webClient.post().uri(serviceUrl).header("source", CmsConstants.CMS)
        .contentType(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, requestClassType))
        .accept(MediaType.APPLICATION_JSON).exchange().flatMap(this::checkResponseStatus)
        .flatMapMany(response -> response.bodyToFlux(responseClassType)).onErrorResume(Flux::error);
  }

  /**
   * Check response status.
   *
   * @param response
   *          the response
   * @return the mono
   */
  private Mono<ClientResponse> checkResponseStatus(ClientResponse response) {
    HttpStatus httpStatus = response.statusCode();
    if (httpStatus.is4xxClientError() || httpStatus.is5xxServerError()) {
      throw new CmsException(httpStatus.value(), httpStatus.getReasonPhrase());
    }
    return Mono.just(response);
  }
}
