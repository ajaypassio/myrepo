/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.learningpolicy.predicate;

import java.util.List;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;

/**
 * The Class LearningPolicyPredicates.
 *
 * @author umender.singh
 */
public class LearningPolicyPredicates {

  /** The logger. */
  private static Logger logger = LoggerFactory.getLogger(LearningPolicyPredicates.class);

  /**
   * Instantiates a new cms predicates.
   */
  public LearningPolicyPredicates() {
    super();
  }

  /**
   * Checks if is asset class matched.
   *
   * @param assetClass
   *          the asset class
   * @return the predicate
   */
  public static Predicate<GLPLearningPolicy> isAssetClassMatched(String assetClass) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.IS_ASSET_CLASS_MATCHED_METHOD);
    return p -> p.getAssetClass().equalsIgnoreCase(assetClass);
  }

  /**
   * Filter learning policy.
   *
   * @param gLPLearningPolicies
   *          the g LP learning policies
   * @param predicate
   *          the predicate
   * @return the GLP learning policy
   */
  public static GLPLearningPolicy filterLearningPolicy(List<GLPLearningPolicy> gLPLearningPolicies,
      Predicate<GLPLearningPolicy> predicate) {
    logger.debug(LoggingConstants.METHOD_INVOCATION,
        LoggingConstants.FILTER_LEARNING_POLICY_METHOD);
    return gLPLearningPolicies.stream().filter(predicate).findFirst().orElse(null);
  }
}
