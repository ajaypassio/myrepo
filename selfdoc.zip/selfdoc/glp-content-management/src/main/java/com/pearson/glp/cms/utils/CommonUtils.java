/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.utils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.dto.common.Configuration;
import com.pearson.glp.cms.dto.common.LearningModel;
import com.pearson.glp.cms.enums.QueryParameter;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class CommonUtils.
 */
public class CommonUtils {

  /**
   * The logger.
   */
  private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);

  /**
   * The Constant OBJECT_MAPPER.
   */
  public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  /**
   * Instantiates a new common utils.
   */
  private CommonUtils() {
    super();
  }

  static {
    OBJECT_MAPPER.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
  }

  /**
   * Convert json string to object.
   *
   * @param <T>
   *          the generic type
   * @param json
   *          the json
   * @param classType
   *          the class type
   * @return the t
   */
  public static <T> T convertJsonStringToObject(String json, Class<T> classType) {
    T object = null;
    try {
      object = OBJECT_MAPPER.readValue(json, classType);
    } catch (final Exception exception) {
      LOGGER.error("convertJsonToObject, Exception has occured {}", exception);
    }
    return object;
  }

  /**
   * Gets the url.
   *
   * @param baseUri
   *          the base uri
   * @param path
   *          the path
   * @return the url
   */
  public static String getUrl(String baseUri, UriEnum path, Object... pathParams) {
    String url = (baseUri != null) ? (baseUri + path) : path.value();
    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(url);
    return uriBuilder.buildAndExpand(pathParams).toString();
  }

  /**
   * Adds the query params.
   *
   * @param url
   *          the url
   * @param paramKey
   *          the param key
   * @param paramValue
   *          the param value
   * @return the string
   */
  public static String addQueryParams(String url, String paramKey, String paramValue) {
    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(url);
    return uriBuilder.queryParam(paramKey, paramValue).build().toString();
  }

  /**
   * Gets the annotated name.
   *
   * @param <T>
   *          the generic type
   * @param fieldName
   *          the field name
   * @param parentClass
   *          the parent class
   * @return the annotated name
   */
  public static <T> String getAnnotatedName(String fieldName, Class<T> parentClass) {
    try {
      Field field = parentClass.getDeclaredField(fieldName);
      return field.isAnnotationPresent(JsonProperty.class)
          ? field.getAnnotation(JsonProperty.class).value()
          : field.getName();
    } catch (NoSuchFieldException nsfe) {
      LOGGER.debug("Field with name {} does not exists", fieldName);
      if (parentClass.getSuperclass() != Object.class) {
        return getAnnotatedName(fieldName, parentClass.getSuperclass());
      }
    }
    return fieldName;
  }

  /**
   * Gets the json property path.
   *
   * @param propertyPath
   *          the property path
   * @param parentClass
   *          the parent class
   * @return the json property path
   */
  public static String getJsonPropertyPath(String propertyPath, Object parentClass) {
    if (propertyPath.contains(".")) {
      String fieldName = propertyPath.substring(propertyPath.lastIndexOf('.') + 1);
      String prefix = propertyPath.split(fieldName)[0];
      return prefix + getAnnotatedName(fieldName, parentClass.getClass());
    } else {
      return getAnnotatedName(propertyPath, parentClass.getClass());
    }
  }

  /**
   * Adds the query params.
   *
   * @param url
   *          the url
   * @param params
   *          the params
   * @return the string
   */
  public static String addQueryParams(String url, MultiValueMap<String, String> params) {
    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(url);
    return uriBuilder.queryParams(params).build().toString();
  }

  /**
   * Gets the query parameter.
   *
   * @param context
   *          the context
   * @param serviceUrl
   *          the service url
   * @return the query parameter
   */
  public static Mono<String> getQueryParameter(ServiceHandlerContext context, String serviceUrl) {
    MultiValueMap<String, String> parameters = context.getAllParameters();
    if (!parameters.isEmpty()) {
      List<String> params = QueryParameter.getEnumValues();
      boolean parameterdetail = params.stream().anyMatch(p -> parameters.keySet().contains(p));
      if (!parameterdetail)
        return Mono
            .error(new CmsException(HttpStatus.BAD_REQUEST.value(), ErrorConstants.INVALID_QUERY));
    }
    serviceUrl = CommonUtils.addQueryParams(serviceUrl, parameters);
    return Mono.just(serviceUrl);
  }

  /**
   * Gets the policy groups.
   *
   * @param config
   *          the config
   * @return the policy groups
   */
  public static String getPolicyGroups(Configuration config) {
    @SuppressWarnings("unchecked")
    List<String> policyGroup = (List<String>) config.get(CmsConstants.POLICY_GROUPS);
    String result = null;
    if (policyGroup != null) {
      result = policyGroup.stream().filter(policy -> policy.startsWith(CmsConstants.TITLE_REGEX))
          .findFirst().orElse(null);
    }
    return result;
  }

  /**
   * Modified self link.
   *
   * @param productId
   *          the product id
   * @param productVersion
   *          the product version
   * @return the mono
   */
  public static String modifiedSelfLink(String productId, String productVersion, UriEnum url) {
    Map<String, String> pathValues = new HashMap<>();
    pathValues.put(CmsConstants.ID, productId);
    pathValues.put(CmsConstants.VER, productVersion);
    return generateHref(url.value(), pathValues);
  }

  /**
   * Generate href.
   *
   * @param path
   *          the path
   * @param pathValues
   *          the path values
   * @return the string
   */
  private static String generateHref(String path, Map<String, String> pathValues) {
    for (Map.Entry<String, String> pathEntrySet : pathValues.entrySet()) {
      path = StringUtils.replace(path,
          CmsConstants.OPEN_BRACE + pathEntrySet.getKey() + CmsConstants.CLOSE_BRACE,
          pathEntrySet.getValue());
    }
    return path;
  }

  /**
   * Creates the learning model.
   *
   * @param learningModel
   *          the learning model
   * @return the learning model
   */
  public static LearningModel createLearningModel(String learningModel) {
    String[] learningModelDetails = learningModel.split(CmsConstants.DOUBLE_COLON_SEPARATOR);
    LearningModel model = new LearningModel();
    model.setId(learningModelDetails[0]);
    model.setBssVer(Integer.valueOf(learningModelDetails[1]));
    model.setVer(learningModelDetails[2]);
    return model;
  }

  /**
   * Gets the content type.
   *
   * @param context
   *          the context
   * @return the content type
   */
  public static String getContentType(ServiceHandlerContext context) {
    return context.getHeader("Accept").stream()
        .filter(medType -> medType.equals(MediaType.APPLICATION_STREAM_JSON_VALUE)).findFirst()
        .orElse(CmsConstants.CONTENT_TYPE_HAL);
  }
}
