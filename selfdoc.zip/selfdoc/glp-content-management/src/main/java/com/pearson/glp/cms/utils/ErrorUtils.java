/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.utils;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.exception.CmsException;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.core.errors.PlatformError;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.base.ServiceRuntimeException;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.core.utils.exception.PlatformException;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;
import com.pearson.glp.crosscutting.isc.client.sync.model.RequestValidationException;

import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

/**
 * The Class ErrorUtils.
 */
public final class ErrorUtils {

  /** The Constant LOGGER. */
  private static final Logger LOGGER = LoggerFactory.getLogger(ErrorUtils.class);

  /**
   * Instantiates a new error utils.
   */
  private ErrorUtils() {
    // no-argument constructor
  }

  /**
   * Gets the error model from isc exception.
   *
   * @param throwable
   *          the throwable
   * @return the error model from isc exception
   */
  public static CustomErrorMessage getErrorModelFromException(final Throwable throwable) {
    CustomErrorMessage errorModel = new CustomErrorMessage();
    if (throwable instanceof IscSyncRuntimeException) {
      errorModel = convertIscMessageToModel(
          ((IscSyncRuntimeException) throwable).getHttpStatusCode(), throwable.getMessage(),
          errorModel);
    } else if (throwable instanceof RequestValidationException) {
      errorModel = convertIscMessageToModel(HttpStatus.BAD_REQUEST.value(), throwable.getMessage(),
          errorModel);
    } else if (throwable instanceof CmsException) {
      errorModel = new CustomErrorMessage(((CmsException) throwable).getErrorCode(),
          ((CmsException) throwable).getErrorMsg());
    } else if (throwable instanceof DecodingException
        || (throwable instanceof ServiceRuntimeException)) {
      errorModel = new CustomErrorMessage(HttpStatus.BAD_REQUEST.value(), throwable.getMessage());
    } else if (throwable instanceof PlatformException) {
      errorModel = new CustomErrorMessage(((PlatformException) throwable).getHttpStatus(),
          getErrorMessage(((PlatformException) throwable).getErrors()));
    }
    return errorModel;
  }

  /**
   * Gets the error message.
   *
   * @param errors
   *          the errors
   * @return the error message
   */
  private static String getErrorMessage(List<PlatformError> errors) {
    return String.join(CmsConstants.COMMA,
        errors.stream().map(PlatformError::getMessage).collect(Collectors.toList()));
  }

  /**
   * Convert isc message to model.
   *
   * @param message
   *          the message
   * @param errorModel
   * @return the custom error message
   */
  private static CustomErrorMessage convertIscMessageToModel(int httpStatus, String message,
      CustomErrorMessage errorModel) {
    try {
      int modelIndex = message.indexOf(CmsConstants.COLON) + 1;
      errorModel = CommonUtils.convertJsonStringToObject(message.substring(modelIndex),
          CustomErrorMessage.class);
      if (errorModel == null || errorModel.getStatus() != httpStatus) {
        errorModel = new CustomErrorMessage(httpStatus);
      }
    } catch (IndexOutOfBoundsException ex) {
      // do nothing
    }
    return errorModel;
  }

  /**
   * Handle cms error.
   *
   * @param ex
   *          the ex
   * @return the mono
   */
  public static Mono<ServiceHandlerResponse> handleCmsError(Throwable ex) {
    LOGGER.error(LoggingConstants.EXCEPTION_OCCURED, ex);
    CustomErrorMessage errorPayload = new CustomErrorMessage(ex);
    return JsonPayloadServiceResponse.withStatus(HttpStatus.valueOf(errorPayload.getStatus()))
        .setPayload(errorPayload);
  }

  /**
   * Handle server response error.
   *
   * @param ex
   *          the ex
   * @return the mono
   */
  public static Mono<ServerResponse> handleServerResponseError(Throwable ex) {
    LOGGER.error(LoggingConstants.EXCEPTION_OCCURED, ex);
    CustomErrorMessage errorPayload = new CustomErrorMessage(ex);
    return ServerResponse.status(errorPayload.getStatus())
        .body(BodyInserters.fromObject(errorPayload));
  }
}
