/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import java.util.Optional;

import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.beanvalidation.groups.GroupAssessmentItemResource;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.resource.response.GLPResource;
import com.pearson.glp.cms.dto.resource.response.ResourceWithStatus;
import com.pearson.glp.cms.handler.ResourceHandler;
import com.pearson.glp.cms.utils.CommonUtilsTest;

/**
 * The Class AssessmentItemResourcesBase.
 */
public abstract class AssessmentItemResourcesBase extends ProducerBase {

  /** The resource handler. */
  @MockBean
  public ResourceHandler resourceHandler;

  @Override
  public void setUp() {
    super.setUp();

    Mockito
        .when(resourceHandler.createResources(Mockito.any(),
            Mockito.eq(Optional.of(GroupAssessmentItemResource.class))))
        .thenReturn(ServerResponse.status(HttpStatus.MULTI_STATUS)
            .header(CmsConstants.CONTENT_TYPE, CmsConstants.CONTENT_TYPE_HAL)
            .body(BodyInserters.fromObject(CommonUtilsTest.convertJsonToObject(
                JsonFileConstants.POST_ASSESS_RESOURCES_RESPONSE, ResourceWithStatus.class))));

    Mockito.when(resourceHandler.getSpecificVersionOfResource(Mockito.any(), Mockito.anyString()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_ASSESS_RESOURCES_RESPONSE, GLPResource.class));

    Mockito.when(resourceHandler.getResourceById(Mockito.any(), Mockito.anyString()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_ASSESS_RESOURCES_RESPONSE, GLPResource.class));
  }
}
