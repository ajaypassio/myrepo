/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.dto.learningmodel.response.BulkLearningModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.handler.AssetModelHandler;

import io.restassured.RestAssured;

/**
 * The Class AssetModelBase.
 */
public abstract class AssetModelBase extends ProducerBase {
  /** The asset model handler. */
  @MockBean
  private AssetModelHandler assetModelHandler;

  /**
   * This method is used to mock the methods call of asset model handler.
   */
  public void setUp() {
    RestAssured.port = this.port;
    RestAssured.baseURI = "http://localhost";

    Mockito.when(assetModelHandler.createAggregateModel(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_AGGREGATE_MODELS_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createInstructionModel(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_INSTRUCTION_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createNarrativeModel(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_NARRATIVE_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createAssessmentModel(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_ASSESSMENT_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createAssessmentItemModel(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_ASSESSMENT_ITEM_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createInstructionModelsVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_NEW_VERSION_OF_INSTRUCTION_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createAggregateModelsVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_NEW_VERSION_OF_AGGREGATE_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createNarrativeModelsVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_NARRATIVE_MODEL_VERSION_RESPONSE, GLPAssetModel.class));
    Mockito.when(assetModelHandler.getAssetModels(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.GET_ASSET_MODELS_RESPONSE, BulkLearningModels.class));

    Mockito.when(assetModelHandler.getAssetModelById(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.GET_ASSET_MODEL_BY_ID_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.getAssetModelsVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_ASSET_MODELS_VERSIONS_RESPONSE, BulkLearningModels.class));

    Mockito.when(assetModelHandler.getAssetModelByVersionId(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_ASSET_MODEL_BY_VERSION_ID_RESPONSE, GLPAssetModel.class));

    Mockito.when(assetModelHandler.createAssetModel(Mockito.any(), Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_ASSESSMENT_MODEL_RESPONSE, GLPAssetModel.class));

  }
}
