/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.handler.PrimitiveAssetHandler;

/**
 * The Class NarrativesBase.
 */
public abstract class NarrativesBase extends ProducerBase {

  /** The primitive asset handler. */
  @MockBean
  public PrimitiveAssetHandler primitiveAssetHandler;

  /**
   * This method is used to mock the methods call of narratives handler.
   */
  @Override
  public void setUp() {
    super.setUp();

    Mockito.when(primitiveAssetHandler.getNarrativesByIdAndVersion(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_NARRATIVES_BY_ID_RESPONSE, GLPLearningAsset.class));

    Mockito.when(primitiveAssetHandler.getNarrativesVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_NARRATIVES_ALL_VERSIONS_RESPONSE, LearningAssetVersions.class));

    Mockito.when(primitiveAssetHandler.addNarrativesVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_NARRATIVES_NEW_VERSION_RESPONSE, AssetWithStatus.class));

    Mockito.when(primitiveAssetHandler.getNarrativeById(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_NARRATIVES_BY_ID_RESPONSE, GLPLearningAsset.class));

    Mockito.when(primitiveAssetHandler.getNarratives(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.GET_BULK_NARRATIVES_RESPONSE, BulkAssets.class));

    Mockito.when(primitiveAssetHandler.addNarratives(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.MULTI_STATUS,
            JsonFileConstants.POST_BULK_NARRATIVES_RESPONSE, AssetWithStatus.class));
  }
}
