/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.test.rule.KafkaEmbedded;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.pearson.glp.cms.ContentManagementServiceApp;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.testconfig.CouchbaseTestConfiguration;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceHandlerResponse;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;

import io.prometheus.client.CollectorRegistry;
import io.restassured.RestAssured;
import net.minidev.json.JSONArray;
import reactor.core.publisher.Mono;

/**
 * The Class ProducerBase.
 * 
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {
    ContentManagementServiceApp.class, CouchbaseTestConfiguration.class })
@ActiveProfiles("testing")
public abstract class ProducerBase {

  /** The port. */
  @LocalServerPort
  protected int port;

  /** The isc sync client. */
  @MockBean
  protected IscSyncClient iscSyncClient;

  /** The web client. */
  @MockBean
  protected WebClient webClient;

  /** The request headers spec. */
  @SuppressWarnings("rawtypes")
  @MockBean
  public RequestHeadersSpec requestHeadersSpec;

  /** The request body spec. */
  @MockBean
  public RequestBodySpec requestBodySpec;

  /** The request body uri spec. */
  @MockBean
  public RequestBodyUriSpec requestBodyUriSpec;

  /** The web test client. */
  @Autowired
  public WebTestClient webTestClient;

  /** The context path. */
  @Value("${server.contextPath}")
  public String contextPath;

  /** The collector registry. */
  @MockBean
  private CollectorRegistry collectorRegistry;

  /** The Constant embeddedKafka. */
  @ClassRule
  public static final KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, 1, "messages");

  /**
   * Before class.
   */
  @BeforeClass
  public static void beforeClass() {
    System.setProperty("spring.kafka.bootstrap-servers", embeddedKafka.getBrokersAsString());
    System.setProperty("spring.cloud.stream.kafka.binder.zkNodes",
        embeddedKafka.getZookeeperConnectionString());
  }

  /**
   * Sets the up.
   */
  @Before
  public void setUp() {
    RestAssured.port = this.port;
    RestAssured.baseURI = "http://localhost";
  }

  /**
   * Assert that value is A string.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAString(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.String.class);
    }
  }

  /**
   * Assert that value is A integer.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAInteger(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.Integer.class);
    }
  }

  /**
   * Assert that value is A bool.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsABool(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.Boolean.class);
    }
  }

  /**
   * Assert that value is long.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsLong(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.lang.Long.class);
    }
  }

  /**
   * Assert that value is A map.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAMap(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.util.Map.class);
    }
  }

  /**
   * Assert that value is A list.
   *
   * @param val
   *          the val
   */
  public void assertThatValueIsAList(JSONArray val) {
    for (Object o : val) {
      Assertions.assertThat(o).isInstanceOf(java.util.List.class);
    }
  }

  /**
   * Gets the mocked response.
   *
   * @param httpStatus
   *          the http status
   * @param jsonFile
   *          the json file
   * @return the mocked response
   */
  protected Mono<ServiceHandlerResponse> getMockedResponse(HttpStatus httpStatus, String jsonFile) {
    return JsonPayloadServiceResponse.withStatus(httpStatus)
        .setPayload(CommonUtilsTest.convertJsonToObject(jsonFile, CustomErrorMessage.class));
  }

  /**
   * Gets the mocked response.
   *
   * @param <T>
   *          the generic type
   * @param httpStatus
   *          the http status
   * @param jsonFile
   *          the json file
   * @param classType
   *          the class type
   * @return the mocked response
   */
  public <T> Mono<ServiceHandlerResponse> getMockedResponse(HttpStatus httpStatus, String jsonFile,
      Class<T> classType) {
    return JsonPayloadServiceResponse.withStatus(httpStatus)
        .setHeader(CmsConstants.CONTENT_TYPE, CmsConstants.CONTENT_TYPE_HAL)
        .setPayload(CommonUtilsTest.convertJsonToObject(jsonFile, classType));
  }

  /**
   * Gets the created response.
   *
   * @param <T>
   *          the generic type
   * @param jsonFile
   *          the json file
   * @param classType
   *          the class type
   * @return the created response
   */
  public <T> Mono<ServerResponse> getCreateServerResponse(String jsonFile, Class<T> classType) {
    return ServerResponse.status(HttpStatus.MULTI_STATUS)
        .header(HttpHeaders.CONTENT_TYPE, CmsConstants.CONTENT_TYPE_HAL)
        .body(BodyInserters.fromObject(CommonUtilsTest.convertJsonToObject(jsonFile, classType)));
  }

  /**
   * Mock web client call.
   */
  @SuppressWarnings("unchecked")
  protected void mockWebClientCall() {
    Mockito.when(webClient.post()).thenReturn(requestBodyUriSpec);
    Mockito.when(requestBodyUriSpec.uri(Mockito.anyString())).thenReturn(requestBodySpec);
    Mockito.when(requestBodySpec.header(Mockito.any(), Mockito.any())).thenReturn(requestBodySpec);
    Mockito.when(requestBodySpec.contentType(Mockito.any())).thenReturn(requestBodySpec);
    Mockito.when(requestBodySpec.body(Mockito.any())).thenReturn(requestHeadersSpec);
    Mockito.when(requestHeadersSpec.accept(Mockito.any())).thenReturn(requestHeadersSpec);
  }
}
