/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.handler.PolicyHandler;
import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.dto.learningasset.response.ProductStateTransition;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.handler.ProductHandler;
import com.pearson.glp.core.handlers.base.ServiceException;

import io.restassured.RestAssured;

import java.util.HashMap;

/**
 * The Class ProductBase.
 *
 * @author nikhil.gupta4
 */
public abstract class ProductBase extends ProducerBase {

  /**
   * The product handler.
   */
  @MockBean
  private ProductHandler productHandler;

  /** The policy handler. */
  @MockBean
  private PolicyHandler policyHandler;

  /**
   * setProductBaseMockData.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setProductBaseMockData() throws ServiceException {

    RestAssured.port = this.port;
    RestAssured.baseURI = "http://localhost";

    Mockito.when(productHandler.getProductByIdAndVersion(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.PRODUCT_BY_ID_AND_VERSION_RESPONSE_JSON, GLPLearningAsset.class));

    Mockito.when(productHandler.getProductVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.PRODUCTS_VERSIONS_RESPONSE_JSON, LearningAssetVersions.class));

    Mockito.when(productHandler.postProductVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.PRODUCT_NEW_VERSION_RESPONSE_JSON, GLPLearningAsset.class));

    Mockito.when(productHandler.getProductById(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.GET_PRODUCT_BY_ID_JSON, GLPLearningAsset.class));

    Mockito.when(productHandler.getProduct(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK, JsonFileConstants.PRODUCTS, BulkAssets.class));

    Mockito.when(productHandler.postProduct(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.CREATED, JsonFileConstants.PRODUCT_POST, GLPLearningAsset.class));

    Mockito.when(productHandler.postProductStateTransition(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_PRODUCT_STATE_TRANSITION_RESPONSE_JSON,
            ProductStateTransition.class));

    Mockito.when(productHandler.getProductStateTransition(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_STATE_TRANSITION_RESPONSE, ProductStateTransition.class));

    Mockito.when(productHandler.putProductStatus(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.PRODUCT_STATUS_RESPONSE, ProductStateTransition.class));

    Mockito.when(productHandler.getProductStatus(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.PRODUCT_STATUS_RESPONSE, ProductStateTransition.class));

    Mockito.when(productHandler.getProductAssessmentTypes(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_ASSESSMENT_TYPES_RESPONSE, GLPLearningAsset.class));

    Mockito.when(productHandler.getProductAssetTypes(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_ASSET_TYPES_RESPONSE, ProductAssetTypes.class));

    Mockito.when(productHandler.mapProductAssessmentTypes(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_MAP_ASSESSMENT_TYPE_RESPONSE_JSON, GLPLearningAsset.class));

    Mockito.when(productHandler.postProductCategoryWeights(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_PRODUCT_CATEGORY_WEIGHTS_RESPONSE, GLPLearningPolicy.class));

    Mockito.when(policyHandler.getResolvedPolicies(Mockito.any(), Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_CATEGORY_WEIGHTS_RESPONSE, HashMap.class));
    Mockito.when(policyHandler.postProductScoringPolicy(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED, TestingConstants.SCORING_POLICY_RESPONSE,
            GLPLearningPolicy.class));

    Mockito.when(policyHandler.getProductScoringPolicy(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.GET_SCORING_POLICY_RESPONSE, Object.class));

  }
}
