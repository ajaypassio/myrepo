/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import java.util.HashMap;

import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.dto.learningmodel.response.BulkProductModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.handler.PolicyHandler;
import com.pearson.glp.cms.handler.ProductModelHandler;

/**
 * The Class ProductModelsBase.
 */
public abstract class ProductModelBase extends ProducerBase {

  /** The productModelHandler handler. */
  @MockBean
  public ProductModelHandler productModelHandler;

  /** The policy handler. */
  @MockBean
  private PolicyHandler policyHandler;

  /**
   * This method is used to mock the methods call of product model handler.
   */
  @Override
  public void setUp() {
    super.setUp();
    Mockito.when(productModelHandler.getProductModelByVersionId(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_SPECIFIC_VERSION_OF_PRODUCT_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(productModelHandler.getProductModelsVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_MODEL_ALL_VERSION_RESPONSE, BulkProductModels.class));

    Mockito.when(productModelHandler.createProductModelsVersions(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_NEW_PRODUCT_MODEL_VERSION_RESPONSE, GLPAssetModel.class));

    Mockito.when(productModelHandler.getProductModelById(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_MODEL_BY_ID_RESPONSE, GLPAssetModel.class));

    Mockito.when(productModelHandler.getProductModels(Mockito.any())).thenReturn(getMockedResponse(
        HttpStatus.OK, JsonFileConstants.GET_BULK_PRODUCT_MODEL_RESPONSE, BulkProductModels.class));

    Mockito.when(productModelHandler.createProductModel(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_BULK_PRODUCT_MODEL_RESPONSE, GLPAssetModel.class));

    Mockito.when(policyHandler.postProductModelScoringPolicy(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_PRODUCT_MODEL_SCORING_POLICY_RESPONSE_JSON,
            GLPLearningPolicy.class));

    Mockito.when(policyHandler.getProductModelScoringPolicy(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_MODEL_SCORING_POLICY_RESPONSE_JSON, HashMap.class));

    Mockito.when(productModelHandler.postProductModelCategoryWeights(Mockito.any(), Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.CREATED,
            JsonFileConstants.POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_RESPONSE,
            GLPLearningPolicy.class));

    Mockito.when(productModelHandler.getResolvedPolicies(Mockito.any(), Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_MODEL_CATEGORY_WEIGHTS_RESPONSE, HashMap.class));

    Mockito.when(productModelHandler.getProductModels(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.OK,
            JsonFileConstants.GET_PRODUCT_MODEL_BY_COMMERCIAL_DETAILS_RESPONSE,
            BulkProductModels.class));
  }

}
