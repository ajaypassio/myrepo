/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.handler.PolicyHandler;
import com.pearson.glp.core.handlers.base.ServiceException;

/**
 * The Class ProductModelsRenameLearningAidsError404Base.
 */
public abstract class ProductModelsRenameLearningAidsError404Base extends ProducerBase {

  /** The policy handler. */
  @MockBean
  private PolicyHandler policyHandler;

  /**
   * setRenameLearningAidsError404BaseMockData.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setRenameLearningAidsBaseMockData() {

    super.setUp();
    Mockito.when(policyHandler.createProductModelLearningAids(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.NOT_FOUND, JsonFileConstants.NOT_FOUND_RESPONSE));

    Mockito.when(policyHandler.getProductModelLearningAids(Mockito.any()))
        .thenReturn(getMockedResponse(HttpStatus.NOT_FOUND, JsonFileConstants.NOT_FOUND_RESPONSE));
  }

}