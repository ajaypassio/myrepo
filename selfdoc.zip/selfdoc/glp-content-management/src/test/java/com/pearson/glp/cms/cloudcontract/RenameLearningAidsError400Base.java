/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract;

import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.handler.PolicyHandler;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.core.handlers.rest.JsonPayloadServiceResponse;

/**
 * The Class RenameLearningAidsError400Base.
 */
public abstract class RenameLearningAidsError400Base extends ProducerBase {

  /** The policy handler. */
  @MockBean
  private PolicyHandler policyHandler;

  /**
   * setRenameLearningAidsError400BaseMockData.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Before
  public void setRenameLearningAidsBaseMockData() throws ServiceException {

    super.setUp();

    Mockito.when(policyHandler.createProductLearningAids(Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST)
            .setPayload(CommonUtilsTest.convertJsonToObject(JsonFileConstants.BAD_REQUEST_RESPONSE,
                CustomErrorMessage.class)));

    Mockito.when(policyHandler.getProductLearningAids(Mockito.any()))
        .thenReturn(JsonPayloadServiceResponse.withStatus(HttpStatus.BAD_REQUEST)
            .setPayload(CommonUtilsTest.convertJsonToObject(JsonFileConstants.BAD_REQUEST_RESPONSE,
                CustomErrorMessage.class)));
  }
}