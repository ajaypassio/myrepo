/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningmodel.request.AssetModelPayload;
import com.pearson.glp.cms.dto.learningmodel.response.BulkLearningModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;

/**
 * The Class AssetModelConsumerTest.
 */
@Ignore
public class AssetModelConsumerTest extends LPBConsumerBase {

  /**
   * Instantiates a new asset model consumer test.
   */
  public AssetModelConsumerTest() {
    super();
  }

  /**
   * Create instruction model test.
   */
  @Test
  public void createInstructionModelTest() {

    AssetModelPayload requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_INSTRUCTION_MODEL_REQUEST, AssetModelPayload.class);
    webTestClient.post().uri(UriEnum.URI_ASSET_MODELS.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus().isCreated()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.LANGUAGE, CmsConstants.TAGS,
                CmsConstants.LABEL, CmsConstants.EXPIRESON));
  }

  /**
   * Create aggregate model test.
   */
  @Test
  public void createAggregateModelTest() {

    AssetModelPayload requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_AGGREGATE_MODELS_REQUEST, AssetModelPayload.class);
    webTestClient.post().uri(UriEnum.URI_ASSET_MODELS.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus().isCreated()
        .expectBody(GLPAssetModel.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrPropertiesExcept());
  }

  /**
   * Create instruction models versions test.
   */
  @Test
  public void createInstructionModelsVersionsTest() {

    AssetModelPayload requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_INSTRUCTION_MODEL_REQUEST, AssetModelPayload.class);
    webTestClient.post().uri(UriEnum.URI_ASSET_MODEL_VERSIONS.value(), CmsConstants.PARAM_ASSET_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus().isCreated()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.ERROR));
  }

  /**
   * Create aggregate models versions test.
   */

  @Test
  public void createAggregateModelsVersionsTest() {

    AssetModelPayload requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST, AssetModelPayload.class);
    webTestClient.post().uri(UriEnum.URI_ASSET_MODEL_VERSIONS.value(), CmsConstants.PARAM_ASSET_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus().isCreated()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.ERROR));
  }

  /**
   * Gets the asset models test.
   *
   * @return the asset models response
   */
  @Test
  public void getAssetModelsTest() {
    webTestClient.get().uri(UriEnum.URI_ASSET_MODELS.value()).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkLearningModels.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept());

  }

  /**
   * Gets the asset model by id test.
   *
   * @return the asset model by id test
   */

  @Test
  public void getAssetModelByIdTest() {
    webTestClient.get().uri(UriEnum.URI_GET_ASSET_MODEL_BY_ID.value(), CmsConstants.PARAM_ASSET_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPAssetModel.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrPropertiesExcept());

  }

  /**
   * Gets the asset models versions test.
   *
   * @return the asset models versions test
   */

  @Test
  public void getAssetModelsVersionsTest() {
    webTestClient.get().uri(UriEnum.URI_ASSET_MODEL_VERSIONS.value(), CmsConstants.PARAM_ASSET_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkLearningModels.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrPropertiesExcept());
  }

  /**
   * Gets the asset model by version id test.
   *
   * @return the asset model by versions id test
   */

  @Test
  public void getAssetModelByVersionIdTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_ASSET_MODEL_SPECIFIC_VERSION.value(), CmsConstants.PARAM_ASSET_ID,
            CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPAssetModel.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrPropertiesExcept());
  }
}
