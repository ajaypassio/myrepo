/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningpolicy.request.PolicyPayload;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.pearson.glp.cms.constant.JsonFileConstants.DELIVERY_POLICY_REQUEST;
import static com.pearson.glp.cms.constant.JsonFileConstants.ENGAGEMENT_POLICY_REQUEST;
import static com.pearson.glp.cms.constant.JsonFileConstants.EVALUATION_POLICY_REQUEST;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LAD_GET_POLICIES;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LAD_GET_POLICIES_INVALID;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LAD_LEARNINGAIDS_POLICY_REQUEST;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LAE_GET_POLICIES;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LAE_GET_POLICIES_INVALID;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LEE_GET_POLICIES;
import static com.pearson.glp.cms.constant.TestingConstants.URI_LEE_GET_POLICY_INVALID;

/**
 * The Class EngagementConsumerTest.
 *
 * @author shubham.bansal
 */
public class EngagementConsumerTest extends EngagementConsumerBase {

  /**
   * Instantiates a new engagement consumer test.
   */
  public EngagementConsumerTest() {
    super();
  }

  /**
   * Post delivery policy test.
   */
  @Test
  public void postDeliveryPolicyTest() {
    List<HashMap<String, Object>> postDeliveryPolicyRequest = Arrays
        .asList(CommonUtilsTest.convertJsonToObject(DELIVERY_POLICY_REQUEST, HashMap.class));

    ladWebTestClient.post().uri(UriEnum.URI_POST_POLICIES.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(postDeliveryPolicyRequest)).exchange().expectStatus()
        .isCreated().expectBody(GLPLearningAsset[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()));
  }

  /**
   * Post delivery Learning Aids policy test.
   */
  @Test
  public void postLearningAidsDeliveryPolicyTest() {

    List<HashMap<String, Object>> postDeliveryPolicyRequest = CommonUtilsTest
        .convertJsonToObject(URI_LAD_LEARNINGAIDS_POLICY_REQUEST, ArrayList.class);
    ladWebTestClient.post().uri(UriEnum.URI_POST_POLICIES.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(postDeliveryPolicyRequest)).exchange().expectStatus()
        .isCreated().expectBody(GLPLearningAsset[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()));
  }

  /**
   * Get delivery policy test.
   */
  @Test
  @Ignore
  public void getDeliveryPolicyTest() {

    ladWebTestClient.get().uri(URI_LAD_GET_POLICIES).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isOk().expectBody(GLPLearningPolicy[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()[0])
            .hasNoNullFieldsOrPropertiesExcept("resourceType", "createdBy", "expiresOn", "errors"));

  }

  /**
   * Get delivery policy test error.
   */

  @Test
  public void getDeliveryPolicyTestError() {

    ladWebTestClient.get().uri(URI_LAD_GET_POLICIES_INVALID).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().is4xxClientError();

  }

  /**
   * Post engagement policy test.
   */
  @Test
  public void postEngagementPolicyTest() {
    List<HashMap<String, Object>> postEngagementPolicyRequest = Arrays
        .asList(CommonUtilsTest.convertJsonToObject(ENGAGEMENT_POLICY_REQUEST, HashMap.class));

    leeWebTestClient.post().uri(UriEnum.URI_POST_POLICIES.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(postEngagementPolicyRequest)).exchange().expectStatus()
        .isCreated().expectBody(GLPLearningAsset[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()));
  }

  /**
   * Get engagement policy test.
   */
  @Test
  public void getEngagementPolicyTest() {

    leeWebTestClient.get().uri(URI_LEE_GET_POLICIES).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isOk().expectBody(GLPLearningPolicy[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()[0])
            .hasNoNullFieldsOrPropertiesExcept("resourceType", "createdBy", "expiresOn", "errors",
                "status"));

  }

  /**
   * Get engagement policy test error.
   */
  @Test
  public void getEngagementPolicyTestError() {

    leeWebTestClient.get().uri(URI_LEE_GET_POLICY_INVALID).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().is4xxClientError();

  }

  /**
   * Post evaluation policy test.
   */
  @Test
  public void postEvaluationPolicyTest() {
    List<HashMap<String, Object>> postEvaluationPolicyRequest = Arrays
        .asList(CommonUtilsTest.convertJsonToObject(EVALUATION_POLICY_REQUEST, HashMap.class));

    laeWebTestClient.post().uri(UriEnum.URI_POST_POLICIES.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(postEvaluationPolicyRequest)).exchange().expectStatus()
        .isCreated().expectBody(GLPLearningAsset[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()));
  }

  /**
   * Get evaluation policy test.
   */
  @Test
  @Ignore
  public void getEvaluationPolicyTest() {

    laeWebTestClient.get().uri(URI_LAE_GET_POLICIES).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().isOk().expectBody(GLPLearningPolicy[].class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody()[0])
            .hasNoNullFieldsOrPropertiesExcept("resourceType", "createdBy", "expiresOn", "errors"));

  }

  /**
   * Get evaluation policy test error.
   */
  @Test
  public void getEvaluationPolicyTestError() {

    laeWebTestClient.get().uri(URI_LAE_GET_POLICIES_INVALID).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().is4xxClientError();

  }

  /**
   * Get evaluation product policy gradebook category test.
   */
  @Test
  @Ignore
  public void getEvaluationProductPolicyGradebookCategoryTest() {
    laeWebTestClient.get().uri(UriEnum.URI_LAE_GET_GRADEBOOK_POLICY_PRODUCT.value())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningPolicy.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Get evaluation product policy gradebook category test error.
   */
  @Test
  public void getEvaluationProductPolicyGradebookCategoryTestError() {
    laeWebTestClient.get().uri(UriEnum.URI_LAE_GET_POLICIES_INVALID.value())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound();
  }

  /**
   * Post evaluation policy product gradebook category test.
   */
  @Test
  @Ignore
  public void postEvaluationPolicyProductGradebookCategoryTest() {
    List<PolicyPayload> requestPayload = Arrays.asList(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_POLICY_PRODUCT_GRADEBOOK_JSON, PolicyPayload.class));
    laeWebTestClient.post().uri(UriEnum.URI_POST_POLICIES.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestPayload)).exchange().expectStatus().isCreated()
        .expectBody(GLPLearningPolicy[].class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()[0]).hasNoNullFieldsOrProperties());
  }
}
