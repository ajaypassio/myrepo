/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import java.time.Duration;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.cloud.contract.stubrunner.spring.StubRunnerProperties;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;

/**
 * The Class LAPConsumerBase.
 */
@RunWith(SpringRunner.class)
@ActiveProfiles("testing")
@AutoConfigureStubRunner(stubsMode = StubRunnerProperties.StubsMode.CLASSPATH, ids = "com.pearson.glp:lap:0.0.1-SNAPSHOT:stubs:8082")
public abstract class LAPConsumerBase {

  /** The web test client. */
  protected WebTestClient webTestClient;

  /**
   * Setup.
   */
  @Before
  public void setup() {
    webTestClient = WebTestClient.bindToServer().baseUrl("http://localhost:8082/lap").build();
    webTestClient = webTestClient.mutate().responseTimeout(Duration.ofMillis(40000)).build();
  }
}
