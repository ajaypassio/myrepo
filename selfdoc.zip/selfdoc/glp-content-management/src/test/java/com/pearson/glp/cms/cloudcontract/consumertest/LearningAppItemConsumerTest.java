/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import java.util.Map;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetsRequest;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceException;

/**
 * The Class LearningAppItemConsumerTest.
 * 
 * @author sourabh.aggarwal
 */
public class LearningAppItemConsumerTest extends LAPConsumerBase {

  /**
   * Instantiates a new learning app item consumer test.
   */
  public LearningAppItemConsumerTest() {
    super();
  }

  /**
   * Gets the learning app item specific version test.
   *
   * @return the learning app item specific version test
   */
  @Test
  public void getLearningAppItemSpecificVersionTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_LEARNING_APP_ITEM_SPECIFIC_VERSION.value(),
            TestingConstants.PARAM_LEARNING_APP_ITEM_ID,
            TestingConstants.PARAM_LEARNING_APP_ITEM_VER)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Gets the learning app item by id test.
   *
   * @return the learning app item by id test
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getLearningAppItemByIdTest() throws ServiceException {
    webTestClient.get()
        .uri(UriEnum.URI_GET_LEARNING_APP_ITEM_BY_ID.value(),
            TestingConstants.PARAM_LEARNING_APP_ITEM_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk().returnResult(Map.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }

  /**
   * Post bulk learning app item test.
   */
  @Test
  public void postBulkLearningAppItemTest() {
    AssetsRequest requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_BULK_LEARNING_APP_ITEM_REQUEST, AssetsRequest.class);
    webTestClient.post().uri(UriEnum.URI_LEARNING_APP_ITEMS.value())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS).expectBody(AssetWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.ERROR));
  }
}