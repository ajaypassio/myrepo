/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.resource.request.ResourcesRequest;
import com.pearson.glp.cms.dto.resource.response.GLPResource;
import com.pearson.glp.cms.dto.resource.response.ResourceWithStatus;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;

/**
 * The Class LearningAppResourcesConsumerTest.
 *
 * @author sagar.agarwal
 */
public class LearningAppResourcesConsumerTest extends LAPConsumerBase {

  /**
   * Instantiates a new learning app resources consumer test.
   */
  public LearningAppResourcesConsumerTest() {
    super();
  }

  /**
   * Gets the learning app resources by ID test.
   *
   * @return the learning app resources by ID test
   */
  @Test
  public void getLearningAppResourcesByIDTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_RESOURCE_BY_ID.value(),
            TestingConstants.PARAM_LEARNING_APP_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.LANGUAGE, CmsConstants.TAGS,
                CmsConstants.LABEL, CmsConstants.EXPIRESON));
  }

  /**
   * Gets the learning app resources by ID and version test.
   *
   * @return the learning app resources by ID and version test
   */
  @Test
  public void getLearningAppResourcesByIDAndVersionTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_RESOURCE_SPECIFIC_VERSION.value(),
            TestingConstants.PARAM_LEARNING_APP_RESOURCE_ID,
            TestingConstants.PARAM_LEARNING_APP_RESOURCE_VER)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.LANGUAGE, CmsConstants.TAGS,
                CmsConstants.LABEL, CmsConstants.EXPIRESON));
  }

  /**
   * Post learning app resources test.
   */
  @Test
  public void postLearningAppResourcesTest() {
    ResourcesRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_LEARNING_APP_RESOURCES, ResourcesRequest.class);
    webTestClient.post().uri(UriEnum.URI_RESOURCES.value()).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).body(BodyInserters.fromObject(requestModel)).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS).expectBody(ResourceWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.ERROR));
  }
}
