/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import java.util.Map;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetVersionRequest;
import com.pearson.glp.cms.dto.learningasset.request.AssetsRequest;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceException;

/**
 * The Class NarrativesProvisioningConsumer.
 */
public class NarrativeConsumerTest extends LAPConsumerBase {

  /**
   * Instantiates a new narrative consumer test.
   */
  public NarrativeConsumerTest() {
    super();
  }

  /**
   * Gets the all versions integration test.
   *
   * @return the all versions integration test
   */
  @Test
  public void getAllVersionsIntegrationTest() {

    webTestClient.get().uri(UriEnum.URI_NARRATIVE_VERSIONS.value(), CmsConstants.PARAM_NARRATIVE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LearningAssetVersions.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Gets the narrative by id test.
   *
   * @return the narrative by id test
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getNarrativeByIdTest() throws ServiceException {

    webTestClient.get()
        .uri(UriEnum.URI_GET_NARRATIVE_BY_ID.value(), CmsConstants.PARAM_NARRATIVE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk().returnResult(Map.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }

  /**
   * Gets the specific version integration test.
   *
   * @return the specific version integration test
   */
  @Test
  public void getSpecificVersionIntegrationTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_NARRATIVE_SPECIFIC_VERSION.value(), CmsConstants.PARAM_NARRATIVE_ID,
            CmsConstants.PARAM_NARRATIVE_VER)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Adds the narrative version test.
   */
  @Test
  public void addNarrativeVersionTest() {
    AssetVersionRequest requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NARRATIVES_NEW_VERSION_REQUEST, AssetVersionRequest.class);
    requestBody.getAsset().setCreatedBy(CmsConstants.CMS);
    webTestClient.post()
        .uri(UriEnum.URI_NARRATIVE_VERSIONS.value(), CmsConstants.PARAM_NARRATIVE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus()
        .isEqualTo(HttpStatus.CREATED).expectBody(AssetWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.ERROR, CmsConstants.ENTITY_STATUS,
                CmsConstants.STATUS));
  }

  /**
   * Post bulk narrative int test.
   */
  @Test
  public void postBulkNarrativeIntTest() {
    AssetsRequest requestBody = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_NARRATIVES_REQUEST, AssetsRequest.class);
    webTestClient.post().uri(UriEnum.URI_NARRATIVES.value()).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).body(BodyInserters.fromObject(requestBody)).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS).expectBody(AssetWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.ERROR));
  }

  /**
   * Gets the bulk narrative integration test.
   *
   * @return the bulk narrative integration test
   */
  @Test
  public void getBulkNarrativeIntegrationTest() {
    webTestClient.get().uri(UriEnum.URI_NARRATIVES.value()).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkAssets.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }
}
