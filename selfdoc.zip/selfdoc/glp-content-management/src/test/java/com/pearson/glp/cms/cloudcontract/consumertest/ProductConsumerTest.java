/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningasset.request.ProductPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductStateTransitionPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductVersionRequest;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.dto.learningasset.response.ProductStateTransition;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;

/**
 * The Class ProductConsumer.
 *
 * @author nikhil.gupta4
 */
@Ignore
public class ProductConsumerTest extends LPBConsumerBase {

  /**
   * Instantiates a new product consumer test.
   */
  public ProductConsumerTest() {
    super();
  }

  /**
   * Gets the products by id and version integration test.
   *
   * @return the products by id and version integration test
   */
  @Test
  public void getProductsByIdAndVersionIntegrationTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION.value(),
            TestingConstants.PRODUCT_PARAM_PRODUCT_ID, TestingConstants.PRODUCT_PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON, CmsConstants.STATUS,
                CmsConstants.LAST_MODIFIED, CmsConstants.CREATED_BY));
  }

  /**
   * Gets the products version integration test.
   *
   * @return the products version integration test
   */
  @Test
  @Ignore
  public void getProductsVersionIntegrationTest() {
    webTestClient.get()
        .uri(UriEnum.URI_PRODUCT_VERSIONS.value(), TestingConstants.PRODUCT_PARAM_PRODUCT_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LearningAssetVersions.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Post product version integration test.
   */
  @Test
  public void createNewProductIntegrationTest() {
    ProductVersionRequest postRequestProductVersion = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_REQUEST_PRODUCT_VERSION, ProductVersionRequest.class);
    webTestClient.post()
        .uri(UriEnum.URI_PRODUCT_VERSIONS.value(), TestingConstants.PRODUCT_PARAM_PRODUCT_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(postRequestProductVersion)).exchange().expectStatus()
        .isCreated().expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON, CmsConstants.STATUS,
                CmsConstants.ID, CmsConstants.ERROR, CmsConstants.LAST_MODIFIED,
                CmsConstants.CREATED_BY));
  }

  /**
   * Gets the product by id integration test.
   *
   * @return the product by id integration test
   */
  @Test
  public void getProductByIdIntegrationTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_PRODUCT_BY_ID.value(), TestingConstants.PRODUCT_PARAM_PRODUCT_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON, CmsConstants.STATUS,
                CmsConstants.ID, CmsConstants.LAST_MODIFIED, CmsConstants.CREATED_BY));
  }

  /**
   * Gets the products integration test.
   *
   * @return the products integration test
   */
  @Test
  public void getProductsIntegrationTest() {
    webTestClient.get().uri(UriEnum.URI_PRODUCTS.value()).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkAssets.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }

  /**
   * Post products integration test.
   */
  @Ignore
  @Test
  public void postProductsIntegrationTest() {
    ProductPayload productPostPayload = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_REQUEST_PRODUCT, ProductPayload.class);
    webTestClient.post().uri(UriEnum.URI_PRODUCTS.value()).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).body(BodyInserters.fromObject(productPostPayload))
        .exchange().expectStatus().isCreated().expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON, CmsConstants.STATUS,
                CmsConstants.ID, CmsConstants.ERROR, CmsConstants.LAST_MODIFIED,
                CmsConstants.CREATED_BY));
  }

  /**
   * Gets the products state integration test.
   *
   * @return the products state integration test
   */
  @Test
  public void getProductsStateIntegrationTest() {
    webTestClient.get()
        .uri(UriEnum.URI_PRODUCT_STATE_TRANSITION.value(),
            TestingConstants.STATE_TRANSITION_PRODUCT_ID,
            TestingConstants.STATE_TRANSITION_PRODUCT_VERSION)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ProductStateTransition.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.STATUS));
  }

  /**
   * Post products state integration test.
   */
  @Test
  public void postProductsStateIntegrationTest() {
    ProductStateTransitionPayload productStateTransitionPayload = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_PRODUCT_STATE_TRANSITION_REQUEST_JSON,
            ProductStateTransitionPayload.class);

    webTestClient.post()
        .uri(UriEnum.URI_PRODUCT_STATE_TRANSITION.value(),
            TestingConstants.STATE_TRANSITION_PRODUCT_ID,
            TestingConstants.STATE_TRANSITION_PRODUCT_VERSION)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(productStateTransitionPayload)).exchange().expectStatus()
        .isCreated().expectBody(ProductStateTransition.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.STATUS));
  }

  /**
   * Get product configuration category weights.
   */
  @Test
  public void getProductConfigurationCategoryWeights() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION_CONFIGURATION.value(),
            TestingConstants.PRODUCT_ID, TestingConstants.PRODUCT_VER)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Get product configuration category weights invalid.
   */
  @Test
  public void getProductConfigurationCategoryWeightsInvalid() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION_CONFIGURATION.value(),
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound();
  }

}
