/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.cloudcontract.consumertest;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.resource.request.ResourceVersionRequest;
import com.pearson.glp.cms.dto.resource.request.ResourcesRequest;
import com.pearson.glp.cms.dto.resource.response.BulkResources;
import com.pearson.glp.cms.dto.resource.response.GLPResource;
import com.pearson.glp.cms.dto.resource.response.ResourceVersions;
import com.pearson.glp.cms.dto.resource.response.ResourceWithStatus;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.utils.CommonUtilsTest;

/**
 * The Class ResourceProvisioningConsumer.
 */
public class ResourceConsumerTest extends LAPConsumerBase {

  /**
   * Instantiates a new resource consumer test.
   */
  public ResourceConsumerTest() {
    super();
  }

  /**
   * Test get specific version of resource.
   *
   * @return the specific version integration test
   */
  @Test
  public void getSpecificVersionIntegrationTest() {
    webTestClient.get()
        .uri(UriEnum.URI_GET_RESOURCE_SPECIFIC_VERSION.value(), CmsConstants.PARAM_RESOURCE_ID,
            CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("language", "tags", "label", "expiresOn"));
  }

  /**
   * Gets the bulk resources integration test.
   *
   * @return the bulk resources integration test
   */
  @Test
  public void getBulkResourcesIntegrationTest() {

    webTestClient.get().uri(UriEnum.URI_RESOURCES.value()).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkResources.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }

  /**
   * Gets the all versions of resource int test.
   *
   * @return the all versions of resource int test
   */
  @Test
  public void getAllVersionsIntegrationTest() {

    webTestClient.get().uri(UriEnum.URI_RESOURCE_VERSIONS.value(), CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ResourceVersions.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Gets the resource by id int test.
   *
   * @return the resource by id int test
   */
  @Test
  public void getByIdIntegrationTest() {
    webTestClient.get().uri(UriEnum.URI_GET_RESOURCE_BY_ID.value(), CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("language", "tags", "label", "expiresOn"));
  }

  /**
   * Post bulk resources int test.
   */
  @Test
  public void postBulkResourcesIntTest() {
    ResourcesRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_RESOURCES_REQUEST, ResourcesRequest.class);
    webTestClient.post().uri(UriEnum.URI_RESOURCES.value()).contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON).body(BodyInserters.fromObject(requestModel)).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS).expectBody(ResourceWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("error"));
  }

  /**
   * Post version integration test.
   */
  @Test
  public void postVersionIntegrationTest() {
    ResourceVersionRequest requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_VERSION_RESOURCE_REQUEST, ResourceVersionRequest.class);
    webTestClient.post().uri(UriEnum.URI_RESOURCE_VERSIONS.value(), CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus()
        .isEqualTo(HttpStatus.CREATED).expectBody(ResourceWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("error", "entityStatus", "status"));
  }
}
