/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.constant;

/**
 * The Class JsonFileConstants.
 */
public final class JsonFileConstants {

  // Resources Response JSONs
  /** The Constant GET_BULK_RESOURCES_RESPONSE. */
  public static final String GET_BULK_RESOURCES_RESPONSE = "bulkResourcesGetResponse.json";
  /** The Constant POST_BULK_RESOURCES_RESPONSE. */
  public static final String POST_BULK_RESOURCES_RESPONSE = "bulkResourcesPostResponse.json";
  /** The Constant GET_RESOURCE_SPECIFIC_VERSION_RESPONSE. */
  public static final String GET_RESOURCE_SPECIFIC_VERSION_RESPONSE = "specificVersionResourceGet.json";
  /** The Constant POST_RESOURCES_VERSIONS_RESPONSE. */
  public static final String POST_RESOURCES_VERSIONS_RESPONSE = "resourcesVersionsPostResponse.json";
  /** The Constant GET_RESOURCE_ALL_VERSIONS_RESPONSE. */
  public static final String GET_RESOURCE_ALL_VERSIONS_RESPONSE = "getAllVersionsOfResource.json";
  /** The Constant POST_ASSESS_RESOURCES_RESPONSE. */
  public static final String POST_ASSESS_RESOURCES_RESPONSE = "postAssessResourcesResponse.json";
  /** The Constant POST_LEARNINGAPP_RESOURCES_RESPONSE. */
  public static final String POST_LEARNINGAPP_RESOURCES_RESPONSE = "postLearningAppResourcesResponse.json";
  /** The Constant GET_ASSESS_RESOURCES_RESPONSE. */
  public static final String GET_ASSESS_RESOURCES_RESPONSE = "getAssessmentItemResourcesByIdAndVersion.json";
  /** The Constant GET_LEARNING_RESOURCES_RESPONSE. */
  public static final String GET_LEARNING_RESOURCES_RESPONSE = "getLearningAppResources.json";
  /** The Constant POST_LEARNING_APP_RESOURCES. */
  public static final String POST_LEARNING_APP_RESOURCES = "postLearningAppResources.json";
  /** The Constant POST_LEARNING_APP_RESOURCES_WRONG_CONTENT. */
  public static final String POST_LEARNING_APP_RESOURCES_WITH_WRONG_CONTENT = "postLearningAppResourcesWithWrongContent.json";

  // Resources Request JSONs
  /** The Constant POST_BULK_RESOURCES_REQUEST. */
  public static final String POST_BULK_RESOURCES_REQUEST = "postBulkResourcesRequestBody.json";
  /** The Constant POST_NEW_VERSION_RESOURCE_REQUEST. */
  public static final String POST_VERSION_RESOURCE_REQUEST = "postVersionResourceRequestBody.json";
  /** The Constant POST_BULK_RESOURCES_BAD_REQUEST. */
  public static final String POST_RESOURCE_BAD_REQUEST = "postResourcesBadRequest.json";
  /** The Constant POST_ASSESS_ITEM_RESOURCES_REQUEST. */
  public static final String POST_ASSESS_ITEM_RESOURCES_REQUEST = "postAssessResourcesRequestBody.json";
  /** The Constant POST_BULK_RESOURCES_BAD_REQUEST. */
  public static final String POST_ASSESS_RESOURCE_BAD_REQUEST = "postAssessResourcesBadRequest.json";

  // Learning Assets Response JSONs
  /** The Constant GET_NARRATIVES_BY_ID_RESPONSE. */
  public static final String GET_NARRATIVES_BY_ID_RESPONSE = "narrativesById.json";
  /** The Constant GET_BULK_NARRATIVES_RESPONSE. */
  public static final String GET_BULK_NARRATIVES_RESPONSE = "getNarratives.json";
  /** The Constant GET_NARRATIVES_ALL_VERSIONS_RESPONSE. */
  public static final String GET_NARRATIVES_ALL_VERSIONS_RESPONSE = "narrativesVersions.json";
  /** The Constant POST_NARRATIVES_NEW_VERSION_RESPONSE. */
  public static final String POST_NARRATIVES_NEW_VERSION_RESPONSE = "narrativesVersionsPost.json";
  /** The Constant POST_BULK_NARRATIVES_RESPONSE. */
  public static final String POST_BULK_NARRATIVES_RESPONSE = "createNarrativesResponse.json";
  /** The Constant GET_ASSESSMENT_ITEMS_BY_ID_VERSION_RESPONSE. */
  public static final String GET_ASSESSMENT_ITEMS_BY_ID_VERSION_RESPONSE = "assessmentItemsByIdAndVer.json";
  /** The Constant GET_ASSESSMENT_ITEMS_BAD_REQUEST. */
  public static final String GET_ASSESSMENT_ITEMS_BAD_REQUEST = "getAssessmentItemsBadResponse.json";
  /** The Constant GET_ASSESSMENT_ITEMS. */
  public static final String GET_ASSESSMENT_ITEMS = "getAssessmentItems.json";
  /** The Constant POST_BULK_INSTRUCTIONS_RESPONSE. */
  public static final String POST_BULK_INSTRUCTIONS_RESPONSE = "createInstructionsResponse.json";
  /** The Constant GET_INSTRUCTIONS_RESPONSE. */
  public static final String GET_INSTRUCTIONS_RESPONSE = "getInstructions.json";
  /** The Constant GET_INSTRUCTIONS_BY_ID_RESPONSE. */
  public static final String GET_INSTRUCTIONS_BY_ID_RESPONSE = "getInstructionsByIdResponse.json";
  /** The Constant GET_INSTRUCTIONS_ALL_VERSIONS_RESPONSE. */
  public static final String GET_INSTRUCTIONS_ALL_VERSIONS_RESPONSE = "getInstructionsAllVersionsResponse.json";
  /** The Constant GET_SPECIFIC_VERSION_OF_INSTRUCTION_RESPONSE. */
  public static final String GET_SPECIFIC_VERSION_OF_INSTRUCTION_RESPONSE = "getSpecificVersionOfInstructionResponse.json";
  /** The Constant POST_NEW_VERSION_OF_INSTRUCTION_RESPONSE. */
  public static final String POST_NEW_VERSION_OF_INSTRUCTION_RESPONSE = "postNewVersionOfInstructionResponse.json";
  /** The Constant GET_AGGREGATE_BY_ID_RESPONSE. */
  public static final String GET_AGGREGATE_BY_ID_RESPONSE = "getAggregateByIdResponse.json";
  /** The Constant GET_ASSESSMENT_BY_ID_RESPONSE. */
  public static final String GET_ASSESSMENT_BY_ID_RESPONSE = "getAssessmentByIdResponse.json";
  /** The Constant GET_AGGREGATES_ALL_VERSIONS_RESPONSE. */
  public static final String GET_AGGREGATES_ALL_VERSIONS_RESPONSE = "getAggregatesAllVersionsResponse.json";
  /** The Constant GET_SPECIFIC_VERSION_OF_AGGREGATE_RESPONSE. */
  public static final String GET_SPECIFIC_VERSION_OF_AGGREGATE_RESPONSE = "getSpecificVersionOfAggregateResponse.json";
  /** The Constant POST_NEW_VERSION_OF_AGGREGATE_RESPONSE. */
  public static final String POST_NEW_VERSION_OF_AGGREGATE_RESPONSE = "postNewVersionOfAggregateResponse.json";
  /** The Constant POST_ASSESSMENT_MODELS_RESPONSE. */
  public static final String POST_ASSESSMENT_MODEL_RESPONSE = "postAssessmentModelsResponseBody.json";
  /** The Constant POST_ASSESSMENT_ITEM_MODELS_RESPONSE. */
  public static final String POST_ASSESSMENT_ITEM_MODEL_RESPONSE = "postAssessmentItemModelsResponseBody.json";
  /** The Constant POST_BULK_AGGREGATE_RESPONSE. */
  public static final String POST_BULK_AGGREGATE_RESPONSE = "createAggregatesResponse.json";
  /** The Constant POST_BULK_ASSESSMENT_RESPONSE. */
  public static final String POST_BULK_ASSESSMENT_RESPONSE = "createAssessmentsResponse.json";
  /** The Constant GET_AGGREGATES_RESPONSE. */
  public static final String GET_AGGREGATES_RESPONSE = "getAggregates.json";
  /** The Constant GET_ASSESSMENT_ITEM_BY_ID_AND_VERSION. */
  public static final String GET_ASSESSMENT_ITEM_SPECIFIC_VERSION_RESPONSE = "getAssessmentItemsByIdAndVersion.json";
  /** The Constant GET_ASSESSMENT_ITEM_BY_ID_RESPONSE. */
  public static final String GET_ASSESSMENT_ITEM_BY_ID_RESPONSE = "getAssessmentItemsById.json";
  /** The Constant GET_ASSESSMENT_ITEM_BY_ID_AND_VERSION. */
  public static final String GET_ASSESSMENT_RUNTIME_SETTING_VERSION_RESPONSE = "getProductAssessmentRuntimeSettingsResponse.json";
  /** The Constant POST_ASSESSMENT_ITEM_RESPONSE. */
  public static final String POST_ASSESSMENT_ITEM_RESPONSE = "createAssessmentItemsResponse.json";
  /** The Constant GET_LEARNING_APPS_BY_ID_RESPONSE. */
  public static final String GET_LEARNING_APPS_BY_ID_RESPONSE = "getLearningAppsByIdResponse.json";
  /** The Constant POST_LEARNING_APP_ITEMS_RESPONSE. */
  public static final String POST_LEARNING_APP_ITEMS_RESPONSE = "createLearningAppItemsResponse.json";
  /** The Constant GET_LEARNING_APP_ITEMS_BY_ID_RESPONSE. */
  public static final String GET_LEARNING_APP_ITEMS_BY_ID_RESPONSE = "getLearningAppItemsByIdResponse.json";
  /** The Constant GET_LEARNINGAPPS_BY_ID_JSON_RESPONSE. */
  public static final String GET_LEARNINGAPPS_BY_ID_JSON_RESPONSE = "getLearningAppsById.json";
  /** The Constant GET_LEARNINGAPPS_BY_ID_VERSION_JSON. */
  public static final String GET_LEARNINGAPPS_BY_ID_VERSION_JSON = "getLearningAppsById.json";
  /** The Constant POST_LEARNINGAPPS_JSON */
  public static final String POST_LEARNINGAPPS_JSON = "postLearningAppResponse.json";
  /** The Constant POST_BULK_EMBEDDED_ASSET_RESPONSE. */
  public static final String POST_BULK_EMBEDDED_ASSET_RESPONSE = "createEmbeddedAssetsResponse.json";
  /** The Constant POST_BULK_EMBEDDED_ASSET_ERROR_RESPONSE. */
  public static final String POST_BULK_EMBEDDED_ASSET_ERROR_RESPONSE = "createEmbeddedAssets400Response.json";

  // Learning Assets Request JSONs
  /** The Constant POST_NARRATIVES_NEW_VERSION_REQUEST. */
  public static final String POST_NARRATIVES_NEW_VERSION_REQUEST = "postNewNarrativeVersionRequestBody.json";
  /** The Constant POST_BULK_NARRATIVES_REQUEST. */
  public static final String POST_BULK_NARRATIVES_REQUEST = "createNarrativesRequest.json";
  /** The Constant POST_NEW_VERSION_OF_INSTRUCTION_REQUEST. */
  public static final String POST_NEW_VERSION_OF_INSTRUCTION_REQUEST = "postNewVersionOfInstructionRequest.json";
  /** The Constant POST_BULK_NARRATIVES_BAD_REQUEST. */
  public static final String POST_BULK_ASSETS_BAD_REQUEST = "postAssetsBadRequest.json";
  /** The Constant POST_NARRATIVES_VERSION_BAD_REQUEST. */
  public static final String POST_NARRATIVES_VERSION_BAD_REQUEST = "postNarrativeVersionBadRequest.json";
  /** The Constant POST_ASSESS_ITEMS_BAD_REQUEST. */
  public static final String POST_ASSESS_ITEMS_BAD_REQUEST = "postAssessItemsBadRequest.json";
  /** The Constant POST_BULK_INSTRUCTIONS_REQUEST. */
  public static final String POST_BULK_INSTRUCTIONS_REQUEST = "createInstructionsRequest.json";
  /** The Constant POST_ASSESSMENT_BAD_REQUEST. */
  public static final String POST_ASSESSMENT_BAD_REQUEST = "postAssessmentBadRequest.json";
  /** The Constant POST_BULK_ASSESMENT_ITEM_REQUEST. */
  public static final String POST_BULK_ASSESMENT_ITEM_REQUEST = "postAssesmentItemRequest.json";
  /** The Constant POST_BULK_LEARNING_APP_ITEM_REQUEST. */
  public static final String POST_BULK_LEARNING_APP_ITEM_REQUEST = "postLearningAppItemRequest.json";
  /** The Constant POST_BULK_EMBEDDED_ASSET_REQUEST. */
  public static final String POST_BULK_EMBEDDED_ASSET_REQUEST = "createEmbeddedAssetsRequest.json";

  // Learning Models Response JSONs
  /** The Constant POST_AGGREGATE_MODELS_VERSIONS_RESPONSE. */
  public static final String POST_AGGREGATE_MODELS_VERSIONS_RESPONSE = "aggregateModelsVersionsResponse.json";
  /** The Constant POST_ASSESSMENT_MODELS_VERSIONS_RESPONSE. */
  public static final String POST_ASSESSMENT_MODELS_VERSIONS_RESPONSE = "assessmentModelsVersionsResponse.json";
  /** The Constant POST_AGGREGATE_MODELS_RESPONSE. */
  public static final String POST_AGGREGATE_MODELS_RESPONSE = "createAggregateModelResponse.json";
  /** The Constant POST_ASSESSMENT_MODELS_RESPONSE. */
  public static final String POST_ASSESSMENT_MODELS_RESPONSE = "createAssessmentModelResponse.json";
  /** The Constant POST_INSTRUCTION_MODELS_RESPONSE. */
  public static final String POST_INSTRUCTION_MODELS_RESPONSE = "createInstructionModelResponse.json";
  /** The Constant POST_INSTRUCTION_MODELS_VERSIONS_RESPONSE. */
  public static final String POST_INSTRUCTION_MODELS_VERSIONS_RESPONSE = "instructionModelsVersionsResponse.json";
  /** The Constant POST_NARRATIVE_MODELS_RESPONSE. */
  public static final String POST_NARRATIVE_MODEL_RESPONSE = "postNarrativeModelResponse.json";
  /** The Constant GET_BULK_PRODUCT_MODEL_RESPONSE. */
  public static final String GET_BULK_PRODUCT_MODEL_RESPONSE = "getBulkProductModelResponse.json";
  /** The Constant GET_PRODUCT_MODEL_ALL_VERSION_RESPONSE. */
  public static final String GET_PRODUCT_MODEL_ALL_VERSION_RESPONSE = "getProductModelAllVersionResponse.json";
  /** The Constant GET_PRODUCT_MODEL_BY_ID_RESPONSE. */
  public static final String GET_PRODUCT_MODEL_BY_ID_RESPONSE = "getProductModelByIdResponse.json";
  /** The Constant GET_SPECIFIC_VERSION_OF_PRODUCT_MODEL_RESPONSE. */
  public static final String GET_SPECIFIC_VERSION_OF_PRODUCT_MODEL_RESPONSE = "getSpecificVersionOfProductModelResponse.json";
  /** The Constant POST_BULK_PRODUCT_MODEL_RESPONSE. */
  public static final String POST_BULK_PRODUCT_MODEL_RESPONSE = "postBulkProductModelResponse.json";
  /** The Constant POST_NEW_PRODUCT_MODEL_VERSION_RESPONSE. */
  public static final String POST_NEW_PRODUCT_MODEL_VERSION_RESPONSE = "postNewProductModelVersionResponse.json";
  /** The Constant POST_INSTRUCTION_MODEL_RESPONSE. */
  public static final String POST_INSTRUCTION_MODEL_RESPONSE = "postInstructionModelResponse.json";
  /** The Constant POST_NEW_VERSION_OF_INSTRUCTION_MODEL_RESPONSE. */
  public static final String POST_NEW_VERSION_OF_INSTRUCTION_MODEL_RESPONSE = "postNewVersionOfInstructionModelResponse.json";
  /** The Constant POST_NEW_VERSION_OF_AGGREGATE_MODEL_RESPONSE. */
  public static final String POST_NEW_VERSION_OF_AGGREGATE_MODEL_RESPONSE = "postNewVersionOfAggregateModelResponse.json";
  /** The Constant GET_ASSET_MODELS_RESPONSE. */
  public static final String GET_ASSET_MODELS_RESPONSE = "getAssetModelsResponse.json";
  /** The Constant GET_ASSET_MODEL_BY_ID_RESPONSE. */
  public static final String GET_ASSET_MODEL_BY_ID_RESPONSE = "getAssetModelByIdResponse.json";
  /** The Constant GET_ASSET_MODEL_BY_VERSION_ID_RESPONSE. */
  public static final String GET_ASSET_MODEL_BY_VERSION_ID_RESPONSE = "getAssetModelByVersionIdResponse.json";
  /** The Constant GET_ASSET_MODELS_VERSIONS_RESPONSE. */
  public static final String GET_ASSET_MODELS_VERSIONS_RESPONSE = "getAssetModelsVersionsResponse.json";
  /** The Constant POST_NARRATIVE_MODEL_VERSION_RESPONSE. */
  public static final String POST_NARRATIVE_MODEL_VERSION_RESPONSE = "postNewVersionOfNarrativeModelResponse.json";

  // Learning Models Request JSONs
  /** The Constant POST_INSTRUCTION_MODEL_REQUEST. */
  public static final String POST_INSTRUCTION_MODEL_REQUEST = "postInstructionModelsRequestBody.json";
  /** The Constant POST_NEW_VERSION_OF_INSTRUCTION_MODEL_REQUEST. */
  public static final String POST_NEW_VERSION_OF_INSTRUCTION_MODEL_REQUEST = "postNewVersionOfInstructionModelRequestBody.json";
  /** The Constant POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST. */
  public static final String POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST = "postNewVersionOfAggregateModelRequestBody.json";
  /** The Constant POST_AGGREGATE_MODELS_REQUEST. */
  public static final String POST_AGGREGATE_MODELS_REQUEST = "postAggregateModelsRequestBody.json";
  /** The Constant POST_ASSESSMENT_ITEM_MODELS_REQUEST. */
  public static final String POST_ASSESSMENT_ITEM_MODELS_REQUEST = "postAssessmentItemModelsRequestBody.json";
  /** The Constant POST_ASSESSMENT_MODELS_REQUEST. */
  public static final String POST_ASSESSMENT_MODELS_REQUEST = "postAssessmentModelsRequestBody.json";
  /** The Constant POST_ASSET_MODEL_BAD_REQUEST. */
  public static final String POST_ASSET_MODEL_BAD_REQUEST = "postAssetModelBadRequest.json";

  // Product Response JSONs
  /** The Constant PRODUCTS_VERSIONS_RESPONSE_JSON. */
  public static final String PRODUCTS_VERSIONS_RESPONSE_JSON = "productsVersionsResponse.json";
  /** The Constant PRODUCT_BY_ID_AND_VERSION_RESPONSE_JSON. */
  public static final String PRODUCT_BY_ID_AND_VERSION_RESPONSE_JSON = "productsByIdAndVersion.json";
  /** The Constant PRODUCT_NEW_VERSION_RESPONSE_JSON. */
  public static final String PRODUCT_NEW_VERSION_RESPONSE_JSON = "productsNewVersion.json";
  /** The Constant PRODUCT_POST. */
  public static final String PRODUCT_POST = "ProductPost.json";
  /** The Constant GET_PRODUCT_BY_ID_JSON. */
  public static final String GET_PRODUCT_BY_ID_JSON = "ProductsById.json";
  /** The Constant PRODUCTS. */
  public static final String PRODUCTS = "Products.json";
  /** The Constant POST_PRODUCT_STATE_TRANSITION_RESPONSE_JSON. */
  public static final String POST_PRODUCT_STATE_TRANSITION_RESPONSE_JSON = "postProductStateTransitionResponse.json";
  /** The Constant GET_PRODUCT_STATE_TRANSITION_RESPONSE. */
  public static final String GET_PRODUCT_STATE_TRANSITION_RESPONSE = "getProductStateTransitionResponse.json";
  /** The Constant POST_MAP_ASSESSMENT_TYPE_RESPONSE_JSON. */
  public static final String POST_MAP_ASSESSMENT_TYPE_RESPONSE_JSON = "postMapAssessmentTypeResponse.json";
  /** The Constant PRODUCT_STATUS_RESPONSE. */
  public static final String PRODUCT_STATUS_RESPONSE = "productStatusResponse.json";
  /** The Constant GET_PRODUCT_ASSESSMENT_TYPES_RESPONSE. */
  public static final String GET_PRODUCT_ASSESSMENT_TYPES_RESPONSE = "getProductAssessmentTypesResponse.json";
  /** The Constant GET_PRODUCT_ASSET_TYPES_RESPONSE. */
  public static final String GET_PRODUCT_ASSET_TYPES_RESPONSE = "getProductAssetTypes.json";
  /** The Constant PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_RESPONSE. */
  public static final String PRODUCT_ASSESSMENT_RUNTIME_SETTINGS_RESPONSE = "createProductAssessmentRuntimeSettings.json";
  /** The Constant GET_PRODUCTS_RESPONSE. */
  public static final String GET_PRODUCTS_RESPONSE = "getProducts.json";
  /** The Constant GET_PRODUCT_BY_ID_AND_VERSION_RESPONSE. */
  public static final String GET_PRODUCT_BY_ID_AND_VERSION_RESPONSE = "getProductByIdAndVersion.json";

  // Product Request JSONs
  /** The Constant POST_REQUEST_PRODUCT. */
  public static final String POST_REQUEST_PRODUCT = "postRequestProduct.json";
  /** The Constant POST_REQUEST_PRODUCT_VERSION. */
  public static final String POST_REQUEST_PRODUCT_VERSION = "postRequestProductVersion.json";
  /** The Constant POST_PRODUCT_BAD_REQUEST. */
  public static final String POST_PRODUCT_BAD_REQUEST = "postProductBadRequest.json";
  /** The Constant POST_PRODUCT_VERSION_BAD_REQUEST. */
  public static final String POST_PRODUCT_VERSION_BAD_REQUEST = "postProductVersionBadRequest.json";
  /** The Constant POST_PRODUCT_STATE_TRANSITION_REQUEST_JSON. */
  public static final String POST_PRODUCT_STATE_TRANSITION_REQUEST_JSON = "postProductStateTransitionRequest.json";
  /** The Constant POST_PRODUCT_STATE_TRANSITION_BAD_REQUEST. */
  public static final String POST_PRODUCT_STATE_TRANSITION_BAD_REQUEST = "postProductStateTransitionBadRequest.json";
  /** The Constant PUT_PRODUCT_STATUS_REQUEST_JSON. */
  public static final String PUT_PRODUCT_STATUS_REQUEST_JSON = "putProductStatusRequest.json";
  /** The Constant POST_MAP_ASSESSMENT_TYPE_REQUEST_JSON. */
  public static final String POST_MAP_ASSESSMENT_TYPE_REQUEST_JSON = "postMapAssessmentTypeRequest.json";

  // Error Response JSONs
  /** The Constant BAD_REQUEST_RESPONSE. */
  public static final String BAD_REQUEST_RESPONSE = "badRequestResponse.json";
  /** The Constant INTERNAL_SERVER_ERROR_RESPONSE. */
  public static final String INTERNAL_SERVER_ERROR_RESPONSE = "internalServerErrorResponse.json";
  /** The Constant NOT_FOUND_RESPONSE. */
  public static final String NOT_FOUND_RESPONSE = "notFoundResponse.json";
  /** The Constant POST_RESOURCES_ERROR_RESPONSE. */
  public static final String POST_RESOURCES_ERROR_RESPONSE = "postResourcesError.json";
  /** The Constant POST_ASSETS_ERROR_RESPONSE. */
  public static final String POST_ASSETS_ERROR_RESPONSE = "postAssetsError.json";
  /** The Constant GET_SPECIFIC_VERSION_OF_LEARNING_APP_RESPONSE. */
  public static final String GET_SPECIFIC_VERSION_OF_LEARNING_APP_RESPONSE = "getSpecificLearningAppResponse.json";
  /** The Constant POST_LEARNINGAPP_REQUEST_JSON. */
  public static final String POST_LEARNINGAPP_REQUEST_JSON = "postLearningAppRequest.json";
  /** The Constant POST_LEARNINGAPP_RESPONSE_JSON. */
  public static final String POST_LEARNINGAPP_RESPONSE_JSON = "postLearningAppResponse.json";
  /** The Constant POST_PRODUCT_MAP_ASSESSMENT_TYPE_REQUEST. */
  public static final String POST_PRODUCT_MAP_ASSESSMENT_TYPE_REQUEST = "postProductMapAssessmentType.json";
  /** The Constant GET_PRODUCT_POLICY_GROUP_RESPONSE. */
  public static final String GET_PRODUCT_POLICY_GROUP_RESPONSE = "getProductPolicyGroupResponse.json";
  /** The Constant GET_DELIVERY_POLICY_RESPONSE. */
  public static final String GET_DELIVERY_POLICY_RESPONSE = "getDeliveryResolvedPolicy.json";
  /** The Constant GET_PRODUCT_CONFIGURATION_RESPONSE. */
  public static final String GET_PRODUCT_CONFIGURATION_RESPONSE = "getPolicyGroupProduct.json";
  /** The Constant POST_POLICY_GROUP_RESPONSE. */
  public static final String POST_POLICY_GROUP_RESPONSE = "postPolicyGroupResponse.json";
  /** The Constant GET_POLICY_GROUP_EMPTY_RESPONSE. */
  public static final String GET_POLICY_GROUP_EMPTY_RESPONSE = "getProductPolicyGroupIsEmptyResponse.json";

  /** The Constant GET_POLICY_GROUP_WITHOUT_TITLE. */
  public static final String GET_POLICY_GROUP_WITHOUT_TITLE = "getProductPolicyGroupWithoutTitle.json";
  /** The Constant EXPERIENCE_POLICY_RESPONSE. */
  public static final String EXPERIENCE_POLICY_RESPONSE = "postExperiencePolicyResponse.json";

  // Engagement Policies JSONs
  /** The Constant DELIVERY_POLICY_REQUEST. */
  public static final String DELIVERY_POLICY_REQUEST = "postDeliveryPolicyRequest.json";
  /** The Constant ENGAGEMENT_POLICY_REQUEST. */
  public static final String ENGAGEMENT_POLICY_REQUEST = "postEngagementPolicyRequest.json";
  /** The Constant EVALUATION_POLICY_REQUEST. */
  public static final String EVALUATION_POLICY_REQUEST = "postEvaluationPolicyRequest.json";

  // Runtime Policy JSONs
  /** The Constant RUNTIME_SETTINGS_REQUEST. */
  public static final String RUNTIME_SETTINGS_REQUEST = "postRuntimeSettingsRequest.json";
  /** The Constant DELIVERY_POLICY_RESPONSE. */
  public static final String DELIVERY_POLICY_RESPONSE = "postDeliveryPolicyResponse.json";
  /** The Constant EVALUATION_POLICY_RESPONSE. */
  public static final String EVALUATION_POLICY_RESPONSE = "postEvaluationPolicyResponse.json";
  /** The Constant POLICY_RESPONSE_ERROR. */
  public static final String POLICY_RESPONSE_ERROR = "postEvaluationPolicyResponseError.json";
  /** The Constant RENAME_LEARNINGAID_POLICY_RESPONSE. */
  public static final String GET_LEARNING_AID_RESPONSE = "getRenameLearningResponse.json";

  /** The Constant GET_ENGAGEMENT_RESOLVED_POLICY. */
  public static final String GET_ENGAGEMENT_RESOLVED_POLICY = "getEngagementResolvedPolicy.json";
  /** The Constant GET_DELIVERY_RESOLVED_POLICY. */
  public static final String GET_DELIVERY_RESOLVED_POLICY = "getDeliveryResolvedPolicies.json";
  /** The Constant GET_EVALUATION_RESOLVED_POLICY. */
  public static final String GET_EVALUATION_RESOLVED_POLICY = "getEvaluationResolvedPolicies.json";

  /** The Constant GET_ALL_ASSESSMENT. */
  public static final String GET_ALL_ASSESSMENT = "getAllAssessment.json";

  /** The Constant GET_ASSESSMENT_BAD_RESPONSE. */
  public static final String GET_ASSESSMENT_BAD_RESPONSE = "getAssessmentBadResponse.json";

  /** The Constant GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE. */
  public static final String GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE = "getProductModelPolicyGroupResponse.json";

  /** The Constant PRODUCT_GET_ASSESSMENT_ASSET_TYPE. */
  public static final String PRODUCT_GET_ASSESSMENT_ASSET_TYPE = "ProductGetAssessmentAssetTypesResponse.json";

  /** The constant PRODUCT_EVENT_JSON. */
  public static final String PRODUCT_EVENT_JSON = "ProductEvent.json";
  /** The Constant GET_DELIVERY_POLICY_RESPONSE_FOR_PRODUCT. */
  public static final String GET_DELIVERY_POLICY_RESPONSE_FOR_PRODUCT = "getDeliveryResolvedPolicyForProduct.json";
  /** The Constant GET_DELIVERY_POLICY_RESPONSE. */
  public static final String GET_PRODUCT_MODELS_WITH_CATEGORY_WEIGHTS = "getProductModelWithCategoryWeightsResponse.json";

  /** The Constant POST_PRODUCT_CATEGORY_WEIGHTS_REQUEST. */
  public static final String POST_PRODUCT_CATEGORY_WEIGHTS_REQUEST = "postProductCategoryWeights.json";

  /** The Constant CATEGORY_WEIGHT_POLICY_RESPONSE. */
  public static final String CATEGORY_WEIGHT_POLICY_RESPONSE = "postCategoryWeightPolicyResponse.json";

  /** The Constant POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_REQUEST. */
  public static final String POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_REQUEST = "postProductModelCategoryWeights.json";

  /** The Constant POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST. */
  public static final String POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST = "postAssessmentRuntimeSettingsRequest.json";

  /** The Constant GET_PRODUCT_SCORING_POLICY_RESPONSE. */
  public static final String GET_PRODUCT_SCORING_POLICY_RESPONSE = "getProductScoringPolicy.json";
  /** The Constant PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_RESPONSE. */
  public static final String PRODUCT_MODEL_ASSESSMENT_RUNTIME_SETTINGS_RESPONSE = "createProductModelAssessmentRuntimeSettings.json";

  /** The Constant POST_PRODUCT_CATEGORY_WEIGHTS_RESPONSE. */
  public static final String POST_PRODUCT_CATEGORY_WEIGHTS_RESPONSE = "postProductCategoryWeightsResponse.json";

  /** The Constant GET_PRODUCT_CATEGORY_WEIGHTS_RESPONSE. */
  public static final String GET_PRODUCT_CATEGORY_WEIGHTS_RESPONSE = "getProductCategoryWeightsResponse.json";

  /** The Constant PRODUCT_CATEGORY_NOT_FOUND_JSON. */
  public static final String PRODUCT_CATEGORY_NOT_FOUND_JSON = "getProductCategoryNotFound.json";

  /** The Constant POST_POLICY_PRODUCT_GRADEBOOK_JSON. */
  public static final String POST_POLICY_PRODUCT_GRADEBOOK_JSON = "postPolicyProductGradebook.json";

  /** The Constant POST_PRODUCT_CATEGORY_WEIGHTS_RESPONSE. */
  public static final String POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_RESPONSE = "postProductModelCategoryWeightsResponse.json";

  /** The Constant GET_PRODUCT_MODEL_CATEGORY_WEIGHTS_RESPONSE. */
  public static final String GET_PRODUCT_MODEL_CATEGORY_WEIGHTS_RESPONSE = "getProductModelCategoryWeightsResponse.json";

  /** The Constant PRODUCT_MODEL_CATEGORY_NOT_FOUND_JSON. */
  public static final String PRODUCT_MODEL_CATEGORY_NOT_FOUND_JSON = "getProductModelCategoryNotFound.json";

  /** The Constant POST_PRODUCT_MODEL_SCORING_POLICY_RESPONSE_JSON. */
  public static final String POST_PRODUCT_MODEL_SCORING_POLICY_RESPONSE_JSON = "postProductModelScoringPolicyResponse.json";

  /** The Constant GET_PRODUCT_MODEL_SCORING_POLICY_RESPONSE_JSON. */
  public static final String GET_PRODUCT_MODEL_SCORING_POLICY_RESPONSE_JSON = "getProductModelScoringPolicyResponse.json";

  /** The Constant GET_SCORING_POLICY_RESPONSE. */
  public static final String GET_SCORING_POLICY_RESPONSE = "getScoringPolicyResponse.json";

  /** The Constant GET_PRODUCT_MODEL_BY_COMMERCIAL_DETAILS_RESPONSE. */
  public static final String GET_PRODUCT_MODEL_BY_COMMERCIAL_DETAILS_RESPONSE = "getProductModelCollectionDetail.json";

  /** The Constant GET_PRODUCT_MODEL_LEARNING_AID_RESPONSE. */
  public static final String GET_PRODUCT_MODEL_LEARNING_AID_RESPONSE = "getProductModelRenameLearningResponse.json";

  /** The Constant PRODUCT_MODEL_LEARNING_AIDS_POLICY_RESPONSE. */
  public static final String PRODUCT_MODEL_LEARNING_AIDS_POLICY_RESPONSE = "postProductModelLearningAidsPolicyResponse.json";

  /**
   * Instantiates a new json file constants.
   */
  private JsonFileConstants() {
    super();
  }
}