/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.constant;

/**
 * The Class TestingConstants.
 * 
 * @author sourabh.aggarwal
 */
public final class TestingConstants {

  /** The Constant ASSET_MODEL_LABEL. */
  public static final String ASSET_MODEL_LABEL = "INSTRUCTION";

  /** The Constant PRODUCT_MODEL_LABEL. */
  public static final String PRODUCT_MODEL_LABEL = "PRODUCT";

  /** The Constant ASSET_MODEL_TAGS. */
  public static final String ASSET_MODEL_TAGS = "REVEL";

  /** The Constant PRODUCT_MODEL_TAGS. */
  public static final String PRODUCT_MODEL_TAGS = "REVEL";

  /** The Constant ASSET_MODEL_ROUTE. */
  public static final String ASSET_MODEL_ROUTE = "/cms/v2/assetModels/";

  /** The Constant AGGREGATE_MODEL_ROUTE. */
  public static final String AGGREGATE_MODEL_ROUTE = "cms/v2/aggregateModels/";

  /** The Constant NARRATIVE_MODEL_ROUTE. */
  public static final String NARRATIVE_MODEL_ROUTE = "cms/v2/narrativeModels/";

  /** The Constant INSTRUCTION_MODEL_ROUTE. */
  public static final String INSTRUCTION_MODEL_ROUTE = "cms/v2/instructionModels/";

  /** The Constant ASSESSMENT_MODEL_ROUTE. */
  public static final String ASSESSMENT_MODEL_ROUTE = "cms/v2/assessmentModels/";

  /** The Constant ASSESSMENT_MODEL_ROUTE. */
  public static final String ASSESSMENT_ITEM_MODEL_ROUTE = "cms/v2/assessmentItemModels/";

  /** The Constant ASSESSMENT. */
  public static final String ASSESSMENT = "ASSESSMENT";

  /** The Constant ASSESSMENT ITEM. */
  public static final String ASSESSMENT_ITEM = "ASSESSMENT_ITEM";

  /** The Constant INSTRUCTION. */
  public static final String INSTRUCTION = "INSTRUCTION";

  /** The Constant AGGREGATE. */
  public static final String AGGREGATE = "AGGREGATE";

  /** The Constant NARRATIVE. */
  public static final String NARRATIVE = "NARRATIVE";

  /** The Constant VERSIONS. */
  public static final String VERSIONS = "/versions/";

  /** The Constant ASSET_MODEL_ID. */
  public static final String ASSET_MODEL_ID = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant ASSET_MODEL_VERSION_ID. */
  public static final String ASSET_MODEL_VERSION_ID = "672e01c3-cfba-4622-81b8-0ca9cc9c4b1e";

  /** The Constant INSTRUCTION_MODEL_ID. */
  public static final String INSTRUCTION_MODEL_ID = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant ASSESSMENT_MODEL_ID. */
  public static final String ASSESSMENT_MODEL_ID = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant AGGREGATE_MODEL_ID. */
  public static final String AGGREGATE_MODEL_ID = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant NARRATIVE_MODEL_ID. */
  public static final String NARRATIVE_MODEL_ID = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant ASSET_MODEL_ID. */
  public static final String PRODUCT_MODEL_ID = "46b49213-1bf1-46b4-9213-46222db8fc7c";

  /** The Constant PRODUCT_MODEL_VERSION_ID. */
  public static final String PRODUCT_MODEL_VERSION_ID = "8bdbe309-433c-4e95-b194-736399c1790b";

  /** The Constant GET_PRODUCT_VERSIONS_BY_ID_RESPONSE. */
  public static final String GET_PRODUCT_VERSIONS_BY_ID_RESPONSE = "getProductVersionsById.json";

  /** The Constant ID_QUERY_STRING. */
  public static final String ID_QUERY_STRING = "?id=13";

  /** The Constant DUMMY_VALUE. */
  public static final String DUMMY_VALUE = "8e959213-1bf1-46b4-b3af-53942db8fc7c";

  /** The Constant DUMMY_NARRATIVE_ID. */
  public static final String DUMMY_NARRATIVE_ID = "243b49fb-24a0-4081-8970-efd55773f32c";

  /** The Constant DUMMY_VERSION_ID. */
  public static final String DUMMY_VERSION_ID = "810a3768-17af-4f2f-9d4c-b07c6cdfc672";

  /** The Constant DUMMY_NARRATIVE_ID. */
  public static final String DUMMY_ASSESSMENT_ITEMS_ID = "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f";

  /** The Constant PARAM_PRODUCT_ID. */
  public static final String PRODUCT_PARAM_PRODUCT_ID = "8883c099-1762-43fe-9ad8-4c9aaa6eafa2";

  /** The Constant PARAM_VERSION_ID. */
  public static final String PRODUCT_PARAM_VERSION_ID = "200a3768-17af-4f2f-9d4c-b07c6cdfc456";

  /** The Constant PRODUCT_ID_FOR_GET_STATUS. */
  public static final String PRODUCT_ID_FOR_GET_STATUS = "1fb057c2-9d9b-4883-a3ac-f96a369645b5";

  /** The Constant VERSION_ID_FOR_GET_STATUS. */
  public static final String VERSION_ID_FOR_GET_STATUS = "22e33af8-4d0c-4beb-bd0f-4548929b875f";

  /** The Constant STATE_TRANSITION_PRODUCT_ID. */
  public static final String STATE_TRANSITION_PRODUCT_ID = "fc989a74-57e0-4be4-89c9-13e7dc75d293";

  /** The Constant STATE_TRANSITION_PRODUCT_VERSION. */
  public static final String STATE_TRANSITION_PRODUCT_VERSION = "bb9dd4b7-8887-4bdd-b1e5-17db3cc4ddf1";

  /** The Constant CONTENT_VALIDATION_FAILED. */
  public static final String CONTENT_VALIDATION_FAILED = "Invalid url of resource content";

  /** The Constant LEARNINGAIDS_POLICY_RESPONSE. */
  public static final String LEARNINGAIDS_POLICY_RESPONSE = "postLearningAidsPolicyResponse.json";
  /** The Constant LEARNINGAIDS_POLICY_REQUEST. */
  public static final String LEARNINGAIDS_POLICY_REQUEST = "postLearningAidsPolicySettings.json";

  /** The Constant PRODUCT_SCORING_POLICY_REQUEST. */
  public static final String SCORING_POLICY_REQUEST = "scoringPolicyRequest.json";

  /** The Constant PRODUCT_SCORING_POLICY_RESPONSE. */
  public static final String SCORING_POLICY_RESPONSE = "scoringPolicyResponse.json";

  /** The Constant PARAM_LEARNING_APP_ITEM_ID. */
  public static final Object PARAM_LEARNING_APP_ITEM_ID = "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f";

  /** The Constant PARAM_LEARNING_APP_ITEM_VER. */
  public static final Object PARAM_LEARNING_APP_ITEM_VER = "810a3768-17af-4f2f-9d4c-b07c6cdfc672";

  /** The Constant PARAM_LEARNING_APP_RESOURCE_ID. */
  public static final String PARAM_LEARNING_APP_RESOURCE_ID = "243b49fb-24a0-4081-8970-efd55773f33d";

  /** The Constant PARAM_LEARNING_APP_RESOURCE_VER. */
  public static final String PARAM_LEARNING_APP_RESOURCE_VER = "18f67618-1f1f-4f59-a86c-961aacb2807f";

  /** The Constant POLICY_GROUPS. */
  public static final String POLICY_GROUPS = "policyGroups";

  /** The Constant TITLE_GUID. */
  public static final String TITLE_GUID = "TITLE_{GUID}";

  /** The Constant ACCEPT. */
  public static final String ACCEPT = "Accept";

  /** The Constant ACCEPT. */
  public static final String APPLICATION_JSON = "application/json";

  /** The Constant URI_LAD_GET_POLICIES. */
  public static final String URI_LAD_GET_POLICIES = "/v2/resolvedPolicies?group=REVEL&assetClass=ASSESSMENTRUNTIMESETTINGS-POLICY-DELIVERY";

  /** The Constant URI_LEE_GET_POLICY. */
  public static final String URI_LEE_GET_POLICIES = "/v2/resolvedPolicies?group=REVEL&assetClass=ASSESSMENTRUNTIMESETTINGS-POLICY-ENGAGEMENT";

  /** The Constant URI_LAE_GET_POLICIES. */
  public static final String URI_LAE_GET_POLICIES = "/v2/resolvedPolicies?group=REVEL&assetClass=ASSESSMENTRUNTIMESETTINGS-POLICY-EVALUATION";

  /** The Constant URI_LAD_GET_POLICIES_INVALID. */
  public static final String URI_LAD_GET_POLICIES_INVALID = "/v2/resolvedPolicies?group=pro&assetClass=ASSESSEMENTRUNTIMESETTINGS-POLICY-DELIVERY";

  /** The Constant URI_LEE_GET_POLICY_INVALID. */
  public static final String URI_LEE_GET_POLICY_INVALID = "/v2/resolvedPolicies?group=pro&assetClass=ASSESSMENTRUNTIMESETTINGS-POLICY-ENGAGEMENT";

  /** The Constant URI_LAE_GET_POLICIES_INVALID. */
  public static final String URI_LAE_GET_POLICIES_INVALID = "/v2/resolvedPolicies?group=pro&assetClass=ASSESSMENTRUNTIMESETTINGS-POLICY-EVALUATION";

  /** The Constant LEARNINGAIDS_POLICY_REQUEST. */
  public static final String URI_LAD_LEARNINGAIDS_POLICY_REQUEST = "postLearningAidsPolicy.json";

  /** The Constant VALID_CONTENT_URN. */
  public static final String VALID_CONTENT_URN = "eps/sanvan/api/item/65760daf-e997-46d1-bf04-bd77768cad96/1/file/narrative/121291d7-9547-44c2-8263-085389c7782f.html";

  /** The Constant VALID_CONTENT_URL. */
  public static final String VALID_CONTENT_URL = "https://epspqa.stg-openclass.com/";

  /** The Constant TITLE_UUID. */
  public static final String TITLE_UUID = "TITLE_46d14271-baa9-4b51-9847-6de209a2e5cf::6dfcdcba-f8e3-4e8f-9a1d-e127b8b116da";

  /** The Constant ZERO. */
  public static final int ZERO = 0;

  /** The Constant PRODUCT_SCORING_POLICY_ID. */
  public static final String PRODUCT_SCORING_POLICY_ID = "bda15e8e-725f-468e-bf97-826d0abcc323";

  /** The Constant PRODUCT_SCORING_POLICY_VER. */
  public static final String PRODUCT_SCORING_POLICY_VER = "d7807269-63bd-47e9-9911-5acc8bc6fe1e";

  /** The Constant PRODUCT_ID. */
  public static final String PRODUCT_ID = "8883c099-1762-43fe-9ad8-4c9aaa6eafa2";

  /** The Constant PRODUCT_VER. */
  public static final String PRODUCT_VER = "200a3768-17af-4f2f-9d4c-b07c6cdfc456";

  /**
   * Instantiates a new testing constants.
   */
  private TestingConstants() {
    super();
  }
}