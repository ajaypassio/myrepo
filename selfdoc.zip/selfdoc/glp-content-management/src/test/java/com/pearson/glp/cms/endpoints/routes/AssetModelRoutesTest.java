/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningmodel.CategorySchema;
import com.pearson.glp.cms.dto.learningmodel.request.AssetModelPayload;
import com.pearson.glp.cms.dto.learningmodel.response.BulkLearningModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceException;

import reactor.core.publisher.Mono;

/**
 * The Class AssetModelProvisioningRoutesTest.
 */
public class AssetModelRoutesTest extends ProducerBase {

  /**
   * Instantiates a new asset model routes test.
   */
  public AssetModelRoutesTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test get all asset models.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAssetModels() throws ServiceException {

    List<GLPAssetModel> learningModelResponseList = new ArrayList<>();
    learningModelResponseList.add(getAssetModelResponse());
    learningModelResponseList.add(getAssetModelResponse());
    BulkLearningModels assetModelResponse = new BulkLearningModels();
    assetModelResponse.setCount(2);
    assetModelResponse.setAssetModels(learningModelResponseList);

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelResponse));

    webTestClient.get().uri(TestingConstants.ASSET_MODEL_ROUTE).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk();
  }

  /**
   * Test get asset model by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelById() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.get().uri(TestingConstants.ASSET_MODEL_ROUTE + TestingConstants.ASSET_MODEL_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Test create instruction model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateInstructionModel() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_INSTRUCTION_MODEL_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.INSTRUCTION);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post().uri(TestingConstants.INSTRUCTION_MODEL_ROUTE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Test create assessment model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssessmentModel() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSESSMENT_MODELS_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.ASSESSMENT);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post().uri(TestingConstants.ASSESSMENT_MODEL_ROUTE)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test create assessment item model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssessmentItemModel() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSESSMENT_ITEM_MODELS_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.ASSESSMENT_ITEM);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post().uri(TestingConstants.ASSESSMENT_ITEM_MODEL_ROUTE)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test create aggregate model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAggregateModel() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_AGGREGATE_MODELS_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.AGGREGATE);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post().uri(TestingConstants.AGGREGATE_MODEL_ROUTE)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test create model.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNarrativeModel() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_AGGREGATE_MODELS_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.NARRATIVE);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post().uri(TestingConstants.NARRATIVE_MODEL_ROUTE)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test get all asset models versions by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllAssetModelsVersionsById() throws ServiceException {

    List<GLPAssetModel> learningModelResponseList = new ArrayList<>();
    learningModelResponseList.add(getAssetModelResponse());
    learningModelResponseList.add(getAssetModelResponse());
    BulkLearningModels assetModelResponse = new BulkLearningModels();
    assetModelResponse.setCount(2);
    assetModelResponse.setAssetModels(learningModelResponseList);

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(assetModelResponse));

    webTestClient.get()
        .uri(TestingConstants.ASSET_MODEL_ROUTE + TestingConstants.ASSET_MODEL_ID
            + TestingConstants.VERSIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Test create instruction models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateInstructionModelsVersions() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_INSTRUCTION_MODEL_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.INSTRUCTION);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post()
        .uri(TestingConstants.INSTRUCTION_MODEL_ROUTE + TestingConstants.INSTRUCTION_MODEL_ID
            + TestingConstants.VERSIONS)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test create aggregate models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAggregateModelsVersions() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.AGGREGATE);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post()
        .uri(TestingConstants.AGGREGATE_MODEL_ROUTE + TestingConstants.AGGREGATE_MODEL_ID
            + TestingConstants.VERSIONS)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test create assessment models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateAssessmentModelsVersions() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.ASSESSMENT);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post()
        .uri(TestingConstants.ASSESSMENT_MODEL_ROUTE + TestingConstants.ASSESSMENT_MODEL_ID
            + TestingConstants.VERSIONS)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test create narrative models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateNarrativeModelsVersions() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.NARRATIVE);

    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.post()
        .uri(TestingConstants.NARRATIVE_MODEL_ROUTE + TestingConstants.NARRATIVE_MODEL_ID
            + TestingConstants.VERSIONS)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful();
  }

  /**
   * Test get asset model by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAssetModelByVersionId() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(getAssetModelResponse()));

    webTestClient.get()
        .uri(TestingConstants.ASSET_MODEL_ROUTE + TestingConstants.ASSET_MODEL_ID
            + TestingConstants.VERSIONS + TestingConstants.ASSET_MODEL_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Gets the asset model response.
   *
   * @return the asset model response
   */
  private GLPAssetModel getAssetModelResponse() {
    GLPAssetModel learningModelResponse = new GLPAssetModel();
    learningModelResponse.setId(UUID.randomUUID().toString());
    learningModelResponse.setVer(UUID.randomUUID().toString());
    return learningModelResponse;
  }

  /**
   * Post asset model with validation failed.
   */
  @Test
  public void postAssetModelWithValidationFailed() {
    AssetModelPayload requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSET_MODEL_BAD_REQUEST, AssetModelPayload.class);
    webTestClient.post().uri(contextPath + UriEnum.URI_POST_AGGREGATE_MODELS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetModelPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Post asset model when min property is greater than max property.
   */
  @Test
  public void postAssetModelWhenMinPropertyIsGreaterThanMaxProperty() {
    AssetModelPayload requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSET_MODEL_BAD_REQUEST, AssetModelPayload.class);

    // putting invalid category schema in request body
    requestModel.getResources().get(TestingConstants.DUMMY_ASSESSMENT_ITEMS_ID).getData()
        .setCategorySchema(getInvalidCategorySchema());

    webTestClient.post().uri(contextPath + UriEnum.URI_POST_AGGREGATE_MODELS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetModelPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Gets the invalid category schema.
   *
   * @return the invalid category schema
   */
  private CategorySchema getInvalidCategorySchema() {
    CategorySchema categorySchema = new CategorySchema();
    categorySchema.setMinProperties("2");
    categorySchema.setMaxProperties("1");
    categorySchema.setType("object");
    return categorySchema;
  }

  /**
   * Post asset model version validation failed.
   */
  @Test
  public void postAssetModelVersionValidationFailed() {
    Mono<AssetModelPayload> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSET_MODEL_BAD_REQUEST, AssetModelPayload.class));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_POST_AGGREGATE_MODEL_VERSIONS, CmsConstants.PARAM_ASSET_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, AssetModelPayload.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }
}
