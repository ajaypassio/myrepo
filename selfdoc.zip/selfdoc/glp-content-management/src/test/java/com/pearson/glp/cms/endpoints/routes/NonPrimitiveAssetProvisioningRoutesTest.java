/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import java.util.UUID;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetVersionRequest;
import com.pearson.glp.cms.dto.learningasset.request.AssetsRequest;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;

import reactor.core.publisher.Mono;

/**
 * The Class NonPrimitiveAssetProvisioningRoutesTest.
 *
 * @author sanket.gupta
 */
public class NonPrimitiveAssetProvisioningRoutesTest extends ProducerBase {

  /**
   * Instantiates a new non primitive asset provisioning routes test.
   */
  public NonPrimitiveAssetProvisioningRoutesTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test Get All Instruction Assets.
   *
   * @return the instruction assets
   */
  @Test
  public void getInstructionAssets() {
    BulkAssets model = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.GET_INSTRUCTIONS_RESPONSE, BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));
    webTestClient.get().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkAssets.class).consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Test Get All Instruction Assets with Service Exception.
   *
   * @return the instruction assets with isc error
   */
  @Test
  public void getInstructionAssetsWithIscError() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
            "Error occurred while fetching data from DB")));

    webTestClient.get().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is5xxServerError()
        .expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isBetween(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.NETWORK_AUTHENTICATION_REQUIRED.value()));
  }

  /**
   * Test Create Instruction Assets.
   */
  @Test
  public void createInstructionAssets() {
    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_INSTRUCTIONS_REQUEST, AssetsRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();
    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.CREATED).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetsRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Test Create Instruction Assets with Streaming.
   */
  @Test
  public void createInstructionAssetsWithStreaming() {
    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_INSTRUCTIONS_REQUEST, AssetsRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();
    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.CREATED).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_STREAM_JSON)
        .body(Mono.just(requestModel), AssetsRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Test Create Instruction Assets with ISC Error.
   */
  @Test
  public void createInstructionAssetsWithIscError() {
    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_INSTRUCTIONS_REQUEST, AssetsRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();
    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.BAD_REQUEST).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetsRequest.class).exchange().expectStatus()
        .is4xxClientError().expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isEqualByComparingTo(HttpStatus.BAD_REQUEST.value()));
  }

  /**
   * Test Get Instruction Asset Versions.
   *
   * @return the instruction asset versions
   */
  @Test
  public void getInstructionAssetVersions() {
    LearningAssetVersions assetVersionsResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_INSTRUCTIONS_ALL_VERSIONS_RESPONSE, LearningAssetVersions.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(assetVersionsResponse));
    webTestClient.get().uri(contextPath + UriEnum.URI_INSTRUCTION_VERSIONS, generateUuid())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LearningAssetVersions.class).consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Test get specific version Instruction.
   *
   * @return the specific instruction
   */
  @Test
  public void getSpecificInstruction() {
    GLPLearningAsset nonPrimitiveAsset = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_SPECIFIC_VERSION_OF_INSTRUCTION_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_INSTRUCTION_SPECIFIC_VERSION, generateUuid(),
            generateUuid())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test get specific version learning app.
   *
   * @return the specific learning app
   */
  @Test
  public void getSpecificLearningApp() {
    GLPLearningAsset nonPrimitiveAsset = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_SPECIFIC_VERSION_OF_LEARNING_APP_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_LEARNING_APP_SPECIFIC_VERSION, generateUuid(),
            generateUuid())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test get Instruction By Id.
   *
   * @return the instruction assetby id
   */
  @Test
  public void getInstructionAssetbyId() {
    GLPLearningAsset nonPrimitiveAsset = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_SPECIFIC_VERSION_OF_INSTRUCTION_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    webTestClient.get().uri(contextPath + UriEnum.URI_GET_INSTRUCTION_BY_ID, generateUuid())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("expiresOn"));
  }

  /**
   * Test Create Instruction Asset Version.
   */
  @Test
  public void postInstructionAssetVersion() {

    AssetWithStatus assetResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_INSTRUCTION_RESPONSE, AssetWithStatus.class);
    Mono<AssetVersionRequest> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_INSTRUCTION_REQUEST, AssetVersionRequest.class));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(assetResponse));
    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTION_VERSIONS, generateUuid())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, AssetVersionRequest.class)).exchange()
        .expectStatus().is2xxSuccessful().expectBody(AssetWithStatus.class);

  }

  /**
   * Test Create Instruction Asset Version with Request Validation Failed.
   */
  @Test
  public void postInstructionAssetVersionWithIscError() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.BAD_REQUEST.value(),
            "Request Validation Failed")));

    AssetVersionRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_INSTRUCTION_REQUEST, AssetVersionRequest.class);
    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTION_VERSIONS, generateUuid())
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetVersionRequest.class).exchange().expectStatus()
        .is4xxClientError().expectBody(CustomErrorMessage.class)
        .consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody().getStatus())
            .isEqualTo(HttpStatus.BAD_REQUEST.value()));
  }

  /**
   * Post assessment bad request.
   *
   * @param AssessmentBadRequestBody
   *          the assessment bad request body
   */
  @Test
  public void postAssessmentBadRequest() {
    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_ASSESSMENT_BAD_REQUEST, AssetsRequest.class);
    this.mockWebClientCall();
    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.BAD_REQUEST).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);
    webTestClient.post().uri(contextPath + UriEnum.URI_ASSESSMENTS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetsRequest.class).exchange().expectStatus()
        .is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Post learning app route test.
   */
  @Test
  public void postLearningAppRouteTest() {

    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_LEARNINGAPP_REQUEST_JSON, AssetsRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();
    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.CREATED).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_LEARNING_APPS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetsRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Gets the learning apps by id.
   *
   * @return the learning apps by id
   */
  @Test
  public void getLearningAppsById() {
    GLPLearningAsset nonPrimitiveAsset = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_LEARNING_APPS_BY_ID_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(nonPrimitiveAsset));
    webTestClient.get().uri(contextPath + UriEnum.URI_GET_LEARNING_APPS_BY_ID, generateUuid())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Gets the assessment invalid param.
   *
   * @return the assessment invalid param
   */
  @Test
  public void getAssessmentInvalidParam() {
    CustomErrorMessage model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ASSESSMENT_BAD_RESPONSE, CustomErrorMessage.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get()
        .uri(uriBuilder -> uriBuilder.path(contextPath + UriEnum.URI_ASSESSMENTS)
            .queryParam(TestingConstants.ASSESSMENT, TestingConstants.DUMMY_VALUE).build())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError()
        .expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isEqualByComparingTo(HttpStatus.BAD_REQUEST.value()));

  }

  /**
   * Gets the assessment without param.
   *
   * @return the assessment without param
   */
  @Test
  public void getAssessmentWithoutParam() {
    BulkAssets model = CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_ALL_ASSESSMENT,
        BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get().uri(contextPath + UriEnum.URI_ASSESSMENTS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkAssets.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Post embedded assets.
   */
  @Test
  public void postEmbeddedAssets() {
    AssetsRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_BULK_EMBEDDED_ASSET_REQUEST, AssetsRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();
    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.CREATED).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_EMBEDDED_ASSETS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_STREAM_JSON)
        .body(Mono.just(requestModel), AssetsRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Generate the random UUID.
   *
   * @return the string
   */
  private String generateUuid() {
    return UUID.randomUUID().toString();
  }
}
