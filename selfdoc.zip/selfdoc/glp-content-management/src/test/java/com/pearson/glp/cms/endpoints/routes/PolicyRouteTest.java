/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import static com.pearson.glp.cms.constant.JsonFileConstants.DELIVERY_POLICY_RESPONSE;
import static com.pearson.glp.cms.constant.JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE;
import static com.pearson.glp.cms.constant.JsonFileConstants.POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST;

import java.util.LinkedHashMap;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.LoggingConstants;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningpolicy.request.AssessmentTypePayload;
import com.pearson.glp.cms.dto.learningpolicy.request.CategoryWeightsPayload;
import com.pearson.glp.cms.dto.learningpolicy.request.PolicyPayload;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.learningpolicy.response.RuntimeSettingsResponse;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.enums.CategoryWeightStatus;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;

import reactor.core.publisher.Mono;

/**
 * The Class PolicyRouteTest.
 *
 * @author ajay.kumar8
 */
public class PolicyRouteTest extends ProducerBase {

  /**
   * Instantiates a new product model route test.
   */
  public PolicyRouteTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test post product model learning aids success.
   */
  @Test
  public void testPostProductModelLearningAidsSuccess() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.LEARNINGAIDS_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy learningAidPolicyResponse = CommonUtilsTest.convertJsonToObject(
        TestingConstants.LEARNINGAIDS_POLICY_RESPONSE, GLPLearningPolicy.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { (learningAidPolicyResponse) }));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RENAME_PRODUCT_MODELS_LEARNING_AIDS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange();
  }

  /**
   * Test post product Model run time settings success.
   */
  @Test
  public void testPostProductModelRunTimeSettingsSuccess() {
    AssessmentTypePayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST, AssessmentTypePayload.class);

    GLPLearningAsset productPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(IscSyncResponseFormat.class)))
        .then(invocation -> Mono.just(productPolicyResponse));

    Mono<GLPLearningPolicy[]> postPolicyResponse = Mono
        .just(new GLPLearningPolicy[] { CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.DELIVERY_POLICY_RESPONSE, GLPLearningPolicy.class) });
    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).then(invocationOnMock -> postPolicyResponse);

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), AssessmentTypePayload.class))
        .exchange().expectStatus().isCreated().expectBody(RuntimeSettingsResponse.class);

  }

  /**
   * Test post product model run time settings failed empty policy.
   */
  @Test
  public void testPostProductModelRunTimeSettingsErrorFromLAE() {
    AssessmentTypePayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST, AssessmentTypePayload.class);

    GLPLearningAsset productPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(IscSyncResponseFormat.class)))
        .then(invocation -> Mono.just(productPolicyResponse));

    GLPLearningPolicy[] postPolicyResponse = new GLPLearningPolicy[] { CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.DELIVERY_POLICY_RESPONSE, GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(postPolicyResponse))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
            LoggingConstants.ERROR_CALLING_LAE)))
        .thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), AssessmentTypePayload.class))
        .exchange().expectStatus().isCreated().expectBody(RuntimeSettingsResponse.class)
        .consumeWith(result -> Assertions.assertThat(result.getResponseBody().getEvaluationPolicy())
            .hasFieldOrProperty("errors"));

  }

  /**
   * Test product model category weights.
   */
  @Test
  public void testGetProductModelWeights() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] resolvedPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_PRODUCT_MODELS_WITH_CATEGORY_WEIGHTS, GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(resolvedPolicyResponse));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LinkedHashMap.class);
  }

  /**
   * Test product model learningAids.
   */
  @Test
  public void testGetProductModelLearningAids() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] resolvedPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_LEARNING_AID_RESPONSE,
            GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(resolvedPolicyResponse));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_MODEL_LEARNING_AIDS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product model category weights success.
   */
  @Test
  public void testPostProductModelCategoryWeightsSuccess() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_REQUEST,
        CategoryWeightsPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = new GLPLearningPolicy();
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    resolvedPolicyResponse.setErrors(CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.NOT_FOUND_RESPONSE, CustomErrorMessage.class));
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { postPolicyResponse }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isCreated().expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product model category weights success.
   */
  @Test
  public void testPostProductModelVersionCategoryWeightsSuccess() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_REQUEST,
        CategoryWeightsPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.EVALUATION_POLICY_RESPONSE, GLPLearningPolicy.class);
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isCreated().expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product model wrong status.
   */
  @Test
  public void testPostProductModelWrongStatus() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_REQUEST,
        CategoryWeightsPayload.class);
    request.setStatus(CategoryWeightStatus.ACTIVE.getVal());
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.EVALUATION_POLICY_RESPONSE, GLPLearningPolicy.class);
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isEqualTo(HttpStatus.BAD_REQUEST);

  }

  /**
   * Test post product model wrong status.
   */
  @Test
  public void testPostProductModelWrongCategoryWeights() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_MODEL_CATEGORY_WEIGHTS_REQUEST,
        CategoryWeightsPayload.class);
    request.getGradebookCategoryPolicy().getData().getGradebookCategoryPolicies()
        .get(TestingConstants.ZERO).setAssessmentType(null);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.EVALUATION_POLICY_RESPONSE, GLPLearningPolicy.class);
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_CATEGORY_WEIGHTS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isEqualTo(HttpStatus.BAD_REQUEST);

  }

  /**
   * Test get product model scoring policy.
   */
  @Test
  public void testGetProductModelScoringPolicy() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_MODEL_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] resolvedPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_PRODUCT_SCORING_POLICY_RESPONSE,
            GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(resolvedPolicyResponse));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODEL_SCORING_POLICY, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product scoring policy success.
   */
  @Test
  public void testPostProductModelScoringPolicySuccess() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy productScoringPolicyResponse = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { (productScoringPolicyResponse) }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_SCORING_POLICY, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange();
  }

  /**
   * Test post product scoring policy failed.
   */
  @Test
  public void testpostProductModelScoringPolicyFailed() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_POLICY_GROUP_WITHOUT_TITLE, GLPLearningAsset.class);
    GLPLearningAsset productScoringPolicyResponse = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));

    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningAsset[] { (productScoringPolicyResponse) }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_SCORING_POLICY, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test get product model assessment runtime setting.
   */
  @Test
  public void testGetProducModeltAssessmentRunTimeSettings() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);

    GLPLearningPolicy[] deliveryPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_DELIVERY_RESOLVED_POLICY,
            GLPLearningPolicy.class) };

    GLPLearningPolicy[] engagementPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_ENGAGEMENT_RESOLVED_POLICY,
            GLPLearningPolicy.class) };

    GLPLearningPolicy[] evaluationPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_EVALUATION_RESOLVED_POLICY,
            GLPLearningPolicy.class) };

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(deliveryPolicyResponse))
        .thenReturn(Mono.just(engagementPolicyResponse))
        .thenReturn(Mono.just(evaluationPolicyResponse));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODELS_ASSESSMENT_RUNTIME_SETTINGS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();

  }

  /**
   * Test get resolved policies.
   */
  @Test
  public void testGetResolvedPolicies() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_CONFIGURATION_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] resolvedPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_LEARNING_AID_RESPONSE,
            GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(resolvedPolicyResponse));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_LEARNING_AIDS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test map product assessment types success.
   */
  @Test
  public void testMapProductAssessmentTypesSuccess() {
    PolicyPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_MAP_ASSESSMENT_TYPE_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] postPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(DELIVERY_POLICY_RESPONSE, GLPLearningPolicy.class) };

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MAP_ASSESSMENT_TYPES, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange()
        .expectStatus().isCreated().expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test map product assessment types failed.
   */
  @Test
  public void testMapProductAssessmentTypesFailed() {
    PolicyPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_MAP_ASSESSMENT_TYPE_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_POLICY_GROUP_EMPTY_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MAP_ASSESSMENT_TYPES, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test post product map learningAId type success.
   */
  @Test
  public void testPostLearningAidsSuccess() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.LEARNINGAIDS_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy learningAidPolicyResponse = CommonUtilsTest.convertJsonToObject(
        TestingConstants.LEARNINGAIDS_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { (learningAidPolicyResponse) }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RENAME_LEARNING_AIDS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange();
  }

  /**
   * Test post product map learningAId type failed.
   */
  @Test
  public void testPostLearningAidsFailed() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.LEARNINGAIDS_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_POLICY_GROUP_WITHOUT_TITLE, GLPLearningAsset.class);
    GLPLearningAsset learningAidPolicyResponse = CommonUtilsTest
        .convertJsonToObject(TestingConstants.LEARNINGAIDS_POLICY_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));

    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningAsset[] { (learningAidPolicyResponse) }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RENAME_LEARNING_AIDS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test get product assessment runtime setting.
   */
  @Test
  public void testGetProductAssessmentRunTimeSettings() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);

    GLPLearningPolicy[] deliveryPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_DELIVERY_RESOLVED_POLICY,
            GLPLearningPolicy.class) };

    GLPLearningPolicy[] engagementPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_ENGAGEMENT_RESOLVED_POLICY,
            GLPLearningPolicy.class) };

    GLPLearningPolicy[] evaluationPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_EVALUATION_RESOLVED_POLICY,
            GLPLearningPolicy.class) };

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(deliveryPolicyResponse))
        .thenReturn(Mono.just(engagementPolicyResponse))
        .thenReturn(Mono.just(evaluationPolicyResponse));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();

  }

  /**
   * Test get product assessment types.
   */
  @Test
  public void testGetProductAssessmentTypes() {
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_ASSESSMENT_TYPES, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();

  }

  /**
   * Test post product run time settings success.
   */
  @Test
  public void testPostProductRunTimeSettingsSuccess() {
    AssessmentTypePayload request = CommonUtilsTest
        .convertJsonToObject(POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST, AssessmentTypePayload.class);

    GLPLearningAsset productPolicyResponse = CommonUtilsTest
        .convertJsonToObject(GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(IscSyncResponseFormat.class)))
        .then(invocation -> Mono.just(productPolicyResponse));

    Mono<GLPLearningPolicy[]> postPolicyResponse = Mono.just(new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(DELIVERY_POLICY_RESPONSE, GLPLearningPolicy.class) });
    Mockito.when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any(), Mockito.any())).then(invocationOnMock -> postPolicyResponse);

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), AssessmentTypePayload.class))
        .exchange().expectStatus().isCreated().expectBody(RuntimeSettingsResponse.class);

  }

  /**
   * Test post product run time settings failed empty policy.
   */
  @Test
  public void testPostProductRunTimeSettingsErrorFromLAE() {
    AssessmentTypePayload request = CommonUtilsTest
        .convertJsonToObject(POST_ASSESSMENT_RUNTIME_SETTINGS_REQUEST, AssessmentTypePayload.class);

    GLPLearningAsset productPolicyResponse = CommonUtilsTest
        .convertJsonToObject(GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(IscSyncResponseFormat.class)))
        .then(invocation -> Mono.just(productPolicyResponse));

    GLPLearningPolicy[] postPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(DELIVERY_POLICY_RESPONSE, GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(postPolicyResponse))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
            LoggingConstants.ERROR_CALLING_LAE)))
        .thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_ASSESSMENT_RUNTIME_SETTINGS,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), AssessmentTypePayload.class))
        .exchange().expectStatus().isCreated().expectBody(RuntimeSettingsResponse.class)
        .consumeWith(result -> Assertions.assertThat(result.getResponseBody().getEvaluationPolicy())
            .hasFieldOrProperty("errors"));

  }

  /**
   * Test post product category weights success.
   */
  @Test
  public void testPostProductCategoryWeightsSuccess() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_CATEGORY_WEIGHTS_REQUEST, CategoryWeightsPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = new GLPLearningPolicy();
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    resolvedPolicyResponse.setErrors(CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.NOT_FOUND_RESPONSE, CustomErrorMessage.class));
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { postPolicyResponse }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isCreated().expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product category weights version success.
   */
  @Test
  public void testPostProductCategoryWeightsVersionSuccess() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_CATEGORY_WEIGHTS_REQUEST, CategoryWeightsPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.EVALUATION_POLICY_RESPONSE, GLPLearningPolicy.class);
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isCreated().expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product category weights with status inactive.
   */
  @Test
  public void testPostProductCategoryWeightsWithStatusInActive() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_CATEGORY_WEIGHTS_REQUEST, CategoryWeightsPayload.class);
    request.setStatus(CategoryWeightStatus.INACTIVE.getVal());
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy resolvedPolicyResponse = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.EVALUATION_POLICY_RESPONSE, GLPLearningPolicy.class);
    resolvedPolicyResponse.setAssetClass(AssetClass.GRADE_BOOK_CATEGORY_POLICY.value());
    GLPLearningPolicy postPolicyResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.CATEGORY_WEIGHT_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyResponse }));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(postPolicyResponse));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isCreated().expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product category weights not equal to 100.
   */
  @Test
  public void testPostProductCategoryWeightsNotEqualTo100() {
    CategoryWeightsPayload request = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_CATEGORY_WEIGHTS_REQUEST, CategoryWeightsPayload.class);
    request.getGradebookCategoryPolicy().getData().getGradebookCategoryPolicies().get(0)
        .setWeight(10);

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), CategoryWeightsPayload.class))
        .exchange().expectStatus().isBadRequest();
  }

  /**
   * Test product category weights.
   */
  @Test
  public void testGetProductWeights() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_CONFIGURATION_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] resolvedPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_PRODUCT_MODELS_WITH_CATEGORY_WEIGHTS, GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(resolvedPolicyResponse));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_CATEGORY_WEIGHTS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LinkedHashMap.class);
  }

  /**
   * Test get product scoring policy.
   */
  @Test
  public void testGetProductScoringPolicy() {

    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_CONFIGURATION_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy[] resolvedPolicyResponse = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_PRODUCT_SCORING_POLICY_RESPONSE,
            GLPLearningPolicy.class) };
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(policyGroupResponse)).thenReturn(Mono.just(resolvedPolicyResponse));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_SCORING_POLICY,
            TestingConstants.PRODUCT_SCORING_POLICY_ID, TestingConstants.PRODUCT_SCORING_POLICY_VER)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningPolicy.class);
  }

  /**
   * Test post product scoring policy success.
   */
  @Test
  public void testPostProductScoringPolicySuccess() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_POLICY_GROUP_RESPONSE, GLPLearningAsset.class);
    GLPLearningPolicy productScoringPolicyResponse = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_RESPONSE, GLPLearningPolicy.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { (productScoringPolicyResponse) }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_SCORING_POLICY, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange();
  }

  /**
   * Test post product scoring policy failed.
   */
  @Test
  public void testpostProductScoringPolicyFailed() {
    PolicyPayload request = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_REQUEST, PolicyPayload.class);
    GLPLearningAsset policyGroupResponse = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_POLICY_GROUP_WITHOUT_TITLE, GLPLearningAsset.class);
    GLPLearningAsset productScoringPolicyResponse = CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_RESPONSE, GLPLearningAsset.class);

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(policyGroupResponse));

    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningAsset[] { (productScoringPolicyResponse) }));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_SCORING_POLICY, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(request), PolicyPayload.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

}
