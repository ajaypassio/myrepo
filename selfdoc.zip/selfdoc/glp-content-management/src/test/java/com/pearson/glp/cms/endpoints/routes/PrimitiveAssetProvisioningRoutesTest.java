/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningasset.request.AssetPayload;
import com.pearson.glp.cms.dto.learningasset.request.AssetVersionRequest;
import com.pearson.glp.cms.dto.learningasset.request.AssetsRequest;
import com.pearson.glp.cms.dto.learningasset.response.AssetWithStatus;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.crosscutting.isc.client.commons.validation.BeanValidator;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * The Class PrimitiveAssetProvisioningRoutesTest.
 */
public class PrimitiveAssetProvisioningRoutesTest extends ProducerBase {

  /**
   * Instantiates a new primitive asset provisioning routes test.
   */
  public PrimitiveAssetProvisioningRoutesTest() {
    super();
  }

  @Before
  public void setUp() {
    BeanValidator beanValidator = new BeanValidator();
    ReflectionTestUtils.setField(BeanValidator.class, "staticLink", beanValidator);
    ReflectionTestUtils.setField(beanValidator, "isValidationEnabled", true);
    ReflectionTestUtils.setField(beanValidator, "failFastFlag", "false");
    ReflectionTestUtils.setField(beanValidator, "restValidationEnabled", true);
  }

  /**
   * Test get narratives.
   */
  @Test
  public void testGetNarratives() {

    BulkAssets model = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.GET_BULK_NARRATIVES_RESPONSE, BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get().uri(contextPath + UriEnum.URI_NARRATIVES).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkAssets.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }

  /**
   * Test post bulk narratives.
   */
  @Test
  public void testPostBulkNarratives() {
    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_NARRATIVES_REQUEST, AssetsRequest.class);
    Flux<AssetPayload> requestFlux = Flux.fromIterable(requestModel.getAssets());
    Mockito
        .when(iscSyncClient.postObjects(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Flux.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_BULK_NARRATIVES_RESPONSE, AssetWithStatus.class)));

    webTestClient.post().uri(contextPath + UriEnum.URI_NARRATIVES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestFlux, AssetPayload.class)).exchange()
        .expectStatus().is2xxSuccessful().expectBodyList(AssetWithStatus.class);
  }

  /**
   * Test post bulk narratives validation failed.
   */
  @Test
  public void testPostBulkNarrativesValidationFailed() {

    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_ASSETS_BAD_REQUEST, AssetsRequest.class);
    Flux<AssetPayload> requestFlux = Flux.fromIterable(requestModel.getAssets());
    Mockito
        .when(iscSyncClient.postObjects(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Flux.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_ASSETS_ERROR_RESPONSE, AssetWithStatus.class)));
    webTestClient.post().uri(contextPath + UriEnum.URI_NARRATIVES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestFlux, AssetPayload.class)).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS).expectBodyList(AssetWithStatus.class);
  }

  /**
   * Test get narratives versions.
   */
  @Test
  public void testGetNarrativesVersions() {

    LearningAssetVersions model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_NARRATIVES_ALL_VERSIONS_RESPONSE, LearningAssetVersions.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_NARRATIVE_VERSIONS, TestingConstants.DUMMY_NARRATIVE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LearningAssetVersions.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Test add narratives versions.
   */
  @Test
  public void testAddNarrativesVersions() {

    AssetVersionRequest requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NARRATIVES_NEW_VERSION_REQUEST, AssetVersionRequest.class);
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_NARRATIVES_NEW_VERSION_RESPONSE, AssetWithStatus.class)));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_NARRATIVE_VERSIONS, TestingConstants.DUMMY_NARRATIVE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus().is2xxSuccessful()
        .expectBody(AssetWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("error", "status"));
  }

  /**
   * Test add narratives versions validation failed.
   */
  @Test
  public void testAddNarrativesVersionsValidationFailed() {

    AssetVersionRequest requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NARRATIVES_VERSION_BAD_REQUEST, AssetVersionRequest.class);

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_NARRATIVE_VERSIONS, TestingConstants.DUMMY_NARRATIVE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject(requestBody)).exchange().expectStatus().is4xxClientError()
        .expectBody(CustomErrorMessage.class);
  }

  /**
   * Gets the specific narrative versions.
   *
   * @return the specific narrative versions
   */
  @Test
  public void getNarrativesByIdAndVersion() {

    GLPLearningAsset model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_NARRATIVES_BY_ID_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_NARRATIVE_SPECIFIC_VERSION,
            TestingConstants.DUMMY_NARRATIVE_ID, TestingConstants.DUMMY_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test get narrative by id.
   */
  @Test
  public void testGetNarrativeById() {

    GLPLearningAsset model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_NARRATIVES_BY_ID_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_NARRATIVE_BY_ID, TestingConstants.DUMMY_NARRATIVE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Gets the specific assessment items by id.
   *
   * @return the specific assessment items by id
   */
  @Test
  public void getAssessmentItemById() {
    GLPLearningAsset model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ASSESSMENT_ITEMS_BY_ID_VERSION_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESSMENT_ITEM_BY_ID,
            TestingConstants.DUMMY_ASSESSMENT_ITEMS_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Gets the assessment items.
   *
   * @return the assessment items
   */
  @Test
  public void getAssessmentItems() {
    BulkAssets model = CommonUtilsTest.convertJsonToObject(JsonFileConstants.GET_ASSESSMENT_ITEMS,
        BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));
    webTestClient.get().uri(contextPath + UriEnum.URI_ASSESSMENT_ITEMS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkAssets.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Gets the assessment items without query parameter.
   *
   * @return the assessment items without query parameter
   */
  @Test
  public void getAssessmentItemsInvalidQueryParameter() {
    CustomErrorMessage model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ASSESSMENT_ITEMS_BAD_REQUEST, CustomErrorMessage.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get()
        .uri(uriBuilder -> uriBuilder.path(contextPath + UriEnum.URI_ASSESSMENT_ITEMS)
            .queryParam(TestingConstants.ASSESSMENT, TestingConstants.DUMMY_VALUE).build())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError()
        .expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.LINKS));
  }

  /**
   * Gets the specific assessment items versions.
   *
   * @return the specific assessment items versions
   */
  @Test
  public void getAssessmentItemsVersions() {
    GLPLearningAsset model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ASSESSMENT_ITEMS_BY_ID_VERSION_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESSMENT_ITEM_SPECIFIC_VERSION,
            TestingConstants.DUMMY_ASSESSMENT_ITEMS_ID, TestingConstants.DUMMY_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test post bulk assessment item.
   */
  @Test
  public void testPostBulkAssessmentItem() {

    AssetsRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_BULK_ASSESMENT_ITEM_REQUEST, AssetsRequest.class);
    Flux<AssetPayload> requestFlux = Flux.fromIterable(requestModel.getAssets());

    Mockito
        .when(iscSyncClient.postObjects(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Flux.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_ASSESSMENT_ITEM_RESPONSE, AssetWithStatus.class)));

    webTestClient.post().uri(contextPath + UriEnum.URI_ASSESSMENT_ITEMS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestFlux, AssetPayload.class)).exchange()
        .expectStatus().is2xxSuccessful().expectBodyList(AssetWithStatus.class);
  }

  /**
   * Test Post assessment item bad request.
   */
  @Test
  public void postAssessItemBadRequest() {
    AssetsRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_ASSESS_ITEMS_BAD_REQUEST, AssetsRequest.class);
    Flux<AssetPayload> requestFlux = Flux.fromIterable(requestModel.getAssets());
    Mockito
        .when(iscSyncClient.postObjects(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Flux.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_RESOURCES_ERROR_RESPONSE, AssetWithStatus.class)));

    webTestClient.post().uri(contextPath + UriEnum.URI_ASSESSMENT_ITEMS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestFlux, AssetPayload.class)).exchange()
        .expectStatus().isEqualTo(HttpStatus.MULTI_STATUS);
  }

  /**
   * Test get learning app items by id and version.
   */
  @Test
  public void testGetLearningAppItemsByIdAndVersion() {
    GLPLearningAsset model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_LEARNING_APP_ITEMS_BY_ID_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_LEARNING_APP_ITEM_SPECIFIC_VERSION.value(),
            TestingConstants.DUMMY_ASSESSMENT_ITEMS_ID, TestingConstants.DUMMY_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test post bulk learning app item.
   */
  @Test
  public void testPostBulkLearningAppItem() {
    AssetsRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_BULK_LEARNING_APP_ITEM_REQUEST, AssetsRequest.class);
    Flux<AssetPayload> requestFlux = Flux.fromIterable(requestModel.getAssets());

    Mockito
        .when(iscSyncClient.postObjects(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Flux.just(CommonUtilsTest
            .convertJsonToObject(JsonFileConstants.POST_LEARNINGAPPS_JSON, AssetWithStatus.class)));

    webTestClient.post().uri(contextPath + UriEnum.URI_LEARNING_APP_ITEMS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestFlux, AssetPayload.class)).exchange()
        .expectStatus().is2xxSuccessful();
  }

  /**
   * Test get learning app items by id.
   */
  @Test
  public void testGetLearningAppItemsById() {
    GLPLearningAsset model = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_LEARNING_APP_ITEMS_BY_ID_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_LEARNING_APP_ITEM_BY_ID.value(),
            TestingConstants.DUMMY_ASSESSMENT_ITEMS_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }
}