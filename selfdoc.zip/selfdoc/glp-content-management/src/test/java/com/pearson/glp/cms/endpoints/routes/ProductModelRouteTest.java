/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.dto.learningmodel.request.AssetModelPayload;
import com.pearson.glp.cms.dto.learningmodel.response.BulkProductModels;
import com.pearson.glp.cms.dto.learningmodel.response.GLPAssetModel;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtils;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceException;

import reactor.core.publisher.Mono;

/**
 * The Class ProductModelRouteTest.
 *
 * @author nitin.tyagi1
 */
public class ProductModelRouteTest extends ProducerBase {

  /**
   * Instantiates a new product model route test.
   */
  public ProductModelRouteTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test get all product models.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProductModels() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_BULK_PRODUCT_MODEL_RESPONSE, BulkProductModels.class)));

    webTestClient.get().uri(contextPath + UriEnum.URI_PRODUCT_MODELS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkProductModels.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Test create product model.
   *
   * @throws ServiceException
   *           the service exception
   */

  @Test
  public void testCreateProductModel() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_AGGREGATE_MODELS_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.PRODUCT_MODEL_LABEL);

    Mockito
        .when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_BULK_PRODUCT_MODEL_RESPONSE, GLPAssetModel.class)));

    webTestClient.post().uri(contextPath + UriEnum.URI_PRODUCT_MODELS)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("createdBy", "lastModified"));
  }

  /**
   * Test create product model versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testCreateProductModelsVersions() throws ServiceException {

    AssetModelPayload assetModelPayload = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_NEW_VERSION_OF_AGGREGATE_MODEL_REQUEST, AssetModelPayload.class);
    assetModelPayload.setAssetType(TestingConstants.PRODUCT_MODEL_LABEL);

    Mockito
        .when(iscSyncClient.postObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_NEW_PRODUCT_MODEL_VERSION_RESPONSE, GLPAssetModel.class)));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODEL_VERSIONS, TestingConstants.PRODUCT_MODEL_ID)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(assetModelPayload), AssetModelPayload.class)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is2xxSuccessful()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("createdBy", "lastModified"));
  }

  /**
   * Test get product models versions.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductModelsVersions() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_PRODUCT_MODEL_ALL_VERSION_RESPONSE, BulkProductModels.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODEL_VERSIONS, TestingConstants.PRODUCT_MODEL_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkProductModels.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Test product models by id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductModelById() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_PRODUCT_MODEL_BY_ID_RESPONSE, GLPAssetModel.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODEL_BY_ID, TestingConstants.PRODUCT_MODEL_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("createdBy", "lastModified"));
  }

  /**
   * Test product models by version id.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductModelByVersionId() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_PRODUCT_MODEL_BY_ID_RESPONSE, GLPAssetModel.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_MODEL_SPECIFIC_VERSION,
            TestingConstants.PRODUCT_MODEL_ID, TestingConstants.PRODUCT_MODEL_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPAssetModel.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("createdBy", "lastModified"));
  }

  /**
   * Post product model without configuration.
   */
  @Test
  public void postProductModelWithoutConfiguration() {
    AssetModelPayload requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSET_MODEL_BAD_REQUEST, AssetModelPayload.class);

    // removing configuration from request body
    requestModel.setConfiguration(null);

    webTestClient.post().uri(contextPath + UriEnum.URI_PRODUCT_MODELS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetModelPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Post product model with validation failed.
   */
  @Test
  public void postProductModelWithValidationFailed() {
    AssetModelPayload requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSET_MODEL_BAD_REQUEST, AssetModelPayload.class);
    webTestClient.post().uri(contextPath + UriEnum.URI_PRODUCT_MODELS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), AssetModelPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Post product model version validation failed.
   */
  @Test
  public void postProductModelVersionValidationFailed() {
    Mono<AssetModelPayload> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSET_MODEL_BAD_REQUEST, AssetModelPayload.class));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_MODEL_VERSIONS, CmsConstants.PARAM_ASSET_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, AssetModelPayload.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test get all product model collection details.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProductModelCollectionDetails() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_BULK_PRODUCT_MODEL_RESPONSE, BulkProductModels.class)));

    webTestClient.get()
        .uri(contextPath + CommonUtils.addQueryParams(UriEnum.URI_PRODUCT_MODELS.value(),
            CmsConstants.COLLECTION_DETAILS, CmsConstants.LABEL))
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Test get all product model empty collection details.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProductModelEmptyCollectionDetails() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_BULK_PRODUCT_MODEL_RESPONSE, BulkProductModels.class)));

    webTestClient.get()
        .uri(contextPath + CommonUtils.addQueryParams(UriEnum.URI_PRODUCT_MODELS.value(),
            CmsConstants.COLLECTION_DETAILS, CmsConstants.EMPTY))
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test get all product model invalid collection details.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetAllProductModelInvalidQueryParam() throws ServiceException {

    Mockito
        .when(iscSyncClient.getObject(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_BULK_PRODUCT_MODEL_RESPONSE, BulkProductModels.class)));

    webTestClient.get()
        .uri(contextPath + CommonUtils.addQueryParams(UriEnum.URI_PRODUCT_MODELS.value(),
            CmsConstants.GROUP, CmsConstants.LABEL))
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }
}
