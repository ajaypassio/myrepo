/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.codec.DecodingException;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.dto.common.AssetGraph;
import com.pearson.glp.cms.dto.learningasset.request.ProductPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductStateTransitionPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductStatusPayload;
import com.pearson.glp.cms.dto.learningasset.request.ProductVersionRequest;
import com.pearson.glp.cms.dto.learningasset.response.BulkAssets;
import com.pearson.glp.cms.dto.learningasset.response.GLPLearningAsset;
import com.pearson.glp.cms.dto.learningasset.response.LearningAssetVersions;
import com.pearson.glp.cms.dto.learningasset.response.ProductStateTransition;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.products.ConfigurationCompleteEventDetails;
import com.pearson.glp.cms.dto.products.ConfigurationCompleteStatus;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.enums.QueryParamKeys;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceException;
import com.pearson.glp.crosscutting.isc.client.sync.model.RequestValidationException;

import reactor.core.publisher.Mono;

/**
 * The Class ProductsProvisioningRoutesTest.
 * 
 * @author bharat.aggarwal
 *
 */
public class ProductsRoutesTest extends ProducerBase {

  /**
   * Instantiates a new products routes test.
   */
  public ProductsRoutesTest() {
    super();
  }

  /** Inits the. */
  @Before
  public void init() {
    MockitoAnnotations.initMocks(this);

  }

  /**
   * Gets the product without query string.
   *
   * @return the product without query string
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductWithoutQueryString() throws ServiceException {
    BulkAssets response = CommonUtilsTest.convertJsonToObject(JsonFileConstants.PRODUCTS,
        BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));
    webTestClient.get().uri(contextPath + UriEnum.URI_PRODUCTS).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkAssets.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test get products with ID query string.
   *
   * @return the product with id query string
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductWithIdQueryString() throws ServiceException {
    BulkAssets response = CommonUtilsTest.convertJsonToObject(JsonFileConstants.PRODUCTS,
        BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));
    webTestClient.get()
        .uri(uriBuilder -> uriBuilder.path(contextPath + UriEnum.URI_PRODUCTS)
            .queryParam(QueryParamKeys.ID.value(), TestingConstants.DUMMY_VALUE).build())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkAssets.class).consumeWith(exchangeResponse -> {
          GLPLearningAsset product = exchangeResponse.getResponseBody().getAssets().get(0);
          Assertions.assertThat(product.getId()).isNotNull();
          Assertions.assertThat(product.getDocType()).isNotNull();
          Assertions.assertThat(product.getAssetType()).isNotNull();
          Assertions.assertThat(product.getVer()).isNotNull();
        });
  }

  /**
   * Gets the product with tags query string.
   *
   * @return the product with tags query string
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductWithTagsQueryString() throws ServiceException {
    BulkAssets products = CommonUtilsTest.convertJsonToObject(JsonFileConstants.PRODUCTS,
        BulkAssets.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(products));
    webTestClient.get()
        .uri(uriBuilder -> uriBuilder.path(contextPath + UriEnum.URI_PRODUCTS)
            .queryParam(QueryParamKeys.TAGS.value(), TestingConstants.DUMMY_VALUE).build())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkAssets.class).consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody()).isNotNull());
  }

  /**
   * Gets the products by extensions metadata.
   *
   * @return the products by extensions metadata
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductsByExtensionsMetadata() throws ServiceException {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(
            CommonUtilsTest.convertJsonToObject(JsonFileConstants.PRODUCTS, BulkAssets.class)));

    webTestClient.get()
        .uri(uriBuilder -> uriBuilder.path(contextPath + UriEnum.URI_PRODUCTS)
            .queryParam(QueryParamKeys.CONTENTMETADATA_ID.value(), TestingConstants.DUMMY_VALUE)
            .build())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(BulkAssets.class).consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody()).isNotNull());
  }

  /**
   * Test get product by id and versions.
   *
   * @return the product by id and version
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductByIdAndVersion() throws ServiceException {
    GLPLearningAsset response = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_BY_ID_AND_VERSION_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_SPECIFIC_VERSION, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Test get product state transition.
   *
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void testGetProductStateTransition() throws ServiceException {
    ProductStateTransition response = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_STATE_TRANSITION_RESPONSE, ProductStateTransition.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_STATE_TRANSITION, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ProductStateTransition.class).consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody()).isNotNull());
  }

  /**
   * Test get product by id.
   *
   * @return the product by id
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductById() throws ServiceException {
    GLPLearningAsset response = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_BY_ID_AND_VERSION_RESPONSE, GLPLearningAsset.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_BY_ID, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPLearningAsset.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.EXPIRESON));
  }

  /**
   * Gets the product versions.
   *
   * @return the product versions
   */
  @Test
  public void getProductVersions() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            TestingConstants.GET_PRODUCT_VERSIONS_BY_ID_RESPONSE, LearningAssetVersions.class)));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_VERSIONS, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(LearningAssetVersions.class).consumeWith(exchangeResponse -> Assertions
            .assertThat(exchangeResponse.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Gets the product status by id and versions.
   *
   * @return the product status by id and versions
   */
  @Test
  public void getProductStatus() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.PRODUCT_STATUS_RESPONSE, ProductStateTransition.class)));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_PRODUCT_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ProductStateTransition.class)
        .consumeWith(exchangeResponse -> Assertions.assertThat(exchangeResponse.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.VER, CmsConstants.CREATED,
                CmsConstants.PREVIOUS_STATE, CmsConstants.TRANSITION_STATE, CmsConstants.REASON,
                CmsConstants.REASON_CODE));
  }

  /**
   * Test post product.
   */
  @Test
  public void testPostProduct() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(JsonFileConstants.PRODUCT_POST,
            ProductPayload.class)));
    Mono<ProductPayload> requestBody = Mono.just(CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_REQUEST_PRODUCT, ProductPayload.class));
    webTestClient.post().uri(contextPath + UriEnum.URI_PRODUCTS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ProductPayload.class)).exchange()
        .expectStatus().isCreated().expectBody(GLPLearningAsset.class);
  }

  /**
   * Test post new versions product.
   */
  @Test
  public void testPostNewVersionsProduct() {
    Mono<ProductVersionRequest> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_REQUEST_PRODUCT_VERSION, ProductVersionRequest.class));
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(requestBody));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ProductVersionRequest.class)).exchange()
        .expectStatus().isCreated().expectBody(GLPLearningAsset.class);
  }

  /**
   * Test post product state transition.
   */
  @Test
  public void testPostProductStateTransition() {
    ProductStateTransitionPayload requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_STATE_TRANSITION_REQUEST_JSON,
        ProductStateTransitionPayload.class);
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(requestBody));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_STATE_TRANSITION, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(requestBody),
            ProductStateTransitionPayload.class))
        .exchange().expectStatus().isCreated().expectBody(ProductStateTransition.class);
  }

  /**
   * Post product state transition validation failed.
   */
  @Test
  public void postProductStateTransitionValidationFailed() {
    ProductStateTransitionPayload requestBody = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_STATE_TRANSITION_BAD_REQUEST,
        ProductStateTransitionPayload.class);
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_STATE_TRANSITION, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(Mono.just(requestBody),
            ProductStateTransitionPayload.class))
        .exchange().expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test post product with validation failed.
   */
  @Test
  public void testPostProductWithValidationFailed() {
    ProductPayload requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_PRODUCT_BAD_REQUEST, ProductPayload.class);
    webTestClient.post().uri(contextPath + UriEnum.URI_PRODUCTS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ProductPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Test post product with validation failed when asset graph is invalid.
   */
  @Test
  public void testPostProductWithValidationFailedWhenAssetGraphIsInvalid() {
    ProductPayload requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_REQUEST_PRODUCT, ProductPayload.class);

    // Adding two invalid assetgraph nodes in request body
    requestModel.getAsset().getAssetGraph().add(new AssetGraph());
    requestModel.getAsset().getAssetGraph().add(new AssetGraph());

    webTestClient.post().uri(contextPath + UriEnum.URI_PRODUCTS)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ProductPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Test post product versions with validation failed.
   */
  @Test
  public void testPostProductVersionsWithValidationFailed() {
    ProductVersionRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_PRODUCT_VERSION_BAD_REQUEST, ProductVersionRequest.class);
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_PRODUCT_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ProductVersionRequest.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Test put product status.
   */
  @Test
  public void testPutProductStatus() {
    Mockito
        .when(iscSyncClient.putObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.PRODUCT_STATUS_RESPONSE, ProductStateTransition.class)));
    Mono<ProductStatusPayload> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.PUT_PRODUCT_STATUS_REQUEST_JSON, ProductStatusPayload.class));
    webTestClient.put()
        .uri(contextPath + UriEnum.URI_PRODUCT_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ProductStatusPayload.class)).exchange()
        .expectStatus().isOk().expectBody(ProductStateTransition.class);
  }

  /**
   * Test put product status with validation failed.
   */
  @Test
  public void testPutProductStatusWithValidationFailed() {
    ProductStatusPayload requestBody = new ProductStatusPayload();
    webTestClient.put()
        .uri(contextPath + UriEnum.URI_PRODUCT_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestBody), ProductStatusPayload.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Gets the product asset types.
   *
   * @return the product asset types
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductAssetTypes() throws ServiceException {
    ProductAssetTypes response = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_ASSET_TYPES_RESPONSE, ProductAssetTypes.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_ASSET_TYPES, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Gets the product asset types with query param.
   *
   * @return the product asset types with query param
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductAssetTypesWithQueryParam() throws ServiceException {
    ProductAssetTypes response = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_ASSET_TYPES_RESPONSE, ProductAssetTypes.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response));
    webTestClient.get()
        .uri(uriBuilder -> uriBuilder.path(contextPath + UriEnum.URI_GET_PRODUCT_ASSET_TYPES)
            .queryParam(CmsConstants.ASSET_TYPE, TestingConstants.ASSESSMENT)
            .build(TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE))
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
  }

  /**
   * Gets the product assessment type by id and version.
   *
   * @return the product assessment type by id and version
   * @throws ServiceException
   *           the service exception
   */
  @Test
  public void getProductAssessmentTypeByIdAndVersion() throws ServiceException {

    GLPLearningAsset response = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_BY_ID_AND_VERSION_RESPONSE, GLPLearningAsset.class);

    GLPLearningPolicy[] learningPolicies = new GLPLearningPolicy[] {
        CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_DELIVERY_POLICY_RESPONSE_FOR_PRODUCT, GLPLearningPolicy.class) };
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(response)).thenReturn(Mono.just(learningPolicies));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_PRODUCT_ASSESSMENT_TYPES_POLICY,
            TestingConstants.DUMMY_VALUE, TestingConstants.DUMMY_VALUE)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();

  }

  /**
   * Post product config complete bad request.
   */
  @Test
  public void postProductConfigCompleteBadRequest() {
    Mono<ConfigurationCompleteStatus> requestBody = Mono
        .just(new ConfigurationCompleteStatus(ErrorConstants.VALIDATION_FAILED));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_POST_CONFIG_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ConfigurationCompleteStatus.class))
        .exchange().expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Post product config complete without payload.
   */
  @Test
  public void postProductConfigCompleteWithoutPayload() {
    Mono<ConfigurationCompleteStatus> requestBody = Mono.empty();
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_POST_CONFIG_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Post product config complete with Request Validation Error.
   */
  @Test
  public void postProductConfigCompleteWithRequestValidationError() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new RequestValidationException(ErrorConstants.VALIDATION_FAILED)));

    Mono<ConfigurationCompleteStatus> requestBody = Mono
        .just(new ConfigurationCompleteStatus(CmsConstants.COMPLETED));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_POST_CONFIG_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ConfigurationCompleteStatus.class))
        .exchange().expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Post product config complete with Request Validation Error.
   */
  @Test
  public void postProductConfigCompleteWithDecodingException() {

    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new DecodingException(ErrorConstants.VALIDATION_FAILED)));

    Mono<ConfigurationCompleteStatus> requestBody = Mono
        .just(new ConfigurationCompleteStatus(CmsConstants.COMPLETED));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_POST_CONFIG_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ConfigurationCompleteStatus.class))
        .exchange().expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test post config status.
   */
  @Test
  public void testPostConfigStatus() {
    ConfigurationCompleteEventDetails details = new ConfigurationCompleteEventDetails();
    Mockito.when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any(), Mockito.any())).thenReturn(Mono.just(details));

    Mono<ConfigurationCompleteStatus> requestBody = Mono
        .just(new ConfigurationCompleteStatus(CmsConstants.COMPLETED));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_POST_CONFIG_STATUS, TestingConstants.DUMMY_VALUE,
            TestingConstants.DUMMY_VALUE)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ConfigurationCompleteStatus.class))
        .exchange().expectStatus().isCreated().expectBody(ConfigurationCompleteEventDetails.class);

  }
}
