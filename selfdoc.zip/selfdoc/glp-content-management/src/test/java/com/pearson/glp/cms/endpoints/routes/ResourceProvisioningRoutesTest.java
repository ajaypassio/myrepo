/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.endpoints.routes;

import java.time.Duration;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.dto.resource.request.ResourceVersionRequest;
import com.pearson.glp.cms.dto.resource.request.ResourcesRequest;
import com.pearson.glp.cms.dto.resource.response.BulkResources;
import com.pearson.glp.cms.dto.resource.response.GLPResource;
import com.pearson.glp.cms.dto.resource.response.ResourceVersions;
import com.pearson.glp.cms.dto.resource.response.ResourceWithStatus;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.cms.exception.CustomErrorMessage;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.base.ServiceRuntimeException;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;
import com.pearson.glp.crosscutting.isc.client.sync.model.RequestValidationException;

import reactor.core.publisher.Mono;

/**
 * The Class ResourceRoutesTest.
 */
public class ResourceProvisioningRoutesTest extends ProducerBase {

  /**
   * Instantiates a new resource provisioning routes test.
   */
  public ResourceProvisioningRoutesTest() {
    super();
  }

  /**
   * Before method.
   */
  @Before
  public void beforeMethod() {
    MockitoAnnotations.initMocks(this);
  }

  /**
   * Test get bulk resources.
   *
   * @return the bulk resources
   */
  @Test
  public void getBulkResources() {
    BulkResources model = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.GET_BULK_RESOURCES_RESPONSE, BulkResources.class);
    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(model));

    webTestClient.get().uri(contextPath + UriEnum.URI_RESOURCES).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().isOk().expectBody(BulkResources.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrProperties());
  }

  /**
   * Test Get bulk resources with isc error.
   *
   * @return the bulk resources with isc error
   */
  @Test
  public void getBulkResourcesWithIscError() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
            "Error occurred while fetching data from DB")));

    webTestClient.get().uri(contextPath + UriEnum.URI_RESOURCES).accept(MediaType.APPLICATION_JSON)
        .exchange().expectStatus().is5xxServerError().expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isBetween(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.NETWORK_AUTHENTICATION_REQUIRED.value()));
  }

  /**
   * Test post bulk resources.
   */
  @Test
  public void postBulkResources() {
    ResourcesRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_RESOURCES_REQUEST, ResourcesRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.MULTI_STATUS).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Test post bulk resource when request body is empty.
   */
  @Test
  public void testPostBulkResourceWhenRequestBodyIsEmpty() {
    ResourcesRequest requestModel = new ResourcesRequest();

    webTestClient.post().uri(contextPath + UriEnum.URI_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .is4xxClientError();
  }

  /**
   * Test Post bulk resources with isc error.
   */
  @Test
  public void postBulkResourcesWithIscError() {
    ResourcesRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_BULK_RESOURCES_REQUEST, ResourcesRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.BAD_GATEWAY).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .is5xxServerError().expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isBetween(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.NETWORK_AUTHENTICATION_REQUIRED.value()));
  }

  /**
   * Test Post bulk resources with request validation failure.
   */
  @Test
  public void postBulkResourcesWithValidationFailed() {
    ResourcesRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_RESOURCE_BAD_REQUEST, ResourcesRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.MULTI_STATUS).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }

  /**
   * Test get specific version resource.
   *
   * @return the specific version resource
   */
  @Test
  public void getSpecificVersionResource() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_RESOURCE_SPECIFIC_VERSION_RESPONSE, GLPResource.class)));

    webTestClient.mutate().responseTimeout(Duration.ofMillis(40000)).build().get()
        .uri(contextPath + UriEnum.URI_GET_RESOURCE_SPECIFIC_VERSION,
            CmsConstants.PARAM_RESOURCE_ID, CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("language", "tags", "label", "expiresOn", "links"));
  }

  /**
   * Gets the specific version resource with invalid id or version.
   *
   * @return the specific version resource with invalid id or version
   */
  @Test
  public void getSpecificVersionResourceWithInvalidIdOrVersion() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.NOT_FOUND.value(),
            "Requested Resource Not Found")));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_RESOURCE_SPECIFIC_VERSION,
            CmsConstants.PARAM_RESOURCE_ID, CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(CustomErrorMessage.class).consumeWith(response -> Assertions
            .assertThat(response.getStatus()).isEqualByComparingTo(HttpStatus.NOT_FOUND));
  }

  /**
   * Test post specific version of resource.
   */
  @Test
  public void postNewVersionOfResource() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_RESOURCES_VERSIONS_RESPONSE, ResourceWithStatus.class)));

    ResourceVersionRequest resourceVersionRequest = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_VERSION_RESOURCE_REQUEST, ResourceVersionRequest.class);
    resourceVersionRequest.getResource().getContent().getService()
        .setUrn(TestingConstants.VALID_CONTENT_URN);
    resourceVersionRequest.getResource().getContent().getService()
        .setUrl(TestingConstants.VALID_CONTENT_URL);

    Mono<ResourceVersionRequest> requestBody = Mono.just(resourceVersionRequest);
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RESOURCE_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ResourceVersionRequest.class)).exchange()
        .expectStatus().is2xxSuccessful().expectBody(ResourceWithStatus.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("error"));
  }

  /**
   * Test post specific version of resource.
   */
  @Test
  public void postVersionResourceValidationFailed() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.POST_RESOURCES_VERSIONS_RESPONSE, ResourceWithStatus.class)));

    Mono<ResourceVersionRequest> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_RESOURCE_BAD_REQUEST, ResourceVersionRequest.class));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RESOURCE_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ResourceVersionRequest.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test post new version of resource with isc error.
   */
  @Test
  public void postNewVersionOfResourceWithIscError() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
            "Unable to save data in DB -Validation Failed")));
    ResourceVersionRequest resourceVersionRequest = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_VERSION_RESOURCE_REQUEST, ResourceVersionRequest.class);
    resourceVersionRequest.getResource().getContent().getService()
        .setUrn(TestingConstants.VALID_CONTENT_URN);
    resourceVersionRequest.getResource().getContent().getService()
        .setUrl(TestingConstants.VALID_CONTENT_URL);
    Mono<ResourceVersionRequest> requestBody = Mono.just(resourceVersionRequest);

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RESOURCE_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ResourceVersionRequest.class)).exchange()
        .expectStatus().is5xxServerError().expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isBetween(HttpStatus.INTERNAL_SERVER_ERROR.value(),
                HttpStatus.NETWORK_AUTHENTICATION_REQUIRED.value()));
  }

  /**
   * Post version resource with content validation failed.
   */
  @Test
  public void postVersionResourceWithContentValidationFailed() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenReturn(Mono.error(new RequestValidationException(HttpStatus.BAD_REQUEST.value(),
            TestingConstants.CONTENT_VALIDATION_FAILED)));

    Mono<ResourceVersionRequest> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_VERSION_RESOURCE_REQUEST, ResourceVersionRequest.class));

    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RESOURCE_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ResourceVersionRequest.class)).exchange()
        .expectStatus().is4xxClientError().expectBody(CustomErrorMessage.class);
  }

  /**
   * Test get all versions of resource.
   *
   * @return the all versions of resource
   */
  @Test
  public void getAllVersionsOfResource() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_RESOURCE_ALL_VERSIONS_RESPONSE, ResourceVersions.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_RESOURCE_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(ResourceVersions.class).consumeWith(response -> Assertions
            .assertThat(response.getResponseBody()).hasNoNullFieldsOrProperties());
  }

  /**
   * Test Get resource by id.
   *
   * @return the resource by id
   */
  @Test
  public void getResourceById() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_RESOURCE_SPECIFIC_VERSION_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_RESOURCE_BY_ID, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("language", "tags", "label", "expiresOn", "links"));
  }

  /**
   * Gets the resource by id with isc error.
   *
   * @return the resource by id with isc error
   */
  @Test
  public void getResourceByIdWithIscError() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono
            .error(new IscSyncRuntimeException(HttpStatus.UNAUTHORIZED.value(), "Not Authorized")));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_RESOURCE_BY_ID, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError()
        .expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isEqualByComparingTo(HttpStatus.UNAUTHORIZED.value()));
  }

  /**
   * Post assessment item resources.
   */
  @Test
  public void postAssessItemResources() {
    ResourcesRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSESS_ITEM_RESOURCES_REQUEST, ResourcesRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.MULTI_STATUS).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_ASSESS_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS);
  }

  /**
   * Post assessment item resources without validate content flag.
   */
  @Test
  public void postAssessItemResourcesWithoutValidateContentFlag() {
    ResourcesRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_ASSESS_RESOURCE_BAD_REQUEST, ResourcesRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.MULTI_STATUS).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);
    webTestClient.post().uri(contextPath + UriEnum.URI_ASSESS_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS);
  }

  /**
   * Gets the assessment item resources by id and version.
   *
   * @return the assessment item resources by id and version
   */
  @Test
  public void getAssessmentItemResourcesByIdAndVersion() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_ASSESS_RESOURCES_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESS_RESOURCE_SPECIFIC_VERSION,
            CmsConstants.PARAM_RESOURCE_ID, CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("language", "tags", "label", "expiresOn"));
  }

  /**
   * Gets the assessment item resources invalid id or version.
   *
   * @return the assessment item resources invalid id or version
   */
  @Test
  public void getAssessmentItemResourcesInvalidIdOrVersion() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.error(new IscSyncRuntimeException(HttpStatus.NOT_FOUND.value(),
            "Requested Resource Not Found")));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESS_RESOURCE_SPECIFIC_VERSION,
            CmsConstants.PARAM_RESOURCE_ID, CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(CustomErrorMessage.class).consumeWith(response -> Assertions
            .assertThat(response.getStatus()).isEqualByComparingTo(HttpStatus.NOT_FOUND));
  }

  /**
   * Gets the assessment item resources by id.
   *
   * @return the assessment item resources by id
   */
  @Test
  public void getAssessmentItemResourcesById() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_ASSESS_RESOURCES_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESS_RESOURCE_BY_ID, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept("language", "tags", "label", "expiresOn"));
  }

  /**
   * Gets the assessment item resources by id with isc error.
   *
   * @return the assessment item resources by id with isc error
   */
  @Test
  public void getAssessmentItemResourcesByIdWithIscError() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono
            .error(new IscSyncRuntimeException(HttpStatus.UNAUTHORIZED.value(), "Not Authorized")));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESS_RESOURCE_BY_ID, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError()
        .expectBody(CustomErrorMessage.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody().getStatus())
            .isEqualByComparingTo(HttpStatus.UNAUTHORIZED.value()));
  }

  /**
   * Gets the assessment item resource by resource API.
   *
   * @return the assessment item resource by resource API
   */
  @Test
  public void getAssessmentItemResourceByResourceAPI() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_ASSESS_RESOURCES_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_RESOURCE_BY_ID, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(CustomErrorMessage.class);
  }

  /**
   * Gets the narrative resource by assessment API.
   *
   * @return the narrative resource by assessment API
   */
  @Test
  public void getNarrativeResourceByAssessmentAPI() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_RESOURCE_SPECIFIC_VERSION_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_ASSESS_RESOURCE_BY_ID, CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isNotFound()
        .expectBody(CustomErrorMessage.class);
  }

  /**
   * Test service runtime exception.
   */
  @Test
  public void testServiceRuntimeException() {
    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any()))
        .thenThrow(new ServiceRuntimeException(ErrorConstants.INVALID_REQUEST_PAYLOAD));

    Mono<ResourceVersionRequest> requestBody = Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_VERSION_RESOURCE_REQUEST, ResourceVersionRequest.class));
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_RESOURCE_VERSIONS, CmsConstants.PARAM_RESOURCE_ID)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromPublisher(requestBody, ResourceVersionRequest.class)).exchange()
        .expectStatus().is4xxClientError();
  }

  /**
   * Gets the learning app resources by id.
   *
   * @return the learning app resources by id
   */
  @Test
  public void getLearningAppResourcesById() {
    // When & Then
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_LEARNING_RESOURCES_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_LEARNINGAPP_RESOURCE_BY_ID,
            CmsConstants.PARAM_RESOURCE_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.LANGUAGE, CmsConstants.TAGS,
                CmsConstants.LABEL, CmsConstants.EXPIRESON));
  }

  /**
   * Gets the learning app resources by id and version.
   *
   * @return the learning app resources by id and version
   */
  @Test
  public void getLearningAppResourcesByIdAndVersion() {
    // When & Then
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(CommonUtilsTest.convertJsonToObject(
            JsonFileConstants.GET_LEARNING_RESOURCES_RESPONSE, GLPResource.class)));

    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_LEARNINGAPP_RESOURCE_SPECIFIC_VERSION,
            CmsConstants.PARAM_RESOURCE_ID, CmsConstants.PARAM_VERSION_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
        .expectBody(GLPResource.class)
        .consumeWith(response -> Assertions.assertThat(response.getResponseBody())
            .hasNoNullFieldsOrPropertiesExcept(CmsConstants.LANGUAGE, CmsConstants.TAGS,
                CmsConstants.LABEL, CmsConstants.EXPIRESON));
  }

  /**
   * Post learning app resources.
   */
  @Test
  public void postLearningAppResources() {
    ResourcesRequest requestModel = CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.POST_LEARNING_APP_RESOURCES, ResourcesRequest.class);
    // Mocking InterService Call
    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.MULTI_STATUS).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_LEARNING_APP_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .isEqualTo(HttpStatus.MULTI_STATUS);
  }

  /**
   * Post learning app resources with wrong content.
   */
  @Test
  public void postLearningAppResourcesWithWrongContent() {
    ResourcesRequest requestModel = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.POST_LEARNING_APP_RESOURCES_WITH_WRONG_CONTENT, ResourcesRequest.class);

    this.mockWebClientCall();

    Mono<ClientResponse> monoClientResponse = Mono
        .just(ClientResponse.create(HttpStatus.MULTI_STATUS).build());
    Mockito.when(requestHeadersSpec.exchange()).thenReturn(monoClientResponse);

    webTestClient.post().uri(contextPath + UriEnum.URI_LEARNING_APP_RESOURCES)
        .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(requestModel), ResourcesRequest.class).exchange().expectStatus()
        .is2xxSuccessful();
  }
}
