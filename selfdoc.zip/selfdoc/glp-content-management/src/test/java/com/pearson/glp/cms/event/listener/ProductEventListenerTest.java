/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.event.listener;

import java.time.LocalDateTime;
import java.util.UUID;

import com.pearson.glp.crosscutting.isc.client.async.model.IscEventStructureImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.gson.Gson;
import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.dto.resource.request.EventPayload;
import com.pearson.glp.cms.event.Events;
import com.pearson.glp.cms.helper.EngagementPolicyHelper;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerContext;
import com.pearson.glp.core.handlers.isc.IscServiceHandlerVoidResponse;
import com.pearson.glp.crosscutting.isc.client.async.model.IscEventStructureImpl;
import com.pearson.glp.crosscutting.isc.client.commons.CrosscuttingEvent;
import com.pearson.glp.crosscutting.isc.client.commons.Event;
import com.pearson.glp.crosscutting.isc.client.commons.validation.BeanValidator;

import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

/**
 * The Class ProductComposeEventListenerTest.
 */
public class ProductEventListenerTest {

  /** The product compose event listener. */
  @InjectMocks
  private ProductEventListener productEventListener;

  /** The engagement policy helper. */
  @Mock
  private EngagementPolicyHelper policyHelper;

  /** The Event event. */
  protected Event event = new Event() {

    @Override
    public String getTimestamp() {
      return LocalDateTime.now().toString();
    }

    @Override
    public String getPayload() {
      return new Gson().toJson(CommonUtilsTest
          .convertJsonToObject(JsonFileConstants.PRODUCT_EVENT_JSON, EventPayload.class));
    }

    @Override
    public String getEventName() {
      return Events.PRODUCT_PROMOTED_TO_CONFIGURATION;
    }

    @Override
    public String getEventId() {
      return UUID.randomUUID().toString();
    }

    @Override
    public CrosscuttingEvent getCrosscuttingEvent() {
      return null;
    }

    @Override
    public IscEventStructureImpl<?> getPayloadWithHeader() {
      return null;
    }
  };

  /** The error event. */
  protected Event errorEvent = new Event() {

    @Override
    public String getTimestamp() {
      return LocalDateTime.now().toString();
    }

    @Override
    public String getPayload() {
      return "Error";
    }

    @Override
    public String getEventName() {
      return Events.PRODUCT_PROMOTED_TO_CONFIGURATION;
    }

    @Override
    public String getEventId() {
      return UUID.randomUUID().toString();
    }

    @Override
    public CrosscuttingEvent getCrosscuttingEvent() {
      return null;
    }

    @Override
    public IscEventStructureImpl<?> getPayloadWithHeader() {
      return null;
    }
  };

  /**
   * Instantiates a new product compose event listener test.
   */
  public ProductEventListenerTest() {
    super();
  }

  /**
   * Setup.
   */
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    BeanValidator beanValidator = new BeanValidator();
    ReflectionTestUtils.setField(BeanValidator.class, "staticLink", beanValidator);
  }

  /**
   * Product Compose Service Handler With Available PMP Message.
   */
  @Test
  public void testProductReadyForConfigurtionHandler() {

    Mockito.when(policyHelper.getPolicyGroupFromProductModelConfig(Mockito.any(), Mockito.any()))
        .thenReturn(fetchPolicyGroup());

    Mockito.when(policyHelper.fetchProductAssessmentType(Mockito.any(), Mockito.any()))
        .thenReturn(prepareProductAssetClassTypeResponse());
    Mockito.doNothing().when(policyHelper).applyDefaultProductRuntimePolicy(Mockito.any(),
        Mockito.anyString(), Mockito.any());

    Mockito.doNothing().when(policyHelper).applyDefaultProductScoringPolicy(Mockito.any(),
        Mockito.anyString(), Mockito.any());

    IscServiceHandlerContext isc = new IscServiceHandlerContext(event);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener
        .productReadyForConfigurationHandler(isc);
    StepVerifier.create(resp)
        .assertNext(res -> Assert.assertEquals(HttpStatus.OK.value(), res.getStatus()))
        .verifyComplete();
  }

  /**
   * Test product compose service handler error.
   */
  @Test
  public void testProductReadyForConfigurtionHandlerError() {

    IscServiceHandlerContext isc = new IscServiceHandlerContext(errorEvent);

    Mono<IscServiceHandlerVoidResponse> resp = productEventListener
        .productReadyForConfigurationHandler(isc);
    StepVerifier.create(resp)
        .assertNext(
            res -> Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), res.getStatus()))
        .verifyComplete();
  }

  /**
   * Fetch policy group.
   *
   * @return the mono
   */
  private Mono<String> fetchPolicyGroup() {
    return Mono.just(TestingConstants.TITLE_UUID);
  }

  /**
   * Prepare Product Asset ClassType Response.
   *
   * @return Mono<ProductAssetTypes>
   */
  private Mono<ProductAssetTypes> prepareProductAssetClassTypeResponse() {

    return Mono.just(CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.PRODUCT_GET_ASSESSMENT_ASSET_TYPE, ProductAssetTypes.class));
  }
}