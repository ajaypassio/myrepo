/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.handler;

import java.util.UUID;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;

import com.pearson.glp.cms.cloudcontract.ProducerBase;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.constants.CmsConstants;
import com.pearson.glp.cms.constants.ErrorConstants;
import com.pearson.glp.cms.enums.UriEnum;
import com.pearson.glp.core.handlers.base.ServiceHandlerContext;

/**
 * The Class ErrorHandlerTest.
 *
 * @author sanket.gupta
 */
public class ErrorHandlerTest extends ProducerBase {

  /** The service handler context. */
  @MockBean
  private ServiceHandlerContext serviceHandlerContext;

  /**
   * Instantiates a new error handler test.
   */
  public ErrorHandlerTest() {
    super();
  }

  /**
   * Test Not Found.
   */
  @Test
  public void testNotFound() {
    webTestClient.get().uri(contextPath + contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test Wrong Accept Type.
   */
  @Test
  public void testWrongAcceptMediaType() {
    webTestClient.get().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.TEXT_EVENT_STREAM).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test Wrong Accept Type.
   */
  @Test
  public void testWrongAcceptMediaTypeStream() {
    webTestClient.get().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.APPLICATION_STREAM_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test Wrong Http Method.
   */
  @Test
  public void testWrongHttpMethod() {
    webTestClient.delete().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus()
        .isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
  }

  /**
   * Test Wrong Uri Post.
   */
  @Test
  public void testWrongUriPost() {
    webTestClient.post()
        .uri(contextPath + UriEnum.URI_GET_INSTRUCTION_BY_ID, UUID.randomUUID().toString())
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test Wrong Content Type in Post.
   */
  @Test
  public void testWrongContentTypePost() {
    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .contentType(MediaType.APPLICATION_PDF).accept(MediaType.APPLICATION_JSON).exchange()
        .expectStatus().is4xxClientError();
  }

  /**
   * Test Wrong Accept.
   */
  @Test
  public void testWrongAcceptPost() {
    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .accept(MediaType.APPLICATION_PDF).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test bad request get.
   */
  @Test
  public void testBadRequestGet() {
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_AGGREGATE_SPECIFIC_VERSION, "Invalid UUID Id",
            "Invalid UUID Ver")
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test bad request post.
   */
  @Test
  public void testBadRequestPost() {
    webTestClient.post().uri(contextPath + UriEnum.URI_INSTRUCTION_VERSIONS, "Invalid UUID Id")
        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
        .body(BodyInserters.fromObject("dummyBody")).exchange().expectStatus().is4xxClientError();
  }

  /**
   * Test null pointer exception.
   */
  @Test
  public void testNullPointerException() {
    Mockito.when(serviceHandlerContext.getParameter(CmsConstants.ID))
        .thenThrow(new NullPointerException());
    webTestClient.get()
        .uri(contextPath + UriEnum.URI_GET_RESOURCE_BY_ID, TestingConstants.NARRATIVE_MODEL_ID)
        .accept(MediaType.APPLICATION_JSON).exchange().expectStatus().is5xxServerError();
  }

  /**
   * Test non standard accept header.
   */
  @Test
  public void testNonStandardAcceptHeader() {
    webTestClient.get().uri(contextPath + UriEnum.URI_INSTRUCTIONS)
        .header(ErrorConstants.ACCEPT_HEADER_KEY, ErrorConstants.INVALID_ACCEPT_HEADER_VALUE)
        .exchange().expectStatus().is4xxClientError();
  }

}
