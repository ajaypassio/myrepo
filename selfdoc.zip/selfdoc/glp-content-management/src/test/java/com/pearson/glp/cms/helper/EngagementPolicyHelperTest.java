/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.helper;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import com.pearson.glp.cms.constant.JsonFileConstants;
import com.pearson.glp.cms.constant.TestingConstants;
import com.pearson.glp.cms.dto.learningpolicy.response.GLPLearningPolicy;
import com.pearson.glp.cms.dto.products.ProductAssetTypes;
import com.pearson.glp.cms.enums.AssetClass;
import com.pearson.glp.cms.utils.CommonUtilsTest;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncResponseFormat;
import com.pearson.glp.crosscutting.isc.client.sync.model.IscSyncRuntimeException;
import com.pearson.glp.crosscutting.isc.client.sync.service.IscSyncClient;

import reactor.core.publisher.Mono;

/**
 * The Class EngagementPolicyHelperTest.
 * 
 * @author srishti.singh
 */
public class EngagementPolicyHelperTest {

  /** The policy helper. */
  @InjectMocks
  private EngagementPolicyHelper policyHelper;

  /** The soring policy factory. */
  @Mock
  private PolicyTransformFactory scoringFactory;

  /** The isc sync client. */
  @Mock
  private IscSyncClient iscSyncClient;

  /** The learning model. */
  private final String learningModel = "24159a5d-c6c0-4d38-991b-dbea95e1e82b::1::9283a2e7-1ac1-4e22-88f3-15b7f688926c";

  /** The Constant REVEL_DEFAULT. */
  private static final String REVEL_DEFAULT = "REVEL_DEFAULT";

  /**
   * Setup.
   */
  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    ReflectionTestUtils.setField(policyHelper, "runtimeSettingsLmLee", learningModel);
    ReflectionTestUtils.setField(policyHelper, "runtimeSettingsLmLae", learningModel);
    ReflectionTestUtils.setField(policyHelper, "runtimeSettingsLmLad", learningModel);
  }

  /**
   * Test apply default product runtime policy.
   */
  @Test
  public void testApplyDefaultProductRuntimePolicy() {
    GLPLearningPolicy[] postPolicyResponse = { CommonUtilsTest
        .convertJsonToObject(JsonFileConstants.DELIVERY_POLICY_RESPONSE, GLPLearningPolicy.class) };

    GLPLearningPolicy resolvedPolicyEngagement = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ENGAGEMENT_RESOLVED_POLICY, GLPLearningPolicy.class);
    GLPLearningPolicy resolvedPolicyEvaluation = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ENGAGEMENT_RESOLVED_POLICY, GLPLearningPolicy.class);
    resolvedPolicyEvaluation.setAssetClass(AssetClass.EVALUATION_RUNTIME_SETTINGS.value());
    GLPLearningPolicy resolvedPolicyDelivery = CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_ENGAGEMENT_RESOLVED_POLICY, GLPLearningPolicy.class);
    resolvedPolicyDelivery.setAssetClass(AssetClass.DELIVERY_RUNTIME_SETTINGS.value());

    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyDelivery }))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyEngagement }))
        .thenReturn(Mono.just(new GLPLearningPolicy[] { resolvedPolicyEvaluation }));

    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any(IscSyncResponseFormat.class)))
        .thenReturn(Mono.just(postPolicyResponse));

    policyHelper.applyDefaultProductRuntimePolicy(Mono.just(REVEL_DEFAULT),
        TestingConstants.TITLE_UUID, Mono.just(prepareProductAssetClassType()));

  }

  /**
   * Test apply default product runtime policy with error.
   */
  @Test
  public void testApplyDefaultProductRuntimePolicyWithError() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(new IscSyncRuntimeException(HttpStatus.NOT_FOUND.value(), "")));

    policyHelper.applyDefaultProductRuntimePolicy(Mono.just(REVEL_DEFAULT),
        TestingConstants.TITLE_UUID, Mono.just(prepareProductAssetClassType()));
  }

  /**
   * Test apply default product scoring policy.
   */
  @Test
  public void testApplyDefaultProductScoringPolicy() {
    GLPLearningPolicy[] postPolicyResponse = { CommonUtilsTest
        .convertJsonToObject(TestingConstants.SCORING_POLICY_RESPONSE, GLPLearningPolicy.class) };

    GLPLearningPolicy[] resolvedPolicyEvaluation = { CommonUtilsTest.convertJsonToObject(
        JsonFileConstants.GET_PRODUCT_SCORING_POLICY_RESPONSE, GLPLearningPolicy.class) };

    Mockito.when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
        Mockito.any())).thenReturn(Mono.just(resolvedPolicyEvaluation));

    Mockito
        .when(iscSyncClient.postObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any(), Mockito.any(IscSyncResponseFormat.class)))
        .thenReturn(Mono.just(postPolicyResponse));

    policyHelper.applyDefaultProductScoringPolicy(Mono.just(REVEL_DEFAULT),
        TestingConstants.TITLE_UUID, Mono.just(prepareProductAssetClassType()));
  }

  /**
   * Test apply default product scoring policy with error.
   */
  @Test
  public void testApplyDefaultProductScoringPolicyWithError() {
    Mockito
        .when(iscSyncClient.getObject(Mockito.anyString(), Mockito.anyMap(), Mockito.any(),
            Mockito.any()))
        .thenReturn(Mono.just(new IscSyncRuntimeException(HttpStatus.NOT_FOUND.value(), "")));

    policyHelper.applyDefaultProductScoringPolicy(Mono.just(REVEL_DEFAULT),
        TestingConstants.TITLE_UUID, Mono.just(prepareProductAssetClassType()));
  }

  /**
   * Prepare product asset class type.
   *
   * @return the product asset types
   */
  private ProductAssetTypes prepareProductAssetClassType() {
    return CommonUtilsTest.convertJsonToObject(JsonFileConstants.PRODUCT_GET_ASSESSMENT_ASSET_TYPE,
        ProductAssetTypes.class);
  }

}
