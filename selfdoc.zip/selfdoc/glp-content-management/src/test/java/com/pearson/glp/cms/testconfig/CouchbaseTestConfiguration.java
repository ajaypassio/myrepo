/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.testconfig;

import org.mockito.Mockito;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.couchbase.config.BeanNames;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;
import com.couchbase.client.java.cluster.ClusterInfo;
import com.couchbase.client.java.env.CouchbaseEnvironment;

/**
 * The Class CouchbaseTestConfiguration.
 */
@TestConfiguration
@Profile("testing")
public class CouchbaseTestConfiguration {

  /**
   * Instantiates a new couchBase test configuration.
   */
  public CouchbaseTestConfiguration() {
    super();
  }

  /**
   * Gets the bucket.
   *
   * @return the bucket
   */
  @Primary
  @Bean(destroyMethod = "close", name = BeanNames.COUCHBASE_BUCKET)
  public Bucket getBucket() {
    return Mockito.mock(Bucket.class);
  }

  /**
   * Gets the couchbase client.
   *
   * @return the couchbase client
   */
  @Primary
  @Bean(destroyMethod = "disconnect", name = BeanNames.COUCHBASE_CLUSTER)
  public Cluster getCouchbaseClient() {
    return Mockito.mock(CouchbaseCluster.class);
  }

  /**
   * Gets the couchbase cluster info.
   *
   * @return the couchbase cluster info
   */
  @Primary
  @Bean(name = BeanNames.COUCHBASE_CLUSTER_INFO)
  public ClusterInfo getCouchbaseClusterInfo() {
    return Mockito.mock(ClusterInfo.class);
  }

  /**
   * Gets the couchbase environment.
   *
   * @return the couchbase environment
   */
  @Primary
  @Bean(destroyMethod = "shutdown", name = BeanNames.COUCHBASE_ENV)
  public CouchbaseEnvironment getCouchbaseEnvironment() {
    return Mockito.mock(CouchbaseEnvironment.class);
  }
}
