/*
 * PEARSON PROPRIETARY AND CONFIDENTIAL INFORMATION SUBJECT TO NDA 
 * Copyright (c) 2018 Pearson Education, Inc.
 * All Rights Reserved. 
 * 
 * NOTICE: All information contained herein is, and remains the property of 
 * Pearson Education, Inc. The intellectual and technical concepts contained 
 * herein are proprietary to Pearson Education, Inc. and may be covered by U.S. 
 * and Foreign Patents, patent applications, and are protected by trade secret 
 * or copyright law. Dissemination of this information, reproduction of this  
 * material, and copying or distribution of this software is strictly forbidden   
 * unless prior written permission is obtained from Pearson Education, Inc.
 */
package com.pearson.glp.cms.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class CommonUtils.
 */
public class CommonUtilsTest {

  /** The logger. */
  private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtilsTest.class);

  /** The Constant OBJECT_MAPPER. */
  public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  /**
   * Instantiates a new common utils.
   */
  public CommonUtilsTest() {
  }

  static {
    OBJECT_MAPPER.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
  }

  /**
   * Convert json to object.
   *
   * @param <T>
   *          the generic type
   * @param jsonFile
   *          the json file
   * @param classType
   *          the class type
   * @return the t
   */
  public static <T> T convertJsonToObject(String jsonFile, Class<T> classType) {
    T object = null;

    try {
      object = OBJECT_MAPPER.readValue(
          new File("src/test/resources/jsonFiles/" + FilenameUtils.getName(jsonFile)), classType);
    } catch (final IOException exception) {
      LOGGER.error("convertJsonToObject, IOException has occured {}", exception);
    }
    return object;
  }
}
