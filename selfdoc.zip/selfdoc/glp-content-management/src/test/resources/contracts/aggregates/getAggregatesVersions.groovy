package contracts.aggregates

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
		url $(consumer(regex('/cms/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions')),
		producer('/cms/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions'))
		headers {
            header('''Accept''', applicationJson())
        }
    }
    
 response {
    headers {   
		contentType('''application/hal+json; charset=UTF-8''')
		  }
    status 200
    bodyMatchers {
      		jsonPath('$._count', byType())
            jsonPath('$.versions', byType())
            jsonPath('$.versions[*]._id', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.versions[*]._ver', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.versions[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.versions[*]._docType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.versions[*]._assetType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.versions[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
    }
    body('''{
	"_count": 3,
	"versions": 
	[
		{
			"_id": "243b49fb-24a0-4081-8970-efd55773f32c",
			"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc671",
			"_bssVer": 1,
			"_docType": "LEARNINGCONTENT",
			"_assetType": "AGGREGATE",
			"_links": 
			{
				"self": 
				{
					"href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc671"
				}
			}
		},

		{
			"_id": "243b49fb-24a0-4081-8970-efd55773f32c",
			"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			"_bssVer": 1,
			"_docType": "LEARNINGCONTENT",
			"_assetType": "AGGREGATE",
			"_links": 
			{
				"self": 
				{
					"href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
				}
			}
		},

		{
			"_id": "243b49fb-24a0-4081-8970-efd55773f32c",
			"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc673",
			"_bssVer": 1,
			"_docType": "LEARNINGCONTENT",
			"_assetType": "AGGREGATE",
			"_links": 
			{
				"self": 
				{
					"href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc673"
				}
			}
		}
	]
	}''')
  }
    priority 1
}