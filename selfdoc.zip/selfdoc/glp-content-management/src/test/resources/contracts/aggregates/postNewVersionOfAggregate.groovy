package contracts.aggregates

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method POST()
		url(value(consumer(regex('/cms/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions')),
			producer('/cms/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions')))
		body(
 		"updateRequest": $(
        "isMajorChange": $(consumer(regex('true|false')), producer('true')),
        "reason": $(consumer(regex('.*')))
        ),
        "asset": $(
        "contentMetadata": $(
        "id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a')),
        "version": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('b1e38cf9-aa76-43bd-94da-31197cb33130'))
        ),
        "learningModel": $(
        "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
        "_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
        "_assetType": $(consumer('AGGREGATE'), producer('AGGREGATE')),
        "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
        "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
        "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'))
        ),
        "tags": $(consumer(regex('\\w+')), producer('REVEL')),
        "expiresOn": $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
        "label": $(consumer(regex('\\w+')), producer('CHAPTER')),
        "language": $(consumer(regex('.*')), producer('en-US')),
        "assetClass": $(consumer(regex('.*')), producer('')),
        "objectives": $(consumer(regex('.*')), producer('')),
        // "groups" : {},

        "resources": $(
        "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f": $(
        "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
        "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
        "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
        "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
        "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
        "_assetType": $(consumer(regex('INSTRUCTION|ASSESSMENT|AGGREGATE')), producer('AGGREGATE'))
        ),
        "0ba5f959-de96-4c03-a95b-ede6ffba9b4c": $(
        "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c')),
        "_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
        "_ver":  $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('5a811b23-7131-4273-b977-a0da1ad6f38b')),
        "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
        "_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
        "_assetType": $(consumer(regex('INSTRUCTION|ASSESSMENT|AGGREGATE')), producer('AGGREGATE'))
        )
        ),
        "assetGraph": [
          $(
          "startNode": $(consumer(regex('.+')), producer('self')),
          "endNode": $(consumer(regex('.+')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'))
          // "relationships": {}
          ),
          $(
          "startNode": $(consumer(regex('.+')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
          "endNode": $(consumer(regex('.+')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c'))
          //"relationships": {}
          )
        ],
        "resourcePlan": [
          $(
          "label": $(consumer(regex('[A-Za-z]+')), producer('BLOCK')),
          "resourceElementType": $(consumer(regex('[A-Za-z]+')), producer('HEADING')),
          "resourceRef":  $(consumer(regex('.*')), producer('resourceRef')),
          "resourceElements": [
            $(
            "label": $(consumer(regex('.+')), producer('slate1')),
            "resourceElementType": $(consumer(regex('.+')), producer('slate')),
            "resourceElements": [],
            "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'))
            ),
            $(
            "label": $(consumer(regex('.+')), producer('slate2')),
            "resourceElementType": $(consumer(regex('.+')), producer('slate')),
            "resourceElements": [],
            "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c'))
            )
          ]
          )
        ],
        // "configuration": $({}),
        "constraints": []
        //"extends": {},
        //"extensions": {},
        //"scope": {}
        )
		)
		

		headers {
			header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        status 201
        bodyMatchers {
            jsonPath('$.asset', byType())
			jsonPath('$.contentMetadata', byType())
            jsonPath('$.asset._id', byType())
			jsonPath('$.asset._ver', byType())
			jsonPath('$.asset._bssVer', byType())
			jsonPath('$.asset._docType', byType())
			jsonPath('$.asset._assetType', byType())
			jsonPath('$.asset._links', byType())
            jsonPath('$.asset._links.self', byType())
            jsonPath('$.asset._links.self.href', byType())
			
        }
        body('''
        {
			"asset": {
				"_id": "243b49fb-24a0-4081-8970-efd55773f32c",
				"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
				"_bssVer": 2,
				"_docType": "LEARNINGCONTENT",
				"_assetType": "AGGREGATE",
				"_links": {
					"self": {
						"href": "/v2/aggregates/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
					}
				}
			},
			"contentMetadata": {
				"id": "09b7ff3b-25e6-47be-a1cd-300cf6ea8b33",
				"version": "455c4472-184f-4e3e-a4d4-a89e858b1d03"
			}

	}
		''')
        headers {
            header('''Content-Type''', '''application/hal+json; charset=UTF-8''')
		}
	}
    priority 1
}