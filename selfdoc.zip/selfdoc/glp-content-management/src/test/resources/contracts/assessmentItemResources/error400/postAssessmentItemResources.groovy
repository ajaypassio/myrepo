package contracts.assessmentItemResources.error400

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "Error 400"
	request {
		method POST()
		urlPath('/cms/v2/assessmentItemResources')		
		body(
			resources: $(consumer(optional(regex('[\\S\\s]*'))),producer('[]'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 207
		bodyMatchers {
			jsonPath('$.[*]', byType())
			jsonPath('$.[*].entityStatus', byType())
			jsonPath('$.[*].contentMetadata', byType())
			jsonPath('$.[*].contentMetadata.id', byType())
			jsonPath('$.[*].contentMetadata.version', byType())
			jsonPath('$.[*].error', byType())
		}
		body('''[ {
			  "entityStatus": "Error",
			  "contentMetadata": {
			    "id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
			    "version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
			  },
			  "error": {			    
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status": 400,
				"error": "Bad Request",
				"message": "Request Validation Failed"
			  }
			}]''')
	}
	priority 3
}