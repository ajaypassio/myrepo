package contracts.assessmentItemResources

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "Success 207"
	request {
		method POST()
		urlPath('/cms/v2/assessmentItemResources')		
		body(
				resources: [
				  $(
					contentMetadata: $(
					  id: $(consumer(regex('.+')),producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e')),
					  version: $(consumer(regex('.+')),producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e'))
					),
					expiresOn: $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
					label: $(consumer(optional(regex('.*'))),producer('assessment-item')),
					tags: $(consumer(optional(regex('.*'))),producer('REVEL')),
					language: $(consumer(optional(regex('.*'))),producer('en-US')),
					content: $(
					  category: $(consumer(regex('assessment-item')),producer('assessment-item')),
					  model: $(consumer(optional(regex('.*'))),producer('PUF')),
					  service: $(
						style: $(consumer(regex('REST')),producer('REST')),
						url: $(consumer(regex('http://www.example.com/content/8883c099-1762-43fe-9ad8-4c9aaa6eafa2')),producer('http://www.example.com/content/8883c099-1762-43fe-9ad8-4c9aaa6eafa2')),
						method: $(consumer(regex('(GET|POST)')),producer('GET')),
						validateContent: $(consumer(regex('(true|false)')),producer('false'))
					  )
					),
					security: $(
						strategy: $(
						algorithm: $(consumer(optional(regex('[\\S\\s]*'))),producer('SHA256'))
						),
						param: $(
						checksum: $(consumer(optional(regex('[\\S\\s]*'))),producer('bff23ba0b17fd6bf0cac055745c16835'))
						)
						),
					scope: $(
					  visibility: $(consumer(optional(regex('.*'))),producer('PUBLIC'))
					),
					extensions: $(
					  name: $(
					  en: $(consumer(optional(regex('.*'))),producer('EOC Q14.3'))
					  )
				  )
				  )
				]
			)
						
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType('''application/hal+json; charset=UTF-8''')
			  }
		status 207
		bodyMatchers {
			jsonPath('$.[*]', byType())
			jsonPath('$.[*].entityStatus', byType())
			jsonPath('$.[*].contentMetadata', byType())
			jsonPath('$.[*].contentMetadata.id', byType())
			jsonPath('$.[*].contentMetadata.version', byType())
			jsonPath('$.[*].resource', byType())
			jsonPath('$.[*].resource._id', byType())
			jsonPath('$.[*].resource._resourceType', byType())
			jsonPath('$.[*].resource._bssVer', byType())
			jsonPath('$.[*].resource._ver', byType())
			jsonPath('$.[*].resource._links', byType())
			jsonPath('$.[*].resource._links.self', byType())
			jsonPath('$.[*].resource._links.self.href', byType())
		}
		body('''[{
			     "entityStatus": "Success",
			     "status": 201,
			     "contentMetadata": {
			       "id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
			       "version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
			     },
			     "resource": {
			       "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
			       "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			       "_bssVer": 1,
			       "_resourceType": "CONTENT",
			       "_links": {
			         "self": {
			           "href": "/v2/assessmentItemResources/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			         }
			       }     
			   }
			  
			}]''')
	}
	priority 1
}