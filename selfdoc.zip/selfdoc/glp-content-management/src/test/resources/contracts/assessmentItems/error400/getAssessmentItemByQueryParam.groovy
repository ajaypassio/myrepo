package contracts.assessmentItems.error400;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Error 400"
	request {
		method GET()
		urlPath('/cms/v2/assessmentItems') {
			queryParameters { parameter ("extension.contentMetdata.id", value(consumer(matching("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")), producer("0016f24c-f2c5-440c-8f13-c12648411e97"))) }
		}
		headers {
			header('''Accept''', applicationJson())
        }
    }
    response {
    	headers { contentType(applicationJsonUtf8()) }
        status 400
        bodyMatchers {
	      jsonPath('$.timestamp', byType())
	      jsonPath('$.status', byType())
	      jsonPath('$.error', byType())
	      jsonPath('$.message', byType())
        }
        body('''
			{
    "timestamp": "2019-02-07T09:06:10+00:00",
    "status": 400,
    "error": "Bad Request",
    "message": "Invalid Query Param used"
}
		''')
    }
    priority 2
}
