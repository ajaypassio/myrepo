package contracts.assessmentItems

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
        urlPath($(  consumer(regex('/cms/v2/assessmentItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
                producer('/cms/v2/assessmentItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')))
        headers {
            header('''Accept''', '''application/json''')
        }
    }
    response {
        status 200
        headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
        bodyMatchers {
            jsonPath('$._id',byRegex(uuid()))
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byRegex(uuid()))
            jsonPath('$._created', byType())
            jsonPath('$._lastModified', byType())
			jsonPath('$._createdBy', byType())
			jsonPath('$.expiresOn', byType())
            jsonPath('$.learningModel', byType())
            jsonPath('$.learningModel._resourceType', byType())
            jsonPath('$.learningModel._docType', byType())
            jsonPath('$.learningModel._assetType',byRegex('[\\w-]+'))
            jsonPath('$.learningModel._id', byType())
            jsonPath('$.learningModel._bssVer', byRegex('[\\w-]+'))
            jsonPath('$.learningModel._ver', byType())
            jsonPath('$.learningModel._links', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$.resources', byType())
            jsonPath('$.resourcePlan', byType())
            jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph', byType())
            jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.configuration', byType())
            jsonPath('$.constraints', byType())
            jsonPath('$.extends', byType())
            jsonPath('$.extensions', byType())
            jsonPath('$.extensions.name', byType())
            jsonPath('$.extensions.taxonomicType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.scope', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
        }
        body(''' {
  "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
  "_bssVer": 1,
  "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
  "_created": "2018-05-18T19:16:15+00:00",
  "_lastModified": "2018-05-18T19:16:15+00:00",
  "_createdBy": "Admin",
  "expiresOn": "2019-11-11T20:14:21+00:00",
  "label": "assessment-item",
  "tags": "REVEL",
  "language": "en-US",
  "_docType": "LEARNINGCONTENT",
  "_assetType": "ASSESSMENT-ITEM",
  "assetClass": "assessment-item",
  "objectives": "",
  "groups": {},
  "learningModel": {
    "_resourceType": "CONTENT",
    "_docType": "LEARNINGMODEL",
    "_assetType": "ASSESSMENT-ITEM",
    "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
    "_bssVer": 1,
    "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
    "_links": {}
  },
  "resources": {
    "32f42ce8": {
      "_resourceType": "CONTENT",
      "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
      "_bssVer": 1,
      "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "_links": {}
    }
  },
  "assetGraph": [
    {
      "startNode": "self",
      "endNode": "32f42ce8",
      "relationships": {}
    }
  ],
  "resourcePlan": [
    {
      "label": "Question 1",
      "resourceElementType": "MCQ",
      "resourceElements": [],
      "resourceRef": "32f42ce8"
    }
  ],
  "configuration": {},
  "constraints": [],
  "extends": {},
  "extensions": {
    "contentMetadata": {
      "id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
      "version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
    },
    "name": {
      "en": "EOC Q14.3"
    },
    "taxonomicType": [
      "https://schema.pearson.com/ns/taxonomictype/cite-interactive-multiple-choice"
    ]
  },
  "scope": {},
  "_links": {
    "self": {
      "href": "/v2/assessmentItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
    }
  }
}''')
    }
    priority 1
}

