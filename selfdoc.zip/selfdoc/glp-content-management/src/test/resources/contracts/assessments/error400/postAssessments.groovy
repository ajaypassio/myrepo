package contracts.assessments.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method POST()
        urlPath('/cms/v2/assessments')
        body(
                resources: $(consumer(optional(regex('[\\S\\s]*'))), producer('[]'))
        )
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        headers {
            contentType(applicationJsonUtf8())
        }
        status 207
        bodyMatchers {
            jsonPath('$.entityStatus', byType())
            jsonPath('$.status', byType())
            jsonPath('$.contentMetadata', byType())
            jsonPath('$.contentMetadata.id', byType())
            jsonPath('$.contentMetadata.version', byType())
            jsonPath('$.error', byType())
        }
        body('''{
			  "entityStatus": "Error",
			  "status": 400,
			  "contentMetadata": {
			    "id": "243b49fb-24a0-4081-8970-efd55773f32c",
			    "version": "325365dc-d8de-11e8-9f8b-f2801f1b9fd1"
			  },
			  "error": {			    
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status":400,
				"error":"Bad Request",
				"message":"Request Validation Failed",
				"links":{
					"href":"/v2/schemas/assessments"
				}
			  }
			}''')
    }
    priority 3
}