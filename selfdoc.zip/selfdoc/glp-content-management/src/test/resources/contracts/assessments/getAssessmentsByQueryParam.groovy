package contracts.assessments;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
    method GET()
    urlPath('/cms/v2/assessments') {
      queryParameters { parameter ("extensions.contentMetadata.id", value(consumer(matching("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")), producer("0016f24c-f2c5-440c-8f13-c12648411e97"))) }
    }
    headers {
      header('''Accept''', applicationJson())
    }
  }
  response {
    status 200
    bodyMatchers {
      jsonPath('$._count', byType())
      jsonPath('$.assets', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.assets[*]._id', byType())
      jsonPath('$.assets[*]._ver', byType())
      jsonPath('$.assets[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
      jsonPath('$.assets[*]._docType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assets[*]._assetType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assets[*]._links', byType())
      jsonPath('$.assets[*]._links.self',byType())
      jsonPath('$.assets[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
    }
    body('''
		{
		  "_count": 1,
		  "assets": [
		    {
		      "_id": "091a7a12-31cc-438c-851f-f1ee4c066d13",
		      "_ver": "91be8b13-cda8-4e3f-8d16-a4c97d230c62",
		      "_bssVer": 1,
		      "_docType": "LEARNINGCONTENT",
		      "_assetType": "ASSESSMENT",
		      "_links": {
				"self": {
		        	"href": "/v2/assessmentItems/091a7a12-31cc-438c-851f-f1ee4c066d13/versions/91be8b13-cda8-4e3f-8d16-a4c97d230c62"
		           }
		       }
		    }
		  ]
		}
			''')
    headers { contentType( '''application/hal+json; charset=UTF-8''') }
  }
}