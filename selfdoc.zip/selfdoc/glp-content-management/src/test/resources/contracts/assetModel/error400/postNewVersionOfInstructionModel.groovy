package contracts.assetModel.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 400"
    request {
        method POST()
        url $(consumer(regex('/cms/v2/instructionModels/.*/versions')), 
        		producer('/cms/v2/instructionModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions'))
        
        body(
			asset: $(consumer(optional(regex('[\\S\\s]*'))),producer('[]'))
			)     
         
	    	    headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
	    }
    }
    response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-29T11:00:08+00:00",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Request Validation Failed"
		}''')
	}
	priority 2
}