package contracts.assetModel.error400

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "."
	request {
		method POST()
		urlPath('/cms/v2/learningAppItemModels')		
		body(
			asset: $(consumer(optional(regex('[\\S\\s]*'))),producer('[]'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-28T11:00:08+00:00",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Request Validation Failed"
		}''')
	}
	priority 2
}