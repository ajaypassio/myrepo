package contracts.assetModel.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 404"
    request {
        method POST()
        url $(consumer(regex('/cms/v2/narrativeModels/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions')), 
        		producer('/cms/v2/narrativeModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions'))
      body(
				"expiresOn": $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
				"label": $(consumer(regex('[A-Za-z]*')), producer('NARRATIVE')),
				"createdBy": $(consumer(regex('[A-Za-z]+')), producer('RAHUL')),
				"tags": $(consumer(regex('\\w*')), producer('REVEL')),
				"language": $(consumer(regex('.*')), producer('en-US')),
				"assetClass": $(consumer(regex('.*')), producer('')),
				"objectives": $(consumer(regex('.*')), producer('')),
				"groups" : $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
				"resources": $(
						"d441ee2a-4475-4511-969c-80cbbeba553e": $(
								"_resourceType": $(consumer(regex('[A-Za-z]+')), producer('INLINED')),
								"category": $(consumer(regex('[A-Za-z]+')), producer('model')),
								"data": $(
										"keyPattern": $(consumer(regex('.+')), producer('RESOURCE-%5CS')),
										"categorySchema": $(
												"type": $(consumer(regex('.*')), producer('object')),
												"minProperties": $(consumer(regex('[0-9]*')), producer('1'))
												),
										"instanceSchema": $(
												"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
												),
										)
								)
						),
				"assetGraph": [
				               $(
				            		   "startNode": $(consumer(regex('.+')), producer('self')),
				            		   "endNode": $(consumer(regex('.+')), producer('d441ee2a-4475-4511-969c-80cbbeba553e'))
				            		   )
				               ],
				"resourcePlan": [
				                 $(
				                		 "label": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceElementType": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceRef": $(consumer(regex('.+')), producer('dummy')),

				                		 )
				                 ],
				"configuration": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"constraints": $(consumer(regex('[\\S\\s]*')),producer('[]')),
				"extends": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"extensions": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"scope": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						)
				)
		 headers {
				header('''Accept''', applicationJson())
		      	contentType(applicationJson())
		    }
	    }
	     response {
	        headers {   
				contentType(applicationJsonUtf8())
				  }
		    status 404
		    bodyMatchers {
				jsonPath('$.timestamp', byType())
				jsonPath('$.status', byType())
				jsonPath('$.error', byType())
				jsonPath('$.message', byType())
			}	    
			body (
	    	'''{
					"timestamp": "2018-12-19T11:00:08+05:30",
					"status": 404,
					"error": "NOT FOUND",
					"message": "Requested Resource Not Found"
				}'''
		    )
	    }
		priority 2
	}
