package contracts.assetModel.error406

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "."
	request {
		method POST()
		urlPath('/cms/v2/narrativeModels')		
		body(
				asset: $(consumer(optional(regex('[\\S\\s]*'))),producer('[]'))
			)
		headers {
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 406
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-19T11:00:08+05:30",
			"status": 406,
			"error": "NOT ACCEPTABLE",
			"message": "The resource cannot provide a representation that meets the request requirements in regards of its Accept."
		}''')
    }
	priority 4
}