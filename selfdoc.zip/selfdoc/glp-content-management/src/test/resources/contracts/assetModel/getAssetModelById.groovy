package contracts.assetModel

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
        urlPath($(	consumer(regex('/cms/v2/assetModels/'+uuid())),
                producer('/cms/v2/assetModels/9cc1ef68-a2f5-49ea-a70d-3c451f94bb99')))
        headers {
            header('''Accept''', '''application/json''')
        }
    }
    response {
        status 200
        headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
        bodyMatchers {
            jsonPath('$._id', byType())
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byType())
            jsonPath('$._created', byType())
            jsonPath('$._createdBy', byType())
			jsonPath('$._lastModified', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())

            jsonPath('$.expiresOn', byType())
            jsonPath('$.label', byType())
            jsonPath('$.objectives', byType())
            jsonPath('$.tags', byType())
            jsonPath('$.language', byType())
            jsonPath('$.assetClass', byType())
            jsonPath('$.objectives', byType())
            jsonPath('$.groups', byType())
            jsonPath('$.resources', byType())

            jsonPath('$.assetGraph', byType())
            jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))

            jsonPath('$.resourcePlan', byType())
            jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))

            jsonPath('$.configuration', byType())

            jsonPath('$.constraints', byType())

            jsonPath('$.extends', byType())

            jsonPath('$.extensions', byType())

            jsonPath('$.scope', byType())

        }
        body(''' 
	{
  "_id": "9cc1ef68-a2f5-49ea-a70d-3c451f94bb99",
  "_bssVer": 1,
  "_ver": "a9b9ae2b-966c-4a66-a6ab-134d685cb99b",
  "_created": "2018-05-18T19:16:15+05:30",
  "_createdBy": "Admin",
  "_lastModified": "2018-11-30T06:51:15+05:30",
  "_docType": "LEARNINGMODEL",
  "_assetType": "INSTRUCTION",
  "expiresOn": "2020-12-12T18:29:50+05:30",
  "label": "INSTRUCTION",
  "tags": "REVEL",
  "language": "en_US",
  "assetClass": "",
  "objectives": "",
  "groups": {},
  "resources": {
    "d441ee2a-4475-4511-969c-80cbbeba553e": {
      "_resourceType": "INLINED",
      "category": "model",
      "data": {
        "keyPattern": "MODULE-5CS",
        "categorySchema": {
          "type": "object",
          "minProperties": 1
        },
        "instanceSchema": {
          "type": "object",
          "required": [
            "_docType",
            "_assetType"
          ],
          "properties": {
            "_resourceType": {
              "type": "string",
              "enum": [
                "LEARNINGASSET"
              ]
            },
            "_docType": {
              "type": "string",
              "enum": [
                "LEARNINGCONTENT"
              ]
            },
            "_assetType": {
              "type": "string",
              "enum": [
                "AGGREGATE"
              ]
            }
          }
        },
        "instanceModel": {
          "_id": "ff3de5a6-6008-4e2f-a8df-489480040397",
          "_bssVer": 1,
          "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
          "_resourceType": "LEARNINGASSET",
          "_docType": "LEARNINGMODEL",
          "_assetType": "AGGREGATE",
          "_links": {
            "self": {
              "href": "/v2/assetModels/ff3de5a6-6008-4e2f-a8df-489480040397/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
            }
          }
        }
      }
    }
  },
  "assetGraph": [
    {
      "startNode": "self",
      "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
      "relationships": {}
    },
    {
      "startNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
      "endNode": "self",
      "relationships": {}
    }
  ],
  "resourcePlan": [
    {
      "label": "SLATE",
      "resourceElementType": "SLATE",
      "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
      "resourceElements": []
    }
  ],
  "configuration": {},
  "constraints": [],
  "extends": {},
  "extensions": {},
  "scope": {},
  "_links": {
    "self": {
      "href": "/v2/assetModels/9cc1ef68-a2f5-49ea-a70d-3c451f94bb99/versions/a9b9ae2b-966c-4a66-a6ab-134d685cb99b"
    }
  }
}      ''')
    }
}

