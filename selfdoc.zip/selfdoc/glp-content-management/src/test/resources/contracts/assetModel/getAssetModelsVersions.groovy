package contracts.assetModel

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
        url(value(consumer(regex('/cms/v2/assetModels/'+uuid()+'/versions')),
                producer('/cms/v2/assetModels/9cc1ef68-a2f5-49ea-a70d-3c451f94bb99/versions')))
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
        headers { contentType('''application/hal+json; charset=UTF-8''') }
        status 200
        bodyMatchers {
            jsonPath('$._count', byType())
            jsonPath('$.assetModels', byType())
            jsonPath('$.assetModels[*]._id', byCommand('assertThatValueIsAString    ($it)'))
            jsonPath('$.assetModels[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.assetModels[*]._ver', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*]._created', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].createdBy', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*]._docType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*]._assetType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].expiresOn', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].tags', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].language', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].assetClass', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].objectives', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].groups', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*].resources', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*].assetGraph', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.assetModels[*].assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*].resourcePlan', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.assetModels[*].resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetModels[*].resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.assetModels[*].configuration', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*].constraints', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.assetModels[*].extends', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*].extensions', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*].scope', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assetModels[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
        }
        body(
                '''{
  "_count": 2,
  "assetModels": [
    {
      "_id": "2a960a81-8331-4b6f-9dda-6356605a0db6",
      "_bssVer": 1,
      "_ver": "cd45d3ff-d783-4ad1-acfb-fe52494d7b35",
      "_created": "2018-10-12T10:56:23+00:00",
      "createdBy": "ADAM",
      "_docType": "LEARNINGMODEL",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/assetModels/2a960a81-8331-4b6f-9dda-6356605a0db6/versions/cd45d3ff-d783-4ad1-acfb-fe52494d7b35"
        }
      },
      "expiresOn": "2020-12-12T18:29:50+00:00",
      "label": "INSTRUCTION",
      "tags": "REVEL",
      "language": "en_US",
      "assetClass": "",
      "objectives": "",
      "groups": {},
      "resources": {
        "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f": {
          "_resourceType": "INLINED",
          "category": "model",
          "data": {
            "keyPattern": "INSTRUCTION-%5IN",
            "categorySchema": {
              "type": "object",
              "minProperties": 1
            },
            "instanceSchema": {
              "type": "object",
              "required": [
                "_docType",
                "_assetType"
              ],
              "properties": {
                "_docType": {
                  "type": "string",
                  "enum": [
                    "LEARNINGCONTENT"
                  ]
                },
                "_resourceType": {
                  "type": "string",
                  "enum": [
                    "LEARNINGASSET"
                  ]
                },
                "_assetType": {
                  "type": "string",
                  "enum": [
                    "NARRATIVE"
                  ]
                }
              }
            },
            "instanceModel": {
              "_id": "d441ee2a-4475-4511-969c-80cbbeba553e",
              "_bssVer": 1,
              "_ver": "d441ee2a-4475-4511-969c-80cbbeba553f",
              "_resourceType": "LEARNINGASSET",
              "_docType": "LEARNINGMODEL",
              "_assetType": "NARRATIVE",
              "_links": {
                "self": {
                  "href": "/v2/assetModels/d441ee2a-4475-4511-969c-80cbbeba553e/versions/d441ee2a-4475-4511-969c-80cbbeba553f"
                }
              }
            }
          }
        }
      },
      "assetGraph": [
        {
          "endNode": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
          "relationships": {
          },
          "startNode": "self"
        },
        {
          "endNode": "self",
          "relationships": {
          },
          "startNode": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f"
        }
      ],
      "resourcePlan": [
        {
          "label": "SLATE",
          "resourceElementType": "SLATE",
          "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
          "resourceElements": []
        }
      ],
      "configuration": {},
      "constraints": [],
      "extends": {},
      "extensions": {},
      "scope": {}
    },
    {
      "_id": "2a960a81-8331-4b6f-9dda-6356605a0db6",
      "_bssVer": 1,
      "_ver": "661a774b-a77e-42a2-a6b2-7075a067e254",
      "_created": "2018-10-12T10:56:49+00:00",
      "createdBy": "ADAM",
      "_docType": "LEARNINGMODEL",
      "_assetType": "INSTRUCTION",
      "_links": {
        "self": {
          "href": "/v2/assetModels/2a960a81-8331-4b6f-9dda-6356605a0db6/versions/661a774b-a77e-42a2-a6b2-7075a067e254"
        }
      },
      "expiresOn": "2020-12-12T18:29:50+00:00",
      "label": "INSTRUCTION",
      "tags": "REVEL",
      "language": "en_US",
      "assetClass": "",
      "objectives": "",
      "groups": {
        "items": [
          "123"
        ]
      },
      "resources": {
        "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f": {
          "_resourceType": "INLINED",
          "category": "model",
          "data": {
            "keyPattern": "INSTRUCTION-%5IN",
            "categorySchema": {
              "type": "object",
              "minProperties": 1
            },
            "instanceSchema": {
              "type": "object",
              "required": [
                "_docType",
                "_assetType"
              ],
              "properties": {
                "_docType": {
                  "type": "string",
                  "enum": [
                    "LEARNINGCONTENT"
                  ]
                },
                "_resourceType": {
                  "type": "string",
                  "enum": [
                    "LEARNINGASSET"
                  ]
                },
                "_assetType": {
                  "type": "string",
                  "enum": [
                    "NARRATIVE"
                  ]
                }
              }
            },
            "instanceModel": {
              "_id": "d441ee2a-4475-4511-969c-80cbbeba553e",
              "_bssVer": 1,
              "_ver": "d441ee2a-4475-4511-969c-80cbbeba553f",
              "_resourceType": "LEARNINGASSET",
              "_docType": "LEARNINGMODEL",
              "_assetType": "NARRATIVE",
              "_links": {
                "self": {
                  "href": "/v2/assetModels/d441ee2a-4475-4511-969c-80cbbeba553e/versions/d441ee2a-4475-4511-969c-80cbbeba553f"
                }
              }
            }
          }
        }
      },
      "assetGraph": [
        {
          "startNode": "self",
          "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
          "relationships": {}
        }
      ],
      "resourcePlan": [
        {
          "label": "SLATE",
          "resourceElementType": "SLATE",
          "resourceRef": "d441ee2a-4475-4511-969c-80cbbeba553e",
          "resourceElements": []
        }
      ],
      "configuration": {},
      "constraints": [],
      "extends": {},
      "extensions": {},
      "scope": {}
    }
  ]
}'''
        )
    }
}

