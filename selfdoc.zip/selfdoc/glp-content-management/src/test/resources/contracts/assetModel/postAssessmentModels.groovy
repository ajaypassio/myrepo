package contracts.assetModel

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method POST()
		urlPath('/cms/v2/assessmentModels')
		body(
				"expiresOn": $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
				"label": $(consumer(regex('.+')), producer('ASSESSMENT')),
				"tags": $(consumer(regex('\\w*')), producer('REVEL')),
				"language": $(consumer(regex('.*')), producer('en-US')),
				"assetClass": $(consumer(regex('.+')), producer('ASSESSMENT')),
				"objectives": $(consumer(regex('.*')), producer('')),
				"groups" : $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
				"resources": $(
						"d441ee2a-4475-4511-969c-80cbbeba553e": $(
							"_resourceType": $(consumer(regex('[A-Za-z]+')), producer('INLINED')),
							"category": $(consumer(regex('[A-Za-z]+')), producer('model')),
							"data": $(
									"keyPattern": $(consumer(regex('.+')), producer('ASSESSMENT-ITEM(.)*')),
									"categorySchema": $(
									   "type": $(consumer(regex('.*')), producer('object')),
									   "minProperties": $(consumer(regex('[0-9]*')), producer('1'))
									        ),
									 "instanceSchema": $(
									   "dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
											),
									 )
								   )
						       ),
				"assetGraph": [
				               $(
				            		   "startNode": $(consumer(regex('.+')), producer('self')),
				            		   "endNode": $(consumer(regex('.+')), producer('d441ee2a-4475-4511-969c-80cbbeba553e'))
				            		   )
				               ],
				"resourcePlan": [
				                 $(
				                		 "label": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceElementType": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceRef": $(consumer(regex('.+')), producer('dummy')),

				                		 )
				                 ],
				"configuration": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"constraints": $(consumer(regex('[\\S\\s]*')),producer('[]')),
				"extends": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"extensions": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"scope": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						)
				)
	headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
		}
	}
	response {
		headers { contentType('''application/hal+json; charset=UTF-8''') }
		status 201
		bodyMatchers {
			jsonPath('$._id', byRegex(uuid()))
			jsonPath('$._bssVer', byType())
			jsonPath('$._ver', byRegex(uuid()))
			jsonPath('$._created', byType())
			jsonPath('$._lastModified',byType())
			jsonPath('$._createdBy', byType())
			jsonPath('$._docType', byType())
			jsonPath('$._assetType', byType())
			jsonPath('$._links', byType())
			jsonPath('$._links.self', byType())
			jsonPath('$._links.self.href', byType())
			jsonPath('$.expiresOn', byType())    
			jsonPath('$.label', byType())
			jsonPath('$.tags', byType())
			jsonPath('$.language', byType())
			jsonPath('$.assetClass', byType())
			jsonPath('$.objectives', byType())
			jsonPath('$.groups', byType())
			jsonPath('$.resources', byType())
			jsonPath('$.assetGraph', byType())
			jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.resourcePlan', byType())
			jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
			jsonPath('$.configuration', byType())
			jsonPath('$.constraints', byType())
			jsonPath('$.extends', byType())
			jsonPath('$.extensions', byType())
			jsonPath('$.scope', byType())
	}
		 body('''{
				  "_id": "26f774a6-fbee-41db-80ae-f9ebb52a8d0b",
				  "_bssVer": 1,
				  "_ver": "33bd016b-e103-48b0-a3fb-6c330e0d391f",
				  "_created": "2018-05-18T19:16:15+00:00",
				  "_lastModified": "2018-05-18T19:16:15+00:00",
				  "_createdBy": "Admin",
				  "_docType": "LEARNINGMODEL",
				  "_assetType": "ASSESSMENT",
				  "expiresOn": "2019-06-18T19:16:15+00:00",
				  "label": "ASSESSMENT",
				  "tags": "REVEL",
				  "language": "en_US",
				  "assetClass": "ASSESSMENT",
				  "objectives": "",
				  "groups": {},
				  "resources": {
				    "d441ee2a-4475-4511-969c-80cbbeba553e": {
				      "_resourceType": "INLINED",
				      "category": "model",
				      "data": {
				        "keyPattern": "ASSESSMENT-ITEM(.)*",
				        "categorySchema": {
				          "type": "object",
				          "minProperties": 1
				        },
				        "instanceSchema": {
				          "type": "object",
				          "required": [
				            "_docType",
				            "_assetType"
				          ],
				          "properties": {
				            "_resourceType": {
				              "type": "string",
				              "enum": [
				                "LEARNINGASSET"
				              ]
				            },
				            "_docType": {
				              "type": "string",
				              "enum": [
				                "LEARNINGCONTENT"
				              ]
				            },
				            "_assetType": {
				              "type": "string",
				              "enum": [
				                "ASSESSMENT-ITEM"
				              ]
				            }
				          }
				        },
				        "instanceModel": {
				          "_id": "afac6fc2-c00a-4bfc-8100-7186fb66c9e9",
				          "_bssVer": 1,
				          "_ver": "d1782fa7-3450-43eb-a248-d99480d4d4f7",
				          "_resourceType": "LEARNINGASSET",
				          "_docType": "LEARNINGMODEL",
				          "_assetType": "ASSESSMENT-ITEM",
				          "_links": {
				            "self": {
				              "href": "/v2/afac6fc2-c00a-4bfc-8100-7186fb66c9e9/versions/d1782fa7-3450-43eb-a248-d99480d4d4f7"
				            }
				          }
				        }
				      }
				    }
				  },
				  "assetGraph": [
				    {
				      "startNode": "self",
				      "endNode": "d441ee2a-4475-4511-969c-80cbbeba553e",
				      "relationships": {}
				    }
				  ],
				  "resourcePlan": [
				    {
				      "label": "dummy",
				      "resourceElementType": "dummy",
				      "resourceRef": "dummy",
				      "resourceElements": []
				    }
				  ],
				  "configuration": {},
				  "constraints": [],
				  "extends": {},
				  "extensions": {},
				  "scope": {},
				  "_links": {
				    "self": {
				      "href": "/v2/26f774a6-fbee-41db-80ae-f9ebb52a8d0b/versions/33bd016b-e103-48b0-a3fb-6c330e0d391f"
				    }
				  }
				}''')

    }
    priority 1
}