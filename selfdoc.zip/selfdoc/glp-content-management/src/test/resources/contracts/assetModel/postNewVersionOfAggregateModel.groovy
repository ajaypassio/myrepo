package contracts.assetModel

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method POST()
        url(value(consumer(regex('/cms/v2/aggregateModels/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions')),
                producer('/cms/v2/aggregateModels/243b49fb-24a0-4081-8970-efd55773f32c/versions')))

        body(
                "expiresOn": $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
                "label": $(consumer(regex('[A-Za-z]+')), producer('INSTRUCTION')),
                "tags": $(consumer(regex('\\w+')), producer('REVEL')),
                "language": $(consumer(regex('.*')), producer('en-US')),
                "assetClass": $(consumer(regex('.*')), producer('')),
                "objectives": $(consumer(regex('.*')), producer('')),
                // "groups" : {},
                "resources": $(
                        "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f": $(

                                "_resourceType": $(consumer(regex('[A-Za-z]+')), producer('INLINED')),
                                "category": $(consumer(regex('[A-Za-z]+')), producer('model')),
                                "data": $(
                                        "keyPattern": $(consumer(regex('.+')), producer('INSTRUCTION-%5IN')),
                                        "categorySchema": $(
                                                "type": $(consumer(regex('.*')), producer('object')),
                                                "minProperties": $(consumer(regex('[0-9]+')), producer('1'))
                                        ),
                                        "instanceSchema": $(
                                                "type": $(consumer(regex('[A-Za-z]+')), producer('object')),
                                                "required": [],
                                                "properties": $(
                                                        "_resourceType": $(
                                                                "type": $(consumer(regex('[A-Za-z]+')), producer('string')),
                                                                "enum": []),
                                                        "_docType": $(
                                                                "type": $(consumer(regex('[A-Za-z]+')), producer('string')),
                                                                "enum": []),
                                                        "_assetType": $(
                                                                "type": $(consumer(regex('[A-Za-z]+')), producer('string')),
                                                                "enum": [])
                                                )),
                                        "instanceModel": $(
                                                "_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
                                                "_bssVer": $(consumer(regex('[0-9]+')), producer(1)),
                                                "_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
                                                "_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
                                                "_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
                                                "_assetType": $(consumer(regex('[A-Za-z]+')), producer('NARRATIVE'))
                                        )
                                )
                        )
                ),

                "assetGraph": [
                        $(
                                "startNode": $(consumer(regex('.+')), producer('self')),
                                "endNode": $(consumer(regex('.+')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'))
                        )
                ],
                "resourcePlan": [
                        $(
                                "label": $(consumer(regex('.*')), producer('SLATE')),
                                "resourceElementType": $(consumer(regex('[A-Za-z]+')), producer('SLATE')),
                                "resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),

                        )
                ]
        )

        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }




    }

    response {
        headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
        status 201
        bodyMatchers {
            jsonPath('$._id', byRegex(uuid()))
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byRegex(uuid()))
            jsonPath('$._created', byType())
            jsonPath('$._createdBy', byType())
			jsonPath('$._lastModified', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$._docType', byType())
            jsonPath('$.expiresOn', byType())
            jsonPath('$.label', byType())
            jsonPath('$.tags', byType())
            jsonPath('$.language', byType())
            jsonPath('$.assetClass', byType())
            jsonPath('$.objectives', byType())
            jsonPath('$.groups', byType())
            jsonPath('$.resources', byType())
            jsonPath('$.assetGraph', byType())
            jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.resourcePlan', byType())
            jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.configuration', byType())
            jsonPath('$.constraints', byType())
            jsonPath('$.extends', byType())
            jsonPath('$.extensions', byType())
            jsonPath('$.scope', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
        }
        body('''{
  "_id": "672e01c3-cfba-4622-81b8-0ca9cc9c4b1e",
  "_bssVer": 1,
  "_ver": "1d26de0a-b704-4fc9-bcaa-728241e50e38",
  "_created": "2018-05-18T19:16:15+00:00",
  "_createdBy": "ADMIN",
  "_lastModified": "2018-11-30T06:51:15+00:00",
  "_docType": "LEARNINGMODEL",
  "_assetType": "AGGREGATE",
  "_links": {
    "self": {
      "href": "/v2/assetModels/672e01c3-cfba-4622-81b8-0ca9cc9c4b1e/versions/1d26de0a-b704-4fc9-bcaa-728241e50e38"
    }
  },
  "expiresOn": "2020-12-12T18:29:50+00:00",
  "label": "CHAPTER",
  "tags": "REVEL",
  "language": "en_US",
  "assetClass": "",
  "objectives": "",
  "groups": {},
  "resources": {
    "ff3de5a6-6008-4e2f-a8df-489480040397": {
      "_id": "ff3de5a6-6008-4e2f-a8df-489480040397",
      "_bssVer": 1,
      "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
      "_resourceType": "LEARNINGASSET",
      "_docType": "LEARNINGMODEL",
      "_assetType": "AGGREGATE",
      "_links": {
        "self": {
          "href": "/v2/assetModels/ff3de5a6-6008-4e2f-a8df-489480040397/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
        }
      }
    },
    "eg3de5a6-6008-4e2f-a8df-489480040395": {
      "_id": "eg3de5a6-6008-4e2f-a8df-489480040397",
      "_bssVer": 1,
      "_ver": "8d63b292-43aa-4e8f-90cc-24282dc71ada",
      "_resourceType": "LEARNINGASSET",
      "_docType": "LEARNINGMODEL",
      "_assetType": "ASSESSMENT",
      "_links": {
        "self": {
          "href": "/v2/assetModels/ff3de5a6-6008-4e2f-a8df-489480040397/versions/8d63b292-43aa-4e8f-90cc-24282dc71ada"
        }
      }
    },
    "aq3de5a6-6008-4e2f-a8df-489480040390": {
      "_resourceType": "INLINED",
      "category": "model",
      "data": {
        "resourceTypeFilter": [
          "LEARNINGASSET"
        ],
        "docTypeFilter": [
          "LEARNINGCONTENT"
        ],
        "assetFilter": [
          "AGGREGATE"
        ],
        "modelSelector": [
          "ff3de5a6-6008-4e2f-a8df-489480040397"
        ],
        "constraints": {
          "minOccurs": "1",
          "maxOccurs": "unbounded"
        }
      }
    },
    "cb3de5a6-6008-4e2f-a8df-48948004028b": {
      "_resourceType": "INLINED",
      "category": "model",
      "data": {
        "resourceTypeFilter": [
          "LEARNINGASSET"
        ],
        "docTypeFilter": [
          "LEARNINGCONTENT"
        ],
        "assetFilter": [
          "ASSESSMENT"
        ],
        "modelSelector": [
          "eg3de5a6-6008-4e2f-a8df-489480040395"
        ],
        "constraints": {
          "minOccurs": "1",
          "maxOccurs": "unbounded"
        }
      }
    }
  },
  "assetGraph": [
    {
      "startNode": "self",
      "endNode": "aq3de5a6-6008-4e2f-a8df-489480040390",
      "relationships": {}
    },
    {
      "startNode": "aq3de5a6-6008-4e2f-a8df-489480040390",
      "endNode": "cb3de5a6-6008-4e2f-a8df-48948004028b",
      "relationships": {}
    }
  ],
  "resourcePlan": [

    {
      "label": "Chapter Module",
      "resourceElementType": "MODULE",
      "resourceRef": "aq3de5a6-6008-4e2f-a8df-489480040390",
      "resourceElements": []
    },
    {
      "label": "Chapter Quiz",
      "resourceElementType": "QUIZ",
      "resourceRef": "cb3de5a6-6008-4e2f-a8df-48948004028b",
      "resourceElements": []
    }
  ],
  "configuration": {},
  "constraints": [],
  "extends": {},
  "extensions": {},
  "scope": {}
}''')
    }
    priority 1
}


