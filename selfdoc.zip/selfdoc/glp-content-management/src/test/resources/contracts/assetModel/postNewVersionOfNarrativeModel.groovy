package contracts.assetModel

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method POST()
        url(value(consumer(regex('/cms/v2/narrativeModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions')),
                producer('/cms/v2/narrativeModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions')))
		body(
				"expiresOn": $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
				"label": $(consumer(regex('[A-Za-z]*')), producer('NARRATIVE')),
				"tags": $(consumer(regex('\\w*')), producer('REVEL')),
				"language": $(consumer(regex('.*')), producer('en-US')),
				"assetClass": $(consumer(regex('.*')), producer('')),
				"objectives": $(consumer(regex('.*')), producer('')),
				"groups" : $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
				"resources": $(
						"d441ee2a-4475-4511-969c-80cbbeba553e": $(
								"_resourceType": $(consumer(regex('[A-Za-z]+')), producer('INLINED')),
								"category": $(consumer(regex('[A-Za-z]+')), producer('model')),
								"data": $(
										"keyPattern": $(consumer(regex('.+')), producer('RESOURCE-%5CS')),
										"categorySchema": $(
												"type": $(consumer(regex('.*')), producer('object')),
												"minProperties": $(consumer(regex('[0-9]*')), producer('1'))
												),
										"instanceSchema": $(
												"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
												),
										)
								)
						),
				"assetGraph": [
				               $(
				            		   "startNode": $(consumer(regex('.+')), producer('self')),
				            		   "endNode": $(consumer(regex('.+')), producer('d441ee2a-4475-4511-969c-80cbbeba553e'))
				            		   )
				               ],
				"resourcePlan": [
				                 $(
				                		 "label": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceElementType": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceRef": $(consumer(regex('.+')), producer('dummy')),

				                		 )
				                 ],
				"configuration": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"constraints": $(consumer(regex('[\\S\\s]*')),producer('[]')),
				"extends": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"extensions": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
				"scope": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						)
				)
		headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
		}
	}
    response {
        headers { contentType('''application/hal+json; charset=UTF-8''') }
        status 201
        bodyMatchers {
            jsonPath('$._id', byRegex(uuid()))
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byRegex(uuid()))
            jsonPath('$._created', byType())
            jsonPath('$._createdBy', byType())
			jsonPath('$._lastModified', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
            jsonPath('$.expiresOn', byType())
            jsonPath('$.label', byType())
            jsonPath('$.tags', byType())
            jsonPath('$.language', byType())
            jsonPath('$.assetClass', byType())
            jsonPath('$.objectives', byType())
            jsonPath('$.groups', byType())
            jsonPath('$.resources', byType())
            jsonPath('$.assetGraph', byType())
            jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.resourcePlan', byType())
            jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.resourcePlan[*].resourceElements', byCommand('assertThatValueIsAList($it)'))
            jsonPath('$.configuration', byType())
            jsonPath('$.constraints', byType())
            jsonPath('$.extends', byType())
            jsonPath('$.extensions', byType())
            jsonPath('$.scope', byType())
       }
        body('''{
			   "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
			   "_bssVer":2,
			   "_ver":"a9b9ae2b-966c-4a66-a6ab-134d685cb00b",
			   "_created":"2018-05-18T19:16:15+00:00",
			   "_createdBy":"rahul",
  			   "_lastModified": "2018-11-30T06:51:15+00:00",
			   "_docType":"LEARNINGMODEL",
			   "_assetType":"NARRATIVE",
			   "_links":{
			      "self":{
			         "href":"/v2/assetModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/a9b9ae2b-966c-4a66-a6ab-134d685cb00b"
			      }
			   },
			   "expiresOn":"2020-12-12T18:29:50+00:00",
			   "label":"NARRATIVE",
			   "tags":"REVEL",
			   "language":"en_US",
			   "assetClass":"",
			   "objectives":"",
			   "groups":{
			
			   },
			   "resources":{
			      "d441ee2a-4475-4511-969c-80cbbeba553e":{
			         "_resourceType":"INLINED",
			         "category":"model",
			         "data":{
			            "keyPattern":"RESOURCE-%5CS",
			            "categorySchema":{
			               "type":"object",
			               "minProperties":1
			            },
			            "instanceSchema":{
			               "type":"object",
			               "properties":{
			                  "_resourceType":{
			                     "type":"string",
			                     "enum":[
			                        "CONTENT"
			                     ]
			                  }
			               }
			            }
			         }
			      }
			   },
			   "assetGraph":[
			      {
			         "startNode":"self",
			         "endNode":"d441ee2a-4475-4511-969c-80cbbeba553e",
			         "relationships":{
			
			         }
			      }
			   ],
			   "resourcePlan":[
			      {
			         "label":"dummy",
			         "resourceElementType":"dummy",
			         "resourceRef":"d441ee2a-4475-4511-969c-80cbbeba553e",
			         "resourceElements":[
			
			         ]
			      }
			   ],
			   "configuration":{
			
			   },
			   "constraints":[
			
			   ],
			   "extends":{
			
			   },
			   "extensions":{
			
			   },
			   "scope":{
			
			   }
			}
		''')

    }
     priority 1
}