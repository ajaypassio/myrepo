package contracts.embeddedAssets.error400;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
  description "."
  request {
    method POST()
    urlPath('/cms/v2/embeddedAssets')
    headers {
      header('''Accept''', applicationJson())
      contentType(applicationJson())
    }
    body(
        "assets": [
          $(
          "contentMetadata": $(
          "id": $(consumer(regex('.*')), producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e')),
          "version": $(consumer(regex('.*')), producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e'))
          ),
          "_assetType": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "learningModel": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "resources": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "configuration": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "extends": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "extensions": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
          "scope": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
          )
        ]
        )
  }
  response {
    headers {    contentType('''application/json;charset=UTF-8''') }
    status 207
    bodyMatchers {
      jsonPath('$.error.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.error.error', byType())
      jsonPath('$.error.message', byType())
      jsonPath('$.entityStatus', byType())
      jsonPath('$.contentMetadata', byType())
      jsonPath('$.contentMetadata.id', byType())
      jsonPath('$.contentMetadata.version', byType())
    }
    body('''{
  "entityStatus": "Error",
  "status": 400,
  "contentMetadata": {
    "id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
    "version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
  },
  "error": {
    "timestamp": "2018-12-20T10:08:19+00:00",
    "status": 400,
    "error": "BAD REQUEST",
    "message": "contentMetadata is required."
  }
}'''
        )
  }
  priority 2
}