package contracts.embeddedAssets.post;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
	description "."
	request {
		method POST()
		urlPath('/cms/v2/embeddedAssets')
		headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
		}
		body(
				"assets": [
					$(
					"contentMetadata": $(
					"id": $(consumer(regex('.*')), producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e')),
					"version": $(consumer(regex('.*')), producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e'))
					),
					"expiresOn": "2018-12-20T10:08:19+00:00",
					"label": "slate",
					"tags": "REVEL",
					"language": "en-US",
					"assetClass": "EMBEDDEDSLATE",
					"objectives": "",
					"groups": $(
					"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),

					"learningModel": $(
					"_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
					"_docType": $(consumer('LEARNINGMODEL'), producer('LEARNINGMODEL')),
					"_assetType": $(consumer('AGGREGATE'), producer('AGGREGATE')),
					"_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
					"_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
					"_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'))
					),
					"resources": $(
					"8eae34d9-f1ec-43aa-9cf4-92c4e7fc6f66": $(
					"_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('8eae34d9-f1ec-43aa-9cf4-92c4e7fc6f66')),
					"_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
					"_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('29be0bb5-fbfe-4d8c-a35f-1bda29788667')),
					"_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
					"_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
					"_assetType": $(consumer('NARRATIVE'), producer('NARRATIVE'))
					),
					),
					"assetGraph": [
						$(
						"startNode": $(consumer(regex('.+')), producer('self')),
						"endNode": $(consumer(regex('.+')), producer('1285f6dc-509d-4cad-82e8-e085a7092c14')),
						"relationships": $(
						"endNodePolicyKey": $(
						"KEY": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d70606a3-3c9f-4bf7-acd8-a1b438431fec')),
						)
						)
						)
					],
					"resourcePlan": [
						$(
						"label": $(consumer(regex('.+')), producer('Narrative')),
						"resourceElementType": $(consumer(regex('.+')), producer('Text')),
						resourceElements: $(consumer(regex('[\\S\\s]*')),producer('[]')),
						"resourceRef": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('0ba5f959-de96-4c03-a95b-ede6ffba9b4c'))
						)
					],
					"configuration": $(
					"d70606a3-3c9f-4bf7-acd8-a1b438431fec": $(
					"_id": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('150578e9-9d42-48d6-85ef-d3553e7e8abc')),
					"_bssVer": $(consumer(regex('[0-9]+')), producer('1')),
					"_ver": $(consumer(regex('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')), producer('d7c6c21e-cb83-416d-a3d9-eaa9fab576d9')),
					"contextType": $(consumer('ASSET'), producer('ASSET')),
					"_resourceType": $(consumer('LEARNINGASSET'), producer('LEARNINGASSET')),
					"assetClass": $(consumer('CONCEPTCHECK'), producer('CONCEPTCHECK')),
					"_docType": $(consumer('LEARNINGCONTENT'), producer('LEARNINGCONTENT')),
					"_assetType": $(consumer('ASSESSMENT'), producer('ASSESSMENT'))
					)),
					"constraints": [],

					"extends": $(
					"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),
					"extensions": $(
					"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),

					"scope": $(
					"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),

					)
				]
				)
	}
	response {
		headers {   contentType('''application/json;charset=UTF-8''')  }
		status 207
		bodyMatchers {
			jsonPath('$.asset', byType())
			jsonPath('$.asset._id', byRegex(uuid()))
			jsonPath('$.asset._ver', byRegex(uuid()))
			jsonPath('$.asset._bssVer', byType())
			jsonPath('$.asset._docType', byType())
			jsonPath('$.asset._links', byType())
			jsonPath('$.asset._links.self', byType())
			jsonPath('$.asset._links.self.href', byType())
			jsonPath('$.contentMetadata', byType())
			jsonPath('$.contentMetadata.id', byType())
			jsonPath('$.contentMetadata.version', byType())
			jsonPath('$.entityStatus', byType())
			jsonPath('$.status', byType())
		}
		body('''
{
	"entityStatus": "Success",
	"status": 201,
	"contentMetadata": {
		"id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
		"version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
	},
	"asset": {
		"_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
		"_bssVer": 1,
		"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
		"_docType": "LEARNINGCONTENT",
		"_assetType": "ASSESSMENT",
		"_links": {
			"self": {
				"href": "/v2/embeddedAssets/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			}
		}
	}
}
''')
	}
	priority 1
}