package contracts.instructions.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Bad Request due to Invalid Uuid"
    request {
        method GET()
	    url $(consumer(regex('/cms/v2/instructions/.*/versions')), producer('/cms/v2/instructions/invalidId/versions'))
	    headers {
			header('''Accept''', applicationJson())
	    }
    }
    
    response {
        headers {   
			contentType(applicationJsonUtf8())
		}
	    status 400
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
	    body('''{
			"timestamp": "2018-12-19T11:00:08+05:30",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Invalid Uuid"
		}''')
   		}
		   priority 3
}
