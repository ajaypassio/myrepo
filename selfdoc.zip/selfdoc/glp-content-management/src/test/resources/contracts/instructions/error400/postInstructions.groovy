package contracts.instructions.error400

import org.springframework.cloud.contract.spec.Contract
Contract.make {
	description "."
	request {
		method POST()
		urlPath('/cms/v2/instructions')
		body(
			resources: $(consumer(optional(regex('[\\S\\s]*'))),producer('[]'))
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 207
		bodyMatchers {
			jsonPath('$.[*]', byType())
			jsonPath('$.[*].entityStatus', byType())
			jsonPath('$.[*].status', byType())
			jsonPath('$.[*].contentMetadata', byType())
			jsonPath('$.[*].contentMetadata.id', byType())
			jsonPath('$.[*].contentMetadata.version', byType())
			jsonPath('$.[*].error', byType())
		}
		body('''{
			  "entityStatus": "Error",
			  "status": 400,
			  "contentMetadata": {
			    "id": "09b7ff3b-25e6-47be-a1cd-300cf6ea8b33",
			    "version": "455c4472-184f-4e3e-a4d4-a89e858b1d03"
			  },
			  "error": {			    
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status":400,
				"error":"Bad Request",
				"message":"Request Validation Failed",
				"links":{
					"href":"/v2/schemas/instructions"
				}
			  }
			}''')
	}
	priority 3
}