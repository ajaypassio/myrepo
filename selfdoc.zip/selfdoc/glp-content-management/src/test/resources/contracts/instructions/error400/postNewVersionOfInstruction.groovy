package contracts.instructions.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 400"
    request {
        method POST()
        url $(consumer(regex('/cms/v2/instructions/.*/versions')),
        		producer('/cms/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions'))
        
        body(
			resource: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
			)     
         
	    	    headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
	    }
    }
    
    response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-19T11:00:08+05:30",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Request Validation Failed"
		}''')
	}
	priority 3
}