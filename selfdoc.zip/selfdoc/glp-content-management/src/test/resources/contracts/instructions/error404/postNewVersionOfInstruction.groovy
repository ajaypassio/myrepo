package contracts.instructions.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 404"
    request {
        method POST()
        url $(consumer(regex('/cms/v2/instructions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions')),
        		producer('/cms/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions'))
        
        body(
			updateRequest: $(
			  isMajorChange: $(consumer(regex(anyBoolean())),producer(true)),
			  reason: $(consumer(regex('.+')),producer('Correction in the content'))
			),
			resource: $(
			  contentMetadata: $(
				id: $(consumer(regex('.+')),producer('8883c099')),
				version: $(consumer(regex('.+')),producer('16f6de1c'))
			  ),
			  expiresOn: $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
			  label: $(consumer(optional(regex('.*'))),producer('narrative')),
			  tags: $(consumer(optional(regex('.*'))),producer('REVEL')),
			  language: $(consumer(optional(regex('.*'))),producer('en-US')),
			  content: $(
				category: $(consumer(regex('[a-zA-Z]+')),producer('narrative')),
				  model: $(consumer(optional(regex('.*'))),producer('PUF')),
				  service: $(
					style: $(consumer(regex('[a-zA-Z]+')),producer('REST')),
					url: $(consumer(regex('.+')),producer('http://www.example.com/content/8883c099')),
					method: $(consumer(regex('(GET|POST)')),producer('GET'))
				  )
			  ),
			security: $(
						strategy: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
						param: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
			scope: $(
				 visibility: $(consumer(optional(regex('.*'))),producer('PUBLIC'))
				),
			extensions: $(
				 type: $(consumer(optional(regex('.*'))),producer('AUTHOR')),
				 name: $(consumer(optional(regex('.*'))),producer('JOHN SQUIRES AND KAREN WYRICK')),
				 role: $(consumer(optional(regex('.*'))),producer('INSTITUTE')),
				 isPrimary: $(consumer(optional(regex(anyBoolean()))),producer(false))
				)
			)
			)     
	    headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
	    }
    }
    
    response {
        headers {   
			contentType(applicationJsonUtf8())
			  }
	    status 404
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}	    
		body (
    	'''{
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Requested Resource Not Found"
			}'''
	    )
    }
	priority 2
}
