package contracts.instructions

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "."
  request {
	method GET()
	urlPath($(	consumer(regex('/cms/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
		   producer('/cms/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')))
	headers {
		header('''Accept''', applicationJson())
    }
  }
  response {
    headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
    status 200
    bodyMatchers {
      jsonPath('$._id', byRegex(uuid()))
      jsonPath('$._bssVer', byType())
      jsonPath('$._ver', byRegex(uuid()))
      jsonPath('$._created', byType())
      jsonPath('$._createdBy', byType())
      jsonPath('$._lastModified', byType())
      jsonPath('$._docType', byType())
      jsonPath('$._assetType', byType())
      jsonPath('$.learningModel', byType())
      jsonPath('$.learningModel._resourceType', byType())
      jsonPath('$.learningModel._docType', byType())
      jsonPath('$.learningModel._assetType', byType())
      jsonPath('$.learningModel._id', byType())
      jsonPath('$.learningModel._bssVer', byType())
      jsonPath('$.learningModel._ver', byType())
      jsonPath('$.learningModel._links', byType())
      jsonPath('$.learningModel._links.self', byType())
      jsonPath('$.learningModel._links.self.href', byType())
      jsonPath('$.tags', byType())
      jsonPath('$.label', byType())
      jsonPath('$.language', byType())
      jsonPath('$.assetClass', byType())
      jsonPath('$.objectives', byType())
      jsonPath('$.groups', byType())
      jsonPath('$.resources', byType())
      jsonPath('$.resourcePlan', byType())
      jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.resourcePlan[*].resourceElements',byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assetGraph', byType())
      jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
      jsonPath('$.configuration', byType())
      jsonPath('$.constraints', byType())
      jsonPath('$.extends', byType())
      jsonPath('$.extensions', byType())
      jsonPath('$.scope', byType())
      jsonPath('$._links', byType())
     }
    
    body('''{  
			   "_id":"243b49fb-24a0-4081-8970-efd55773f32c",
			   "_bssVer":1,
			   "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			   "_created":"2018-08-01T03:54:46+00:00",
			   "_createdBy":"ADMIN",
			   "_lastModified": "2018-12-05T09:29:19+00:00",
			   "_docType":"LEARNINGCONTENT",
			   "_assetType":"INSTRUCTION",
			   "learningModel":{  
			      "_resourceType":"LEARNINGASSET",
			      "_docType":"LEARNINGMODEL",
			      "_assetType":"INSTRUCTION",
			      "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
			      "_bssVer":1,
			      "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			      "_links":{  
			         "self":{  
			            "href":"/v2/assetModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			         }
			      }
			   },
			   "tags":"REVEL",
			   "label":"INSTRUCTION",
			   "language":"en-US",
			   "assetClass":"",
			   "objectives":"",
			   "groups":{  
			
			   },
			   "resources":{  
			      "32f42ce8":{  
			         "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
			         "_bssVer":1,
			         "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			         "_resourceType":"LEARNINGASSET",
			         "_docType":"LEARNINGCONTENT",
			         "_assetType":"NARRATIVE",
			         "_links":{  
			            "self":{  
			               "href":"/v2/narratives/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			            }
			         }
			      },
			      "32f42ce9":{  
			         "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
			         "_bssVer":1,
			         "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			         "_resourceType":"LEARNINGASSET",
			         "_docType":"LEARNINGCONTENT",
			         "_assetType":"NARRATIVE",
			         "_links":{  
			            "self":{  
			               "href":"/v2/narratives/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			            }
			         }
			      }
			   },
			   "resourcePlan":[  
			      {  
			         "label":"",
			         "resourceElementType":"HEADING",
			         "resourceRef":"",
			         "resourceElements":[  
			            {  
			               "label":"slate1",
			               "resourceElementType":"slate",
			               "resourceElements":[  
			
			               ],
			               "resourceRef":"32f42ce8"
			            },
			            {  
			               "label":"slate2",
			               "resourceElementType":"slate",
			               "resourceElements":[  
			
			               ],
			               "resourceRef":"32f42ce9"
			            }
			         ]
			      }
			   ],
			   "assetGraph":[  
			      {  
			         "startNode":"self",
			         "endNode":"32f42ce8",
			         "relationships":{  
			
			         }
			      },
			      {  
			         "startNode":"32f42ce8",
			         "endNode":"32f42ce9",
			         "relationships":{  
			
			         }
			      }
			   ],
			   "configuration":{  
			
			   },
			   "constraints":[  
			
			   ],
			   "extends":{  
			
			   },
			   "extensions":{  
			      
			   },
			   "scope":{  
			
			   },
			   "_links":{  
			      "self":{  
			         "href":"/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			      }
			   }
	}
''')
  }
  priority 1
}