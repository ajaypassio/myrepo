package contracts.instructions

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method GET()
        urlPath('/cms/v2/instructions')
        headers {
            header('''Accept''', applicationJson())
        }
    }
    response {
        status 200
        headers {   
			contentType('''application/hal+json; charset=UTF-8''') 
		}
        bodyMatchers {
            jsonPath('$._count', byType())
            jsonPath('$.assets', byType())
            jsonPath('$.assets[*]._id', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assets[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.assets[*]._links', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assets[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assets[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
        }
        body('''{
	  "_count": 2,
	  "assets": [
	    {
	      "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
	     "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
	     "_bssVer": 1,
	     "_docType": "LEARNINGCONTENT",
	      "_assetType": "INSTRUCTION",
	      "_links": {
	        "self": {
	          "href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
	        }
	      }
	    },
	    {
	      "_id": "243b49fb-24a0-4081-8970-efd55773f33c",
	      "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc673",
	     "_bssVer": 1,
	     "_docType": "LEARNINGCONTENT",
	      "_assetType": "INSTRUCTION",
	      "_links": {
	        "self": {
	          "href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f33c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc673"
	        }
	      }
	    }
	  ]
	}''')
}
    priority 1
}