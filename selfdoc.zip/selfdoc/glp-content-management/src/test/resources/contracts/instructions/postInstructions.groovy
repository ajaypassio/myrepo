package contracts.instructions

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method POST()
        urlPath('/cms/v2/instructions')

        body(
            assets: [
                $(
                    contentMetadata: $(
                        id: $(consumer(regex('.+')), producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e')),
                        version: $(consumer(regex('.+')), producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e'))
                    ),
                    expiresOn: $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
                    label: $(consumer(optional(regex('.*'))), producer('instruction')),
                    tags: $(consumer(optional(regex('.*'))), producer('REVEL')),
                    language: $(consumer(optional(regex('.*'))), producer('en-US')),
                    assetClass: $(consumer(optional(regex('.*'))), producer('instruction')),
                    objectives: $(consumer(optional(regex('.*'))), producer('')),
                    groups: $(consumer(optional(regex('[\\S\\s]*'))), producer('{}')),
                    learningModel: $(
                        _resourceType: $(consumer(regex('.+')), producer('LEARNINGASSET')),
                        _docType: $(consumer(regex('.+')), producer('LEARNINGMODEL')),
                        _assetType: $(consumer(regex('.+')), producer('INSTRUCTION')),
                        _id: $(consumer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
                        _bssVer: $(consumer(regex(anInteger())), producer(1)),
                        _ver: $(consumer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'))
                    ),

                    resources: $(
                        "32f42ce8": $(
                            _id: $(consumer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'), producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
                            _bssVer: $(consumer(regex(anInteger())), producer(1)),
                            _ver: $(consumer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'), producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
                            _resourceType: $(consumer(regex('.+')), producer('LEARNINGASSET')),
                            _docType: $(consumer(regex('.+')), producer('LEARNINGCONTENT')),
                            _assetType: $(consumer(regex('.+')), producer('NARRATIVE')),
                        )
                    ),
                    assetGraph: [
                        $(
                            startNode: $(consumer(regex('.+')), producer('self')),
                            endNode: $(consumer(regex('.+')), producer('32f42ce8')),
                            relationships: $(
                                    optionalKey: $(consumer(optional(regex('[\\S\\s]*'))), producer('{}'))
                            )
                        )
                    ],
                    resourcePlan: [
                        $(
                            label: $(consumer(regex('.+')), producer('Question 1')),
                            resourceElementType: $(consumer(regex('.+')), producer('MCQ')),
                            resourceRef: $(consumer(regex('.*')), producer('32f42ce8')),
                            resourceElements: $(consumer(regex('[\\S\\s]*')), producer('[]'))
                        )
                    ],
                    configuration: $(
                        optionalKey: $(consumer(optional(regex('[\\S\\s]*'))), producer('{}'))
                    ),
                    constraints: $(consumer(regex('[\\S\\s]*')), producer('[]')),
                    "extends": $(
                        optionalKey: $(consumer(optional(regex('[\\S\\s]*'))), producer('{}'))
                    ),
                    extensions: $(
                        optionalKey: $(consumer(optional(regex('[\\S\\s]*'))), producer('{}'))
                    ),
                    scope: $(
                        optionalKey: $(consumer(optional(regex('[\\S\\s]*'))), producer('{}'))
                    )
                )
            ]
        )
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
	  
	  headers {
            header('''Accept''', applicationJson())
            header('''Content-Type''', applicationJson())
      }
	}
	
    response {
        status 207
        bodyMatchers {
            jsonPath('$.entityStatus', byType())
            jsonPath('$.status', byType())
            jsonPath('$.asset', byType())
            jsonPath('$.asset._id', byType())
            jsonPath('$.asset._ver', byType())
            jsonPath('$.asset._bssVer', byType())
            jsonPath('$.asset._docType', byType())
            jsonPath('$.asset._assetType', byType())
            jsonPath('$.asset._links', byType())
            jsonPath('$.asset._links.self', byType())
            jsonPath('$.asset._links.self.href', byType())
            jsonPath('$.contentMetadata', byType())
            jsonPath('$.contentMetadata.id', byType())
            jsonPath('$.contentMetadata.version', byType())
        }
        body('''{
         "entityStatus": "Success",
         "status": 201,
		 "asset":{
		 "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
		 "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
		 "_bssVer": 1,
		 "_docType": "LEARNINGCONTENT",
		 "_assetType": "INSTRUCTION",
		 "_links": {
			 "self": {
			 	"href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			 }
		 }
		},
		"contentMetadata": {
		        "id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
		        "version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
	    }
		}''')
        headers {
            header('''Content-Type''', '''application/json;charset=UTF-8''')
        }
    }
    priority 1
}