package contracts.instructions

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method POST()
		url(value(consumer(regex('/cms/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions')),
			producer('/cms/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions')))
		body(
			'''{
				   "updateRequest":{
				      "isMajorChange":true,
				      "reason":"Modification in the content"
				   },
				   "assets":{
				      "contentMetadata":{
				         "id":"d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
				         "version":"b1e38cf9-aa76-43bd-94da-31197cb33130"
				      },				    
				      "learningModel":{
				         "_resourceType":"LEARNINGASSET",
				         "_docType":"LEARNINGMODEL",
				         "_assetType":"INSTRUCTION",
				         "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
				         "_bssVer":1,
				         "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
				         "_links":{
				            "self":{
				               "href":"/v2/assetModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
				            }
				         }
				      },
				      "tags":"REVEL",
				      "expiresOn": "2019-12-31T17:28:35+00:00",
				      "label":"INSTRUCTION",
				      "language":"en-US",
				      "assetClass":"",
				      "objectives":"",
				      "groups":{
				
				      },
				      "resources":{
				         "32f42ce8":{
				            "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
				            "_bssVer":1,
				            "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
				            "_resourceType":"LEARNINGASSET",
				            "_docType":"LEARNINGCONTENT",
				            "_assetType":"NARRATIVE",
				            "_links":{
				               "self":{
				                  "href":"/v2/narratives/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
				               }
				            }
				         },
				         "32f42ce9":{
				            "_id":"32f42ce9-61dd-4bbc-bba5-1fdc03a0af9f",
				            "_bssVer":1,
				            "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
				            "_resourceType":"LEARNINGASSET",
				            "_docType":"LEARNINGCONTENT",
				            "_assetType":"NARRATIVE",
				            "_links":{
				               "self":{
				                  "href":"/v2/narratives/32f42ce9-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
				               }
				            }
				         }
				      },
				      "assetGraph":[
				         {
				            "startNode":"self",
				            "endNode":"32f42ce8",
				            "relationships":{
				
				            }
				         },
				         {
				            "startNode":"32f42ce8",
				            "endNode":"32f42ce9",
				            "relationships":{
				
				            }
				         }
				      ],
				      "resourcePlan":[
				         {
				            "label":"BLOCK",
				            "resourceElementType":"HEADING",
				            "resourceRef":"",
				            "resourceElements":[
				               {
				                  "label":"slate1",
				                  "resourceElementType":"slate",
				                  "resourceElements":[
				
				                  ],
				                  "resourceRef":"32f42ce8"
				               },
				               {
				                  "label":"slate2",
				                  "resourceElementType":"slate",
				                  "resourceElements":[
				
				                  ],
				                  "resourceRef":"32f42ce9"
				               }
				            ]
				         }
				      ],
				      "configuration":{
				
				      },
				      "constraints":[
				
				      ],
				      "extends":{
				
				      },
				      "extensions":{
				
				      },
				      "scope":{
				
				      }
				   }
				}'''
		)
		bodyMatchers {
		  jsonPath('$.updateRequest.isMajorChange', byRegex(anyBoolean()))
		  jsonPath('$.updateRequest.reason', byRegex('[\\w+\\s+\\w+]+'))
		  jsonPath('$.assets.contentMetadata.id', byRegex('.+'))
		  jsonPath('$.assets.expiresOn', byRegex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))
		  jsonPath('$.assets.contentMetadata.version', byRegex('.+'))
		  jsonPath('$.assets.learningModel._resourceType', byRegex(onlyAlphaUnicode()))
		  jsonPath('$.assets.learningModel._docType', byRegex(onlyAlphaUnicode()))
		  jsonPath('$.assets.learningModel._assetType', byRegex(onlyAlphaUnicode()))
		  jsonPath('$.assets.learningModel._id', byRegex(uuid()))
		  jsonPath('$.assets.learningModel._bssVer', byRegex(anInteger()))
		  jsonPath('$.assets.learningModel._ver', byRegex(uuid()))
		  jsonPath('$.assets.assetGraph[*].startNode', byRegex(alphaNumeric()))
		  jsonPath('$.assets.assetGraph[*].endNode', byRegex(alphaNumeric()))
		  jsonPath('$.assets.resourcePlan.resourceElementType', byRegex('[A-Z]+'))
		}

		headers {
			header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        status 201
        bodyMatchers {
			jsonPath('$.asset', byType())
			jsonPath('$.contentMetadata', byType())
            jsonPath('$.asset._id', byType())
			jsonPath('$.asset._ver', byType())
			jsonPath('$.asset._bssVer', byType())
			jsonPath('$.asset._docType', byType())
			jsonPath('$.asset._assetType', byType())
			jsonPath('$.asset._links', byType())
            jsonPath('$.asset._links.self', byType())
            jsonPath('$.asset._links.self.href', byType())
			
        }
		body('''{
			"asset": {
				"_id": "243b49fb-24a0-4081-8970-efd55773f32c",
				"_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
				"_bssVer": 2,
				"_docType": "LEARNINGCONTENT",
				"_assetType": "INSTRUCTION",
				"_links": {
					"self": {
						"href": "/v2/instructions/243b49fb-24a0-4081-8970-efd55773f32c/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
					}
				}
			},
			"contentMetadata": {
				"id": "09b7ff3b-25e6-47be-a1cd-300cf6ea8b33",
				"version": "455c4472-184f-4e3e-a4d4-a89e858b1d03"
			}

			}'''
        	)
        headers {
            header('''Content-Type''', '''application/hal+json; charset=UTF-8''')
		}
	}
	priority 1
}