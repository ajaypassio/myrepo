package contracts.learningAppItems.error400

import org.springframework.cloud.contract.spec.Contract

import groovy.json.JsonParser

Contract.make {
	description "Error 400"
	request {
		method POST()
		urlPath('/cms/v2/learningAppItems')
		body(
				assets: $(consumer(optional(regex('[\\S\\s]*'))),producer('[]'))
				)
		headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
		}
	}

	response {
		status 207
		bodyMatchers {
			jsonPath('$.entityStatus', byType())
			jsonPath('$.status', byType())
			jsonPath('$.contentMetadata', byType())
			jsonPath('$.contentMetadata.id', byType())
			jsonPath('$.contentMetadata.version', byType())
			jsonPath('$.error', byType())
			jsonPath('$.error.timestamp', byType())
			jsonPath('$.error.status', byType())
			jsonPath('$.error.error', byType())
			jsonPath('$.error.message', byType())
		}
		body('''{
			  "entityStatus": "Error",
			  "status": 400,
			  "contentMetadata": {
				"id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
				"version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
			  },
			  "error": {
				"timestamp": "2018-12-19T11:00:08+00:00",
				"status": 400,
				"error": "Bad Request",
				"message": "Request Validation Failed"
			  }
			}''')
		headers {    contentType('''application/hal+json; charset=UTF-8''') }
	}
	priority 3
}