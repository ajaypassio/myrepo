package contracts.learningAppItems.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "error 404"
  request {
	method GET()
	urlPath($(	consumer(regex('/cms/v2/learningAppItems/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}')),
		   producer('/cms/v2/learningAppItems/8883c099-1762-43fe-9ad8-4c9aaa6eafa2')))
	headers {
		header('''Accept''', applicationJson())
    }
  }
  response {
        headers {   
			contentType(applicationJsonUtf8())
			  }
	    status 404
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}	    
		body (
    	'''{
			  "timestamp": "2018-12-19T11:00:08+00:00",
			  "status": 404,
			  "error": "NOT FOUND",
			  "message": "The requested resource is not available"
			}'''
	    )
    }
	priority 2
}
