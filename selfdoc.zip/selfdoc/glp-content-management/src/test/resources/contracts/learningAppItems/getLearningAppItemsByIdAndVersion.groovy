package contracts.learningAppItems

import org.springframework.cloud.contract.spec.Contract

import com.jayway.jsonpath.JsonPath

Contract.make {
	description "."
	request {
		method GET()
		urlPath($(  consumer('/cms/v2/learningAppItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672'),
				producer('/cms/v2/learningAppItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')))
		headers { header('''Accept''', '''application/json''') }
	}
	response {
		status 200
		headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
		bodyMatchers {
			jsonPath('$._id', byType())
			jsonPath('$._bssVer', byType())
			jsonPath('$._ver', byType())
			jsonPath('$._created', byType())
			jsonPath('$._lastModified', byType())
			jsonPath('$.learningModel', byType())
			jsonPath('$.learningModel._resourceType', byType())
			jsonPath('$.learningModel._docType', byType())
			jsonPath('$.learningModel._assetType',byRegex('[\\w-]+'))
			jsonPath('$.learningModel._id', byType())
			jsonPath('$.learningModel._bssVer', byRegex('[\\w-]+'))
			jsonPath('$.learningModel._ver', byType())
			jsonPath('$.learningModel._links', byType())
			jsonPath('$._docType', byType())
			jsonPath('$._assetType', byRegex('[\\w-]+'))
			jsonPath('$.resources', byType())
			jsonPath('$.resourcePlan', byType())
			jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph', byType())
			jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].relationships', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.configuration', byType())
			jsonPath('$.constraints', byType())
			jsonPath('$.extends', byType())
			jsonPath('$.extensions', byType())
			jsonPath('$.scope', byType())
			jsonPath('$._links', byType())
			jsonPath('$._links.self', byType())
			jsonPath('$._links.self.href', byType())
			jsonPath('$._createdBy', byType())
		}
		body('''{
  "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
  "_bssVer": 1,
  "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
  "_created": "2018-05-18T19:16:15+00:00",
  "_lastModified": "2018-05-18T19:16:15+00:00",
  "_createdBy": "Admin",
  "expiresOn": "2018-11-11T20:14:21+00:00",
  "label": "learningapp-item",
  "tags": "REVEL",
  "language": "en-US",
  "_docType": "LEARNINGCONTENT",
  "_assetType": "LEARNINGAPP-ITEM",
  "assetClass": "learningapp-item",
  "objectives": "",
  "groups": {},
  "learningModel": {
    "_resourceType": "CONTENT",
    "_docType": "LEARNINGMODEL",
    "_assetType": "LEARNINGAPP-ITEM",
    "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
    "_bssVer": 1,
    "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
    "_links": {}
  },
  "resources": {
    "32f42ce8": {
      "_resourceType": "CONTENT",
      "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
      "_bssVer": 1,
      "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "_links": {}
    }
  },
  "assetGraph": [
    {
      "startNode": "self",
      "endNode": "32f42ce8",
      "relationships": {}
    }
  ],
  "resourcePlan": [
    {
      "label": "Learning App 1",
      "resourceElementType": "writingsolutions",
      "resourceElements": [],
      "resourceRef": "32f42ce8"
    }
  ],
  "configuration": {},
  "constraints": [],
  "extends": {},
  "extensions": {
    "contentMetadata": {
      "id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
      "version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
    }
  },
  "scope": {},
  "_links": {
    "self": {
      "href": "/v2/learningAppItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
    }
  }
}''')
	}
	priority 1
}