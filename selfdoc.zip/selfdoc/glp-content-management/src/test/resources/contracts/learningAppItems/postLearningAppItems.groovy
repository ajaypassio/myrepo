package contracts.learningAppItems

import org.springframework.cloud.contract.spec.Contract

import com.jayway.jsonpath.JsonPath

Contract.make {
	description "."
	request {
		method POST()
		urlPath('/cms/v2/learningAppItems')
		body(
				 [
					$(
					contentMetadata: $(
					id: $(consumer(regex('.+')),producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e')),
					version: $(consumer(regex('.+')),producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e'))
					),
					expiresOn: $(consumer(optional(regex(iso8601WithOffset()))),producer('2018-11-09T20:47:19+00:00')),
					label: $(consumer(optional(regex('.*'))),producer('learningapp-item')),
					tags: $(consumer(optional(regex('.*'))),producer('REVEL')),
					language: $(consumer(optional(regex('.*'))),producer('en-US')),
					assetClass : $(consumer(optional(regex('.*'))),producer('learningapp-item')),
					objectives : $(consumer(optional(regex('.*'))),producer('')),
					groups : $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
					learningModel: $(
					_resourceType: $(consumer(regex('.+')),producer('LEARNINGASSET')),
					_docType: $(consumer(regex('.+')),producer('LEARNINGMODEL')),
					_assetType: $(consumer(regex('.+')),producer('LEARNINGAPP-ITEM')),
					_id: $(consumer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'),producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
					_bssVer: $(consumer(regex(anInteger())),producer(1)),
					_ver: $(consumer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'),producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'))
					),
					resources: $(
					"32f42ce8": $(
					_id: $(consumer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'),producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
					_bssVer: $(consumer(regex(anInteger())),producer(1)),
					_ver: $(consumer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'),producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672')),
					_resourceType: $(consumer(regex('.+')),producer('CONTENT'))
					)
					),
					assetGraph: [
						$(
						startNode: $(consumer(regex('.+')),producer('self')),
						endNode: $(consumer(regex('.+')),producer('32f42ce8')),
						relationships: $(
						optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						)
						)
					],
					resourcePlan: [
						$(
						label: $(consumer(regex('.+')),producer('Question 1')),
						resourceElementType: $(consumer(regex('.+')),producer('MCQ')),
						resourceRef: $(consumer(regex('.*')),producer('32f42ce8')),
						resourceElements: $(consumer(regex('[\\S\\s]*')),producer('[]'))
						)
					],
					configuration: $(
					optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),
					constraints: $(consumer(regex('[\\S\\s]*')),producer('[]')),
					"extends": $(
					optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),
					extensions: $(
					optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					),
					scope: $(
					optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					)
					)
				]
				)
		headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
		}
	}

	response {
		status 207
		bodyMatchers {
			jsonPath('$.entityStatus', byType())
			jsonPath('$.status', byType())
			jsonPath('$.contentMetadata', byType())
			jsonPath('$.contentMetadata.id', byType())
			jsonPath('$.contentMetadata.version', byType())
			jsonPath('$.asset', byType())
			jsonPath('$.asset._id', byType())
			jsonPath('$.asset._ver', byType())
			jsonPath('$.asset._bssVer', byType())
			jsonPath('$.asset._docType', byType())
			jsonPath('$.asset._assetType', byType())
			jsonPath('$.asset._links', byType())
			jsonPath('$.asset._links.self', byType())
			jsonPath('$.asset._links.self.href', byType())
		}
		body('''     {
 "entityStatus": "Success",
 "status": 201,
 "contentMetadata": {
   "id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
   "version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
 },
 "asset": {
   "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
   "_bssVer": 1,
   "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
   "_resourceType": "LEARNINGASSET",
   "_docType": "LEARNINGCONTENT",
   "_assetType": "LEARNINGAPP-ITEM",
   "_links": {
     "self": {
       "href": "/v2/learningAppItems/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
     }
   }
 }
}''')
		headers {    contentType('''application/hal+json; charset=UTF-8''') }
	}
	priority 1
}