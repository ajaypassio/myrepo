package contracts.learningAppResources;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Success 200"
	request {
		method GET()
		urlPath($(	consumer(regex('/cms/v2/learningAppResources/243b49fb-24a0-4081-8970-efd55773f32c/versions/18f67618-1f1f-4f59-a86c-961aacb2806e')),
				producer('/cms/v2/learningAppResources/243b49fb-24a0-4081-8970-efd55773f32c/versions/18f67618-1f1f-4f59-a86c-961aacb2806e')))
		headers {
			header('''Accept''', applicationJson())
		}
	}

	response {
		headers {    contentType('''application/hal+json; charset=UTF-8''') }
		status 200
		bodyMatchers {
			jsonPath('$._id', byRegex(uuid()))
			jsonPath('$._bssVer', byType())
			jsonPath('$._ver', byRegex(uuid()))
			jsonPath('$._created', byType())
			jsonPath('$._lastModified', byType())
			jsonPath('$._createdBy', byType())
			jsonPath('$._resourceType', byType())
			jsonPath('$.expiresOn', byType())
			jsonPath('$.label', byType())
			jsonPath('$.tags', byType())
			jsonPath('$.language', byType())
			jsonPath('$.content', byType())
			jsonPath('$.content.category', byType())
			jsonPath('$.content.model', byType())
			jsonPath('$.content.service', byType())
			jsonPath('$.content.service.style', byType())
			jsonPath('$.content.service.data', byType())
			jsonPath('$.content.service.data.templateId', byType())
			jsonPath('$.content.service.data.learningsystem', byType())
			jsonPath('$.content.service.data.type', byType())
			jsonPath('$.content.service.data.label', byType())
			jsonPath('$.content.service.data.description', byType())
			jsonPath('$.content.service.data.disciplines', byType())
			jsonPath('$.content.service.data.disciplines[*]', byType())
			jsonPath('$.content.service.data.keywords', byType())
			jsonPath('$.content.service.data.keywords.en', byType())
			jsonPath('$.content.service.data.keywords.en[*]', byType())
			jsonPath('$.security', byType())
			jsonPath('$.scope', byType())
			jsonPath('$.extensions', byType())
			jsonPath('$.extensions.contentMetadata', byType())
			jsonPath('$.extensions.contentMetadata.id', byType())
			jsonPath('$.extensions.contentMetadata.version', byType())
			jsonPath('$._links', byType())
			jsonPath('$._links.self',byType())
			jsonPath('$._links.self.href', byType())
		}
		body (
			'''{
				  "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
				  "_bssVer": 1,
				  "_ver": "18f67618-1f1f-4f59-a86c-961aacb2806e",
				  "_created": "2018-12-25T05:55:58+00:00",
				  "_lastModified": "2018-12-25T05:55:58+00:00",
				  "_createdBy": "Admin",
				  "_resourceType": "CONTENT",
				  "expiresOn": "2019-12-25T05:55:58+00:00",
				  "label": "assessment-learning-apps",
				  "tags": "REVEL",
				  "language": "en-US",
				  "content": {
				    "category": "assessment-learning-apps",
				    "model": "PUF",
				    "service": {
				      "style": "EMBEDDED",
				      "data": {
				        "templateId": "1005",
				        "learningsystem": "knowdl",
				        "type": "simulation",
				        "label": "Medieval Art History",
				        "description": "A survey of art up to the 15th century",
				        "disciplines": [
				          "art",
				          "psychology"
				        ],
				        "keywords": {
				          "en": [
				            "graphs",
				            "quadratic"
				          ]
				        }
				      }
				       
				    }
				  },
				  "security": {},
				  "scope": {},
				  "extensions": {
				    "contentMetadata": {
				      "id": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
				      "version": "urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
				    }
				  },
				  "_links": {
				    "self": {
				      "href": "/v2/learningAppResources/243b49fb-24a0-4081-8970-efd55773f32c/versions/18f67618-1f1f-4f59-a86c-961aacb2806e"
				    }
				  }
				}''')
	}
	priority 1
}