package contracts.learningAppResources;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Success 207"
	request {
		method POST()
		urlPath('/cms/v2/learningAppResources')
		body(
				resources: [
				  $(
					contentMetadata: $(
					  id: $(consumer(regex('.+')),producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e')),
					  version: $(consumer(regex('.+')),producer('urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e'))
					),
					expiresOn: $(consumer(optional(regex('.*'))),producer('2019-12-31T17:28:35+00:00')),
					label: $(consumer(optional(regex('.*'))),producer('assessment-item')),
					tags: $(consumer(optional(regex('.*'))),producer('REVEL')),
					language: $(consumer(optional(regex('.*'))),producer('en-US')),
					content: $(
					  category: $(consumer(regex('assessment-learning-apps')),producer('assessment-learning-apps')),
					  model: $(consumer(optional(regex('.*'))),producer('PUF')),
					  service: $(
						style: $(consumer(regex('EMBEDDED')),producer('EMBEDDED')),
						data: $(
							templateId: $(consumer(regex('.+')),producer('1005')),
							learningsystem: $(consumer(regex('.+')),producer('knowdl')),
							type: $(consumer(regex('.+')),producer('simulation')),
							disciplines: $([consumer(regex('.+'))]),
							label: $(consumer(optional(regex('.*'))),producer('Medieval Art History')),
							description: $(consumer(optional(regex('.*'))),producer('A survey of art up to the 15th century')),
							keywords: $(
								en: [
								  $(consumer(regex('.*')))
								]
							  )
							)
					  )
					),
					security: $(
						strategy: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
						param: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
					scope: $(
					  visibility: $(consumer(optional(regex('.*'))),producer('PUBLIC'))
					),
					extensions: $(
					  name: $(consumer(optional(regex('.*'))),producer('JOHN SQUIRES AND KAREN WYRICK')),
					  taxonomicType:$(consumer(optional('.*')),producer('https://schema.pearson.com/ns/taxonomictype/cite-interactive-multiple-choice')) 
					)
				  )
				]
			)
						
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
	}
	response {
		headers {   
			contentType('''application/hal+json; charset=UTF-8''')
			  }
		status 207
		bodyMatchers {
			jsonPath('$.[*]', byType())
			jsonPath('$.[*].entityStatus', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.[*].status', byCommand('assertThatValueIsAInteger($it)'))
			jsonPath('$.[*].contentMetadata', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.[*].contentMetadata.id', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.[*].contentMetadata.version', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.[*].resource', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.[*].resource._id', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.[*].resource._resourceType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.[*].resource._bssVer', byCommand('assertThatValueIsAInteger($it)'))
			jsonPath('$.[*].resource._ver', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.[*].resource._links', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.[*].resource._links.self', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.[*].resource._links.self.href', byCommand('assertThatValueIsAString($it)'))
		}
		body('''[{
			     "entityStatus": "Success",
			     "status": 201,
			     "contentMetadata": {
			       "id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
			       "version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
			     },
			     "resource": {
			       "_id": "32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
			       "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
			       "_bssVer": 1,
			       "_resourceType": "CONTENT",
			       "_links": {
			         "self": {
			           "href": "/v2/learningAppResources/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/learningAppResources/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
			         }
			       }     
			   }
			  
			}]''')
	}
	priority 2
}