package contracts.narratives.error406

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Error 406"
	request {
		method GET()
		urlPath($(	consumer(regex('/cms/v2/narratives/.*/versions')), 
       	producer('/cms/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions')))
	}
	
	response {
    headers {   
		contentType(applicationJsonUtf8())
		  }
    status 406
    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-19T11:00:08+05:30",
			"status": 406,
			"error": "NOT ACCEPTABLE",
			"message": "The resource cannot provide a representation that meets the request requirements in regards of its Accept."
		}''')
    }
	priority 4
}