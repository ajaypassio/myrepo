package contracts.narratives

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Success 200"
	request {
		method GET()
		urlPath($(	consumer(regex('/cms/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions')), 
       	producer('/cms/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions')))
		headers {
            header('''Accept''', applicationJson())
        }
	}
	
	response {
		status 200
		bodyMatchers {
            jsonPath('$._count', byType())
            jsonPath('$.versions', byType())
            jsonPath('$.versions[*]._id', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.versions[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
			jsonPath('$.versions[*]._ver', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._docType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._assetType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.versions[*]._links', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.versions[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.versions[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
        }
        body('''{
                  "_count": 2,
                  "versions": [
                    {
                      "_id": "e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1",
                      "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae87",
					  "_bssVer": 1,
				      "_docType": "LEARNINGCONTENT",
				      "_assetType": "NARRATIVE",
                      "_links": {
                        "self": {
                          "href": "/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
                        }
                      }
                    },
                    {
                      "_id": "e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1",
                      "_ver": "16f6de1c-d5f8-4e0e-8c41-94a68c9cae88",
					  "_bssVer": 1,
		    		  "_docType": "LEARNINGCONTENT",
		    		  "_assetType": "NARRATIVE",
                      "_links": {
                        "self": {
                          "href": "/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions/820a3105-17af-4f2f-9d4c-b07c6cdfc510"
                        }
                      }
                    }
                  ]
                }'''
        )
        headers {
            contentType('''application/hal+json; charset=UTF-8''')
        }
	}
priority 1
}