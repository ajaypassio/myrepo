package contracts.narratives

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Success 200"
    request {
        method GET()
        urlPath('/cms/v2/narratives')
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        status 200
        headers {   
			contentType('''application/hal+json; charset=UTF-8''') 
		}
        bodyMatchers {
            jsonPath('$._count', byType())
            jsonPath('$.assets', byType())
            jsonPath('$.assets[*]._id', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assets[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
			jsonPath('$.assets[*]._ver', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assets[*]._docType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assets[*]._assetType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.assets[*]._links', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assets[*]._links.self', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.assets[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
        }
        body('''{
  "_count": 1,
  "assets": [
    {
      "_id": "e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1",
     
       "_bssVer": 1,
	   "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
	   "_docType": "LEARNINGCONTENT",
       "_assetType": "NARRATIVE",
       "_links": {
        "self": {
          "href": "/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
        }
      }
    }
  ]
}''')
}
priority 1
}