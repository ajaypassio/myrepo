package contracts.narratives

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Success 201"
    request {
        method POST()
        url(value(consumer(regex('/cms/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions')), 
        	producer('/cms/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions')))

		body(
		updateRequest: $(
			isMajorChange: $(consumer(regex(anyBoolean())),producer(true)),
			reason: $(consumer(regex('.+')),producer('Correction in the content'))
		),
		asset: $(
			contentMetadata: $(
				id: $(consumer(regex('.+')),producer('8883c099')),
				version: $(consumer(regex('.+')),producer('16f6de1c'))
			),
			learningModel: $(
			  _resourceType: $(consumer(regex('.+')),producer('CONTENT')),
			  _docType: $(consumer(regex('.+')),producer('LEARNINGMODEL')),
			  _assetType: $(consumer(regex('.+')),producer('NARRATIVE')),
			  _id: $(consumer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f'),producer('32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f')),
			  _bssVer: $(consumer(regex(anInteger())),producer(1)),
			  _ver: $(consumer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'),producer('810a3768-17af-4f2f-9d4c-b07c6cdfc672'))
			),
			tags: $(consumer(optional(regex('.*'))),producer('REVEL')),
			expiresOn: $(consumer(optional(regex('((2019|20[2-9]\\d|2[1-9]\\d{2}|[3-9]\\d{3})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))T(([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d))(\\+|-)(([0-5]\\d):([0-5]\\d))'))),
			  				producer('2019-12-31T17:28:35+00:00')),
			createdBy:$(consumer(optional(regex('.*'))),producer('Admin')),
			label: $(consumer(optional(regex('.*'))),producer('NARRATIVE')),
			language: $(consumer(optional(regex('.*'))),producer('en-US')),
			assetClass : $(consumer(optional(regex('.*'))),producer('')),
			objectives : $(consumer(optional(regex('.*'))),producer('')),
			groups : $(consumer(optional(regex('[\\S\\s]*'))),producer('{}')),
			resources: $(
			  "243b49fb-24a0-4081-8970-efd55773f32c": $(
				_id: $(consumer('243b49fb-24a0-4081-8970-efd55773f32c'),producer('243b49fb-24a0-4081-8970-efd55773f32c')),
				_bssVer: $(consumer(regex(anInteger())),producer(1)),
				_ver: $(consumer('18f67618-1f1f-4f59-a86c-961aacb2806e'),producer('18f67618-1f1f-4f59-a86c-961aacb2806e')),
				_resourceType: $(consumer(regex('.+')),producer('CONTENT'))
			  ),
			  "325361ae-d8de-11e8-9f8b-f2801f1b9fd1": $(
				_id: $(consumer('325361ae-d8de-11e8-9f8b-f2801f1b9fd1'),producer('325361ae-d8de-11e8-9f8b-f2801f1b9fd1')),
				_bssVer: $(consumer(regex(anInteger())),producer(1)),
				_ver: $(consumer('325365dc-d8de-11e8-9f8b-f2801f1b9fd1'),producer('325365dc-d8de-11e8-9f8b-f2801f1b9fd1')),
				_resourceType: $(consumer(regex('.+')),producer('CONTENT'))
			  )
			),
			assetGraph: [
			  $(
				startNode: $(consumer(regex('.+')),producer('self')),
				endNode: $(consumer(regex('.+')),producer('32f42ce8')),
				relationships: $(
					optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					)
			  ),
			  $(
				  startNode: $(consumer(regex('.+')),producer('32f42ce8')),
				  endNode: $(consumer(regex('.+')),producer('32f42ce9')),
				  relationships: $(
					  optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
					  )
			  )
			],
			resourcePlan: [
			  $(
				label: $(consumer(regex('.+')),producer('BLOCK')),
				resourceElementType: $(consumer(regex('.+')),producer('HEADING')),
				resourceRef: $(consumer(regex('.*')),producer('string')),
				resourceElements: [
				  $(
					label: $(consumer(regex('.+')),producer('slate1')),
					resourceElementType: $(consumer(regex('.+')),producer('slate1')),
					resourceElements: $(consumer(regex('[\\S\\s]*')),producer('[]')),
					resourceRef: $(consumer(regex('.+')),producer('32f42ce8'))
				  ),
				  $(
					label: $(consumer(regex('.+')),producer('slate2')),
					resourceElementType: $(consumer(regex('.+')),producer('slate2')),
					resourceElements: $(consumer(regex('[\\S\\s]*')),producer('[]')),
					resourceRef: $(consumer(regex('.+')),producer('32f42ce9'))
				  )
				]
			  )
			],
			configuration: $(
				optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
				),
			constraints: $(consumer(regex('[\\S\\s]*')),producer('[]')),
			"extends": $(
				optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
				),
			extensions: $(
				optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
				),
			scope: $(
				optionalKey: $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
				)
		)
	)
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        status 201
        bodyMatchers {
			jsonPath('$.contentMetadata', byType())
			jsonPath('$.contentMetadata.id', byType())
			jsonPath('$.contentMetadata.version', byType())
			jsonPath('$.asset', byType())
            jsonPath('$.asset._id', byType())
			jsonPath('$.asset._ver', byType())
			jsonPath('$.asset._bssVer', byType())
			jsonPath('$.asset._docType', byType())
			jsonPath('$.asset._assetType', byType())
            jsonPath('$.asset._links', byType())
            jsonPath('$.asset._links.self', byType())
            jsonPath('$.asset._links.self.href', byType())
        }
        body('''{
		  "contentMetadata": {
		    "id": "d87b55ce-dae8-4efd-8b30-6dc85f9eaf4a",
		    "version": "b1e38cf9-aa76-43bd-94da-31197cb33130"
		  },
		  "asset": {
		    "_id": "e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1",
		    "_ver": "820a3105-17af-4f2f-9d4c-b07c6cdfc510",
		    "_bssVer": 1,
		    "_docType": "LEARNINGCONTENT",
		    "_assetType": "NARRATIVE",
		    "_links": {
		      "self": {
		        "href": "/v2/narratives/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd1/versions/820a3105-17af-4f2f-9d4c-b07c6cdfc510"
		      }
		    }
		  }
		}'''
        )
        headers {
            contentType('''application/hal+json; charset=UTF-8''')
        }
    }
	priority 1
}