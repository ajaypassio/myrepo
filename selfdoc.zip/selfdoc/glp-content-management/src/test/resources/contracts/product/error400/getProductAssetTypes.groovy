package contracts.product.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 400"
    request {
        method GET()
        urlPath($(consumer(regex('/cms/v2/products/.*/versions/.*/assetTypes')),  
        			producer('/cms/v2/products/invalidId/versions/invalidVer/assetTypes')))
                
	    headers {
			header('''Accept''', applicationJson())
	      }
    }
    
    response {
        headers {   
			contentType(applicationJsonUtf8())
		}
	    status 400
	    bodyMatchers {
            jsonPath('$.timestamp', byType())
            jsonPath('$.status', byType())
            jsonPath('$.error', byType())
            jsonPath('$.message', byType())
        }
        body('''{
            "timestamp": "2018-11-12T08:40:16.684Z",
            "status": 400,
            "error": "BAD REQUEST",
            "message": "Invalid Request : Invalid Uuid"
        }''')
   		}
		   priority 3
}