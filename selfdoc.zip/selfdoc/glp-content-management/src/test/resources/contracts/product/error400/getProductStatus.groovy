package contracts.product.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 400"
    request {
        method GET()
        url $(consumer(regex('/cms/v2/products/.*/versions/.*/status')), 
        		producer('/cms/v2/products/1fb057c2-9d9b-4883-a3ac-f96a369645b5/versions/22e33af8-4d0c-4beb-bd0f-4548929b875f/status'))
        headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
	    }
    }
    
    response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-11-12T05:55:58+05:30",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Request Validation Failed"
		}''')
	}
	priority 4
}