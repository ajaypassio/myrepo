package contracts.product.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Error 400"
	request {
		method POST()
		url $(consumer(regex('/cms/v2/products/.*/versions/.*/mapAssessmentTypes')),
				producer('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/243b49fb-24a0-4081-8970-efd55773f32c/mapAssessmentTypes'))
		
		body(
			"tags": $(consumer(regex('\\w*')), producer('ASSESSEMENTTYPELIST')),
			)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
	    }
    }
    
    response {
		headers {   
			contentType(applicationJsonUtf8())
			  }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
               "timestamp": "2018-12-19T11:00:08+05:30",
               "status": 400,
               "error": "BAD REQUEST",
               "message": "The request does not comply with the expected schema"
                }''')
	}
	priority 3
}