package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Error 400"
    request {
        method POST()
        url(value(consumer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights'), producer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights')))
        headers {
            accept(applicationJson())
            contentType(applicationJson())
        }
        body(
                gradebookCategoryPolicy:$(consumer(optional(regex('.*'))),producer('{}'))
        )
    }
    response {
        status 400
        bodyMatchers {
            jsonPath('$.timestamp',byType())
            jsonPath('$.status',byType())
            jsonPath('$.error',byType())
            jsonPath('$.message',byType())
        }
        body('''     
  {
 "timestamp": "2019-01-16T18:42:31+05:30",
  "status": 400,
  "error": "Bad Request",
  "message": "Invalid Request : Request Validation Failed."
}
    '''
        )
        headers { contentType(applicationJsonUtf8()) }
    }
    priority 3
}