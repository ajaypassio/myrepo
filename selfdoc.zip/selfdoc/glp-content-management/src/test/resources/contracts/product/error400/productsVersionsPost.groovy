package contracts.product.error400

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "."
    request {
        method POST()
        url $(consumer(regex('/cms/v2/products/.*/versions')), 
        		producer('/cms/v2/products/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions'))
        body(
                assets: $(consumer(optional(regex('[\\S\\s]*'))), producer('[]'))
        )
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        headers {
            contentType(applicationJsonUtf8())
        }
        status 400
        bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-29T11:00:08+00:00",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Request Validation Failed"
		}''')
	}
    priority 2
}