package contracts.product.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 404"
    request {
        method GET()
        url $(consumer(regex('/cms/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/status')), 
        		producer('/cms/v2/products/1fb057c2-9d9b-4883-a3ac-f96a369645b5/versions/22e33af8-4d0c-4beb-bd0f-4548929b875f/status'))
        headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
			
	    }
    }
    response {
        headers {   
			contentType(applicationJsonUtf8())
			  }
	    status 404
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}	    
		body (
    	'''{
				"timestamp": "2018-11-12T05:55:58+05:30",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Requested Resource Not Found"
			}'''
	    )
    }
	priority 3
}