package contracts.product.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Error 404"
	request {
		method POST()
		url $(consumer(regex('/cms/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/mapAssessmentTypes')),
				producer('/cms/v2/products/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/mapAssessmentTypes'))
		body(
			"assetClass": $(consumer(regex('.+')), producer('ASSESSEMENTTYPE-LIST-POLICY')),
				"label": $(consumer(regex('[A-Za-z]*')), producer('NARRATIVE')),
				"tags": $(consumer(regex('\\w*')), producer('ASSESSEMENTTYPELIST')),
				"language": $(consumer(regex('.*')), producer('en-US')),
				"resources": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
						
				"assetGraph": $(consumer(regex('[\\S\\s]*')),producer('[]')),
				               
				"resourcePlan": [
				                 $(
				                		 "label": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceElementType": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceRef": $(consumer(regex('.+')), producer('dummy')),
										 "resourceElement": $(consumer(regex('[\\S\\s]*')),producer('[]')),

				                		 )
				                 ],
				)

		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
	    }
    }
    
    response {
        headers {   
			contentType(applicationJsonUtf8())
			  }
	    status 404
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}	    
		body (
    	'''{
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Requested Resource Not Found"
			}'''
	    )
    }
	priority 2
}
