package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Error 404"
    request {
        method POST()
        urlPath(value(consumer(regex('/cms/v2/products/.*/versions/.*/categoryWeights')), producer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights')))
        headers {
            accept(applicationJson())
            contentType(applicationJson())
        }
        body(
                gradebookCategoryPolicy: $(
                        data: $(
                                gradebookCategoryPolicies: $([
                                        $(
                                                assessmentType: $(consumer(regex('.+')), producer('HOMEWORK')),
                                                gradebookCategory: $(consumer(regex('.+')), producer('Homework')),
                                                gradebookLabel: $(consumer(regex('.+')), producer('Homework')),
                                                weight: $(consumer(regex('\\b(0*(?:[1-9][0-9]?|100))\\b')), producer(20))
                                        )
                                ])
                        )
                ),
                status:$(consumer(regex('(ACTIVE|INACTIVE)')),producer("ACTIVE"))
        )
    }
    response {
        headers {
            contentType(applicationJsonUtf8())
        }
        status 404
        bodyMatchers {
            jsonPath('$.timestamp', byType())
            jsonPath('$.status', byType())
            jsonPath('$.error', byType())
            jsonPath('$.message', byType())
        }
        body (
                '''{
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Product Not Found"
			}'''
        )
    }
    priority 2
}