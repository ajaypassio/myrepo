package contracts.product.error404;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Error 404"
    request {
        method POST()
        urlPath(value(consumer(regex('/cms/v2/products/.*/versions/.*/scoringPolicy')), producer('/cms/v2/products/24159a5d-c6c1-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/scoringPolicy')))
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
        body(
                scoringPolicy: $(
                        data: $(
                                assessmentTypes: $([
                                        $(
                                                assessmentType: $(consumer(regex('.+')), producer('HOMEWORK')),
                                                possiblePoints: $(consumer(regex('^-?\\d+')), producer(1)),
                                                maxAttempts: $(consumer(regex('^-?\\d+')), producer(1)),
                                                penaltyPoints: $(consumer(regex('^-?\\d+')), producer(3))
                                        )
                                ])
                        )
                )
        )
    }
    response {
        headers {
            contentType(applicationJsonUtf8())
        }
        status 404
        bodyMatchers {
            jsonPath('$.timestamp', byType())
            jsonPath('$.status', byType())
            jsonPath('$.error', byType())
            jsonPath('$.message', byType())
        }
        body (
                '''{
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Requested Resource Not Found"
			}'''
        )
    }
    priority 2
}