package contracts.product.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
  description "error 404"
  request {
	method GET()
	urlPath($(	consumer(regex('/cms/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}')), 
       	producer('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672')))
	headers {
		header('''Accept''', applicationJson())
    }
  }
  response {
        headers {   
			contentType(applicationJsonUtf8())
			  }
	    status 404
	    bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}	    
		body (
    	'''{
				"timestamp": "2018-12-19T11:00:08+05:30",
				"status": 404,
				"error": "NOT FOUND",
				"message": "Requested Resource Not Found"
			}'''
	    )
    }
	priority 2
}
