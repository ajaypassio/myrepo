package contracts.product.error406

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Error 406"
    request {
        method GET()
                urlPath($(consumer(regex('/cms/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/stateTransitions')),  
        			producer('/cms/v2/products/18f67618-1f1f-4f59-a86c-961aacb2806e/versions/18f67618-1f1f-4f59-a86c-961aacb2806e/stateTransitions')))

    }
    
    response {
        headers {   
			contentType(applicationJsonUtf8())  
			}
	    status 406
	    bodyMatchers {
            jsonPath('$.timestamp', byType())
            jsonPath('$.status', byType())
            jsonPath('$.error', byType())
            jsonPath('$.message', byType())
        }
        body('''{
            "timestamp": "2018-12-19T11:00:08+05:30",
            "status": 406,
            "error": "NOT ACCEPTABLE",
            "message": "The resource cannot provide a representation that meets the request requirements in regards of its Accept."
        }''')
    }
	priority 4
}