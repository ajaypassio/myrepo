package contracts.product

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Success 200"
    request {
        method GET()
        urlPath($(consumer(regex('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/assessmentTypes')), 
        			producer('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/assessmentTypes')))
	    headers {
			header('''Accept''', applicationJson())
	      }
    }
    
    response {
        headers {   
			contentType('''application/hal+json; charset=UTF-8''')
		}
	    status 200
	    bodyMatchers {
			  jsonPath('$._id', byRegex(uuid()))
		      jsonPath('$._bssVer', byType())
		      jsonPath('$._ver', byRegex(uuid()))
		      jsonPath('$._docType', byType())
		      jsonPath('$._assetType', byType())
		      jsonPath('$.tags', byType())
		      jsonPath('$.language', byType())
		      jsonPath('$.assetClass', byType())
		      jsonPath('$.resources', byType())
		      jsonPath('$.assetGraph', byType())
		      jsonPath('$.resourcePlan', byType())
		      jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
		      jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
		      jsonPath('$.resourcePlan[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
		      jsonPath('$.resourcePlan[*].resourceElements',byCommand('assertThatValueIsAList($it)'))
		      		      
	    }
	    body (
	    	'''{
			    "_id": "5ca1279d-7b8a-471f-aa98-8574c608288a",
			    "_bssVer": 1,
			    "_ver": "b9b308e2-9b3e-4d66-9572-98045cffd5ed",
			    "_docType": "LEARNINGENGAGEMENT",
			    "_assetType": "LEARNINGPOLICY",
			    "assetClass": "ASSESSEMENTTYPE-LIST-POLICY",
			    "tags": "ASSESSEMENTTYPELIST",
			    "language": "en_US",
			    "resources": {
			      "assessmentTypes": {
			        "_resourceType": "INLINED",
			        "category": "configuration",
			        "model": "glp-assessmenttype-list",
			        "data": {
			          "list": [
			            {
			              "assessmentType" : "HOMEWORK",
			              "label" : "abc homework"
			            },
			            {
			              "assessmentType" : "PRACTICE",
			              "label" : "practice"
			            },
			            {
			              "assessmentType" : "QUIZ",
			              "label" : "quiz"
			            },
			            {
			              "assessmentType" : "DIAGNOSTIC",
			              "label" : "diagnostic"
			            },
			            {
			              "assessmentType" : "TEST",
			              "label" : "test"
			            }
			          ]        
			        }
			      }
			    },
			    "assetGraph": [],
			    "resourcePlan": [
			      {
			        "label": "",
			        "resourceElementType": "INLINED",
			        "resourceRef": "assessmentTypes",
			        "resourceElements": []
			      }
			    ]
			  }''')
   		}
		   priority 1
}