package contracts.product

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Success 200"
    request {
        method GET()
        urlPath($(consumer(regex('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/6accf98a-4056-40e5-9b91-8cafbdbec729/assetTypes')), 
        			producer('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/6accf98a-4056-40e5-9b91-8cafbdbec729/assetTypes')))
	    headers {
			header('''Accept''', applicationJson())
	      }
    }
    
    response {
        headers {   
			contentType('''application/hal+json; charset=UTF-8''')
		}
	    status 200
	    bodyMatchers {
	      	jsonPath('$._id',byRegex(uuid()))
            jsonPath('$._bssVer', byType())
            jsonPath('$._ver', byRegex(uuid()))
            jsonPath('$._created', byType())
            jsonPath('$._lastModified', byType())
            jsonPath('$._resourceType', byType())
			jsonPath('$._resourceCtx', byType())
			jsonPath('$.resourceClass', byType())
			jsonPath('$.content', byType())
			jsonPath('$.content.category', byType())
			jsonPath('$.content.model', byType())
			jsonPath('$.content.data', byType())
            jsonPath('$.extensions', byType())
            jsonPath('$.scope', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
	    }
	    body (
	    	'''{ 
   "_id":"747f0498-0a54-4062-8d1e-e1a7f7cdb337",
   "_bssVer":1,
   "_ver":"4245d52f-062d-49ab-b155-3469dd1c03fa",
   "_created":"2018-05-18T19:16:15+00:00",
   "_lastModified":"2018-05-18T19:16:15+00:00",
   "_resourceType":"USERDEFINED",
   "_resourceCtx":"PRODUCTBUILDER",
   "resourceClass":"ASSETCLASSTYPES",
   "label":"",
   "tags":"",
   "language":"en_US",
   "content":{ 
      "category":"abstract",
      "model":"assetClasstypes",
      "data":{ 
         "assetClassTypes":[ 
            { 
               "assetType":"ASSESSMENT",
               "assetClass":"QUIZ,HOMEWORK,PRACTICE,TEST,DIAGNOSTIC"
            },
            { 
               "assetType":"AGGREGATE",
               "assetClass":"CHAPTER,SLATE,MODULE"
            },
            { 
               "assetType":"INSTRUCTION",
               "assetClass":"INSTRUCTION"
            },
            { 
               "assetType":"NARRATIVE",
               "assetClass":"NARRATIVE"
            },
            { 
               "assetType":"PRODUCT",
               "assetClass":"PRODUCT"
            },
            { 
               "assetType":"ASSESSMENT-ITEM",
               "assetClass":"ASSESSMENT-ITEM"
            }
         ]
      }
   },
   "extensions":{ 
      "contentMetadata":{ 
         "id":"urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e",
         "version":"urn:pearson:work:0fa4a596-9ab8-49a9-877e-24aabc3b2a0e"
      },
      "product":{ 
         "id":"ceaa82f3-32b5-4eb9-b2f4-bc06cb278273",
         "version":"6d4e0fae-1ddc-4a01-a6c9-d6cde8e1740b"
      }
   },
   "scope":{ 
 
   },
   "_links":{ 
      "self":{ 
         "href":"/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/6accf98a-4056-40e5-9b91-8cafbdbec729/assetTypes"
      }
   }
}''')
   		}
		   priority 1
}