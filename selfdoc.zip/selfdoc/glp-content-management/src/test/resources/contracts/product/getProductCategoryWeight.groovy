package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Get Product Category Weight Success"
    request {
        method GET()
        url(value(consumer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights'), producer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights')))
        headers {
            accept(applicationJson())
        }
    }
    response {
        status 200
        bodyMatchers {
            jsonPath('$.gradebookCategoryPolicy', byType())
            jsonPath('$.gradebookCategoryPolicy.data', byType())
            jsonPath('$.gradebookCategoryPolicy.data.gradebookCategoryPolicies', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.gradebookCategoryPolicy.data.gradebookCategoryPolicies[*].assessmentType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.gradebookCategoryPolicy.data.gradebookCategoryPolicies[*].gradebookCategory', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.gradebookCategoryPolicy.data.gradebookCategoryPolicies[*].gradebookLabel', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.gradebookCategoryPolicy.data.gradebookCategoryPolicies[*].weight', byCommand('assertThatValueIsAInteger($it)'))
        }
        body('''
		        {
    "gradebookCategoryPolicy": {
        "data": {
            "gradebookCategoryPolicies": [
                {
                    "assessmentType": "HOMEWORK",
                    "gradebookCategory": "Homework",
                    "gradebookLabel": "Homework",
                    "weight": 20
                },
                {
                    "assessmentType": "PRACTICE",
                    "gradebookCategory": "Practice",
                    "gradebookLabel": "Practice",
                    "weight": 20
                },
                {
                    "assessmentType": "QUIZ",
                    "gradebookCategory": "Quiz",
                    "gradebookLabel": "Quiz",
                    "weight": 20
                },
                {
                    "assessmentType": "TEST",
                    "gradebookCategory": "Test",
                    "gradebookLabel": "Test",
                    "weight": 20
                },
                {
                    "assessmentType": "DIAGNOSTIC",
                    "gradebookCategory": "Read",
                    "gradebookLabel": "Read",
                    "weight": 20
                }
            ]
        }
    }
}
		    '''
        )
        headers {
            contentType('''application/hal+json; charset=UTF-8''')
        }
    }
    priority 1
}