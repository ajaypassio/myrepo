package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Get product scoring policy success"
    request {
        method GET()
        url(value(consumer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/scoringPolicy'), producer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/scoringPolicy')))
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }

    }
    response {
        status 200
        bodyMatchers {
            jsonPath('$.scoringPolicy', byType())
            jsonPath('$.scoringPolicy.data', byType())
            jsonPath('$.scoringPolicy.data.assessmentTypes', byCommand('assertThatValueIsAMap($it)'))
            jsonPath('$.scoringPolicy.data.assessmentTypes[*].assessmentType', byCommand('assertThatValueIsAString($it)'))
            jsonPath('$.scoringPolicy.data.assessmentTypes[*].possiblePoints', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.scoringPolicy.data.assessmentTypes[*].maxAttempts', byCommand('assertThatValueIsAInteger($it)'))
            jsonPath('$.scoringPolicy.data.assessmentTypes[*].penaltyPoints', byCommand('assertThatValueIsAInteger($it)'))

        }
        body('''{
  "scoringPolicy": {
    "data": {
      "assessmentTypes": [
        {
          "assessmentType": "HOMEWORK",
          "possiblePoints": 1,
          "maxAttempts": 3,
          "penaltyPoints": -1
        }
      ]
    }
  }
}

    '''
        )
        headers { contentType('''application/hal+json; charset=UTF-8''') }
    }
    priority 1
}