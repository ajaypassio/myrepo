package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

	Contract.make {
		  description "."
		  request {
		    method GET()
		    url (value(consumer('/cms/v2/products/1fb057c2-9d9b-4883-a3ac-f96a369645b5/versions/22e33af8-4d0c-4beb-bd0f-4548929b875f/status'), 
		    producer('/cms/v2/products/1fb057c2-9d9b-4883-a3ac-f96a369645b5/versions/22e33af8-4d0c-4beb-bd0f-4548929b875f/status')))
		    headers {
		      header('''Accept''', applicationJson())
		      contentType(applicationJson())
		    }
		   }
	response {
		    status 200
		    bodyMatchers {
		      jsonPath('$._id', byRegex(uuid()))
		      jsonPath('$._status', byType())
		      jsonPath('$._lastModified', byType())
		      jsonPath('$._links', byType())
		      jsonPath('$._links.self', byType())
		      jsonPath('$._links.self.href', byType())
		    }
		    body('''
		        {
		    "_id": "a5cdb62b-b5af-43d0-92f9-6dc0be54a508",
		    "_status": "COMPOSE",
		    "_lastModified": "2018-12-25T05:55:58+05:30",
		    "_links": {
		        "self": {
		            "href": "/v2/products/1fb057c2-9d9b-4883-a3ac-f96a369645b5/versions/22e33af8-4d0c-4beb-bd0f-4548929b875f/status"
		        }
		    }
		}
		    '''
		        )
		    headers { contentType('''application/hal+json; charset=UTF-8''') }
		  }
		  priority 1
}