package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
	description "."
	request {
		method POST()
		url(value(consumer(regex('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672/mapAssessmentTypes'))
		, producer('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672/mapAssessmentTypes')))
		
		body(
			"assetClass": $(consumer(regex('.+')), producer('ASSESSEMENTTYPE-LIST-POLICY')),
				"label": $(consumer(regex('[A-Za-z]*')), producer('NARRATIVE')),
				"tags": $(consumer(regex('\\w*')), producer('ASSESSEMENTTYPELIST')),
				"language": $(consumer(regex('.*')), producer('en-US')),
				"resources": $(
						"dummyKey": $(consumer(optional(regex('[\\S\\s]*'))),producer('{}'))
						),
						
				"assetGraph": $(consumer(regex('[\\S\\s]*')),producer('[]')),
				               
				"resourcePlan": [
				                 $(
				                		"label": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceElementType": $(consumer(regex('.+')), producer('dummy')),
				                		 "resourceRef": $(consumer(regex('.+')), producer('dummy')),
										 "resourceElement": $(consumer(regex('[\\S\\s]*')),producer('[]')),

				                		 )
				                 ],
				)

		headers {
			header('''Accept''', applicationJson())
			  contentType(applicationJson())
		}
	}
	response {
		status 201
		headers {
			contentType('''application/hal+json; charset=UTF-8''')
		}
	bodyMatchers {
	      jsonPath('$._id', byRegex(uuid()))
	      jsonPath('$._ver', byRegex(uuid()))
	      jsonPath('$._bssVer', byType())
	      jsonPath('$._docType', byType())
	      jsonPath('$._assetType', byType())
	    }
	    body (
	    	'''{
                  "_id": "bd414271-baa9-4b51-9847-6de209a2e0b0",
                  "_ver": "243b49fb-24a0-4081-8970-efd55773f32c",
                  "_bssVer": 1,
                  "_docType": "LEARNINGENGAGEMENT",
                  "_assetType": "LEARNINGPOLICY"
            }''')
   		}
		   priority 1
}