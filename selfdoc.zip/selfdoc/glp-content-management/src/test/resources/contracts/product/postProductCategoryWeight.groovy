package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Post product category weight success"
    request {
        method POST()
        url(value(consumer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights'), producer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights')))
        headers {
            accept(applicationJson())
            contentType(applicationJson())
        }
        body(
                gradebookCategoryPolicy: $(
                        data: $(
                                gradebookCategoryPolicies: $([
                                        $(
                                                assessmentType: $(consumer(regex('.+')), producer('HOMEWORK')),
                                                gradebookCategory: $(consumer(regex('.+')), producer('Homework')),
                                                gradebookLabel: $(consumer(regex('.+')), producer('Homework')),
                                                weight: $(consumer(regex('\\b(0*(?:[1-9][0-9]?|100))\\b')), producer(20))
                                        )
                                ])
                        )
                ),
                status:$(consumer(regex('(ACTIVE|INACTIVE)')),producer("ACTIVE"))
        )
    }
    response {
        status 201
        bodyMatchers {
            jsonPath('$._id', byType())
            jsonPath('$._ver', byType())
            jsonPath('$._bssVer', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
        }
        body('''     
  {
    "_id": "94fb6205-98e7-4415-8dc6-2542e7bd8b7b",
    "_ver": "6644106a-e220-4663-9340-320666afb366",
    "_bssVer": 1,
    "_docType": "LEARNINGENGAGEMENT",
    "_assetType": "LEARNINGPOLICY",
    "_links": {
        "self": {
            "href": "/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/categoryWeights"
        }
    }
}
    '''
        )
        headers { contentType('''application/hal+json; charset=UTF-8''') }
    }
    priority 1
}