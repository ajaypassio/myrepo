package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
    description "Post product scoring policy success"
    request {
        method POST()
        url(value(consumer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/scoringPolicy'), producer('/cms/v2/products/24159a5d-c6c0-4d38-991b-dbea95e1e82b1/versions/1527a2e7-1ac1-4e22-88f3-15b7f688283e/scoringPolicy')))
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
        body(
                scoringPolicy: $(
                        data: $(
                                assessmentTypes: $([
                                        $(
                                                assessmentType: $(consumer(regex('.+')), producer('HOMEWORK')),
                                                possiblePoints: $(consumer(regex('^-?\\d+')), producer(1)),
                                                maxAttempts: $(consumer(regex('^-?\\d+')), producer(1)),
                                                penaltyPoints: $(consumer(regex('^-?\\d+')), producer(3))
                                        )
                                ])
                        )
                )
        )
    }
    response {
        status 201
        bodyMatchers {
            jsonPath('$._id', byType())
            jsonPath('$._ver', byType())
            jsonPath('$._bssVer', byType())
            jsonPath('$._docType', byType())
            jsonPath('$._assetType', byType())
            jsonPath('$._links', byType())
            jsonPath('$._links.self', byType())
            jsonPath('$._links.self.href', byType())
        }
        body('''     
  {
    "_id": "94fb6205-98e7-4415-8dc6-2542e7bd8b7b",
    "_ver": "6644106a-e220-4663-9340-320666afb366",
    "_bssVer": 1,
    "_docType": "LEARNINGENGAGEMENT",
    "_assetType": "LEARNINGPOLICY",
    "_links": {
        "self": {
            "href": "/v2/policies/94fb6205-98e7-4415-8dc6-2542e7bd8b7b"
        }
    }
}
    '''
        )
        headers { contentType('''application/hal+json; charset=UTF-8''') }
    }
    priority 1
}