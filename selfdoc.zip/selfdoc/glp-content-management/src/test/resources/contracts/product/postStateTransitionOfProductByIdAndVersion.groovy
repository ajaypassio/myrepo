package contracts.product;

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
	description "."
	request {
		method POST()
		url(value(consumer(regex('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/6accf98a-4056-40e5-9b91-8cafbdbec729/stateTransitions'))
		, producer('/cms/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/6accf98a-4056-40e5-9b91-8cafbdbec729/stateTransitions')))
		headers {
			header('''Accept''', applicationJson())
			contentType(applicationJson())
		}
		body(
			transitionState: $(consumer(regex('LIVE')),producer('LIVE')),
			contentMetadata: $(
			  id: $(consumer(regex('.+')),producer('8883c099')),
			  version: $(consumer(regex('.+')),producer('16f6de1c'))
			),
			reason: $(consumer(regex('.+')),producer('Title Live after review')),
			reasonCode : $(consumer(regex('.+')),producer('157'))
		)
		headers {
			header('''Accept''', applicationJson())
	      	contentType(applicationJson())
    	}
    }
	response {
		status 201
		headers {
			contentType('''application/hal+json; charset=UTF-8''')
		}
	bodyMatchers {
	      jsonPath('$._id', byRegex(uuid()))
	      jsonPath('$._ver', byRegex(uuid()))
	      jsonPath('$._created', byType())
	      jsonPath('$._lastModified', byType())
	      jsonPath('$.previousState', byType())
	      jsonPath('$.transitionState', byType())
	      jsonPath('$.reason', byType())
	      jsonPath('$.reasonCode', byType())
	      jsonPath('$._links', byType())
		  jsonPath('$._links.self', byType())
		  jsonPath('$._links.self.href', byType())
		  jsonPath('$._links.status', byType())
		  jsonPath('$._links.status.href', byType())
	    }
	    body (
	    	'''{
				  "_id": "243b49fb-24a0-4081-8970-efd55773f32c",
				  "_ver": "6accf98a-4056-40e5-9b91-8cafbdbec729",
				  "_created": "2018-05-18T19:16:15+00:00",
				  "_lastModified": "2018-05-18T19:16:15+00:00",
				  "previousState": "REVIEW",
				  "transitionState": "LIVE",
				  "reason": "",
				  "reasonCode": "157",
				  "_links": {
				    "self": {
				      "href": "/v2/products/243b49fb-24a0-4081-8970-efd55773f32c/versions/6accf98a-4056-40e5-9b91-8cafbdbec729"
				    },
				    "status": {
				      "href": "/v2/products/5cc49de2-734c-491f-b10c-0e084c5bae31/status"
				    }
				  }
			}''')
   		}
		   priority 1
}