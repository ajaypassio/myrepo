package contracts.product;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "."
	request {
		method GET()
		urlPath('/cms/v2/products')
		headers {
			header('''Accept''', applicationJson())
		}
	}
	response {
		status 200
		bodyMatchers {
			jsonPath('$._count', byType())
			jsonPath('$.assets', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.assets[*]._id', byType())
			jsonPath('$.assets[*]._ver', byType())
			jsonPath('$.assets[*]._bssVer', byCommand('assertThatValueIsAInteger($it)'))
			jsonPath('$.assets[*].createdBy', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assets[*]._docType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assets[*]._assetType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assets[*]._links', byType())
			jsonPath('$.assets[*]._links.self',byType())
			jsonPath('$.assets[*]._links.self.href', byCommand('assertThatValueIsAString($it)'))
		}
		body('''
		{
  "_count": 1,
  "assets": [
    {
      "_id": "8883c099-1762-43fe-9ad8-4c9aaa6eafa2",
     "_ver": "810a3768-17af-4f2f-9d4c-b07c6cdfc672",
     "_bssVer": 1,
     "createdBy": "Admin",
     "_docType": "LEARNINGCONTENT",
      "_assetType": "PRODUCT",
      "_links": {
        "self": {
          "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
        }
      }
    }
  ]
}
		'''
				)
		headers { contentType('''application/hal+json; charset=UTF-8''') }
	}
}