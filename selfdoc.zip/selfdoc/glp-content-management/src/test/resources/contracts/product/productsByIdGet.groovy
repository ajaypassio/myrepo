package contracts.product;

import org.springframework.cloud.contract.spec.Contract

Contract.make {
	description "Get Product By Id"
	priority 1
	request {
		method GET()
		url(value(	consumer(regex('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2')), producer('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2')))
		headers {
			header('''Accept''', applicationJson())
		}
	}
	response {
		headers { contentType('''application/hal+json; charset=UTF-8''') }
		status 200
		bodyMatchers {
			jsonPath('$._id', byType())
			jsonPath('$._bssVer',byType())
			jsonPath('$._ver', byType())
			jsonPath('$._created', byType())
			jsonPath('$._lastModified', byType())
			jsonPath('$.expiresOn', byType())
			jsonPath('$._docType', byType())
			jsonPath('$._assetType', byType())
			jsonPath('$.learningModel', byType())
			jsonPath('$.learningModel._resourceType', byType())
			jsonPath('$.learningModel._docType', byType())
			jsonPath('$.learningModel._assetType',byType())
			jsonPath('$.learningModel._id',byType())
			jsonPath('$.learningModel._bssVer', byType())
			jsonPath('$.learningModel._ver', byType())
			jsonPath('$.learningModel._links', byType())
			jsonPath('$.learningModel._links.self', byType())
			jsonPath('$.learningModel._links.self.href',byType())
			jsonPath('$.tags', byType())
			jsonPath('$.label',byType())
			jsonPath('$.language', byType())
			jsonPath('$.assetClass', byType())
			jsonPath('$.objectives',byType())
			jsonPath('$.groups', byType())
			jsonPath('$.resources',byType())
			jsonPath('$.resourcePlan', byCommand('assertThatValueIsAMap($it)'))
			jsonPath('$.resourcePlan[*].label', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElementType', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceRef',byType())
			jsonPath('$.resourcePlan[*].resourceElements',  byType())
			jsonPath('$.resourcePlan[*].resourceElements[*].label', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElements[*].resourceElementType',byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.resourcePlan[*].resourceElements[*].resourceElements', byType())
			jsonPath('$.resourcePlan[*].resourceElements[*].resourceRef', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph',byType())
			jsonPath('$.assetGraph[*].startNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].endNode', byCommand('assertThatValueIsAString($it)'))
			jsonPath('$.assetGraph[*].relationships', byType())
			jsonPath('$.configuration', byType())
			jsonPath('$.constraints',byType())
			jsonPath('$.extends',byType())
			jsonPath('$._createdBy',byType())
			jsonPath('$.extensions', byType())
			jsonPath('$.scope', byType())
			jsonPath('$._links', byType())
			jsonPath('$._links.self', byType())
			jsonPath('$._links.self.href', byType())
			jsonPath('$._links.status', byType())
			jsonPath('$._links.status.href', byType())
		}
		body('''
			{  
   "_id":"8883c099-1762-43fe-9ad8-4c9aaa6eafa2",
   "_bssVer":1,
   "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
   "_created":"2018-08-01T03:54:46+00:00",
   "expiresOn": "2020-12-12T18:29:50+00:00",
   "_docType":"LEARNINGCONTENT",
   "_assetType":"PRODUCT",
   "learningModel":{  
      "_resourceType":"LEARNINGASSET",
      "_docType":"LEARNINGMODEL",
      "_assetType":"PRODUCT",
      "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
      "_bssVer":1,
      "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
      "_links":{  
         "self":{  
            "href":"/v2/productModels/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
         }
      }
   },
   "tags":"REVEL",
   "label":"PRODUCT",
   "language":"en-US",
   "assetClass":"",
   "objectives":"",
   "groups":{  

   },
   "resources":{  
      "32f42ce8":{  
         "_id":"32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f",
         "_bssVer":1,
         "_createdBy":"Admin",
         "_ver":"810a3768-17af-4f2f-9d4c-b07c6cdfc672",
         "_resourceType":"LEARNINGASSET",
         "_docType":"LEARNINGCONTENT",
         "_assetType":"AGGREGATE",
         "_links":{  
            "self":{  
               "href":"/v2/aggregates/32f42ce8-61dd-4bbc-bba5-1fdc03a0af9f/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
            }
         }
      }
   },
   "resourcePlan":[  
      {  
         "label":"INDEX",
         "resourceElementType":"HEADING",
         "resourceRef":"",
         "resourceElements":[  
            {  
               "label":"INDEX",
               "resourceElementType":"INDEX",
               "resourceElements":[  

               ],
               "resourceRef":"32f42ce8"
            }
         ]
      }
   ],
   "assetGraph":[  
      {  
         "startNode":"self",
         "endNode":"32f42ce8",
         "relationships":{  

         }
      },
      {  
         "startNode":"32f42ce8",
         "endNode":"self",
         "relationships":{  

         }
      }
   ],
   "configuration":{  

   },
   "constraints":[  

   ],
   "extends":{  

   },
   "_createdBy":"Admin",
   "_lastModified": "2018-08-01T03:54:46+00:00",
   "extensions":{
		"contentMetadata":{
			"id": "dcd035ca-bc1a-11e8-a355-529269fb1459",
			"version": "06aa73bd-db72-4210-a88a-8c24ab3ff789"
		}
	},
   "scope":{  

   },
   "_links":{  
      "self":{  
         "href":"/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/810a3768-17af-4f2f-9d4c-b07c6cdfc672"
      },
      "status":{  
         "href":"/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/status"
      }
   }
}
        ''')
	}
	
	priority 1
}
