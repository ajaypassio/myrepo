package contracts.productAssessmentRuntimeSettings.error404

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "error 404"
    request {
        method POST()
        url(value(consumer(regex('/cms/v2/products/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/versions/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/assessmentRuntimeSettings')),
                producer('/cms/v2/products/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd2/versions/e08b71a0-d9cc-11e8-9f8b-f2801f1b9fd2/assessmentRuntimeSettings')))

        body(
          assessmentTypes : $(
              [
                $(
                  assessmentType : $(consumer(regex('HOMEWORK|PRACTICE|QUIZ|DIAGNOSTIC|TEST|ConceptCheck|Non-scored')), producer('HOMEWORK')),
                  runtimeEnabled : $(consumer(regex('.+')), producer('continuousSettings')),
                  runtimeSettings : $(
                    continuousSettings : $(
                      learningAids : $([
                          $(
                            learningAidType : $(consumer(regex('ANIMATION|GRAPHER|PRINT|TEXTBOOKEXTRAS|FINANCIALCALCULATOR|HELPMESOLVETHIS|TEACHME|VIEWANEXAMPLE|SOLVEDPROBLEM|EXAMPLE')), producer('ANIMATION')),
                            value : $(consumer(regex('true|false')),producer('true'))
                          )
                      ]),
                      learningAidInReviewModeOnly : $(
                        label : $(consumer(regex('.+')), producer('Learning Aids in Review Model Only')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowContinuedWorkAfterDueDate : $(
                        label : $(consumer(regex('.+')), producer('Allow Continued Work after Due Date?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowPartialCredit : $(
                        label : $(consumer(regex('.+')), producer('Allow Partial Credit?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                    ),
                    discreetSettings : $(
                      learningAids : $([
                          $(
                            learningAidType : $(consumer(regex('ANIMATION|GRAPHER|PRINT|TEXTBOOKEXTRAS|FINANCIALCALCULATOR|HELPMESOLVETHIS|TEACHME|VIEWANEXAMPLE|SOLVEDPROBLEM|EXAMPLE')), producer('ANIMATION')),
                            value : $(consumer(regex('true|false')),producer('true'))
                          )
                      ]),
                      learningAidInReviewModeOnly : $(
                        label : $(consumer(regex('.+')), producer('Learning Aids in Review Model Only')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowContinuedWorkAfterDueDate : $(
                        label : $(consumer(regex('.+')), producer('Allow Continued Work after Due Date?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowPartialCredit : $(
                        label : $(consumer(regex('.+')), producer('Allow Partial Credit?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      saveForLater : $(
                        label : $(consumer(regex('.+')), producer('Save For Later')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      )
                    )
                  ) 
                )
              ]
            )
        )
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        headers {   
      contentType(applicationJsonUtf8())
        }
      status 404
      bodyMatchers {
      jsonPath('$.timestamp', byType())
      jsonPath('$.status', byType())
      jsonPath('$.error', byType())
      jsonPath('$.message', byType())
    }     
    body (
      '''{
        "timestamp": "2018-12-19T11:00:08+05:30",
        "status": 404,
        "error": "NOT FOUND",
        "message": "Requested Resource Not Found"
      }'''
      )
    }
  priority 2
}
