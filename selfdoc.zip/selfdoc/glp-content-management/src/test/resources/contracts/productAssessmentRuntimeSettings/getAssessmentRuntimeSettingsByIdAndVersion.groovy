package contracts.productAssessmentRuntimeSettings

import org.springframework.cloud.contract.spec.Contract

import com.jayway.jsonpath.JsonPath

Contract.make {
  description "success 200"
  request {
    method GET()
    urlPath($(  consumer('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings'),
        producer('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings')))
    headers {
      header('''Accept''', '''application/json''')
        }
    }
    response {
        status 200
        headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
    bodyMatchers {
        jsonPath('$.assessmentTypes', byType())
      jsonPath('$.assessmentTypes[*].assessmentType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeEnabled', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.learningAids',byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.learningAids.learningAidType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.learningAids.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.learningAidInReviewModeOnly', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.learningAidInReviewModeOnly.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.learningAidInReviewModeOnly.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.allowContinuedWorkAfterDueDate', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.allowContinuedWorkAfterDueDate.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.allowContinuedWorkAfterDueDate.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.allowPartialCredit', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.allowPartialCredit.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.continuousSettings.allowPartialCredit.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.learningAids',byCommand('assertThatValueIsAList($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.learningAids.learningAidType', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.learningAids.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.learningAidInReviewModeOnly', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.learningAidInReviewModeOnly.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.learningAidInReviewModeOnly.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.allowContinuedWorkAfterDueDate', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.allowContinuedWorkAfterDueDate.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.allowContinuedWorkAfterDueDate.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.allowPartialCredit', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.allowPartialCredit.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.allowPartialCredit.value', byCommand('assertThatValueIsABool($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.saveForLater', byType())
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.saveForLater.label', byCommand('assertThatValueIsAString($it)'))
      jsonPath('$.assessmentTypes[*].runtimeSettings.discreetSettings.saveForLater.value', byCommand('assertThatValueIsABool($it)'))
}
    body('''
    {
  "assessmentTypes": [
    {
      "assessmentType": "HOMEWORK",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINT",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "FINANCIALCALC",
              "value": true
            },
            {
              "learningAidType": "GUIDEDSOLUTION",
              "value": true
            },
            {
              "learningAidType": "SOLVEDPROBLEM",
              "value": true
            },
            {
              "learningAidType": "EXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINT",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "FINANCIALCALC",
              "value": true
            },
            {
              "learningAidType": "GUIDEDSOLUTION",
              "value": true
            },
            {
              "learningAidType": "SOLVEDPROBLEM",
              "value": true
            },
            {
              "learningAidType": "EXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          },
          "saveForLater": {
            "label": "Save For Later",
            "value": true
          }
        }
      }
    },
    {
      "assessmentType": "PRACTICE",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINT",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "FINANCIALCALC",
              "value": true
            },
            {
              "learningAidType": "GUIDEDSOLUTION",
              "value": true
            },
            {
              "learningAidType": "SOLVEDPROBLEM",
              "value": true
            },
            {
              "learningAidType": "EXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINT",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "FINANCIALCALC",
              "value": true
            },
            {
              "learningAidType": "GUIDEDSOLUTION",
              "value": true
            },
            {
              "learningAidType": "SOLVEDPROBLEM",
              "value": true
            },
            {
              "learningAidType": "EXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          },
          "saveForLater": {
            "label": "Save For Later",
            "value": true
          }
        }
      }
    },
    {
      "assessmentType": "QUIZ",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "saveForLater": {
            "label": "Save For Later",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        }
      }
    },
    {
      "assessmentType": "DIAGNOSTIC",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          },
          "saveForLater": {
            "label": "Save For Later",
            "value": true
          }
        }
      }
    },
    {
      "assessmentType": "TEST",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          },
          "saveForLater": {
            "label": "Save For Later",
            "value": true
          }
        }
      }
    },
    {
      "assessmentType": "ConceptCheck",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "learningAidInReviewModeOnly": {
            "label": "Learning Aids in Review Model Only",
            "value": true
          },
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          },
          "allowPartialCredit": {
            "label": "Allow Partial Credit?",
            "value": true
          },
          "saveForLater": {
            "label": "Save For Later",
            "value": true
          }
        }
      }
    },
    {
      "assessmentType": "Non-scored",
      "runtimeEnabled": "continuousSettings",
      "runtimeSettings": {
        "continuousSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          }
        },
        "discreetSettings": {
          "learningAids": [
            {
              "learningAidType": "ANIMATION",
              "value": true
            },
            {
              "learningAidType": "GRAPHER",
              "value": true
            },
            {
              "learningAidType": "PRINTER",
              "value": false
            },
            {
              "learningAidType": "TEXTBOOKEXTRAS",
              "value": true
            },
            {
              "learningAidType": "HELPMESOLVETHIS",
              "value": true
            },
            {
              "learningAidType": "TEACHME",
              "value": true
            },
            {
              "learningAidType": "VIEWANEXAMPLE",
              "value": true
            }
          ],
          "allowContinuedWorkAfterDueDate": {
            "label": "Allow Continued Work after Due Date?",
            "value": true
          }
        }
      }
    }
  ]
}
  ''')
  }
  priority 1
}