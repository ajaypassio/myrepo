package contracts.productAssessmentRuntimeSettings

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    description "Success 201"
    request {
        method POST()
        url(value(consumer(regex('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings')),
                producer('/cms/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings')))

        body(
          assessmentTypes : $(
              [
                $(
                  assessmentType : $(consumer(regex('HOMEWORK|PRACTICE|QUIZ|DIAGNOSTIC|TEST|ConceptCheck|Non-scored')), producer('HOMEWORK')),
                  runtimeEnabled : $(consumer(regex('.+')), producer('continuousSettings')),
                  runtimeSettings : $(
                    continuousSettings : $(
                      learningAids : $([
                          $(
                            learningAidType : $(consumer(regex('ANIMATION|GRAPHER|PRINT|TEXTBOOKEXTRAS|FINANCIALCALCULATOR|HELPMESOLVETHIS|TEACHME|VIEWANEXAMPLE|SOLVEDPROBLEM|EXAMPLE')), producer('ANIMATION')),
                            value : $(consumer(regex('true|false')),producer('true'))
                          )
                      ]),
                      learningAidInReviewModeOnly : $(
                        label : $(consumer(regex('.+')), producer('Learning Aids in Review Model Only')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowContinuedWorkAfterDueDate : $(
                        label : $(consumer(regex('.+')), producer('Allow Continued Work after Due Date?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowPartialCredit : $(
                        label : $(consumer(regex('.+')), producer('Allow Partial Credit?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                    ),
                    discreetSettings : $(
                      learningAids : $([
                          $(
                            learningAidType : $(consumer(regex('ANIMATION|GRAPHER|PRINT|TEXTBOOKEXTRAS|FINANCIALCALCULATOR|HELPMESOLVETHIS|TEACHME|VIEWANEXAMPLE|SOLVEDPROBLEM|EXAMPLE')), producer('ANIMATION')),
                            value : $(consumer(regex('true|false')),producer('true'))
                          )
                      ]),
                      learningAidInReviewModeOnly : $(
                        label : $(consumer(regex('.+')), producer('Learning Aids in Review Model Only')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowContinuedWorkAfterDueDate : $(
                        label : $(consumer(regex('.+')), producer('Allow Continued Work after Due Date?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      allowPartialCredit : $(
                        label : $(consumer(regex('.+')), producer('Allow Partial Credit?')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      ),
                      saveForLater : $(
                        label : $(consumer(regex('.+')), producer('Save For Later')),
                        value : $(consumer(regex('true|false')),producer('true'))
                      )
                    )
                  ) 
                )
              ]
            )
        )
            
        headers {
            header('''Accept''', applicationJson())
            contentType(applicationJson())
        }
    }
    response {
        headers { header('''Content-Type''', '''application/hal+json; charset=UTF-8''') }
        status 201
        bodyMatchers {
            jsonPath('$.deliveryPolicy', byType())
            jsonPath('$.deliveryPolicy._docType', byType())
            jsonPath('$.deliveryPolicy._assetType', byType())
            jsonPath('$.deliveryPolicy._id', byType())
            jsonPath('$.deliveryPolicy._bssVer', byType())
            jsonPath('$.deliveryPolicy._ver', byType())
            jsonPath('$.deliveryPolicy._links', byType())
            jsonPath('$.deliveryPolicy._links.self', byType())
            jsonPath('$.deliveryPolicy._links.self.href', byType())
            
            jsonPath('$.engagementPolicy', byType())
            jsonPath('$.engagementPolicy._docType', byType())
            jsonPath('$.engagementPolicy._assetType', byType())
            jsonPath('$.engagementPolicy._id', byType())
            jsonPath('$.engagementPolicy._bssVer', byType())
            jsonPath('$.engagementPolicy._ver', byType())
            jsonPath('$.engagementPolicy._links', byType())
            jsonPath('$.engagementPolicy._links.self', byType())
            jsonPath('$.engagementPolicy._links.self.href', byType())
            
            jsonPath('$.evaluationPolicy', byType())
            jsonPath('$.evaluationPolicy._docType', byType())
            jsonPath('$.evaluationPolicy._assetType', byType())
            jsonPath('$.evaluationPolicy._id', byType())
            jsonPath('$.evaluationPolicy._bssVer', byType())
            jsonPath('$.evaluationPolicy._ver', byType())
            jsonPath('$.evaluationPolicy._links', byType())
            jsonPath('$.evaluationPolicy._links.self', byType())
            jsonPath('$.evaluationPolicy._links.self.href', byType())
            
        }
        body('''
          {
            "deliveryPolicy": {
              "_docType": "LEARNINGENGAGEMENT",
              "_assetType": "LEARNINGPOLICY",
              "_id": "5ca1279d-7b8a-471f-aa98-8574c608288a",
              "_bssVer": 1,
              "_ver": "b9b308e2-9b3e-4d66-9572-98045cffd5ed",
              "_links": {
                "self": {
                  "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings"
                }
              }
            },
            "engagementPolicy": {
              "_docType": "LEARNINGENGAGEMENT",
              "_assetType": "LEARNINGPOLICY",
              "_id": "5ca1279d-7b8a-471f-aa98-8574c608288a",
              "_bssVer": 1,
              "_ver": "b9b308e2-9b3e-4d66-9572-98045cffd5ed",
              "_links": {
                "self": {
                  "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings"
                }
              }
            },
            "evaluationPolicy": {
              "_docType": "LEARNINGENGAGEMENT",
              "_assetType": "LEARNINGPOLICY",
              "_id": "5ca1279d-7b8a-471f-aa98-8574c608288a",
              "_bssVer": 1,
              "_ver": "b9b308e2-9b3e-4d66-9572-98045cffd5ed",
              "_links": {
                "self": {
                  "href": "/v2/products/8883c099-1762-43fe-9ad8-4c9aaa6eafa2/versions/200a3768-17af-4f2f-9d4c-b07c6cdfc456/assessmentRuntimeSettings"
                }
              }
            }
          }
      '''
                )
    }
    priority 1
}