package contracts.productModel.error400

import org.springframework.cloud.contract.spec.Contract;

Contract.make {
	description "post product model scoring policy for 400 handling"
	request {
		method POST()
		url(value(consumer(regex('/cms/v2/productModels/b42daf60-2528-4d7f-bb33-3b32d45034e8/versions/b23016bf-bed3-48ab-98dc-6583ac44d9ca/scoringPolicy')),
			producer('/cms/v2/productModels/b42daf60-2528-4d7f-bb33-3b32d45034e8/versions/b23016bf-bed3-48ab-98dc-6583ac44d9ca/scoringPolicy')))
		headers {
			accept(applicationJson())
			contentType(applicationJson())
		}
		body(
			scoringPolicy:$(consumer(optional(regex('.*'))),producer('{}'))
				)
	}
	response {
		headers {    contentType(applicationJsonUtf8()) }
		status 400
		bodyMatchers {
			jsonPath('$.timestamp', byType())
			jsonPath('$.status', byType())
			jsonPath('$.error', byType())
			jsonPath('$.message', byType())
		}
		body('''{
			"timestamp": "2018-12-28T11:00:08+00:00",
			"status": 400,
			"error": "BAD REQUEST",
			"message": "Invalid Request : Request Validation Failed"
		}''')
	}
	priority 2
}